# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = להורות לאתרים לא למכור או לשתף את הנתונים שלי
    .accesskey = מ
non-technical-privacy-group =
    .label = העדפות פרטיות של אתרים
do-not-track-removal3 =
    .message = איננו תומכים עוד באפשרות ”נא לא לעקוב”.
non-technical-privacy-heading =
    .label = הגנות נוספות
preferences-privacy-relay-available =
    .description = הסתרת כתובת הדוא״ל האמיתית שלך כדי להגן על תיבת הדואר הנכנס שלך מפני דואל זבל.
    .label = להציע מסכות דוא״ל של { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = הגדרות
category-nav-heading =
    .heading = הגדרות
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = חיפוש בהגדרות
    .style = width: 15.4em
managed-notice = הדפדפן שלך מנוהל על־ידי הארגון שלך.
managed-notice-info-icon =
    .alt = מידע
managed-notice-nav =
    .label = הדפדפן שלך מנוהל על־ידי הארגון שלך.
tls-key-logging-notice-nav =
    .label = ייתכן שיישומון או שירות יראו את התעבורה המוצפנת שלך.
category-list =
    .aria-label = קטגוריות
pane-general-title = כללי
pane-home-title = בית
pane-home-startup-title2 = בית והפעלה
    .title = בית והפעלה
pane-search-title2 = חיפוש
    .title = חיפוש
pane-privacy-title3 = פרטיות ואבטחה
    .title = פרטיות ואבטחה
pane-privacy-section =
    .heading = פרטיות ואבטחה
pane-sync-title3 = סנכרון
pane-ai-controls-title2 = בקרי בינה מלאכותית
    .title = בקרי בינה מלאכותית
pane-about-firefox-title = על אודות { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = מראה
    .title = { pane-appearance-title }
pane-downloads-title2 = הורדות
    .title = הורדות
pane-downloads3 =
    .heading = הורדות
pane-accessibility-title = נגישות
    .title = { pane-accessibility-title }
pane-languages-title2 = שפות
    .title = שפות
preferences-languages-header3 =
    .heading = שפות
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = נסו את התכונות הניסיוניות שלנו! הן נמצאות בפיתוח ומשתדרגות עם הזמן, דבר שעשוי להשפיע על אופן הפעולה של { -brand-short-name }. אנו מקבלים נתונים על אופן השימוש שלך בתכונות אלה רק אם האפשרות <a data-l10n-name="data-collection">נתונים טכניים ונתוני אינטראקציה</a> הופעלה.
pane-experimental-reset =
    .label = שחזור ברירות מחדל
    .accesskey = ש
help-button-label2 = תמיכה ב־{ -brand-short-name }
    .title = תמיכה ב־{ -brand-short-name }
addons-button-label2 = הרחבות וערכות נושא
    .title = הרחבות וערכות נושא
focus-search =
    .key = f
close-button =
    .aria-label = סגירה
do-not-track-removal2 =
    .label = איננו תומכים עוד בחיווי ”נא לא לעקוב”
applications-setting-new-file-types =
    .label = מה על { -brand-short-name } לעשות עם קבצים מסוג אחר?

## Browser Restart Dialog

feature-enable-requires-restart = יש להפעיל את { -brand-short-name } מחדש כדי להפעיל תכונה זו.
feature-disable-requires-restart = יש להפעיל את { -brand-short-name } מחדש כדי להשבית תכונה זו.
should-restart-title = הפעלת { -brand-short-name } מחדש
should-restart-ok = הפעלת { -brand-short-name } מחדש כעת
cancel-no-restart-button = ביטול
restart-later = הפעלה מחדש מאוחר יותר

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>‏{ $name }</strong> שולטת בהגדרה זו.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>‏{ $name }</strong> שולטת בהגדרה זו.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>‏{ $name }</strong> דורשת שימוש במגירת לשוניות.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>‏{ $name }</strong> שולטת בהגדרה זו.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>‏{ $name }</strong> שולטת באופן החיבור של { -brand-short-name } לאינטרנט.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = להפעלת ההרחבה יש לגשת לתוספות <img data-l10n-name="addons-icon"/> בתפריט <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = כדי להפעיל מחדש את ההרחבה הזו, יש לבקר ב<a data-l10n-name="addons-link">הרחבות וערכות נושא</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = ‏{ $name } שולטת בחלק מהגדרות דף הבית שלך.

## Preferences UI Search Results

search-results-header = תוצאות חיפוש
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = אין תוצאות בהגדרות לביטוי ״<span data-l10n-name="query"></span>״, עמך הסליחה.
search-results-help-link = לעזרה נוספת, נא לפנות אל <a data-l10n-name="url">אתר התמיכה של { -brand-short-name }</a>

## General Section

always-check-default =
    .label = תמיד לבדוק אם { -brand-short-name } הוא דפדפן ברירת המחדל
    .accesskey = ת
startup-restore-windows-and-tabs =
    .label = פתיחת חלונות ולשוניות קודמות
    .accesskey = פ
startup-windows-launch-on-login-profile-disabled =
    .message = ניתן להפעיל את העדפה זו על־ידי סימון האפשרות ״{ profile-manager-use-selected.label }״ בחלון ״בחירת פרופיל משתמש״.
windows-launch-on-login =
    .label = פתיחת { -brand-short-name } באופן אוטומטי כשהמחשב שלך נדלק
    .accesskey = פ
windows-launch-on-login-disabled = העדפה זו הושבתה ב־Windows. כדי לשנות אותה, יש לבקר ב<a data-l10n-name="startup-link">אפליקציות אתחול</a> בהגדרות המערכת.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = לפתוח גם לשונית חדשה
    .accesskey = ל
disable-extension =
    .label = השבתת הרחבה
preferences-data-migration-group =
    .description = העברת הסימניות, ססמאות, היסטוריה, הרחבות ונתוני המילוי אוטומטי שלך מדפדפן אחר.
    .label = ייבוא נתוני דפדפן
preferences-data-migration-button =
    .label = ייבוא נתונים
    .accesskey = י
preferences-profiles-group-header =
    .heading = פרופילים
preferences-profiles-subpane-description =
    .description = לכל פרופיל יש נתוני גלישה והגדרות נפרדים, כולל היסטוריה, ססמאות ועוד.
preferences-profiles-section-header =
    .description = לכל פרופיל יש נתוני גלישה והגדרות נפרדים, כולל היסטוריה, ססמאות ועוד.
    .label = פרופילים
preferences-manage-profiles-button =
    .label = ניהול פרופילים
preferences-profiles-settings-button =
    .label = הגדרות
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = הפרופיל החדש יעתיק את ההגדרות, התוספות, ההיסטוריה ונתונים שמורים כמו סימניות וססמאות - אבל לא פרטי החשבון או הסנכרון שלך.
    .label = העתקת פרופיל קיים
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = פרופיל להעתקה
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = בחירת פרופיל
preferences-copy-profile-button = העתקה
tabs-browsing-section =
    .heading = לשוניות וגלישה
pane-tabs-browsing-title2 = לשוניות וגלישה
    .title = לשוניות וגלישה
tabs-group-header2 =
    .label = לשוניות
tabs-opening-heading =
    .label = פתיחה
tabs-interaction-heading =
    .label = אינטראקציה
tabs-containers-heading =
    .label = מגירות
tabs-closing-heading =
    .label = סגירה
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab מחליף את הלשוניות לפי סדר השימוש בהן
    .accesskey = ל
open-new-link-as-tabs =
    .label = פתיחת קישורים בלשוניות במקום בחלונות חדשים
    .accesskey = ח
open-external-link-next-to-active-tab =
    .label = פתיחת קישורים מיישומים מיד אחרי הלשונית הפעילה שלך
ask-on-close-multiple-tabs =
    .label = לשאול לפני סגירת מספר לשוניות
    .accesskey = ל
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = לשאול לפני יציאה באמצעות { $quitKey }
    .accesskey = ל
warn-on-open-many-tabs =
    .label = הצגת אזהרה כאשר פתיחת מספר לשוניות עשויה להאט את { -brand-short-name }
    .accesskey = פ
switch-to-new-tabs-2 =
    .label = בעת פתיחת קישורים או מדיה בלשונית חדשה, יש לעבור אליה מיידית
    .accesskey = ב
show-tabs-in-taskbar =
    .label = הצגת תצוגה מקדימה של לשוניות בסרגל המשימות של Windows
    .accesskey = ת
browser-containers-enabled-2 =
    .label = שימוש במגירות לשוניות
    .accesskey = ג
browser-containers-learn-more = מידע נוסף
browser-containers-settings-2 =
    .label = ניהול הגדרות
    .accesskey = נ
containers-disable-alert-title = האם לסגור את כל מגירות הלשוניות?
startup-group =
    .label = הפעלה

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] אם האפשרות „לשוניות מגירות” תבוטל כעת, מגירת לשונית אחת תיסגר. האם ברצונך לבטל את מגירות הלשוניות?
       *[other] אם האפשרות „לשוניות מגירות” תבוטל כעת, { $tabCount } מגירות לשוניות תסגרנה. האם ברצונך לבטל את מגירות הלשוניות?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] סגירת מגירת לשונית אחת
       *[other] סגירת { $tabCount } מגירות לשוניות
    }

##

containers-disable-alert-cancel-button = להשאיר מופעל
containers-remove-alert-title = האם להסיר מגירה זו?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] אם מגירה זו תוסר, לשונית אחת תיסגר. האם ברצונך להסיר מגירה זו?
       *[other] אם מגירה זו תוסר, { $count } לשוניות תסגרנה. האם ברצונך להסיר מגירה זו?
    }
containers-remove-ok-button = להסיר מגירה זו
containers-remove-cancel-button = לא להסיר מגירה זו
settings-tabs-show-image-in-preview =
    .label = הצגת תצוגה מקדימה בעת ריחוף על לשונית
    .accessKey = ת
settings-tabs-drag-to-create-tab-groups =
    .label = גרירת לשוניות יחד ליצירת קבוצות לשוניות
browser-layout-header2 =
    .label = פריסת דפדפן
browser-layout-horizontal-tabs2 =
    .description = לשוניות למעלה
    .label = לשוניות אופקיות
    .title = לשוניות למעלה
browser-layout-vertical-tabs2 =
    .description = לשוניות בצד, בסרגל הצד
    .label = לשוניות אנכיות
    .title = לשוניות בצד, בסרגל הצד
browser-layout-show-sidebar2 =
    .description = קבלת גישה מהירה לסימניות, ללשוניות מהטלפון שלך, לצ’אטבוטים של AI ועוד מבלי לעזוב את התצוגה הראשית שלך.
    .label = הצגת סרגל צד
page-navigation-group =
    .label = ניווט בדף

## General Section - Language & Appearance

language-and-appearance-header = שפה ותצוגה
appearance-group2 =
    .description = חלק מהאתרים משנים את הצבעים שלהם כדי להתאים אותם להעדפות שלך. באפשרותך לבחור בערכת הצבעים הרצויה לך.
    .label = מראה האתר
preferences-web-appearance-choice-auto3 =
    .label = מערכת
    .title = שינוי אוטומטי של הרקעים והתכנים של אתרים בהתבסס על הגדרות המערכת שלך וערכת הנושא של { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = בהיר
    .title = שימוש במראה בהיר עבור רקעים ותכנים של אתרים.
preferences-web-appearance-choice-dark2 =
    .label = כהה
    .title = שימוש במראה כהה עבור רקעים ותכנים של אתרים.
web-appearance-group =
    .aria-label = מראה האתר
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = הגדרות בקרת הניגודיות שלך דורסות את מראה האתר.
preferences-web-appearance-link =
    .label = ניהול ערכות נושא של { -brand-short-name } בהרחבות וערכות נושא
preferences-contrast-control-group =
    .description = אתרים משתמשים במגוון של צבעי חזית וצבעי רקע. לקבלת ניגודיות עקבית, ניתן להשתמש באותם הצבעים בכל האתרים.
    .label = ניגודיות של אתרי אינטרנט
preferences-contrast-control-radio-group =
    .label = עקיפת צבעים
preferences-contrast-control-use-platform-settings =
    .label = אוטומטי (שימוש בהגדרות מערכת)
    .accesskey = א
preferences-contrast-control-off =
    .label = כבוי
    .accesskey = כ
preferences-contrast-control-custom =
    .label = התאמה אישית
    .accesskey = ה
preferences-colors-manage-button2 =
    .label = ניהול צבעים
    .accesskey = צ
preferences-colors-manage-button =
    .label = ניהול צבעים…
    .accesskey = צ
preferences-fonts-header2 =
    .label = גופנים
preferences-default-zoom-label =
    .label = מרחק מתצוגה ברירת מחדל
    .accesskey = ת
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = שינוי גודל טקסט בלבד
    .accesskey = ט
preferences-text-zoom-override-warning2 =
    .message = אם האפשרות ״שינוי גודל טקסט בלבד״ פעיל ורמת המרחק מתצוגה ברירת המחדל שלך אינה 100%, ייתכן שאתרים מסויימים לא יציגו תוכן כראוי.
language-header = שפה
choose-language-description = בחירת השפה המועדפת עליך להצגת דפים
website-language-heading =
    .description = חלק מהאתרים מוצגים במספר שפות. ניתן לבחור בשפות בסדר המועדף עליך.
    .label = שפת אתרים
website-preferred-language =
    .label = שפות מועדפות
website-language-list =
    .aria-label = שפות מועדפות
website-add-language =
    .label = הוספת שפה
website-add-language-button =
    .aria-label = הוספת השפה שנבחרה
    .title = הוספת השפה שנבחרה
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = הסרת { $locale }
    .title = הסרת { $locale }
choose-button =
    .label = בחירה…
    .accesskey = ב
choose-browser-language-description = נא לבחור את השפות בהן ייעשה שימוש להצגת תפריטים, הודעות והתרעות מ־{ -brand-short-name }.
manage-browser-languages-button =
    .label = הגדרת חלופות…
    .accesskey = ח
confirm-browser-language-change-description = יש להפעיל את { -brand-short-name } מחדש כדי להחיל את השינויים האלה
confirm-browser-language-change-button = החלה והפעלה מחדש
browser-language-heading =
    .description = בחירת השפות בהן ייעשה שימוש להצגת תפריטים, הודעות והתרעות מ־{ -brand-short-name }.
    .label = שפת הדפדפן
browser-language-preferred-label =
    .label = שפה מועדפת
browser-language-fallback-label =
    .description = בשימוש כאשר התרגום לשפה המועדפת לוקה בחסר.
    .label = שפה חלופית
browser-language-install-error =
    .message = ל־{ -brand-short-name } אין אפשרות לעדכן את השפות שלך כרגע. נא לבדוק שקיים חיבור לאינטרנט ולנסות שוב.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = חריגות…
    .accesskey = ג
settings-translations-header =
    .aria-label = תרגומים
    .description = תרגום עמודים או טקסט נבחר. כדי להגן על הפרטיות של, תרגומים נשארים במכשיר שלך.
    .label = תרגומים
settings-translations-offer-to-translate-label =
    .label = להציע תרגום של עמוד שלם
settings-translations-more-settings-button =
    .description = הגדרת העדפות עבור שפות, אתרים ותרגום לא מקוון.
    .label = הגדרות תרגום נוספות
settings-translations-subpage-header =
    .heading = הגדרות תרגום נוספות
settings-translations-subpage-speed-up-translation-header =
    .description = ניתן להוריד שפות שלמות לקבלת תרגומים מהירים יותר ולתרגם באופן לא־מקוון.
    .label = האצת התרגום
settings-translations-subpage-automatic-translation-header =
    .label = תרגום אוטומטי
settings-translations-subpage-always-translate-header =
    .label = תמיד לתרגם שפות אלו
settings-translations-subpage-never-translate-header =
    .label = לעולם לא לתרגם שפות אלו
settings-translations-subpage-never-translate-sites-header =
    .label = לעולם לא לתרגם אתרים אלו
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = כדי להוסיף אתר, יש לפתוח את <img data-l10n-name="translations-icon"/> חלונית התרגום, לבחור באפשרות <img data-l10n-name="settings-icon"/> הגדרות תרגום, ולאחר מכן לבחור באפשרות ״לעולם לא לתרגם אתר זה״
settings-translations-subpage-language-select-option =
    .label = הוספת שפה
settings-translations-subpage-language-add-button =
    .aria-label = הוספת שפה
    .title = הוספת שפה
settings-translations-subpage-download-languages-header =
    .label = הורדת שפות
settings-translations-subpage-download-languages-select-option =
    .label = בחירת שפה
settings-translations-subpage-download-languages-button =
    .aria-label = הורדת שפה
    .title = הורדת שפה
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = לא הורדו שפות
settings-translations-subpage-no-languages-added =
    .label = לא נוספו שפות
settings-translations-subpage-download-progress = ההורדה מתבצעת…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = לא ניתן היה להוריד את { $language } ({ $size }MB)
settings-translations-subpage-download-retry-button =
    .label = ניסיון חוזר
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = למחוק את { $language } ({ $size }MB)
settings-translations-subpage-download-delete-button =
    .label = מחיקה
settings-translations-subpage-download-cancel-button =
    .label = ביטול
settings-translations-subpage-no-sites-added =
    .label = לא נוספו אתרים
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = שימוש בהגדרות מערכת ההפעלה שלך עבור ״{ $localeName }״ כדי לעצב תאריכים, זמנים, מספרים ומידות.
settings-spellcheck-header =
    .label = בדיקת איות
check-user-spelling =
    .label = בדיקת איות תוך כדי הקלדה
    .accesskey = ב
spellcheck-download-dictionaries =
    .label = הורדת מילונים
spellcheck-promo =
    .heading = כיצד להשתמש בבדיקת איות
    .message = יש ללחוץ מקש ימני על שדה טקסט כדי להפעיל או לכבות את בדיקת האיות, או לשנות את השפה. לא כל השדות תומכים בבדיקת איות.

## Downloads - Files and applications

files-and-applications-title = קבצים ויישומים
download-save-files-header =
    .label = שמירת קבצים אל
download-save-where-3 =
    .aria-label = שמירת קבצים אל
download-always-ask-where2 =
    .label = לשאול היכן לשמור קבצים לפני ההורדה
    .accesskey = ש
download-private-browsing-delete2 =
    .label = מחיקת הורדות שבוצעו מחלונות פרטיים בעת סגירה
    .accesskey = מ
applications-header = יישומים
applications-description = בחירה כיצד { -brand-short-name } יטפל בקבצים שהורדו מהרשת או ביישומים שיהיו בשימוש במהלך הגלישה.
applications-setting2 =
    .description = בחירה כיצד { -brand-short-name } מטפל בקבצים ותוכן שהורד.
    .label = קבצים ויישומים
applications-filter =
    .placeholder = חיפוש סוגי קבצים או יישומים
applications-type-column =
    .label = סיווג תוכן
    .accesskey = ס
applications-type-heading = סוג תוכן
applications-action-column =
    .label = פעולה
    .accesskey = פ
applications-action-heading = פעולה
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = קובץ { $extension }‏
applications-action-save =
    .label = שמירת קובץ
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = שימוש ב־{ $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = שימוש ב־{ $app-name } (ברירת מחדל)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] שימוש ביישום ברירת המחדל של macOS
            [windows] שימוש ביישום ברירת המחדל של Windows
           *[other] שימוש ביישום ברירת המחדל של המערכת
        }
applications-use-other =
    .label = שימוש ביישום אחר…
applications-select-helper = בחירת יישום מסייע
applications-manage-app =
    .label = פרטי יישום…
applications-always-ask =
    .label = לשאול תמיד
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ‏({ $type })
applications-open-inapp =
    .label = פתיחה ב־{ -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = מה על { -brand-short-name } לעשות עם קבצים מסוג אחר?
applications-save-for-new-types =
    .label = לשמור קבצים
    .accesskey = מ
applications-save-for-new-types2 =
    .label = לשמור קבצים באופן אוטומטי
    .accesskey = ש
applications-ask-before-handling =
    .label = לשאול האם לפתוח או לשמור את הקבצים
    .accesskey = א
applications-ask-before-handling2 =
    .label = לשאול האם לפתוח או לשמור את הקבצים
    .accesskey = ל
drm-group =
    .label = תוכן ניהול זכויות קניין (DRM)
play-drm-content =
    .label = הפעלת תוכן מוגן DRM
    .accesskey = ה
play-drm-content-learn-more = מידע נוסף
# Variables:
# $version (string) - Firefox version
update-application-version = גרסה { $version } <a data-l10n-name="learn-more">מה חדש</a>
update-history-2 =
    .label = הצגת היסטוריית עדכונים
    .accesskey = ה
update-application-installation =
    .label = התקנה
update-application-radio-group =
    .aria-label = התקנה
update-application-auto-2 =
    .label = התקנת עדכונים באופן אוטומטי (מומלץ)
    .accesskey = ע
update-application-check-choose-2 =
    .label = בדיקה אחר עדכונים, אבל מתן האפשרות לבחור מתי להתקין
    .accesskey = ב
update-application-background-enabled =
    .label = כאשר { -brand-short-name } אינו פועל
    .accesskey = כ
update-application-warning-cross-user-setting-2 =
    .message = הגדרה זו תחול על כל חשבונות Windows ופרופילי { -brand-short-name } המשתמשים בהתקנה זו של { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = הצגת פחות תזכורות לעדכון
    .accesskey = פ
update-setting-write-failure-title2 = שגיאה בשמירת הגדרות העדכון
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    ‏{ -brand-short-name } נתקל בשגיאה ולא שמר את השינוי הזה. נא לשים לב כי שינוי הגדרת העדכון דורשת הרשאת כתיבה לקובץ שלהלן. ייתכן שתהיה לך או למנהל מערכת אפשרות לתקן את השגיאה על־ידי הענקת שליטה מלאה לקבוצה 'משתמשים' עבור קובץ זה.
    
    לא ניתן לכתוב לקובץ: { $path }
update-in-progress-title = העדכון בתהליך
update-in-progress-message = האם ברצונך ש־{ -brand-short-name } ימשיך בעדכון זה?
update-in-progress-ok-button = &ביטול
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &המשך

## About Firefox

about-firefox-header =
    .heading = על אודות { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = העדכונים משפרים את המהירות, היציבות והאבטחה של { -brand-short-name }.
    .label = עדכונים ל־{ -brand-short-name }
update-application-suppress-prompts-heading =
    .label = התרעות
update-application-updates-managed-by-os =
    .message = העדכונים מנוהלים על־ידי מערכת ההפעלה שלך

## Firefox support

support-application-heading =
    .description = קבלת עזרה בפתרון בעיות או שיתוף רעיונות עם הקהילה.
    .label = תמיכה ב־{ -brand-short-name }
support-get-help =
    .label = קבלת עזרה
support-share-ideas =
    .label = שיתוף רעיונות ומשוב

## Firefox newsletter

newsletter-settings-heading =
    .description = קבלת מדריכים, עצות וחדשות כדי שהחוויה שלך ב־{ -brand-product-name } תעבוד בצורה הטובה ביותר עבורך.
    .label = קבוצת דיוור של { -brand-product-name }
newsletter-sign-up-link =
    .label = הרשמה

## General Section - Performance

performance-settings-learn-more = מידע נוסף
performance-allow-hw-accel =
    .label = שימוש בהאצת חומרה כשניתן
    .accesskey = ה
performance-limit-content-process-option = הגבלת תהליך תוכן
    .accesskey = ה
performance-limit-content-process-enabled-desc = תהליכי תוכן נוספים עשויים לשפר את הביצועים בעת שימוש במספר לשוניות, עם זאת ייעשה שימוש ביותר זיכרון.
performance-limit-content-process-blocked-desc = שינוי מספר תהליכי תוכן אפשרי רק עם { -brand-short-name } מרובה תהליכים. <a data-l10n-name="learn-more">כיצד לבדוק אם ריבוי תהליכים מופעל</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (ברירת מחדל)
performance-group =
    .label = ביצועים
performance-use-recommended-settings-checkbox-2 =
    .description = הגדרות אלו מותאמות לחומרה ולמערכת ההפעלה שלך.
    .label = שימוש בהגדרות ביצועים מומלצות
    .accesskey = ה

## Accessibility page

browsing-use-autoscroll =
    .label = שימוש בגלילה אוטומטית
    .accesskey = ב
keyboard-and-scrolling-group =
    .label = ניווט וגלילה באמצעות המקלדת
motion-and-link-group =
    .label = תנועה ועיצוב קישורים
browsing-use-smooth-scrolling =
    .label = שימוש בגלילה חלקה
    .accesskey = ח
browsing-gtk-use-non-overlay-scrollbars =
    .label = תמיד להציג פסי גלילה
    .accesskey = פ
browsing-always-underline-links =
    .label = תמיד להציג קו מתחת לקישורים
    .accesskey = ק
browsing-use-onscreen-keyboard =
    .label = הצגת מקלדת מגע בעת הצורך
    .accesskey = מ
browsing-use-cursor-navigation =
    .label = תמיד להשתמש במקשי הסמן לניווט בתוך דפים
    .accesskey = ס
browsing-use-full-keyboard-navigation =
    .label = שימוש במקש ה־Tab כדי להעביר את המיקוד בין פקדי טפסים וקישורים
    .accesskey = T
browsing-search-on-start-typing =
    .label = חיפוש מלל עם תחילת הקלדה
    .accesskey = מ
settings-keyboard-shortcuts-group =
    .description = שליטה באופן הניווט והאינטראקציה ב־{ -brand-short-name }.
    .label = קיצורי מקלדת
settings-keyboard-shortcuts-customkeys-link =
    .label = התאמה אישית של קיצורי מקלדת
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = התאמה אישית של הגדרות שורת הכתובת בחיפוש
settings-media-group =
    .label = מדיה
browsing-picture-in-picture-toggle-enabled-2 =
    .label = שימוש בתמונה בתוך תמונה
    .accesskey = ת
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = להמשיך לנגן סרטונים במצב תמונה בתוך תמונה בעת מעבר בין לשוניות
    .accesskey = ס
browsing-media-control =
    .label = שליטה במדיה באמצעות מקלדת, אוזניות או ממשק וירטואלי
    .accesskey = ש
recommendations-group =
    .label = המלצות
browsing-cfr-recommendations =
    .label = קבלת המלצות על הרחבות תוך כדי גלישה
    .accesskey = ק
browsing-cfr-features =
    .label = קבלת המלצות על תכונות תוך כדי גלישה
    .accesskey = ת
browsing-group =
    .label = דפדוף
preferences-accessibility-header =
    .heading = נגישות
preferences-default-zoom-select =
    .aria-label = מרחק מתצוגה ברירת מחדל
preferences-fonts-family =
    .label = משפחת גופנים
    .accesskey = מ
preferences-fonts-size =
    .label = גודל גופן
    .accesskey = ג
preferences-fonts-advanced-settings =
    .label = הגדרות מתקדמות
    .accesskey = ה

## General Section - Proxy

network-proxy-group2 =
    .description = הגדרת אופן החיבור של { -brand-short-name } לאינטרנט.
    .label = הגדרות שרת מתווך
network-proxy-connection-settings2 =
    .description = שינוי הגדרות אלו עשוי לגרום לבעיות לחיבור לרשת
    .label = קביעת תצורה של שרת מתווך
    .accesskey = ש

## Home Section

home-new-windows-tabs-header = חלונות ולשוניות חדשים
home-new-windows-tabs-description2 = ניתן לבחור מה יופיע בעת פתיחת דף הבית שלך, חלונות חדשים ולשוניות חדשות.
home-section =
    .heading = בית והפעלה

## Home Section - Default Browser

home-default-browser-title =
    .label = דפדפן ברירת מחדל
is-default-browser-2 =
    .message = { -brand-short-name } הוא דפדפן ברירת המחדל שלך. בחירה טובה.
is-not-default-browser-2 =
    .message = פססט, { -brand-short-name } אינו דפדפן ברירת המחדל שלך.
set-as-my-default-browser-2 =
    .label = הגדרה כדפדפן ברירת המחדל
    .accesskey = ב

## Custom Homepage subpage

home-homepage-mode-label = דף הבית וחלונות חדשים
home-newtabs-mode-label = לשוניות חדשות
home-restore-defaults =
    .label = שחזור ברירות מחדל
    .accesskey = ש
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (ברירת מחדל)
home-mode-choice-custom =
    .label = כתובות מותאמות אישית…
home-mode-choice-blank =
    .label = דף ריק
home-homepage-custom-url =
    .placeholder = נא להדביק כתובת…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = ניהול הרחבה
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] שימוש בדף הנוכחי
           *[other] שימוש בדפים הנוכחיים
        }
    .accesskey = נ
choose-bookmark =
    .label = שימוש בסימנייה…
    .accesskey = ס
home-homepage-title =
    .label = דף הבית
home-homepage-new-windows =
    .label = חלונות חדשים
home-homepage-new-tabs =
    .label = לשוניות חדשות
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = בחירה באתר מסוים
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = כתובות אתרי אינטרנט
home-custom-homepage-list =
    .aria-label = כתובות אתרים
home-custom-homepage-address =
    .placeholder = נא להכניס כתובת
home-custom-homepage-address-button =
    .label = הוספת כתובת
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = עדיין לא נוספו אתרים.
home-custom-homepage-delete-address-button =
    .aria-label = מחיקת כתובת
    .title = מחיקת כתובת
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = החלפה עם
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = הדפים הפתוחים הנוכחיים
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = סימניות…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = הרחבה ({ $extension })
home-custom-homepage-header = דף בית מותאם אישית
home-custom-homepage-subpage =
    .heading = דף בית מותאם אישית

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = תוכן { -firefox-home-brand-name }
home-prefs-content-description2 = בחירת התוכן שיוצג ב{ -firefox-home-brand-name }.
home-prefs-search-header =
    .label = חיפוש ברשת
home-prefs-shortcuts-header =
    .label = קיצורי דרך
home-prefs-shortcuts-description = אתרים ששמרת או ביקרת בהם
home-prefs-shortcuts-by-option-sponsored =
    .label = קיצורי דרך ממומנים
home-prefs-recommended-by-header-generic =
    .label = סיפורים מומלצים
home-prefs-recommended-by-description-generic = תוכן יוצא דופן שנבחר בקפידה על־ידי משפחת { -brand-product-name }
home-prefs-stories-header =
    .label = סיפורים
home-prefs-stories-description = סיפורים מותאמים אישית המבוססים על הפעילות שלך

##

home-prefs-recommended-by-learn-more = איך זה עובד
home-prefs-recommended-by-option-sponsored-stories =
    .label = סיפורים ממומנים
home-prefs-highlights-option-visited-pages =
    .label = עמודים בהם ביקרת
home-prefs-highlights-options-bookmarks =
    .label = סימניות
home-prefs-highlights-option-most-recent-download =
    .label = ההורדות האחרונות
home-prefs-recent-activity-header =
    .label = פעילות אחרונה
home-prefs-recent-activity-description = מבחר של אתרים ותכנים אחרונים
home-prefs-weather-header =
    .label = מזג אוויר
home-prefs-weather-description = תחזית היום במבט חטוף
home-prefs-weather-learn-more-link = מידע נוסף
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = תמיכה ב־{ -brand-product-name }
home-prefs-mission-message = נותני החסות שלנו תומכים במשימה שלנו לבנות אינטרנט טוב יותר
home-prefs-mission-message-learn-more-link = כיצד?
home-prefs-manage-topics-link = ניהול נושאים
home-prefs-choose-wallpaper-link = בחירת תמונת רקע
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] שורה אחת
           *[other] { $num } שורות
        }

## Search Section

search-show-suggestions-option =
    .label = הצגת הצעות חיפוש
    .accesskey = ה
search-show-suggestions-url-bar-option =
    .label = הצגת הצעות חיפוש בתוצאות שורת הכתובת
    .accesskey = ח
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = הצגת הצעות חיפוש לפני היסטורית הגלישה בתוצאות שורת הכתובת
search-show-suggestions-private-windows-2 =
    .label = הצעות חיפוש בחלונות פרטיים
search-suggestions-cant-show-2 =
    .message = הצעות חיפוש לא יופיעו בתוצאות סרגל המיקום מכיוון שהגדרת ש־{ -brand-short-name } לעולם לא לזכור היסטוריה.
addressbar-header-1 =
    .description = בחירה בהצעות שיוצגו בשורת הכתובת
    .label = שורת כתובת
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = הצעות מ־{ -brand-short-name } ומהשותפים שלנו בשורת הכתובת שלך.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = הצגת מונחי חיפוש בשורת הכתובת בדפי תוצאות
search-separate-default-engine-2 =
    .label = שימוש במנוע חיפוש ברירת מחדל שונה בחלונות פרטיים
    .accesskey = ח
search-separate-default-engine-dropdown =
    .aria-label = מנוע חיפוש ברירת מחדל בחלונות פרטיים
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = ניווט בשורת הכתובת
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = דילוג על תפריט התוצאות בעת שימוש במקש ה־Tab כדי להעביר את המיקוד
search-suggestions-header-2 =
    .label = הצעות מנועי חיפוש
search-one-click-header2 = קיצורי דרך לחיפוש
search-one-click-desc = בחירת מנועי חיפוש חלופיים שיופיעו מתחת לשורת הכתובת ושורת החיפוש עם תחילת ההקלדה של מילות מפתח.
search-one-click-header-3 =
    .description = ניתן לבחור אילו מנועי חיפוש וקיצורי דרך יופיעו בשורת הכתובת שלך.
    .label = מנועי חיפוש נוספים
search-engine-list =
    .aria-label = מנועי חיפוש וקיצורי דרך
update-search-engine-success =
    .message = מנוע החיפוש עודכן בהצלחה
search-edit-engine-2 =
    .title = עריכת מנוע חיפוש
search-delete-engine =
    .title = מחיקת מנוע חיפוש
search-enable-engine =
    .title = הפעלת מנוע חיפוש
search-outlink-to-extensions-page =
    .title = ניהול בהרחבות וערכות נושא
search-choose-engine-column =
    .label = מנוע חיפוש
search-choose-keyword-column =
    .label = מילת מפתח
search-restore-default =
    .label = שחזור למנועי חיפוש ברירת מחדל
    .accesskey = ש
search-remove-engine =
    .label = הסרה
    .accesskey = ה
search-add-engine =
    .label = הוספה
    .accesskey = ה
search-add-engine-2 =
    .label = הוספת מנוע חיפוש
    .accesskey = ה
search-edit-engine =
    .label = עריכה
    .accesskey = ע
search-find-more-link = מנועי חיפוש נוספים
search-filtering-for-add-engine = הוספת מנוע
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = מילת מפתח כפולה
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = בחרת להשתמש במילת מפתח שנמצאת כרגע בשימוש על־ידי ״{ $name }״. נא לבחור במילה אחרת.
search-keyword-warning-bookmark = בחרת להשתמש במילת מפתח שנמצאת כרגע בשימוש על־ידי סימנייה. נא לבחור במילה אחרת.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = כבר קיים מנוע חיפוש בשם ״{ $name }״. נא לבחור בשם אחר.
remove-engine-confirmation = האם ברצונך להסיר את מנוע חיפוש זה?
remove-engine-remove = הסרה
remove-addon-engine-alert = כדי להסיר את מנוע חיפוש זה, יש להסיר את התוספת המשוייכת אליו.
search-engine-group =
    .label = מנוע חיפוש ברירת מחדל
search-default-engine =
    .aria-label = מנוע חיפוש ברירת מחדל
# Header for the search section ("search" is a noun).
search-section =
    .heading = חיפוש

## Containers Section

containers-section-header2 =
    .heading = הגדרות מגירה
containers-card-header2 =
    .description = הפרדת עוגיות על־ידי מגירות כך שניתן להשתמש בחשבונות שונים באותו האתר, ולהגביל מעקב חוצה אתרים.
    .label = מגירות
containers-add-button2 =
    .label = הוספת מגירה חדשה
    .accesskey = ה
containers-list =
    .aria-label = מגירות
containers-new-tab-check3 =
    .label = בחירת מגירה עבור כל לשונית חדשה
    .accesskey = ב
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = לא להשתמש במגירות עבור קישורים שנפתחו מיישומים חיצוניים
    .accesskey = ל
containers-new-tab-check2 =
    .description = אפשרות זו תפתח את תפריט המגירות בכל פעם שלוחצים על כפתור הלשונית החדשה.
    .label = בחירת מגירה עבור כל לשונית חדשה
    .accesskey = ב
containers-settings-button2 =
    .title = הגדרות
containers-remove-button3 =
    .title = מחיקה
containers-sites-card-header =
    .description = יש לבחור במגירה לאתר ו־{ -brand-short-name } ישתמש בו בכל פעם שהאתר ייפתח.
    .label = מגירות לאתרים ספציפיים
containers-sites-add-button =
    .label = הוספת אתר
    .accesskey = ה
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = מגירה עבור { $site }
containers-site-remove-button =
    .title = מחיקה
containers-remove-button2 =
    .title = הסרה

## Account and sync

sync-group-label =
    .label = סנכרון
account-group-label2 =
    .label = חשבון
account-disabled-group =
    .description = הגדרות החשבון אינן זמינות.
    .label = חשבון
account-placeholder2 =
    .description = ניתן להתחבר ולשמור על הנתונים שלך פרטיים, מוצפנים ונגישים באופן מיידי בכל מקום בו משתמשים ב־{ -brand-short-name }.
    .label = לא נכנסת לחשבון
account-sync-section =
    .heading = חשבון וסנכרון
pane-account-sync-title2 = חשבון וסנכרון
    .title = חשבון וסנכרון

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = קחו את הרשת עמכם
sync-signedout-description2 = סנכרון הסימניות, ההיסטוריה, הלשוניות, הססמאות, ההרחבות וההגדרות בין כל המכשירים שלך.
sync-signedout-account-signin3 =
    .label = כניסה כדי לסנכרן
    .accesskey = ס
sync-signedout-account-signin-4 =
    .label = יש להיכנס לחשבון שלך כדי להתחיל בסנכרון
    .accesskey = ה
sync-signedout-account-short =
    .label = כניסה
    .accesskey = כ
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = הורידו את Firefox עבור <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> או <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> כדי להסתנכרן עם המכשירים הניידים שלכם.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = שינוי תמונת פרופיל
    .tooltiptext = שינוי תמונת פרופיל
sync-profile-picture-account-problem =
    .alt = תמונת פרופיל חשבון
fxa-login-rejected-warning =
    .alt = אזהרה
sync-sign-out =
    .label = התנתקות…
    .accesskey = ה
sync-sign-out2 =
    .label = התנתקות
    .accesskey = ה
sync-manage-account = ניהול חשבון
    .accesskey = נ
sync-manage-account2 =
    .label = ניהול חשבון
    .accesskey = נ

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = הכתובת  { $email } אינה מאומתת.
sync-signedin-unverified2 =
    .description = נא לבדוק את הדוא״ל שלך כדי לאמת את החשבון שלך ולסיים את ההרשמה.
    .label = ‏{ $email } עדיין לא אומת
sync-signedin-login-failure = נא להיכנס לחשבון כדי להתחבר מחדש { $email }
sync-signedin-login-failure2 =
    .description = יש להיכנס שוב כדי להתחבר מחדש ולהתחיל לסנכרן את הנתונים שלך.
    .label = התנתקת מ־{ $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = אימות חשבון
    .accesskey = א
sync-remove-account =
    .label = הסרת חשבון
    .accesskey = ס
sync-sign-in =
    .label = כניסה
    .accesskey = כ

## Sync section - enabling or disabling sync.

prefs-syncing-on = סנכרון: פעיל
prefs-syncing-on-2 =
    .label = הסנכרון פעיל
prefs-syncing-off = סנכרון: כבוי
prefs-syncing-off-2 =
    .description = ניתן להפעיל את הסנכרון כדי לקבל את הסימניות, הססמאות, ההיסטוריה שלך ועוד בכל מכשיר.
    .label = הסנכרון כבוי
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = יש להפעיל את הסנכרון כדי לקבל את הסימניות, הססמאות, ההיסטוריה ועוד במכשיר זה.
    .label = הסנכרון כבוי
prefs-sync-turn-on-syncing =
    .label = הפעלת סנכרון…
    .accesskey = ס
prefs-sync-turn-on-syncing-2 =
    .label = הפעלת סנכרון
    .accesskey = ס
prefs-sync-offer-setup-label2 = סנכרון הסימניות, ההיסטוריה, הלשוניות, הססמאות, ההרחבות וההגדרות בין כל המכשירים שלך.
prefs-sync-now-button =
    .label = סנכרון כעת
    .accesskey = ס
prefs-sync-now-button-2 =
    .label = סנכרון כעת
    .accesskey = ס
prefs-syncing-button =
    .label = בתהליך סנכרון…
prefs-syncing-button-2 =
    .label = בתהליך סנכרון…
    .title = סנכרון כעת
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = הבחירות שלך לגבי סוגי הנתונים לסנכרון יחולו מעכשיו רק במכשיר הזה.

## The list of things currently syncing.

sync-syncing-across-devices-heading = הפריטים הבאים מסונכרנים על פני כל המכשירים המחוברים שלך:
sync-syncing-across-devices-heading-2 = נתונים המסונכרנים בין מכשירים
sync-syncing-across-devices-heading-3 = נתונים המסונכרנים במכשיר זה
sync-syncing-across-devices-empty-state2 =
    .description = שום דבר לא מסונכרן… עדיין. ניתן להתחיל לסנכרן כדי לקבל את כל הנתונים שלך בכל המכשירים שלך.
    .label = ניהול נתונים מסונכרנים
sync-syncing-across-devices-empty-state3 =
    .description = אין שום דבר מסונכרן… בינתיים. ניתן לבחור מה ברצונך לסנכרן במכשיר זה.
    .label = ניהול נתונים מסונכרנים
sync-currently-syncing-bookmarks = סימניות
sync-currently-syncing-history = היסטוריה
sync-currently-syncing-tabs = לשוניות פתוחות
sync-currently-syncing-passwords = ססמאות
sync-currently-syncing-addresses = כתובות
sync-currently-syncing-payment-methods = אמצעי תשלום
sync-currently-syncing-addons = תוספות
sync-currently-syncing-settings = הגדרות
sync-manage-options =
    .label = ניהול סנכרון…
    .accesskey = נ
sync-manage-options-2 =
    .label = ניהול נתונים מסונכרנים
    .accesskey = נ
settings-sync-disconnect-button =
    .label = התנתקות

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = סימניות
    .accesskey = ס
sync-engine-history =
    .label = היסטוריה
    .accesskey = ה
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = לשוניות פתוחות
    .tooltiptext = לשוניות פתוחות מהמכשירים האחרים שלך
    .accesskey = ל
sync-engine-tabs =
    .label = לשוניות פתוחות
    .tooltiptext = רשימה של מה שפתוח בכל ההתקנים המסונכרנים
    .accesskey = ל
sync-engine-passwords =
    .label = ססמאות
    .tooltiptext = ססמאות ששמרת
    .accesskey = ס
sync-engine-addresses2 =
    .label = כתובות
    .tooltiptext = כתובות ששמרת ב־{ -brand-short-name }
    .accesskey = כ
sync-engine-payment-methods3 =
    .label = אמצעי תשלום
    .tooltiptext = אמצעי תשלום ששמרת
    .accesskey = א
sync-engine-addons2 =
    .label = תוספות
    .tooltiptext = הרחבות וערכות נושא שהוספת ל־{ -brand-short-name } למחשבים
    .accesskey = ת
sync-engine-addresses =
    .label = כתובות
    .tooltiptext = כתובות למשלוח דואר ששמרת (שולחן עבודה בלבד)
    .accesskey = כ
sync-engine-payment-methods2 =
    .label = אמצעי תשלום
    .tooltiptext = שמות, כרטיסי מספרים ותאריכי תפוגה
    .accesskey = ל
sync-engine-addons =
    .label = תוספות
    .tooltiptext = הרחבות וערכות נושא עבור Firefox שולחני
    .accesskey = ת
sync-engine-settings =
    .label = הגדרות
    .tooltiptext = הגדרות כלליות, פרטיות ואבטחה ששינית
    .accesskey = ת
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = שמירה
    .buttonlabelextra2 = התנתקות…
    .buttonaccesskeyaccept = ש
    .buttonaccesskeyextra2 = ה
    .style = min-width: 36em;
    .title = ניהול הפריטים שמסתנכרנים בכל המכשירים המחוברים שלך
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = שמירה
    .buttonlabelextra2 = התנתקות…
    .buttonaccesskeyaccept = ש
    .buttonaccesskeyextra2 = ה
    .style = min-width: 36em;
    .title = ניהול הפריטים שמסתנכרנים במכשיר זה

## The device name controls.

sync-device-name-header = שם המכשיר
sync-device-name-header-2 =
    .label = שם המכשיר
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = שם המכשיר
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = שינוי שם מכשיר
    .accesskey = ש
sync-device-name-change =
    .label = שינוי שם מכשיר…
    .accesskey = ש
sync-device-name-cancel =
    .label = ביטול
    .accesskey = ב
sync-device-name-save =
    .label = שמירה
    .accesskey = ש
sync-connect-another-device = חיבור מכשיר נוסף
sync-connect-another-device-2 =
    .label = חיבור מכשיר נוסף

## Privacy Section

privacy-header = פרטיות דפדפן

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = ססמאות
    .searchkeywords = כניסות
forms-passwords-header =
    .aria-label = ססמאות
    .label = ססמאות
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = לבקש לשמור ססמאות
    .accesskey = ל
forms-manage-password-exceptions =
    .label = ניהול חריגות עבור ססמאות
    .accesskey = נ
forms-exceptions =
    .label = חריגות…
    .accesskey = ר
forms-suggest-passwords =
    .label = קבלת הצעה לססמה חזקה
    .accesskey = ת
forms-breach-alerts =
    .label = הצגת התרעות על ססמאות עבור אתרים שנפרצו
    .accesskey = ס
forms-breach-alerts-learn-more-link = מידע נוסף
preferences-relay-integration-checkbox2 =
    .label = הצעת מסכות דוא״ל של { -relay-brand-name } כדי להגן על כתובת הדוא״ל שלך
    .accesskey = ת
relay-integration-learn-more-link = מידע נוסף
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = מילוי שמות משתמשים וססמאות באופן אוטומטי
    .accesskey = מ
forms-fill-usernames-and-passwords-2 =
    .label = שמירה ומילוי אוטומטי של שמות משתמשים וססמאות
    .accesskey = מ
forms-saved-passwords =
    .label = ססמאות שמורות
    .accesskey = ס
forms-saved-passwords-2 =
    .label = ניהול ססמאות שמורות
    .accesskey = ס
forms-saved-passwords-searchkeywords = במחשב שלך נשמרו פרטי הכניסה לאתרים הבאים
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = הגנות נוספות
forms-primary-pw-use =
    .label = שימוש בססמה ראשית
    .accesskey = ש
forms-primary-pw-use-2 =
    .description = מוסיף שכבה נוספת של הגנה כדי להגן על הססמאות השמורות שלך.
    .label = שימוש בססמה ראשית
    .accesskey = ש
forms-primary-pw-set =
    .label = הגדרת ססמה ראשית
forms-primary-pw-on-2 = הססמה הראשית <strong>פעילה</strong>
forms-primary-pw-on =
    .label = ססמה ראשית פעילה
forms-primary-pw-change-2 =
    .label = שינוי ססמה ראשית
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = כיבוי
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = לדרוש פרטי התחברות של המכשיר כדי למלא ולנהל ססמאות
forms-os-reauth-2 =
    .label = לדרוש פרטי התחברות של המכשיר כדי לנהל ססמאות
forms-primary-pw-learn-more-link = מידע נוסף
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = שינוי ססמה ראשית…
    .accesskey = נ
forms-primary-pw-change =
    .label = שינוי ססמה ראשית…
    .accesskey = נ
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = מצבך כרגע הוא FIPS. ‏FIPS דורש ססמה ראשית לא־ריקה.
forms-master-pw-fips-desc = שינוי הססמה נכשל
forms-windows-sso =
    .label = לאפשר SSO של Windows עבור חשבונות של Microsoft, עבודה או לימודים
forms-windows-sso-learn-more-link = מידע נוסף
forms-windows-sso-desc = ניהול חשבונות בהגדרות במכשיר
windows-passkey-settings-label = ניהול passkeys בהגדרות המערכת
privacy-panel-settings-header =
    .description = קבלת סיוע בהגנה על המידע שלך ברשת ב־{ -brand-short-name }.
    .label = הגדרות חלונית הפרטיות
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = הצגת הודעות על דליפות נתונים
    .accesskey = ה

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = כדי ליצור ססמה ראשית, יש להזין את פרטי הכניסה שלך ל־Windows. פעולה זאת מסייעת בהגנה על אבטחת החשבונות שלך.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = ליצור ססמה ראשית
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] לשנות את ההגדרות עבור אמצעי תשלום
       *[other] ‏{ -brand-short-name } מנסה לשנות את ההגדרות עבור אמצעי תשלום. יש להשתמש בפרטי ההתחברות של המכשיר שלך כדי לאפשר זאת.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = אמצעי תשלום
autofill-payment-methods-checkbox-message-2 =
    .label = שמירה ומילוי אוטומטי של פרטי אמצעי תשלום
    .accesskey = ת
autofill-payment-methods-manage-payments-title =
    .heading = ניהול אמצעי תשלום
autofill-payment-methods-manage-payments-button =
    .label = ניהול אמצעי תשלום
    .accesskey = נ
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = לדרוש התחברות למכשיר כדי לבצע מילוי אוטומטי
    .accesskey = ל
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = לדרוש פרטי התחברות של המכשיר כדי למלא אוטומטית ולנהל אמצעי תשלום
    .accesskey = פ
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = שמירת קודי אבטחה
    .accesskey = ק
autofill-payment-methods-add-button = הוספת אמצעי תשלום חדש
payments-list-header =
    .label = אמצעי תשלום
payments-delete-payment-prompt-title = למחוק את אמצעי התשלום הזה?
payments-delete-payment-prompt-confirm-button = מחיקה
payments-delete-payment-prompt-cancel-button = ביטול
payments-delete-payment-button-label =
    .aria-label = מחיקה
payments-edit-payment-button-label =
    .aria-label = עריכה
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = לא נוספו אמצעי תשלום
autofill-addresses-checkbox-message =
    .label = שמירה ומילוי אוטומטי של כתובות
    .accesskey = ש
autofill-addresses-manage-addresses-button =
    .label = ניהול כתובות ועוד
    .accesskey = נ
addresses-list-header =
    .label = כתובות
addreses-delete-address-button-label =
    .aria-label = מחיקה
addreses-edit-address-button-label =
    .aria-label = עריכה
addresses-delete-address-prompt-title = למחוק את הכתובת הזאת?
addresses-delete-address-prompt-confirm-button = מחיקה
addresses-delete-address-prompt-cancel-button = ביטול
autofill-addresses-add-button = הוספת כתובת חדשה
autofill-addresses-manage-addresses-title =
    .heading = ניהול כתובות ועוד
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = לא נוספו כתובות
personal-info-group =
    .label = מידע אישי
autofill-personal-info-checkbox-message =
    .label = שמירה ומילוי אוטומטי של מידע אישי
autofill-personal-info-manage-button =
    .label = ניהול מידע אישי
passports-list-header =
    .label = דרכונים
passports-delete-passport-button-label =
    .aria-label = מחיקה
passports-edit-passport-button-label =
    .aria-label = עריכה
passports-delete-passport-prompt-title = למחוק את הדרכון הזה?
passports-delete-passport-prompt-confirm-button = מחיקה
passports-delete-passport-prompt-cancel-button = ביטול
autofill-passports-add-button = הוספת דרכון חדש
autofill-personal-info-manage-title =
    .heading = ניהול מידע אישי
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = לא נוספו דרכונים
pane-passwords-autofill-title2 = ססמאות ומילוי אוטומטי
    .title = ססמאות ומילוי אוטומטי
preferences-passwords-autofill-header =
    .heading = ססמאות ומילוי אוטומטי
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } נשמר
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } נשמר
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = כתובות ועוד
payments-group =
    .label = אמצעי תשלום

## Privacy Section - History

history-remember-option-never2 =
    .description = כל חלון פועל כמו חלון פרטי. כאשר אפשרות זו מופעלת, יש לאפשר הרחבות כדי שיפעלו.
    .label = לעולם לא לשמור היסטוריה
history-remember-option-custom2 =
    .label = התאמה אישית של ההיסטוריה
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = ‏{ -brand-short-name } יזכור את היסטוריית הגלישה, ההורדות, הטפסים והחיפוש שלך.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } ישתמש באותן ההגדרות לגלישה פרטית, ולא יזכור היסטוריה כלשהי במהלך הגלישה שלך ברשת.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = ‏{ -brand-short-name } ישתמש בהגדרות מותאמות אישית עבור היסטוריית הגלישה, ההורדות, הטפסים והחיפוש שלך.
history-private-browsing-permanent =
    .label = שימוש תמידי במצב גלישה פרטית
    .accesskey = ה
history-remember-browser-option =
    .label = שמירת היסטוריית גלישה והורדות
    .accesskey = ש
history-remember-search-option =
    .label = שמירת חיפושים והיסטוריית טפסים
    .accesskey = ט
history-clear-on-close-option =
    .label = מחיקת היסטוריה כאשר { -brand-short-name } נסגר
    .accesskey = נ
history-clear-on-close-settings =
    .label = הגדרות…
    .accesskey = ה
history-shutdown-exceptions =
    .label = ניהול חריגות
    .accesskey = נ
history-clear-button =
    .label = ניקוי היסטוריה…
    .accesskey = ה
history-header2 =
    .heading = היסטוריה
history-section-header =
    .description = בחירה בפריטים שברצונך ש־{ -brand-short-name } ישמור בעת סגירת הדפדפן.
    .label = היסטוריה
history-custom-section-header =
    .description = התאמה אישית של הפריטים שברצונך ש־{ -brand-short-name } ישמור בעת סגירת הדפדפן.
    .label = הגדרות מתקדמות
history-custom-button =
    .label = בחירה בפריטים שברצונך ש־{ -brand-short-name } ישמור
history-group =
    .label = היסטוריה
history-mode-radio-group =
    .aria-label = היסטוריה
history-remember-option-all2 =
    .label = לשמור היסטוריה

## Privacy Section - Site Data

sitedata-total-size-calculating = בתהליך חישוב גודל נתוני אתרים ומטמון…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = אתרים משתמשים כעת ב־<strong>{ $value } { $unit }</strong> משטח הדיסק.
sitedata-learn-more = מידע נוסף
sitedata-delete-on-close2 =
    .label = ניקוי עוגיות ונתוני אתרים בכל סגירת { -brand-short-name }
    .accesskey = נ
sitedata-delete-on-close-private-browsing3 =
    .message = בהתאם להגדרות ההיסטוריה שלך, { -brand-short-name } מוחק עוגיות ונתוני אתרים מההפעלה שלך בעת סגירת הדפדפן.
sitedata-delete-on-close-private-browsing4 =
    .heading = ההיסטוריה לא תישמר.
    .message = ‏{ -brand-short-name } מנקה עוגיות ונתוני אתרים מההפעלה שלך בעת סגירת הדפדפן.
sitedata-option-block-cross-site-trackers =
    .label = רכיבי מעקב חוצי אתרים
sitedata-option-block-cross-site-tracking-cookies =
    .label = עוגיות מעקב חוצות אתרים
sitedata-option-block-cross-site-cookies2 =
    .label = בידוד עוגיות חוצות אתרים
sitedata-option-block-unvisited =
    .label = עוגיות מאתרים שלא ביקרתי בהם
sitedata-option-block-all-cross-site-cookies =
    .label = כל העוגיות חוצות האתרים (עשוי לשבש פעילות של חלק מהאתרים)
sitedata-option-block-all =
    .label = כל העוגיות (ישבש פעילות של אתרים)
sitedata-clear2 =
    .label = מחיקת נתוני גלישה
    .accesskey = מ
sitedata-settings2 =
    .label = ניהול נתוני גלישה
    .accesskey = נ
sitedata-cookies-exceptions =
    .label = ניהול חריגות…
    .accesskey = ח
sitedata-cookies-exceptions2 =
    .description = באפשרותך לציין אילו אתרים תמיד מורשים או אסורים להשתמש בעוגיות ונתוני אתרים.
    .label = ניהול חריגות
    .accesskey = ח
sitedata-heading =
    .description = ניהול העוגיות, ההיסטוריה, המטמון, נתוני האתרים שלך ועוד.
    .label = נתוני גלישה
sitedata-settings3 =
    .label = ניקוי נתונים עבור אתרים ספציפיים
    .accesskey = ס
sitedata-cookies-exceptions3 =
    .description = בחירה באופן שבו אתרים ספציפיים מטפלים בעוגיות ונתוני אתרים.
    .label = ניהול חריגות
    .accesskey = נ
cookies-site-data-group =
    .label = עוגיות ונתוני אתרים

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = חוסם כרזות עוגיות
cookie-banner-blocker-description = כשאתר שואל האם הוא יכול להשתמש בעוגיות במצב גלישה פרטית, { -brand-short-name } מסרב עבורך באופן אוטומטי. רק באתרים נתמכים.
cookie-banner-learn-more = מידע נוסף
cookie-banner-blocker-checkbox-label =
    .label = סירוב אוטומטי לכרזות עוגיות

## Search Section

addressbar-locbar-history-option =
    .label = היסטוריית גלישה
    .accesskey = ג
addressbar-locbar-bookmarks-option =
    .label = סימניות
    .accesskey = ס
addressbar-locbar-clipboard-option =
    .label = לוח העריכה
    .accesskey = ל
addressbar-locbar-openpage-option =
    .label = לשוניות פתוחות
    .accesskey = ל
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = קיצורי דרך
    .accesskey = ק
addressbar-locbar-topsites-option =
    .label = אתרים מובילים
    .accesskey = מ
addressbar-locbar-engines-option-1 =
    .label = הצגת הצעות לשימוש במנועי חיפוש
    .accesskey = מ
addressbar-locbar-quickactions-option =
    .label = פעולות מהירות
    .accesskey = פ
addressbar-locbar-showrecentsearches-option-2 =
    .label = חיפושים אחרונים
    .accesskey = ח
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = הצעות חיפוש פופולריות
    .accesskey = ה
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = קבלת הצעות מהאינטרנט הקשורות לחיפוש שלך.
    .label = הצעות מ־{ -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = תמיכה ב־{ -brand-short-name } עם הצעות ממומנות מדי פעם.
    .label = הצעות מנותני חסות
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = אחזור הצעות מ־Mozilla תוך כדי הקלדה
addressbar-dismissed-suggestions-label-2 =
    .description = שחזור הצעות שנדחו מנותני חסות ומ־{ -brand-short-name }.
    .label = הצעות שנדחו
addressbar-restore-dismissed-suggestions-button-2 =
    .label = שחזור הצעות

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = הגנת מעקב מתקדמת
content-blocking-section-top-level-description = רכיבי מעקב עוקבים אחריך ברשת כדי לאסוף מידע על הרגלי הגלישה ותחומי העניין שלך. { -brand-short-name } חוסם הרבה מרכיבי המעקב האלו, לרבות תסריטים זדוניים אחרים.
content-blocking-learn-more = מידע נוסף
content-blocking-fpi-incompatibility-warning = ‏First Party Isolation (FPI) נמצא כעת בשימוש, שעוקף חלק מהגדרות העוגיות של { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = ‏Resist Fingerprinting (RFP) נמצא כעת בשימוש, שמחליף חלק מהגדרות ההגנה של { -brand-short-name } מפני מעקב זהות דיגיטלית. זה עלול לשבש פעילות של חלק מהאתרים.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = רגיל
    .accesskey = ר
enhanced-tracking-protection-setting-strict =
    .label = מחמיר
    .accesskey = מ
enhanced-tracking-protection-setting-custom =
    .label = התאמה אישית
    .accesskey = ה

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = מאוזן בין הגנה לביצועים. דפים ייטענו כרגיל.
content-blocking-etp-strict-desc = הגנה חזקה יותר, אך עשויה לשבש פעילות של אתרים או תוכן.
content-blocking-etp-custom-desc = בחירה באילו רכיבי מעקב ותסריטים יש לחסום.
content-blocking-etp-blocking-desc = ‏{ -brand-short-name } חוסם את הפריטים הבאים:
content-blocking-private-windows = תוכן מעקב בחלונות פרטיים
content-blocking-cross-site-cookies-in-all-windows2 = עוגיות חוצות אתרים בכל החלונות
content-blocking-cross-site-tracking-cookies = עוגיות מעקב חוצות אתרים
content-blocking-all-cross-site-cookies-private-windows = עוגיות חוצות אתרים בחלונות פרטיים
content-blocking-isolate-cross-site-cookies = בידוד עוגיות חוצות אתרים
content-blocking-social-media-trackers = רכיבי מעקב של מדיה חברתית
content-blocking-all-cookies = כל העוגיות
content-blocking-unvisited-cookies = עוגיות מאתרים שלא ביקרתי בהם
content-blocking-all-windows-tracking-content = תוכן מעקב בכל החלונות
content-blocking-all-cross-site-cookies = כל העוגיות חוצות האתרים
content-blocking-cryptominers = כורי מטבעות דיגיטליים
content-blocking-fingerprinters = רכיבי זהות דיגיטלית
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = רכיבי זהות דיגיטלית ידועים וחשודים
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = הגנת עוגיות מלאה מגבילה עוגיות לאתר שבו אתה נמצא, כך שרכיבי מעקב לא יכולים להשתמש בהן כדי לעקוב אחריך בין אתרים.
content-blocking-etp-standard-tcp-rollout-learn-more = מידע נוסף
content-blocking-etp-standard-tcp-title = כולל הגנת עוגיות מלאה, תכונת הפרטיות העוצמתית ביותר שלנו אי פעם
content-blocking-warning-title-2 = ייתכן שחלק מהאתרים לא יעבדו כשורה כשהגנת מעקב מחמירה פעילה
content-blocking-warning-title-custom = ייתכן שחלק מהאתרים לא יעבדו כשורה כשהגנת מעקב מותאמת אישית פעילה
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = ‏{ -brand-short-name } ממליץ להשתמש בהגדרות ״תיקון בעיות באתרים״ כדי להפחית תכונות ותוכן שבורים באתרים. אם נראה שאתר מסוים לא פועל כשורה, ניתן לנסות לכבות את הגנת המעקב עבור אותו אתר כדי לטעון את כל התוכן.
content-blocking-warning-learn-how = מידע נוסף
content-blocking-baseline-exceptions-3 =
    .description = מסייע בטעינת אתרים ותכונות על־ידי ביטול חסימה של אלמנטים חיוניים בלבד שעשויים להכיל רכיבי מעקב. זה מכסה את רוב הבעיות הנפוצות.
    .label = תיקון בעיות משמעותיות באתרים (מומלץ)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = משחזר דברים כמו סרטונים במאמר או מקטעי תגובות על־ידי ביטול חסימה של אלמנטים שעשויים להכיל רכיבי מעקב. פעולה זו יכולה להפחית בעיות באתרים אך מציעה הגנה פחותה יותר. יש להשתמש בו עם תיקונים לבעיות משמעותיות.
    .label = תיקון בעיות קלות באתרים
content-blocking-baseline-uncheck-warning-dialog-title = האם ברצונך לכבות את התיקונים?
content-blocking-baseline-uncheck-warning-dialog-body = הגדרה זו מסייעת לתקן את בעיות האתרים הנפוצות ביותר. אם הגדרה זו תכובה, ייתכן שחלק מהאתרים לא יפעלו, ו־{ -brand-short-name } לא יוכל לסייע בפתרון בעיות אלו.
content-blocking-baseline-uncheck-warning-dialog-ok-button = כיבוי התיקונים
content-blocking-baseline-uncheck-warning-dialog-cancel-button = להשאיר את התיקונים פעילים
content-blocking-reload-description = יהיה עליך לטעון מחדש את הלשוניות שלך כדי להחיל שינויים אלו.
content-blocking-reload-tabs-button =
    .label = טעינת כל הלשוניות מחדש
    .accesskey = ט
content-blocking-tracking-content-label =
    .label = תוכן מעקב
    .accesskey = ת
content-blocking-tracking-protection-option-all-windows =
    .label = בכל החלונות
    .accesskey = כ
content-blocking-option-private =
    .label = רק בחלונות פרטיים
    .accesskey = פ
content-blocking-cookies-label =
    .label = עוגיות
    .accesskey = ע
content-blocking-expand-section =
    .tooltiptext = מידע נוסף
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = כורי מטבעות דיגיטליים
    .accesskey = כ
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = רכיבי זהות דיגיטלית ידועים
    .accesskey = ד
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = רכיבי זהות דיגיטלית חשודים
    .accesskey = ח

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = ניהול חריגות…
    .accesskey = ח

## Privacy Section - Permissions

permissions-notification-pause =
    .label = השהיית התרעות עד להפעלה מחדש של { -brand-short-name }
    .accesskey = ה
permissions-autoplay2 =
    .label = ניגון אוטומטי
permissions-block-popups2 =
    .label = חסימת חלונות קופצים והפניות מצד שלישי
    .accesskey = ח
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = ניתן להוסיף אתרים שיכולים לפתוח חלונות קופצים ולהשתמש בהפניות מצד שלישי.
    .label = ניהול חריגות
    .searchkeywords = חלון קופץ
    .accesskey = נ
permissions-addon-install-warning3 =
    .label = הצגת אזהרה כשאתרים מנסים להתקין הרחבות
    .accesskey = א
permissions-addon-exceptions2 =
    .label = בחירה באתרים המורשים להתקין הרחבות
    .accesskey = ב
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = לאפשר לאתרים לבקש לפתוח קישורי יישומונים
    .accesskey = ל
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = ניהול אתרים חסומים
    .accesskey = נ
permissions-location2 =
    .label = מיקום
permissions-localhost2 =
    .label = יישומים ושירותים של מכשירים
permissions-local-network2 =
    .label = מכשירים ברשת המקומית
permissions-xr2 =
    .label = מציאות מדומה
permissions-camera2 =
    .label = מצלמה
permissions-microphone2 =
    .label = מיקרופון
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = רמקול
permissions-notification2 =
    .label = התרעות
permissions-header3 =
    .description = ניהול הפריטים שאתרים יכולים לגשת אליהם, לשלוט בהם או להפעיל.
    .label = הרשאות
permissions-data-section =
    .heading = הרשאות ונתונים
pane-permissions-data-title2 = הרשאות ונתונים
    .title = הרשאות ונתונים
notifications-section-header =
    .heading = התרעות
notifications-entry-card-header =
    .description = בחירה באילו אתרים יכולים לשלוח התרעות, וכיצד התרעות אלו יופיעו.
    .label = התרעות
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] אתר אחד
           *[other] { $count } אתרים
        }
    .label = ניהול הגדרות התרעות
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = ניהול הגדרות התרעות של אתרים
notifications-website-card-header =
    .description = בחירה באופן שבו אתרים יכולים לשלוח התרעות.
    .label = התרעות של אתרים
notifications-filter =
    .placeholder = חיפוש אתרים
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = אתר
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = לאפשר התרעות
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = אתרים
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = תמיד
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = לאפשר
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = לעולם לא
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = לא נוספו התרעות של אתרים.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = אין התרעות של אתרים התואמות את החיפוש שלך.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = כדי לוודא ששינוי זה כלול בגיבויים שלך, יש לפתוח כל פרופיל ולבחור באפשרות ״גיבוי כעת״ בהגדרות.
nimbus-rollouts =
    .description = השינויים יוחלו באופן מרוחק.
    .label = לאפשר ל־{ -brand-short-name } לשפר תכונות, ביצועים ויציבות בין עדכונים
addon-recommendations3 =
    .description = קבלת המלצות על הרחבות לשיפור חווית הגלישה שלך.
    .label = לאפשר המלצות מותאמות אישית על הרחבות
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = דיווח נתונים מושבת עבור תצורת בנייה זו.
collection-backlogged-crash-reports2 =
    .label = שליחת דיווחי קריסה באופן אוטומטי
    .accesskey = ש
collection-backlogged-crash-reports-description = זה מסייע ל־{ -vendor-short-name } לאבחן ולתקן בעיות בדפדפן. דיווחים עשויים לכלול נתונים אישיים או רגישים.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = אותן ההגדרות, מראה חדש!
    .message = אירגנו מחדש את הדף הזה כדי שיהיה קל יותר לסרוק ולעיין בו. ההגדרות האישיות שלך לא השתנו, והכל עדיין כאן. טיפ: אפשר להשתמש בחיפוש כדי לקפוץ ישר לאן שצריך.
settings-redesign-promo-dismiss-button =
    .label = הבנתי
privacy-segmentation-section-header = תכונות חדשות שמשפרות את הגלישה שלך
privacy-segmentation-section-description = כשאנחנו מציעים תכונות המשתמשות בנתונים שלך כדי להעניק לך חוויה אישית יותר:
privacy-segmentation-radio-off =
    .label = שימוש בהצעות של { -brand-product-name }
privacy-segmentation-radio-on =
    .label = הצגת מידע מפורט
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = אנו שואפים לספק לך אפשרויות בחירה ולאסוף רק את הנתונים המינימליים הדרושים כדי לשפר את { -brand-product-name } עבור כולם.
    .label = איסוף המידע של { -brand-short-name }
    .searchkeywords = טלמטריה
data-collection-link = הצגת הצהרת הפרטיות
data-collection-preferences-across-profiles =
    .message = הגדרות אלה חלות על כל פרופיל של { -brand-product-name } במכשיר זה.
data-collection-profiles-link = צפייה בכל הפרופילים
data-collection-health-report-telemetry-disabled =
    .message = אינך מאפשר יותר ל־{ -vendor-short-name } לקבל נתונים טכניים ונתוני אינטראקציה. כל המידע הקודם שלך יימחק תוך 30 ימים.
data-collection-health-report =
    .description = זה מסייע לנו לשפר את היכולות, הביצועים והיציבות של { -brand-product-name }.
    .label = שליחת נתונים טכניים ונתוני אינטראקציה אל { -vendor-short-name }
    .accesskey = ט
data-collection-health-report-disabled =
    .description = דיווח נתונים מושבת עבור תצורה הבנייה הזו.
    .label = שליחת נתונים טכניים ונתוני אינטראקציה אל { -vendor-short-name }
    .accesskey = ט
data-collection-run-studies =
    .description = ‏{ -brand-short-name } בוחר באופן אקראי משתמשים כדי לבדוק תכונות, דבר שמסייע לשפר את האיכות עבור כולם.
    .label = לאפשר ל־{ -brand-short-name } להריץ מחקרים על תכונות
data-collection-studies-link =
    .label = הצגת המחקרים של { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = זה מסייע ל־{ -vendor-short-name } לאבחן ולתקן בעיות בדפדפן. דיווחים עשויים לכלול נתונים אישיים או רגישים.
    .label = שליחת דיווחי קריסה באופן אוטומטי
    .accesskey = ש
data-collection-usage-ping =
    .description = זה מסייע ל־{ -vendor-short-name } להעריך כמה יש משתמשים פעילים.
    .label = שליחת פינג שימוש יומי אל { -vendor-short-name }
    .accesskey = פ

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = אבטחה
browsing-protection-group2 =
    .description = אתרים והורדות מסוכנות עשויות להזיק לנתונים ולמכשיר שלך. { -brand-short-name } חוסם אותם באופן אוטומטי, ומזהיר אותם מפני תוכנות מזיקות או בלתי רצויות.
    .label = הגנה מפני תוכן מטעה ותוכנה מסוכנת
security-enable-safe-browsing =
    .label = חסימת תוכן מסוכן ומטעה
    .accesskey = ת
security-enable-safe-browsing-link = מידע נוסף
security-safe-browsing-warning =
    .message = כיבוי אפשרות זו מפחית את ההגנה מפני הונאות, אתרים זדוניים והורדות מסוכנות.
security-block-downloads =
    .label = חסימת הורדות מסוכנות
    .accesskey = ה
security-block-uncommon-software =
    .label = הצגת אזהרה מפני תכניות לא רצויות ולא נפוצות
    .accesskey = ת

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = לאפשר ל־{ -brand-short-name } לתת באופן אוטומטי אמון באישורי שורש מצד שלישי שיותקנו על ידך
    .accesskey = ל
certs-devices-enable-fips = הפעלת FIPS
space-alert-over-5gb-settings-button =
    .label = פתיחת הגדרות
    .accesskey = ה
space-alert-over-5gb-message2 = <strong>ל־{ -brand-short-name } אוזל שטח הדיסק.</strong> יתכן שתכני אתרים לא יוצגו כשורה. ניתן למחוק נתונים שמורים בהגדרות > פרטיות ואבטחה > עוגיות ונתוני אתרים.
space-alert-under-5gb-message2 = <strong>ל־{ -brand-short-name } אוזל שטח הדיסק.</strong> יתכן שנתוני אתרים לא יוצגו כשורה. ניתן לבקר בקישור של “מידע נוסף” כדי לייעל את אופן השימוש בדיסק לחוויית גלישה טובה יותר.
certs-description3 =
    .description = הגדרת התצורה של האישורים שבהם { -brand-short-name } משתמש לצורך אימות חיבורים מאובטחים.
    .label = אישורי אבטחה
certs-view2 =
    .label = ניהול אישורים
    .accesskey = א
certs-devices2 =
    .label = ניהול התקני אבטחה
    .accesskey = נ

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = כיצד עובד מצב HTTPS בלבד
httpsonly-radio-enabled =
    .label = הפעלת מצב HTTPS בלבד בכל החלונות
httpsonly-radio-enabled-pbm =
    .label = הפעלת מצב HTTPS בלבד אך ורק בחלונות פרטיים
httpsonly-radio-disabled3 =
    .description = ‏ייתכן ש־{ -brand-short-name } עדיין ישדרג חלק מהחיבורים
    .label = לא להפעיל מצב HTTPS בלבד
httpsonly-group =
    .description = מאפשר רק חיבורים מאובטחים לאתרי אינטרנט. { -brand-short-name } ישאל לפני התחברות באמצעות חיבור לא מאובטח.
    .label = מצב HTTPS בלבד
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = ‏DNS על גבי HTTPS
dns-over-https-group2 =
    .description = מערכת שמות מתחם (DNS) על גבי HTTPS מצפינה את הבקשות שלך לאתרים כך שקשה יותר לספק האינטרנט שלך או לאחרים לראות לאילו אתרים מתבצעת הגישה.
    .label = ‏DNS על גבי HTTPS
preferences-doh-description2 = מערכת שמות מתחם (DNS) על גבי HTTPS שולחת את הבקשה שלך לשם מתחם דרך חיבור מוצפן, מספקת DNS מאובטח ומקשה על אחרים לראות לאיזה אתר הדפדפן עומד לגשת.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = מצב: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = ספק: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = כתובת לא תקנית
preferences-doh-steering-status = שימוש בספק מקומי
preferences-doh-status-active = פעיל
preferences-doh-status-disabled = כבוי
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = לא פעיל ({ $reason })
preferences-doh-group-message2 = הפעלת DNS על גבי HTTPS באמצעות:
preferences-doh-radio-group =
    .aria-label = הפעלת DNS על גבי HTTPS באמצעות:
preferences-doh-expand-section =
    .tooltiptext = מידע נוסף
preferences-doh-setting-default =
    .label = הגנה ברירת מחדל
    .accesskey = ב
preferences-doh-default-desc = ‏{ -brand-short-name } מחליט מתי להשתמש ב־DNS מאובטח כדי להגן על הפרטיות שלך.
preferences-doh-default-detailed-desc-1 = שימוש ב־DNS מאובטח באזורים שבהם הוא זמין
preferences-doh-default-detailed-desc-2 = שימוש במפענח ה־DNS ברירת המחדל אם יש בעיה עם ספק ה־DNS המאובטח
preferences-doh-default-detailed-desc-3 = שימוש בספק מקומי, אם ניתן
preferences-doh-default-detailed-desc-4 = כבוי כאשר VPN, בקרת הורים או מדיניות ארגונית פעילים
preferences-doh-default-detailed-desc-5 = כבוי כאשר הרשת אומרת ל־{ -brand-short-name } שעליו לא להשתמש ב־DNS מאובטח
preferences-doh-setting-enabled =
    .label = הגנה מוגברת
    .accesskey = מ
preferences-doh-enabled-desc = באפשרותך לשלוט מתי להשתמש ב־DNS מאובטח ולבחור בספק שלך.
preferences-doh-enabled-detailed-desc-1 = שימוש בספק שייבחר על ידך
preferences-doh-enabled-detailed-desc-2 = שימוש במפענח ה־DNS ברירת המחדל רק אם יש בעיה עם ה־DNS המאובטח
preferences-doh-setting-strict =
    .label = הגנה מירבית
    .accesskey = ר
preferences-doh-strict-desc = ‏{ -brand-short-name } תמיד ישתמש ב־DNS מאובטח. תוצג אזהרת סיכון אבטחה לפני שנשתמש ב־DNS של המערכת שלך.
preferences-doh-strict-detailed-desc-1 = שימוש רק בספק שייבחר על ידך
preferences-doh-strict-detailed-desc-2 = תוצג אזהרה אם DNS מאובטח אינו זמין
preferences-doh-strict-detailed-desc-3 = אם DNS מאובטח אינו זמין, האתרים לא ייטענו או יפעלו כראוי
preferences-doh-setting-off =
    .label = כבוי
    .accesskey = כ
preferences-doh-off-desc = שימוש במפענח ה־DNS ברירת המחדל שלך
preferences-doh-select-resolver = בחירת ספק:
preferences-doh-manage-exceptions =
    .label = ניהול חריגות…
    .accesskey = ח
preferences-doh-overview-default =
    .description = שימוש ב־DNS מאובטח באזורים בהם הוא זמין.
    .label = הגנה ברירת מחדל
preferences-doh-overview-custom =
    .description = תמיד להשתמש ב־DNS מאובטח עם שליטה על הספק שלך ועל אופן ההתנהגות אם הוא לא זמין.
    .label = התאמה אישית
preferences-doh-overview-off =
    .description = שימוש במפענח ה־DNS ברירת המחדל שלך.
    .label = כבוי
preferences-doh-advanced-button =
    .label = הגדרות מתקדמות
preferences-doh-advanced-section =
    .description = מערכת שמות מתחם (DNS) על גבי HTTPS מצפינה את הבקשות שלך לאתרים כך שקשה יותר לספק האינטרנט שלך או לאחרים לראות לאילו אתרים מתבצעת הגישה.
    .label = הגדרות מתקדמות
preferences-doh-manage-exceptions2 =
    .label = ניהול חריגות
    .accesskey = ח
preferences-doh-radio-default =
    .description = שימוש ב־DNS מאובטח באזורים שבהם הוא זמין
    .label = ברירת מחדל
preferences-doh-radio-custom =
    .description = תמיד להשתמש ב־DNS מאובטח עם שליטה על הספק שלך ועל אופן ההתנהגות אם הוא לא זמין
    .label = התאמה אישית
preferences-doh-radio-off =
    .description = שימוש במפענח ה־DNS ברירת המחדל שלך
    .label = כבוי
preferences-doh-fallback-label =
    .label = תמיד להזהיר אותי אם DNS מאובטח אינו זמין
preferences-doh-status-item-off =
    .message = ‏DNS על גבי HTTPS כבוי
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = ‏DNS על גבי HTTPS לא עובד מכיוון שנתקלנו בשגיאה ({ $reason }) בעת ניסיון להשתמש בספק { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = ‏DNS על גבי HTTPS לא עובד מכיוון שקיבלנו כתובת לא תקנית ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = ‏DNS על גבי HTTPS משתמש בספק { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = ‏DNS על גבי HTTPS לא עובד מכיוון שנתקלנו בשגיאה ({ $reason }) בעת ניסיון להשתמש בספק המקומי { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = ‏DNS על גבי HTTPS משתמש בספק המקומי { $name }
preferences-doh-select-resolver-label =
    .label = בחירת ספק:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = שימוש בספק זה כדי לפענח DNS על גבי HTTPS
preferences-doh-custom-provider-label =
    .aria-label = נא להכניס כתובת ספק מותאם אישית
preferences-doh-header2 =
    .heading = ‏DNS על גבי HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = אבטחת חיבור ותוכנה
preferences-connection-link-section =
    .description = כאן ניתן לראות כיצד החיבורים נשארים מאובטחים, תוכנות מזיקות נחסמות, ואתרים מאומתים.
    .label = אבטחת חיבור ותוכנה
preferences-connection-link-button =
    .label = הגדרות מתקדמות

## The following strings are used in the Download section of settings

desktop-folder-name = שולחן עבודה
downloads-folder-name = הורדות

## Appearance page

preferences-appearance-header =
    .heading = מראה
browser-theme-group =
    .description = ניתן לעצב את { -brand-short-name } בדרך שלך. צבעי ערכת הנושא חלים על סרגלי כלים, תפריטים והודעות.
    .label = ערכת הנושא של הדפדפן
browser-theme-manage-link =
    .label = ניהול ערכות נושא ב־{ -brand-short-name }
appearance-window-density-group =
    .description = התאמת המרווחים מסביב לרכיבים בחלון כמו סרגל הכלים, הלשוניות וסרגל הצד.
    .label = צפיפות החלון
appearance-window-density-radio-group =
    .aria-label = צפיפות החלון
appearance-window-density-automatic =
    .description = מרווח רגיל, צפוף או מגע מוחל באופן אוטומטי
    .label = אוטומטית (ברירת מחדל)
appearance-window-density-automatic-no-touch =
    .description = מרווח רגיל או צפוף מוחל באופן אוטומטי
    .label = אוטומטית (ברירת מחדל)
appearance-window-density-standard =
    .description = מרווח מאוזן עבור רוב המסכים
    .label = רגילה
appearance-window-density-auto-touch-mode =
    .label = שימוש במרווח של מגע עבור מצב מחשב לוח
appearance-window-density-compact =
    .description = מרווח מצומצם עבור מסכים קטנים יותר
    .label = צפופה
appearance-window-density-touch =
    .description = רכיבי חלון ואזורי לחיצה גדולים יותר, המותאמים למסכי מגע
    .label = מגע
related-settings-group =
    .label = הגדרות קשורות
related-settings-accessibility-link =
    .label = התאמה אישית של הגדרות מרחק מתצוגה וגופנים בתפריט נגישות
related-settings-home-link =
    .label = התאמה אישית של { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = התאמה אישית של פריסת הדפדפן

## AI controls page

preferences-ai-controls-description = תמיד יש לך אפשרות בחירה ב־{ -brand-short-name }, לרבות האם להשתמש בתכונות משופרות באמצעות בינה מלאכותית. בקרוב יהיו הגדרות נוספות.
preferences-ai-controls-block-ai-label = חסימת שיפורי בינה מלאכותית
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = חסימה פירושה שלא יוצגו שיפורי בינה מלאכותית חדשים או קיימים ב־{ -brand-short-name }, או חלונות קופצים לגביהם. <a data-l10n-name="link">קבלת פרטים נוספים</a> על מה כלול וכיצד לשלוט בתכונות למידת מכונה מסורתיות, כמו הצעות חיפוש והמלצות.
preferences-ai-controls-blocked-message =
    .message = שיפורי בינה מלאכותית חדשים ונוכחיים חסומים כברירת מחדל. כדי לבטל חסימה של תכונה ספציפית, יש להשתמש בפקדים שלהלן.
preferences-ai-controls-on-device-group =
    .description = אלו משתמשים במודלי בינה מלאכותית קטנים המורדים למכשיר שלך אם נעשה שימוש בתכונה. גישה זו מסייעת לשמור על הפרטיות שלך.
    .label = בינה מלאכותית במכשיר
preferences-ai-controls-translations-control =
    .description = גלישה חלקה באינטרנט בשפה המועדפת עליך.
    .label = תרגומים
preferences-ai-controls-translations-more-link = הגדרות תרגום נוספות
preferences-ai-controls-pdfjs-control =
    .description = בעת הוספת תמונות לקובצי PDF, זה מוסיף תיאורים כדי להפוך אותם לנגישים.
    .label = טקסט חלופי לתמונה במציג PDF של { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = קבלת הצעות לשמות ולארגון הלשוניות שלך.
    .label = הצעות לקבוצות לשוניות
preferences-ai-controls-key-points-control =
    .description = הצגת סיכום מהיר לפני פתיחת קישור.
    .label = נקודות מפתח בתצוגות מקדימות של קישורים
preferences-ai-controls-speech-recognition-control =
    .description = תמלול דיבור באופן מקומי.
    .label = זיהוי דיבור
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = ניתן להשאיר צ’אטבוט בתצוגה בזמן הגלישה. יש אפשרות בחירה מבין מספר ספקים הניתנים להחלפה בכל עת.
    .label = ספקי צ’אטבוטים של בינה מלאכותית בסרגל הצד
preferences-ai-controls-sidebar-chatbot-group =
    .description = להשאיר צ’אטבוט בתצוגה תוך כדי גלישה. ניתן לבחור מבין Anthropic Claude, ChatGPT, Copilot, Google Gemini, ו־Le Chat Mistral.
    .label = ספקי צ’אטבוטים של בינה מלאכותית בסרגל הצד
preferences-ai-controls-sidebar-chatbot-control =
    .label = צ’אטבוט בסרגל הצד
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = זמין
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = מופעל
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = חסום
preferences-ai-controls-state-description-before = מה המשמעות של האפשרויות:
preferences-ai-controls-state-description-available = <strong>זמין:</strong> התכונה גלויה וניתן להשתמש בה.
preferences-ai-controls-state-description-enabled = <strong>מופעל:</strong> בחרת להשתמש בתכונה.
preferences-ai-controls-state-description-blocked = <strong>חסום:</strong> התכונה לא גלויה ולא ניתן להשתמש בה. עבור בינה מלאכותית במכשיר, כל המודלים שכבר הורדו יוסרו.
preferences-ai-controls-block-confirmation-heading = לחסום שיפורי בינה מלאכותית?
preferences-ai-controls-block-confirmation-description = לא יוצגו שיפורי בינה מלאכותית חדשים או קיימים ב־{ -brand-short-name }, או חלונות קופצים לגביהם. לאחר מכן, יהיה באפשרותך לבטל את החסימה של כל דבר שברצונך להמשיך להשתמש.
preferences-ai-controls-block-confirmation-features-start = מה ייחסם:
preferences-ai-controls-block-confirmation-translations = תרגומים
preferences-ai-controls-block-confirmation-pdfjs = טקסט חלופי לתמונה במציג PDF של { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = הצעות לקבוצות לשוניות
preferences-ai-controls-block-confirmation-key-points = נקודות מפתח בתצוגות מקדימות של קישורים
preferences-ai-controls-block-confirmation-sidebar-chatbot = ספקי צ’אטבוטים בסרגל הצד
preferences-ai-controls-block-confirmation-speech-recognition = זיהוי דיבור
preferences-ai-controls-block-confirmation-features-after = החסימה משפיעה גם על הרחבות המשתמשות בבינה מלאכותית המסופקת על־ידי { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = ביטול
preferences-ai-controls-block-confirmation-confirm =
    .label = חסימה
preferences-ai-controls-header3 =
    .heading = בקרי בינה מלאכותית

## Privacy and security status card

security-privacy-status-ok-header = ‏{ -brand-short-name } עומד על המשמר
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = ‏{ -brand-short-name } ממליץ על מספר שיפורי אבטחה
security-privacy-status-ok-label = הגנת מעקב מתקדמת פעילה
security-privacy-status-problem-label = מצאנו הגדרות המשפיעות על ההגנה שלך
security-privacy-status-problem-helper-label = הצגת הסוגיות
security-privacy-status-pending-trackers-label = מחפש כמה רכיבי מעקב { -brand-short-name } חסם במהלך החודש האחרון
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] רכיב מעקב אחד נחסם במהלך החודש האחרון
       *[other] { $trackerCount } רכיבי מעקב נחסמו במהלך החודש האחרון
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = יש לך <a data-l10n-name="strict-tracking-protection">הגנה מחמירה</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = יש לך <a data-l10n-name="custom-tracking-protection">הגנה מותאמת אישית</a>
security-privacy-status-up-to-date-label = יש לך את הגרסה העדכנית והבטוחה ביותר של { -brand-short-name }
security-privacy-status-update-needed-label = זמינה גרסה חדשה של { -brand-short-name }.
security-privacy-status-update-error-label = ‏{ -brand-short-name } מתקשה לעדכן את עצמו
security-privacy-status-update-checking-label = ‏{ -brand-short-name } מחפש אחר עדכונים
security-privacy-status-update-needed-description = יש לעדכן לקבלת עדכוני המהירות, היציבות והאבטחה האחרונים.
security-privacy-status-update-button-label =
    .label = עדכון { -brand-short-name }
security-privacy-image-warning =
    .alt = מגן עם סימן קריאה, המביע דאגה לגבי אזהרות האבטחה שלך
security-privacy-image-ok =
    .alt = מגן עם סימן וי, המראה שאין לך בעיות אבטחה
security-privacy-issue-card =
    .heading = אזהרות אבטחה
issue-card-reset-button =
    .label = איפוס
issue-card-dismiss-button =
    .aria-label = סגירה
    .tooltiptext = סגירה

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = אתרים משתמשים ברכיבי מעקב כדי לעקוב אחריך ברשת ולהציג פרסומות מציקות. { -brand-short-name } מגן עליך תוך כדי גלישה, וחוסם רכיבי מעקב באופן אוטומטי כך שיש לך שליטה על העקבות הדיגיטליים שלך.
    .label = הגנת מעקב מתקדמת
preferences-etp-level-radio-group =
    .aria-label = הגנת מעקב מתקדמת
preferences-etp-level-standard =
    .description = הגנות חזקות ומהימנות שעובדות בצורה חלקה עם רוב האתרים.
    .label = רגיל (ברירת מחדל)
preferences-etp-level-strict =
    .description = הגנות חזקות יותר שחוסמות את רוב רכיבי המעקב, אך עשויות לגרום לחלק מהאתרים להישבר.
    .label = מחמיר
preferences-etp-level-custom =
    .description = בחירה באילו הגנות להפעיל או לכבות.
    .label = התאמה אישית
preferences-etp-status-advanced-button =
    .label = הגדרות מתקדמות
preferences-etp-tracker-count-enabled =
    .label = הצגת כמות רכיבי המעקב החסומים בשורת הכתובת
preferences-etp-status-protections-dashboard-link =
    .description = ניתן לצפות בכמה רכיבי מעקב { -brand-short-name } חסם עבורך, לרבות רכיבי מעקב של מדיה חברתית, רכיבי זהות דיגיטלית וכורי מטבעות דיגיטליים.
    .label = צפייה בלוח המחוונים של ההגנות המותאמות אישית שלך
preferences-etp-header =
    .heading = הגנת מעקב מתקדמת
preferences-etp-advanced-settings-group =
    .description = אתרים משתמשים ברכיבי מעקב כדי לעקוב אחריך ברשת ולהציג פרסומות מציקות. { -brand-short-name } מגן עליך תוך כדי גלישה, וחוסם את רוב רכיבי המעקב באופן אוטומטי כך שיש לך שליטה על העקבות הדיגיטליים שלך.
    .label = הגדרות מתקדמות
preferences-etp-customize-button =
    .label = התאמה אישית של הגנת המעקב
preferences-etp-reload-tabs-hint =
    .message = יש לטעון מחדש את הלשוניות שלך כדי להחיל את השינויים האלה.
preferences-etp-reload-tabs-hint-button =
    .label = טעינת כל הלשוניות מחדש
preferences-etp-rfp-warning-message =
    .message = ‏Resist Fingerprinting (RFP) נמצא כעת בשימוש, שמחליף חלק מהגדרות ההגנה של { -brand-short-name } מפני מעקב זהות דיגיטלית. זה עלול לשבש פעילות של חלק מהאתרים.
preferences-etp-level-warning-message =
    .heading = לתשומת ליבך! ייתכן שחלק מהאתרים לא יפעלו כצפוי.
    .message = חלק מהאתרים בונים רכיבי מעקב כחלק מהיכולות, האפשרויות או התוכן שלהם. כאשר { -brand-short-name } חוסם אותם, האתר נראה שבור. כדאי לנסות את האפשרות ״תיקון בעיות באתר״ או לכבות את הגנת המעקב עבור אותו אתר.
preferences-etp-manage-exceptions-button =
    .description = ניהול אתרים שבהם הגנת המעקב המתקדמת מושבתת.
    .label = ניהול חריגות
preferences-etp-customize-header =
    .heading = התאמה אישית של הגנת המעקב
preferences-etp-reset =
    .description = מאפס את ההגדרות לרמת הגנה מוגדרת מראש.
    .label = איפוס התאמות אישיות
preferences-etp-reset-standard-button =
    .label = איפוס למצב רגיל
preferences-etp-reset-strict-button =
    .label = איפוס למצב מחמיר
preferences-etp-custom-control-group =
    .description = בחירה באילו הגנות להפעיל או לכבות.
    .label = הגנת מעקב
preferences-etp-custom-cookies-enabled =
    .label = עוגיות
preferences-etp-custom-cookie-behavior =
    .aria-label = עוגיות
preferences-etp-custom-cookie-behavior-accept-all =
    .label = לאפשר את כל העוגיות
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = חסימת עוגיות מעקב חוצות אתרים
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = חסימת עוגיות חוצות אתרים
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = בידוד עוגיות חוצות אתרים
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = חסימת עוגיות מאתרים שלא ביקרתי בהם
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = חסימת כל העוגיות חוצות האתרים (עשוי לשבש פעילות של חלק מהאתרים)
preferences-etp-custom-cookie-behavior-block-all =
    .label = חסימת כל העוגיות (ישבש פעילות של אתרים)
preferences-etp-custom-tracking-protection-enabled =
    .label = תוכן מעקב
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = תוכן מעקב
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = כורי מטבעות דיגיטליים
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = רכיבי זהות דיגיטלית ידועים
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = רכיבי זהות דיגיטלית חשודים
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = רכיבי זהות דיגיטלית חשודים

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = זה עשוי לאפשר לחלק מרכיבי המעקב לעקוב אחריך ללא עוגיות.
    .label = רכיבי זהות דיגיטלית ידועים אינם חסומים
security-privacy-issue-warning-third-party-cookies =
    .description = עוגיות צד שלישי משמשות למעקב אחר הפעילות שלך בין אתרים שונים.
    .label = עוגיות צד שלישי מופעלות
security-privacy-issue-warning-password-manager =
    .description = מנהל הססמאות מסייע לך לאחסן ססמאות חזקות עבור החשבונות שלך.
    .label = מנהל הססמאות מושבת
security-privacy-issue-warning-popup-blocker =
    .description = חלונות קופצים פוגעים ברצף הגלישה ועלולים להזיק.
    .label = חוסם חלונות קופצים מושבת
security-privacy-issue-warning-extension-install =
    .description = אתרים יכולים להתקין הרחבות ב־{ -brand-short-name } מבלי לשאול.
    .label = אתרים יכולים להתקין הרחבות
security-privacy-issue-warning-safe-browsing =
    .description = החשיפה שלך להונאות ותוכנות זדוניות מאתרים גדלה.
    .label = תוכן מסוכן ומטעה אינו חסום
security-privacy-issue-warning-doh2 =
    .description = ‏DNS על גבי HTTPS מסייע להסתיר מפני ספק האינטרנט שלך לדעת לאילו אתרים עומדים להיכנס.
    .label = ‏DNS על גבי HTTPS מושבת
security-privacy-issue-warning-ech2 =
    .description = ‏Encrypted Client Hello מסייע להסתיר מפני ספק האינטרנט שלך לדעת לאילו אתרים עומדים להיכנס.
    .label = ‏Encrypted Client Hello מושבת
security-privacy-issue-warning-doh =
    .description = ‏DNS על גבי HTTPS מסתיר מספק האינטרנט שלך את האתרים שאליהם ניגשים.
    .label = ‏DNS על גבי HTTPS מושבת
security-privacy-issue-warning-ech =
    .description = ‏Encrypted Client Hello מסתיר מספק האינטרנט שלך את האתרים אליהם ניגשים.
    .label = ‏Encrypted Client Hello מושבת
security-privacy-issue-warning-proxy-autodetection =
    .description = הגדרה אוטומטית של שרת מתווך עשויה לאפשר לרשתות שאינן מהימנות לנטר אחר הפעילות שלך.
    .label = הגדרה אוטומטית של שרת מתווך מופעלת

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = אפשר להזמין מישהו לבחור את הדפדפן ששם את הפרטיות במקום הראשון.
    .label = שיתוף { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = שיתוף { -brand-product-name }


pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = שינויים ל-about:config, מקובצים לוגית ונגישים בקלות
vorbit-header = העדפות vOrbit-lite
vorbit-warning-title = שימו לב!
vorbit-warning-description = הגדרות ברירת המחדל נבחרו בקפידה בדגש על פרטיות ואבטחה. לפני שינוי של ההגדרות האלו, יש לקרוא את התיאור שלהן כדי להבין את ההשלכות.
vorbit-general-heading = התנהגות הדפדפן
vorbit-extension-update-checkbox =
    .label = עדכון תוספים אוטומטית
vorbit-sync-checkbox =
    .label = שימוש ב-Firefox Sync
vorbit-autocopy-checkbox =
    .label = הדבקה באמצעות לחצן העכבר האמצעי
vorbit-styling-checkbox =
    .label = התאמה אישית של userChrome.css
vorbit-network-heading = רשת
vorbit-ipv6-checkbox =
    .label = שימוש ב-IPv6
vorbit-privacy-heading = פרטיות
vorbit-webgl-checkbox =
    .label = שימוש ב-WebGL
vorbit-rfp-checkbox =
    .label = שימוש ב-ResistFingerprinting
vorbit-security-heading = אבטחה
vorbit-ocsp-warning1 = זה מגביר את רמת האבטחה, אך יגרום לשבירה כששרת OCSP יהיה מושבת.
vorbit-sync-description = סנכרנו את הנתונים עם דפדפנים אחרים. דורש הפעלה מחדש.
vorbit-sync-warning1 = Firefox Sync מצפין את הנתונים מקומית לפני שהוא שולח אותם לשרת.
vorbit-autocopy-description = בחרו טקסט כדי להעתיק אותו, ואז הדביקו אותו עם לחיצה על המקש האמצעי בעכבר.
vorbit-styling-description = אפשרו את זה כדי להתאים אישית את ממשק המשתמש עם ערכת נושא שתיטען ידנית.
vorbit-styling-warning1 = אנא ודאו שניתן לסמוך על ספק ערכת הנושא.
vorbit-footer = קישורים שימושיים
vorbit-open-profile = פתיחת תיקיית פרופיל המשתמש
vorbit-config-link = כל ההגדרות המתקדמות (about:config)
vorbit-goog-safe-download-warning1 = כל הבדיקות נערכות מקומית.
vorbit-goog-safe-warning1 = כבוי עקב חשש מצנזורה אך מומלץ למשתמשים פחות מתקדמים. כל הבדיקות נערכות מקומית.
vorbit-goog-safe-description = אם יש לך חשש מתוכנות זדוניות ומדיוג, יש לשקול לאפשר את זה.
