# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = ‏{ -brand-shortcut-name } במצב גלישה פרטית
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = גלישה מהירה ופרטית באינטרנט
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] ‏{ -brand-full-name } - גלישה פרטית
       *[other] גלישה פרטית של { -brand-full-name }
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = גלישה פרטית
popups-infobar-dont-show-message2 =
    .label = לא להציג הודעה זו כאשר חלונות קופצים או הפניות מצד שלישי נחסמים
    .accesskey = ל
edit-popup-settings2 =
    .label = ניהול הגדרות חלונות קופצים והפניות צד שלישי…
    .accesskey = נ
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] הצגת מידע אתר
            [1] הצגת מידע אתר (רכיב מעקב אחד נחסם)
           *[other] הצגת מידע אתר ({ $count } רכיבי מעקב נחסמו)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] קישור אחד
           *[other] { $count } קישורים
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = ‏AirDrop, הודעות ועוד…
    .accesskey = ה
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = הודעות, דואר ועוד…
    .accesskey = ד
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = שיתוף…
    .accesskey = ש
urlbar-identity-button =
    .aria-label = הצגת נתוני אתר

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = פתיחת חלונית הודעת התקנה
urlbar-web-notification-anchor =
    .tooltiptext = החלפת מצב קבלת התרעות מהאתר
urlbar-midi-notification-anchor =
    .tooltiptext = פתיחת חלונית MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = פתיחת חלונית התקשורת הטורית
urlbar-eme-notification-anchor =
    .tooltiptext = ניהול השימוש בתכניות DRM
urlbar-web-authn-anchor =
    .tooltiptext = פתיחת חלונית Web Authentication
urlbar-canvas-notification-anchor =
    .tooltiptext = ניהול הרשאות חילוץ ממשטח ציור
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = ניהול שיתוף המיקרופון שלך עם האתר
urlbar-default-notification-anchor =
    .tooltiptext = פתיחת חלונית הודעות
urlbar-geolocation-notification-anchor =
    .tooltiptext = פתיחת חלונית בקשת מיקום
urlbar-localhost-notification-anchor =
    .tooltiptext = ניהול גישה למכשיר מקומי עבור אתר זה
urlbar-local-network-notification-anchor =
    .tooltiptext = ניהול שיתוף הגישה לרשת המקומית שלך עם אתר זה
urlbar-xr-notification-anchor =
    .tooltiptext = פתיחת חלונית הרשאות למציאות מדומה
urlbar-storage-access-anchor =
    .tooltiptext = פתיחת חלונית הרשאות לפעילות בדפדפן
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = ניהול שיתוף החלונות או המסך שלך עם האתר
urlbar-indexed-db-notification-anchor =
    .tooltiptext = פתיחת חלונית הודעת אחסון לא מקוון
urlbar-password-notification-anchor =
    .tooltiptext = פתיחת חלונית הודעת שמירת ססמה
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = ניהול שיתוף המצלמה ו/או המיקרופון שלך עם האתר
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = ניהול שיתוף רמוקלים אחרים עם האתר
urlbar-autoplay-notification-anchor =
    .tooltiptext = פתיחת לוח ניגון אוטומטי
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = שמירת נתונים באחסון קבוע
urlbar-addons-notification-anchor =
    .tooltiptext = פתיחת חלונית ההודעות של התקנת תוספות
urlbar-search-tips-confirm = בסדר, הבנתי
urlbar-search-tips-confirm-short = הבנתי
urlbar-result-menu-button =
    .title = פתיחת תפריט
urlbar-result-menu-button-feedback = משוב
    .title = פתיחת תפריט
urlbar-result-menu-learn-more2 = מידע נוסף
    .accesskey = מ
urlbar-result-menu-remove-from-history2 = הסרה מההיסטוריה
    .accesskey = ה
urlbar-result-menu-tip-get-help2 = קבלת עזרה
    .accesskey = ע
urlbar-result-menu-dismiss-suggestion2 = סגירה הצעה זו
    .accesskey = ס
urlbar-result-menu-remove-top-site = הסרת האתר המוביל הזה
    .accesskey = ה
urlbar-result-menu-manage-firefox-suggest2 = ניהול { -firefox-suggest-brand-name }
    .accesskey = נ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = דיווח על מיקום לא מדויק
    .accesskey = ד
urlbar-result-menu-show-less-frequently3 = להציג בתדירות נמוכה יותר
    .accesskey = ל
urlbar-result-menu-dont-show-weather-suggestions3 = לא להציג הצעות מזג אוויר
    .accesskey = ל
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = דיווח על מיקום לא מדויק
urlbar-result-menu-show-less-frequently2 = להציג בתדירות נמוכה יותר
urlbar-result-menu-dont-show-weather-suggestions2 = לא להציג הצעות מזג אוויר
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = סגירת הצעה זו
    .accesskey = ס
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = הסרה מההיסטוריה
    .accesskey = ה
urlbar-result-menu-learn-more =
    .label = מידע נוסף
    .accesskey = מ
urlbar-result-menu-remove-from-history =
    .label = הסרה מההיסטוריה
    .accesskey = ה
urlbar-result-menu-tip-get-help =
    .label = קבלת עזרה
    .accesskey = ע
urlbar-result-menu-dismiss-suggestion =
    .label = סגירה הצעה זו
    .accesskey = ס
urlbar-result-menu-manage-firefox-suggest =
    .label = ניהול { -firefox-suggest-brand-name }
    .accesskey = נ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = דיווח על מיקום לא מדויק
urlbar-result-menu-show-less-frequently =
    .label = להציג בתדירות נמוכה יותר
urlbar-result-menu-dont-show-weather-suggestions =
    .label = לא להציג הצעות מזג אוויר
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = פתיחת תפריט
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = תודה על המשוב שלך
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = תודה על המשוב שלך. לא יוצגו עוד הצעות מזג אוויר.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = מהיום מקלידים פחות ומוצאים יותר: אפשר לחפש עם { $engineName } ישירות משורת הכתובת שלך.
urlbar-search-tips-redirect-2 = ניתן להתחיל את החיפוש שלך בשורת הכתובת כדי לצפות בהצעות מ־{ $engineName } ובהיסטוריית הגלישה שלך.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = ניתן לבחור בקיצור הדרך הזה כדי למצוא את מה שמחפשים מהר יותר.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = סימניות
urlbar-search-mode-tabs = לשוניות
urlbar-search-mode-history = היסטוריה
urlbar-search-mode-actions = פעולות

##

urlbar-geolocation-blocked =
    .tooltiptext = חסמת מפני האתר הזה לגשת לנתוני המיקום שלך.
urlbar-localhost-blocked =
    .tooltiptext = חסמת חיבורים למכשיר המקומי עבור אתר זה.
urlbar-local-network-blocked =
    .tooltiptext = חסמת חיבורים לרשת המקומית עבור אתר זה.
urlbar-xr-blocked =
    .tooltiptext = חסמת גישה למכשיר מציאות מדומה עבור אתר זה.
urlbar-web-notifications-blocked =
    .tooltiptext = חסמת התרעות עבור אתר זה.
urlbar-camera-blocked =
    .tooltiptext = חסמת את המצלמה שלך עבור אתר זה.
urlbar-microphone-blocked =
    .tooltiptext = חסמת את המיקרופון שלך עבור אתר זה.
urlbar-screen-blocked =
    .tooltiptext = חסמת מפני האתר הזה את האפשרות לשתף את המסך שלך.
urlbar-persistent-storage-blocked =
    .tooltiptext = חסמת את האתר הזה משמירת נתונים קבועים.
urlbar-popup-blocked2 =
    .tooltiptext = חסמת חלונות קופצים והפניות מצד שלישי עבור אתר זה.
urlbar-autoplay-media-blocked =
    .tooltiptext = חסמת ניגון אוטומטי של מדיה עם קול עבור אתר זה.
urlbar-canvas-blocked =
    .tooltiptext = חסמת חילוץ נתוני משטחי ציור עבור אתר זה.
urlbar-midi-blocked =
    .tooltiptext = חסמת גישת MIDI עבור אתר זה.
urlbar-serial-blocked =
    .tooltiptext = חסמת גישת יציאה טורית לאתר זה.
urlbar-install-blocked =
    .tooltiptext = חסמת התקנת תוספות עבור אתר זה.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = עריכת סימנייה זו ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = יצירת סימנייה לדף זה ({ $shortcut })
urlbar-split-view-button =
    .aria-label = תצוגה מפוצלת
    .tooltiptext = תצוגה מפוצלת

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = הדבקה ומעבר
    .accesskey = מ
urlbar-menuitem-paste-and-search =
    .label = הדבקה וחיפוש
    .accesskey = ח

## Searchbar context menu

clear-search-history =
    .label = מחיקת היסטוריית חיפוש
    .accesskey = מ

## Page Action Context Menu

page-action-manage-extension2 =
    .label = ניהול הרחבה…
    .accesskey = נ
page-action-remove-extension2 =
    .label = הסרת הרחבה
    .accesskey = ה

## Auto-hide Context Menu

full-screen-autohide =
    .label = הסתרת סרגלים
    .accesskey = ה
full-screen-exit =
    .label = יציאה ממצב מסך מלא
    .accesskey = צ

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = הפעם, לחפש באמצעות:
search-one-offs-change-settings-compact-button =
    .tooltiptext = שינוי הגדרות החיפוש
search-one-offs-context-open-new-tab =
    .label = חיפוש בלשונית חדשה
    .accesskey = ל
search-one-offs-context-set-as-default =
    .label = הגדרה כמנוע חיפוש ברירת מחדל
    .accesskey = ב
search-one-offs-context-set-as-default-private =
    .label = הגדרה כמנוע חיפוש ברירת המחדל עבור חלונות פרטיים
    .accesskey = ג
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = הוספת מנוע החיפוש “{ $engineName }”
    .label = הוספת “{ $engineName }”
    .tooltiptext = הוספת מנוע החיפוש “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = הוספת מנוע חיפוש
    .accesskey = ה
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = הוספת מנוע חיפוש

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = סימניות ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = לשוניות ({ $restrict })
search-one-offs-history =
    .tooltiptext = היסטוריה ({ $restrict })
search-one-offs-actions =
    .tooltiptext = פעולות ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = הצגת תוספות
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = הרחבות, ערכות נושא, תוספות, תוספים
# Opens preferences page at AI controls
quickactions-manageai = ניהול בקרי בינה מלאכותית
quickactions-cmd-manageai = ביטול AI, ביטול בינה מלאכותית, השבתת AI, השבתת בינה מלאכותית, ניהול AI, ניהול בינה מלאכותית
# Opens the bookmarks library window
quickactions-bookmarks2 = ניהול סימניות
quickactions-cmd-bookmarks = סימניות, מועדפים
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = ניקוי היסטוריה אחרונה
quickactions-cmd-clearrecenthistory2 = עוגיות, ניקוי עוגיות, נקה עוגיות, לנקות עוגיות, מטמון, ניקוי מטמון, נקה מטמון, לנקות מטמון, נתוני גלישה, ניקוי נתוני גלישה, נקה נתוני גלישה, היסטוריה, ניקוי היסטוריה אחרונה, נקה היסטוריה אחרונה, לנקות היסטוריה אחרונה
# Opens about:downloads page
quickactions-downloads2 = הצגת הורדות
quickactions-cmd-downloads = הורדות
# Opens about:addons page in the extensions section
quickactions-extensions = ניהול הרחבות
quickactions-cmd-extensions2 = הרחבות, תוספות, תוספים
# Opens Firefox View
quickactions-firefoxview = פתיחת { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = פתיחת { -firefoxview-brand-name }, לפתוח את { -firefoxview-brand-name }, לפתוח את view, view
# Opens SUMO home page
quickactions-help = עזרה עבור { -brand-product-name }
quickactions-cmd-help = עזרה, תמיכה
# Opens the devtools web inspector
quickactions-inspector2 = פתיחת כלי פיתוח
quickactions-cmd-inspector2 = מפקח, inspector, כלי פיתוח, כלי מפתחים, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = דגימת צבע מהדף
quickactions-cmd-colorpicker = בורר צבעים, טפטפת, בחירת צבע, דגימת צבע, לבחור צבע, לדגום צבע, בחר צבע, דגום צבע
# Opens Firefox Library
quickactions-cmd-library = ספרייה,ספריה
quickactions-library = פתיחת ספרייה
# Opens about:logins
quickactions-logins2 = ניהול ססמאות
quickactions-cmd-logins = כניסות, פרטי התחברות, פרטי גישה, פרטי כניסה, ססמאות, סיסמאות
# Mutes all tabs playing audio
quickactions-mute = השתקת לשוניות שמפעילות שמע
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = השתק, השתקה, שקט, ששש
# Opens the print dialog
quickactions-print2 = הדפסת הדף
quickactions-cmd-print = הדפסה, הדפס, להדפיס
# Opens the print dialog at the save to PDF option
quickactions-savepdf = שמירת הדף בתור PDF
quickactions-cmd-savepdf2 = pdf, שמירת הדף, שמירת דף, שמירת העמוד, שמירת עמוד, שמור את הדף, לשמור את הדף, שמור את העמוד, לשמור את העמוד
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = פתיחת עורך PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = פתיחת חלון פרטי
quickactions-cmd-private = גלישה פרטית, גלישה אנונימית
# Opens a SUMO article explaining how to refresh
quickactions-refresh = ריענון { -brand-short-name }
quickactions-cmd-refresh = ריענון, רענן, לרענן
# Restarts the browser
quickactions-restart = הפעלת { -brand-short-name } מחדש
quickactions-cmd-restart = הפעלה מחדש, הפעל מחדש, להפעיל מחדש
# Opens the screenshot tool
quickactions-screenshot3 = צילום מסך
quickactions-cmd-screenshot2 = צילום מסך, screenshot, לקיחת צילום מסך, צלם את המסך
# Opens about:translations
quickactions-translate = תרגום
quickactions-cmd-translate = תרגום,תירגום,לתרגם
# Opens about:preferences
quickactions-settings2 = ניהול הגדרות
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = הגדרות, העדפות, אפשרויות, ניהול
# Opens about:addons page in the themes section
quickactions-themes = ניהול ערכות נושא
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = ערכות נושא, תוספות, הרחבות
# Opens a SUMO article explaining how to update the browser
quickactions-update = עדכון { -brand-short-name }
quickactions-cmd-update = עדכון, עדכן, לעדכן
# Opens the view-source UI with current pages source
quickactions-viewsource2 = הצגת מקור הדף
quickactions-cmd-viewsource2 = הצגת מקור, הצג מקור, מקור, מקור הדף
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = פתיחת { -firefoxlabs-brand-name }
quickactions-cmd-labs = מעבדות, ניסוי
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = מידע נוסף על פעולות מהירות
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = יש ללחוץ על Tab כדי לבחור:

## Bookmark Panel

bookmarks-add-bookmark = הוספת סימנייה
bookmarks-edit-bookmark = עריכת סימנייה
bookmark-panel-cancel =
    .label = ביטול
    .accesskey = ב
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] הסרת סימנייה
           *[other] הסרת { $count } סימניות
        }
    .accesskey = ס
bookmark-panel-show-editor-checkbox =
    .label = הצגת העורך בזמן שמירה
    .accesskey = ה
bookmark-panel-save-button2 =
    .label = שמירה
    .accesskey = ש
bookmark-panel-save-button =
    .label = שמירה
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = מידע אתר עבור { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = אבטחת החיבור עבור { $host }
identity-connection-not-secure = החיבור אינו מאובטח
identity-connection-secure = החיבור מאובטח
identity-connection-failure = כשל בחיבור
identity-connection-internal = דף זה הנו דף מאובטח של { -brand-short-name }.
identity-connection-file = דף זה מאוחסן במחשב שלך.
identity-connection-associated = עמוד זה נטען מתוך עמוד אחר.
identity-extension-page = עמוד זה נטען מתוך הרחבה.
identity-active-blocked = { -brand-short-name } חסם חלקים מהדף שאינם בטוחים.
identity-custom-root = חיבור מאומת על־ידי מנפיק אישורים שאינו מזוהה על־ידי Mozilla.
identity-passive-loaded = חלקים מדף זה אינם מאובטחים (כגון תמונות).
identity-active-loaded = ניטרלת את אמצעי האבטחה על דף זה.
identity-weak-encryption = דף זה משתמש בהצפנה חלשה.
identity-https-only-connection-upgraded = (שודרג ל־HTTPS)
identity-https-only-label2 = שדרוג אוטומטי של אתר זה לחיבור מאובטח
identity-https-only-dropdown-on =
    .label = פעיל
identity-https-only-dropdown-off =
    .label = כבוי
identity-https-only-dropdown-off-temporarily =
    .label = כבוי באופן זמני
identity-https-only-info-turn-on3 = יש להפעיל את השדרוג ל־HTTPS אם ברצונך ש־{ -brand-short-name } ישדרג את החיבור כשהדבר אפשרי.
identity-https-only-info-turn-off3 = אם נראה שהדף שבור, באפשרותך לכבות את שדרוג ה־HTTPS עבור אתר זה כדי לטעון מחדש באמצעות HTTP לא מאובטח.
identity-https-only-info-no-upgrade = לא ניתן לשדרג את החיבור מ־HTTP.
identity-permissions-storage-access-header = עוגיות חוצות אתרים
identity-permissions-storage-access-hint = צדדים אלה יכולים להשתמש בעוגיות חוצות אתרים ובנתוני אתרים בזמן שנמצאים באתר זה.
identity-permissions-storage-access-learn-more = מידע נוסף
identity-permissions-reload-hint = יתכן שיהיה עליך לרענן את העמוד כדי שהשינויים ייכנסו לתוקף.
identity-clear-site-data =
    .label = ניקוי עוגיות ונתוני אתרים…
identity-connection-not-secure-security-view = החיבור שלך לאתר זה אינו מאובטח.
identity-connection-verified = החיבור שלך לאתר זה מאובטח.
identity-ev-owner-label2 = האישור הונפק עבור
identity-verifier-label2 = גורם מאמת
identity-ev-owner-label = האישור הונפק עבור:
identity-verifier-label = גורם מאמת:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = מוסמך כפי שצוין בתקנה (EU) 2024/1183.
identity-description-custom-root2 = ‏Mozilla אינה מזהה את מנפיק האישורים הזה. ייתכן שהוא נוסף ממערכת ההפעלה שלך או על־ידי מנהל מערכת.
identity-cert-exception-overridden = הוספת חריגת אבטחה לאתר זה.
identity-remove-cert-exception =
    .label = הסרת חריגה
    .accesskey = ס
identity-description-insecure = החיבור שלך לאתר זה אינו פרטי. המידע שנשלח זמין לצפייה לאחרים (כגון ססמאות, הודעות, כרטיסי אשראי וכו׳).
identity-description-weak-cipher-intro = החיבור שלך לאתר זה משתמש בהצפנה חלשה ואינו פרטי.
identity-description-weak-cipher-risk = אנשים אחרים יכולים לצפות במידע שלך או לשנות את התנהגות האתר.
identity-description-active-blocked2 = { -brand-short-name } חסם חלקים שאינם בטוחים בדף זה.
identity-description-passive-loaded = החיבור שלך לאתר זה אינו פרטי, ומידע שישותף עם האתר עשוי להיות נגיש לאחרים.
identity-description-passive-loaded-insecure2 = אתר זה מכיל תוכן שאינו מאובטח (כגון תמונות).
identity-description-passive-loaded-mixed2 = למרות ש־{ -brand-short-name } חסם חלק מהתוכן, עדיין קיים בדף תוכן שאינו מאובטח (כגון תמונות).
identity-description-active-loaded = אתר זה מכיל תוכן שאינו מאובטח (כגון תסריטים) והחיבור שלך אליו אינו פרטי.
identity-description-active-loaded-insecure = מידע שישותף עם אתר זה, כגון ססמאות, הודעות, פרטי כרטיס האשראי וכדומה, עשוי להיות נגיש לאחרים.
identity-description-tls-key-logging-heading = ייתכן שהחיבור שלך אינו פרטי
identity-description-tls-key-logging-message = ייתכן שיישומון או שירות יראו את התעבורה המוצפנת שלך מאתר זה.
identity-more-info-link-text =
    .label = מידע נוסף

## Window controls

browser-window-minimize-button =
    .tooltiptext = מזעור
browser-window-maximize-button =
    .tooltiptext = הגדלה
browser-window-restore-down-button =
    .tooltiptext = שחזור כלפי מטה
browser-window-close-button =
    .tooltiptext = סגירה
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = חזרה

## Bookmarks toolbar items

browser-import-button2 =
    .label = ייבוא סימניות…
    .tooltiptext = ייבוא סימניות מדפדפן אחר אל תוך { -brand-short-name }.
bookmarks-toolbar-empty-message = לקבלת גישה מהירה, ניתן למקם את הסימניות שלך כאן בסרגל הכלים של הסימניות. <a data-l10n-name="manage-bookmarks">ניהול סימניות…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = מצלמה:
    .accesskey = מ
popup-select-camera-icon =
    .tooltiptext = מצלמה
popup-select-microphone-device =
    .value = מיקרופון:
    .accesskey = ק
popup-select-microphone-icon =
    .tooltiptext = מיקרופון
popup-select-speaker-icon =
    .tooltiptext = רמקולים
popup-select-window-or-screen =
    .label = חלון או מסך:
    .accesskey = ח
popup-all-windows-shared = ישותפו כל החלונות הגלויים על המסך.

## WebRTC window or screen share tab switch warning

sharing-warning-window = { -brand-short-name } משותף כעת. אנשים אחרים יכולים לראות כשיבוצע מעבר ללשונית חדשה.
sharing-warning-screen = כל המסך שלך משותף כעת. אנשים אחרים יכולים לראות כשיבוצע מעבר ללשונית חדשה.
sharing-warning-proceed-to-tab =
    .label = המשך ללשונית
sharing-warning-disable-for-session =
    .label = השבתת הגנת השיתוף עבור הפעלה זו

## WebSerial "select a port" popup

webserial-select-port-label = בחירת יציאה טורית:
webserial-no-ports-available = אין יציאות טוריות זמינות

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = סגירה
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = חיפוש או הקלדת כתובת
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = נא להכניס כתובת
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = חיפוש באמצעות { $name }
    .placeholder = חיפוש ברשת
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = חיפוש ב־{ $name }
    .placeholder = נא להקליד מונח לחיפוש
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = חיפוש בסימניות
    .placeholder = נא להקליד מונח לחיפוש
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = חיפוש בהיסטוריה
    .placeholder = נא להקליד מונח לחיפוש
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = חיפוש בלשוניות
    .placeholder = נא להקליד מונח לחיפוש
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = חיפוש פעולות
    .placeholder = נא להקליד מונחים לחיפוש
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = ‏ניתן לחפש עם { $name } או להקליד כתובת
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = הדפדפן נמצא בשליטה מרוחקת (סיבה: { $component })
urlbar-permissions-granted =
    .tooltiptext = הענקת לאתר זה הרשאות נוספות.
urlbar-switch-to-tab =
    .value = מעבר ללשונית:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = הרחבה:
urlbar-go-button2 =
    .title = מעבר לכתובת שבסרגל המיקום
urlbar-page-action-button =
    .tooltiptext = פעולות דף
urlbar-revert-button =
    .tooltiptext = הצגת הכתובת בשורת המיקום

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = חיפוש באמצעות { $engine } בחלון פרטי
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = חיפוש בחלון פרטי
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = חיפוש באמצעות { $engine }
urlbar-result-action-sponsored = ממומן
urlbar-result-action-switch-tab = מעבר ללשונית
urlbar-result-action-move-tab-to-split-view = העברת לשונית לתצוגה מפוצלת
urlbar-result-action-visit = ביקור
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = מעבר ללשונית · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = קבוצה ללא שם
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = לבקר מלוח העריכה
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = יש ללחוץ על Tab כדי לחפש באמצעות { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = יש ללחוץ על Tab כדי לחפש ב־{ $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = חיפוש באמצעות { $engine } ישירות משורת הכתובת
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = חיפוש ב־{ $engine } ישירות משורת הכתובת
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = העתקה
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = לא מוגדר
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = הרחבה של { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = מומלץ
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> ב{ $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> ב{ $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> ב{ $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = ‏{ $provider } · ממומן
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = ביקרת לאחרונה { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] ביקרת לאחרונה אתמול
        [two] ביקרת לאחרונה שלשום
       *[other] ביקרת לאחרונה לפני { $daysAgo } ימים
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] ביקרת לאחרונה בשבוע שעבר
        [two] ביקרת לאחרונה לפני שבועיים
       *[other] ביקרת לאחרונה לפני { $weeksAgo } שבועות
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] ביקרת לאחרונה בחודש שעבר
        [two] ביקרת לאחרונה לפני חודשיים
       *[other] ביקרת לאחרונה לפני { $monthsAgo } חודשים
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = ביקרת לאחרונה בתאריך { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = התווסף לסימניות בתאריך { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = ביקרת לאחרונה { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = ביקרת לאחרונה { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = ביקרת לאחרונה ב־{ $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = קבלת נתוני שוק המניות ישירות בשורת החיפוש שלך
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = הצגת עדכונים של שוק המניות ועוד מהשותפים שלנו בעת שיתוף נתוני שאילתות חיפוש עם { -vendor-short-name }. <a data-l10n-name="learn-more-link">מידע נוסף</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = הצגת הצעות
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = לא כעת
urlbar-result-realtime-opt-in-dismiss = סגירה
urlbar-result-realtime-opt-in-dismiss-all2 = לא להציג הצעות אלו
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = לא להציג הצעות שוק מניות
    .accesskey = ל
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = לא להציג הצעות שוק מניות
urlbar-result-realtime-opt-in-dismiss-all =
    .label = לא להציג הצעות אלו
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = לא להציג הצעות שוק מניות
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = תודה על המשוב שלך. לא יוצגו עוד הצעות לשוק מניות.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = הצעות לשוק המניות
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = תודה על המשוב שלך. לא יוצגו עוד הצעות אלו.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] ‏{ $name } · בעוד יום אחד
        [two] ‏{ $name } · בעוד יומיים
       *[other] ‏{ $name } · בעוד { $daysUntilStart } ימים
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] ‏{ $name } · מתחיל בעוד יום אחד
        [two] ‏{ $name } · מתחיל בעוד יומיים
       *[other] ‏{ $name } · מתחיל בעוד { $daysUntilStart } ימים
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] ‏{ $name } · מסתיים בעוד יום אחד
        [two] ‏{ $name } · מסתיים בעוד יומיים
       *[other] ‏{ $name } · מסתיים בעוד { $daysUntilEnd } ימים
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = ‏{ $name } · היום
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = ‏{ $name } · מסתיים היום

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = חיפוש באמצעות { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = ‏{ $keywords } - חיפוש ב{ $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = ‏{ $keywords } - חיפוש באמצעות { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = ‏{ $engine }, בחירת מנוע חיפוש
urlbar-searchmode-button-no-engine2 =
    .title = לא נבחר קיצור דרך, בחירת קיצור דרך
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = חיפוש באמצעות מילות מפתח מושבת
urlbar-searchmode-dropmarker2 =
    .title = בחירת מנוע חיפוש
urlbar-searchmode-bookmarks4 = סימניות
urlbar-searchmode-tabs4 = לשוניות
urlbar-searchmode-history4 = היסטוריה
urlbar-searchmode-actions4 = פעולות
urlbar-searchmode-bookmarks3 = סימניות
    .accesskey = ס
urlbar-searchmode-tabs3 = לשוניות
    .accesskey = ל
urlbar-searchmode-history3 = היסטוריה
    .accesskey = ה
urlbar-searchmode-actions3 = פעולות
    .accesskey = פ
urlbar-searchmode-exit-button2 =
    .title = סגירה
urlbar-searchmode-default2 =
    .title = מנוע חיפוש ברירת מחדל
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = הוספת “{ $engineName }”
    .title = הוספת מנוע החיפוש “{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = הפעם לחפש באמצעות:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = חיפוש באמצעות:
urlbar-searchmode-popup-search-settings2 = הגדרות חיפוש
urlbar-searchmode-popup-settings2 = הגדרות[]
urlbar-searchmode-popup-search-settings = הגדרות חיפוש
    .accesskey = ח
urlbar-searchmode-popup-settings = הגדרות[]
    .accesskey = ה

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = חיפוש בסימניות
urlbar-result-action-search-history = חיפוש בהיסטוריה
urlbar-result-action-search-tabs = חיפוש לשוניות
urlbar-result-action-search-actions = פעולות חיפוש
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = מעבר אל { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = פתיחת { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = פתיחה בלשונית חדשה
    .accesskey = ל
urlbar-view-context-menu-open-in-container-tab =
    .label = פתיחה במגירת לשוניות חדשה
    .accesskey = מ
urlbar-view-context-menu-open-in-window =
    .label = פתיחה בחלון חדש
    .accesskey = ח
urlbar-view-context-menu-open-in-private-window =
    .label = פתיחה בחלון פרטי חדש
    .accesskey = ר
urlbar-view-context-menu-open-in-tab2 = פתיחה בלשונית חדשה
    .accesskey = ל
urlbar-view-context-menu-open-in-container-tab2 = פתיחה במגירת לשוניות חדשה
    .accesskey = מ
urlbar-view-context-menu-open-in-window2 = פתיחה בחלון חדש
    .accesskey = ח
urlbar-view-context-menu-open-in-private-window2 = פתיחה בחלון פרטי חדש
    .accesskey = ר
urlbar-view-context-menu-search-in-tab = חיפוש בלשונית חדשה
    .accesskey = ח
urlbar-view-context-menu-search-in-container-tab = חיפוש במגירת לשוניות חדשה
    .accesskey = מ
urlbar-view-context-menu-search-in-window = חיפוש בחלון חדש
    .accesskey = ח
urlbar-view-context-menu-search-in-private-window = חיפוש בחלון פרטי חדש
    .accesskey = ר
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = דילוג על תפריט זה בעת שימוש במקש ה־Tab
    .accesskey = ד

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = הצעות מ־{ $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = פעולות מהירות
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = חיפושים אחרונים
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = פופולרי ב־{ $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = לא להציע חיפושים פופולריים
    .accesskey = ל
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = לא להציע חיפושים פופולריים
    .accesskey = פ
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = לא להציע חיפושים פופולריים
    .accesskey = פ
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = תודה על המשוב שלך. לא יוצגו עוד חיפושים פופולריים.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = כניסה לתצוגת קריאה
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = סגירת תצוגת הקריאה

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = פתיחת תמונה בתוך תמונה ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = סגירת תמונה בתוך תמונה ({ $shortcut })
picture-in-picture-panel-header = תמונה בתוך תמונה
picture-in-picture-panel-headline = אתר זה אינו ממליץ על תמונה בתוך תמונה
picture-in-picture-panel-body = ייתכן שסרטונים לא יוצגו כפי שהמפתח התכוון בזמן שמצב תמונה בתוך תמונה מופעל.
picture-in-picture-enable-toggle =
    .label = להפעיל בכל זאת

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> כעת במסך מלא
fullscreen-warning-no-domain = מסמך זה כעת במסך מלא
fullscreen-exit-button = יציאה ממסך מלא (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = יציאה ממסך מלא (Esc)
fullscreen-keyboardlock-exit-button = יציאה ממסך מלא (לחיצה ממושכת על Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = יציאה ממסך מלא (לחיצה ממושכת על Esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = לאתר בכתובת <span data-l10n-name="domain">{ $domain }</span> יש שליטה על הסמן שלך. לחיצה על ESC תחזיר את השליטה אליך.
pointerlock-warning-no-domain = למסמך זה יש שליטה על הסמן שלך. לחיצה על ESC תחזיר את השליטה אליך.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = ניהול סימניות
bookmarks-recent-bookmarks-panel-subheader = סימניות אחרונות
bookmarks-toolbar-chevron =
    .tooltiptext = הצגת סימניות נוספות
bookmarks-sidebar-content =
    .aria-label = סימניות
bookmarks-menu-button =
    .label = תפריט סימניות
bookmarks-other-bookmarks-menu =
    .label = סימניות אחרות
bookmarks-mobile-bookmarks-menu =
    .label = סימניות מהנייד

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] הסתרת סרגל הצד סימניות
           *[other] הצגת סרגל הצד
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] הסתרת סרגל הכלים סימניות
           *[other] הצגת סרגל הכלים סימניות
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] הסתרת סרגל הכלים סימניות
           *[other] הצגת סרגל הכלים סימניות
        }

##

bookmarks-search =
    .label = חיפוש בסימניות
bookmarks-tools =
    .label = כלי סימניות
bookmarks-subview-edit-bookmark =
    .label = עריכת סימנייה זו…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = סימניות
    .toolbarname = סרגל כלים סימניות
    .accesskey = ס
bookmarks-toolbar-menu =
    .label = סרגל כלים סימניות
bookmarks-toolbar-placeholder =
    .title = פריטי סרגל כלים סימניות
bookmarks-toolbar-placeholder-button =
    .label = פריטי סרגל כלים סימניות
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = יצירת סימנייה ללשונית הנוכחית…

## Library Panel items

library-bookmarks-menu =
    .label = סימניות

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = תיקון קידוד טקסט
    .tooltiptext = ניחוש קידוד הטקסט הנכון בהסתמך על תוכן הדף

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = הגדרות
    .tooltiptext =
        { PLATFORM() ->
            [macos] פתיחת הגדרות ({ $shortcut })
           *[other] פתיחת הגדרות
        }
toolbar-overflow-customize-button =
    .label = התאמה אישית של סרגל הכלים…
    .accesskey = ס
toolbar-button-email-link =
    .label = שליחת קישור בדוא״ל
    .tooltiptext = שליחת קישור לדף זה בדוא״ל
toolbar-button-logins =
    .label = ססמאות
    .tooltiptext = הצגה וניהול הססמאות השמורות שלך
qrcode-panel-error =
    .message = יצירת קוד QR נכשלה. נא לנסות שוב.
qrcode-copy-button =
    .label = העתקה
qrcode-copy-success =
    .message = קוד ה־QR הועתק ללוח העריכה.
qrcode-copy-error =
    .message = כישלון בהעתקת קוד ה־QR.
qrcode-save-button =
    .label = שמירה
qrcode-window-title = קוד QR
qrcode-dialog-title = קוד QR
qrcode-image =
    .aria-label = קוד QR
qrcode-close-button =
    .aria-label = סגירה
toolbar-button-save-page =
    .label = שמירת דף
    .tooltiptext = שמירת דף זה ({ $shortcut })
toolbar-button-open-file =
    .label = פתיחת קובץ
    .tooltiptext = פתיחת קובץ ({ $shortcut })
toolbar-button-synced-tabs =
    .label = לשוניות מסונכרנות
    .tooltiptext = הצגת לשוניות ממכשירים אחרים
toolbar-button-send-tab =
    .label = שליחת לשונית
    .tooltiptext = שליחת הלשונית הנוכחית למכשיר אחר
toolbar-button-new-private-window =
    .label = חלון פרטי חדש
    .tooltiptext = פתיחת חלון גלישה פרטית חדש ({ $shortcut })
toolbar-button-share-tab =
    .label = שיתוף
    .tooltiptext = שיתוף דף זה
toolbar-button-tab-groups =
    .label = קבוצות לשוניות
    .tooltiptext = הצגת קבוצות הלשוניות שלך
toolbar-button-history =
    .label = היסטוריה
    .tooltiptext = הצגת ההיסטוריה שלך ({ $shortcut })
toolbar-button-find =
    .label = חיפוש
    .tooltiptext = חיפוש בדף זה ({ $shortcut })
toolbar-button-developer =
    .label = כלי פיתוח
    .tooltiptext = פתיחת כלי פיתוח ({ $shortcut })
toolbar-button-forget =
    .label = לשכוח
    .tooltiptext = לשכוח חלק מהיסטוריית הגלישה
toolbar-zoom-controls =
    .label = פקדי מרחק מתצוגה
    .title = פקדי מרחק מתצוגה
toolbar-button-zoom-out =
    .label = התרחקות
    .tooltiptext = התרחקות ‎({ $shortcut })
toolbar-button-zoom-reset-tooltip = איפוס הגדרות מרחק מתצוגה ({ $shortcut })
toolbar-button-zoom-in =
    .label = התקרבות
    .tooltiptext = התקרבות ‎({ $shortcut })
toolbar-edit-controls =
    .label = פקדי עריכה
    .title = פקדי עריכה
toolbar-button-cut =
    .label = גזירה
    .tooltiptext = גזירה ({ $shortcut })
toolbar-button-copy =
    .label = העתקה
    .tooltiptext = העתקה ({ $shortcut })
toolbar-button-paste =
    .label = הדבקה
    .tooltiptext = הדבקה ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = באתר זה קיימים משאבי אודיו או וידאו העושים שימוש ברכיב ניהול זכויות קניין, מה שעשוי להגביל את היכולות ש־{ -brand-short-name } מאפשר לך לעשות עם משאבים אלו.
eme-notifications-drm-content-playing-manage = ניהול הגדרות
eme-notifications-drm-content-playing-manage-accesskey = נ
eme-notifications-drm-content-playing-dismiss = סגירה
eme-notifications-drm-content-playing-dismiss-accesskey = ס

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = עליך להפעיל את רכיב ניהול זכויות הקניין (DRM) כדי להשמיע אודיו או לצפות בווידאו בדף זה.
eme-notifications-drm-content-disabled-button =
    .label = הפעלת ניהול זכויות קניין
    .accesskey = ז
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } מתקין כעת רכיבים הנחוצים כדי לנגן אודיו או וידאו בדף זה. נא להמתין ולנסות שוב מאוחר יותר.
decoder-doctor-no-codecs-linux-message = כדי לנגן וידאו יתכן שיהיה עליך להתקין את מפעני הווידאו הנדרשים.
decoder-doctor-no-hw-acceleration-message = כדי לשפר את איכות הווידאו יתכן שיהיה עליך להתקין את חבילת תכונות המדיה מבית Microsoft.
decoder-doctor-no-pulse-audio-message = כדי להשמיע קול, נדרשת התקנת היישום PulseAudio.
decoder-doctor-unsupported-libavcodec-message = libavcodec כנראה חשוף לסכנות או אינו נתמך, ויש לעדכנו כדי לנגן וידאו.
decoder-doctor-decode-error-message = אירעה תקלה בעת פענוח משאב מדיה.
decoder-doctor-decode-warning-message = אירעה שגיאה במהלך פענוח משאב מדיה.
decoder-doctor-learn-how-link = מידע נוסף
decoder-doctor-report-issue-button =
    .label = דיווח על בעיה באתר
    .accesskey = ב
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = התוסף החיצוני { $pluginName } קרס.
plugin-crashed-notification-reload-button =
    .label = טעינת דף מחדש
    .accesskey = מ
plugin-crashed-notification-submit-button =
    .label = שליחת דיווח קריסה
    .accesskey = ק

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = אתר מטעה!
safebrowsing-reported-attack-site-message = אתר תקיפה מדווח!
safebrowsing-reported-unwanted-site-message = אתר תוכנה לא רצויה מדווח!
safebrowsing-reported-harmful-site-message = אתר שדווח כמזיק!
safebrowsing-get-me-out-of-here-button =
    .label = קחו אותי מכאן!
    .accesskey = ק
safebrowsing-not-a-deceptive-site-button =
    .label = אתר זה אינו אתר מטעה…
    .accesskey = ט
safebrowsing-not-an-attack-site-button =
    .label = אתר זה אינו אתר תקיפה…
    .accesskey = א

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = עליך להתחבר לרשת זו לפני שיהיה באפשרותך לגלוש באינטרנט.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = פתיחת דף התחברות לרשת

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = האם התכוונת להגיע אל { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = כן, נא להעביר אותי אל { $hostName }
    .accesskey = כ

## Password save/update panel

panel-save-update-username-2 =
    .label = שם משתמש
panel-save-update-password-2 =
    .label = ססמה

##

# "More" item in macOS share menu
menu-share-more =
    .label = עוד…
menu-share-windows =
    .label = אפשרויות נוספות
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] העתקת קישור
           *[other] העתקת { $count } קישורים
        }
    .accesskey = ה
ui-tour-info-panel-close =
    .tooltiptext = סגירה

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = לאפשר חלונות קופצים והפניות מצד שלישי עבור { $uriHost }
    .accesskey = א

##

picture-in-picture-hide-toggle =
    .label = הסתרת הכפתור של תמונה בתוך תמונה
    .accesskey = ה

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = העברת הכפתור של תמונה בתוך תמונה לצד ימין
    .accesskey = י
picture-in-picture-move-toggle-left =
    .label = העברת הכפתור של תמונה בתוך תמונה לצד שמאל
    .accesskey = ש

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = ניווט
navbar-downloads =
    .label = הורדות
navbar-overflow-2 =
    .tooltiptext = כלים נוספים
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = הדפסה
    .tooltiptext = הדפסת דף זה… ({ $shortcut })
navbar-home =
    .label = דף הבית
    .tooltiptext = דף הבית של { -brand-short-name }
navbar-library =
    .label = ספרייה
    .tooltiptext = צפייה בהיסטוריה, סימניות שמורות ועוד
navbar-search =
    .title = חיפוש
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = לשוניות הדפדפן
tabs-toolbar-new-tab =
    .label = לשונית חדשה
tabs-toolbar-list-all-tabs-2 =
    .label = חיפוש וניהול לשוניות
    .tooltiptext = חיפוש וניהול לשוניות
tabs-toolbar-list-all-tabs =
    .label = רשימת כל הלשוניות
    .tooltiptext = רשימת כל הלשוניות

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = ניתן לשחרר לשונית כאן כדי לנעוץ אותה

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>לפתוח את הלשוניות הקודמות?</strong> באפשרותך לשחזר את ההפעלה הקודמת שלך מתפריט היישום של { -brand-short-name } ‏<img data-l10n-name="icon"/>, תחת היסטוריה.
restore-session-startup-suggestion-button = להראות לך איך

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = הארגון שלך חסם גישה לדפים מקומיים במחשב זה.

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = הקיצור { $searchTabsShortcut } כעת מחפש לשוניות
urlbar-addons-shortcut-moved-description = כדי לפתוח את דף ההרחבות וערכות הנושא, יש להשתמש בקיצור { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = ניהול קיצורי דרך
urlbar-addons-shortcut-moved-dismiss = הבנתי

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } יישלח אוטומטית חלק מהנתונים אל { -vendor-short-name } כדי שנוכל לשפר את החוויה שלך.
data-reporting-notification-button =
    .label = בחירת פריטים לשיתוף
    .accesskey = ש
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = גלישה פרטית
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = גלישה פרטית
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = מידע על גלישה פרטית
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = גלישה זו מתרחשת בחלון פרטי
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = זה מסייע להסתיר את הגלישה שלך מפני אחרים במכשיר זה, אך לא הופך אותך לבלתי נראה ברשת. <a data-l10n-name="learn-more">מי עשוי לראות את הפעילות שלי?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = מניעת אובדן נתונים (DLP) מאת { $agentName }. יש ללחוץ למידע נוסף.
content-analysis-panel-title2 = מניעת אובדן נתונים
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = הארגון שלך משתמש ב־<b>{ $agentName }</b> כדי לשלוט באופן שבו ניתן לשתף מידע רגיש. <a data-l10n-name="info">מידע נוסף</a>
content-analysis-panel-title = הגנת נתונים
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = הארגון שלך משתמש ב־<b>{ $agentName }</b> כדי להגן מפני אובדן נתונים. <a data-l10n-name="info">מידע נוסף</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = הרחבות
    .tooltiptext = הרחבות

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = הרחבות
    .tooltiptext =
        הרחבות
        נדרשות הרשאות

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = הרחבות
    .tooltiptext =
        הרחבות
        חלק מההרחבות אינן מורשות

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = הרחבות
    .tooltiptext =
        הרחבות
        חלק מההרחבות מושבתות

## Private browsing reset button

reset-pbm-panel-heading2 = לנקות נתונים ולהתחיל הפעלה פרטית חדשה?
reset-pbm-panel-description3 = פעולה זו מנקה את ההיסטוריה והעוגיות שלך, ומנתקת אותך מהחשבונות שלך באתרים. החלונות הפרטיים שלך ייסגרו, וייפתח חלון חדש.
reset-pbm-panel-description2 = פעולה זו מוחקת את ההיסטוריה, העוגיות וכל שאר נתוני האתרים מבלי לסגור את החלון הפרטי שלך.
reset-pbm-panel-always-ask-checkbox =
    .label = תמיד לשאול אותי
    .accesskey = ת
reset-pbm-panel-cancel-button =
    .label = ביטול
    .accesskey = ב
reset-pbm-panel-confirm-button2 =
    .label = ניקוי הפעלה פרטית
    .accesskey = נ
reset-pbm-panel-complete = נתוני ההפעלה הפרטית נמחקו
reset-pbm-toolbar-button2 =
    .label = ניקוי הפעלה פרטית
    .tooltiptext = ניקוי הפעלה פרטית

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = למחוק את כל נתוני הגלישה שלך?
fire-button-panel-description = פעולה זו תמחק את ההיסטוריה, עוגיות ונתוני אתרים. יבוצע ניתוק מחשבונות באתרים. חלון זה ייסגר, ו־{ -brand-short-name } יפתח חלון חדש.
fire-button-panel-choose-description = אם אין ברצונך למחוק הכל, יש לבחור בנתונים ספציפיים במקום.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = בחירה…
fire-button-panel-cancel-button =
    .label = ביטול
    .accesskey = ב
fire-button-panel-confirm-button =
    .label = מחיקת הכל
    .accesskey = מ
fire-button-panel-complete = נתוני הגלישה נמחקו
fire-button-toolbar-button2 =
    .label = מחיקת חלק או כל הנתונים
    .tooltiptext = מחיקת חלק או כל נתוני הגלישה שלך

## Autorefresh blocker

refresh-blocked-refresh-label = ‏{ -brand-short-name } מנע מעמוד זה לטעון את עצמו מחדש באופן אוטומטי.
refresh-blocked-redirect-label = ‏{ -brand-short-name } מנע מעמוד זה להפנות לעמוד אחר באופן אוטומטי.
refresh-blocked-allow =
    .label = לאפשר
    .accesskey = א

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = המסכות המאובטחות והקלות לשימוש שלנו מגינות על הזהות שלך ומונעות דואר זבל על־ידי הסתרת כתובת הדוא״ל שלך.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = כל הודעות הדוא״ל שנשלחות למסכות הדוא״ל שלך יועברו אל <strong>{ $useremail }</strong> (אלא אם תבחר לחסום אותם).
firefox-relay-offer-legal-notice = לחיצה על ״שימוש במסכת דוא״ל״ מהווה הסכמה ל<label data-l10n-name="tos-url">תנאי השירות</label> <label data-l10n-name="privacy-url">ולהצהרת הפרטיות</label>.
firefox-relay-offer-legal-notice-1 = ההרשמה ויצירת מסכת דוא״ל מהוות הסכמה ל<label data-l10n-name="tos-url">תנאי השירות</label> <label data-l10n-name="privacy-url">ולהצהרת הפרטיות</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (ללא אימות)
popup-notification-xpinstall-prompt-learn-more = מידע נוסף על התקנת תוספות בצורה בטוחה
popup-notification-xpinstall-prompt-block-url = צפייה בפרטים
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = לאפשר להרחבה זו לפעול בחלונות פרטיים
    .accesskey = ל
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = שיתוף נתונים טכניים ונתוני אינטראקציה עם מפתח ההרחבה
    .accesskey = ש

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } מנע מאתר זה לפתוח חלון קופץ.
       *[other] { -brand-short-name } מנע מאתר זה לפתוח { $popupCount } חלונות קופצים.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } מנע מאתר זה לבצע הפניה.
        [one] { -brand-short-name } מנע מאתר זה לפתוח חלון קופץ ולבצע הפניה.
       *[other] { -brand-short-name } מנע מאתר זה לפתוח { $popupCount } חלונות קופצים ולבצע הפניה.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message =
    { $popupCount ->
        [one] ‏
       *[other] { -brand-short-name } מנע מאתר זה לפתוח יותר מ־{ $popupCount } חלונות קופצים.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } מנע מאתר זה לפתוח יותר מחלון קופץ אחד ולבצע הפניה.
       *[other] { -brand-short-name } מנע מאתר זה לפתוח יותר מ־{ $popupCount } חלונות קופצים ולבצע הפניה.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] אפשרויות
           *[other] העדפות
        }
    .accesskey =
        { PLATFORM() ->
            [windows] א
           *[other] ד
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = הצגת “{ $popupURI }”
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = הצגת ״{ $redirectURI }״

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = לא ניתן היה לפתוח את דו־שיח הקבצים של Windows. לא ניתן לבחור קובץ או תיקייה.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = לא ניתן היה לפתוח את דו־שיח הקבצים של Windows. הקובץ יישמר ב־{ $path }.
file-picker-failed-save-nowhere = לא ניתן היה לפתוח את דו־שיח הקבצים של Windows. לא נמצאה תיקיית ברירת מחדל; הקובץ לא יישמר.
file-picker-crashed-open = דו־שיח הקבצים של Windows קרס. לא ניתן לבחור קובץ או תיקייה.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = דו־שיח הקבצים של Windows קרס. הקובץ יישמר ב־{ $path }.
file-picker-crashed-save-nowhere = דו־שיח הקבצים של Windows קרס. לא נמצאה תיקיית ברירת מחדל; הקובץ לא יישמר.
file-picker-crashed-show-in-folder =
    .label = הצגה בתיקייה
    .accessKey = ת

## Unsigned add-ons notification

unsigned-addons-disabled-message = אחת או יותר מהתוספות המותקנות אינה ניתנת לאימות ולכן נוטרלה.
unsigned-addons-disabled-learn-more =
    .label = מידע נוסף
    .accesskey = מ

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = דף זה מאט את { -brand-short-name }. כדי להאיץ את הדפדפן שלך, כדאי לעצור דף זה.
process-hang-nonspecific-tab-message = דף אינטרנט מאט את { -brand-short-name }. כדי להאיץ את הדפדפן שלך, כדאי לעצור דף זה.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = ‏“{ $title }” מאט את { -brand-short-name }. כדי להאיץ את הדפדפן שלך, כדאי לעצור דף זה.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = ההרחבה “{ $addonName }” מאטה את { -brand-short-name }. כדי להאיץ את הדפדפן שלך, כדאי לעצור הרחבה זו.
process-hang-addon-learn-more =
    .value = מידע נוסף
process-hang-stop-button =
    .label = עצירה
    .accesskey = ע

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = סיום ההגדרה
onboarding-aw-finish-setup-button =
    .label = סיום ההגדרה
    .tooltiptext = סיום הגדרת { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = הגנת מעקב מתקדמת פעילה
trustpanel-etp-label-disabled = הגנת מעקב מתקדמת כבויה
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = הגנת מעקב מתקדמת: פעילה עבור { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = הגנת מעקב מתקדמת: כבויה עבור { $host }
trustpanel-etp-description-enabled = אם משהו נראה שבור באתר הזה, ניתן לנסות לכבות את ההגנות.
trustpanel-etp-description-disabled = ‏{ -brand-product-name } חושב שחברות צריכות לעקוב אחריך פחות. אנו חוסמים כמה שיותר רכיבי מעקב כשההגנות פעילות.
trustpanel-trackercount-label = הצגת כמות רכיבי המעקב החסומים בשורת הכתובת
trustpanel-trackercount-toggle =
    .aria-label = הצגת כמות רכיבי המעקב החסומים בשורת הכתובת
trustpanel-connection-label-secure = החיבור מאובטח
trustpanel-connection-label-insecure = החיבור אינו מאובטח
trustpanel-header-enabled = ‏{ -brand-product-name } עומד על המשמר
trustpanel-description-enabled2 = ההגנות פעילות. אם נזהה משהו חריג, נודיע לך.
trustpanel-header-enabled-insecure = יש להיזהר באתר זה
trustpanel-description-enabled-insecure = ‏{ -brand-product-name } שם לב למשהו חשוד.
trustpanel-header-disabled = כיבית את ההגנות
trustpanel-description-disabled = ההגנות של { -brand-product-name } מושבתות כרגע. אנו מציעים להפעיל מחדש את ההגנות.
trustpanel-clear-cookies-button = ניקוי עוגיות ונתוני אתרים
trustpanel-privacy-link = הגדרות פרטיות
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = ניקוי עוגיות ונתוני אתר עבור { $host }
trustpanel-clear-cookies-description = הסרת עוגיות ונתוני אתרים עשויה לנתק את החשבון שלך מאתרים ולרוקן עגלות קניות.
trustpanel-clear-cookies-subview-button-clear = ניקוי
trustpanel-clear-cookies-subview-button-cancel = ביטול
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = הגנות חיבור עבור { $host }
trustpanel-siteinformation-morelink = פרטי אתר נוספים
trustpanel-blocker-see-all = צפייה בהכל
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = הגנות מעקב עבור { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = לא מאובטח
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] רכיב מעקב אחד נחסם
       *[other] { $count } רכיבי מעקב נחסמו
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = ‏{ -brand-product-name } חושב שחברות צריכות לעקוב אחריך פחות. אז אנחנו חוסמים כמה שניתן.
trustpanel-blocked-header = ‏{ -brand-product-name } חסם את הפריטים הבאים עבורך:
trustpanel-tracking-header = ‏{ -brand-product-name } איפשר את הפריטים הבאים כדי שהאתרים לא יישברו:
trustpanel-tracking-description = ללא רכיבי מעקב, ייתכן שחלק מהכפתורים, הטפסים ושדות ההתחברות לא יפעלו.
trustpanel-insecure-section-header = החיבור שלך אינו מאובטח
trustpanel-insecure-description = הנתונים הנשלחים לאתר זה אינם מוצפנים. גורם מצד שלישי יכול לצפות, לגנוב או לשנות אותו בזמן שהוא מועבר ברשת.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] עוגיית מעקב אחת חוצה אתרים
       *[other] { $count } עוגיות מעקב חוצות אתרים
    }
trustpanel-list-label-tracking-content = תוכן מעקב
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] רכיב זהות דיגיטלית אחד
       *[other] { $count } רכיבי זהות דיגיטלית
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] רכיב מעקב אחד של מדיה חברתית
       *[other] { $count } רכיבי מעקב של מדיה חברתית
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] כורה מטבעות דיגיטליים אחד
       *[other] { $count } כורי מטבעות דיגיטליים
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } חסם רכיב מעקב אחד של מדיה חברתית
       *[other] ‏{ -brand-product-name } חסם { $count } רכיבי מעקב של מדיה חברתית
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } איפשר רכיב מעקב אחד של מדיה חברתית
       *[other] ‏{ -brand-product-name } איפשר { $count } רכיבי מעקב של מדיה חברתית
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } חסם עוגיית מעקב אחת חוצה אתרים
       *[other] ‏{ -brand-product-name } חסם { $count } עוגיות מעקב חוצות אתרים
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } איפשר עוגיית מעקב אחת חוצה אתרים
       *[other] ‏{ -brand-product-name } איפשר { $count } עוגיות מעקב חוצות אתרים
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } חסם רכיב מעקב אחד
       *[other] ‏{ -brand-product-name } חסם { $count } רכיבי מעקב
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } איפשר רכיב מעקב אחד
       *[other] ‏{ -brand-product-name } איפשר { $count } רכיבי מעקב
    }
trustpanel-tracking-content-tab-list-header = האתרים האלה מנסים לעקוב אחריך:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } חסם רכיב זהות דיגיטלית אחד
       *[other] ‏{ -brand-product-name } חסם { $count } רכיבי זהות דיגיטלית
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } איפשר רכיב זהות דיגיטלית אחד
       *[other] ‏{ -brand-product-name } איפשר { $count } רכיבי זהות דיגיטלית
    }
trustpanel-fingerprinter-list-header = האתרים האלה מנסים לקחת את טביעת האצבע הדיגיטלית שלך:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } חסם כורה מטבעות דיגיטליים אחד
       *[other] ‏{ -brand-product-name } חסם { $count } כורי מטבעות דיגיטליים
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] ‏{ -brand-product-name } איפשר כורה מטבעות דיגיטליים אחד
       *[other] ‏{ -brand-product-name } איפשר { $count } כורי מטבעות דיגיטליים
    }
trustpanel-cryptominer-tab-list-header = האתרים האלה מנסים לכרות מטבעות דיגיטליים:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = יש לך חשבון באתר זה?
trustpanel-breachalerts-anonymous-breached-description = ‏{ -brand-product-name } גילה כי באתר זה הייתה דליפת נתונים ב־12 החודשים האחרונים. ניתן לבדוק האם נפגעת מדליפה זו.
trustpanel-breachalerts-anonymous-breached-button-dismiss = סגירה
trustpanel-breachalerts-anonymous-breached-button-check-monitor = התחלת סריקה חינמית
trustpanel-blocker-section-header2 =
    { $count ->
        [one] רכיב מעקב <span data-l10n-name="count">אחד</span> נחסם באתר זה
       *[other] <span data-l10n-name="count">{ $count }</span> רכיבי מעקב נחסמו באתר זה
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>האתר נראה שבור?</strong> ניתן לטעון מחדש את הדף כדי להפחית זמנית את הגנת המעקב שלך.
reduced-protection-infobar-reload-button = טעינה מחדש
    .accesskey = ט
reduced-protection-infobar-never-show-button = לא להציג שוב
    .accesskey = ל


identity-allow-site-data = vOrbit-lite: תמיד לשמור עוגיות/נתונים עבור האתר הזה
