# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Websites anweisen, meine Daten nicht zu verkaufen oder weiterzugeben
    .accesskey = s
non-technical-privacy-group =
    .label = Datenschutzeinstellungen für Websites
do-not-track-removal3 =
    .message = Wir unterstützen die "Do Not Track"-Funktion nicht mehr.
non-technical-privacy-heading =
    .label = Zusätzliche Schutzmaßnahmen
preferences-privacy-relay-available =
    .description = Verbirgt Ihre echte E-Mail-Adresse, um Ihren Posteingang vor Spam zu schützen.
    .label = { -relay-brand-name } E-Mail-Masken vorschlagen
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Einstellungen
category-nav-heading =
    .heading = Einstellungen
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = In Einstellungen suchen
    .style = width: 15.4em
managed-notice = Der Browser wird durch Ihre Organisation verwaltet.
managed-notice-info-icon =
    .alt = Information
managed-notice-nav =
    .label = Der Browser wird durch Ihre Organisation verwaltet.
tls-key-logging-notice-nav =
    .label = Eine App oder ein Dienst kann möglicherweise Ihren verschlüsselten Datenverkehr einsehen.
category-list =
    .aria-label = Kategorien
pane-general-title = Allgemein
pane-home-title = Startseite
pane-home-startup-title2 = Startseite
    .title = Startseite
pane-search-title2 = Suche
    .title = Suche
pane-privacy-title3 = Datenschutz & Sicherheit
    .title = Datenschutz & Sicherheit
pane-privacy-section =
    .heading = Datenschutz & Sicherheit
pane-sync-title3 = Synchronisation
pane-ai-controls-title2 = KI-Einstellungen
    .title = KI-Einstellungen
pane-about-firefox-title = Über { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Erscheinungsbild
    .title = { pane-appearance-title }
pane-downloads-title2 = Downloads
    .title = Downloads
pane-downloads3 =
    .heading = Downloads
pane-accessibility-title = Barrierefreiheit
    .title = { pane-accessibility-title }
pane-languages-title2 = Sprachen
    .title = Sprachen
preferences-languages-header3 =
    .heading = Sprachen
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Probieren Sie unsere experimentellen Funktionen aus! Sie sind noch in der Entwicklung und entwickeln sich weiter, was sich auf die Funktionsweise von { -brand-short-name } auswirken könnte. Wir erhalten Daten über Ihre Nutzung dieser Funktionen nur, wenn Sie <a data-l10n-name="data-collection">technische und Interaktionsdaten</a> aktiviert haben.
pane-experimental-reset =
    .label = Standard wiederherstellen
    .accesskey = w
help-button-label2 = Hilfe für { -brand-short-name }
    .title = Hilfe für { -brand-short-name }
addons-button-label2 = Erweiterungen & Themes
    .title = Erweiterungen & Themes
focus-search =
    .key = f
close-button =
    .aria-label = Schließen
do-not-track-removal2 =
    .label = Wir unterstützen das "Do Not Track"-Signal nicht mehr
applications-setting-new-file-types =
    .label = Wie soll { -brand-short-name } mit anderen Dateien verfahren?

## Browser Restart Dialog

feature-enable-requires-restart = { -brand-short-name } muss neu gestartet werden, um diese Funktion zu aktivieren.
feature-disable-requires-restart = { -brand-short-name } muss neu gestartet werden, um diese Funktion zu deaktivieren.
should-restart-title = { -brand-short-name } neu starten
should-restart-ok = { -brand-short-name } jetzt neu starten
cancel-no-restart-button = Abbrechen
restart-later = Später neu starten

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrolliert diese Einstellung.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrolliert diese Einstellung.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> benötigt die Tab-Umgebungen.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrolliert diese Einstellung.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> kontrolliert, wie sich { -brand-short-name } mit dem Internet verbindet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Um die Erweiterung zu aktivieren, öffnen Sie das <img data-l10n-name="menu-icon"/> Menü und dann <img data-l10n-name="addons-icon"/> Add-ons.
extension-controlled-enable-2 = Um diese Erweiterung wieder zu aktivieren, besuchen Sie <a data-l10n-name="addons-link">Erweiterungen und Themes</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } kontrolliert einige Ihrer Startseiten-Einstellungen.

## Preferences UI Search Results

search-results-header = Suchergebnisse
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Keine Treffer in den Einstellungen für "<span data-l10n-name="query"></span>".
search-results-help-link = Benötigen Sie Hilfe? Dann besuchen Sie die <a data-l10n-name="url">Hilfeseite für { -brand-short-name }</a>.

## General Section

always-check-default =
    .label = Immer überprüfen, ob { -brand-short-name } der Standardbrowser ist
    .accesskey = p
startup-restore-windows-and-tabs =
    .label = Vorherige Fenster und Tabs öffnen
    .accesskey = o
startup-windows-launch-on-login-profile-disabled =
    .message = Um diese Einstellung zu aktivieren, klicken Sie auf "{ profile-manager-use-selected.label }" im Fenster "Benutzerprofil wählen".
windows-launch-on-login =
    .label = { -brand-short-name } automatisch öffnen, wenn der Rechner gestartet wird
    .accesskey = ö
windows-launch-on-login-disabled = Diese Einstellung wurde in Windows deaktiviert. Zum Ändern besuchen Sie <a data-l10n-name="startup-link">Autostart</a> in den Systemeinstellungen.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Außerdem einen neuen Tab öffnen
    .accesskey = n
disable-extension =
    .label = Erweiterung deaktivieren
preferences-data-migration-group =
    .description = Lesezeichen, Passwörter, Chronik, Erweiterungen und Daten für automatisches Ausfüllen in Firefox importieren.
    .label = Browserdaten importieren
preferences-data-migration-button =
    .label = Daten importieren
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profile
preferences-profiles-subpane-description =
    .description = Jedes Profil hat unterschiedliche Browser-Daten und -Einstellungen, wie Chronik, Passwörter und mehr.
preferences-profiles-section-header =
    .description = Jedes Profil hat unterschiedliche Browser-Daten und -Einstellungen, wie Chronik, Passwörter und mehr.
    .label = Profile
preferences-manage-profiles-button =
    .label = Profile verwalten
preferences-profiles-settings-button =
    .label = Einstellungen
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Das neue Profil kopiert Ihre Einstellungen, Add-ons, den Verlauf und gespeicherte Daten wie Lesezeichen und Passwörter – jedoch nicht Ihre Konto- oder Synchronisierungsdaten.
    .label = Ein bestehendes Profil kopieren
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Zu kopierendes Profil
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Profil auswählen
preferences-copy-profile-button = Kopieren
tabs-browsing-section =
    .heading = Tabs und Surfen
pane-tabs-browsing-title2 = Tabs und Surfen
    .title = Tabs und Surfen
tabs-group-header2 =
    .label = Tabs
tabs-opening-heading =
    .label = Öffnen
tabs-interaction-heading =
    .label = Interaktion
tabs-containers-heading =
    .label = Tab-Umgebungen
tabs-closing-heading =
    .label = Schließen
ctrl-tab-recently-used-order =
    .label = Bei Strg+Tab die Tabs nach letzter Nutzung in absteigender Reihenfolge anzeigen
    .accesskey = z
open-new-link-as-tabs =
    .label = Links in Tabs anstatt in neuen Fenstern öffnen
    .accesskey = T
open-external-link-next-to-active-tab =
    .label = Links aus Apps neben Ihrem aktiven Tab öffnen
ask-on-close-multiple-tabs =
    .label = Fragen, bevor mehrere Tabs geschlossen werden
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Fragen, bevor mit { $quitKey } beendet wird
    .accesskey = b
warn-on-open-many-tabs =
    .label = Warnen, wenn das gleichzeitige Öffnen mehrerer Tabs { -brand-short-name } verlangsamen könnte
    .accesskey = c
switch-to-new-tabs-2 =
    .label = Tabs im Vordergrund öffnen
    .accesskey = V
show-tabs-in-taskbar =
    .label = Tab-Vorschauen in der Windows-Taskleiste anzeigen
    .accesskey = k
browser-containers-enabled-2 =
    .label = Tab-Umgebungen aktivieren
    .accesskey = a
browser-containers-learn-more = Weitere Informationen
browser-containers-settings-2 =
    .label = Einstellungen verwalten
    .accesskey = u
containers-disable-alert-title = Alle Tabs in Umgebungen schließen?
startup-group =
    .label = Start

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Falls die Funktion "Tab-Umgebungen" jetzt deaktiviert wird, so wird { $tabCount } Tab in einer Umgebung geschlossen. Soll die Funktion "Tab-Umgebungen" wirklich deaktiviert werden?
       *[other] Falls die Funktion "Tab-Umgebungen" jetzt deaktiviert wird, so werden { $tabCount } Tabs in Umgebungen geschlossen. Soll die Funktion "Tab-Umgebungen" wirklich deaktiviert werden?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] { $tabCount } Tab in einer Umgebung schließen
       *[other] { $tabCount } Tabs im Umgebungen schließen
    }

##

containers-disable-alert-cancel-button = Aktiviert belassen
containers-remove-alert-title = Diese Umgebung löschen?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Wenn diese Umgebung jetzt gelöscht wird, so wird { $count } Tab aus dieser Umgebung geschlossen. Soll diese Umgebung wirklich gelöscht werden?
       *[other] Wenn diese Umgebung jetzt gelöscht wird, so werden { $count } Tabs aus dieser Umgebung geschlossen. Soll diese Umgebung wirklich gelöscht werden?
    }
containers-remove-ok-button = Umgebung löschen
containers-remove-cancel-button = Umgebung behalten
settings-tabs-show-image-in-preview =
    .label = Eine Grafik-Vorschau anzeigen, wenn Sie mit der Maus über einen Tab fahren
    .accessKey = f
settings-tabs-drag-to-create-tab-groups =
    .label = Ziehen Sie Tabs zusammen, um Tab-Gruppen zu erstellen
browser-layout-header2 =
    .label = Browser-Layout
browser-layout-horizontal-tabs2 =
    .description = Tabs oben
    .label = Horizontale Tabs
    .title = Tabs oben
browser-layout-vertical-tabs2 =
    .description = Tabs an der Seite, in der Sidebar
    .label = Vertikale Tabs
    .title = Tabs an der Seite, in der Sidebar
browser-layout-show-sidebar2 =
    .description = Greifen Sie schnell auf Lesezeichen, Tabs von Ihrem Handy, KI-Chatbots und mehr zu, ohne die Hauptansicht zu verlassen.
    .label = Sidebar anzeigen
page-navigation-group =
    .label = Seitennavigation

## General Section - Language & Appearance

language-and-appearance-header = Sprache und Erscheinungsbild
appearance-group2 =
    .description = Einige Websites passen ihr Farbschema basierend auf Ihren Einstellungen an. Wählen Sie Ihr Farbschema aus.
    .label = Erscheinungsbild von Websites
preferences-web-appearance-choice-auto3 =
    .label = System
    .title = Automatisch die Seitenhintergründe und -inhalte auf der Grundlage von Systemeinstellungen und { -brand-short-name } anpassen
preferences-web-appearance-choice-light2 =
    .label = Hell
    .title = Ein helles Erscheinungsbild für Hintergründe und Inhalte von Websites verwenden
preferences-web-appearance-choice-dark2 =
    .label = Dunkel
    .title = Ein dunkles Erscheinungsbild für Hintergründe und Inhalte von Websites verwenden
web-appearance-group =
    .aria-label = Erscheinungsbild von Websites
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Ihre Kontrast-Einstellungen überschreiben das Erscheinungsbild von Websites.
preferences-web-appearance-link =
    .label = Verwalten Sie { -brand-short-name }-Themes in Erweiterungen & Themes.
preferences-contrast-control-group =
    .description = Websites verwenden eine Vielzahl von Vordergrund- und Hintergrundfarben. Um einen einheitlichen Kontrast zu erzielen, können Sie auf allen Websites dieselben Farben verwenden.
    .label = Kontraststeuerung
preferences-contrast-control-radio-group =
    .label = Farben überschreiben
preferences-contrast-control-use-platform-settings =
    .label = Automatisch (Systemeinstellungen verwenden)
    .accesskey = S
preferences-contrast-control-off =
    .label = Aus
    .accesskey = A
preferences-contrast-control-custom =
    .label = Benutzerdefiniert
    .accesskey = B
preferences-colors-manage-button2 =
    .label = Farben verwalten
    .accesskey = F
preferences-colors-manage-button =
    .label = Farben verwalten…
    .accesskey = F
preferences-fonts-header2 =
    .label = Schriftarten
preferences-default-zoom-label =
    .label = Standard-Zoom
    .accesskey = Z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage } %
preferences-zoom-text-only =
    .label = Nur Text zoomen
    .accesskey = T
preferences-text-zoom-override-warning2 =
    .message = Warnung: Wenn Sie "Nur Text zoomen" auswählen und Ihr Standard-Zoom nicht auf 100% gesetzt ist, kann dies dazu führen, dass einige Websites oder Inhalte nicht funktionieren.
language-header = Sprache
choose-language-description = Bevorzugte Sprachen für die Darstellung von Websites wählen
website-language-heading =
    .description = Einige Webseiten werden in mehreren Sprachen angezeigt. Wählen Sie die Sprachen in der von Ihnen bevorzugten Reihenfolge aus.
    .label = Sprache der Website
website-preferred-language =
    .label = Bevorzugte Sprachen
website-language-list =
    .aria-label = Bevorzugte Sprachen
website-add-language =
    .label = Sprache hinzufügen
website-add-language-button =
    .aria-label = Ausgewählte Sprache hinzufügen
    .title = Ausgewählte Sprache hinzufügen
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = { $locale } entfernen
    .title = { $locale } entfernen
choose-button =
    .label = Wählen…
    .accesskey = W
choose-browser-language-description = Sprache für die Anzeige von Menüs, Mitteilungen und Benachrichtigungen von { -brand-short-name }
manage-browser-languages-button =
    .label = Alternative Sprachen festlegen…
    .accesskey = S
confirm-browser-language-change-description = { -brand-short-name } muss neu gestartet werden, um die Änderungen zu übernehmen.
confirm-browser-language-change-button = Anwenden und neu starten
browser-language-heading =
    .description = Sprache für die Anzeige von Menüs, Mitteilungen und Benachrichtigungen von { -brand-short-name }.
    .label = Browser-Sprache
browser-language-preferred-label =
    .label = Bevorzugte Sprache
browser-language-fallback-label =
    .description = Verwendet, wenn die bevorzugte Sprachlokalisierung unvollständig ist.
    .label = Alternative Sprache
browser-language-install-error =
    .message = { -brand-short-name } kann Ihre Sprachen momentan nicht aktualisieren. Überprüfen Sie, ob Sie mit dem Internet verbunden sind, oder versuchen Sie es erneut.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Ausnahmen…
    .accesskey = u
settings-translations-header =
    .aria-label = Übersetzungen
    .description = Übersetzen Sie Seiten oder selektierten Text. Um Ihre Sicherheit zu erhöhen, bleiben die Übersetzungen auf Ihrem Gerät.
    .label = Übersetzungen
settings-translations-offer-to-translate-label =
    .label = Übersetzung ganzer Seite anbieten
settings-translations-more-settings-button =
    .description = Einstellungen für Sprachen, Websites und Offline-Übersetzung.
    .label = Weitere Einstellungen für die Übersetzung
settings-translations-subpage-header =
    .heading = Weitere Einstellungen für die Übersetzung
settings-translations-subpage-speed-up-translation-header =
    .description = Download kompletter Sprachen für schnellere  und Offline-Übersetzung.
    .label = Übersetzung beschleunigen
settings-translations-subpage-automatic-translation-header =
    .label = Automatische Übersetzung
settings-translations-subpage-always-translate-header =
    .label = Diese Sprachen immer übersetzen
settings-translations-subpage-never-translate-header =
    .label = Diese Sprachen nie übersetzen
settings-translations-subpage-never-translate-sites-header =
    .label = Diese Websites nie übersetzen
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Um eine Website hinzuzufügen, öffnen Sie das <img data-l10n-name="translations-icon"/> Übersetzungsfenster, wählen die <img data-l10n-name="settings-icon"/> Übersetzungseinstellungen und dann „Diese Seite nie übersetzen“.
settings-translations-subpage-language-select-option =
    .label = Sprache hinzufügen
settings-translations-subpage-language-add-button =
    .aria-label = Sprache hinzufügen
    .title = Sprache hinzufügen
settings-translations-subpage-download-languages-header =
    .label = Sprachen herunterladen
settings-translations-subpage-download-languages-select-option =
    .label = Sprache auswählen
settings-translations-subpage-download-languages-button =
    .aria-label = Sprache herunterladen
    .title = Sprache herunterladen
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Keine Sprachen heruntergeladen
settings-translations-subpage-no-languages-added =
    .label = Keine Sprachen hinzugefügt
settings-translations-subpage-download-progress = Download läuft…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = { $language } konnte nicht heruntergeladen werden ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Erneut versuchen
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = { $language } ({ $size } MB) löschen?
settings-translations-subpage-download-delete-button =
    .label = Löschen
settings-translations-subpage-download-cancel-button =
    .label = Abbrechen
settings-translations-subpage-no-sites-added =
    .label = Keine Websites hinzugefügt
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Einstellungen des Betriebssystems für "{ $localeName }" verwenden, um Datum, Uhrzeit, Zahlen und Maßeinheiten zu formatieren.
settings-spellcheck-header =
    .label = Rechtschreibprüfung
check-user-spelling =
    .label = Rechtschreibung während der Eingabe überprüfen
    .accesskey = R
spellcheck-download-dictionaries =
    .label = Wörterbücher hinzufügen
spellcheck-promo =
    .heading = Wie Sie die Rechtschreibprüfung verwenden
    .message = Klicken Sie mit der rechten Maustaste auf ein Textfeld, um die Rechtschreibprüfung zu aktivieren oder zu deaktivieren, oder um die Sprache zu ändern. Nicht alle Felder unterstützen die Rechtschreibprüfung.

## Downloads - Files and applications

files-and-applications-title = Dateien und Anwendungen
download-save-files-header =
    .label = Alle Dateien in folgendem Ordner abspeichern:
download-save-where-3 =
    .aria-label = Alle Dateien in folgendem Ordner abspeichern:
download-always-ask-where2 =
    .label = Jedes Mal nachfragen, wo eine Datei gespeichert werden soll
    .accesskey = n
download-private-browsing-delete2 =
    .label = Heruntergeladene Dateien im privaten Modus löschen, wenn alle privaten Fenster geschlossen sind
    .accesskey = p
applications-header = Anwendungen
applications-description = Legen Sie fest, wie { -brand-short-name } mit Dateien verfährt, die Sie aus dem Web oder aus Anwendungen, die Sie beim Surfen verwenden, herunterladen.
applications-setting2 =
    .description = Legen Sie fest, wie { -brand-short-name } mit heruntergeladenen Dateien und Inhalten verfährt.
    .label = Dateien und Anwendungen
applications-filter =
    .placeholder = Dateitypen oder Anwendungen suchen
applications-type-column =
    .label = Dateityp
    .accesskey = D
applications-type-heading = Dateityp
applications-action-column =
    .label = Aktion
    .accesskey = A
applications-action-heading = Aktion
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension }-Datei
applications-action-save =
    .label = Datei speichern
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Mit { $app-name } öffnen
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Mit { $app-name } öffnen (Standard)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] macOS-Standardanwendung verwenden
            [windows] Windows-Standardanwendung verwenden
           *[other] System-Standardanwendung verwenden
        }
applications-use-other =
    .label = Andere Anwendung…
applications-select-helper = Hilfsanwendung wählen
applications-manage-app =
    .label = Anwendungsdetails…
applications-always-ask =
    .label = Jedes Mal nachfragen
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = In { -brand-short-name } öffnen

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Wie soll { -brand-short-name } mit anderen Dateien verfahren?
applications-save-for-new-types =
    .label = Dateien speichern
    .accesskey = s
applications-save-for-new-types2 =
    .label = Dateien speichern
    .accesskey = s
applications-ask-before-handling =
    .label = Fragen, ob Dateien geöffnet oder gespeichert werden sollen
    .accesskey = F
applications-ask-before-handling2 =
    .label = Fragen, ob Dateien geöffnet oder gespeichert werden sollen
    .accesskey = F
drm-group =
    .label = Inhalte mit DRM-Kopierschutz
play-drm-content =
    .label = Inhalte mit DRM-Kopierschutz wiedergeben
    .accesskey = D
play-drm-content-learn-more = Weitere Informationen
# Variables:
# $version (string) - Firefox version
update-application-version = Version { $version } <a data-l10n-name="learn-more">Neue Funktionen und Änderungen</a>
update-history-2 =
    .label = Update-Chronik anzeigen
    .accesskey = C
update-application-installation =
    .label = Installation
update-application-radio-group =
    .aria-label = Installation
update-application-auto-2 =
    .label = Updates automatisch installieren (empfohlen)
    .accesskey = U
update-application-check-choose-2 =
    .label = Nach Updates suchen, aber wählen, wann sie installiert werden
    .accesskey = N
update-application-background-enabled =
    .label = Wenn { -brand-short-name } nicht ausgeführt wird
    .accesskey = n
update-application-warning-cross-user-setting-2 =
    .message = Diese Einstellung betrifft alle Windows-Konten und { -brand-short-name }-Profile, welche diese Installation von { -brand-short-name } verwenden.
update-application-suppress-prompts-2 =
    .label = Weniger Update-Erinnerungen anzeigen
    .accesskey = W
update-setting-write-failure-title2 = Fehler beim Speichern der Update-Einstellungen
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } bemerkte einen Fehler und hat diese Änderung nicht gespeichert. Das Ändern dieser Update-Einstellung benötigt Schreibrechte für die unten genannte Datei. Sie oder ein Systemadministrator können das Problem eventuell beheben, indem Sie der Gruppe "Benutzer" vollständige Kontrolle über die Datei gewähren.
    
    Konnte folgende Datei nicht speichern: { $path }
update-in-progress-title = Update wird durchgeführt
update-in-progress-message = Soll { -brand-short-name } mit dem Update fortfahren?
update-in-progress-ok-button = &Verwerfen
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Fortfahren

## About Firefox

about-firefox-header =
    .heading = Über { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Updates verbessern die Geschwindigkeit, Stabilität und Sicherheit von { -brand-short-name }.
    .label = { -brand-short-name }-Updates
update-application-suppress-prompts-heading =
    .label = Benachrichtigungen
update-application-updates-managed-by-os =
    .message = Updates werden durch Ihr Betriebssystem verwaltet

## Firefox support

support-application-heading =
    .description = Beheben Sie Probleme oder tauschen Sie Ideen mit der Community aus.
    .label = { -brand-short-name }-Hilfe
support-get-help =
    .label = Hilfe erhalten
support-share-ideas =
    .label = Teilen Sie Ideen und Feedback

## Firefox newsletter

newsletter-settings-heading =
    .description = Holen Sie sich Anleitungen, Ratschläge und Neuigkeiten, damit Sie das bestmögliche { -brand-product-name }-Erlebnis nutzen können.
    .label = { -brand-product-name }-Newsletter
newsletter-sign-up-link =
    .label = Anmelden

## General Section - Performance

performance-settings-learn-more = Weitere Informationen
performance-allow-hw-accel =
    .label = Hardwarebeschleunigung verwenden, wenn verfügbar
    .accesskey = v
performance-limit-content-process-option = Maximale Anzahl an Inhaltsprozessen
    .accesskey = M
performance-limit-content-process-enabled-desc = Mehr Inhaltsprozesse verbessern die Leistung bei Verwendung mehrerer Tabs, aber nutzen auch mehr Arbeitsspeicher.
performance-limit-content-process-blocked-desc = Das Ändern der Anzahl der Inhaltsprozesse ist nur in { -brand-short-name } mit mehreren Prozessen möglich. <a data-l10n-name="learn-more">Wie Sie herausfinden, ob Firefox mit mehreren Prozessen ausgeführt wird</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (Standard)
performance-group =
    .label = Leistung
performance-use-recommended-settings-checkbox-2 =
    .description = Diese Einstellungen sind auf Ihre Hardware und Ihr Betriebssystem abgestimmt.
    .label = Empfohlene Leistungseinstellungen verwenden
    .accesskey = E

## Accessibility page

browsing-use-autoscroll =
    .label = Automatischen Bildlauf aktivieren
    .accesskey = A
keyboard-and-scrolling-group =
    .label = Tastatur-Navigation und Bildlauf
motion-and-link-group =
    .label = Bildlauf und Link-Styling
browsing-use-smooth-scrolling =
    .label = Sanften Bildlauf aktivieren
    .accesskey = S
browsing-gtk-use-non-overlay-scrollbars =
    .label = Bildlaufleisten immer anzeigen
    .accesskey = B
browsing-always-underline-links =
    .label = Links immer unterstreichen
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = Bildschirmtastatur falls notwendig anzeigen
    .accesskey = B
browsing-use-cursor-navigation =
    .label = Markieren von Text mit der Tastatur zulassen
    .accesskey = M
browsing-use-full-keyboard-navigation =
    .label = Tab-Taste verwenden, um den Fokus zwischen Formular-Steuerung und Links zu verschieben
    .accesskey = T
browsing-search-on-start-typing =
    .label = Beim Tippen automatisch im Seitentext suchen
    .accesskey = u
settings-keyboard-shortcuts-group =
    .description = Steuern Sie, wie Sie sich bewegen und mit { -brand-short-name } interagieren.
    .label = Tastenkombinationen
settings-keyboard-shortcuts-customkeys-link =
    .label = Tastenkombinationen anpassen
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Adressleisten-Einstellungen in der Suche anpassen
settings-media-group =
    .label = Medien
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Videosteuerung für Bild-im-Bild (PiP) anzeigen
    .accesskey = V
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Videos weiter in Bild-im-Bild abspielen, wenn Sie Tabs wechseln
    .accesskey = w
browsing-media-control =
    .label = Medien über Tastatur, Headset oder virtuelle Schnittstelle steuern
    .accesskey = e
recommendations-group =
    .label = Empfehlungen
browsing-cfr-recommendations =
    .label = Erweiterungen während des Surfens empfehlen
    .accesskey = h
browsing-cfr-features =
    .label = Funktionen während des Surfens empfehlen
    .accesskey = F
browsing-group =
    .label = Surfen
preferences-accessibility-header =
    .heading = Barrierefreiheit
preferences-default-zoom-select =
    .aria-label = Standard-Zoom
preferences-fonts-family =
    .label = Standard-Schriftart
    .accesskey = S
preferences-fonts-size =
    .label = Größe
    .accesskey = G
preferences-fonts-advanced-settings =
    .label = Erweiterte Einstellungen
    .accesskey = E

## General Section - Proxy

network-proxy-group2 =
    .description = Konfigurieren Sie, wie { -brand-short-name } eine Verbindung zum Internet herstellt.
    .label = Proxy-Einstellungen
network-proxy-connection-settings2 =
    .description = Das Ändern dieser Einstellungen kann zu Verbindungsproblemen führen.
    .label = Proxy konfigurieren
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Neue Fenster und Tabs
home-new-windows-tabs-description2 = Legen Sie fest, was als Startseite sowie in neuen Fenstern und Tabs geöffnet wird.
home-section =
    .heading = Startseite und Start

## Home Section - Default Browser

home-default-browser-title =
    .label = Standardbrowser
is-default-browser-2 =
    .message = { -brand-short-name } ist der Standardbrowser. Gute Wahl.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } ist nicht Ihr Standardbrowser
set-as-my-default-browser-2 =
    .label = Als Standard festlegen
    .accesskey = g

## Custom Homepage subpage

home-homepage-mode-label = Startseite und neue Fenster
home-newtabs-mode-label = Neue Tabs
home-restore-defaults =
    .label = Standard wiederherstellen
    .accesskey = w
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Standard)
home-mode-choice-custom =
    .label = Benutzerdefinierte Adressen…
home-mode-choice-blank =
    .label = Leere Seite
home-homepage-custom-url =
    .placeholder = Adresse einfügen…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Erweiterung verwalten
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Aktuelle Seite verwenden
           *[other] Aktuelle Seiten verwenden
        }
    .accesskey = A
choose-bookmark =
    .label = Lesezeichen verwenden…
    .accesskey = L
home-homepage-title =
    .label = Startseite
home-homepage-new-windows =
    .label = Neue Fenster
home-homepage-new-tabs =
    .label = Neue Tabs
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Wählen Sie eine bestimmte Website
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Website-Adresse(n)
home-custom-homepage-list =
    .aria-label = Website-Adressen
home-custom-homepage-address =
    .placeholder = Adresse eingeben
home-custom-homepage-address-button =
    .label = Adresse hinzufügen
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Noch keine Websites hinzugefügt.
home-custom-homepage-delete-address-button =
    .aria-label = Adresse löschen
    .title = Adresse löschen
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Ersetzen durch
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Derzeit geöffnete Seiten
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Lesezeichen…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Erweiterung ({ $extension })
home-custom-homepage-header = Benutzerdefinierte Startseite
home-custom-homepage-subpage =
    .heading = Benutzerdefinierte Startseite

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name }-Inhalte
home-prefs-content-description2 = Wählen Sie, welche Inhalte auf Ihrem { -firefox-home-brand-name }-Bildschirm angezeigt werden sollen.
home-prefs-search-header =
    .label = Internetsuche
home-prefs-shortcuts-header =
    .label = Verknüpfungen
home-prefs-shortcuts-description = Websites, die Sie speichern oder besuchen
home-prefs-shortcuts-by-option-sponsored =
    .label = Gesponserte Verknüpfungen
home-prefs-recommended-by-header-generic =
    .label = Empfohlene Artikel
home-prefs-recommended-by-description-generic = Besondere Inhalte ausgewählt von der { -brand-product-name }-Familie
home-prefs-stories-header =
    .label = Artikel
home-prefs-stories-description = Artikel, die Ihnen gefallen könnten

##

home-prefs-recommended-by-learn-more = Wie es funktioniert
home-prefs-recommended-by-option-sponsored-stories =
    .label = Gesponserte Artikel
home-prefs-highlights-option-visited-pages =
    .label = Besuchte Seiten
home-prefs-highlights-options-bookmarks =
    .label = Lesezeichen
home-prefs-highlights-option-most-recent-download =
    .label = Neueste Downloads
home-prefs-recent-activity-header =
    .label = Neueste Aktivität
home-prefs-recent-activity-description = Eine Auswahl kürzlich besuchter Websites und Inhalte
home-prefs-weather-header =
    .label = Wetter
home-prefs-weather-description = Die heutige Wettervorhersage auf einen Blick
home-prefs-weather-learn-more-link = Weitere Informationen
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = { -brand-product-name } unterstützen
home-prefs-mission-message = Unsere Sponsoren unterstützen unsere Mission, ein besseres Internet zu schaffen
home-prefs-mission-message-learn-more-link = Erfahren, wie das geht
home-prefs-manage-topics-link = Themen verwalten
home-prefs-choose-wallpaper-link = Wählen Sie ein Hintergrundbild
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } Zeile
           *[other] { $num } Zeilen
        }

## Search Section

search-show-suggestions-option =
    .label = Suchvorschläge anzeigen
    .accesskey = S
search-show-suggestions-url-bar-option =
    .label = Suchvorschläge in Adressleiste anzeigen
    .accesskey = v
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = In Adressleiste Suchvorschläge anzeigen, bevor Sie die Chronik ansehen
search-show-suggestions-private-windows-2 =
    .label = Suchvorschläge in privaten Fenstern
search-suggestions-cant-show-2 =
    .message = Suchvorschläge werden nicht in der Adressleiste angezeigt, weil { -brand-short-name } angewiesen wurde, keine Chronik zu speichern.
addressbar-header-1 =
    .description = Wählen Sie aus, welche Vorschläge in Ihrer Adressleiste angezeigt werden
    .label = Adressleiste
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Vorschläge von { -brand-short-name } und unseren Partnern in Ihrer Adressleiste.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Suchbegriffe in der Adressleiste auf Ergebnisseiten anzeigen
search-separate-default-engine-2 =
    .label = Verwenden Sie eine andere Standardsuchmaschine in privaten Fenstern
    .accesskey = V
search-separate-default-engine-dropdown =
    .aria-label = Standardsuchmaschine in privaten Fenstern
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Navigation in der Adressleiste
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Ergebnismenü überspringen, wenn Sie die Tab-Taste zum Verschieben des Fokus verwenden
search-suggestions-header-2 =
    .label = Suchmaschinen-Vorschläge
search-one-click-header2 = Suchmaschinen-Schlüsselwörter
search-one-click-desc = Wählen Sie die Suchmaschinen, welche unterhalb der Adress- bzw. Suchleiste angezeigt werden, nachdem Sie den Suchbegriff eingegeben haben.
search-one-click-header-3 =
    .description = Wählen Sie, welche Suchmaschinen und Verknüpfungen in Ihrer Adressleiste angezeigt werden sollen.
    .label = Zusätzliche Suchmaschinen
search-engine-list =
    .aria-label = Suchmaschinen und Suchverknüpfungen
update-search-engine-success =
    .message = Suchmaschine erfolgreich aktualisiert
search-edit-engine-2 =
    .title = Suchmaschine bearbeiten
search-delete-engine =
    .title = Suchmaschine löschen
search-enable-engine =
    .title = Suchmaschine aktivieren
search-outlink-to-extensions-page =
    .title = In Erweiterungen und Themes verwalten
search-choose-engine-column =
    .label = Suchmaschine
search-choose-keyword-column =
    .label = Schlüsselwort
search-restore-default =
    .label = Standardsuchmaschinen wiederherstellen
    .accesskey = w
search-remove-engine =
    .label = Entfernen
    .accesskey = E
search-add-engine =
    .label = Hinzufügen
    .accesskey = H
search-add-engine-2 =
    .label = Suchmaschine hinzufügen
    .accesskey = h
search-edit-engine =
    .label = Bearbeiten
    .accesskey = B
search-find-more-link = Weitere Suchmaschinen hinzufügen
search-filtering-for-add-engine = Suchmaschine hinzufügen
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Doppeltes Schlüsselwort
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Sie haben ein Schlüsselwort ausgewählt, das bereits von "{ $name }" verwendet wird, bitte wählen Sie ein anderes.
search-keyword-warning-bookmark = Sie haben ein Schlüsselwort ausgewählt, das bereits von einem Lesezeichen verwendet wird, bitte wählen Sie ein anderes.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Es gibt bereits eine Suchmaschine mit dem Namen "{ $name }". Bitte wählen Sie einen anderen Namen.
remove-engine-confirmation = Soll diese Suchmaschine wirklich entfernt werden?
remove-engine-remove = Entfernen
remove-addon-engine-alert = Um diese Suchmaschine zu entfernen, entfernen Sie das zugehörige Add-on.
search-engine-group =
    .label = Standardsuchmaschine
search-default-engine =
    .aria-label = Standardsuchmaschine
# Header for the search section ("search" is a noun).
search-section =
    .heading = Suchen

## Containers Section

containers-section-header2 =
    .heading = Einstellungen für Tab-Umgebungen
containers-card-header2 =
    .description = Trennen Sie Cookies durch Tab-Umgebungen, damit Sie verschiedene Konten auf derselben Website verwenden und das seitenübergreifende Tracking einschränken können.
    .label = Tab-Umgebungen
containers-add-button2 =
    .label = Neue Tab-Umgebung hinzufügen
    .accesskey = N
containers-list =
    .aria-label = Tab-Umgebungen
containers-new-tab-check3 =
    .label = Tab-Umgebung für jeden neuen Tab wählen
    .accesskey = w
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Keine Tab-Umgebungen für Links verwenden, die von externen Apps geöffnet werden
    .accesskey = K
containers-new-tab-check2 =
    .description = Dadurch wird das Tab-Umgebungs-Menü jedes Mal geöffnet, wenn Sie die Schaltfläche Neuer Tab öffnen drücken.
    .label = Tab-Umgebung für jeden neuen Tab wählen
    .accesskey = w
containers-settings-button2 =
    .title = Einstellungen
containers-remove-button3 =
    .title = Löschen
containers-sites-card-header =
    .description = Wählen Sie eine Tab-Umgebung für eine Website und { -brand-short-name } verwendet sie jedes Mal, wenn die Website geöffnet wird.
    .label = Seitenspezifische Umgebungen
containers-sites-add-button =
    .label = Website hinzufügen
    .accesskey = W
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Tab-Umgebung für { $site }
containers-site-remove-button =
    .title = Löschen
containers-remove-button2 =
    .title = Entfernen

## Account and sync

sync-group-label =
    .label = Synchronisation
account-group-label2 =
    .label = Konto
account-disabled-group =
    .description = Kontoeinstellungen sind nicht verfügbar.
    .label = Konto
account-placeholder2 =
    .description = Melden Sie sich an und sorgen Sie dafür, dass Ihre Daten privat, verschlüsselt und überall, wo Sie { -brand-short-name } nutzen, sofort verfügbar sind.
    .label = Sie sind nicht angemeldet
account-sync-section =
    .heading = Konto und Synchronisation
pane-account-sync-title2 = Konto und Synchronisation
    .title = Konto und Synchronisation

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = So haben Sie das Web überall dabei.
sync-signedout-description2 = Synchronisieren Sie Ihre Lesezeichen, Chronik, Tabs, Passwörter, Add-ons und Einstellungen zwischen allen Ihren Geräten.
sync-signedout-account-signin3 =
    .label = Zum Synchronisieren anmelden…
    .accesskey = S
sync-signedout-account-signin-4 =
    .label = Melden Sie sich bei Ihrem Konto an, um mit der Synchronisation zu beginnen
    .accesskey = M
sync-signedout-account-short =
    .label = Anmelden
    .accesskey = A
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Firefox für <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> oder <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> herunterladen, um mit Ihrem Handy zu synchronisieren.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Profilbild ändern
    .tooltiptext = Profilbild ändern
sync-profile-picture-account-problem =
    .alt = Profilbild des Kontos
fxa-login-rejected-warning =
    .alt = Warnung
sync-sign-out =
    .label = Abmelden…
    .accesskey = b
sync-sign-out2 =
    .label = Abmelden
    .accesskey = b
sync-manage-account = Konto verwalten
    .accesskey = v
sync-manage-account2 =
    .label = Konto verwalten
    .accesskey = v

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } wurde noch nicht bestätigt.
sync-signedin-unverified2 =
    .description = Überprüfen Sie Ihren Posteingang, um Ihr Konto zu verifizieren.
    .label = { $email } wurde noch nicht bestätigt
sync-signedin-login-failure = Melden Sie sich an, um erneut mit { $email } zu verbinden.
sync-signedin-login-failure2 =
    .description = Melden Sie sich wieder an, um Ihre Daten zu synchronisieren.
    .label = Sie sind von { $email } abgemeldet
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Konto verifizieren
    .accesskey = v
sync-remove-account =
    .label = Konto entfernen
    .accesskey = e
sync-sign-in =
    .label = Anmelden
    .accesskey = m

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synchronisation: EIN
prefs-syncing-on-2 =
    .label = Die Synchronisation ist AKTIVIERT
prefs-syncing-off = Synchronisation: AUS
prefs-syncing-off-2 =
    .description = Aktivieren Sie die Synchronisation, um Ihre Lesezeichen, Passwörter, den Verlauf und mehr auf jedem Gerät abzurufen.
    .label = Die Synchronisation ist DEAKTIVIERT
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Aktivieren Sie die Synchronisation, um Ihre Lesezeichen, Passwörter, Chronik und mehr auf dieses Gerät zu übertragen.
    .label = Die Synchronisation ist DEAKTIVIERT
prefs-sync-turn-on-syncing =
    .label = Synchronisation aktivieren…
    .accesskey = S
prefs-sync-turn-on-syncing-2 =
    .label = Synchronisation aktivieren
    .accesskey = S
prefs-sync-offer-setup-label2 = Synchronisieren Sie Ihre Lesezeichen, Chronik, Tabs, Passwörter, Add-ons und Einstellungen zwischen allen Ihren Geräten.
prefs-sync-now-button =
    .label = Jetzt synchronisieren
    .accesskey = J
prefs-sync-now-button-2 =
    .label = Jetzt synchronisieren
    .accesskey = J
prefs-syncing-button =
    .label = Wird synchronisiert…
prefs-syncing-button-2 =
    .label = Wird synchronisiert…
    .title = Jetzt synchronisieren
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Ihre Auswahl für die Synchronisierung gilt jetzt nur für dieses Gerät.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Sie synchronisieren diese Elemente mit allen Ihren verbundenen Geräten:
sync-syncing-across-devices-heading-2 = Diese Daten werden zwischen den Geräten synchronisiert:
sync-syncing-across-devices-heading-3 = Auf diesem Gerät synchronisierte Daten
sync-syncing-across-devices-empty-state2 =
    .description = Sie synchronisieren nichts … noch nicht. Starten Sie die Synchronisierung, um alle ihre Daten auf allen ihren Geräten zu haben.
    .label = Synchronisierte Daten verwalten
sync-syncing-across-devices-empty-state3 =
    .description = Sie synchronisieren… noch nichts. Wählen Sie aus, was auf diesem Gerät synchronisiert werden soll.
    .label = Synchronisierte Daten verwalten
sync-currently-syncing-bookmarks = Lesezeichen
sync-currently-syncing-history = Chronik
sync-currently-syncing-tabs = Offene Tabs
sync-currently-syncing-passwords = Passwörter
sync-currently-syncing-addresses = Adressen
sync-currently-syncing-payment-methods = Zahlungsmethoden
sync-currently-syncing-addons = Add-ons
sync-currently-syncing-settings = Einstellungen
sync-manage-options =
    .label = Synchronisierung verwalten…
    .accesskey = S
sync-manage-options-2 =
    .label = Synchronisierte Daten verwalten
    .accesskey = v
settings-sync-disconnect-button =
    .label = Trennen

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Lesezeichen
    .accesskey = L
sync-engine-history =
    .label = Chronik
    .accesskey = C
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Offene Tabs
    .tooltiptext = Offene Tabs von Ihren anderen Geräten
    .accesskey = O
sync-engine-tabs =
    .label = Offene Tabs
    .tooltiptext = Liste aller offenen Tabs von allen verbundenen Geräten
    .accesskey = T
sync-engine-passwords =
    .label = Passwörter
    .tooltiptext = Gespeicherte Passwörter
    .accesskey = P
sync-engine-addresses2 =
    .label = Adressen
    .tooltiptext = Adressen, die Sie in { -brand-short-name } gespeichert haben
    .accesskey = A
sync-engine-payment-methods3 =
    .label = Zahlungsmethoden
    .tooltiptext = Zahlungsmethoden, die Sie gespeichert haben
    .accesskey = Z
sync-engine-addons2 =
    .label = Add-ons
    .tooltiptext = Erweiterungen und Themes, die Sie zu { -brand-short-name } für Desktop hinzugefügt haben
    .accesskey = A
sync-engine-settings2 =
    .label = Einstellungen
    .tooltiptext = { -brand-short-name }-Einstellungen, wo zutreffend
    .accesskey = E
sync-engine-addresses =
    .label = Adressen
    .tooltiptext = Gespeicherte postalische Adressen (nur für Desktops)
    .accesskey = d
sync-engine-payment-methods2 =
    .label = Zahlungsmethoden
    .tooltiptext = Namen, Kartennummern und Gültigkeitsdatum
    .accesskey = Z
sync-engine-addons =
    .label = Add-ons
    .tooltiptext = Erweiterungen und Themes für Firefox für Desktops
    .accesskey = A
sync-engine-settings =
    .label = Einstellungen
    .tooltiptext = Durch Sie geänderte allgemeine, Datenschutz- und Sicherheitseinstellungen
    .accesskey = E
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Speichern
    .buttonlabelextra2 = Trennen…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = T
    .style = min-width: 36em;
    .title = Verwalten, was mit Ihren verbundenen Geräten synchronisiert wird
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Speichern
    .buttonlabelextra2 = Trennen…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Verwalten, was auf diesem Gerät synchronisiert wird

## The device name controls.

sync-device-name-header = Gerätename
sync-device-name-header-2 =
    .label = Gerätename
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Gerätename
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Gerät umbenennen
    .accesskey = u
sync-device-name-change =
    .label = Gerät umbenennen…
    .accesskey = u
sync-device-name-cancel =
    .label = Abbrechen
    .accesskey = b
sync-device-name-save =
    .label = Speichern
    .accesskey = S
sync-connect-another-device = Weiteres Gerät verbinden
sync-connect-another-device-2 =
    .label = Weiteres Gerät verbinden

## Privacy Section

privacy-header = Browser-Datenschutz

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Passwörter
    .searchkeywords = Zugangsdaten
forms-passwords-header =
    .aria-label = Passwörter
    .label = Passwörter
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Fragen, ob Passwörter gespeichert werden sollen
    .accesskey = F
forms-manage-password-exceptions =
    .label = Ausnahmen für Passwörter verwalten
    .accesskey = v
forms-exceptions =
    .label = Ausnahmen…
    .accesskey = u
forms-suggest-passwords =
    .label = Starke Passwörter vorschlagen
    .accesskey = S
forms-breach-alerts =
    .label = Alarme für Passwörter, deren Websites von einem Datenleck betroffen waren
    .accesskey = A
forms-breach-alerts-learn-more-link = Weitere Informationen
preferences-relay-integration-checkbox2 =
    .label = { -relay-brand-name }-E-Mail-Masken zum Schutz Ihrer E-Mail-Adresse vorschlagen
    .accesskey = E
relay-integration-learn-more-link = Weitere Informationen
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Benutzernamen und Passwörter automatisch ausfüllen
    .accesskey = a
forms-fill-usernames-and-passwords-2 =
    .label = Benutzernamen und Passwörter speichern und automatisch ausfüllen
    .accesskey = a
forms-saved-passwords =
    .label = Gespeicherte Passwörter
    .accesskey = G
forms-saved-passwords-2 =
    .label = Gespeicherte Passwörter verwalten
    .accesskey = G
forms-saved-passwords-searchkeywords = Zugangsdaten für folgende Websites sind auf Ihrem Computer gespeichert:
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Zusätzliche Schutzmaßnahmen
forms-primary-pw-use =
    .label = Hauptpasswort verwenden
    .accesskey = v
forms-primary-pw-use-2 =
    .description = Fügt eine zusätzliche Sicherheitsebene hinzu, um Ihre gespeicherten Passwörter zu schützen.
    .label = Hauptpasswort verwenden
    .accesskey = v
forms-primary-pw-set =
    .label = Hauptpasswort festlegen
forms-primary-pw-on-2 = Hauptpasswort ist <strong>AN</strong>
forms-primary-pw-on =
    .label = Hauptpasswort ist AN
forms-primary-pw-change-2 =
    .label = Hauptpasswort ändern
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Deaktivieren
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Anmeldung am Gerät zum Ausfüllen und Verwalten von Passwörtern verlangen
forms-os-reauth-2 =
    .label = Anmeldung am Gerät zum Verwalten von Passwörtern verlangen
forms-primary-pw-learn-more-link = Weitere Informationen
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Hauptpasswort ändern…
    .accesskey = H
forms-primary-pw-change =
    .label = Hauptpasswort ändern…
    .accesskey = H
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = Früher bekannt als Master-Passwort
forms-primary-pw-fips-title = Sie sind derzeit im FIPS-Modus. FIPS benötigt ein nicht leeres Hauptpasswort.
forms-master-pw-fips-desc = Ändern des Passworts fehlgeschlagen
forms-windows-sso =
    .label = Windows Single Sign-on für Microsoft-, Geschäfts- und Schulkonten erlauben
forms-windows-sso-learn-more-link = Weitere Informationen
forms-windows-sso-desc = Verwalten Sie Konten in Ihren Geräteeinstellungen.
windows-passkey-settings-label = Passkeys in den Systemeinstellungen verwalten
privacy-panel-settings-header =
    .description = Erhalten Sie Hilfe, um Ihre Informationen online zu schützen in { -brand-short-name }.
    .label = Datenschutzeinstellungen
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Nachrichten zu Datenlecks anzeigen
    .accesskey = N

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Um ein Hauptpasswort zu erstellen, müssen die Anmeldedaten des Windows-Benutzerkontos eingegeben werden. Dies dient dem Schutz Ihrer Zugangsdaten.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = Hauptpasswort festlegen
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] die Einstellungen für Zahlungsmethoden ändern
       *[other] { -brand-short-name } versucht, die Einstellungen für Zahlungsmethoden zu ändern. Verwenden Sie die Anmeldung auf dem Gerät, um dies zu erlauben.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Zahlungsmethoden
autofill-payment-methods-checkbox-message-2 =
    .label = Zahlungsinformationen speichern und automatisch ausfüllen
    .accesskey = Z
autofill-payment-methods-manage-payments-title =
    .heading = Zahlungsmethoden verwalten
autofill-payment-methods-manage-payments-button =
    .label = Zahlungsmethode verwalten
    .accesskey = v
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Zum automatischen Ausfüllen Geräteanmeldung erforderlich machen
    .accesskey = A
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Anmeldung am Gerät anfordern, um Zahlungsmethoden automatisch auszufüllen und zu verwalten
    .accesskey = A
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Sicherheitscodes speichern
    .accesskey = S
autofill-payment-methods-add-button = Neue Zahlungsmethode hinzufügen
payments-list-header =
    .label = Zahlungsmethoden
payments-delete-payment-prompt-title = Diese Zahlungsmethode löschen?
payments-delete-payment-prompt-confirm-button = Löschen
payments-delete-payment-prompt-cancel-button = Abbrechen
payments-delete-payment-button-label =
    .aria-label = Löschen
payments-edit-payment-button-label =
    .aria-label = Bearbeiten
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Keine Zahlungsmethoden hinzugefügt
autofill-addresses-checkbox-message =
    .label = Adressen speichern und automatisch ausfüllen
    .accesskey = s
autofill-addresses-manage-addresses-button =
    .label = Adressen und mehr verwalten
    .accesskey = m
addresses-list-header =
    .label = Adressen
addreses-delete-address-button-label =
    .aria-label = Löschen
addreses-edit-address-button-label =
    .aria-label = Bearbeiten
addresses-delete-address-prompt-title = Diese Adresse löschen?
addresses-delete-address-prompt-confirm-button = Löschen
addresses-delete-address-prompt-cancel-button = Abbrechen
autofill-addresses-add-button = Neue Adresse hinzufügen
autofill-addresses-manage-addresses-title =
    .heading = Adressen und mehr verwalten
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Keine Adressen hinzugefügt
personal-info-group =
    .label = Persönliche Daten
autofill-personal-info-checkbox-message =
    .label = Persönliche Daten speichern und automatisch ausfüllen
autofill-personal-info-manage-button =
    .label = Persönliche Daten verwalten
passports-list-header =
    .label = Reisepässe
passports-delete-passport-button-label =
    .aria-label = Löschen
passports-edit-passport-button-label =
    .aria-label = Bearbeiten
passports-delete-passport-prompt-title = Diesen Reisepass löschen?
passports-delete-passport-prompt-confirm-button = Löschen
passports-delete-passport-prompt-cancel-button = Abbrechen
autofill-passports-add-button = Neuen Reisepass hinzufügen
autofill-personal-info-manage-title =
    .heading = Persönliche Daten verwalten
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Keine Reisepässe hinzugefügt
pane-passwords-autofill-title2 = Passwörter und Autovervollständigung
    .title = Passwörter und Autovervollständigung
preferences-passwords-autofill-header =
    .heading = Passwörter und Autovervollständigung
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } gespeichert
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } gespeichert
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adressen und mehr
payments-group =
    .label = Zahlungsmethoden

## Privacy Section - History

history-remember-option-never2 =
    .description = Jedes Fenster verhält sich wie ein privates Fenster. Wenn diese Option aktiviert ist, müssen Erweiterungen zugelassen werden.
    .label = Chronik niemals anlegen
history-remember-option-custom2 =
    .label = Chronik anpassen
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } wird die Adressen der besuchten Webseiten, Downloads sowie eingegebene Formular- und Suchdaten speichern.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } wird dieselben Einstellungen wie im Privaten Modus verwenden und keinerlei Chronik anlegen, während Sie { -brand-short-name } benutzen.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } wird benutzerdefinierte Einstellungen für das Surfen, Downloads, Formulare und Suchchroniken verwenden.
history-private-browsing-permanent =
    .label = Immer den Privaten Modus verwenden
    .accesskey = M
history-remember-browser-option =
    .label = Besuchte Seiten und Download-Chronik speichern
    .accesskey = w
history-remember-search-option =
    .label = Eingegebene Suchbegriffe und Formulardaten speichern
    .accesskey = S
history-clear-on-close-option =
    .label = Die Chronik löschen, wenn { -brand-short-name } geschlossen wird
    .accesskey = g
history-clear-on-close-settings =
    .label = Einstellungen…
    .accesskey = E
history-shutdown-exceptions =
    .label = Ausnahmen verwalten
    .accesskey = A
history-clear-button =
    .label = Chronik löschen…
    .accesskey = C
history-header2 =
    .heading = Chronik
history-section-header =
    .description = Wählen Sie aus, was { -brand-short-name } beim Schließen des Browsers speichern soll.
    .label = Chronik
history-custom-section-header =
    .description = Wählen Sie aus, was { -brand-short-name } beim Schließen des Browsers speichern soll.
    .label = Erweiterte Einstellungen
history-custom-button =
    .label = Wählen Sie aus, was { -brand-short-name } speichern soll
history-group =
    .label = Chronik
history-mode-radio-group =
    .aria-label = Chronik
history-remember-option-all2 =
    .label = Chronik anlegen

## Privacy Section - Site Data

sitedata-total-size-calculating = Größe von Website-Daten und Cache wird berechnet…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Websites belegen derzeit <strong>{ $value } { $unit }</strong> Speicherplatz.
sitedata-learn-more = Weitere Informationen
sitedata-delete-on-close2 =
    .label = Cookies und Website-Daten beim Beenden von { -brand-short-name } löschen
    .accesskey = B
sitedata-delete-on-close-private-browsing3 =
    .message = Basierend auf Ihren Chronikeinstellungen löscht { -brand-short-name } Cookies und Website-Daten aus Ihrer Sitzung, wenn Sie den Browser schließen.
sitedata-delete-on-close-private-browsing4 =
    .heading = Chronik wird nicht gespeichert.
    .message = { -brand-short-name } löscht Cookies und Website-Daten aus Ihrer Sitzung, wenn Sie den Browser schließen.
sitedata-option-block-cross-site-trackers =
    .label = Zur seitenübergreifenden Aktivitätenverfolgung
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cookies zur seitenübergreifenden Aktivitätenverfolgung
sitedata-option-block-cross-site-cookies2 =
    .label = Seitenübergreifende Cookies isolieren
sitedata-option-block-unvisited =
    .label = Cookies von nicht besuchten Websites
sitedata-option-block-all-cross-site-cookies =
    .label = Alle seitenübergreifenden Cookies (einige Websites funktionieren dann eventuell nicht mehr)
sitedata-option-block-all =
    .label = Alle Cookies (einige Websites funktionieren dann nicht mehr)
sitedata-clear2 =
    .label = Surf-Daten löschen
    .accesskey = l
sitedata-settings2 =
    .label = Surf-Daten verwalten
    .accesskey = v
sitedata-cookies-exceptions =
    .label = Ausnahmen verwalten…
    .accesskey = u
sitedata-cookies-exceptions2 =
    .description = Sie können festlegen, welche Websites immer oder nie Cookies und Seitendaten verwenden dürfen.
    .label = Ausnahmen verwalten
    .accesskey = A
sitedata-heading =
    .description = Verwalten Sie Ihre Cookies, Ihren Verlauf, Ihren Cache, Ihre Website-Daten und vieles mehr.
    .label = Browser-Daten
sitedata-settings3 =
    .label = Daten für bestimmte Websites löschen
    .accesskey = l
sitedata-cookies-exceptions3 =
    .description = Wählen Sie aus, wie bestimmte Websites mit Cookies und Website-Daten umgehen sollen.
    .label = Ausnahmen verwalten
    .accesskey = A
cookies-site-data-group =
    .label = Cookies und Website-Daten

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Cookie-Banner-Blocker
cookie-banner-blocker-description = Wenn eine Website fragt, ob sie Cookies im privaten Modus verwenden darf, lehnt { -brand-short-name } dies automatisch für Sie ab. Nur auf unterstützten Websites.
cookie-banner-learn-more = Weitere Informationen
cookie-banner-blocker-checkbox-label =
    .label = Cookie-Banner automatisch ablehnen

## Search Section

addressbar-locbar-history-option =
    .label = Einträge aus der Chronik
    .accesskey = C
addressbar-locbar-bookmarks-option =
    .label = Einträge aus den Lesezeichen
    .accesskey = L
addressbar-locbar-clipboard-option =
    .label = Zwischenablage
    .accesskey = Z
addressbar-locbar-openpage-option =
    .label = Offene Tabs
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Verknüpfungen
    .accesskey = V
addressbar-locbar-topsites-option =
    .label = Wichtige Seiten
    .accesskey = W
addressbar-locbar-engines-option-1 =
    .label = Suchmaschinen vorschlagen
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = Schnellaktionen
    .accesskey = S
addressbar-locbar-showrecentsearches-option-2 =
    .label = Letzte Suchanfragen
    .accesskey = L
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Beliebte Suchvorschläge
    .accesskey = B
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Erhalten Sie Vorschläge aus dem Web, die sich auf Ihre Suche beziehen.
    .label = Vorschläge von { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Unterstützen Sie { -brand-short-name } mit gelegentlichen gesponserten Vorschlägen.
    .label = Vorschläge von Sponsoren
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Abrufen von Vorschlägen von Mozilla beim Eintippen
addressbar-dismissed-suggestions-label-2 =
    .description = Verworfene Vorschläge von Sponsoren und { -brand-short-name } wiederherstellen.
    .label = Verworfene Vorschläge
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Vorschläge wiederherstellen

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Verbesserter Schutz vor Aktivitätenverfolgung
content-blocking-section-top-level-description = Skripte zur Aktivitätenverfolgung folgen Ihnen und sammeln Informationen über Ihre Internet-Gewohnheiten und Interessen. { -brand-short-name } blockiert viele dieser Skripte zur Aktivitätenverfolgung und andere böswillige Skripte.
content-blocking-learn-more = Weitere Informationen
content-blocking-fpi-incompatibility-warning = Sie verwenden First Party Isolation (FPI), was einige der Cookie-Einstellungen von { -brand-short-name } überschreibt.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Sie verwenden "Resist Fingerprinting" (RFP), was einige der Einstellungen von { -brand-short-name } zum Schutz vor Identifizierung (Fingerprinter) ersetzt. Dies kann dazu führen, dass einige Websites nicht funktionieren.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standard
    .accesskey = S
enhanced-tracking-protection-setting-strict =
    .label = Streng
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Benutzerdefiniert
    .accesskey = B

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Ausgewogen zwischen Schutz und Leistung. Seiten laden normal.
content-blocking-etp-strict-desc = Stärkerer Schutz, einige Websites oder mancher Inhalt funktioniert eventuell nicht.
content-blocking-etp-custom-desc = Wählen Sie, welche Art von Skripten zur Aktivitätenverfolgung und sonstige Inhalte blockiert werden.
content-blocking-etp-blocking-desc = { -brand-short-name } blockiert Folgendes:
content-blocking-private-windows = Inhalte zur Aktivitätenverfolgung in privaten Fenstern
content-blocking-cross-site-cookies-in-all-windows2 = Seitenübergreifende Cookies in allen Fenstern
content-blocking-cross-site-tracking-cookies = Cookies zur seitenübergreifenden Aktivitätenverfolgung
content-blocking-all-cross-site-cookies-private-windows = Seitenübergreifende Cookies in privaten Fenstern
content-blocking-isolate-cross-site-cookies = Seitenübergreifende Cookies isolieren
content-blocking-social-media-trackers = Skripte zur Aktivitätenverfolgung durch soziale Netzwerke
content-blocking-all-cookies = Alle Cookies
content-blocking-unvisited-cookies = Cookies von nicht besuchten Websites
content-blocking-all-windows-tracking-content = Inhalte zur Aktivitätenverfolgung in allen Fenstern
content-blocking-all-cross-site-cookies = Alle seitenübergreifenden Cookies
content-blocking-cryptominers = Heimliche Digitalwährungsberechner (Krypto-Miner)
content-blocking-fingerprinters = Identifizierer (Fingerprinter)
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Bekannte und vermutete Identifizierer (Fingerprinter)
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Der vollständige Cookie-Schutz beschränkt Cookies auf die Website, auf der Sie sich befinden, sodass Elemente zur Aktivitätenverfolgung sie nicht verwenden können, um Ihnen Website-übergreifend zu folgen.
content-blocking-etp-standard-tcp-rollout-learn-more = Weitere Informationen
content-blocking-etp-standard-tcp-title = Beinhaltet den vollständigen Cookie-Schutz, unsere leistungsfähigste Datenschutzfunktion aller Zeiten
content-blocking-warning-title-2 = Einige Websites können möglicherweise wegen des strengen Schutzes vor Aktivitätenverfolgung nicht funktionieren.
content-blocking-warning-title-custom = Einige Websites können möglicherweise wegen des benutzerdefinierten Schutzes vor Aktivitätenverfolgung nicht funktionieren.
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } empfiehlt die Verwendung der Einstellungen "Probleme mit Webseiten beheben", um fehlerhafte Funktionen und Inhalte von Websites zu reduzieren. Wenn eine Webseite defekt zu sein scheint, versuchen Sie, den Tracking-Schutz für diese Website zu deaktivieren, um alle Inhalte zu laden.
content-blocking-warning-learn-how = Weitere Informationen
content-blocking-baseline-exceptions-3 =
    .description = Hilft beim Laden von Webseiten und Funktionen, indem nur wichtige Elemente freigeschaltet werden, die Tracker enthalten könnten. Deckt die häufigsten Probleme ab.
    .label = Größere Probleme mit Websites beheben (empfohlen)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Stellt Dinge wie Videos in einem Artikel oder Kommentarabschnitten wieder her, indem es Elemente freigibt, die Tracker enthalten könnten. Dies kann Probleme mit der Website reduzieren, bietet aber weniger Schutz. Muss mit Korrekturen für größere Probleme verwendet werden.
    .label = Kleinere Probleme mit Websites beheben
content-blocking-baseline-uncheck-warning-dialog-title = Sollen die Korrekturen wirklich deaktiviert werden?
content-blocking-baseline-uncheck-warning-dialog-body = Diese Einstellung hilft bei der Behebung der häufigsten Probleme mit der Website. Wenn Sie sie deaktivieren, funktionieren einige Websites möglicherweise nicht und { -brand-short-name } kann nicht bei der Behebung dieser Probleme helfen.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Fehlerbehebungen deaktivieren
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Fehlerbehebungen aktiviert lassen
content-blocking-reload-description = Um die Änderungen anzuwenden, müssen alle Tabs neu geladen werden.
content-blocking-reload-tabs-button =
    .label = Alle Tabs neu laden
    .accesskey = T
content-blocking-tracking-content-label =
    .label = Inhalte zur Aktivitätenverfolgung
    .accesskey = n
content-blocking-tracking-protection-option-all-windows =
    .label = In allen Fenstern
    .accesskey = a
content-blocking-option-private =
    .label = Nur in privaten Fenstern
    .accesskey = p
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Weitere Informationen
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Heimliche Digitalwährungsberechner (Krypto-Miner)
    .accesskey = w
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Bekannte Identifizierer (Fingerprinter)
    .accesskey = B
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Vermutete Identifizierer (Fingerprinter)
    .accesskey = V

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Ausnahmen verwalten…
    .accesskey = v

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Benachrichtigungen bis zum Neustart von { -brand-short-name } deaktivieren
    .accesskey = n
permissions-autoplay2 =
    .label = Automatische Wiedergabe
permissions-block-popups2 =
    .label = Blockieren Sie Pop-ups und Drittanbieter-Weiterleitungen
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Ausnahmen für Pop-ups und Drittanbieter-Weiterleitungen verwalten
    .label = Ausnahmen verwalten
    .searchkeywords = Pop-ups
    .accesskey = E
permissions-addon-install-warning3 =
    .label = Warnen, wenn Websites versuchen, Erweiterungen zu installieren
    .accesskey = W
permissions-addon-exceptions2 =
    .label = Wählen Sie aus, welche Websites Erweiterungen installieren dürfen
    .accesskey = E
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Websites erlauben, das Öffnen von App-Links anzufragen.
    .accesskey = W
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Blockierte Websites verwalten
    .accesskey = B
permissions-location2 =
    .label = Standort
permissions-localhost2 =
    .label = Apps und Dienste des Geräts
permissions-local-network2 =
    .label = Geräte im lokalen Netzwerk
permissions-xr2 =
    .label = Virtuelle Realität
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Lautsprecher
permissions-notification2 =
    .label = Benachrichtigungen
permissions-header3 =
    .description = Verwalten Sie, auf was Websites zugreifen können, was kontrolliert oder ausgelöst werden kann.
    .label = Berechtigungen
permissions-data-section =
    .heading = Berechtigungen und Daten
pane-permissions-data-title2 = Berechtigungen und Daten
    .title = Berechtigungen und Daten
notifications-section-header =
    .heading = Benachrichtigungen
notifications-entry-card-header =
    .description = Wählen Sie aus, welche Websites Benachrichtigungen senden können und wie diese angezeigt werden.
    .label = Benachrichtigungen
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } Website
           *[other] { $count } Websites
        }
    .label = Benachrichtigungs-Einstellungen verwalten
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Benachrichtigungs-Einstellungen für Websites verwalten
notifications-website-card-header =
    .description = Wählen Sie, wie Websites Benachrichtigungen senden dürfen.
    .label = Website-Benachrichtigungen
notifications-filter =
    .placeholder = Websites suchen
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Website
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Benachrichtigungen erlauben
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Websites
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Immer
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Erlauben
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Nie
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Keine Website-Benachrichtigungen hinzugefügt.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Keine Website-Benachrichtigungen entsprechen Ihrer Suche.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Um sicherzustellen, dass diese Änderung in Ihren Backups enthalten ist, öffnen Sie die einzelnen Profile und wählen Sie in den Einstellungen "Jetzt sichern".
nimbus-rollouts =
    .description = Änderungen werden per Fernzugriff angewendet.
    .label = { -brand-short-name } erlauben, Funktionen, Leistung und Stabilität zwischen den Updates zu verbessern
addon-recommendations3 =
    .description = Erhalten Sie Empfehlungen für Erweiterungen, um Ihr Surferlebnis zu verbessern.
    .label = Personalisierte Erweiterungsempfehlungen erlauben
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Datenübermittlung ist für diese Build-Konfiguration deaktiviert.
collection-backlogged-crash-reports2 =
    .label = Absturzberichte automatisch senden
    .accesskey = A
collection-backlogged-crash-reports-description = Dies hilft { -vendor-short-name } bei der Diagnose und Behebung von Problemen mit dem Browser. Die Berichte können persönliche oder sensible Daten enthalten.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Gleiche Einstellungen, neues Erscheinungsbild!
    .message = Wir haben diese Seite neu gestaltet, damit Sie sie leichter überfliegen und erkunden können. Ihre persönlichen Einstellungen haben sich nicht geändert, und alles ist weiterhin vorhanden. Tipp: Nutzen Sie die Suchfunktion, um direkt zu dem zu gelangen, was Sie suchen.
settings-redesign-promo-dismiss-button =
    .label = Verstanden
privacy-segmentation-section-header = Neue Funktionen, die Ihr Surfen verbessern
privacy-segmentation-section-description = Wenn wir Funktionen anbieten, die Ihre Daten verwenden, um Ihnen ein persönlicheres Erlebnis zu bieten:
privacy-segmentation-radio-off =
    .label = { -brand-product-name }-Empfehlungen verwenden
privacy-segmentation-radio-on =
    .label = Detaillierte Informationen anzeigen
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Wir bemühen uns, Ihnen die Wahl zu lassen und nur die Daten zu sammeln, die notwendig sind, um { -brand-product-name } für alle zu verbessern.
    .label = Datenerhebung durch { -brand-short-name } und deren Verwendung
    .searchkeywords = Telemetrie
data-collection-link = Datenschutzhinweis ansehen
data-collection-preferences-across-profiles =
    .message = Diese Einstellungen gelten für jedes { -brand-product-name }-Profil auf diesem Gerät.
data-collection-profiles-link = Alle Profile anzeigen
data-collection-health-report-telemetry-disabled =
    .message = Sie gestatten { -vendor-short-name } nicht mehr, technische und Interaktionsdaten zu erfassen. Alle bisherigen Daten werden innerhalb von 30 Tagen gelöscht.
data-collection-health-report =
    .description = Dies hilft uns, die Funktionen, Leistung und Stabilität von { -brand-product-name } zu verbessern.
    .label = Daten zu technischen Details und Interaktionen an { -vendor-short-name } senden
    .accesskey = r
data-collection-health-report-disabled =
    .description = Für diese Build-Konfiguration ist das Datenreporting deaktiviert.
    .label = Daten zu technischen Details und Interaktionen an { -vendor-short-name } senden
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } wählt nach dem Zufallsprinzip Benutzer aus, um Funktionen zu testen, was dazu beiträgt, die Qualität für alle zu verbessern.
    .label = { -brand-short-name } das Installieren und Durchführen von Studien erlauben
data-collection-studies-link =
    .label = { -brand-short-name }-Studien ansehen
data-collection-backlogged-crash-reports =
    .description = Dies hilft { -vendor-short-name } bei der Diagnose und Behebung von Problemen mit dem Browser. Die Berichte können persönliche oder sensible Daten enthalten.
    .label = Absturzberichte automatisch senden
    .accesskey = A
data-collection-usage-ping =
    .description = Dies hilft { -vendor-short-name }, aktive Benutzer zu schätzen.
    .label = Täglichen Nutzungs-Ping an { -vendor-short-name } senden
    .accesskey = N

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Sicherheit
browsing-protection-group2 =
    .description = Gefährliche Websites und Downloads können Ihre Daten und Ihr Gerät gefährden. { -brand-short-name } blockiert diese automatisch und warnt Sie vor riskanter oder unerwünschter Software.
    .label = Schutz vor betrügerischen Inhalten und gefährlicher Software
security-enable-safe-browsing =
    .label = Gefährliche und betrügerische Inhalte blockieren
    .accesskey = b
security-enable-safe-browsing-link = Weitere Informationen
security-safe-browsing-warning =
    .message = Das Deaktivieren dieser Option reduziert den Schutz vor Betrug, böswilligen Websites und gefährlichen Downloads.
security-block-downloads =
    .label = Gefährliche Downloads blockieren
    .accesskey = D
security-block-uncommon-software =
    .label = Vor unerwünschter und ungewöhnlicher Software warnen
    .accesskey = S

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = { -brand-short-name } erlauben, Stammzertifikaten von Drittanbietern, die Sie installieren, automatisch zu vertrauen
    .accesskey = t
certs-devices-enable-fips = FIPS aktivieren
space-alert-over-5gb-settings-button =
    .label = Einstellungen öffnen
    .accesskey = E
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } verfügt über nur noch wenig freien Speicherplatz.</strong> Website-Inhalte werden vielleicht nicht richtig angezeigt. Sie können gespeicherte Daten im Menü Einstellungen > Datenschutz & Sicherheit > Cookies und Website-Daten löschen.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } verfügt über nur noch wenig freien Speicherplatz.</strong> Website-Inhalte werden vielleicht nicht richtig angezeigt. Besuchen Sie "Weitere Informationen", um die Speichernutzung für ein besseres Weberlebnis zu optimieren.
certs-description3 =
    .description = Konfigurieren Sie die Zertifikate, die { -brand-short-name } zur Überprüfung sicherer Verbindungen verwendet.
    .label = Zertifikate
certs-view2 =
    .label = Zertifikate verwalten
    .accesskey = Z
certs-devices2 =
    .label = Kryptographie-Module verwalten
    .accesskey = K

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = So funktioniert Nur-HTTPS
httpsonly-radio-enabled =
    .label = Nur-HTTPS-Modus in allen Fenstern aktivieren
httpsonly-radio-enabled-pbm =
    .label = Nur-HTTPS-Modus nur in privaten Fenstern aktivieren
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } könnte trotzdem einige Verbindungen ändern
    .label = Nur-HTTPS-Modus nicht aktivieren
httpsonly-group =
    .description = Erlaubt nur sichere Verbindungen zu Websites. { -brand-short-name } wird nachfragen, bevor eine unsichere Verbindung hergestellt wird.
    .label = Nur-HTTPS-Modus
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS über HTTPS
dns-over-https-group2 =
    .description = Das Domain-Name-System über HTTPS (DoH) verschlüsselt Website-Abfragen, sodass es für Ihren Internetanbieter oder andere schwieriger ist, zu sehen, welche Websites Sie besuchen möchten.
    .label = DNS über HTTPS
preferences-doh-description2 = Domain Name System (DNS) über HTTPS sendet Ihre Anfrage für einen Domainnamen über eine verschlüsselte Verbindung, wodurch ein sicheres DNS bereitgestellt wird. Dies erschwert es anderen, zu sehen, welche Website Sie gerade besuchen.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Status: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Anbieter: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Ungültige Adresse
preferences-doh-steering-status = Lokaler Anbieter wird verwendet
preferences-doh-status-active = Aktiv
preferences-doh-status-disabled = Aus
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Nicht aktiv ({ $reason })
preferences-doh-group-message2 = DNS über HTTPS aktivieren mit:
preferences-doh-radio-group =
    .aria-label = DNS über HTTPS aktivieren mit:
preferences-doh-expand-section =
    .tooltiptext = Weitere Informationen
preferences-doh-setting-default =
    .label = Standardschutz
    .accesskey = S
preferences-doh-default-desc = { -brand-short-name } entscheidet, wann sicheres DNS verwendet wird, um Ihre Privatsphäre zu schützen.
preferences-doh-default-detailed-desc-1 = Sicheres DNS in Regionen verwenden, in denen es verfügbar ist
preferences-doh-default-detailed-desc-2 = Ihren Standard-DNS-Resolver verwenden, wenn ein Problem mit dem sicheren DNS-Anbieter auftritt
preferences-doh-default-detailed-desc-3 = Lokalen Anbieter verwenden, wenn möglich
preferences-doh-default-detailed-desc-4 = Deaktivieren, wenn VPN, Jugendschutz oder Unternehmensrichtlinien aktiv sind
preferences-doh-default-detailed-desc-5 = Deaktivieren, wenn ein Netzwerk { -brand-short-name } sagt, dass es kein sicheres DNS verwenden sollte
preferences-doh-setting-enabled =
    .label = Erhöhter Schutz
    .accesskey = E
preferences-doh-enabled-desc = Sie kontrollieren, wann Sie sicheres DNS verwenden, und wählen Ihren Anbieter.
preferences-doh-enabled-detailed-desc-1 = Ausgewählten Anbieter verwenden
preferences-doh-enabled-detailed-desc-2 = Ihren Standard-DNS-Resolver nur verwenden, wenn ein Problem mit sicherem DNS auftritt
preferences-doh-setting-strict =
    .label = Maximaler Schutz
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } wird immer sicheres DNS verwenden. Es wird eine Warnung zu einem Sicherheitsrisiko angezeigt, bevor wir Ihr System-DNS verwenden.
preferences-doh-strict-detailed-desc-1 = Nur ausgewählten Anbieter verwenden
preferences-doh-strict-detailed-desc-2 = Immer warnen, wenn kein sicheres DNS verfügbar ist
preferences-doh-strict-detailed-desc-3 = Wenn sicheres DNS nicht verfügbar ist, werden Websites nicht laden oder funktionieren nicht richtig
preferences-doh-setting-off =
    .label = Aus
    .accesskey = A
preferences-doh-off-desc = Ihren Standard-DNS-Resolver verwenden
preferences-doh-select-resolver = Anbieter auswählen:
preferences-doh-manage-exceptions =
    .label = Ausnahmen verwalten…
    .accesskey = u
preferences-doh-overview-default =
    .description = Verwenden Sie sicheres DNS in Regionen, in denen es verfügbar ist.
    .label = Standardschutz
preferences-doh-overview-custom =
    .description = Verwenden Sie immer sicheres DNS mit Kontrolle über Ihren Provider und Fallback-Verhalten.
    .label = Benutzerdefiniert
preferences-doh-overview-off =
    .description = Verwenden Sie Ihren Standard-DNS-Resolver.
    .label = Deaktiviert
preferences-doh-advanced-button =
    .label = Erweiterte Einstellungen
preferences-doh-advanced-section =
    .description = Das Domain-Name-System über HTTPS (DoH) verschlüsselt Website-Abfragen, sodass es für Ihren Internetanbieter oder andere schwieriger ist, zu sehen, welche Websites Sie besuchen möchten.
    .label = Erweiterte Einstellungen
preferences-doh-manage-exceptions2 =
    .label = Ausnahmen verwalten
    .accesskey = u
preferences-doh-radio-default =
    .description = Sicheres DNS in Regionen verwenden, in denen es verfügbar ist
    .label = Standard
preferences-doh-radio-custom =
    .description = Immer sicheres DNS verwenden mit Kontrolle über den Anbieter und das Rückfall-Verhalten
    .label = Benutzerdefiniert
preferences-doh-radio-off =
    .description = Ihren Standard-DNS-Resolver verwenden
    .label = Aus
preferences-doh-fallback-label =
    .label = Immer warnen, wenn kein sicheres DNS verfügbar ist
preferences-doh-status-item-off =
    .message = DNS über HTTPS ist deaktiviert
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS über HTTPS funktioniert nicht, weil wir beim Verwenden des Anbieters { $name } auf einen Fehler ({ $reason }) gestoßen sind.
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS über HTTPS funktioniert nicht, weil wir eine ungültige URL erhalten haben ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS über HTTPS verwendet den Anbieter { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS über HTTPS funktioniert nicht, weil wir beim Verwenden des lokalen Anbieters { $name } auf einen Fehler ({ $reason }) gestoßen sind.
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS über HTTPS verwendet den lokalen Anbieter { $name }
preferences-doh-select-resolver-label =
    .label = Anbieter auswählen:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Verwenden Sie diesen Anbieter für die Auflösung von DNS über HTTPS.
preferences-doh-custom-provider-label =
    .aria-label = Geben Sie eine benutzerdefinierte Anbieter-URL ein
preferences-doh-header2 =
    .heading = DNS über HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Verbindungs- und Softwaresicherheit
preferences-connection-link-section =
    .description = Erfahren Sie, wie Verbindungen sicher bleiben, schädliche Software blockiert wird und Websites überprüft werden.
    .label = Verbindungs- und Softwaresicherheit
preferences-connection-link-button =
    .label = Erweiterte Einstellungen

## The following strings are used in the Download section of settings

desktop-folder-name = Desktop
downloads-folder-name = Downloads

## Appearance page

preferences-appearance-header =
    .heading = Erscheinungsbild
browser-theme-group =
    .description = Passen Sie { -brand-short-name } Ihren Wünschen an. Die Themenfarben gelten für Symbolleisten, Menüs und Nachrichten.
    .label = Browser-Theme
browser-theme-manage-link =
    .label = { -brand-short-name }-Themes verwalten
appearance-window-density-group =
    .description = Passen Sie den Abstand rund um Fensterelemente wie Symbolleiste, Registerkarten und Seitenleiste an.
    .label = Dichte des Fensters
appearance-window-density-radio-group =
    .aria-label = Dichte des Fensters
appearance-window-density-automatic =
    .description = Standard-, Kompakt- oder Touchmodus wird automatisch angewendet
    .label = Automatisch (Standard)
appearance-window-density-automatic-no-touch =
    .description = Standard- oder Kompaktmodus wird automatisch angewendet
    .label = Automatisch (Standard)
appearance-window-density-standard =
    .description = Ausgewogener Abstand für die meisten Bildschirme
    .label = Standard
appearance-window-density-auto-touch-mode =
    .label = Verwenden Sie Touch für den Tablet-Modus
appearance-window-density-compact =
    .description = Reduzierter Abstand für kleinere Bildschirme
    .label = Kompakt
appearance-window-density-touch =
    .description = Größere Fensterelemente und Klickziele, optimiert für Touchscreens
    .label = Touch
related-settings-group =
    .label = Verwandte Einstellungen
related-settings-accessibility-link =
    .label = Zoom- und Schriftart-Einstellungen in Barrierefreiheit anpassen
related-settings-home-link =
    .label = { -firefox-home-brand-name } anpassen
related-settings-tabs-browsing-link =
    .label = Browser-Layout anpassen

## AI controls page

preferences-ai-controls-description = Sie haben in { -brand-short-name } immer die Wahl, ob Sie durch KI verbesserte Funktionen nutzen möchten. Weitere Einstellungen folgen bald.
preferences-ai-controls-block-ai-label = KI-Verbesserungen blockieren
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Das Blockieren bedeutet, dass Sie in { -brand-short-name } keine neuen oder aktuellen KI-Verbesserungen sehen, oder Pop-ups darüber. <a data-l10n-name="link">Erfahren Sie weitere Details</a> darüber, was enthalten ist und wie Sie traditionelle Machine-Learning-Funktionen steuern, wie Suchvorschläge und -empfehlungen.
preferences-ai-controls-blocked-message =
    .message = Neue und aktuelle KI-Verbesserungen werden standardmäßig blockiert. Verwenden Sie die folgenden Einstellungen, um die Blockierung einer bestimmten Funktion aufzuheben.
preferences-ai-controls-on-device-group =
    .description = Diese Funktionen verwenden kleine KI-Modelle, die auf ihr Gerät heruntergeladen werden. Dieser Ansatz hilft dabei, Ihre Privatsphäre zu schützen.
    .label = Geräteinterne KI
preferences-ai-controls-translations-control =
    .description = Stöbern Sie nahtlos in Ihrer bevorzugten Sprache im Internet.
    .label = Übersetzungen
preferences-ai-controls-translations-more-link = Weitere Übersetzungseinstellungen
preferences-ai-controls-pdfjs-control =
    .description = Wenn Sie Bilder zu PDFs hinzufügen, werden Beschreibungen hinzugefügt, um sie zugänglich zu machen.
    .label = Alternativ-Text der Grafik im { -brand-short-name }-PDF-Betrachter
preferences-ai-controls-tab-group-suggestions-control =
    .description = Erhalten Sie Vorschläge zur Benennung und Organisation Ihrer Tabs.
    .label = Vorschläge für Tab-Gruppen
preferences-ai-controls-key-points-control =
    .description = Sehen Sie eine Zusammenfassung, bevor Sie einen Link öffnen.
    .label = Wichtige Punkte in der Link-Vorschau
preferences-ai-controls-speech-recognition-control =
    .description = Gesprochenes lokal transkribieren.
    .label = Spracherkennung
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Behalten Sie einen Chatbot beim Surfen im Blick. Wählen Sie aus mehreren Anbietern und wechseln Sie jederzeit.
    .label = KI-Chatbot-Anbieter in der Sidebar
preferences-ai-controls-sidebar-chatbot-group =
    .description = Behalten Sie einen Chatbot in Reichweite, während Sie surfen. Wählen Sie zwischen Anthropic Claude, ChatGPT, Copilot, Google Gemini und Le Chat Mistral.
    .label = KI-Chatbot-Anbieter in der Sidebar
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot in der Sidebar
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Verfügbar
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Aktiviert
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Blockiert
preferences-ai-controls-state-description-before = Bedeutung der Optionen:
preferences-ai-controls-state-description-available = <strong>Verfügbar:</strong> Sie sehen die Funktion und können sie verwenden.
preferences-ai-controls-state-description-enabled = <strong>Aktiviert:</strong> Sie haben der Verwendung der Funktion zugestimmt.
preferences-ai-controls-state-description-blocked = <strong>Blockiert:</strong> Sie werden die Funktion nicht sehen und können sie nicht verwenden. Für die geräteinterne KI werden alle bereits heruntergeladenen Modelle entfernt.
preferences-ai-controls-block-confirmation-heading = KI-Verbesserungen blockieren?
preferences-ai-controls-block-confirmation-description = Sie werden keine neuen oder aktuellen KI-Verbesserungen in { -brand-short-name } sehen, oder Pop-ups darüber. Danach können Sie alles entsperren, was Sie weiter verwenden möchten.
preferences-ai-controls-block-confirmation-features-start = Was wird blockiert:
preferences-ai-controls-block-confirmation-translations = Übersetzungen
preferences-ai-controls-block-confirmation-pdfjs = Alternativ-Text der Grafik im { -brand-short-name }-PDF-Betrachter
preferences-ai-controls-block-confirmation-tab-group-suggestions = Vorschläge für Tab-Gruppen
preferences-ai-controls-block-confirmation-key-points = Wichtige Punkte in der Link-Vorschau
preferences-ai-controls-block-confirmation-sidebar-chatbot = Chatbot-Anbieter in der Sidebar
preferences-ai-controls-block-confirmation-speech-recognition = Spracherkennung
preferences-ai-controls-block-confirmation-features-after = Das Blockieren betrifft auch Erweiterungen, die KI von { -brand-short-name } verwenden.
preferences-ai-controls-block-confirmation-cancel =
    .label = Abbrechen
preferences-ai-controls-block-confirmation-confirm =
    .label = Blockieren
preferences-ai-controls-header3 =
    .heading = KI-Einstellungen

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } ist wachsam
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } empfiehlt einige Sicherheitsverbesserungen
security-privacy-status-ok-label = Verbesserter Tracking-Schutz ist aktiviert
security-privacy-status-problem-label = Wir haben Einstellungen gefunden, die sich auf Ihren Schutz auswirken
security-privacy-status-problem-helper-label = Probleme anzeigen
security-privacy-status-pending-trackers-label = Nachschlagen, wie viele Elemente zur Aktivitätenverfolgung { -brand-short-name } im letzten Monat blockiert hat
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } Tracker im letzten Monat blockiert
       *[other] { $trackerCount } Tracker im letzten Monat blockiert
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Sie haben <a data-l10n-name="strict-tracking-protection">Strengen Schutz</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Sie haben einen <a data-l10n-name="custom-tracking-protection">benutzerdefinierten Schutz</a>
security-privacy-status-up-to-date-label = Sie haben die neueste und sicherste Version von { -brand-short-name }
security-privacy-status-update-needed-label = Eine neue Version von { -brand-short-name } ist verfügbar.
security-privacy-status-update-error-label = { -brand-short-name } hat Probleme bei der Aktualisierung
security-privacy-status-update-checking-label = { -brand-short-name } sucht nach Updates
security-privacy-status-update-needed-description = Aktualisieren Sie, um die neuesten Geschwindigkeits-, Stabilitäts- und Sicherheits-Updates zu erhalten.
security-privacy-status-update-button-label =
    .label = { -brand-short-name } aktualisieren
security-privacy-image-warning =
    .alt = Ein Schild mit einem Ausrufezeichen, das Besorgnis über Ihre Sicherheitswarnungen ausdrückt
security-privacy-image-ok =
    .alt = Ein Schild mit einem Häkchen, das anzeigt, dass Sie keine offenen Sicherheitsprobleme haben
security-privacy-issue-card =
    .heading = Sicherheitswarnungen
issue-card-reset-button =
    .label = Zurücksetzen
issue-card-dismiss-button =
    .aria-label = Verwerfen
    .tooltiptext = Verwerfen

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Websites verwenden Tracker, um Sie online zu verfolgen und Ihnen gruselige Werbung anzuzeigen. { -brand-short-name } schützt Sie beim Surfen und blockiert Tracker automatisch, sodass Sie die Kontrolle über Ihre digitalen Spuren behalten.
    .label = Verbesserter Tracking-Schutz
preferences-etp-level-radio-group =
    .aria-label = Verbesserter Tracking-Schutz
preferences-etp-level-standard =
    .description = Starke, zuverlässige Schutzmaßnahmen, die mit den meisten Websites reibungslos funktionieren.
    .label = Standard (Voreinstellung)
preferences-etp-level-strict =
    .description = Stärkere Schutzmaßnahmen, die mehr Tracker blockieren, aber dazu führen können, dass einige Websites nicht mehr funktionieren.
    .label = Streng
preferences-etp-level-custom =
    .description = Wählen Sie aus, welche Schutzfunktionen Sie aktivieren oder deaktivieren möchten.
    .label = Benutzerdefiniert
preferences-etp-status-advanced-button =
    .label = Erweiterte Einstellungen
preferences-etp-tracker-count-enabled =
    .label = Blockierte Tracker in der Adressleiste anzeigen
preferences-etp-status-protections-dashboard-link =
    .description = Sehen Sie, wie viele hinterhältige Tracker { -brand-short-name } für Sie blockiert hat, darunter Social-Media-Tracker, Fingerprinter und Cryptominer.
    .label = Sehen Sie sich Ihre personalisierte Schutz-Übersicht an
preferences-etp-header =
    .heading = Verbesserter Tracking-Schutz
preferences-etp-advanced-settings-group =
    .description = Websites verwenden Tracker, um Sie online zu verfolgen und Ihnen gruselige Werbung anzuzeigen. { -brand-short-name } schützt Sie beim Surfen und blockiert die meisten Tracker automatisch, sodass Sie die Kontrolle über Ihre digitalen Spuren behalten.
    .label = Erweiterte Einstellungen
preferences-etp-customize-button =
    .label = Tracking-Schutz anpassen
preferences-etp-reload-tabs-hint =
    .message = Laden Sie Ihre Tabs neu, um die Änderungen zu übernehmen.
preferences-etp-reload-tabs-hint-button =
    .label = Alle Tabs neu laden
preferences-etp-rfp-warning-message =
    .message = Sie verwenden "Resist Fingerprinting" (RFP), was einige der Einstellungen von { -brand-short-name } zum Schutz vor Identifizierung (Fingerprinter) ersetzt. Dies kann dazu führen, dass einige Websites nicht funktionieren.
preferences-etp-level-warning-message =
    .heading = Achtung! Einige Websites funktionieren möglicherweise nicht wie erwartet.
    .message = Einige Websites integrieren Tracker in ihre Funktionen oder Inhalte. Wenn { -brand-short-name } diese blockiert, sieht die Website fehlerhaft aus. Versuchen Sie, "Website-Problem beheben" oder den Tracking-Schutz für diese Website zu deaktivieren.
preferences-etp-manage-exceptions-button =
    .description = Verwalten Sie die Websites, auf denen der erweiterte Tracking-Schutz deaktiviert ist.
    .label = Ausnahmen verwalten
preferences-etp-customize-header =
    .heading = Anpassen des Tracking-Schutzes
preferences-etp-reset =
    .description = Stellen Sie die Einstellungen auf eine voreingestellte Schutzstufe zurück.
    .label = Anpassungen zurücksetzen
preferences-etp-reset-standard-button =
    .label = Auf Standard zurücksetzen
preferences-etp-reset-strict-button =
    .label = Auf Streng zurücksetzen
preferences-etp-custom-control-group =
    .description = Wählen Sie aus, welche Schutzfunktionen Sie aktivieren oder deaktivieren möchten.
    .label = Tracking-Schutz
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Alle Cookies erlauben
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Cookies zur seitenübergreifenden Aktivitätenverfolgung blockieren
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Seitenübergreifende Cookies blockieren
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Seitenübergreifende Cookies isolieren
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Cookies von nicht besuchten Websites blockieren
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Alle seitenübergreifenden Cookies blockieren (einige Websites funktionieren dann eventuell nicht mehr)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Alle Cookies blockieren (stört die Funktionsweise von Websites)
preferences-etp-custom-tracking-protection-enabled =
    .label = Inhalte zur Aktivitätenverfolgung
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Inhalte zur Aktivitätenverfolgung
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Heimliche Digitalwährungsberechner (Krypto-Miner)
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Bekannte Identifizierer (Fingerprinter)
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Vermutete Identifizierer (Fingerprinter)
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Vermutete Identifizierer (Fingerprinter)

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Dadurch können einige Tracker Sie möglicherweise auch ohne Cookies verfolgen.
    .label = Bekannte Fingerprinter werden nicht blockiert
security-privacy-issue-warning-third-party-cookies =
    .description = Cookies von Drittanbietern werden verwendet, um Sie über verschiedene Websites hinweg zu verfolgen.
    .label = Cookies von Drittanbietern sind aktiviert
security-privacy-issue-warning-password-manager =
    .description = Passwortmanager helfen Ihnen dabei, sichere Passwörter für Ihre Konten zu speichern.
    .label = Passwort-Verwaltung ist deaktiviert
security-privacy-issue-warning-popup-blocker =
    .description = Popups sind störend und potenziell schädlich.
    .label = Pop-up-Blocker ist deaktiviert
security-privacy-issue-warning-extension-install =
    .description = Websites können Erweiterungen für { -brand-short-name } ohne Rückfrage installieren.
    .label = Websites können Erweiterungen installieren
security-privacy-issue-warning-safe-browsing =
    .description = Das Risiko, Opfer von Betrug und Malware auf Websites zu werden, ist erhöht.
    .label = Gefährliche und betrügerische Inhalte werden nicht blockiert
security-privacy-issue-warning-doh2 =
    .description = DNS über HTTPS hilft vor Ihrem Netzwerkanbieter zu verbergen, welche Websites Sie besuchen werden.
    .label = DNS über HTTPS ist deaktiviert
security-privacy-issue-warning-ech2 =
    .description = Verschlüsselter Client Hello hilft vor Ihrem Netzwerkanbieter zu verbergen, welche Websites Sie besuchen werden.
    .label = Verschlüsselter Client Hello ist deaktiviert
security-privacy-issue-warning-doh =
    .description = DNS über HTTPS verbirgt vor Ihrem Netzbetreiber, welche Websites Sie besuchen.
    .label = DNS über HTTPS ist deaktiviert
security-privacy-issue-warning-ech =
    .description = Verschlüsselter Client Hello verbirgt vor Ihrem Netzbetreiber, welche Websites Sie besuchen.
    .label = Verschlüsselter Client Hello ist deaktiviert
security-privacy-issue-warning-proxy-autodetection =
    .description = Die automatische Proxy-Konfiguration könnte es nicht vertrauenswürdigen Netzwerken ermöglichen, Ihre Aktivitäten zu überwachen.
    .label = Proxy-Auto-Konfiguration ist aktiviert

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Laden Sie jemanden ein, den Browser zu wählen, bei dem der Datenschutz an erster Stelle steht.
    .label = { -brand-product-name } empfehlen
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = { -brand-product-name } empfehlen


pane-vorbit-title = vOrbit-lite
vorbit-header = vOrbit-lite-Einstellungen
category-vorbit =
    .tooltiptext = Änderungen in about:config, logisch gruppiert und einfach zugänglich
vorbit-security-heading = Sicherheit
vorbit-sync-checkbox =
    .label = Firefox Sync aktivieren
vorbit-privacy-heading = Privatsphäre
vorbit-extension-update-description = Browsererweiterungen auf dem neuesten Stand halten. Für Ihre Sicherheit empfohlen.
vorbit-warning-title = Vorsicht!
vorbit-warning-description = Wir wählen unsere Voreinstellungen mit dem Fokus auf Datenschutz und Sicherheit. Wenn Sie diese Einstellungen ändern, lesen Sie die Beschreibungen, um die Auswirkungen dieser Änderungen zu verstehen.
vorbit-webgl-checkbox =
    .label = WebGL mit Erlaubnis je Seite aktivieren
vorbit-general-heading = Browserverhalten
vorbit-extension-update-checkbox =
    .label = Erweiterungen automatisch aktualisieren
vorbit-autocopy-checkbox =
    .label = Einfügen mit mittlerer Maustaste aktivieren
vorbit-goog-safe-download-checkbox =
    .label = Downloads scannen
vorbit-network-heading = Netzwerk
vorbit-ipv6-checkbox =
    .label = IPv6 aktivieren
vorbit-xorigin-ref-checkbox =
    .label = Referrer aus anderen Domänen einschränken
vorbit-broken-heading = Fingerprinting
vorbit-rfp-checkbox =
    .label = ResistFingerprinting aktivieren
vorbit-styling-checkbox =
    .label = Änderungen an userChrome.css zulassen
vorbit-autocopy-description = Markieren Sie Text, um ihn zu kopieren, und fügen Sie ihn dann mit der mittleren Maustaste ein.
vorbit-extension-update-warning1 = Wenn Sie den Code Ihrer Erweiterungen nicht vor jedem Update überprüfen, sollten Sie diese Option aktivieren.
vorbit-ocsp-description = Verhindert die Verbindung zu einer Website, wenn die OCSP-Prüfung nicht durchgeführt werden kann.
vorbit-goog-safe-checkbox =
    .label = Google Safe Browsing aktivieren
vorbit-ipv6-description = Erlauben Sie { -brand-short-name }, sich über IPv6 zu verbinden.
vorbit-ipv6-warning1 = Statt IPv6 im Browser zu blockieren, empfehlen wir, die IPv6-Datenschutzerweiterung in Ihrem Betriebssystem zu aktivieren.
vorbit-ocsp-warning1 = Dies erhöht die Sicherheit, führt jedoch zu Störungen, wenn ein OCSP-Server ausfällt.
vorbit-sync-description = Synchronisieren Sie Ihre Daten mit anderen Browsern. Erfordert Neustart.
vorbit-styling-description = Aktivieren Sie diese Option, wenn Sie die Benutzeroberfläche mit einem manuell geladenen Design anpassen möchten.
vorbit-styling-warning1 = Stellen Sie sicher, dass Sie dem Anbieter des Designs vertrauen.
vorbit-rfp-description = ResistFingerprinting ist das beste Anti-Fingerprinting-Tool seiner Art.
vorbit-webgl-description = Dies aktiviert WebGL mit einer Erlaubnisabfrage je Seite.
vorbit-footer = Nützliche Links
vorbit-config-link = Alle erweiterten Einstellungen (about:config)
vorbit-sync-warning1 = Firefox Sync verschlüsselt Daten lokal, bevor sie zum Server übertragen werden.
vorbit-letterboxing-checkbox =
    .label = Letterboxing aktivieren
vorbit-ocsp-checkbox =
    .label = OCSP-Hard-Fail erzwingen
vorbit-xorigin-ref-description = Referrer nur bei gleicher Herkunft senden.
vorbit-xorigin-ref-warning1 = Dies könnte Fehler verursachen. Außerdem werden selbst gesendete Referrer weiterhin gekürzt.
vorbit-webgl-warning1 = Wenn eine Seite versucht, einen WebGL-Kontext zu erstellen, werden Sie zuerst um Erlaubnis gefragt.
vorbit-rfp-warning1 = Wenn Sie ResistFingerprinting deaktivieren müssen, ziehen Sie in Betracht, eine Erweiterung wie Canvas Blocker zu verwenden.
vorbit-auto-decline-canvas-description = Automatisch den Canvas-Zugriff gegenüber Webseiten verweigern, ohne den Benutzer zu fragen.
vorbit-auto-decline-canvas-warning1 = Es ist weiterhin möglich, den Canvas-Zugriff aus der URL-Leiste heraus zu erlauben.
vorbit-letterboxing-description = Letterboxing fügt dem Fenster Umrandungen hinzu, um nur eine begrenzte Anzahl gerundeter Auflösungen zurückzugeben.
vorbit-goog-safe-description = Wenn Sie um Malware und Phishing besorgt sind, ziehen Sie in Betracht, dies zu aktivieren.
vorbit-goog-safe-warning1 = Deaktiviert aufgrund von Zensur-Bedenken, aber für weniger erfahrene Anwender empfohlen. Alle Überprüfungen finden lokal statt.
vorbit-goog-safe-download-description = Erlauben Sie Safe Browsing, Ihre Downloads zu scannen, um verdächtige Dateien zu finden.
vorbit-goog-safe-download-warning1 = Alle Überprüfungen finden lokal statt.
vorbit-open-profile = Benutzerprofilverzeichnis öffnen
content-blocking-section-top-level-description = vOrbit-lite unterstützt erweiterten Trackingschutz im strengen Modus und hat diesen standardmäßig aktiviert. Dies ist eine der wichtigsten Einstellungen im Browser, da sie eine Aufteilung nach Status, strenge Sperrlisten und andere nützliche Datenschutzfunktionen bietet. Wir empfehlen nicht, einen anderen Modus auszuwählen.
vorbit-webgl-prompt-checkbox =
    .label = Das WebGL-Pop-up für einzelne Websites verbergen
vorbit-webgl-prompt-description = Dies verbirgt das Pop-up, das erschient, wenn eine Website versucht, einen WebGL-Kontext zu erstellen. Sie können diese Abfrage immer noch manuell auslösen, wenn Sie auf das Symbol in der Suchleiste klicken.
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = Browserverhalten
vorbit-network-heading2 =
    .label = Netzwerk
vorbit-ipv6-checkbox2 =
    .label = IPv6 aktivieren
    .description = Verbindung von { -brand-short-name } über IPv6 erlauben.
vorbit-privacy-heading2 =
    .label = Datenschutz
vorbit-broken-heading2 =
    .label = Fingerprinting
vorbit-security-heading2 =
    .label = Sicherheit
vorbit-extension-update-checkbox2 =
    .label = Erweiterungen automatisch aktualisieren
    .description = Halten Sie Ihre Erweiterungen ohne manuellen Eingriff auf dem neuesten Stand. Eine gute Wahl für Ihre Sicherheit.
vorbit-autocopy-checkbox2 =
    .label = Einfügen per Mittelklick aktivieren
    .description = Markieren Sie einen Text, um ihn zu kopieren und fügen Sie ihn dann mit einem Mittelklick ein.
vorbit-sync-checkbox2 =
    .label = Firefox Sync aktivieren
    .description = Synchronisieren Sie Ihre Daten mit anderen Browsern. Erfordert einen Neustart.
vorbit-styling-checkbox2 =
    .label = Anpassung von userChrome.css zulassen
    .description = Aktivieren Sie diese Option, wenn Sie die Benutzeroberfläche mit einem manuell geladenen Design anpassen möchten.
vorbit-xorigin-ref-checkbox2 =
    .label = Ursprungsübergreifende Referrer einschränken
    .description = Referrer nur bei gleicher Herkunft senden.
vorbit-webgl-checkbox2 =
    .label = WebGL immer zulassen
    .description = Dadurch wird WebGL immer zugelassen, ohne dass eine Berechtigung erforderlich ist.
vorbit-webgl-prompt-checkbox2 =
    .label = WebGL-Pop-up pro Website verbergen
    .description = Dadurch wird das Pop-up-Fenster ausgeblendet, das erscheint, wenn eine Website versucht, einen WebGL-Kontext zu erstellen. Sie können das Fenster weiterhin manuell aufrufen, indem Sie auf das Symbol in der Suchleiste klicken.
vorbit-rfp-checkbox2 =
    .label = Fingerprinting-Schutz aktivieren
    .description = Aktiviert alle verfügbaren Schutzmaßnahmen gegen Fingerprinting. Dies kann jedoch dazu führen, dass einige Websites nicht korrekt funktionieren.
vorbit-letterboxing-checkbox2 =
    .label = Letterboxing aktivieren
    .description = Beim Letterboxing werden um die Fenster herum Ränder eingefügt, um eine begrenzte Anzahl abgerundeter Auflösungen zurückzugeben.
