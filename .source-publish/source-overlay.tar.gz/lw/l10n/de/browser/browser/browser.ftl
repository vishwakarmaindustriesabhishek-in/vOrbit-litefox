# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } Privater Modus
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Schnelles und privates Surfen
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } – Privater Modus
       *[other] { -brand-full-name } Privater Modus
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Privater Modus
popups-infobar-dont-show-message2 =
    .label = Diese Nachricht nicht anzeigen, wenn Pop-ups oder Drittanbieter-Weiterleitungen blockiert sind
    .accesskey = D
edit-popup-settings2 =
    .label = Weiterleitungseinstellungen für Pop-ups und Drittanbieter verwalten…
    .accesskey = W
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Website-Informationen anzeigen
            [1] Website-Informationen anzeigen ({ $count } Tracker blockiert)
            [one] Website-Informationen anzeigen ({ $count } Tracker blockiert)
           *[other] Website-Informationen anzeigen ({ $count } Tracker blockiert)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } Link
           *[other] { $count } Links
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Nachrichten und mehr…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Nachrichten, Mail und mehr…
    .accesskey = N
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Teilen …
    .accesskey = T
urlbar-identity-button =
    .aria-label = Seiteninformationen anzeigen

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Ansicht über eine Installation öffnen
urlbar-web-notification-anchor =
    .tooltiptext = Ändern, ob diese Website Benachrichtigungen senden darf
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI-Ansicht öffnen
urlbar-serial-notification-anchor =
    .tooltiptext = Ansicht für serielle Schnittstellen öffnen
urlbar-eme-notification-anchor =
    .tooltiptext = Verwendung von DRM-geschützter Software verwalten
urlbar-web-authn-anchor =
    .tooltiptext = Ansicht für Web-Authentifizierung öffnen
urlbar-canvas-notification-anchor =
    .tooltiptext = Erlaubnis zur Abfrage von Canvas-Daten verwalten
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Verwalten des Zugriffs auf Ihr Mikrofon durch diese Website
urlbar-default-notification-anchor =
    .tooltiptext = Ansicht mit Benachrichtigung öffnen
urlbar-geolocation-notification-anchor =
    .tooltiptext = Ansicht mit Standortanfrage öffnen
urlbar-localhost-notification-anchor =
    .tooltiptext = Zugriff auf lokale Geräte für diese Website verwalten
urlbar-local-network-notification-anchor =
    .tooltiptext = Verwalten des Zugriffs auf Ihr lokales Netzwerk durch diese Website
urlbar-xr-notification-anchor =
    .tooltiptext = Ansicht für VR-Zugriff (Virtuelle Realität) öffnen
urlbar-storage-access-anchor =
    .tooltiptext = Ansicht für während des Surfens berechtigte Aktivitäten öffnen
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Verwalten des Zugriffs auf Ihre Fenster oder Bildschirme durch diese Website
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Ansicht über Offline-Speicher öffnen
urlbar-password-notification-anchor =
    .tooltiptext = Ansicht über gespeicherte Zugangsdaten öffnen
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Verwalten des Zugriffs auf Ihre Kamera und/oder Ihr Mikrofon durch diese Website
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Verwalten des Zugriffs auf andere Lautsprecher durch diese Website
urlbar-autoplay-notification-anchor =
    .tooltiptext = Ansicht für automatische Wiedergabe öffnen
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Daten im dauerhaften Speicher speichern
urlbar-addons-notification-anchor =
    .tooltiptext = Ansicht mit Anfrage zur Installation eines Add-ons öffnen
urlbar-search-tips-confirm = OK
urlbar-search-tips-confirm-short = OK
urlbar-result-menu-button =
    .title = Menü öffnen
urlbar-result-menu-button-feedback = Feedback
    .title = Menü öffnen
urlbar-result-menu-learn-more2 = Weitere Informationen
    .accesskey = W
urlbar-result-menu-remove-from-history2 = Aus Chronik entfernen
    .accesskey = e
urlbar-result-menu-tip-get-help2 = Hilfe erhalten
    .accesskey = H
urlbar-result-menu-dismiss-suggestion2 = Diesen Vorschlag verwerfen
    .accesskey = v
urlbar-result-menu-remove-top-site = Diese wichtige Seite entfernen
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest2 = { -firefox-suggest-brand-name } verwalten
    .accesskey = v
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Ungenauen Standort melden
    .accesskey = U
urlbar-result-menu-show-less-frequently3 = Seltener anzeigen
    .accesskey = S
urlbar-result-menu-dont-show-weather-suggestions3 = Keine Wettervorschläge anzeigen
    .accesskey = K
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Ungenauen Standort melden
urlbar-result-menu-show-less-frequently2 = Seltener anzeigen
urlbar-result-menu-dont-show-weather-suggestions2 = Keine Wettervorschläge anzeigen
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Diesen Vorschlag verwerfen
    .accesskey = v
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Aus Chronik entfernen
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = Weitere Informationen
    .accesskey = W
urlbar-result-menu-remove-from-history =
    .label = Aus Chronik entfernen
    .accesskey = e
urlbar-result-menu-tip-get-help =
    .label = Hilfe erhalten
    .accesskey = H
urlbar-result-menu-dismiss-suggestion =
    .label = Diesen Vorschlag verwerfen
    .accesskey = v
urlbar-result-menu-manage-firefox-suggest =
    .label = { -firefox-suggest-brand-name } verwalten
    .accesskey = v
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Ungenauen Standort melden
urlbar-result-menu-show-less-frequently =
    .label = Seltener anzeigen
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Keine Wettervorschläge anzeigen
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Menü öffnen
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Danke für Ihre Rückmeldung!
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Danke für Ihr Feedback. Wettervorschläge werden nicht mehr angezeigt.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Weniger tippen, mehr finden: Direkt mit { $engineName } von der Adressleiste aus suchen.
urlbar-search-tips-redirect-2 = Starten Sie Ihre Suche in der Adressleiste, um Suchvorschläge von { $engineName } sowie Ihre Browser-Chronik angezeigt zu bekommen.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Wählen Sie diese Verknüpfung, um schneller Suchergebnisse zu erhalten.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Lesezeichen
urlbar-search-mode-tabs = Tabs
urlbar-search-mode-history = Chronik
urlbar-search-mode-actions = Aktionen

##

urlbar-geolocation-blocked =
    .tooltiptext = Sie haben den Zugriff auf Ihren Standort durch diese Website blockiert.
urlbar-localhost-blocked =
    .tooltiptext = Sie haben Verbindungen zu lokalen Geräten für diese Webseite blockiert.
urlbar-local-network-blocked =
    .tooltiptext = Sie haben Verbindungen zum lokalen Netzwerk für diese Webseite blockiert.
urlbar-xr-blocked =
    .tooltiptext = Sie haben den Zugriff auf VR-Geräte durch diese Website blockiert.
urlbar-web-notifications-blocked =
    .tooltiptext = Sie haben das Anzeigen von Benachrichtigungen durch diese Website blockiert.
urlbar-camera-blocked =
    .tooltiptext = Sie haben den Zugriff auf Ihre Kamera durch diese Website blockiert.
urlbar-microphone-blocked =
    .tooltiptext = Sie haben den Zugriff auf Ihr Mikrofon durch diese Website blockiert.
urlbar-screen-blocked =
    .tooltiptext = Sie haben den Zugriff auf Ihren Bildschirm durch diese Website blockiert.
urlbar-persistent-storage-blocked =
    .tooltiptext = Sie haben die Verwendung von dauerhaftem Speicher für diese Website blockiert.
urlbar-popup-blocked2 =
    .tooltiptext = Sie haben Pop-ups und Drittanbieter-Weiterleitungen für diese Webseite blockiert.
urlbar-autoplay-media-blocked =
    .tooltiptext = Sie haben die automatische Wiedergabe von Medien mit Ton für diese Website blockiert.
urlbar-canvas-blocked =
    .tooltiptext = Sie haben das Abfragen von Canvas-Daten durch diese Website blockiert.
urlbar-midi-blocked =
    .tooltiptext = Sie haben den Zugriff auf MIDI durch diese Website blockiert.
urlbar-serial-blocked =
    .tooltiptext = Sie haben den Zugriff auf die seriellen Ports durch diese Website blockiert.
urlbar-install-blocked =
    .tooltiptext = Sie haben die Installation von Erweiterungen von dieser Website blockiert.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Dieses Lesezeichen bearbeiten ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Lesezeichen für diese Seite setzen ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Geteilte Ansicht
    .tooltiptext = Geteilte Ansicht

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Einfügen & Los
    .accesskey = E
urlbar-menuitem-paste-and-search =
    .label = Einfügen und Suchen
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = Such-Chronik löschen
    .accesskey = S

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Erweiterung verwalten…
    .accesskey = w
page-action-remove-extension2 =
    .label = Erweiterung entfernen
    .accesskey = n

## Auto-hide Context Menu

full-screen-autohide =
    .label = Symbolleisten ausblenden
    .accesskey = a
full-screen-exit =
    .label = Vollbild beenden
    .accesskey = V

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Einmalig suchen mit:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Sucheinstellungen ändern
search-one-offs-context-open-new-tab =
    .label = In neuem Tab suchen
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = Als Standardsuchmaschine festlegen
    .accesskey = S
search-one-offs-context-set-as-default-private =
    .label = Als Standardsuchmaschine für private Fenster festlegen
    .accesskey = p
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Suchmaschine "{ $engineName }" hinzufügen
    .label = "{ $engineName }" hinzufügen
    .tooltiptext = Suchmaschine "{ $engineName }" hinzufügen
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Suchmaschine hinzufügen
    .accesskey = S
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Suchmaschine hinzufügen

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Lesezeichen ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Tabs ({ $restrict })
search-one-offs-history =
    .tooltiptext = Chronik ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Aktionen ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Add-ons anzeigen
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = Erweiterungen, Themes, Add-ons
# Opens preferences page at AI controls
quickactions-manageai = KI-Einstellungen verwalten
quickactions-cmd-manageai = KI deaktivieren, ki deaktivieren, ki verwalten, KI verwalten
# Opens the bookmarks library window
quickactions-bookmarks2 = Lesezeichen verwalten
quickactions-cmd-bookmarks = Lesezeichen
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Neueste Chronik löschen
quickactions-cmd-clearrecenthistory2 = Cookies, Cookies löschen, Cache, Cache löschen, Surf-Daten, Surf-Daten löschen, Chronik, Neueste Chronik löschen
# Opens about:downloads page
quickactions-downloads2 = Downloads anzeigen
quickactions-cmd-downloads = Downloads
# Opens about:addons page in the extensions section
quickactions-extensions = Erweiterungen verwalten
quickactions-cmd-extensions2 = Erweiterungen, Add-ons
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name } öffnen
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = { -firefoxview-brand-name }, { -firefoxview-brand-name } öffnen, Ansicht öffnen, Ansicht
# Opens SUMO home page
quickactions-help = { -brand-product-name }-Hilfe
quickactions-cmd-help = Hilfe, Support
# Opens the devtools web inspector
quickactions-inspector2 = Entwicklerwerkzeuge öffnen
quickactions-cmd-inspector2 = Inspektor, devtools, Entwicklerwerkzeuge
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Wählen Sie eine Farbe aus
quickactions-cmd-colorpicker = Farbwähler, Farbpipette, Farbe auswählen
# Opens Firefox Library
quickactions-cmd-library = Bibliothek
quickactions-library = Bibliothek öffnen
# Opens about:logins
quickactions-logins2 = Passwörter verwalten
quickactions-cmd-logins = Zugangsdaten, Logins, Anmeldungen, Passwörter
# Mutes all tabs playing audio
quickactions-mute = Tabs mit Audio stummschalten
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = stumm, psst
# Opens the print dialog
quickactions-print2 = Seite drucken
quickactions-cmd-print = Drucken
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Seite als PDF speichern
quickactions-cmd-savepdf2 = pdf, Seite speichern
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF-Editor öffnen
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Privates Fenster öffnen
quickactions-cmd-private = Privater Modus
# Opens a SUMO article explaining how to refresh
quickactions-refresh = { -brand-short-name } bereinigen
quickactions-cmd-refresh = Aktualisieren
# Restarts the browser
quickactions-restart = { -brand-short-name } neu starten
quickactions-cmd-restart = Neu starten
# Opens the screenshot tool
quickactions-screenshot3 = Bildschirmfoto aufnehmen
quickactions-cmd-screenshot2 = Bildschirmfoto, Bildschirmfoto machen
# Opens about:translations
quickactions-translate = Übersetzen
quickactions-cmd-translate = Übersetzen
# Opens about:preferences
quickactions-settings2 = Einstellungen verwalten
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = Einstellungen, Präferenzen, Optionen, verwalten
# Opens about:addons page in the themes section
quickactions-themes = Themes verwalten
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = Themes, Add-ons
# Opens a SUMO article explaining how to update the browser
quickactions-update = { -brand-short-name } aktualisieren
quickactions-cmd-update = Aktualisieren
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Seitenquelltext anzeigen
quickactions-cmd-viewsource2 = Quelltext anzeigen, Quelltext, Seitenquelltext
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = { -firefoxlabs-brand-name } öffnen
quickactions-cmd-labs = Labs, Experiment, Experimente
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Mehr über Schnellaktionen erfahren
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Tab drücken, um auszuwählen:

## Bookmark Panel

bookmarks-add-bookmark = Lesezeichen hinzufügen
bookmarks-edit-bookmark = Lesezeichen bearbeiten
bookmark-panel-cancel =
    .label = Abbrechen
    .accesskey = b
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Lesezeichen entfernen
           *[other] { $count } Lesezeichen entfernen
        }
    .accesskey = e
bookmark-panel-show-editor-checkbox =
    .label = Eigenschaften beim Speichern bearbeiten
    .accesskey = g
bookmark-panel-save-button2 =
    .label = Speichern
    .accesskey = S
bookmark-panel-save-button =
    .label = Speichern
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Website-Informationen für { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Verbindungssicherheit für { $host }
identity-connection-not-secure = Verbindung nicht sicher
identity-connection-secure = Verbindung sicher
identity-connection-failure = Verbindungsfehler
identity-connection-internal = Dies ist eine sichere { -brand-short-name }-Seite.
identity-connection-file = Diese Seite ist auf Ihrem Computer gespeichert.
identity-connection-associated = Diese Seite wurde durch eine andere Seite bereitgestellt.
identity-extension-page = Diese Seite wurde durch eine Erweiterung bereitgestellt.
identity-active-blocked = { -brand-short-name } hat nicht sichere Inhalte dieser Seite blockiert.
identity-custom-root = Die Verbindung wurde durch eine Zertifizierungsstelle bestätigt, welche standardmäßig nicht von Mozilla anerkannt wird.
identity-passive-loaded = Teile dieser Seite sind nicht sicher (wie z.B. Grafiken).
identity-active-loaded = Sie haben den Schutz für diese Seite deaktiviert.
identity-weak-encryption = Diese Seite verwendet eine schwache Verschlüsselung.
identity-https-only-connection-upgraded = (zu HTTPS geändert)
identity-https-only-label2 = Automatisches Upgrade dieser Website auf eine sichere Verbindung
identity-https-only-dropdown-on =
    .label = Ein
identity-https-only-dropdown-off =
    .label = Aus
identity-https-only-dropdown-off-temporarily =
    .label = Temporär aus
identity-https-only-info-turn-on3 = Aktivieren Sie HTTPS-Upgrades für diese Website, wenn Sie möchten, dass { -brand-short-name } die Verbindung nach Möglichkeit aktualisiert.
identity-https-only-info-turn-off3 = Wenn die Seite defekt zu sein scheint, sollten Sie die HTTPS-Upgrades für diese Website deaktivieren, damit sie über unsicheres HTTP neu geladen wird.
identity-https-only-info-no-upgrade = Verbindung konnte nicht von HTTP geändert werden.
identity-permissions-storage-access-header = Seitenübergreifende Cookies
identity-permissions-storage-access-hint = Diese Beteiligten können Cookies und Website-Daten verwenden, während Sie sich auf dieser Website befinden.
identity-permissions-storage-access-learn-more = Weitere Informationen
identity-permissions-reload-hint = Eventuell muss die Seite neu geladen werden, um die Änderungen zu übernehmen.
identity-clear-site-data =
    .label = Cookies und Website-Daten löschen…
identity-connection-not-secure-security-view = Sie kommunizieren mit dieser Seite über eine ungesicherte Verbindung.
identity-connection-verified = Sie sind derzeit über eine gesicherte Verbindung mit dieser Website verbunden.
identity-ev-owner-label2 = Zertifikat ausgestellt für
identity-verifier-label2 = Verifiziert von
identity-ev-owner-label = Zertifikat ausgestellt für:
identity-verifier-label = Verifiziert von:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Qualifiziert im Sinne der Richtlinie (EU) 2024/1183.
identity-description-custom-root2 = Mozilla erkennt diese Zertifizierungsstelle standardmäßig nicht an. Sie wurde eventuell vom Betriebssystem oder durch einen Administrator importiert.
identity-cert-exception-overridden = Sie haben eine Sicherheitsausnahme für diese Website hinzugefügt.
identity-remove-cert-exception =
    .label = Ausnahme entfernen
    .accesskey = A
identity-description-insecure = Ihre Verbindung zu dieser Website ist nicht vertraulich. Von Ihnen übermittelte Informationen (wie Passwörter, Nachrichten, Kreditkartendaten, usw.) können von Anderen eingesehen werden.
identity-description-weak-cipher-intro = Ihre Verbindung zu dieser Website verwendet eine schwache Verschlüsselung.
identity-description-weak-cipher-risk = Andere Personen können Ihre Informationen mitlesen oder das Verhalten der Website ändern.
identity-description-active-blocked2 = { -brand-short-name } hat nicht sichere Inhalte dieser Seite blockiert.
identity-description-passive-loaded = Ihre Verbindung ist nicht sicher und mit dieser Website geteilte Informationen können von Anderen eingesehen werden.
identity-description-passive-loaded-insecure2 = Diese Website enthält nicht sichere Inhalte (wie z.B. Grafiken).
identity-description-passive-loaded-mixed2 = Obwohl { -brand-short-name } Inhalte blockiert hat, enthält die Seite weiterhin nicht sichere Inhalte (wie z.B. Grafiken).
identity-description-active-loaded = Diese Website enthält nicht sichere Inhalte (wie z.B. Skripte) und Ihre Verbindung ist nicht vertraulich.
identity-description-active-loaded-insecure = Mit dieser Seite geteilte Informationen (wie Passwörter, Nachrichten, Kreditkartendaten, usw.) können von Anderen eingesehen werden.
identity-description-tls-key-logging-heading = Ihre Verbindung ist möglicherweise nicht privat
identity-description-tls-key-logging-message = Eine App oder ein Dienst kann möglicherweise Ihren verschlüsselten Datenverkehr von dieser Website sehen.
identity-more-info-link-text =
    .label = Weitere Informationen

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimieren
browser-window-maximize-button =
    .tooltiptext = Maximieren
browser-window-restore-down-button =
    .tooltiptext = Verkleinern
browser-window-close-button =
    .tooltiptext = Schließen
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Zurück

## Bookmarks toolbar items

browser-import-button2 =
    .label = Lesezeichen importieren…
    .tooltiptext = Lesezeichen aus einem anderen Browser zu { -brand-short-name } importieren.
bookmarks-toolbar-empty-message = Legen Sie Ihre Lesezeichen hier in der Lesezeichen-Symbolleiste ab, um schnell darauf zuzugreifen. <a data-l10n-name="manage-bookmarks">Lesezeichen verwalten…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Audiowiedergabegeräte
popup-select-window-or-screen =
    .label = Fenster oder Bildschirm:
    .accesskey = F
popup-all-windows-shared = Alle sichtbaren Fenster auf dem Bildschirm werden weitergegeben.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Sie teilen { -brand-short-name }. Andere Personen können sehen, wenn Sie zu einem neuen Tab wechseln.
sharing-warning-screen = Sie teilen Ihren gesamten Bildschirm. Andere Personen können sehen, wenn Sie zu einem neuen Tab wechseln.
sharing-warning-proceed-to-tab =
    .label = Weiter zum Tab
sharing-warning-disable-for-session =
    .label = Freigabeschutz für diese Sitzung deaktivieren

## WebSerial "select a port" popup

webserial-select-port-label = Wählen Sie einen seriellen Port aus:
webserial-no-ports-available = Kein serieller Port verfügbar

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Schließen
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Suche oder Adresse eingeben
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Adresse eingeben
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Mit { $name } suchen
    .placeholder = Das Web durchsuchen
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = { $name } durchsuchen
    .placeholder = Suchbegriffe eingeben
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Lesezeichen durchsuchen
    .placeholder = Suchbegriffe eingeben
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Chronik durchsuchen
    .placeholder = Suchbegriffe eingeben
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Tabs durchsuchen
    .placeholder = Suchbegriffe eingeben
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Aktionen durchsuchen
    .placeholder = Suchbegriffe eingeben
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Mit { $name } suchen oder Adresse eingeben
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Browser wird ferngesteuert (Grund: { $component })
urlbar-permissions-granted =
    .tooltiptext = Sie haben dieser Website zusätzliche Berechtigungen erteilt.
urlbar-switch-to-tab =
    .value = Wechseln zum Tab:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Erweiterung:
urlbar-go-button2 =
    .title = In der Adressleiste eingegebene Adresse laden
urlbar-page-action-button =
    .tooltiptext = Aktionen für Seite
urlbar-revert-button =
    .tooltiptext = Die Adresse in der Adressleiste anzeigen

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Mit "{ $engine }" in privatem Fenster suchen
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = In privatem Fenster suchen
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Mit "{ $engine }" suchen
urlbar-result-action-sponsored = Gesponsert
urlbar-result-action-switch-tab = Zum Tab wechseln
urlbar-result-action-move-tab-to-split-view = Tab in geteilte Ansicht verschieben
urlbar-result-action-visit = Aufrufen
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Zum Tab wechseln · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Unbenannte Gruppe
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Aus der Zwischenablage aufrufen
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Tab drücken, um mit { $engine } zu suchen
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Tab drücken, um { $engine } zu durchsuchen
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Mit { $engine } direkt aus der Adressleiste suchen
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = { $engine } direkt aus der Adressleiste durchsuchen
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopieren
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = undefiniert
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name }-Erweiterung
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Empfohlen
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> in { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Gesponsert
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Fragen
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Sie waren zuletzt { $date } hier
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Sie waren zuletzt vor { $daysAgo } Tag hier
       *[other] Sie waren zuletzt vor { $daysAgo } Tagen hier
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Sie waren zuletzt vor { $weeksAgo } Woche hier
       *[other] Sie waren zuletzt vor { $weeksAgo } Wochen hier
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Sie waren zuletzt vor { $monthsAgo } Monat hier
       *[other] Sie waren zuletzt vor { $monthsAgo } Monaten hier
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Sie waren zuletzt am { $date } hier
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = als Lesezeichen gesetzt am { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = { $date } zuletzt besucht
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = zuletzt besucht vor { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Zuletzt besucht am { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Holen Sie sich Aktiendaten direkt in Ihre Suchleiste
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Markt-Updates und mehr von unseren Partnern anzeigen, wenn Sie Suchanfragedaten mit { -vendor-short-name } teilen. <a data-l10n-name="learn-more-link">Weitere Informationen</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Vorschläge anzeigen
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Nicht jetzt
urlbar-result-realtime-opt-in-dismiss = Schließen
urlbar-result-realtime-opt-in-dismiss-all2 = Diese Vorschläge nicht anzeigen
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Marktvorschläge nicht anzeigen
    .accesskey = M
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Marktvorschläge nicht anzeigen
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Diese Vorschläge nicht anzeigen
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Marktvorschläge nicht anzeigen
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Danke für Ihr Feedback. Marktvorschläge werden nicht mehr angezeigt.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Vorschläge für den Aktienmarkt
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Danke für Ihr Feedback. Diese Vorschläge werden nicht mehr angezeigt.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · In { $daysUntilStart } Tag
       *[other] { $name } · In { $daysUntilStart } Tagen
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Beginnt in { $daysUntilStart } Tag
       *[other] { $name } · Beginnt in { $daysUntilStart } Tagen
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Endet in { $daysUntilEnd } Tag
       *[other] { $name } · Endet in { $daysUntilEnd } Tagen
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Heute
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Endet heute

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Mit "{ $engine }" suchen
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - { $localSearchMode } durchsuchen
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Mit { $engine } suchen
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, Suchmaschine auswählen
urlbar-searchmode-button-no-engine2 =
    .title = Keine Verknüpfung ausgewählt, wählen Sie eine Verknüpfung
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Die Schlüsselwortsuche ist deaktiviert
urlbar-searchmode-dropmarker2 =
    .title = Suchmaschine auswählen
urlbar-searchmode-bookmarks4 = Lesezeichen
urlbar-searchmode-tabs4 = Tabs
urlbar-searchmode-history4 = Chronik
urlbar-searchmode-actions4 = Aktionen
urlbar-searchmode-bookmarks3 = Lesezeichen
    .accesskey = L
urlbar-searchmode-tabs3 = Tabs
    .accesskey = T
urlbar-searchmode-history3 = Chronik
    .accesskey = C
urlbar-searchmode-actions3 = Aktionen
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Schließen
urlbar-searchmode-default2 =
    .title = Standardsuchmaschine
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = "{ $engineName }" hinzufügen
    .title = Suchmaschine "{ $engineName }" hinzufügen
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Einmalig suchen mit:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Suchen mit:
urlbar-searchmode-popup-search-settings2 = Sucheinstellungen
urlbar-searchmode-popup-settings2 = Einstellungen
urlbar-searchmode-popup-search-settings = Sucheinstellungen
    .accesskey = S
urlbar-searchmode-popup-settings = Einstellungen
    .accesskey = E

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Lesezeichen durchsuchen
urlbar-result-action-search-history = Chronik durchsuchen
urlbar-result-action-search-tabs = Tabs durchsuchen
urlbar-result-action-search-actions = Aktionen durchsuchen
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Zu { $group } wechseln
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } öffnen

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = In neuem Tab öffnen
    .accesskey = T
urlbar-view-context-menu-open-in-container-tab =
    .label = In neuem Tab in Umgebung öffnen
    .accesskey = m
urlbar-view-context-menu-open-in-window =
    .label = In neuem Fenster öffnen
    .accesskey = F
urlbar-view-context-menu-open-in-private-window =
    .label = In neuem privaten Fenster öffnen
    .accesskey = p
urlbar-view-context-menu-open-in-tab2 = In neuem Tab öffnen
    .accesskey = T
urlbar-view-context-menu-open-in-container-tab2 = In neuem Tab in Umgebung öffnen
    .accesskey = m
urlbar-view-context-menu-open-in-window2 = In neuem Fenster öffnen
    .accesskey = F
urlbar-view-context-menu-open-in-private-window2 = In neuem privaten Fenster öffnen
    .accesskey = p
urlbar-view-context-menu-search-in-tab = In neuem Tab suchen
    .accesskey = T
urlbar-view-context-menu-search-in-container-tab = In neuem Tab in Umgebung suchen
    .accesskey = U
urlbar-view-context-menu-search-in-window = In neuem Fenster suchen
    .accesskey = F
urlbar-view-context-menu-search-in-private-window = In neuem privaten Fenster suchen
    .accesskey = p
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Dieses Menü überspringen, wenn Sie die Tab-Taste verwenden
    .accesskey = D

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine }-Vorschläge
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Schnellaktionen
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Letzte Suchanfragen
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Beliebt bei { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Beliebte Suchanfragen nicht anzeigen
    .accesskey = B
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Beliebte Suchanfragen nicht anzeigen
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Beliebte Suchanfragen nicht anzeigen
    .accesskey = n
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Danke für Ihr Feedback. Beliebte Suchanfragen werden nicht mehr angezeigt.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Leseansicht öffnen
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Leseansicht beenden

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Bild-im-Bild öffnen ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Bild-im-Bild schließen ({ $shortcut })
picture-in-picture-panel-header = Bild-im-Bild
picture-in-picture-panel-headline = Diese Website empfiehlt kein Bild-im-Bild
picture-in-picture-panel-body = Videos werden möglicherweise nicht so angezeigt, wie vom Entwickler beabsichtigt, wenn Bild-im-Bild aktiviert ist.
picture-in-picture-enable-toggle =
    .label = Trotzdem aktivieren

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> befindet sich jetzt im Vollbildmodus.
fullscreen-warning-no-domain = Dieses Dokument befindet sich jetzt im Vollbildmodus.
fullscreen-exit-button = Vollbild beenden (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Vollbild beenden (esc)
fullscreen-keyboardlock-exit-button = Vollbild beenden (Esc drücken und halten)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Vollbild beenden (Esc drücken und halten)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> kontrolliert den Mauszeiger. Drücken Sie die Esc-Taste, wenn Sie wieder die Kontrolle übernehmen wollen.
pointerlock-warning-no-domain = Dieses Dokument kontrolliert den Mauszeiger. Drücken Sie die Esc-Taste, wenn Sie wieder die Kontrolle übernehmen wollen.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Lesezeichen verwalten
bookmarks-recent-bookmarks-panel-subheader = Neueste Lesezeichen
bookmarks-toolbar-chevron =
    .tooltiptext = Weitere Lesezeichen anzeigen
bookmarks-sidebar-content =
    .aria-label = Lesezeichen
bookmarks-menu-button =
    .label = Lesezeichen-Menü
bookmarks-other-bookmarks-menu =
    .label = Weitere Lesezeichen
bookmarks-mobile-bookmarks-menu =
    .label = Mobile Lesezeichen

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Lesezeichen-Sidebar schließen
           *[other] Lesezeichen-Sidebar anzeigen
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Lesezeichen-Symbolleiste ausblenden
           *[other] Lesezeichen-Symbolleiste anzeigen
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Lesezeichen-Symbolleiste ausblenden
           *[other] Lesezeichen-Symbolleiste anzeigen
        }

##

bookmarks-search =
    .label = Lesezeichen durchsuchen
bookmarks-tools =
    .label = Lesezeichen-Werkzeuge
bookmarks-subview-edit-bookmark =
    .label = Dieses Lesezeichen bearbeiten…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Lesezeichen
    .toolbarname = Lesezeichen-Symbolleiste
    .accesskey = L
bookmarks-toolbar-menu =
    .label = Lesezeichen-Symbolleiste
bookmarks-toolbar-placeholder =
    .title = Lesezeichen-Symbole
bookmarks-toolbar-placeholder-button =
    .label = Lesezeichen-Symbole
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Aktuellen Tab als Lesezeichen hinzufügen…

## Library Panel items

library-bookmarks-menu =
    .label = Lesezeichen

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Textkodierung reparieren
    .tooltiptext = Richtige Textkodierung basierend auf dem Seiteninhalt erraten

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Einstellungen
    .tooltiptext =
        { PLATFORM() ->
            [macos] Einstellungen öffnen ({ $shortcut })
           *[other] Einstellungen öffnen
        }
toolbar-overflow-customize-button =
    .label = Symbolleisten anpassen…
    .accesskey = S
toolbar-button-email-link =
    .label = Link senden
    .tooltiptext = Link zu dieser Seite per E-Mail senden
toolbar-button-logins =
    .label = Passwörter
    .tooltiptext = Gespeicherte Passwörter anzeigen und verwalten
qrcode-panel-error =
    .message = Der QR-Code konnte nicht erzeugt werden. Bitte versuchen Sie es erneut.
qrcode-copy-button =
    .label = Kopieren
qrcode-copy-success =
    .message = QR-Code in die Zwischenablage kopiert.
qrcode-copy-error =
    .message = Der QR-Code konnte nicht kopiert werden.
qrcode-save-button =
    .label = Speichern
qrcode-window-title = QR-Code
qrcode-dialog-title = QR-Code
qrcode-image =
    .aria-label = QR-Code
qrcode-close-button =
    .aria-label = Schließen
toolbar-button-save-page =
    .label = Seite speichern
    .tooltiptext = Seite speichern unter ({ $shortcut })
toolbar-button-open-file =
    .label = Datei öffnen
    .tooltiptext = Datei öffnen ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Synchronisierte Tabs
    .tooltiptext = Tabs von anderen Geräten anzeigen
toolbar-button-send-tab =
    .label = Tab senden
    .tooltiptext = Aktuellen Tab an ein anderes Gerät senden
toolbar-button-new-private-window =
    .label = Neues privates Fenster
    .tooltiptext = Ein neues privates Fenster öffnen ({ $shortcut })
toolbar-button-share-tab =
    .label = Teilen
    .tooltiptext = Diese Seite teilen
toolbar-button-tab-groups =
    .label = Tab-Gruppen
    .tooltiptext = Tab-Gruppen anzeigen
toolbar-button-history =
    .label = Chronik
    .tooltiptext = Kürzlich besuchte Seiten anzeigen ({ $shortcut })
toolbar-button-find =
    .label = Suchen
    .tooltiptext = Diese Seite durchsuchen ({ $shortcut })
toolbar-button-developer =
    .label = Entwickler-­Werkzeuge
    .tooltiptext = Werkzeuge für Web-Entwickler öffnen ({ $shortcut })
toolbar-button-forget =
    .label = Vergessen
    .tooltiptext = Teile der Browser-Chronik löschen
toolbar-zoom-controls =
    .label = Zoom-Steuerung
    .title = Zoom-Steuerung
toolbar-button-zoom-out =
    .label = Verkleinern
    .tooltiptext = Verkleinern ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Normalgröße ({ $shortcut })
toolbar-button-zoom-in =
    .label = Vergrößern
    .tooltiptext = Vergrößern ({ $shortcut })
toolbar-edit-controls =
    .label = Bearbeiten
    .title = Schaltflächen zum Kopieren, Ausschneiden und Einfügen
toolbar-button-cut =
    .label = Ausschneiden
    .tooltiptext = Ausschneiden ({ $shortcut })
toolbar-button-copy =
    .label = Kopieren
    .tooltiptext = Kopieren ({ $shortcut })
toolbar-button-paste =
    .label = Einfügen
    .tooltiptext = Einfügen ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = { $domain }-QR-Code

## EME notification panel

eme-notifications-drm-content-playing = Einige Audio- oder Videodateien auf dieser Seite nutzen DRM-Kopierschutz, der einschränkt, was Sie in { -brand-short-name } damit tun können.
eme-notifications-drm-content-playing-manage = Einstellungen verwalten
eme-notifications-drm-content-playing-manage-accesskey = v
eme-notifications-drm-content-playing-dismiss = Schließen
eme-notifications-drm-content-playing-dismiss-accesskey = c

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Der DRM-Kopierschutz muss aktiviert werden, um einige Audio- oder Videoelemente auf dieser Seite wiederzugeben.
eme-notifications-drm-content-disabled-button =
    .label = DRM-Kopierschutz aktivieren
    .accesskey = a
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } installiert zusätzliche Komponenten, welche für die Wiedergabe der Audio- oder Videodateien auf dieser Seite benötigt werden. Versuchen Sie es später erneut.
decoder-doctor-no-codecs-linux-message = Zur Wiedergabe des Videos müssen Sie eventuell die dafür notwendigen Video-Decoder installieren.
decoder-doctor-no-hw-acceleration-message = Zur Verbesserung der Videoqualität müssen Sie eventuell den Media Feature Pack von Microsoft installieren.
decoder-doctor-no-pulse-audio-message = Zur Audio-Wiedergabe müssen Sie die eventuell benötigte Software PulseAudio installieren.
decoder-doctor-unsupported-libavcodec-message = libavcodec sollte aktualisiert werden, um Videos wiederzugeben, da es gegen Angriffe verwundbar sein könnte oder die installierte Version nicht unterstützt wird.
decoder-doctor-decode-error-message = Beim Dekodieren einer Medien-Ressource trat ein Fehler auf.
decoder-doctor-decode-warning-message = Beim Dekodieren einer Medien-Ressource trat ein behebbarer Fehler auf.
decoder-doctor-learn-how-link = So wird's gemacht
decoder-doctor-report-issue-button =
    .label = Seitenproblem melden
    .accesskey = m
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Das Plugin "{ $pluginName }" ist abgestürzt.
plugin-crashed-notification-reload-button =
    .label = Seite neu laden
    .accesskey = S
plugin-crashed-notification-submit-button =
    .label = Absturzbericht senden
    .accesskey = A

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Betrügerische Website!
safebrowsing-reported-attack-site-message = Als attackierend gemeldete Website!
safebrowsing-reported-unwanted-site-message = Als Seite mit Downloads unerwünschter Software bekannt!
safebrowsing-reported-harmful-site-message = Als schädliche Website gemeldet!
safebrowsing-get-me-out-of-here-button =
    .label = Diese Seite verlassen!
    .accesskey = D
safebrowsing-not-a-deceptive-site-button =
    .label = Dies ist keine betrügerische Website…
    .accesskey = k
safebrowsing-not-an-attack-site-button =
    .label = Dies ist keine attackierende Website…
    .accesskey = k

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Sie müssen sich bei dem Netzwerk anmelden, um auf das Internet zugreifen zu können.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Anmeldeseite des Netzwerks öffnen

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Wollten Sie { $hostName } aufrufen?
keyword-uri-fixup-go-to-button =
    .label = Ja, { $hostName } öffnen
    .accesskey = J

## Password save/update panel

panel-save-update-username-2 =
    .label = Benutzername
panel-save-update-password-2 =
    .label = Passwort

##

# "More" item in macOS share menu
menu-share-more =
    .label = Mehr…
menu-share-windows =
    .label = Weitere Optionen
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Link kopieren
           *[other] { $count } Links kopieren
        }
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = Schließen

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Pop-ups und Drittanbieter-Weiterleitungen für { $uriHost } erlauben
    .accesskey = P

##

picture-in-picture-hide-toggle =
    .label = Schalter für Bild-im-Bild (PiP) ausblenden
    .accesskey = B

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Schalter für Bild-im-Bild (PiP) nach rechts verschieben
    .accesskey = v
picture-in-picture-move-toggle-left =
    .label = Schalter für Bild-im-Bild (PiP) nach links verschieben
    .accesskey = v

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigation
navbar-downloads =
    .label = Downloads
navbar-overflow-2 =
    .tooltiptext = Weitere Werkzeuge
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Drucken
    .tooltiptext = Diese Seite drucken… ({ $shortcut })
navbar-home =
    .label = Startseite
    .tooltiptext = { -brand-short-name }-Startseite
navbar-library =
    .label = Bibliothek
    .tooltiptext = Öffnen von Chronik, Lesezeichen und mehr
navbar-search =
    .title = Suchen
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Browser-Tabs
tabs-toolbar-new-tab =
    .label = Neuer Tab
tabs-toolbar-list-all-tabs-2 =
    .label = Tabs durchsuchen und verwalten
    .tooltiptext = Tabs durchsuchen und verwalten
tabs-toolbar-list-all-tabs =
    .label = Alle Tabs auflisten
    .tooltiptext = Alle Tabs auflisten

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Tab zum Anheften hier loslassen

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Vorherige Tabs öffnen?</strong> Sie können Ihre vorherige Sitzung über das { -brand-short-name }-Anwendungsmenü <img data-l10n-name="icon"/> unter Chronik wiederherstellen.
restore-session-startup-suggestion-button = Wie es funktioniert

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Ihre Organisation hat den Zugriff auf lokale Dateien auf diesem Computer blockiert

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } durchsucht jetzt Tabs
urlbar-addons-shortcut-moved-description = Um Erweiterungen und Themes zu öffnen, verwenden Sie { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Tastenkombinationen verwalten
urlbar-addons-shortcut-moved-dismiss = Verstanden

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } sendet automatisch einige Daten an { -vendor-short-name }, damit die Benutzerzufriedenheit verbessert werden kann.
data-reporting-notification-button =
    .label = Zu übermittelnde Daten festlegen
    .accesskey = f
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Privater Modus
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Privater Modus
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Informationen zum privaten Modus
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Sie sind in einem privaten Fenster
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Dies hilft, Ihre Surf-Aktivitäten auf diesem Gerät vor anderen zu verbergen, macht Sie aber online nicht unsichtbar. <a data-l10n-name="learn-more">Wer kann meine Aktivitäten sehen?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Verhinderung von Datenverlust (DLP) von { $agentName }. Klicken Sie hier, um weitere Informationen zu erhalten.
content-analysis-panel-title2 = Schutz vor Datenverlust
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Ihre Organisation verwendet <b>{ $agentName }</b>, um zu kontrollieren, wie vertrauliche Daten weitergegeben werden dürfen. <a data-l10n-name="info">Weitere Informationen</a>
content-analysis-panel-title = Datenschutz
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Ihre Organisation verwendet <b>{ $agentName }</b> zum Schutz vor Datenverlust. <a data-l10n-name="info">Weitere Informationen</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Erweiterungen
    .tooltiptext = Erweiterungen

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Erweiterungen
    .tooltiptext =
        Erweiterungen
        Berechtigungen nötig

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Erweiterungen
    .tooltiptext =
        Erweiterungen
        Einige Erweiterungen sind nicht erlaubt

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Erweiterungen
    .tooltiptext =
        Erweiterungen
        Einige Erweiterungen wurden deaktiviert

## Private browsing reset button

reset-pbm-panel-heading2 = Daten löschen und eine neue private Sitzung starten?
reset-pbm-panel-description3 = Dadurch werden Ihre Chronik und Cookies gelöscht und Sie werden von Websites abgemeldet. Ihre Privaten Fenster werden geschlossen und ein neues wird geöffnet.
reset-pbm-panel-description2 = Dadurch werden Chronik, Cookies und alle anderen Website-Daten gelöscht, ohne Ihr privates Fenster zu schließen.
reset-pbm-panel-always-ask-checkbox =
    .label = Immer fragen
    .accesskey = I
reset-pbm-panel-cancel-button =
    .label = Abbrechen
    .accesskey = A
reset-pbm-panel-confirm-button2 =
    .label = Private Sitzung löschen
    .accesskey = l
reset-pbm-panel-complete = Private Sitzungsdaten gelöscht
reset-pbm-toolbar-button2 =
    .label = Private Sitzung löschen
    .tooltiptext = Private Sitzung löschen

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Alle Surf-Daten löschen?
fire-button-panel-description = Dadurch werden Chronik, Cookies und Website-Daten gelöscht. Sie werden von Websites abgemeldet. Dieses Fenster wird geschlossen und { -brand-short-name } öffnet ein neues.
fire-button-panel-choose-description = Wenn Sie nicht alles löschen möchten, können Sie stattdessen gezielt bestimmte Daten auswählen.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Auswählen…
fire-button-panel-cancel-button =
    .label = Abbrechen
    .accesskey = A
fire-button-panel-confirm-button =
    .label = Alle löschen
    .accesskey = l
fire-button-panel-complete = Surf-Daten gelöscht
fire-button-toolbar-button2 =
    .label = Einige oder alle Daten löschen
    .tooltiptext = Löschen Sie einige oder alle Ihrer Surf-Daten

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } hat diese Webseite daran gehindert automatisch neu zu laden.
refresh-blocked-redirect-label = { -brand-short-name } hat diese Webseite daran gehindert automatisch auf eine andere Webseite umzuleiten.
refresh-blocked-allow =
    .label = Erlauben
    .accesskey = E

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Unsere sicheren, einfach zu bedienenden Masken schützen Ihre Identität und verhindern Spam, indem sie Ihre E-Mail-Adresse verstecken.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Alle E-Mails, die an Ihre E-Mail-Masken gesendet werden, werden an <strong>{ $useremail }</strong> weitergeleitet (es sei denn, Sie beschließen, sie zu blockieren).
firefox-relay-offer-legal-notice = Indem Sie auf "E-Mail-Maske verwenden" klicken, stimmen Sie den <label data-l10n-name="tos-url">Nutzungsbedingungen</label> und dem <label data-l10n-name="privacy-url">Datenschutzhinweis</label> zu.
firefox-relay-offer-legal-notice-1 = Indem Sie sich anmelden und eine E-Mail-Maske erstellen, stimmen Sie den <label data-l10n-name="tos-url">Nutzungsbedingungen</label> und dem <label data-l10n-name="privacy-url">Datenschutzhinweis</label> zu.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (nicht verifiziert)
popup-notification-xpinstall-prompt-learn-more = Weitere Informationen über das sichere Installieren von Add-ons
popup-notification-xpinstall-prompt-block-url = Details ansehen
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Ausführen der Erweiterung in privaten Fenstern erlauben
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Technische Daten und Interaktionsdaten mit Entwicklern der Erweiterung teilen
    .accesskey = t

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } hat diese Website daran gehindert, ein Pop-up-Fenster zu öffnen.
       *[other] { -brand-short-name } hat diese Website daran gehindert, { $popupCount } Pop-up-Fenster zu öffnen.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } hat diese Website daran gehindert weiterzuleiten.
        [1] { -brand-short-name } hat diese Website daran gehindert ein Pop-up-Fenster zu öffnen und weiterzuleiten.
        [one] { -brand-short-name } hat diese Website daran gehindert ein Pop-up-Fenster zu öffnen und weiterzuleiten.
       *[other] { -brand-short-name } hat diese Website daran gehindert, { $popupCount } Pop-up-Fenster zu öffnen und weiterzuleiten.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } hat diese Website daran gehindert, mehr als { $popupCount } Pop-up-Fenster zu öffnen.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } hat diese Website daran gehindert, mehr als { $popupCount } Pop-up-Fenster zu öffnen und weiterzuleiten.
       *[other] { -brand-short-name } hat diese Website daran gehindert, mehr als { $popupCount } Pop-up-Fenster zu öffnen und weiterzuleiten.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Einstellungen
           *[other] Einstellungen
        }
    .accesskey =
        { PLATFORM() ->
            [windows] i
           *[other] i
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Anzeigen: '{ $popupURI }'
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Der Windows-Dateidialog konnte nicht geöffnet werden. Es konnte keine Datei oder Ordner ausgewählt werden.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Der Windows-Dateidialog konnte nicht geöffnet werden. Die Datei wird unter { $path } gespeichert.
file-picker-failed-save-nowhere = Der Windows-Dateidialog konnte nicht geöffnet werden. Es konnte kein Standardordner gefunden werden; die Datei wird nicht gespeichert.
file-picker-crashed-open = Der Windows-Dateidialog ist abgestürzt. Es konnte keine Datei oder Ordner ausgewählt werden.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Der Windows-Dateidialog ist abgestürzt. Die Datei wird unter { $path } gespeichert.
file-picker-crashed-save-nowhere = Der Windows-Dateidialog ist abgestürzt. Es konnte kein Standardordner gefunden werden; die Datei wird nicht gespeichert.
file-picker-crashed-show-in-folder =
    .label = In Ordner anzeigen
    .accessKey = O

## Unsigned add-ons notification

unsigned-addons-disabled-message = Ein oder mehrere Add-ons konnten nicht verifiziert werden und wurden deshalb deaktiviert.
unsigned-addons-disabled-learn-more =
    .label = Weitere Informationen
    .accesskey = W

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Diese Seite verlangsamt { -brand-short-name }. Halten Sie die Seite an, um den Browser zu beschleunigen.
process-hang-nonspecific-tab-message = Eine Webseite verlangsamt { -brand-short-name }. Halten Sie die Seite an, um den Browser zu beschleunigen.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = "{ $title }" verlangsamt { -brand-short-name }. Halten Sie die Seite an, um den Browser zu beschleunigen.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = "{ $addonName }" verlangsamt { -brand-short-name }. Halten Sie die Erweiterung an, um den Browser zu beschleunigen.
process-hang-addon-learn-more =
    .value = Weitere Informationen
process-hang-stop-button =
    .label = Anhalten
    .accesskey = A

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Einrichtung abschließen
onboarding-aw-finish-setup-button =
    .label = Einrichtung abschließen
    .tooltiptext = Einrichtung von { -brand-short-name } abschließen

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Verbesserter Tracking-Schutz ist aktiviert
trustpanel-etp-label-disabled = Verbesserter Tracking-Schutz ist deaktiviert
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Verbesserter Tracking-Schutz: aktiviert für { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Verbesserter Tracking-Schutz: deaktiviert für { $host }
trustpanel-etp-description-enabled = Wenn etwas auf dieser Website beschädigt aussieht, versuchen Sie, die Schutzmaßnahmen zu deaktivieren.
trustpanel-etp-description-disabled = { -brand-product-name } ist der Meinung, dass Unternehmen Ihnen weniger folgen sollten. Wir blockieren so viele Elemente zur Aktivitätenverfolgung wie möglich, wenn Sie die Schutzmaßnahmen aktivieren.
trustpanel-trackercount-label = Blockierte Tracker in der Adressleiste anzeigen
trustpanel-trackercount-toggle =
    .aria-label = Blockierte Tracker in der Adressleiste anzeigen
trustpanel-connection-label-secure = Verbindung sicher
trustpanel-connection-label-insecure = Verbindung nicht sicher
trustpanel-header-enabled = { -brand-product-name } ist wachsam
trustpanel-description-enabled2 = Sie sind geschützt. Wenn wir etwas entdecken, sagen wir es Ihnen.
trustpanel-header-enabled-insecure = Seien Sie vorsichtig auf dieser Website
trustpanel-description-enabled-insecure = { -brand-product-name } hat etwas Verdächtiges bemerkt.
trustpanel-header-disabled = Sie haben die Schutzmaßnahmen deaktiviert
trustpanel-description-disabled = { -brand-product-name } ist nicht im Dienst. Wir empfehlen Ihnen, den Schutz wieder zu aktivieren.
trustpanel-clear-cookies-button = Cookies und Website-Daten löschen
trustpanel-privacy-link = Datenschutzeinstellungen
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Cookies und Website-Daten für { $host } löschen
trustpanel-clear-cookies-description = Durch das Löschen von Cookies und Website-Daten werden Sie eventuell von Websites abgemeldet und Warenkörbe gelöscht.
trustpanel-clear-cookies-subview-button-clear = Löschen
trustpanel-clear-cookies-subview-button-cancel = Abbrechen
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Verbindungssicherheit für { $host }
trustpanel-siteinformation-morelink = Mehr Website-Informationen
trustpanel-blocker-see-all = Alle anzeigen
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Verfolgungsschutz für { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Nicht sicher
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } Tracker blockiert
       *[other] { $count } Tracker blockiert
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } ist der Meinung, dass Unternehmen Ihnen weniger folgen sollten. Daher blockieren wir so viele wie möglich.
trustpanel-blocked-header = { -brand-product-name } hat dies für Sie blockiert:
trustpanel-tracking-header = { -brand-product-name } erlaubt diese Dinge, damit Websites noch funktionieren:
trustpanel-tracking-description = Ohne Tracker funktionieren einige Schaltflächen, Formulare und Anmeldefelder möglicherweise nicht.
trustpanel-insecure-section-header = Ihre Verbindung ist nicht sicher
trustpanel-insecure-description = Die Daten, die Sie an diese Website senden, sind nicht verschlüsselt. Sie könnten eingesehen, gestohlen oder verändert werden.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } Cookie zur seitenübergreifenden Aktivitätenverfolgung
       *[other] { $count } Cookies zur seitenübergreifenden Aktivitätenverfolgung
    }
trustpanel-list-label-tracking-content = Inhalte zur Aktivitätenverfolgung
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } Identifizierer (Fingerprinter)
       *[other] { $count } Identifizierer (Fingerprinter)
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } Social-Media-Tracker (Skript zur Aktivitätenverfolgung durch soziale Netzwerke)
       *[other] { $count } Social-Media-Tracker (Skripte zur Aktivitätenverfolgung durch soziale Netzwerke)
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } Heimlicher Digitalwährungsberechner (Krypto-Miner)
       *[other] { $count } Heimliche Digitalwährungsberechner (Krypto-Miner)
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Social-Media-Tracker blockiert
       *[other] { -brand-product-name } hat { $count } Social-Media-Tracker blockiert
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Social-Media-Tracker erlaubt
       *[other] { -brand-product-name } hat { $count } Social-Media-Tracker erlaubt
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Cookie zur seitenübergreifenden Aktivitätenverfolgung blockiert
       *[other] { -brand-product-name } hat { $count } Cookies zur seitenübergreifenden Aktivitätenverfolgung blockiert
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Cookie zur seitenübergreifenden Aktivitätenverfolgung erlaubt
       *[other] { -brand-product-name } hat { $count } Cookies zur seitenübergreifenden Aktivitätenverfolgung erlaubt
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Element zur Aktivitätenverfolgung blockiert
       *[other] { -brand-product-name } hat { $count } Elemente zur Aktivitätenverfolgung blockiert
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Element zur Aktivitätenverfolgung erlaubt
       *[other] { -brand-product-name } hat { $count } Elemente zur Aktivitätenverfolgung erlaubt
    }
trustpanel-tracking-content-tab-list-header = Diese Websites versuchen, Sie zu verfolgen:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Identifizierer (Fingerprinter) blockiert
       *[other] { -brand-product-name } hat { $count } Identifizierer (Fingerprinter) blockiert
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } Identifizierer (Fingerprinter) erlaubt
       *[other] { -brand-product-name } hat { $count } Identifizierer (Fingerprinter) erlaubt
    }
trustpanel-fingerprinter-list-header = Diese Websites versuchen, Fingerabdrücke von Ihnen zu erstellen:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } heimlichen Digitalwährungsberechner (Krypto-Miner) blockiert
       *[other] { -brand-product-name } hat { $count } heimliche Digitalwährungsberechner (Krypto-Miner) blockiert
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } hat { $count } heimlichen Digitalwährungsberechner (Krypto-Miner) erlaubt
       *[other] { -brand-product-name } hat { $count } heimliche Digitalwährungsberechner (Krypto-Miner) erlaubt
    }
trustpanel-cryptominer-tab-list-header = Diese Websites versuchen Krypto-Mining zu betreiben:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Haben Sie ein Konto auf dieser Website?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } hat herausgefunden, dass diese Website in den letzten 12 Monaten von einem Datenleck betroffen war. Finden Sie heraus, ob Sie betroffen sind.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Schließen
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Kostenlose Überprüfung starten
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> Tracker auf dieser Website blockiert
       *[other] <span data-l10n-name="count">{ $count }</span> Tracker auf dieser Website blockiert
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Sieht die Website beschädigt aus?</strong> Laden Sie die Seite neu, um den Schutz vor Aktivitätenverfolgung vorübergehend zu verringern.
reduced-protection-infobar-reload-button = Neu laden
    .accesskey = N
reduced-protection-infobar-never-show-button = Nicht erneut anzeigen
    .accesskey = N


identity-allow-site-data = Cookies/Daten für diese Seite immer speichern
urlbar-webgl-notification-anchor =
    .tooltiptext = Berechtigung zur WebGL-Kontexterstellung verwalten
urlbar-webgl-blocked =
    .tooltiptext = Sie haben die WebGL-Kontexterstellung für diese Website blockiert.
