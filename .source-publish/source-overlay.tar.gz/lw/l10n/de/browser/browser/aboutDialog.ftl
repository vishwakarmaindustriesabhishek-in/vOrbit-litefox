# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

aboutDialog-title =
    .title = Über { -brand-full-name }
releaseNotes-link = Neue Funktionen und Änderungen
update-checkForUpdatesButton =
    .label = Nach Updates suchen
    .accesskey = N
update-updateButton =
    .label = Zum Abschließen des Updates { -brand-shorter-name } neu starten
    .accesskey = Z
update-checkingForUpdates = Nach Updates suchen…
settings-update-checking-for-updates =
    .label = Nach Updates suchen…

## Variables:
##   $transfer (string) - Transfer progress.

aboutdialog-update-downloading = Update wird heruntergeladen – <label data-l10n-name="download-status">{ $transfer }</label>
settings-update-downloading-2 =
    .label = Update wird heruntergeladen — { $transfer }

##

update-applying = Update wird durchgeführt…
settings-update-applying =
    .label = Update wird durchgeführt…
update-failed = Update fehlgeschlagen. <label data-l10n-name="failed-link">Laden Sie die neueste Version herunter</label>
update-failed-main = Update fehlgeschlagen. <a data-l10n-name="failed-link-main">Laden Sie die neueste Version herunter</a>
update-policy-disabled = Ihre Organisation hat Updates deaktiviert
settings-update-policy-disabled =
    .label = Ihre Organisation hat Updates deaktiviert
update-noUpdatesFound = { -brand-short-name } ist aktuell
settings-update-no-updates-found =
    .label = { -brand-short-name } ist aktuell
aboutdialog-update-checking-failed = Suche nach Updates fehlgeschlagen.
settings-update-checking-failed =
    .label = Suche nach Updates fehlgeschlagen.
update-otherInstanceHandlingUpdates = { -brand-short-name } wird durch eine andere Instanz aktualisiert.
settings-update-other-instance-handling-updates =
    .label = { -brand-short-name } wird durch eine andere Instanz aktualisiert.

## Variables:
##   $displayUrl (String): URL to page with download instructions. Example: www.mozilla.org/firefox/nightly/

aboutdialog-update-manual-with-link = Updates verfügbar unter <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-manual-with-link = Updates verfügbar unter <a data-l10n-name="manual-link">{ $displayUrl }</a>
update-unsupported = Auf diesem System können keine weiteren Updates installiert werden. <label data-l10n-name="unsupported-link">Weitere Informationen</label>
settings-update-unsupported = Auf diesem System können keine weiteren Updates installiert werden. <a data-l10n-name="unsupported-link">Weitere Informationen</a>
update-restarting = Wird neu gestartet…
settings-update-restarting =
    .label = Wird neu gestartet…
update-internal-error2 = Aufgrund eines internen Fehlers konnte nicht nach Updates gesucht werden. Updates verfügbar unter <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-internal-error = Aufgrund eines internen Fehlers konnte nicht nach Updates gesucht werden. Updates verfügbar unter <a data-l10n-name="manual-link">{ $displayUrl }</a>

##

# Variables:
#   $channel (String): description of the update channel (e.g. "release", "beta", "nightly" etc.)
aboutdialog-channel-description = Sie sind derzeit auf dem Update-Kanal <label data-l10n-name="current-channel">{ $channel }</label>.
warningDesc-version = { -brand-short-name } ist experimentell und könnte instabil sein.
aboutdialog-help-user = { -brand-product-name }-Hilfe
aboutdialog-submit-feedback = Feedback senden
community-exp = <label data-l10n-name="community-exp-mozillaLink">{ -vendor-short-name }</label> ist eine <label data-l10n-name="community-exp-creditsLink">globale Community</label>, die daran arbeitet, dass das Internet frei, öffentlich und für jeden zugänglich bleibt.
community-2 = { -brand-short-name } wird entwickelt und gestaltet von <label data-l10n-name="community-mozillaLink">{ -vendor-short-name }</label>, einer <label data-l10n-name="community-creditsLink">globalen Community</label>, die daran arbeitet, dass das Internet frei, öffentlich und für jeden zugänglich bleibt.
helpus = Wollen Sie uns unterstützen? <label data-l10n-name="helpus-donateLink">Spenden Sie</label> oder <label data-l10n-name="helpus-getInvolvedLink">machen Sie mit!</label>
helpus-referrals2 = Möchten Sie helfen? <label data-l10n-name="helpus-donateLink">Spenden Sie</label>, <label data-l10n-name="helpus-shareFirefoxLink">Teilen Sie { -brand-product-name }</label>, oder <label data-l10n-name="helpus-getInvolvedLink">machen Sie mit!</label>
bottomLinks-license = Informationen zur Lizenzierung
bottom-links-terms = Nutzungsbedingungen
bottom-links-privacy = Datenschutzhinweis
# Example of resulting string: 66.0.1 (64-bit)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version = { $version } ({ $bits }-Bit)
# Example of resulting string: 66.0a1 (2019-01-16) (64-bit)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version-nightly = { $version } ({ $isodate }) ({ $bits }-Bit)
# Example of resulting string: 131.0a1 (aarch64)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch = { $version } ({ $arch })
# Example of resulting string: 131.0a1 (2024-08-27) (aarch64)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch-nightly = { $version } ({ $isodate }) ({ $arch })


about-vorbit = vOrbit-lite ist eine angepasste Version von Firefox mit den Hauptzielen Datenschutz, Sicherheit und Benutzerfreiheit.
