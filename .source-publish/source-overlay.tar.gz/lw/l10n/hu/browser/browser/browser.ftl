# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } privát böngészés
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Gyors és privát webböngészés
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } – privát böngészés
       *[other] { -brand-full-name } privát böngészés
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Privát böngészés
popups-infobar-dont-show-message2 =
    .label = Ne jelenjen meg ez az üzenet, ha a felugró ablakok vagy a harmadik féltől származó átirányítások blokkolva vannak
    .accesskey = N
edit-popup-settings2 =
    .label = Felugró ablakok és harmadik féltől származó átirányítási beállítások kezelése…
    .accesskey = F
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Webhely-információk megtekintése
            [1] Webhely-információk megtekintése (1 nyomkövető blokkolva)
            [one] Webhely-információk megtekintése ({ $count } nyomkövető blokkolva)
           *[other] Webhely-információk megtekintése ({ $count } nyomkövető blokkolva)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } hivatkozás
           *[other] { $count } hivatkozás
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Üzenetek és egyebek…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Üzenetek, Mail és egyebek…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Megosztás…
    .accesskey = o
urlbar-identity-button =
    .aria-label = Oldal adatainak megjelenítése

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Telepítési üzenetpanel megnyitása
urlbar-web-notification-anchor =
    .tooltiptext = Módosítsa, hogy kaphat-e értesítéseket ettől az oldaltól
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI panel megnyitása
urlbar-serial-notification-anchor =
    .tooltiptext = Soros portos eszközök paneljének megnyitása
urlbar-eme-notification-anchor =
    .tooltiptext = DRM-es szoftver használatának kezelése
urlbar-web-authn-anchor =
    .tooltiptext = Webes hitelesítési panel megnyitása
urlbar-canvas-notification-anchor =
    .tooltiptext = Vászonból kinyerés engedélyének kezelése
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = A mikrofon az oldallal megosztásának kezelése
urlbar-default-notification-anchor =
    .tooltiptext = Üzenetpanel megnyitása
urlbar-geolocation-notification-anchor =
    .tooltiptext = Helymeghatározási kérés panel megnyitása
urlbar-localhost-notification-anchor =
    .tooltiptext = Webhely helyi eszközökre vonatkozó hozzáférésének kezelése
urlbar-local-network-notification-anchor =
    .tooltiptext = Webhely helyi hálózati hozzáférés-megosztásának kezelése
urlbar-xr-notification-anchor =
    .tooltiptext = A virtuális valóság engedélyek panel megnyitása
urlbar-storage-access-anchor =
    .tooltiptext = Böngészési tevékenység engedélyezési panel megnyitása
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Az ablakok vagy képernyő az oldallal megosztásának kezelése
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Kapcsolat nélküli tárolás üzenetpanel megnyitása
urlbar-password-notification-anchor =
    .tooltiptext = Jelszó mentési üzenetpanel megnyitása
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = A kamera és/vagy mikrofon az oldallal megosztásának kezelése
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Egyéb hangszórók az oldallal történő megosztásának kezelése
urlbar-autoplay-notification-anchor =
    .tooltiptext = Automatikus lejátszás panel megnyitása
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Adatok tárolása az állandó tárban
urlbar-addons-notification-anchor =
    .tooltiptext = Kiegészítő telepítési üzenetpanel megnyitása
urlbar-search-tips-confirm = Rendben, értettem
urlbar-search-tips-confirm-short = Megértettem!
urlbar-result-menu-button =
    .title = Menü megnyitása
urlbar-result-menu-button-feedback = Visszajelzés
    .title = Menü megnyitása
urlbar-result-menu-learn-more2 = További tudnivalók
    .accesskey = T
urlbar-result-menu-remove-from-history2 = Törlés az előzményekből
    .accesskey = T
urlbar-result-menu-tip-get-help2 = Segítség kérése
    .accesskey = S
urlbar-result-menu-dismiss-suggestion2 = Javaslat elvetése
    .accesskey = e
urlbar-result-menu-remove-top-site = Népszerű oldal eltávolítása
    .accesskey = t
urlbar-result-menu-manage-firefox-suggest2 = A { -firefox-suggest-brand-name } kezelése
    .accesskey = k
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Pontatlan hely jelentése
    .accesskey = P
urlbar-result-menu-show-less-frequently3 = Megjelenítés ritkábban
    .accesskey = M
urlbar-result-menu-dont-show-weather-suggestions3 = Ne jelenjenek meg időjárási javaslatok
    .accesskey = N
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Pontatlan hely jelentése
urlbar-result-menu-show-less-frequently2 = Megjelenítés ritkábban
urlbar-result-menu-dont-show-weather-suggestions2 = Ne jelenjenek meg időjárási javaslatok
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Javaslat elvetése
    .accesskey = e
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Törlés az előzményekből
    .accesskey = T
urlbar-result-menu-learn-more =
    .label = További tudnivalók
    .accesskey = T
urlbar-result-menu-remove-from-history =
    .label = Törlés az előzményekből
    .accesskey = T
urlbar-result-menu-tip-get-help =
    .label = Segítség kérése
    .accesskey = S
urlbar-result-menu-dismiss-suggestion =
    .label = Javaslat elvetése
    .accesskey = e
urlbar-result-menu-manage-firefox-suggest =
    .label = A { -firefox-suggest-brand-name } kezelése
    .accesskey = k
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Pontatlan hely jelentése
urlbar-result-menu-show-less-frequently =
    .label = Megjelenítés ritkábban
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Ne jelenjenek meg időjárási javaslatok
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Menü megnyitása
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Köszönjük a visszajelzését
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Köszönjük a visszajelzését. Többé nem fogja látni az időjárási javaslatokat.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Gépeljen kevesebbet, találjon többet: { $engineName } keresés közvetlenül a címsorból.
urlbar-search-tips-redirect-2 = Kezdjen keresni a címsorban, és lássa a { $engineName } javaslatait, valamint a böngészési előzményeit.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Válassza ezt a rövidítést, hogy gyorsabban megtalálja, amire szüksége van.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Könyvjelzők
urlbar-search-mode-tabs = Lapok
urlbar-search-mode-history = Előzmények
urlbar-search-mode-actions = Műveletek

##

urlbar-geolocation-blocked =
    .tooltiptext = Blokkolta a helymeghatározási információkat ezen az oldalon.
urlbar-localhost-blocked =
    .tooltiptext = Blokkolta a webhely helyi eszközökre vonatkozó hozzáférését.
urlbar-local-network-blocked =
    .tooltiptext = Blokkolta a webhely helyi hálózati hozzáférését.
urlbar-xr-blocked =
    .tooltiptext = Blokkolta a virtuális valóság eszköz elérését ezen az oldalon.
urlbar-web-notifications-blocked =
    .tooltiptext = Blokkolta az értesítéseket ezen az oldalon.
urlbar-camera-blocked =
    .tooltiptext = Blokkolta a kamerát ezen az oldalon.
urlbar-microphone-blocked =
    .tooltiptext = Blokkolta a mikrofont ezen az oldalon.
urlbar-screen-blocked =
    .tooltiptext = Blokkolta a képernyőmegosztást ezen az oldalon.
urlbar-persistent-storage-blocked =
    .tooltiptext = Blokkolta az állandó adattárolást ezen az oldalon.
urlbar-popup-blocked2 =
    .tooltiptext = Blokkolta a felugró ablakokat és a harmadik féltől származó átirányításokat ezen az oldalon.
urlbar-autoplay-media-blocked =
    .tooltiptext = Blokkolta a média automatikus hangos lejátszását ezen az oldalon.
urlbar-canvas-blocked =
    .tooltiptext = Blokkolta a vászonadatok kinyerését ezen az oldalon.
urlbar-midi-blocked =
    .tooltiptext = Blokkolta a MIDI elérést ezen az oldalon.
urlbar-serial-blocked =
    .tooltiptext = Blokkolta a soros port elérését ezen az oldalon.
urlbar-install-blocked =
    .tooltiptext = Blokkolta a kiegészítők telepítését erről az oldalról.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Könyvjelző szerkesztése ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Oldal a könyvjelzők közé ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Osztott nézet
    .tooltiptext = Osztott nézet

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Beillesztés és ugrás
    .accesskey = B
urlbar-menuitem-paste-and-search =
    .label = Beillesztés és keresés
    .accesskey = B

## Searchbar context menu

clear-search-history =
    .label = Keresés előzményeinek törlése
    .accesskey = t

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Kiegészítő kezelése…
    .accesskey = K
page-action-remove-extension2 =
    .label = Kiegészítő eltávolítása
    .accesskey = e

## Auto-hide Context Menu

full-screen-autohide =
    .label = Eszköztárak elrejtése
    .accesskey = E
full-screen-exit =
    .label = Kilépés a teljes képernyős módból
    .accesskey = K

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Ezúttal keressen a következővel:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Keresési beállítások módosítása
search-one-offs-context-open-new-tab =
    .label = Keresés új lapon
    .accesskey = r
search-one-offs-context-set-as-default =
    .label = Legyen alapértelmezett keresőszolgáltatás
    .accesskey = L
search-one-offs-context-set-as-default-private =
    .label = Beállítás alapértelmezett keresőszolgáltatásként a privát ablakokban
    .accesskey = p
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = „{ $engineName }” keresőszolgáltatás hozzáadása
    .label = „{ $engineName }” hozzáadása
    .tooltiptext = „{ $engineName }” keresőszolgáltatás hozzáadása
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Keresőszolgáltatás hozzáadása
    .accesskey = K
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Keresőszolgáltatás hozzáadása

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Könyvjelzők ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Lapok ({ $restrict })
search-one-offs-history =
    .tooltiptext = Előzmények ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Műveletek ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Kiegészítők megjelenítése
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = kiegészítők, témák
# Opens preferences page at AI controls
quickactions-manageai = MI-vezérlők kezelése
quickactions-cmd-manageai = mi letiltása, mi kikapcsolása, mi kezelése
# Opens the bookmarks library window
quickactions-bookmarks2 = Könyvjelzők kezelése
quickactions-cmd-bookmarks = könyvjelzők
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Előzmények törlése
quickactions-cmd-clearrecenthistory2 = sütik, sütik törlése, gyorsítótár, gyorsítótár ürítése, böngészési adatok, böngészési adatok törlése, előzmények, előzmények törlése
# Opens about:downloads page
quickactions-downloads2 = Letöltések megtekintése
quickactions-cmd-downloads = letöltések
# Opens about:addons page in the extensions section
quickactions-extensions = Kiegészítők kezelése
quickactions-cmd-extensions2 = kiegészítők
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name } megnyitása
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = { -firefoxview-brand-name } megnyitása, { -firefoxview-brand-name }, nézet megnyitása, nézet
# Opens SUMO home page
quickactions-help = { -brand-product-name } súgó
quickactions-cmd-help = súgó, támogatás
# Opens the devtools web inspector
quickactions-inspector2 = Fejlesztői eszközök megnyitása
quickactions-cmd-inspector2 = inspector, vizsgáló, devtools, fejlesztői eszközök
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Válasszon egy színt
quickactions-cmd-colorpicker = színválasztó, pipetta, szín választása
# Opens Firefox Library
quickactions-cmd-library = könyvtár
quickactions-library = Könyvtár megnyitása
# Opens about:logins
quickactions-logins2 = Jelszavak kezelése
quickactions-cmd-logins = bejelentkezések, jelszavak
# Mutes all tabs playing audio
quickactions-mute = Hangot játszó lapok némítása
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = némítás, pszt, sssssh
# Opens the print dialog
quickactions-print2 = Oldal nyomtatása
quickactions-cmd-print = nyomtatás
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Oldal mentése PDF-ként
quickactions-cmd-savepdf2 = pdf, lap mentése, oldal mentése
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF szerkesztő megnyitása
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Privát ablak megnyitása
quickactions-cmd-private = privát böngészés
# Opens a SUMO article explaining how to refresh
quickactions-refresh = A { -brand-short-name } felfrissítése
quickactions-cmd-refresh = frissítés
# Restarts the browser
quickactions-restart = A { -brand-short-name } újraindítása
quickactions-cmd-restart = újraindítás
# Opens the screenshot tool
quickactions-screenshot3 = Képernyőkép készítése
quickactions-cmd-screenshot2 = screenshot, képernyőkép, képernyőkép készítése
# Opens about:translations
quickactions-translate = Fordítás
quickactions-cmd-translate = fordítás
# Opens about:preferences
quickactions-settings2 = Beállítások kezelése
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = beállítások, lehetőségek, kezelés
# Opens about:addons page in the themes section
quickactions-themes = Témák kezelése
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = témák, kiegészítők
# Opens a SUMO article explaining how to update the browser
quickactions-update = A { -brand-short-name } frissítése
quickactions-cmd-update = frissítés
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Oldal forrásának megtekintése
quickactions-cmd-viewsource2 = source, forrás megtekintése, forrás, oldal forrása
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = A { -firefoxlabs-brand-name } megnyitása
quickactions-cmd-labs = labor, kísérlet
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = További információ a gyors műveletekről
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Nyomja meg a Tabot a kiválasztáshoz:

## Bookmark Panel

bookmarks-add-bookmark = Könyvjelző hozzáadása
bookmarks-edit-bookmark = Könyvjelző szerkesztése
bookmark-panel-cancel =
    .label = Mégse
    .accesskey = M
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Könyvjelző törlése
           *[other] { $count } könyvjelző törlése
        }
    .accesskey = t
bookmark-panel-show-editor-checkbox =
    .label = Szerkesztő megjelenítése mentéskor
    .accesskey = e
bookmark-panel-save-button2 =
    .label = Mentés
    .accesskey = M
bookmark-panel-save-button =
    .label = Mentés
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Oldalinformációk erről: { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = A(z) { $host } kapcsolatának biztonsága
identity-connection-not-secure = A kapcsolat nem biztonságos
identity-connection-secure = A kapcsolat biztonságos
identity-connection-failure = Kapcsolódási hiba
identity-connection-internal = Ez egy biztonságos { -brand-short-name } oldal.
identity-connection-file = Ez az oldal a számítógépén van tárolva.
identity-connection-associated = Ez az oldal egy másik oldalról lett betöltve.
identity-extension-page = Ez az oldal kiegészítőből lett betöltve.
identity-active-blocked = A { -brand-short-name } blokkolta az oldal néhány nem biztonságos elemét.
identity-custom-root = A kapcsolatot egy olyan tanúsítványkibocsátó igazolta, amelyet a Mozilla nem ismeri fel.
identity-passive-loaded = A weboldal egyes részei nem biztonságosak (például a képek).
identity-active-loaded = Kikapcsolta a védelmet ezen az oldalon.
identity-weak-encryption = Ez az oldal gyenge titkosítást használ.
identity-https-only-connection-upgraded = (frissítve HTTPS-re)
identity-https-only-label2 = A webhely kapcsolatának automatikus frissítése biztonságossá
identity-https-only-dropdown-on =
    .label = Be
identity-https-only-dropdown-off =
    .label = Ki
identity-https-only-dropdown-off-temporarily =
    .label = Ideiglenesen ki
identity-https-only-info-turn-on3 = Kapcsolja be a HTTPS frissítéseket ezen az oldalon, ha azt akarja, hogy a { -brand-short-name } frissítse a kapcsolatot, ha lehetséges.
identity-https-only-info-turn-off3 = Ha az oldal nem megfelelően működik, lehet ki kell kapcsolnia a HTTPS frissítéseket az oldalon, hogy nem biztonságos HTTP-vel töltse újra.
identity-https-only-info-no-upgrade = Nem lehet frissíteni a kapcsolatot HTTP-ről.
identity-permissions-storage-access-header = Webhelyek közötti sütik
identity-permissions-storage-access-hint = Ezek a felek használhatják a webhelyek közötti sütiket és a webhely adatait, amíg Ön ezen a webhelyen tartózkodik.
identity-permissions-storage-access-learn-more = További tudnivalók
identity-permissions-reload-hint = Lehet hogy újra kell töltenie az oldalt a változások érvényesítéséhez.
identity-clear-site-data =
    .label = Sütik és oldaladatok eltávolítása…
identity-connection-not-secure-security-view = Nem biztonságosan kapcsolódik ehhez az oldalhoz.
identity-connection-verified = Biztonságosan kapcsolódik ehhez az oldalhoz.
identity-ev-owner-label2 = Tanúsítvány kiállítva ennek:
identity-verifier-label2 = Ellenőrizte:
identity-ev-owner-label = Tanúsítvány kiállítva ennek:
identity-verifier-label = Ellenőrizte:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Az (EU) 2024/1183 rendeleteben meghatározottak szerint.
identity-description-custom-root2 = A Mozilla nem ismeri fel ezt a tanúsítványkibocsátót. Lehet, hogy az operációs rendszer vagy egy rendszergazda adta hozzá.
identity-cert-exception-overridden = Biztonsági kivételt adott hozzá ehhez a webhelyhez.
identity-remove-cert-exception =
    .label = Kivétel eltávolítása
    .accesskey = e
identity-description-insecure = A kapcsolat ehhez az oldalhoz nem biztonságos. Az elküldött információkat mások is láthatják (például a jelszavakat, üzeneteket, bankkártya-adatokat stb.).
identity-description-weak-cipher-intro = A kapcsolat ehhez a weboldalhoz túl gyenge titkosítást használ, és nem biztonságos.
identity-description-weak-cipher-risk = Mások megjeleníthetik információit, vagy módosíthatják a weboldal viselkedését.
identity-description-active-blocked2 = A { -brand-short-name } blokkolta az oldal néhány nem biztonságos elemét.
identity-description-passive-loaded = A kapcsolat nem biztonságos, és az oldalnak elküldött információkat mások is láthatják.
identity-description-passive-loaded-insecure2 = A weboldal nem biztonságos elemeket (például képeket) tartalmaz.
identity-description-passive-loaded-mixed2 = Noha a { -brand-short-name } blokkolt bizonyos tartalmakat, még mindig van nem biztonságos tartalom (például képek) az oldalon.
identity-description-active-loaded = A weboldal nem biztonságos elemeket (például parancsfájlokat) tartalmaz, és a kapcsolat nem biztonságos.
identity-description-active-loaded-insecure = Az oldalnak elküldött információkat mások is láthatják (például a jelszavakat, üzeneteket, bankkártya-adatokat stb.).
identity-description-tls-key-logging-heading = A kapcsolata nem biztos, hogy privát
identity-description-tls-key-logging-message = Egy alkalmazás vagy szolgáltatás láthatja a titkosított forgalmát erről az oldalról.
identity-more-info-link-text =
    .label = További tudnivalók

## Window controls

browser-window-minimize-button =
    .tooltiptext = Kis méret
browser-window-maximize-button =
    .tooltiptext = Maximalizálás
browser-window-restore-down-button =
    .tooltiptext = Előző méret
browser-window-close-button =
    .tooltiptext = Bezárás
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Vissza

## Bookmarks toolbar items

browser-import-button2 =
    .label = Könyvjelzők importálása…
    .tooltiptext = Könyvjelzők importálása egy másik böngészőből a { -brand-short-name }ba…
bookmarks-toolbar-empty-message = A gyors eléréshez a könyvjelzők ide helyezhetők, a könyvjelzők eszköztárra. <a data-l10n-name="manage-bookmarks">Könyvjelzők kezelése…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Hangeszközök
popup-select-window-or-screen =
    .label = Ablak vagy képernyő:
    .accesskey = A
popup-all-windows-shared = A képernyő minden látható ablaka meg lesz osztva.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Ön megosztja a { -brand-short-name }ot. Mások is láthatják, ha új lapra vált.
sharing-warning-screen = Ön megosztja a teljes képernyőjét. Mások is láthatják, ha új lapra vált.
sharing-warning-proceed-to-tab =
    .label = Tovább a laphoz
sharing-warning-disable-for-session =
    .label = Megosztásvédelem kikapcsolása ebben a munkamenetben

## WebSerial "select a port" popup

webserial-select-port-label = Válasszon soros portot:
webserial-no-ports-available = Nem érhető el soros port

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Bezárás
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Keresés vagy cím
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Cím megadása
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Keresés a(z) { $name } keresővel
    .placeholder = Keresés a weben
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Keresés a(z) { $name } keresővel
    .placeholder = Adja meg a keresési kifejezéseket
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Könyvjelzők keresése
    .placeholder = Adja meg a keresési kifejezéseket
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Előzmények keresése
    .placeholder = Adja meg a keresési kifejezéseket
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Lapok keresése
    .placeholder = Adja meg a keresési kifejezéseket
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Műveletek keresése
    .placeholder = Adja meg a keresési kifejezéseket
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Keressen a(z) { $name } keresővel vagy adjon meg egy címet
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = A böngésző távvezérlés alatt áll (ok: { $component })
urlbar-permissions-granted =
    .tooltiptext = További engedélyeket adott ennek az oldalnak.
urlbar-switch-to-tab =
    .value = Váltás erre a lapra:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Kiegészítő:
urlbar-go-button2 =
    .title = Ugrás a címmezőben levő címre
urlbar-page-action-button =
    .tooltiptext = Oldalműveletek
urlbar-revert-button =
    .tooltiptext = A cím megjelenítése a címmezőben

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = { $engine } keresés egy privát ablakban
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Keresés egy privát ablakban
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine } keresés
urlbar-result-action-sponsored = Szponzorált
urlbar-result-action-switch-tab = Váltás erre a lapra
urlbar-result-action-move-tab-to-split-view = Lap áthelyezése osztott nézetbe
urlbar-result-action-visit = Keresse fel:
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Váltás erre a lapra: <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Névtelen csoport
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Felkeresés a vágólapról
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Nyomja meg a Tabot, hogy a következővel keressen: { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Nyomja meg a Tabot, hogy a következővel keressen: { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Keresés a(z) { $engine } segítségével közvetlenül a címsorból
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Keresés a(z) { $engine } webhelyen közvetlenül a címsorból
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Másolás
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = meghatározatlan
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } kiegészítő
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Ajánlott
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature } °{ $unit }</strong> itt: { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature } °{ $unit }</strong> itt: { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature } °{ $unit }</strong> itt: { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } ∙ Szponzorálva
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Kérdezze meg
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Utolsó látogatás: { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Utoljára { $daysAgo } napja kereste fel
       *[other] Utoljára { $daysAgo } napja kereste fel
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Utoljára { $weeksAgo } hete kereste fel
       *[other] Utoljára { $weeksAgo } hete kereste fel
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Utoljára { $monthsAgo } hónapja kereste fel
       *[other] Utoljára { $monthsAgo } hónapja kereste fel
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Utolsó látogatás: { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Könyvjelzőzve: { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Utoljára felkeresve: { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Utoljára felkeresve: { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Utoljára felkeresve: { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Szerezzen tőzsdei adatokat közvetlenül a keresősávban
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Pénzpiaci hírek és egyebek megjelenítése a partnereinktől, ha megosztja a keresési adatokat a { -vendor-short-name(ending: "accented") }val. <a data-l10n-name="learn-more-link">További tudnivalók</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Javaslatok megjelenítése
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Most nem
urlbar-result-realtime-opt-in-dismiss = Eltüntetés
urlbar-result-realtime-opt-in-dismiss-all2 = Ne jelenjenek meg ezek a javaslatok
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Ne jelenjenek meg pénzpiaci javaslatok
    .accesskey = N
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Ne jelenjenek meg pénzpiaci javaslatok
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Ne jelenjenek meg ezek a javaslatok
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Ne jelenjenek meg pénzpiaci javaslatok
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Köszönjük a visszajelzését. Többé nem fogja látni az pénzpiaci javaslatokat.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Tőzsdei javaslatok
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Köszönjük a visszajelzését. Többé nem fogja látni ezeket a javaslatokat.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } nap múlva
       *[other] { $name } · { $daysUntilStart } nap múlva
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } nap múlva kezdődik
       *[other] { $name } · { $daysUntilStart } nap múlva kezdődik
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · { $daysUntilEnd } nap múlva ér véget
       *[other] { $name } · { $daysUntilEnd } nap múlva ér véget
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Ma
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Ma ér véget

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine } keresés
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } – { $localSearchMode } keresés
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } – Keresés ezzel: { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, válasszon keresőszolgáltatást
urlbar-searchmode-button-no-engine2 =
    .title = Nincs gyorsparancs kiválasztva, válasszon egyet
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = A kulcsszavas keresés le van tiltva
urlbar-searchmode-dropmarker2 =
    .title = Válasszon keresőszolgáltatást
urlbar-searchmode-bookmarks4 = Könyvjelzők
urlbar-searchmode-tabs4 = Lapok
urlbar-searchmode-history4 = Előzmények
urlbar-searchmode-actions4 = Műveletek
urlbar-searchmode-bookmarks3 = Könyvjelzők
    .accesskey = K
urlbar-searchmode-tabs3 = Lapok
    .accesskey = L
urlbar-searchmode-history3 = Előzmények
    .accesskey = E
urlbar-searchmode-actions3 = Műveletek
    .accesskey = M
urlbar-searchmode-exit-button2 =
    .title = Bezárás
urlbar-searchmode-default2 =
    .title = Alapértelmezett keresőszolgáltatás
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = „{ $engineName }” hozzáadása
    .title = „{ $engineName }” keresőszolgáltatás hozzáadása
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Ezúttal keressen a következővel:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Keresés ezzel:
urlbar-searchmode-popup-search-settings2 = Keresési beállítások
urlbar-searchmode-popup-settings2 = Beállítások
urlbar-searchmode-popup-search-settings = Keresési beállítások
    .accesskey = s
urlbar-searchmode-popup-settings = Beállítások
    .accesskey = B

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Könyvjelzők keresése
urlbar-result-action-search-history = Előzmények keresése
urlbar-result-action-search-tabs = Lapok keresése
urlbar-result-action-search-actions = Keresési műveletek
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Váltás erre: { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } megnyitása

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Megnyitás új lapon
    .accesskey = j
urlbar-view-context-menu-open-in-container-tab =
    .label = Megnyitás új konténerlapban
    .accesskey = k
urlbar-view-context-menu-open-in-window =
    .label = Megnyitás új ablakban
    .accesskey = M
urlbar-view-context-menu-open-in-private-window =
    .label = Megnyitás új privát ablakban
    .accesskey = p
urlbar-view-context-menu-open-in-tab2 = Megnyitás új lapon
    .accesskey = j
urlbar-view-context-menu-open-in-container-tab2 = Megnyitás új konténerlapban
    .accesskey = k
urlbar-view-context-menu-open-in-window2 = Megnyitás új ablakban
    .accesskey = M
urlbar-view-context-menu-open-in-private-window2 = Megnyitás új privát ablakban
    .accesskey = p
urlbar-view-context-menu-search-in-tab = Keresés új lapon
    .accesskey = K
urlbar-view-context-menu-search-in-container-tab = Keresés új konténerlapon
    .accesskey = j
urlbar-view-context-menu-search-in-window = Keresés új ablakban
    .accesskey = a
urlbar-view-context-menu-search-in-private-window = Keresés új privát ablakban
    .accesskey = p
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Menü kihagyása a Tab billentyű használatakor
    .accesskey = k

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } javaslatok
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Gyors műveletek
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Legutóbbi keresések
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Felkapott ebben: { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Ne jelenjenek meg a felkapott keresések
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Ne jelenjenek meg a felkapott keresések
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Ne jelenjenek meg a felkapott keresések
    .accesskey = N
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Köszönjük visszajelzését. Többé nem fogja látni a felkapott kereséseket.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Belépés olvasó nézetbe
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Olvasó nézet bezárása

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Kép a képben megnyitása ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Kép a képben bezárása ({ $shortcut })
picture-in-picture-panel-header = Kép a képben
picture-in-picture-panel-headline = A weboldal nem ajánlja a Kép a képben módot
picture-in-picture-panel-body = Előfordulhat, hogy a videók nem a fejlesztő által kívánt módon jelennek meg, ha a Kép a képben funkció engedélyezett.
picture-in-picture-enable-toggle =
    .label = Engedélyezés mindenképp

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = A(z) <span data-l10n-name="domain">{ $domain }</span> mostantól teljes képernyős
fullscreen-warning-no-domain = A dokumentum mostantól teljes képernyős
fullscreen-exit-button = Kilépés a teljes képernyőből (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Kilépés a teljes képernyőből (esc)
fullscreen-keyboardlock-exit-button = Kilépés a teljes képernyős módból (Nyomja meg és tartsa lenyomva az Esc billentyűt)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Kilépés a teljes képernyős módból (Nyomja meg és tartsa lenyomva az Esc billentyűt)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = A következő irányítja az egérmutatót: <span data-l10n-name="domain">{ $domain }</span> . Nyomja meg az Esc gombot az irányítás visszavételéhez.
pointerlock-warning-no-domain = Ez a dokumentum vezérli az egérmutatóját. Nyomja meg az Esc gombot az irányítás visszavételéhez.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Könyvjelzők kezelése
bookmarks-recent-bookmarks-panel-subheader = Friss könyvjelzők
bookmarks-toolbar-chevron =
    .tooltiptext = További könyvjelzők megjelenítése
bookmarks-sidebar-content =
    .aria-label = Könyvjelzők
bookmarks-menu-button =
    .label = Könyvjelzők menü
bookmarks-other-bookmarks-menu =
    .label = Más könyvjelzők
bookmarks-mobile-bookmarks-menu =
    .label = Mobilos könyvjelzők

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Könyvjelzők oldalsáv elrejtése
           *[other] Könyvjelzők oldalsáv megjelenítése
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Könyvjelző eszköztár elrejtése
           *[other] Könyvjelző eszköztár megjelenítése
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Könyvjelző eszköztár elrejtése
           *[other] Könyvjelző eszköztár megjelenítése
        }

##

bookmarks-search =
    .label = Könyvjelzők keresése
bookmarks-tools =
    .label = Könyvjelzőzési eszközök
bookmarks-subview-edit-bookmark =
    .label = Könyvjelző szerkesztése…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Könyvjelzők
    .toolbarname = Könyvjelző eszköztár
    .accesskey = K
bookmarks-toolbar-menu =
    .label = Könyvjelző eszköztár
bookmarks-toolbar-placeholder =
    .title = Könyvjelző eszköztár elemei
bookmarks-toolbar-placeholder-button =
    .label = Könyvjelző eszköztár elemei
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Jelenlegi lap könyvjelzőzése…

## Library Panel items

library-bookmarks-menu =
    .label = Könyvjelzők

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Szövegkódolás javítása
    .tooltiptext = A szöveg kódolásának kitalálása az oldal tartalma alapján

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Beállítások
    .tooltiptext =
        { PLATFORM() ->
            [macos] Beállítások megnyitása ({ $shortcut })
           *[other] Beállítások megnyitása
        }
toolbar-overflow-customize-button =
    .label = Eszköztár testreszabása…
    .accesskey = E
toolbar-button-email-link =
    .label = Hivatkozás küldése
    .tooltiptext = Az oldalra mutató hivatkozás küldése e-mailben
toolbar-button-logins =
    .label = Jelszavak
    .tooltiptext = A mentett jelszavak megtekintése és kezelése
qrcode-panel-error =
    .message = Nem sikerült a QR-kód előállítása. Próbálja meg újra.
qrcode-copy-button =
    .label = Másolás
qrcode-copy-success =
    .message = QR-kód a vágólapra másolva.
qrcode-copy-error =
    .message = Nem sikerült a QR-kód másolása.
qrcode-save-button =
    .label = Mentés
qrcode-window-title = QR-kód
qrcode-dialog-title = QR-kód
qrcode-image =
    .aria-label = QR-kód
qrcode-close-button =
    .aria-label = Bezárás
toolbar-button-save-page =
    .label = Oldal mentése
    .tooltiptext = Oldal mentése ({ $shortcut })
toolbar-button-open-file =
    .label = Fájl megnyitása
    .tooltiptext = Fájl megnyitása ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Szinkronizált lapok
    .tooltiptext = Lapok megjelenítése más készülékekről
toolbar-button-send-tab =
    .label = Lap küldése
    .tooltiptext = Jelenlegi lap küldése egy másik eszközre
toolbar-button-new-private-window =
    .label = Új privát ablak
    .tooltiptext = Új privát ablak megnyitása ({ $shortcut })
toolbar-button-share-tab =
    .label = Megosztás
    .tooltiptext = Oldal megosztása
toolbar-button-tab-groups =
    .label = Lapcsoportok
    .tooltiptext = Lapcsoportok megjelenítése
toolbar-button-history =
    .label = Előzmények
    .tooltiptext = Előzmények megjelenítése ({ $shortcut })
toolbar-button-find =
    .label = Keresés
    .tooltiptext = Keresés ezen az oldalon ({ $shortcut })
toolbar-button-developer =
    .label = Fejlesztő
    .tooltiptext = Webfejlesztői eszközök ({ $shortcut })
toolbar-button-forget =
    .label = Elfelejtés
    .tooltiptext = Böngészési előzmények elfelejtése
toolbar-zoom-controls =
    .label = Nagyítás
    .title = Nagyítás
toolbar-button-zoom-out =
    .label = Kicsinyítés
    .tooltiptext = Kicsinyítés ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Nagyítási szint visszaállítása ({ $shortcut })
toolbar-button-zoom-in =
    .label = Nagyítás
    .tooltiptext = Nagyítás ({ $shortcut })
toolbar-edit-controls =
    .label = Szerkesztésvezérlők
    .title = Vezérlőelemek szerkesztése
toolbar-button-cut =
    .label = Kivágás
    .tooltiptext = Kivágás ({ $shortcut })
toolbar-button-copy =
    .label = Másolás
    .tooltiptext = Másolás ({ $shortcut })
toolbar-button-paste =
    .label = Beillesztés
    .tooltiptext = Beillesztés ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = A weboldal egyes hangjai vagy videói DRM szoftvert használnak, ami korlátozhatja, hogy a { -brand-short-name } ezekkel kapcsolatban mit engedélyezhet Önnek.
eme-notifications-drm-content-playing-manage = Beállítások kezelése
eme-notifications-drm-content-playing-manage-accesskey = k
eme-notifications-drm-content-playing-dismiss = Elvetés
eme-notifications-drm-content-playing-dismiss-accesskey = E

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Az oldalon lévő egyes hangok vagy videók lejátszásához engedélyezni kell a DRM-et.
eme-notifications-drm-content-disabled-button =
    .label = DRM engedélyezése
    .accesskey = D
eme-notifications-drm-content-cdm-installing-message = A { -brand-short-name } az oldalon lévő hangok vagy videók lejátszásához szükséges összetevőket telepít. Próbálja újra később.
decoder-doctor-no-codecs-linux-message = Videolejátszáshoz szükség lehet a szükséges videokodekek telepítésére.
decoder-doctor-no-hw-acceleration-message = A videominőség javításához szükség lehet a Microsoft Media Feature Pack telepítésére.
decoder-doctor-no-pulse-audio-message = Hanglejátszáshoz szükség lehet a szükséges PulseAudio szoftver telepítésére.
decoder-doctor-unsupported-libavcodec-message = A libavcodec sebezhető lehet, vagy nem támogatott, és frissíteni kell a videolejátszáshoz.
decoder-doctor-decode-error-message = Hiba történt a média-erőforrás dekódolása közben.
decoder-doctor-decode-warning-message = Helyrehozható hiba történt a média-erőforrás dekódolása közben.
decoder-doctor-learn-how-link = Tudja meg, hogyan
decoder-doctor-report-issue-button =
    .label = Hibás webhely bejelentése
    .accesskey = j
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = A(z) { $pluginName } bővítmény összeomlott.
plugin-crashed-notification-reload-button =
    .label = Újratöltés
    .accesskey = r
plugin-crashed-notification-submit-button =
    .label = Hibajelentés küldése
    .accesskey = H

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Félrevezető oldal!
safebrowsing-reported-attack-site-message = Bejelentett támadó webhely!
safebrowsing-reported-unwanted-site-message = Bejelentett, nem kívánatos szoftvereket terjesztő oldal!
safebrowsing-reported-harmful-site-message = Bejelentett ártalmas oldal!
safebrowsing-get-me-out-of-here-button =
    .label = Oldal elhagyása
    .accesskey = O
safebrowsing-not-a-deceptive-site-button =
    .label = Ez nem félrevezető oldal…
    .accesskey = n
safebrowsing-not-an-attack-site-button =
    .label = Ez nem támadó webhely…
    .accesskey = E

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Az internet elérése előtt be kell jelentkezni a hálózatra.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Hálózati bejelentkezés oldal megnyitása

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Ide szeretett volna eljutni: { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Igen, vigyél ide: { $hostName }
    .accesskey = I

## Password save/update panel

panel-save-update-username-2 =
    .label = Felhasználónév
panel-save-update-password-2 =
    .label = Jelszó

##

# "More" item in macOS share menu
menu-share-more =
    .label = Továbbiak…
menu-share-windows =
    .label = További beállítások
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Hivatkozás másolása
           *[other] { $count } hivatkozás másolása
        }
    .accesskey = H
ui-tour-info-panel-close =
    .tooltiptext = Bezárás

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Felugró ablakok és harmadik féltől származó átirányítások engedélyezése itt: { $uriHost }
    .accesskey = e

##

picture-in-picture-hide-toggle =
    .label = Kép a képben kapcsoló elrejtése
    .accesskey = r

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = A Kép a képben kapcsoló áthelyezése a jobb oldalra
    .accesskey = j
picture-in-picture-move-toggle-left =
    .label = A Kép a képben kapcsoló áthelyezése a bal oldalra
    .accesskey = b

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigáció
navbar-downloads =
    .label = Letöltések
navbar-overflow-2 =
    .tooltiptext = További eszközök
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Nyomtatás
    .tooltiptext = Oldal kinyomtatása… ({ $shortcut })
navbar-home =
    .label = Kezdőlap
    .tooltiptext = { -brand-short-name } kezdőoldal
navbar-library =
    .label = Könyvtár
    .tooltiptext = Előzmények, mentett könyvjelzők megtekintése
navbar-search =
    .title = Keresés
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Böngészőlapok
tabs-toolbar-new-tab =
    .label = Új lap
tabs-toolbar-list-all-tabs-2 =
    .label = Lapok keresése és kezelése
    .tooltiptext = Lapok keresése és kezelése
tabs-toolbar-list-all-tabs =
    .label = Összes lap felsorolása
    .tooltiptext = Összes lap felsorolása

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Húzza ide a lapot a rögzítéshez

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Megnyitná az előző lapokat?</strong> Visszaállíthatja az előző munkamenetét a { -brand-short-name } alkalmazásmenüben <img data-l10n-name="icon"/>, az Előzmények alatt.
restore-session-startup-suggestion-button = Mutassa meg hogyan

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = A szervezete blokkolta a helyi fájlok elérését ezen a számítógépen

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = A { $searchTabsShortcut } lapokat keres
urlbar-addons-shortcut-moved-description = A kiegészítők és témák megnyitásához használja a { $addonsShortcut } gyorsbillentyűt.
urlbar-addons-shortcut-moved-change-shortcuts = Gyorsbillentyűk kezelése
urlbar-addons-shortcut-moved-dismiss = Megértettem

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = A { -brand-short-name } automatikusan adatokat küld a { -vendor-short-name } számára, hogy javíthassuk a felhasználói élményt.
data-reporting-notification-button =
    .label = Megosztandó adatok kiválasztása
    .accesskey = v
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Privát böngészés
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Privát böngészés
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Privát böngészés információi
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Jelenleg privát ablakban van
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Ez segít abban, hogy ezen az eszközön rejtve maradjon mások elől, de nem teszi láthatatlanná az interneten. <a data-l10n-name="learn-more">Ki láthatja a tevékenységemet?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Az adatvesztés-megelőzés (DLP) a következőtől: { $agentName }. Kattintson a további információkért.
content-analysis-panel-title2 = Adatvesztés megelőzése
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Az Ön szervezete <b>{ $agentName }</b>segítségével szabályozza az érzékeny adatok megosztását. <a data-l10n-name="info"> Tudjon meg többet </a>
content-analysis-panel-title = Adatbiztonság
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = A szervezete a(z) <b>{ $agentName }</b> eszközt használja az adatvesztés elleni védelemhez. <a data-l10n-name="info">További tudnivalók</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Kiegészítők
    .tooltiptext = Kiegészítők

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Kiegészítők
    .tooltiptext =
        Kiegészítők
        Jogosultságok szükségesek

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Kiegészítők
    .tooltiptext =
        Kiegészítők
        Egyes kiegészítők nem engedélyezettek

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Kiegészítők
    .tooltiptext =
        Kiegészítők
        Egyes kiegészítők le vannak tiltva

## Private browsing reset button

reset-pbm-panel-heading2 = Törli az adatokat, és új privát munkamenetet indít?
reset-pbm-panel-description3 = Ez törli az előzményeket és a sütiket, és kilépteti az oldalakról. A privát ablakai be lesznek zárva, és egy új fog megnyílni.
reset-pbm-panel-description2 = Ez a privát ablak bezárása nélkül törli az előzményeket, a sütiket és az összes oldaladatot.
reset-pbm-panel-always-ask-checkbox =
    .label = Rákérdezés mindig
    .accesskey = R
reset-pbm-panel-cancel-button =
    .label = Mégse
    .accesskey = M
reset-pbm-panel-confirm-button2 =
    .label = Privát munkamenet törlése
    .accesskey = m
reset-pbm-panel-complete = A privát munkamenet adatai törölve
reset-pbm-toolbar-button2 =
    .label = Privát munkamenet törlése
    .tooltiptext = Privát munkamenet törlése

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Törli az összes böngészési adatot?
fire-button-panel-description = Ez törli az előzményeket, sütiket és oldaladatokat. Ki lesz jelentkeztetve a webhelyeken. Ez az ablak bezárul, és a { -brand-short-name } egy újat nyit.
fire-button-panel-choose-description = Ha nem szeretne mindent törölni, akkor válasszon konkrét adatokat.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Válasszon…
fire-button-panel-cancel-button =
    .label = Mégse
    .accesskey = M
fire-button-panel-confirm-button =
    .label = Összes törlése
    .accesskey = e
fire-button-panel-complete = Böngészési adatok törölve
fire-button-toolbar-button2 =
    .label = Adatok egy részének vagy egészének törlése
    .tooltiptext = Böngészési adatok egy részének vagy egészének törlése

## Autorefresh blocker

refresh-blocked-refresh-label = A { -brand-short-name } megakadályozta, hogy az oldal automatikusan újratöltődjön.
refresh-blocked-redirect-label = A { -brand-short-name } megakadályozta, hogy az oldal automatikusan átirányítson egy másik oldalra.
refresh-blocked-allow =
    .label = Engedélyezés
    .accesskey = E

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Biztonságos, könnyen használható maszkjaink az e-mail-címének elrejtésével védik személyazonosságát, és megakadályozzák a levélszemetet.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Az e-mail-maszkjaira küldött levelek a(z) <strong>{ $useremail }</strong> címre lesznek továbbítva (hacsak nem dönt úgy, hogy letiltja őket).
firefox-relay-offer-legal-notice = Az „E-mail-maszk használata” gombra kattintással elfogadja a <label data-l10n-name="tos-url">Szolgáltatási feltételeket</label> és az <label data-l10n-name="privacy-url">Adatvédelmi nyilatkozatot</label>.
firefox-relay-offer-legal-notice-1 = A regisztrációval és az e-mail-maszk létrehozásával elfogadja a <label data-l10n-name="tos-url">Szolgáltatási feltételeket</label> és az <label data-l10n-name="privacy-url">Adatvédelmi nyilatkozatot</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Ellenőrizetlen)
popup-notification-xpinstall-prompt-learn-more = Tudjon meg többet a bővítmények biztonságos telepítéséről
popup-notification-xpinstall-prompt-block-url = Részletek megtekintése
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = A kiegészítő futtatásának engedélyezése privát ablakokban
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Műszaki és interakciós adatok megosztása a kiegészítőfejlesztőkkel
    .accesskey = M

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] A { -brand-short-name } megakadályozta, hogy ez a webhely felugró ablakot nyisson meg.
       *[other] A { -brand-short-name } megakadályozta, hogy ez a webhely { $popupCount } felugró ablakot nyisson meg.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] A { -brand-short-name } megakadályozta, hogy a webhely átirányítsa.
        [1] A { -brand-short-name } megakadályozta, hogy a webhely egy felugró ablakot nyisson meg és átirányítsa.
        [one] A { -brand-short-name } megakadályozta, hogy a webhely egy felugró ablakot nyisson meg és átirányítsa.
       *[other] A { -brand-short-name } megakadályozta, hogy a webhely { $popupCount } felugró ablakot nyisson meg és átirányítsa.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = A { -brand-short-name } megakadályozta, hogy ez a webhely több mint { $popupCount } felugró ablakot nyisson meg.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] A { -brand-short-name } megakadályozta, hogy a webhely több mint { $popupCount } felugró ablakot nyisson meg és átirányítsa.
       *[other] A { -brand-short-name } megakadályozta, hogy a webhely több mint { $popupCount } felugró ablakot nyisson meg és átirányítsa.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Beállítások
           *[other] Beállítások
        }
    .accesskey =
        { PLATFORM() ->
            [windows] B
           *[other] B
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = „{ $popupURI }” megjelenítése
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = „{ $redirectURI }” megjelenítése

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = A Windows fájlválasztó párbeszédablaka nem nyitható meg. Nem választható ki fájl vagy mappa.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = A Windows fájlválasztó párbeszédablaka nem nyitható meg. A fájl ide lesz mentve: { $path }.
file-picker-failed-save-nowhere = A Windows fájlválasztó párbeszédablaka nem nyitható meg. Nem található alapértelmezett mappa; a fájl nem lesz mentve.
file-picker-crashed-open = A Windows fájlválasztó párbeszédablaka összeomlott. Nem választható ki fájl vagy mappa.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = A Windows fájlválasztó párbeszédablaka összeomlott. A fájl ide lesz mentve: { $path }.
file-picker-crashed-save-nowhere = A Windows fájlválasztó párbeszédablaka összeomlott. Nem található alapértelmezett mappa; a fájl nem lesz mentve.
file-picker-crashed-show-in-folder =
    .label = Megjelenítés mappában
    .accessKey = m

## Unsigned add-ons notification

unsigned-addons-disabled-message = Legalább egy telepített kiegészítő nem ellenőrizhető, és le lett tiltva.
unsigned-addons-disabled-learn-more =
    .label = További tudnivalók
    .accesskey = T

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Ez az oldal lelassítja a { -brand-short-name } futását. A böngésző felgyorsítása érdekében állítsa le ezt az oldalt.
process-hang-nonspecific-tab-message = Egy weboldal lelassítja a { -brand-short-name } futását. A böngésző felgyorsítása érdekében állítsa le azt az oldalt.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = A(z) „{ $title }” lelassítja a { -brand-short-name } futását. A böngésző felgyorsítása érdekében állítsa le azt az oldalt.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = A(z) „{ $addonName }” lelassítja a { -brand-short-name } futását. A böngésző felgyorsítása érdekében állítsa le azt a kiegészítőt.
process-hang-addon-learn-more =
    .value = További tudnivalók
process-hang-stop-button =
    .label = Leállítás
    .accesskey = L

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Beállítás befejezése
onboarding-aw-finish-setup-button =
    .label = Beállítás befejezése
    .tooltiptext = A { -brand-short-name } beállításának befejezése

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = A fokozott követés elleni védelem be van kapcsolva
trustpanel-etp-label-disabled = A fokozott követés elleni védelem ki van kapcsolva
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Fokozott követés elleni védelem: a(z) { $host } helyen be
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Fokozott követés elleni védelem: a(z) { $host } helyen ki
trustpanel-etp-description-enabled = Ha valami nem működik ezen az oldalon, próbálja meg kikapcsolni.
trustpanel-etp-description-disabled = A { -brand-product-name } úgy gondolja, hogy a cégeknek kevésbé kellene Önt követniük. A lehető legtöbb követőt blokkoljuk, amikor bekapcsolja a védelmet.
trustpanel-trackercount-label = A blokkolt nyomkövetők megjelenítése a címsávban
trustpanel-trackercount-toggle =
    .aria-label = A blokkolt nyomkövetők megjelenítése a címsávban
trustpanel-connection-label-secure = A kapcsolat biztonságos
trustpanel-connection-label-insecure = A kapcsolat nem biztonságos
trustpanel-header-enabled = A { -brand-product-name } résen van
trustpanel-description-enabled2 = Védve van. Ha látunk valamit, értesíteni fogjuk.
trustpanel-header-enabled-insecure = Legyen óvatos ezen az oldalon
trustpanel-description-enabled-insecure = A { -brand-product-name } valami gyanúsat észlelt.
trustpanel-header-disabled = Kikapcsolta a védelmeket
trustpanel-description-disabled = A { -brand-product-name } szolgálaton kívül van. Javasoljuk a védelmek ismételt bekapcsolását.
trustpanel-clear-cookies-button = Sütik és oldaladatok törlése
trustpanel-privacy-link = Adatvédelmi beállítások
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = A(z) { $host } sütijeinek és webhelyadatainak törlése
trustpanel-clear-cookies-description = A sütik és webhelyadatok eltávolítása kijelentkeztetheti a webhelyekről, és törölheti a kosarait.
trustpanel-clear-cookies-subview-button-clear = Törlés
trustpanel-clear-cookies-subview-button-cancel = Mégse
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = A(z) { $host } kapcsolatának védelmei
trustpanel-siteinformation-morelink = További webhely-információk
trustpanel-blocker-see-all = Összes megjelenítése
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = A(z) { $host } követés elleni védelmei
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Nem biztonságos
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } nyomkövető blokkolva
       *[other] { $count } nyomkövető blokkolva
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = A { -brand-product-name } úgy gondolja, hogy a cégeknek kevésbé kellene Önt követniük. Ezért a lehető legtöbbet blokkoljuk.
trustpanel-blocked-header = A { -brand-product-name } ezeket a dolgokat blokkolta Önnek:
trustpanel-tracking-header = A { -brand-product-name } engedélyezte ezeket a dolgokat, hogy az oldalak ne legyenek hibásak:
trustpanel-tracking-description = Nyomkövetők nélkül egyes gombok, űrlapok és bejelentkezési mezők lehet, hogy nem fognak működni.
trustpanel-insecure-section-header = A kapcsolat nem biztonságos
trustpanel-insecure-description = A webhelynek küldött adatok nem titkosítottak. Megtekinthetőek, ellophatóak vagy megváltoztathatóak.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } webhelyek közötti nyomkövető süti
       *[other] { $count } webhelyek közötti nyomkövető süti
    }
trustpanel-list-label-tracking-content = Nyomkövető tartalom
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } ujjlenyomat-készítő
       *[other] { $count } ujjlenyomat-készítő
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } közösségimédia-követő
       *[other] { $count } közösségimédia-követő
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } kriptobányász
       *[other] { $count } kriptobányász
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } blokkolt { $count } közösségimédia-követőt
       *[other] A { -brand-product-name } blokkolt { $count } közösségimédia-követőt
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } engedélyezett { $count } közösségimédia-követőt
       *[other] A { -brand-product-name } engedélyezett { $count } közösségimédia-követőt
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } blokkolt { $count } webhelyek közötti nyomkövető sütit
       *[other] A { -brand-product-name } blokkolt { $count } webhelyek közötti nyomkövető sütit
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } engedélyezett { $count } webhelyek közötti nyomkövető sütit
       *[other] A { -brand-product-name } engedélyezett { $count } webhelyek közötti nyomkövető sütit
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } blokkolt { $count } követőt
       *[other] A { -brand-product-name } blokkolt { $count } követőt
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } engedélyezett { $count } követőt
       *[other] A { -brand-product-name } engedélyezett { $count } követőt
    }
trustpanel-tracking-content-tab-list-header = Ezek a webhelyek próbálják követni Önt:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } blokkolt { $count } ujjlenyomat-készítőt
       *[other] A { -brand-product-name } blokkolt { $count } ujjlenyomat-készítőt
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } engedélyezett { $count } ujjlenyomat-készítőt
       *[other] A { -brand-product-name } engedélyezett { $count } ujjlenyomat-készítőt
    }
trustpanel-fingerprinter-list-header = Ezek a webhelyek ujjlenyomatot próbálnak készíteni Önről:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } blokkolt { $count } kriptobányászt
       *[other] A { -brand-product-name } blokkolt { $count } kriptobányászt
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] A { -brand-product-name } engedélyezett { $count } kriptobányászt
       *[other] A { -brand-product-name } engedélyezett { $count } kriptobányászt
    }
trustpanel-cryptominer-tab-list-header = Ezek a webhelyek próbálnak meg kriptovalutát bányászni:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Van fiókja ezen az oldalon?
trustpanel-breachalerts-anonymous-breached-description = A { -brand-product-name } azt találta, hogy ez a webhely az elmúlt 12 hónapban adatvédelmi incidensben volt érintett. Tudja meg, hogy érintette-e Önt.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Eltüntetés
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Ingyenes vizsgálat indítása
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> nyomkövető blokkolva ezen az oldalon
       *[other] <span data-l10n-name="count">{ $count }</span> nyomkövető blokkolva ezen az oldalon
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>A webhely még mindig hibásnak tűnik?</strong> Töltse újra az oldalt a követés elleni védelem ideiglenes csökkentésével.
reduced-protection-infobar-reload-button = Újratöltés
    .accesskey = r
reduced-protection-infobar-never-show-button = Ne jelenjen meg újra
    .accesskey = N


identity-allow-site-data = Mindig tárolja el a sütiket/adatokat ezen az oldalon
urlbar-webgl-notification-anchor =
    .tooltiptext = WebGL-kontextus engedélyének kezelése
urlbar-webgl-blocked =
    .tooltiptext = WebGL-kontextus létrehozása le van tiltva ennél a webhelynél.
