# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

aboutDialog-title =
    .title = Acerca de { -brand-full-name }
releaseNotes-link = Novedades
update-checkForUpdatesButton =
    .label = Buscar actualizaciones
    .accesskey = B
update-updateButton =
    .label = Reinicie para actualizar { -brand-shorter-name }
    .accesskey = R
update-checkingForUpdates = Comprobando actualizaciones…
settings-update-checking-for-updates =
    .label = Comprobando actualizaciones…

## Variables:
##   $transfer (string) - Transfer progress.

aboutdialog-update-downloading = Descargando actualización — <label data-l10n-name="download-status">{ $transfer }</label>
settings-update-downloading-2 =
    .label = Descargando actualización — { $transfer }

##

update-applying = Aplicando actualización…
settings-update-applying =
    .label = Aplicando actualización…
update-failed = La actualización falló. <label data-l10n-name="failed-link">Descargar la última versión</label>
update-failed-main = La actualización falló. <a data-l10n-name="failed-link-main">Descargar la última versión</a>
update-policy-disabled = Actualizaciones deshabilitadas por su organización
settings-update-policy-disabled =
    .label = Actualizaciones deshabilitadas por su organización
update-noUpdatesFound = { -brand-short-name } está actualizado
settings-update-no-updates-found =
    .label = { -brand-short-name } está actualizado
aboutdialog-update-checking-failed = Error al buscar actualizaciones.
settings-update-checking-failed =
    .label = Error al buscar actualizaciones.
update-otherInstanceHandlingUpdates = { -brand-short-name } está siendo actualizado por otra instancia
settings-update-other-instance-handling-updates =
    .label = { -brand-short-name } está siendo actualizado por otra instancia

## Variables:
##   $displayUrl (String): URL to page with download instructions. Example: www.mozilla.org/firefox/nightly/

aboutdialog-update-manual-with-link = Actualización disponible en <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-manual-with-link = Actualización disponible en <a data-l10n-name="manual-link">{ $displayUrl }</a>
update-unsupported = No puede ejecutar más actualizaciones en este sistema. <label data-l10n-name="unsupported-link">Saber más</label>
settings-update-unsupported = No puede ejecutar más actualizaciones en este sistema. <a data-l10n-name="unsupported-link">Saber más</a>
update-restarting = Reiniciando…
settings-update-restarting =
    .label = Reiniciando…
update-internal-error2 = No se pueden buscar actualizaciones debido a un error interno. Actualizaciones disponibles en <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-internal-error = No se pueden buscar actualizaciones debido a un error interno. Actualizaciones disponibles en <a data-l10n-name="manual-link">{ $displayUrl }</a>

##

# Variables:
#   $channel (String): description of the update channel (e.g. "release", "beta", "nightly" etc.)
aboutdialog-channel-description = Está usando el canal <label data-l10n-name="current-channel">{ $channel }</label> para actualizar.
warningDesc-version = { -brand-short-name } es experimental y puede ser inestable.
aboutdialog-help-user = Ayuda de { -brand-product-name }
aboutdialog-submit-feedback = Enviar opinión
community-exp = <label data-l10n-name="community-exp-mozillaLink">{ -vendor-short-name }</label> es una <label data-l10n-name="community-exp-creditsLink">comunidad global</label> que trabaja unida para mantener la Web abierta, pública y accesible para todos.
community-2 = { -brand-short-name } está diseñado por <label data-l10n-name="community-mozillaLink">{ -vendor-short-name }</label>, una <label data-l10n-name="community-creditsLink">comunidad global</label> que trabaja unida para mantener la Web abierta, pública y accesible para todos.
helpus = ¿Quiere ayudar? <label data-l10n-name="helpus-donateLink">¡Haga una donación</label> o <label data-l10n-name="helpus-getInvolvedLink">involúcrese!</label>
helpus-referrals2 = ¿Quiere ayudar? <label data-l10n-name="helpus-donateLink">Haga una donación</label>, <label data-l10n-name="helpus-shareFirefoxLink">Comparta { -brand-product-name }</label> o <label data-l10n-name="helpus-getInvolvedLink">¡Involúcrese!</label>
bottomLinks-license = Información de licencia
bottom-links-terms = Términos de uso
bottom-links-privacy = Aviso de privacidad
# Example of resulting string: 66.0.1 (64-bit)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version = { $version } ({ $bits }-bit)
# Example of resulting string: 66.0a1 (2019-01-16) (64-bit)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version-nightly = { $version } ({ $isodate }) ({ $bits }-bit)
# Example of resulting string: 131.0a1 (aarch64)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch = { $version } ({ $arch })
# Example of resulting string: 131.0a1 (2024-08-27) (aarch64)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch-nightly = { $version } ({ $isodate }) ({ $arch })


about-vorbit = vOrbit-lite es una versión personalizada de Firefox, cuyos objetivos principales son la privacidad, la seguridad y la libertad del usuario.
