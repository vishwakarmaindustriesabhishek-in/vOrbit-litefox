# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = Navegación privada de { -brand-shortcut-name }
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Navegación web rápida y privada
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Navegación privada
       *[other] { -brand-full-name } Navegación privada
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Navegación privada
popups-infobar-dont-show-message2 =
    .label = No mostrar este mensaje cuando las ventanas emergentes o las redirecciones de terceros estén bloqueadas
    .accesskey = N
edit-popup-settings2 =
    .label = Administrar la configuración de ventanas emergentes y redireccionamientos de terceros…
    .accesskey = A
urlbar-identity-button =
    .aria-label = Ver información del sitio

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Abrir panel de mensajes de instalación
urlbar-web-notification-anchor =
    .tooltiptext = Cambiar si puede recibir notificaciones del sitio
urlbar-midi-notification-anchor =
    .tooltiptext = Abrir el panel MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Abrir panel serie
urlbar-eme-notification-anchor =
    .tooltiptext = Administrar uso de software DRM
urlbar-web-authn-anchor =
    .tooltiptext = Abrir el panel de Autenticación web
urlbar-canvas-notification-anchor =
    .tooltiptext = Administrar permisos de extracción de canvas
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Administrar la compartición de su micrófono con el sitio
urlbar-default-notification-anchor =
    .tooltiptext = Abrir panel de mensajes
urlbar-geolocation-notification-anchor =
    .tooltiptext = Abrir panel de solicitud de ubicación
urlbar-localhost-notification-anchor =
    .tooltiptext = Administrar el acceso al dispositivo local para este sitio
urlbar-local-network-notification-anchor =
    .tooltiptext = Administrar compartir el acceso a la red local con este sitio
urlbar-xr-notification-anchor =
    .tooltiptext = Abrir el panel de permisos de realidad virtual
urlbar-storage-access-anchor =
    .tooltiptext = Abrir el panel de permisos de actividad de navegación
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Administrar la compartición de sus ventanas o pantalla con el sitio
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Abrir panel de mensajes de almacenamiento sin conexión
urlbar-password-notification-anchor =
    .tooltiptext = Abrir el panel de mensajes de contraseñas
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Administrar la compartición de su cámara o micrófono con el sitio
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Administrar la compartición de otros altavoces con el sitio
urlbar-autoplay-notification-anchor =
    .tooltiptext = Abrir el panel de reproducción automática
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Guardar datos en almacenamiento persistente
urlbar-addons-notification-anchor =
    .tooltiptext = Abrir el panel de mensajes de instalación de complementos
urlbar-search-tips-confirm = Vale, entendido
urlbar-search-tips-confirm-short = Entendido
urlbar-result-menu-button =
    .title = Abrir menú
urlbar-result-menu-button-feedback = Comentarios
    .title = Abrir menú
urlbar-result-menu-learn-more2 = Saber más
    .accesskey = S
urlbar-result-menu-remove-from-history2 = Eliminar del historial
    .accesskey = E
urlbar-result-menu-tip-get-help2 = Obtener ayuda
    .accesskey = a
urlbar-result-menu-dismiss-suggestion2 = Descartar esta sugerencia
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest2 = Administrar { -firefox-suggest-brand-name }
    .accesskey = A
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Informar ubicación inexacta
    .accesskey = n
urlbar-result-menu-show-less-frequently3 = Mostrar con menos frecuencia
    .accesskey = M
urlbar-result-menu-dont-show-weather-suggestions3 = No mostrar sugerencias meteorológicas
    .accesskey = N
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Informar ubicación inexacta
urlbar-result-menu-show-less-frequently2 = Mostrar con menos frecuencia
urlbar-result-menu-dont-show-weather-suggestions2 = No mostrar sugerencias meteorológicas
urlbar-result-menu-learn-more =
    .label = Saber más
    .accesskey = S
urlbar-result-menu-remove-from-history =
    .label = Eliminar del historial
    .accesskey = E
urlbar-result-menu-tip-get-help =
    .label = Obtener ayuda
    .accesskey = a
urlbar-result-menu-dismiss-suggestion =
    .label = Descartar esta sugerencia
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = Administrar { -firefox-suggest-brand-name }
    .accesskey = A
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Informar ubicación inexacta
urlbar-result-menu-show-less-frequently =
    .label = Mostrar con menos frecuencia
urlbar-result-menu-dont-show-weather-suggestions =
    .label = No mostrar sugerencias meteorológicas
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Abrir menú
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Gracias por su opinión
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Gracias por su opinión. Ya no verá sugerencias meteorológicas.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Escriba menos, encuentre más: busque con { $engineName } directamente desde la barra de direcciones.
urlbar-search-tips-redirect-2 = Inicie su búsqueda en la barra de direcciones para ver sugerencias de { $engineName } y su historial de navegación.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Seleccione este acceso directo para encontrar más rápidamente lo que necesite.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Marcadores
urlbar-search-mode-tabs = Pestañas
urlbar-search-mode-history = Historial
urlbar-search-mode-actions = Acciones

##

urlbar-geolocation-blocked =
    .tooltiptext = Ha bloqueado la información de ubicación para este sitio web.
urlbar-localhost-blocked =
    .tooltiptext = Ha bloqueado las conexiones a dispositivos locales para este sitio web.
urlbar-local-network-blocked =
    .tooltiptext = Ha bloqueado las conexiones de red local para este sitio web.
urlbar-xr-blocked =
    .tooltiptext = Ha bloqueado el acceso de dispositivos de realidad virtual para este sitio web.
urlbar-web-notifications-blocked =
    .tooltiptext = Ha bloqueado las notificaciones para este sitio web.
urlbar-camera-blocked =
    .tooltiptext = Ha bloqueado su cámara para este sitio web.
urlbar-microphone-blocked =
    .tooltiptext = Ha bloqueado su micrófono para este sitio web.
urlbar-screen-blocked =
    .tooltiptext = Ha impedido que este sitio web comparta su pantalla.
urlbar-persistent-storage-blocked =
    .tooltiptext = Ha bloqueado el almacenamiento de datos para este sitio web.
urlbar-popup-blocked2 =
    .tooltiptext = Ha bloqueado las ventanas emergentes y las redirecciones de terceros para este sitio web.
urlbar-autoplay-media-blocked =
    .tooltiptext = Ha bloqueado la reproducción automática de medios con sonido para este sitio web.
urlbar-canvas-blocked =
    .tooltiptext = Ha bloqueado la extracción de datos de canvas en este sitio web.
urlbar-midi-blocked =
    .tooltiptext = Ha bloqueado el acceso al MIDI para este sitio web.
urlbar-serial-blocked =
    .tooltiptext = Ha bloqueado el acceso al puerto serie para este sitio web.
urlbar-install-blocked =
    .tooltiptext = Ha bloqueado la instalación de complementos para este sitio web.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Editar este marcador ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Añadir esta página a marcadores ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Vista dividida
    .tooltiptext = Vista dividida

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Pegar e ir
    .accesskey = P

## Searchbar context menu

clear-search-history =
    .label = Limpiar historial de búsqueda
    .accesskey = L

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Administrar extensión…
    .accesskey = e
page-action-remove-extension2 =
    .label = Eliminar extensión
    .accesskey = E

## Auto-hide Context Menu

full-screen-autohide =
    .label = Ocultar barras de herramientas
    .accesskey = H
full-screen-exit =
    .label = Salir del modo pantalla completa
    .accesskey = m

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Esta vez, busque con:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Cambiar configuración de búsqueda
search-one-offs-context-open-new-tab =
    .label = Buscar en una pestaña nueva
    .accesskey = B
search-one-offs-context-set-as-default =
    .label = Establecer como buscador predeterminado
    .accesskey = E
search-one-offs-context-set-as-default-private =
    .label = Establecer como buscador predeterminado para ventanas privadas
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Añadir buscador “{ $engineName }”
    .label = Añadir “{ $engineName }”
    .tooltiptext = Añadir buscador “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Añadir buscador
    .accesskey = A
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Añadir buscador

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Marcadores ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Pestañas ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historial ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Acciones ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Ver complementos
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = extensiones, temas, complementos
# Opens the bookmarks library window
quickactions-bookmarks2 = Administrar marcadores
quickactions-cmd-bookmarks = marcadores
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Limpiar el historial reciente
quickactions-cmd-clearrecenthistory2 = cookies, borrar cookies, caché, borrar caché, datos de navegación, borrar datos de navegación, historial, borrar historial reciente
# Opens about:downloads page
quickactions-downloads2 = Ver descargas
quickactions-cmd-downloads = descargas
# Opens about:addons page in the extensions section
quickactions-extensions = Gestionar extensiones
quickactions-cmd-extensions2 = extensiones, complementos
# Opens Firefox View
quickactions-firefoxview = Abrir { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = abrir { -firefoxview-brand-name }, { -firefoxview-brand-name }, abrir vista, ver
# Opens SUMO home page
quickactions-help = Ayuda de { -brand-product-name }
quickactions-cmd-help = ayuda, soporte
# Opens the devtools web inspector
quickactions-inspector2 = Abrir herramientas para desarrollo
quickactions-cmd-inspector2 = inspector, devtools, herramientas para desarrolladores
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Seleccione un color
quickactions-cmd-colorpicker = selector de color, cuentagotas, elegir color
# Opens Firefox Library
quickactions-cmd-library = biblioteca
quickactions-library = Abrir biblioteca
# Opens about:logins
quickactions-logins2 = Administrar contraseñas
quickactions-cmd-logins = inicios de sesión y contraseñas
# Mutes all tabs playing audio
quickactions-mute = Silenciar pestañas que reproducen audio
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = silencio, shhhh, sssssh
# Opens the print dialog
quickactions-print2 = Imprimir página
quickactions-cmd-print = imprimir
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Guardar página como PDF
quickactions-cmd-savepdf2 = pdf, guardar página
# Opens a new private browsing window
quickactions-private2 = Abrir ventana privada
quickactions-cmd-private = navegación privada
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Restablecer { -brand-short-name }
quickactions-cmd-refresh = refrescar
# Restarts the browser
quickactions-restart = Reiniciar { -brand-short-name }
quickactions-cmd-restart = reiniciar
# Opens the screenshot tool
quickactions-screenshot3 = Hacer una captura de pantalla
quickactions-cmd-screenshot2 = captura de pantalla, hacer una captura de pantalla
# Opens about:translations
quickactions-translate = Traducir
quickactions-cmd-translate = traducir
# Opens about:preferences
quickactions-settings2 = Administrar ajustes
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = ajustes, preferencias, opciones, administrar
# Opens about:addons page in the themes section
quickactions-themes = Administrar temas
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temas, complementos
# Opens a SUMO article explaining how to update the browser
quickactions-update = Actualizar { -brand-short-name }
quickactions-cmd-update = actualizar
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Ver código fuente de la página
quickactions-cmd-viewsource2 = ver código fuente, fuente, código fuente de la página
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Abrir { -firefoxlabs-brand-name }
quickactions-cmd-labs = labs, experimento
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Saber más sobre las acciones rápidas
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Pulse tabulador para seleccionar:

## Bookmark Panel

bookmarks-add-bookmark = Añadir marcador
bookmarks-edit-bookmark = Editar marcador
bookmark-panel-cancel =
    .label = Cancelar
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Eliminar marcador
           *[other] Eliminar { $count } marcadores
        }
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = Mostrar editor al guardar
    .accesskey = s
bookmark-panel-save-button =
    .label = Guardar
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Información del sitio para { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Seguridad de la conexión para { $host }
identity-connection-not-secure = Conexión no segura
identity-connection-secure = Conexión segura
identity-connection-failure = Fallo de conexión
identity-connection-internal = Esta es una página segura de { -brand-short-name }.
identity-connection-file = Esta página se guarda en su equipo.
identity-connection-associated = Esta página está cargada desde otra página.
identity-extension-page = Esta página está cargada desde una extensión.
identity-active-blocked = { -brand-short-name } ha bloqueado partes de esta página que no son seguras.
identity-custom-root = Conexión verificada por un emisor de certificados que Mozilla no reconoce.
identity-passive-loaded = Partes de esta página no son seguras (como imágenes).
identity-active-loaded = Tiene la protección desactivada en esta página.
identity-weak-encryption = Esta página usa cifrado débil.
identity-https-only-connection-upgraded = (actualizado a HTTPS)
identity-https-only-label2 = Actualizar automáticamente este sitio a una conexión segura
identity-https-only-dropdown-on =
    .label = Activado
identity-https-only-dropdown-off =
    .label = Desactivado
identity-https-only-dropdown-off-temporarily =
    .label = Desactivado temporalmente
identity-https-only-info-turn-on3 = Active la actualización a HTTPS para este sitio si quiere que { -brand-short-name } actualice la conexión cuando sea posible.
identity-https-only-info-turn-off3 = Si la página no funciona correctamente, pruebe a desactivar el cambio a HTTPS para este sitio y volver a cargarlo usando una conexión HTTP insegura.
identity-https-only-info-no-upgrade = No se puede actualizar la conexión desde HTTP.
identity-permissions-storage-access-header = Cookies entre sitios
identity-permissions-storage-access-hint = Estas partes pueden usar cookies de sitios cruzados y datos del sitio mientras está en este sitio.
identity-permissions-storage-access-learn-more = Saber más
identity-permissions-reload-hint = Puede que necesite recargar la página para que se apliquen los cambios.
identity-clear-site-data =
    .label = Limpiar cookies y datos del sitio…
identity-connection-not-secure-security-view = No está conectado de forma segura a este sitio.
identity-connection-verified = Está conectado de forma segura a este sitio.
identity-ev-owner-label = Certificado emitido a nombre de:
identity-verifier-label = Verificado por:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Cualificado según lo especificado en el Reglamento (UE) 2024/1183.
identity-description-custom-root2 = Mozilla no reconoce al emisor de este certificado. Puede haber sido agregado desde su sistema operativo o por un administrador.
identity-cert-exception-overridden = Ha añadido una excepción de seguridad para este sitio.
identity-remove-cert-exception =
    .label = Eliminar excepción
    .accesskey = E
identity-description-insecure = Su conexión a este sitio no es privada. La información que envíe podría ser vista por otros (como contraseñas, mensajes, tarjetas de crédito, etc.).
identity-description-weak-cipher-intro = Su conexión a este sitio web usa cifrado débil y no es privada.
identity-description-weak-cipher-risk = Otras personas pueden ver su información o modificar el comportamiento del sitio web.
identity-description-active-blocked2 = { -brand-short-name } ha bloqueado partes de esta página que no son seguras.
identity-description-passive-loaded = Su conexión no es privada y la información que comparta con el sitio podría ser vista por otros.
identity-description-passive-loaded-insecure2 = Este sitio web contiene contenido que no es seguro (como imágenes).
identity-description-passive-loaded-mixed2 = Aunque { -brand-short-name } ha bloqueado cierto contenido, aún hay contenido en la página que no es seguro (como imágenes).
identity-description-active-loaded = Este sitio web contiene contenido que no es seguro (tal como scripts) y su conexión no es privada.
identity-description-active-loaded-insecure = La información que comparta con este sitio podría ser vista por otros (como contraseñas, mensajes, tarjetas de crédito, etc.).
identity-more-info-link-text =
    .label = Más información

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimizar
browser-window-maximize-button =
    .tooltiptext = Maximizar
browser-window-restore-down-button =
    .tooltiptext = Restaurar abajo
browser-window-close-button =
    .tooltiptext = Cerrar
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Volver

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importar marcadores…
    .tooltiptext = Importar marcadores desde otro navegador a { -brand-short-name }.
bookmarks-toolbar-empty-message = Para un acceso rápido, sitúe sus marcadores aquí en la barra de herramientas de marcadores. <a data-l10n-name="manage-bookmarks">Administrar marcadores…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Cámara:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = Cámara
popup-select-microphone-device =
    .value = Micrófono:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Micrófono
popup-select-speaker-icon =
    .tooltiptext = Altavoces
popup-select-window-or-screen =
    .label = Ventana o pantalla:
    .accesskey = V
popup-all-windows-shared = Se compartirán todas las ventanas visibles en su pantalla.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Está compartiendo { -brand-short-name }. Otras personas pueden ver cuando pasa a una pestaña nueva.
sharing-warning-screen = Está compartiendo su pantalla completa. Otras personas pueden ver cuando pasa a una pestaña nueva.
sharing-warning-proceed-to-tab =
    .label = Ir a la pestaña
sharing-warning-disable-for-session =
    .label = Deshabilitar la protección de compartición para esta sesión

## WebSerial "select a port" popup

webserial-select-port-label = Seleccione un puerto serie:
webserial-no-ports-available = No hay puertos serie disponibles

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Cerrar
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Término de búsqueda o dirección
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Introducir dirección
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Buscar con { $name }
    .placeholder = Buscar en la web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Buscar { $name }
    .placeholder = Introducir términos de búsqueda
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Buscar en marcadores
    .placeholder = Introducir términos de búsqueda
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Buscar en el historial
    .placeholder = Introducir términos de búsqueda
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Buscar en las pestañas
    .placeholder = Introducir términos de búsqueda
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Acciones de búsqueda
    .placeholder = Introducir términos de búsqueda
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Buscar con { $name } o introducir una dirección
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = El navegador está bajo control remoto (razón: { $component })
urlbar-permissions-granted =
    .tooltiptext = Ha concedido permisos adicionales a este sitio web.
urlbar-switch-to-tab =
    .value = Cambiar a la pestaña:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Extensión:
urlbar-go-button2 =
    .title = Ir a la URL de la barra de direcciones
urlbar-page-action-button =
    .tooltiptext = Acciones con la página
urlbar-revert-button =
    .tooltiptext = Mostrar la dirección en la barra de direcciones

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Buscar con { $engine } en una ventana privada
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Buscar en una ventana privada
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Buscar con { $engine }
urlbar-result-action-sponsored = Patrocinado
urlbar-result-action-switch-tab = Cambiar a la pestaña
urlbar-result-action-move-tab-to-split-view = Mover pestaña a vista dividida
urlbar-result-action-visit = Visitar
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Cambiar a pestaña · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Grupo sin nombre
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Visitar desde el portapapeles
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Presione Tab para buscar con { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Presione Tab para buscar con { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Buscar con { $engine } directamente desde la barra de direcciones
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Buscar con { $engine } directamente desde la barra de direcciones
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Copiar
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = indefinido
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Extensión de { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Recomendado
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> en { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> en { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> en { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Patrocinado
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Pregunta

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Obtenga datos del mercado de valores directamente en la barra de búsqueda
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Comparta los datos de la búsqueda con { -vendor-short-name } y obtenga información actualizada sobre el mercado y más datos de nuestros socios. <a data-l10n-name="learn-more-link">Saber más</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Mostrar sugerencias
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Ahora no
urlbar-result-realtime-opt-in-dismiss = Descartar
urlbar-result-realtime-opt-in-dismiss-all2 = No mostrar estas sugerencias
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = No mostrar sugerencias de mercados
    .accesskey = N
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = No mostrar sugerencias de mercados
urlbar-result-realtime-opt-in-dismiss-all =
    .label = No mostrar estas sugerencias
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = No mostrar sugerencias de mercados
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Gracias por su opinión. Ya no verá sugerencias de mercados.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Sugerencias para el mercado de valores
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Gracias por su opinión. Ya no verá estas sugerencias.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · En { $daysUntilStart } días
       *[other] { $name } · En { $daysUntilStart } días
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Empieza en { $daysUntilStart } días
       *[other] { $name } · Empieza en { $daysUntilStart } días
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Termina en { $daysUntilEnd } días
       *[other] { $name } · Termina en { $daysUntilEnd } días
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Hoy
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Termina hoy

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Buscar con { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Buscar en { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Buscar con { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, elegir un buscador
urlbar-searchmode-button-no-engine2 =
    .title = No se ha seleccionado ningún acceso directo, elija un acceso directo
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = La búsqueda de palabras clave está desactivada
urlbar-searchmode-dropmarker2 =
    .title = Elegir un buscador
urlbar-searchmode-bookmarks4 = Marcadores
urlbar-searchmode-tabs4 = Pestañas
urlbar-searchmode-history4 = Historial
urlbar-searchmode-actions4 = Acciones
urlbar-searchmode-bookmarks3 = Marcadores
    .accesskey = M
urlbar-searchmode-tabs3 = Pestañas
    .accesskey = P
urlbar-searchmode-history3 = Historial
    .accesskey = H
urlbar-searchmode-actions3 = Acciones
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Cerrar
urlbar-searchmode-default2 =
    .title = Buscador predeterminado
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Añadir “{ $engineName }”
    .title = Añadir buscador “{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Esta vez buscar con:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Buscar con:
urlbar-searchmode-popup-search-settings2 = Ajustes de búsqueda
urlbar-searchmode-popup-settings2 = Ajustes
urlbar-searchmode-popup-search-settings = Ajustes de búsqueda
    .accesskey = A
urlbar-searchmode-popup-settings = Ajustes
    .accesskey = A

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Buscar marcadores
urlbar-result-action-search-history = Buscar en el historial
urlbar-result-action-search-tabs = Buscar pestañas
urlbar-result-action-search-actions = Buscar acciones
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Cambiar a { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Abrir { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Abrir en una pestaña nueva
    .accesskey = A
urlbar-view-context-menu-open-in-container-tab =
    .label = Abrir en nueva pestaña contenedora
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = Abrir en una ventana nueva
    .accesskey = n
urlbar-view-context-menu-open-in-private-window =
    .label = Abrir en una nueva ventana privada
    .accesskey = p
urlbar-view-context-menu-open-in-tab2 = Abrir en una pestaña nueva
    .accesskey = A
urlbar-view-context-menu-open-in-container-tab2 = Abrir en nueva pestaña contenedora
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = Abrir en una ventana nueva
    .accesskey = n
urlbar-view-context-menu-open-in-private-window2 = Abrir en una nueva ventana privada
    .accesskey = p

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Sugerencias de { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Acciones rápidas
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Búsquedas recientes
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Popular en { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = No mostrar las búsquedas más populares
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = No mostrar las búsquedas más populares
    .accesskey = d
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = No mostrar las búsquedas más populares
    .accesskey = d
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Gracias por su opinión. Ya no verá más búsquedas populares.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Abrir vista de lectura
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Cerrar vista de lectura

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Abrir Picture-in-Picture ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Cerrar Picture-in-Picture ({ $shortcut })
picture-in-picture-panel-header = Picture-in-Picture
picture-in-picture-panel-headline = Este sitio web no recomienda Picture-in-Picture
picture-in-picture-panel-body = Es posible que los vídeos no se muestren como el desarrollador pretendía mientras Picture-in-Picture está activado.
picture-in-picture-enable-toggle =
    .label = Activar de todos modos

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> está ahora en pantalla completa
fullscreen-warning-no-domain = Este documento está ahora en pantalla completa
fullscreen-exit-button = Salir de pantalla completa (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Salir de pantalla completa (esc)
fullscreen-keyboardlock-exit-button = Salir del modo de pantalla completa (mantenga pulsada la tecla Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Salir del modo de pantalla completa (mantenga pulsada la tecla esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> tiene el control de su puntero. Pulse Esc para recuperar el control.
pointerlock-warning-no-domain = Este documento tiene el control del puntero. Pulse Esc para recuperar el control.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Administrar marcadores
bookmarks-recent-bookmarks-panel-subheader = Marcadores recientes
bookmarks-toolbar-chevron =
    .tooltiptext = Mostrar más marcadores
bookmarks-sidebar-content =
    .aria-label = Marcadores
bookmarks-menu-button =
    .label = Menú de marcadores
bookmarks-other-bookmarks-menu =
    .label = Otros marcadores
bookmarks-mobile-bookmarks-menu =
    .label = Marcadores del móvil

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Ocultar panel lateral de marcadores
           *[other] Ver el panel lateral de marcadores
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Ocultar barra de herramientas de marcadores
           *[other] Ver la barra de marcadores
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Ocultar la barra de marcadores
           *[other] Mostrar la barra de marcadores
        }

##

bookmarks-search =
    .label = Buscar marcadores
bookmarks-tools =
    .label = Herramientas de marcadores
bookmarks-subview-edit-bookmark =
    .label = Editar este marcador…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Marcadores
    .toolbarname = Barra de herramientas de marcadores
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Barra de herramientas de marcadores
bookmarks-toolbar-placeholder =
    .title = Elementos de la barra de herramientas de marcadores
bookmarks-toolbar-placeholder-button =
    .label = Elementos de la barra de herramientas de marcadores
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Añadir pestaña actual a marcadores…

## Library Panel items

library-bookmarks-menu =
    .label = Marcadores

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Reparar la codificación de texto
    .tooltiptext = Adivina la codificación de texto correcta a partir del contenido de la página

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Ajustes
    .tooltiptext =
        { PLATFORM() ->
            [macos] Abrir ajustes ({ $shortcut })
           *[other] Abrir ajustes
        }
toolbar-overflow-customize-button =
    .label = Personalizar barra de herramientas…
    .accesskey = P
toolbar-button-email-link =
    .label = Enviar enlace
    .tooltiptext = Enviar por correo un enlace a esta página
toolbar-button-logins =
    .label = Contraseñas
    .tooltiptext = Ver y administrar sus contraseñas guardadas
qrcode-panel-error =
    .message = No se ha podido generar el código QR. Inténtelo de nuevo.
qrcode-copy-button =
    .label = Copiar
qrcode-copy-success =
    .message = Código QR copiado al portapapeles.
qrcode-copy-error =
    .message = No se ha podido copiar el código QR.
qrcode-save-button =
    .label = Guardar
qrcode-window-title = Código QR
qrcode-dialog-title = Código QR
qrcode-image =
    .aria-label = Código QR
qrcode-close-button =
    .aria-label = Cerrar
toolbar-button-save-page =
    .label = Guardar página
    .tooltiptext = Guardar esta página ({ $shortcut })
toolbar-button-open-file =
    .label = Abrir archivo
    .tooltiptext = Abrir un archivo ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Pestañas sincronizadas
    .tooltiptext = Mostrar pestañas de otros dispositivos
toolbar-button-send-tab =
    .label = Enviar pestaña
    .tooltiptext = Enviar la pestaña actual a otro dispositivo
toolbar-button-new-private-window =
    .label = Nueva ventana privada
    .tooltiptext = Abrir una nueva ventana de navegación privada ({ $shortcut })
toolbar-button-share-tab =
    .label = Compartir
    .tooltiptext = Compartir esta página
toolbar-button-tab-groups =
    .label = Grupos de pestañas
    .tooltiptext = Mostrar sus grupos de pestañas
toolbar-button-history =
    .label = Historial
    .tooltiptext = Muestre su historial ({ $shortcut })
toolbar-button-find =
    .label = Buscar
    .tooltiptext = Buscar en esta página ({ $shortcut })
toolbar-button-developer =
    .label = Desarrollador
    .tooltiptext = Abrir herramientas del desarrollador web ({ $shortcut })
toolbar-button-forget =
    .label = Olvidar
    .tooltiptext = Olvidar parte del historial de navegación
toolbar-zoom-controls =
    .label = Controles de tamaño
    .title = Controles de tamaño
toolbar-button-zoom-out =
    .label = Reducir
    .tooltiptext = Reducir tamaño ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Reiniciar nivel de ampliación ({ $shortcut })
toolbar-button-zoom-in =
    .label = Aumentar
    .tooltiptext = Aumentar tamaño ({ $shortcut })
toolbar-edit-controls =
    .label = Controles de edición
    .title = Controles de edición
toolbar-button-cut =
    .label = Cortar
    .tooltiptext = Cortar ({ $shortcut })
toolbar-button-copy =
    .label = Copiar
    .tooltiptext = Copiar ({ $shortcut })
toolbar-button-paste =
    .label = Pegar
    .tooltiptext = Pegar ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = codigoqr-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Cierto audio o vídeo en este sitio usa software DRM, que puede limitar lo que { -brand-short-name } le permite hacer con él.
eme-notifications-drm-content-playing-manage = Administrar ajustes
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = Descartar
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Debe activar DRM para reproducir cierto audio o vídeo en esta página.
eme-notifications-drm-content-disabled-button =
    .label = Activar DRM
    .accesskey = A
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } está instalando componentes necesarios para reproducir el audio o vídeo en esta página. Inténtelo de nuevo más tarde.
decoder-doctor-no-codecs-linux-message = Para reproducir vídeo, puede que necesite instalar los códecs de vídeo necesarios.
decoder-doctor-no-hw-acceleration-message = Para mejorar la calidad del vídeo, puede que necesite instalar el Media Feature Pack de Microsoft.
decoder-doctor-no-pulse-audio-message = Para reproducir sonido, puede que necesite instalar el software PulseAudio necesario.
decoder-doctor-unsupported-libavcodec-message = libavcodec puede ser vulnerable o no compatible, y debería ser actualizado para reproducir vídeo.
decoder-doctor-decode-error-message = Ha sucedido un error al decodificar un recurso multimedia.
decoder-doctor-decode-warning-message = Ha sucedido un error recuperable al decodificar un recurso multimedia.
decoder-doctor-learn-how-link = Saber cómo
decoder-doctor-report-issue-button =
    .label = Informar de problema en sitio
    .accesskey = I
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = El plugin { $pluginName } ha fallado.
plugin-crashed-notification-reload-button =
    .label = Recargar página
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = Enviar un informe de error
    .accesskey = v

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = ¡Sitio engañoso!
safebrowsing-reported-attack-site-message = ¡Este sitio es una web atacante!
safebrowsing-reported-unwanted-site-message = ¡Sitio sospechoso de servir software no deseado!
safebrowsing-reported-harmful-site-message = ¡Sitio identificado como dañino!
safebrowsing-get-me-out-of-here-button =
    .label = ¡Sácame de aquí!
    .accesskey = S
safebrowsing-not-a-deceptive-site-button =
    .label = Este no es un sitio engañoso…
    .accesskey = n
safebrowsing-not-an-attack-site-button =
    .label = No es un sitio atacante…
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Debe iniciar sesión en esta red antes de que pueda acceder a Internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Abrir página de inicio de sesión en la red

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = ¿Quizá quería ir a { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Sí, llévame a { $hostName }
    .accesskey = S

## Password save/update panel

panel-save-update-username-2 =
    .label = Nombre de usuario
panel-save-update-password-2 =
    .label = Contraseña

##

# "More" item in macOS share menu
menu-share-more =
    .label = Más…
menu-share-windows =
    .label = Más opciones
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Copiar enlace
           *[other] Copiar { $count } enlaces
        }
    .accesskey = l
ui-tour-info-panel-close =
    .tooltiptext = Cerrar

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Permitir ventanas emergentes y redirecciones de terceros para { $uriHost }
    .accesskey = P

##

picture-in-picture-hide-toggle =
    .label = Ocultar botón de Picture-in-Picture
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Mover el botón de Picture-in-Picture al lado derecho
    .accesskey = r
picture-in-picture-move-toggle-left =
    .label = Mover el botón de Picture-in-Picture al lado izquierdo
    .accesskey = l

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Área de navegación
navbar-downloads =
    .label = Descargas
navbar-overflow-2 =
    .tooltiptext = Más herramientas
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Imprimir
    .tooltiptext = Imprima esta página… ({ $shortcut })
navbar-home =
    .label = Inicio
    .tooltiptext = Página de inicio de { -brand-short-name }
navbar-library =
    .label = Catálogo
    .tooltiptext = Ver historial, marcadores guardados y más
navbar-search =
    .title = Buscar
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Pestañas del navegador
tabs-toolbar-new-tab =
    .label = Nueva pestaña
tabs-toolbar-list-all-tabs =
    .label = Mostrar todas las pestañas
    .tooltiptext = Mostrar todas las pestañas

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Soltar la pestaña aquí para pegar

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>¿Abrir pestañas anteriores?</strong> Puede restaurar su sesión anterior desde el menú de la aplicación { -brand-short-name } <img data-l10n-name = "icon" />, bajo Historial.
restore-session-startup-suggestion-button = Mostrar cómo

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Su organización ha bloqueado el acceso a archivos locales en este equipo.

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } manda automáticamente algunos datos a { -vendor-short-name } por lo que podemos mejorar su experiencia.
data-reporting-notification-button =
    .label = Elegir qué comparto
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Navegación privada
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Navegación privada
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Prevención de pérdida de datos (DLP) por { $agentName }. Haga clic aquí para obtener más información.
content-analysis-panel-title = Protección de datos
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Su organización usa <b>{ $agentName }</b> para protegerse contra la pérdida de datos. <a data-l10n-name="info">Saber más</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Extensiones
    .tooltiptext = Extensiones

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Extensiones
    .tooltiptext =
        Extensiones
        Se necesitan permisos

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Extensiones
    .tooltiptext =
        Extensiones
        Algunas extensiones no están permitidas

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Extensiones
    .tooltiptext =
        Extensiones
        Algunas extensiones están desactivadas

## Private browsing reset button

reset-pbm-panel-heading2 = ¿Borrar datos e iniciar una nueva sesión privada?
reset-pbm-panel-description2 = Esto borra el historial, las cookies y todos los demás datos del sitio sin cerrar la ventana privada.
reset-pbm-panel-always-ask-checkbox =
    .label = Preguntarme siempre
    .accesskey = a
reset-pbm-panel-cancel-button =
    .label = Cancelar
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = Borrar sesión privada
    .accesskey = i
reset-pbm-panel-complete = Se han eliminado los datos de la sesión privada
reset-pbm-toolbar-button2 =
    .label = Borrar sesión privada
    .tooltiptext = Borrar sesión privada

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = ¿Eliminar todos los datos de navegación?
fire-button-panel-description = Esto elimina el historial, las cookies y los datos del sitio. Se cerrará su sesión en los sitios web. Esta ventana se cerrará y { -brand-short-name } abrirá una nueva.
fire-button-panel-choose-description = Si no desea eliminarlo todo, seleccione datos específicos en su lugar.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Seleccionar…
fire-button-panel-cancel-button =
    .label = Cancelar
    .accesskey = C
fire-button-panel-confirm-button =
    .label = Eliminar todo
    .accesskey = E
fire-button-panel-complete = Se han eliminado los datos de navegación
fire-button-toolbar-button2 =
    .label = Eliminar algunos o todos los datos
    .tooltiptext = Eliminar algunos o todos sus datos de navegación

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } evitó que esta página se recargara automáticamente.
refresh-blocked-redirect-label = { -brand-short-name } evitó que esta página se redireccionara automáticamente hacia otra.
refresh-blocked-allow =
    .label = Permitir
    .accesskey = P

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Nuestras máscaras seguras y fáciles de usar protegen su identidad y evitan el correo no deseado al ocultar su dirección de correo electrónico.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Todos los correos electrónicos enviados a sus máscaras de correo electrónico se reenviarán a <strong>{ $useremail }</strong> (a menos que decida bloquearlos).
firefox-relay-offer-legal-notice = Al hacer clic en “Usar máscara de correo electrónico”, acepta los <label data-l10n-name="tos-url">Términos del servicio</label> y el <label data-l10n-name="privacy-url">Aviso de privacidad </label>.
firefox-relay-offer-legal-notice-1 = Al iniciar sesión y crear una máscara de correo electrónico, acepta los <label data-l10n-name="tos-url">Términos del servicio</label> y el <label data-l10n-name="privacy-url">Aviso de privacidad</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (No verificado)
popup-notification-xpinstall-prompt-learn-more = Descubra más sobre cómo instalar complementos de forma segura
popup-notification-xpinstall-prompt-block-url = Ver detalles
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Permitir que la extensión se ejecute en ventanas privadas
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Compartir datos técnicos y de interacción con el desarrollador de extensiones
    .accesskey = s

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } ha impedido que este sitio abriera una ventana emergente.
       *[other] { -brand-short-name } ha impedido que este sitio abriera { $popupCount } ventanas emergentes.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } ha evitado que este sitio redireccionara.
        [1] { -brand-short-name } ha evitado que este sitio abra una ventana emergente y redireccionara.
        [one] { -brand-short-name } ha evitado que este sitio abra { $popupCount } ventana emergente y redireccionara.
       *[other] { -brand-short-name } ha evitado que este sitio abra { $popupCount } ventanas emergentes y redireccionara.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } ha evitado que este sitio abra más de { $popupCount } ventanas emergentes.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } ha evitado que este sitio abra más de { $popupCount } ventana emergente y redireccionara.
       *[other] { -brand-short-name } ha evitado que este sitio abra más de { $popupCount } ventanas emergentes y redireccionara.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Opciones
           *[other] Preferencias
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] f
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Mostrar '{ $popupURI }'
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Mostrar “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = No se ha podido abrir el diálogo de archivos de Windows. No se ha podido seleccionar ningún archivo o carpeta.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = No se ha podido abrir el diálogo de archivos de Windows. No se ha podido seleccionar ningún archivo o carpeta. El archivo se guardará en { $path }.
file-picker-failed-save-nowhere = No se ha podido abrir el diálogo de archivos de Windows. No se ha podido encontrar ninguna carpeta predeterminada; el archivo no se guardará.
file-picker-crashed-open = El diálogo de archivos de Windows ha fallado. No se ha podido seleccionar ningún archivo o carpeta.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = El diálogo de archivos de Windows ha fallado. El archivo se guardará en { $path }.
file-picker-crashed-save-nowhere = El diálogo de archivos de Windows ha fallado. No se ha podido encontrar ninguna carpeta predeterminada; el archivo no se guardará.
file-picker-crashed-show-in-folder =
    .label = Mostrar en la carpeta
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = Uno o más complementos instalados no se pueden verificar y han sido desactivados.
unsigned-addons-disabled-learn-more =
    .label = Saber más
    .accesskey = S

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Esta página está ralentizando { -brand-short-name }. Para acelerar el navegador, detenga esta página.
process-hang-nonspecific-tab-message = Una página web está ralentizando { -brand-short-name }. Para acelerar el navegador, detenga esa página.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” está ralentizando { -brand-short-name }. Para acelerar el navegador, detenga esa página.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” está ralentizando { -brand-short-name }. Para acelerar el navegador, detenga esa extensión.
process-hang-addon-learn-more =
    .value = Saber más
process-hang-stop-button =
    .label = Detener
    .accesskey = t

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Finalizar la configuración
onboarding-aw-finish-setup-button =
    .label = Finalizar la configuración
    .tooltiptext = Finalizar la configuración de { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Protección mejorada contra rastreo activada
trustpanel-etp-label-disabled = Protección mejorada contra rastreo desactivada
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Protección mejorada contra rastreo: Activada para { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Protección mejorada contra rastreo: Desactivada para { $host }
trustpanel-etp-description-enabled = Si algo parece que no funciona en este sitio, intente desactivar las protecciones.
trustpanel-etp-description-disabled = { -brand-product-name } piensa que las empresas deberían seguirle menos. Bloqueamos tantos rastreadores como podemos cuando se activan las protecciones.
trustpanel-connection-label-secure = Conexión segura
trustpanel-connection-label-insecure = Conexión no segura
trustpanel-header-enabled = { -brand-product-name } está en guardia
trustpanel-description-enabled2 = Está protegido. Si detectamos algo, se lo haremos saber.
trustpanel-header-enabled-insecure = Tenga cuidado en este sitio
trustpanel-description-enabled-insecure = { -brand-product-name } notó algo sospechoso.
trustpanel-header-disabled = Ha desactivado las protecciones
trustpanel-description-disabled = { -brand-product-name } está fuera de servicio. Le sugerimos volver a activar las protecciones.
trustpanel-clear-cookies-button = Limpiar cookies y datos del sitio
trustpanel-privacy-link = Ajustes de privacidad
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Borrar cookies y datos del sitio para { $host }
trustpanel-clear-cookies-description = Eliminar cookies y datos del sitio puede cerrar sesión en los sitios web y limpiar los carritos de compras.
trustpanel-clear-cookies-subview-button-clear = Limpiar
trustpanel-clear-cookies-subview-button-cancel = Cancelar
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Protecciones de conexión para { $host }
trustpanel-siteinformation-morelink = Más información del sitio
trustpanel-blocker-see-all = Ver todo
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Protecciones contra el rastreo para { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = No seguro

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } cree que las empresas deberían seguirle menos. Por eso bloqueamos a todas las que podemos.
trustpanel-blocked-header = { -brand-product-name } bloqueó estos elementos:
trustpanel-tracking-header = { -brand-product-name } permitió estos elementos para que los sitios no fallasen:
trustpanel-tracking-description = Sin rastreadores, algunos botones, formularios y campos de inicio de sesión podrían no funcionar.
trustpanel-insecure-section-header = Su conexión no es segura
trustpanel-insecure-description = Los datos enviados a este sitio no están cifrados. Podrían ser vistos, robados o alterados.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } cookie de rastreo entre sitios
       *[other] { $count } cookies de rastreo entre sitios
    }
trustpanel-list-label-tracking-content = Contenido de rastreo
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } detector de huellas digitales
       *[other] { $count } detectores de huellas digitales
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } rastreador de redes sociales
       *[other] { $count } rastreadores de redes sociales
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } criptominero
       *[other] { $count } criptomineros
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloqueado { $count } rastreador de redes sociales
       *[other] { -brand-product-name } ha bloqueado { $count } rastreadores de redes sociales
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha permitido { $count } rastreador de redes sociales
       *[other] { -brand-product-name } ha permitido { $count } rastreadores de redes sociales
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloqueado { $count } cookie de rastreo entre sitios
       *[other] { -brand-product-name } ha bloqueado { $count } cookies de rastreo entre sitios
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha permitido { $count } cookie de rastreo entre sitios
       *[other] { -brand-product-name } ha permitido { $count } cookies de rastreo entre sitios
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloqueado { $count } rastreador
       *[other] { -brand-product-name } ha bloqueado { $count } rastreadores
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha permitido { $count } rastreador
       *[other] { -brand-product-name } ha permitido { $count } rastreadores
    }
trustpanel-tracking-content-tab-list-header = Estos sitios están intentando rastrearle:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloqueado { $count } detector de huellas digitales
       *[other] { -brand-product-name } ha bloqueado { $count } detectores de huellas digitales
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha permitido { $count } detector de huellas digitales
       *[other] { -brand-product-name } ha permitido { $count } detectores de huellas digitales
    }
trustpanel-fingerprinter-list-header = Estos sitios están tratando de identificarle:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloqueado { $count } criptominero
       *[other] { -brand-product-name } ha bloqueado { $count } criptomineros
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha permitido { $count } criptominero
       *[other] { -brand-product-name } ha permitido { $count } criptomineros
    }
trustpanel-cryptominer-tab-list-header = Estos sitios están tratando de minar criptomonedas:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = ¿Tiene una cuenta en este sitio?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } encontró que este sitio sufrió una filtración de datos en los últimos 12 meses. Averigüe si usted se vio afectado.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Descartar
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Iniciar escaneo gratuito
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> rastreador bloqueado en este sitio
       *[other] <span data-l10n-name="count">{ $count }</span> rastreadores bloqueados en este sitio
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>¿El sitio web no funciona correctamente?</strong> Recargue la página para reducir temporalmente su protección contra el rastreo.
reduced-protection-infobar-reload-button = Recargar
    .accesskey = R
reduced-protection-infobar-never-show-button = No volver a mostrar
    .accesskey = N


identity-allow-site-data = Guardar siempre las cookies y los datos de esta página web
urlbar-webgl-notification-anchor =
    .tooltiptext = Gestionar el permiso de creación de contextos WebGL
urlbar-webgl-blocked =
    .tooltiptext = Has bloqueado la creación de contextos WebGL para este sitio web.
