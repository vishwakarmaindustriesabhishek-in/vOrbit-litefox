# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Decir a los sitios web que no vendan ni compartan mis datos
    .accesskey = s
non-technical-privacy-group =
    .label = Preferencias de privacidad del sitio web
do-not-track-removal3 =
    .message = Ya no admitimos la función “No rastrear”.
non-technical-privacy-heading =
    .label = Protecciones adicionales
preferences-privacy-relay-available =
    .description = Se oculta la dirección de correo electrónico real para proteger su bandeja de entrada del spam.
    .label = Sugerir máscaras de correo electrónico de { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Ajustes
category-nav-heading =
    .heading = Ajustes
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Buscar en ajustes
    .style = width: 15.4em
managed-notice = Su navegador está siendo administrado por su organización.
managed-notice-info-icon =
    .alt = Información
managed-notice-nav =
    .label = Su navegador está siendo administrado por su organización.
tls-key-logging-notice-nav =
    .label = Una aplicación o servicio puede ver el tráfico cifrado.
category-list =
    .aria-label = Categorías
pane-general-title = General
pane-home-title = Inicio
pane-home-startup-title2 = Inicio
    .title = Inicio
pane-search-title2 = Buscar
    .title = Buscar
pane-privacy-title3 = Privacidad & Seguridad
    .title = Privacidad & Seguridad
pane-privacy-section =
    .heading = Privacidad & Seguridad
pane-sync-title3 = Sincronización
pane-ai-controls-title2 = Controles de IA
    .title = Controles de IA
pane-about-firefox-title = Acerca de { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Apariencia
    .title = { pane-appearance-title }
pane-downloads-title2 = Descargas
    .title = Descargas
pane-downloads3 =
    .heading = Descargas
pane-accessibility-title = Accesibilidad
    .title = { pane-accessibility-title }
pane-languages-title2 = Idiomas
    .title = Idiomas
preferences-languages-header3 =
    .heading = Idiomas
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = ¡Pruebe nuestras funciones experimentales! Están en desarrollo y evolucionando, lo que podría afectar el funcionamiento de { -brand-short-name }. Solo recibimos datos sobre el uso que hace de estas funciones si tiene <a data-l10n-name="data-collection">datos técnicos y de interacción</a> activados.
pane-experimental-reset =
    .label = Restaurar predeterminados
    .accesskey = R
help-button-label2 = Asistencia de { -brand-short-name }
    .title = Asistencia de { -brand-short-name }
addons-button-label2 = Extensiones y temas
    .title = Extensiones y temas
focus-search =
    .key = f
close-button =
    .aria-label = Cerrar
do-not-track-removal2 =
    .label = Ya no admitimos la señal “No rastrear”
applications-setting-new-file-types =
    .label = ¿Qué debería hacer { -brand-short-name } con otros archivos?

## Browser Restart Dialog

feature-enable-requires-restart = { -brand-short-name } debe ser reiniciado para activar esta característica.
feature-disable-requires-restart = { -brand-short-name } debe ser reiniciado para activar esta característica.
should-restart-title = Reiniciar { -brand-short-name }
should-restart-ok = Reiniciar { -brand-short-name } ahora
cancel-no-restart-button = Cancelar
restart-later = Reiniciar más tarde

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla este ajuste.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla este ajuste.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> requiere pestañas contenedoras.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla este ajuste.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla cómo se conecta { -brand-short-name } a Internet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Para activar la extensión vaya a Complementos <img data-l10n-name="addons-icon"/> en el menú <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Para volver a activar esta extensión visite <a data-l10n-name="addons-link">Extensiones y temas</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } controla algunas de las configuraciones de su página de inicio.

## Preferences UI Search Results

search-results-header = Resultados de la búsqueda
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = ¡Lo sentimos! No hay resultados para "<span data-l10n-name="query"></span>" en los ajustes.
search-results-help-link = ¿Necesita ayuda? Visite <a data-l10n-name="url">Ayuda de { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Comprobar siempre si { -brand-short-name } es su navegador predeterminado
    .accesskey = o
startup-restore-windows-and-tabs =
    .label = Abrir ventanas y pestañas anteriores
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = Active esta preferencia marcando “{ profile-manager-use-selected.label }” en la ventana “Seleccionar perfil de usuario”.
windows-launch-on-login =
    .label = Abrir { -brand-short-name } automáticamente al iniciar el ordenador
    .accesskey = A
windows-launch-on-login-disabled = Esta opción se ha desactivado en Windows. Para cambiarla, visite <a data-l10n-name="startup-link">Aplicaciones de inicio</a> en la configuración del sistema.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = También abrir una nueva pestaña
    .accesskey = n
disable-extension =
    .label = Desactivar extensión
preferences-data-migration-group =
    .description = Traiga sus marcadores, contraseñas, historial, extensiones y datos de autocompletado desde otro navegador.
    .label = Importar datos del navegador
preferences-data-migration-button =
    .label = Importar datos
    .accesskey = m
preferences-profiles-group-header =
    .heading = Perfiles
preferences-profiles-subpane-description =
    .description = Cada perfil tiene datos de navegación y configuraciones separadas, incluyendo historial, contraseñas y más.
preferences-profiles-section-header =
    .description = Cada perfil tiene datos de navegación y configuraciones separadas, incluyendo historial, contraseñas y más.
    .label = Perfiles
preferences-manage-profiles-button =
    .label = Administrar perfiles
preferences-profiles-settings-button =
    .label = Ajustes
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = El nuevo perfil copiará los ajustes, los complementos, el historial y datos guardados como marcadores y contraseñas — pero no copiará la información de su cuenta ni de la sincronización.
    .label = Copiar un perfil existente
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Perfil a copiar
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Seleccionar perfil
preferences-copy-profile-button = Copiar
tabs-browsing-section =
    .heading = Pestañas y navegación
pane-tabs-browsing-title2 = Pestañas y navegación
    .title = Pestañas y navegación
tabs-group-header2 =
    .label = Pestañas
tabs-opening-heading =
    .label = Abrir
tabs-interaction-heading =
    .label = Interacción
tabs-containers-heading =
    .label = Contenedores
tabs-closing-heading =
    .label = Cerrar
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab pasa por las pestañas en orden de uso reciente
    .accesskey = T
open-new-link-as-tabs =
    .label = Abrir enlaces en pestañas en lugar de en ventanas nuevas
    .accesskey = v
open-external-link-next-to-active-tab =
    .label = Abrir enlaces de aplicaciones junto a su pestaña activa
ask-on-close-multiple-tabs =
    .label = Preguntar antes de cerrar múltiples pestañas
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Preguntar antes de salir con { $quitKey }
    .accesskey = a
warn-on-open-many-tabs =
    .label = Advertirle cuando al abrir múltiples pestañas se pueda ralentizar { -brand-short-name }
    .accesskey = v
switch-to-new-tabs-2 =
    .label = Al abrir enlaces o medios en una nueva pestaña, cambiar a ella inmediatamente
    .accesskey = b
show-tabs-in-taskbar =
    .label = Mostrar miniaturas de las pestañas en la barra de tareas de Windows
    .accesskey = ñ
browser-containers-enabled-2 =
    .label = Usar pestañas contenedoras
    .accesskey = n
browser-containers-learn-more = Saber más
browser-containers-settings-2 =
    .label = Administrar ajustes
    .accesskey = i
containers-disable-alert-title = ¿Cerrar todas las pestañas contenedoras?
startup-group =
    .label = Inicio

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Si desactiva las pestañas contenedores ahora, se cerrará { $tabCount } pestaña contenedora. ¿Está seguro de que quiere desactivar las pestañas contenedoras?
       *[other] Si desactiva las pestañas contenedores ahora, se cerrarán { $tabCount } pestañas contenedoras. ¿Está seguro de que quiere desactivar las pestañas contenedoras?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Cerrar { $tabCount } pestaña contenedora
       *[other] Cerrar { $tabCount } pestañas contenedoras
    }

##

containers-disable-alert-cancel-button = Mantener activadas
containers-remove-alert-title = ¿Eliminar este contenedor?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Si elimina este contenedor ahora, se cerrará { $count } pestaña contenedora. ¿Está seguro de que quiere eliminar este contenedor?
       *[other] Si elimina este contenedor ahora, se cerrarán { $count } pestañas contenedoras. ¿Está seguro de que quiere eliminar este contenedor?
    }
containers-remove-ok-button = Eliminar este contenedor
containers-remove-cancel-button = No eliminar este contenedor
settings-tabs-show-image-in-preview =
    .label = Mostrar una vista previa al pasar el cursor sobre una pestaña
    .accessKey = M
settings-tabs-drag-to-create-tab-groups =
    .label = Arrastre las pestañas para crear grupos de pestañas
browser-layout-header2 =
    .label = Disposición del navegador
browser-layout-horizontal-tabs2 =
    .description = Pestañas en la parte superior
    .label = Pestañas horizontales
    .title = Pestañas en la parte superior
browser-layout-vertical-tabs2 =
    .description = Pestañas en el lateral, en la barra lateral
    .label = Pestañas verticales
    .title = Pestañas en el lateral, en la barra lateral
browser-layout-show-sidebar2 =
    .description = Acceda rápidamente a marcadores, pestañas de su teléfono, chatbots de IA y más sin salir de la vista principal.
    .label = Mostrar barra lateral
page-navigation-group =
    .label = Navegación entre páginas

## General Section - Language & Appearance

language-and-appearance-header = Idioma y apariencia
appearance-group2 =
    .description = Algunos sitios web cambian sus colores para coincidir con las preferencias. Elija su esquema de color.
    .label = Apariencia del sitio web
preferences-web-appearance-choice-auto3 =
    .label = Sistema
    .title = Cambiar automáticamente fondos y contenido de sitios web basándose en la configuración de su sistema y el tema de { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Claro
    .title = Usar una apariencia clara para los fondos y el contenido del sitio web.
preferences-web-appearance-choice-dark2 =
    .label = Oscuro
    .title = Usar una apariencia oscura para los fondos y el contenido del sitio web.
web-appearance-group =
    .aria-label = Apariencia del sitio web
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Sus ajustes de contraste prevalecen sobre la apariencia del sitio web.
preferences-web-appearance-link =
    .label = Administre los temas de { -brand-short-name } en Extensiones y temas
preferences-contrast-control-group =
    .description = Los sitios web utilizan una variedad de colores de primer plano y de fondo. Para lograr un contraste uniforme, puede utilizar los mismos colores en todos los sitios web.
    .label = Contraste de sitios web
preferences-contrast-control-radio-group =
    .label = Reemplazar colores
preferences-contrast-control-use-platform-settings =
    .label = Automático (utilizar la configuración del sistema)
    .accesskey = A
preferences-contrast-control-off =
    .label = Desactivado
    .accesskey = D
preferences-contrast-control-custom =
    .label = Personalizado
    .accesskey = P
preferences-colors-manage-button2 =
    .label = Administrar colores
    .accesskey = c
preferences-colors-manage-button =
    .label = Administrar colores…
    .accesskey = c
preferences-fonts-header2 =
    .label = Tipos de letra
preferences-default-zoom-label =
    .label = Ampliación predeterminada
    .accesskey = A
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Sólo ampliar texto
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Si la opción “Ampliar solo texto” está activada y el nivel de zoom predeterminado no es del 100%, es posible que algunos sitios web no muestren el contenido correctamente.
language-header = Idioma
choose-language-description = Elegir el idioma preferido para mostrar las páginas web
website-language-heading =
    .description = Algunas página se muestran en múltiples idiomas. Seleccione idiomas en el orden que prefiera.
    .label = Idioma del sitio web
website-preferred-language =
    .label = Idiomas preferidos
website-add-language =
    .label = Añadir idioma
website-add-language-button =
    .aria-label = Añadir idioma seleccionado
    .title = Añadir idioma seleccionado
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Eliminar { $locale }
    .title = Eliminar { $locale }
choose-button =
    .label = Seleccionar…
    .accesskey = o
choose-browser-language-description = Seleccione los idiomas en los que se mostrarán los menús, mensajes y notificaciones de { -brand-short-name }.
manage-browser-languages-button =
    .label = Establecer alternativas…
    .accesskey = l
confirm-browser-language-change-description = Reinicie { -brand-short-name } para aplicar los cambios
confirm-browser-language-change-button = Aplicar y reiniciar
browser-language-heading =
    .description = Elija el idioma usado para mostrar menús,  mensajes y notificaciones de { -brand-short-name }.
    .label = Idioma del navegador
browser-language-preferred-label =
    .label = Idioma preferido
browser-language-fallback-label =
    .description = Usado cuando la localización del idioma preferido está incompleta.
    .label = Idioma alternativo
browser-language-install-error =
    .message = { -brand-short-name } no puede actualizar sus idiomas en este momento. Compruebe que esté conectado a internet o vuelva a intentarlo.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Excepciones…
    .accesskey = x
settings-translations-header =
    .aria-label = Traducciones
    .description = Traduzca páginas o texto seleccionado. Para proteger su privacidad, las traducciones permanecen en su dispositivo.
    .label = Traducciones
settings-translations-offer-to-translate-label =
    .label = Ofrecer traducción de página completa
settings-translations-more-settings-button =
    .description = Configure las preferencias de idiomas, sitios web y traducción sin conexión.
    .label = Más ajustes de traducción
settings-translations-subpage-header =
    .heading = Más ajustes de traducción
settings-translations-subpage-speed-up-translation-header =
    .description = Descargue idiomas completos para traducir más rápido y sin conexión.
    .label = Acelerar la traducción
settings-translations-subpage-automatic-translation-header =
    .label = Traducción automática
settings-translations-subpage-always-translate-header =
    .label = Siempre traducir estos idiomas
settings-translations-subpage-never-translate-header =
    .label = Nunca traducir estos idiomas
settings-translations-subpage-never-translate-sites-header =
    .label = No traducir nunca estos sitios
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Para añadir un sitio, abra el <img data-l10n-name="translations-icon"/> panel de traducción, seleccione los <img data-l10n-name="settings-icon"/> ajustes de traducción y luego elija “Nunca traducir sitio”
settings-translations-subpage-language-select-option =
    .label = Añadir idioma
settings-translations-subpage-language-add-button =
    .aria-label = Añadir idioma
    .title = Añadir idioma
settings-translations-subpage-download-languages-header =
    .label = Descargar idiomas
settings-translations-subpage-download-languages-select-option =
    .label = Seleccionar idioma
settings-translations-subpage-download-languages-button =
    .aria-label = Descargar idioma
    .title = Descargar idioma
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = No hay idiomas descargados
settings-translations-subpage-no-languages-added =
    .label = No hay idiomas añadidos
settings-translations-subpage-download-progress = Descarga en curso…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = No se pudo descargar { $language } ({ $size }MB)
settings-translations-subpage-download-retry-button =
    .label = Reintentar
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = ¿Eliminar { $language } ({ $size }MB)?
settings-translations-subpage-download-delete-button =
    .label = Eliminar
settings-translations-subpage-download-cancel-button =
    .label = Cancelar
settings-translations-subpage-no-sites-added =
    .label = No hay sitios añadidos
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Usar la configuración de su sistema operativo para “{ $localeName }” para dar formato a fechas, horas, números y medidas.
settings-spellcheck-header =
    .label = Corrector ortográfico
check-user-spelling =
    .label = Revisar la ortografía según escribe
    .accesskey = v
spellcheck-download-dictionaries =
    .label = Descargar diccionarios
spellcheck-promo =
    .heading = Cómo usar el corrector ortográfico
    .message = Haga clic en un campo de texto para activar o desactivar el corrector ortográfico o para cambiar el idioma. No todos los campos permiten uso del corrector ortográfico.

## Downloads - Files and applications

files-and-applications-title = Archivos y aplicaciones
download-save-files-header =
    .label = Guardar archivos en
download-save-where-3 =
    .aria-label = Guardar archivos en
download-always-ask-where2 =
    .label = Preguntar dónde guardar archivos antes de descargar.
    .accesskey = P
download-private-browsing-delete2 =
    .label = Eliminar las descargas de la ventana privada al cerrarla
    .accesskey = E
applications-header = Aplicaciones
applications-description = Elija cómo gestiona { -brand-short-name } los archivos que usted descarga de la web o las aplicaciones que usa mientras navega.
applications-setting2 =
    .description = Elija cómo { -brand-short-name } maneja los archivos y contenidos descargados.
    .label = Archivos y aplicaciones
applications-filter =
    .placeholder = Buscar tipos de archivo o aplicaciones
applications-type-column =
    .label = Tipo de contenido
    .accesskey = T
applications-type-heading = Tipo de contenido
applications-action-column =
    .label = Acción
    .accesskey = A
applications-action-heading = Acción
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = archivo { $extension }
applications-action-save =
    .label = Guardar archivo
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Usar { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Usar { $app-name } (predeterminado)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Usar la aplicación predeterminada de macOS
            [windows] Usar la aplicación predeterminada de Windows
           *[other] Usar la aplicación predeterminada del sistema
        }
applications-use-other =
    .label = Usar otra…
applications-select-helper = Seleccione aplicación auxiliar
applications-manage-app =
    .label = Detalles de la aplicación…
applications-always-ask =
    .label = Preguntar siempre
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Abrir en { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = ¿Qué debería hacer { -brand-short-name } con otros archivos?
applications-save-for-new-types =
    .label = Guardar archivos
    .accesskey = s
applications-save-for-new-types2 =
    .label = Guardar archivos automáticamente
    .accesskey = G
applications-ask-before-handling =
    .label = Preguntar si abrir o guardar archivos
    .accesskey = a
applications-ask-before-handling2 =
    .label = Preguntar para abrir o guardar archivos
    .accesskey = a
drm-group =
    .label = Contenido sujeto a administración de derechos de autor (DRM)
play-drm-content =
    .label = Reproducir contenido controlado por DRM
    .accesskey = R
play-drm-content-learn-more = Saber más
# Variables:
# $version (string) - Firefox version
update-application-version = Versión { $version } <a data-l10n-name="learn-more">Novedades</a>
update-history-2 =
    .label = Mostrar historial de actualizaciones
    .accesskey = M
update-application-installation =
    .label = Instalación
update-application-radio-group =
    .aria-label = Instalación
update-application-auto-2 =
    .label = Instalar actualizaciones automáticamente (recomendado)
    .accesskey = a
update-application-check-choose-2 =
    .label = Buscar actualizaciones, pero elegir cuándo instalarlas
    .accesskey = c
update-application-background-enabled =
    .label = Cuando { -brand-short-name } no se esté ejecutando
    .accesskey = C
update-application-warning-cross-user-setting-2 =
    .message = Esta configuración se aplicará a todas las cuentas de Windows y los perfiles { -brand-short-name } usando esta instalación de { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Mostrar menos recordatorios de actualizaciones
    .accesskey = n
update-setting-write-failure-title2 = Error al guardar los ajustes de actualización
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } ha encontrado un error y no ha guardado este cambio.  Tenga en cuenta que establecer este ajuste de actualización requiere permiso para escribir en el archivo indicado a continuación. Usted o un administrador del sistema pueden resolver el error otorgando al grupo de Usuarios el control total de este archivo.
    
    No se puede escribir en el archivo: { $path }
update-in-progress-title = Actualización en curso
update-in-progress-message = ¿Quiere que { -brand-short-name } continúe con la actualización?
update-in-progress-ok-button = &Ignorar
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Continuar

## About Firefox

about-firefox-header =
    .heading = Acerca de { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Las actualizaciones mejoran la velocidad, estabilidad y seguridad de { -brand-short-name }.
    .label = Actualizaciones de { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Notificaciones
update-application-updates-managed-by-os =
    .message = Las actualizaciones son administradas por el sistema operativo

## Firefox support

support-application-heading =
    .description = Resuelve problemas o comparte ideas con la comunidad.
    .label = Asistencia de { -brand-short-name }
support-get-help =
    .label = Obtener ayuda
support-share-ideas =
    .label = Compartir ideas y opiniones

## General Section - Performance

performance-settings-learn-more = Saber más
performance-allow-hw-accel =
    .label = Usar aceleración de hardware cuando esté disponible
    .accesskey = r
performance-limit-content-process-option = Límite de procesos de contenido
    .accesskey = L
performance-limit-content-process-enabled-desc = Más procesos de contenido pueden mejorar el rendimiento al usar múltiples pestañas, pero también usarán más memoria.
performance-limit-content-process-blocked-desc = Modificar el número de procesos de contenido solo es posible con { -brand-short-name } multiproceso. <a data-l10n-name="learn-more">Sepa cómo comprobar si el multiproceso está activado</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (predeterminado)
performance-group =
    .label = Rendimiento
performance-use-recommended-settings-checkbox-2 =
    .description = Estas configuraciones son a medida del hardware y sistema operativo.
    .label = Usar ajustes de rendimiento recomendados
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = Usar desplazamiento automático
    .accesskey = a
keyboard-and-scrolling-group =
    .label = Navegación y desplazamiento por teclado
motion-and-link-group =
    .label = Estilo de movimiento y enlaces
browsing-use-smooth-scrolling =
    .label = Usar desplazamiento suave
    .accesskey = v
browsing-gtk-use-non-overlay-scrollbars =
    .label = Mostrar siempre las barras de desplazamiento
    .accesskey = o
browsing-always-underline-links =
    .label = Siempre subrayar los enlaces
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = Mostrar un teclado táctil cuando sea necesario
    .accesskey = s
browsing-use-cursor-navigation =
    .label = Usar siempre las teclas del cursor para navegar dentro de las páginas
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = Use la tecla de tabulación para mover el foco entre los controles de formulario y los enlaces
    .accesskey = t
browsing-search-on-start-typing =
    .label = Buscar texto cuando comience a escribir
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = Controle cómo se mueve e interactúa con { -brand-short-name }.
    .label = Atajos de teclado
settings-keyboard-shortcuts-customkeys-link =
    .label = Personalizar los atajos de teclado
settings-media-group =
    .label = Medios
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Usar Picture-in-Picture
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Seguir reproduciendo vídeos en modo picture-in-picture al cambiar de pestaña
    .accesskey = S
browsing-media-control =
    .label = Controlar los medios con el teclado, los auriculares o la interfaz virtual
    .accesskey = v
recommendations-group =
    .label = Recomendaciones
browsing-cfr-recommendations =
    .label = Recomendar extensiones mientras se navega
    .accesskey = R
browsing-cfr-features =
    .label = Recomendar funciones mientras navega
    .accesskey = R
browsing-group =
    .label = Navegación
preferences-accessibility-header =
    .heading = Accesibilidad
preferences-default-zoom-select =
    .aria-label = Ampliación predeterminada
preferences-fonts-family =
    .label = Familia tipográfica
    .accesskey = D
preferences-fonts-size =
    .label = Tamaño de letra
    .accesskey = l
preferences-fonts-advanced-settings =
    .label = Ajustes avanzados
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .description = Configure cómo { -brand-short-name } se conecta al internet.
    .label = Configuración de proxy
network-proxy-connection-settings2 =
    .description = Cambiar estos ajustes puede ocasionar problemas de conectividad
    .label = Configurar proxy
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Nuevas ventanas y pestañas
home-new-windows-tabs-description2 = Elija qué ver al abrir su página de inicio, nuevas ventanas y nuevas pestañas.
home-section =
    .heading = Inicio

## Home Section - Default Browser

home-default-browser-title =
    .label = Navegador predeterminado
is-default-browser-2 =
    .message = { -brand-short-name } es su navegador predeterminado. Buena elección.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } no es su navegador predeterminado.
set-as-my-default-browser-2 =
    .label = Convertir en predeterminado
    .accesskey = C

## Custom Homepage subpage

home-homepage-mode-label = Página de inicio y ventanas nuevas
home-newtabs-mode-label = Nuevas pestañas
home-restore-defaults =
    .label = Restaurar ajustes predeterminados
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Predeterminado)
home-mode-choice-custom =
    .label = URLs personalizadas…
home-mode-choice-blank =
    .label = Página en blanco
home-homepage-custom-url =
    .placeholder = Pegar URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Gestionar extensión
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Usar página actual
           *[other] Usar páginas actuales
        }
    .accesskey = C
choose-bookmark =
    .label = Usar marcador…
    .accesskey = m
home-homepage-title =
    .label = Página de inicio
home-homepage-new-windows =
    .label = Nuevas ventanas
home-homepage-new-tabs =
    .label = Nuevas pestañas
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Elija un sitio específico
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Dirección(es) del sitio web
home-custom-homepage-address =
    .placeholder = Introducir dirección
home-custom-homepage-address-button =
    .label = Añadir dirección
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = No hay sitios web añadidos todavía
home-custom-homepage-delete-address-button =
    .aria-label = Eliminar dirección
    .title = Eliminar dirección
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Reemplazar con
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Páginas abiertas actualmente
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Marcadores…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Extensión ({ $extension })
home-custom-homepage-header = Página de inicio personalizada
home-custom-homepage-subpage =
    .heading = Página de inicio personalizada

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Contenido de { -firefox-home-brand-name }
home-prefs-content-description2 = Seleccione el contenido que desea en la pantalla de inicio de { -firefox-home-brand-name }.
home-prefs-search-header =
    .label = Búsqueda web
home-prefs-shortcuts-header =
    .label = Accesos directos
home-prefs-shortcuts-description = Sitios que guarda o visita
home-prefs-shortcuts-by-option-sponsored =
    .label = Accesos directos patrocinados
home-prefs-recommended-by-header-generic =
    .label = Historias recomendadas
home-prefs-recommended-by-description-generic = Contenido excepcional seleccionado por la familia { -brand-product-name }
home-prefs-stories-header =
    .label = Historias
home-prefs-stories-description = Historias personalizadas basadas en su actividad

##

home-prefs-recommended-by-learn-more = Cómo funciona
home-prefs-recommended-by-option-sponsored-stories =
    .label = Historias patrocinadas
home-prefs-highlights-option-visited-pages =
    .label = Páginas visitadas
home-prefs-highlights-options-bookmarks =
    .label = Marcadores
home-prefs-highlights-option-most-recent-download =
    .label = Descargas más recientes
home-prefs-recent-activity-header =
    .label = Actividad reciente
home-prefs-recent-activity-description = Una selección de sitios y contenidos recientes
home-prefs-weather-header =
    .label = El tiempo
home-prefs-weather-description = El pronóstico para hoy de un vistazo
home-prefs-weather-learn-more-link = Saber más
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Apoyar a { -brand-product-name }
home-prefs-mission-message = Nuestros patrocinadores apoyan nuestra misión de construir una web mejor
home-prefs-mission-message-learn-more-link = Descubra cómo
home-prefs-manage-topics-link = Administrar temas
home-prefs-choose-wallpaper-link = Elija un fondo de pantalla
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } fila
           *[other] { $num } filas
        }

## Search Section

search-show-suggestions-option =
    .label = Mostrar sugerencias de búsqueda
    .accesskey = s
search-show-suggestions-url-bar-option =
    .label = Mostrar sugerencias de búsqueda en los resultados de la barra de direcciones
    .accesskey = M
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Mostrar sugerencias de búsqueda antes del historial de navegación en los resultados de la barra de direcciones
search-show-suggestions-private-windows-2 =
    .label = Mostrar sugerencias de búsqueda en ventanas privadas
search-suggestions-cant-show-2 =
    .message = Las sugerencias de búsqueda no se mostrarán en los resultados de la barra de direcciones porque ha configurado { -brand-short-name } para que nunca recuerde el historial.
addressbar-header-1 =
    .description = Elija qué sugerencias se muestran en su barra de direcciones
    .label = Barra de direcciones
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Sugerencias de { -brand-short-name } y nuestros socios en su barra de direcciones.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Mostrar términos de búsqueda en la barra de direcciones en las páginas de resultados
search-separate-default-engine-2 =
    .label = Usar un buscador predeterminado diferente en ventanas privadas
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = Buscador predeterminado en ventanas privadas
search-suggestions-header-2 =
    .label = Sugerencias del buscador
search-one-click-header2 = Atajos de búsqueda
search-one-click-desc = Elija los buscadores alternativos que aparecen bajo las barras de direcciones y de búsqueda cuando comienza a escribir una palabra clave.
search-one-click-header-3 =
    .description = Elija qué buscadores y atajos aparecen en su barra de direcciones.
    .label = Buscadores adicionales
update-search-engine-success =
    .message = Buscador actualizado correctamente
search-edit-engine-2 =
    .title = Editar buscador
search-delete-engine =
    .title = Eliminar buscador
search-enable-engine =
    .title = Acivar buscador
search-outlink-to-extensions-page =
    .title = Administrar en extensiones y temas
search-choose-engine-column =
    .label = Buscador
search-choose-keyword-column =
    .label = Palabra clave
search-restore-default =
    .label = Restaurar buscadores predeterminados
    .accesskey = R
search-remove-engine =
    .label = Eliminar
    .accesskey = E
search-add-engine =
    .label = Añadir
    .accesskey = A
search-add-engine-2 =
    .label = Añadir buscador
    .accesskey = A
search-edit-engine =
    .label = Editar
    .accesskey = E
search-find-more-link = Encontrar más buscadores
search-filtering-for-add-engine = Añadir buscador
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Palabra clave duplicada
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Ha seleccionado una palabra clave que está siendo usada por "{ $name }". Por favor, seleccione otra.
search-keyword-warning-bookmark = Ha seleccionado una palabra clave que está siendo usada por otro marcador. Por favor, seleccione otra.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Ya existe un buscador con el nombre "{ $name }". Por favor elija otro nombre.
remove-engine-confirmation = ¿Está seguro de querer eliminar este buscador?
remove-engine-remove = Eliminar
remove-addon-engine-alert = Para eliminar este buscador, elimine el complemento asociado.
search-engine-group =
    .label = Buscador predeterminado
search-default-engine =
    .aria-label = Buscador predeterminado
# Header for the search section ("search" is a noun).
search-section =
    .heading = Buscar

## Containers Section

containers-section-header2 =
    .heading = Ajustes del contenedor
containers-card-header2 =
    .description = Separar las cookies por contenedor para poder utilizar diferentes cuentas en el mismo sitio web y limitar el seguimiento entre sitios.
    .label = Contenedores
containers-add-button2 =
    .label = Añadir nuevo contenedor
    .accesskey = A
containers-new-tab-check3 =
    .label = Seleccionar un contenedor para cada nueva pestaña
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = No usar contenedores para enlaces abiertos desde aplicaciones externas
    .accesskey = N
containers-new-tab-check2 =
    .description = Esto abrirá el menú de contenedores cada vez que presione el botón de abrir nueva pestaña.
    .label = Selecciona un contenedor para cada pestaña nueva
    .accesskey = S
containers-settings-button2 =
    .title = Ajustes
containers-remove-button3 =
    .title = Eliminar
containers-sites-card-header =
    .description = Elia un contenedor para un sitio y { -brand-short-name } lo utilizará cada vez que se abra el sitio.
    .label = Contenedores específicos del sitio
containers-sites-add-button =
    .label = Añadir sitio web
    .accesskey = A
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Contenedor para { $site }
containers-site-remove-button =
    .title = Eliminar
containers-remove-button2 =
    .title = Eliminar

## Account and sync

sync-group-label =
    .label = Sincronización
account-group-label2 =
    .label = Cuenta
account-disabled-group =
    .description = Los ajustes de la cuenta no están disponibles.
    .label = Cuenta
account-placeholder2 =
    .description = Inicie sesión y mantenga sus datos privados, cifrados y accesibles al instante dondequiera que use { -brand-short-name }.
    .label = No ha iniciado sesión
account-sync-section =
    .heading = Cuenta y sincronización
pane-account-sync-title2 = Cuenta y sincronización
    .title = Cuenta y sincronización

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Llévese la web con usted
sync-signedout-description2 = Sincronice sus marcadores, historial, pestañas, contraseñas, complementos y ajustes en todos sus dispositivos.
sync-signedout-account-signin3 =
    .label = Iniciar sesión para sincronizar…
    .accesskey = I
sync-signedout-account-signin-4 =
    .label = Iniciar sesión en la cuenta para empezar a sincronizar
    .accesskey = I
sync-signedout-account-short =
    .label = Iniciar sesión
    .accesskey = I
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Descargar Firefox para <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> o <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> para sincronizar con su dispositivo móvil.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Cambiar imagen del perfil
    .tooltiptext = Cambiar imagen del perfil
sync-profile-picture-account-problem =
    .alt = Foto de perfil de la cuenta
fxa-login-rejected-warning =
    .alt = Advertencia
sync-sign-out =
    .label = Cerrar sesión…
    .accesskey = C
sync-sign-out2 =
    .label = Cerrar sesión
    .accesskey = C
sync-manage-account = Administrar cuenta
    .accesskey = A
sync-manage-account2 =
    .label = Administrar cuenta
    .accesskey = A

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } no está verificado.
sync-signedin-unverified2 =
    .description = Revise su bandeja de entrada para confirmar su cuenta y hacerla oficial.
    .label = { $email } todavía no está confirmado
sync-signedin-login-failure = Inicie sesión para reconectar { $email }
sync-signedin-login-failure2 =
    .description = Vuelva a iniciar sesión para volver a conectarse y comenzar a sincronizar sus datos.
    .label = Ha cerrado sesión en { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Verificar cuenta
    .accesskey = V
sync-remove-account =
    .label = Eliminar cuenta
    .accesskey = E
sync-sign-in =
    .label = Conectarse
    .accesskey = n

## Sync section - enabling or disabling sync.

prefs-syncing-on = Sincronización: ACTIVADA
prefs-syncing-on-2 =
    .label = Sincronización ACTIVADA
prefs-syncing-off = Sincronización: DESACTIVADA
prefs-syncing-off-2 =
    .description = Active la sincronización para tener sus marcadores, contraseñas, historial y más en cualquier dispositivo.
    .label = Sincronización DESACTIVADA
prefs-sync-turn-on-syncing =
    .label = Activar la sincronización…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Activar la sincronización
    .accesskey = s
prefs-sync-offer-setup-label2 = Sincronice sus marcadores, historial, pestañas, contraseñas, complementos y ajustes en todos sus dispositivos.
prefs-sync-now-button =
    .label = Sincronizar ahora
    .accesskey = N
prefs-sync-now-button-2 =
    .label = Sincronizar ahora
    .accesskey = N
prefs-syncing-button =
    .label = Sincronizando…
prefs-syncing-button-2 =
    .label = Sincronizando…
    .title = Sincronizar ahora

## The list of things currently syncing.

sync-syncing-across-devices-heading = Se están sincronizando estos ítems en todos sus dispositivos conectados:
sync-syncing-across-devices-heading-2 = Datos sincronizados entre dispositivos
sync-syncing-across-devices-empty-state2 =
    .description = No se está sincronizando nada… aún. Empiece a sincronizar para tener todos sus datos en todos sus dispositivos.
    .label = Administrar datos sincronizados
sync-currently-syncing-bookmarks = Marcadores
sync-currently-syncing-history = Historial
sync-currently-syncing-tabs = Pestañas abiertas
sync-currently-syncing-passwords = Contraseña
sync-currently-syncing-addresses = Direcciones
sync-currently-syncing-payment-methods = Métodos de pago
sync-currently-syncing-addons = Complementos
sync-currently-syncing-settings = Ajustes
sync-manage-options =
    .label = Administrar sincronización…
    .accesskey = m
sync-manage-options-2 =
    .label = Administrar datos sincronizados
    .accesskey = m
settings-sync-disconnect-button =
    .label = Desconectar

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Marcadores
    .accesskey = m
sync-engine-history =
    .label = Historial
    .accesskey = r
sync-engine-tabs =
    .label = Pestañas abiertas
    .tooltiptext = Una lista de lo que está abierto en todos los dispositivos sincronizados
    .accesskey = t
sync-engine-passwords =
    .label = Contraseñas
    .tooltiptext = Contraseñas que ha guardado
    .accesskey = C
sync-engine-addresses =
    .label = Direcciones
    .tooltiptext = Direcciones postales que ha guardado (solo escritorio)
    .accesskey = D
sync-engine-payment-methods2 =
    .label = Métodos de pago
    .tooltiptext = Nombres, números de tarjeta y fechas de caducidad
    .accesskey = g
sync-engine-addons =
    .label = Complementos
    .tooltiptext = Extensiones y temas para Firefox de escritorio
    .accesskey = C
sync-engine-settings =
    .label = Ajustes
    .tooltiptext = Cambios en los ajustes de General, Privacidad y Seguridad
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Guardar
    .buttonlabelextra2 = Desconectar…
    .buttonaccesskeyaccept = G
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Administrar lo que se sincroniza entre sus dispositivos conectados

## The device name controls.

sync-device-name-header = Nombre del dispositivo
sync-device-name-header-2 =
    .label = Nombre del dispositivo
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Nombre del dispositivo
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Cambiar nombre del dispositivo
    .accesskey = a
sync-device-name-change =
    .label = Cambiar nombre del dispositivo…
    .accesskey = a
sync-device-name-cancel =
    .label = Cancelar
    .accesskey = e
sync-device-name-save =
    .label = Guardar
    .accesskey = u
sync-connect-another-device = Conectar otro dispositivo
sync-connect-another-device-2 =
    .label = Conectar otro dispositivo

## Privacy Section

privacy-header = Privacidad del navegador

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Contraseñas
    .searchkeywords = inicios de sesión
forms-passwords-header =
    .aria-label = Contraseñas
    .label = Contraseñas
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Preguntar para guardar contraseñas
    .accesskey = a
forms-manage-password-exceptions =
    .label = Administrar excepciones de contraseña
    .accesskey = m
forms-exceptions =
    .label = Excepciones…
    .accesskey = x
forms-suggest-passwords =
    .label = Sugerir contraseñas seguras
    .accesskey = S
forms-breach-alerts =
    .label = Mostrar alertas sobre contraseñas para sitios web comprometidos
    .accesskey = b
forms-breach-alerts-learn-more-link = Saber más
preferences-relay-integration-checkbox2 =
    .label = Sugerir máscaras de correo { -relay-brand-name } para proteger su dirección de correo electrónico
    .accesskey = r
relay-integration-learn-more-link = Saber más
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Completar nombres de usuario y contraseñas automáticamente
    .accesskey = C
forms-fill-usernames-and-passwords-2 =
    .label = Guardar y autocompletar nombres de usuario y contraseñas
    .accesskey = u
forms-saved-passwords =
    .label = Contraseñas guardadas
    .accesskey = d
forms-saved-passwords-2 =
    .label = Administrar contraseñas guardadas
    .accesskey = d
forms-saved-passwords-searchkeywords = Se guardan en su equipo los inicios de sesión de los siguientes sitios
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Protecciones adicionales
forms-primary-pw-use =
    .label = Usar una contraseña maestra
    .accesskey = U
forms-primary-pw-use-2 =
    .description = Añada una capa adicional de seguridad para proteger sus contraseñas guardadas
    .label = Usar una contraseña maestra
    .accesskey = U
forms-primary-pw-set =
    .label = Establecer contraseña maestra
forms-primary-pw-on-2 = La contraseña maestra está <strong>ACTIVADA</strong>
forms-primary-pw-on =
    .label = La contraseña maestra está activada
forms-primary-pw-change-2 =
    .label = Cambiar la contraseña maestra
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Desactivar
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Requerir inicio de sesión en el dispositivo para introducir y administrar contraseñas
forms-os-reauth-2 =
    .label = Requerir inicio de sesión en el dispositivo para administrar contraseñas
forms-primary-pw-learn-more-link = Saber más
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Cambiar contraseña maestra…
    .accesskey = M
forms-primary-pw-change =
    .label = Cambiar la contraseña maestra…
    .accesskey = P
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Se encuentra actualmente en modo FIPS. FIPS requiere una contraseña maestra no vacía.
forms-master-pw-fips-desc = Fallo al cambiar la contraseña
forms-windows-sso =
    .label = Permitir el inicio de sesión único de Windows para Microsoft, cuentas de trabajo y escolares
forms-windows-sso-learn-more-link = Saber más
forms-windows-sso-desc = Administrar cuentas en la configuración de su dispositivo
windows-passkey-settings-label = Administrar claves de acceso en la configuración del sistema
privacy-panel-settings-header =
    .description = Reciba ayuda para proteger su información en línea con { -brand-short-name }
    .label = Ajustes del panel de privacidad
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Mostrar mensajes de filtraciones
    .accesskey = M

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Para crear una contraseña maestra, introduzca sus credenciales de inicio de sesión de Windows. Esto ayuda a proteger la seguridad de sus cuentas.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = crear una contraseña maestra
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] cambiar los ajustes de los métodos de pago
       *[other] { -brand-short-name } está intentando cambiar la configuración de los métodos de pago. Inicie sesión en su dispositivo para autorizar esta acción.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Métodos de pago
autofill-payment-methods-checkbox-message-2 =
    .label = Guardar y autocompletar métodos de pago
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = Administrar métodos de pago
autofill-payment-methods-manage-payments-button =
    .label = Administrar métodos de pago
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Requerir inicio de sesión en el dispositivo para autocompletar y administrar métodos de pago
    .accesskey = o
autofill-payment-methods-add-button = Añadir nuevo método de pago
payments-list-header =
    .label = Métodos de pago
payments-delete-payment-prompt-title = ¿Eliminar este método de pago?
payments-delete-payment-prompt-confirm-button = Eliminar
payments-delete-payment-prompt-cancel-button = Cancelar
payments-delete-payment-button-label =
    .aria-label = Eliminar
payments-edit-payment-button-label =
    .aria-label = Editar
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = No se han añadido métodos de pago
autofill-addresses-checkbox-message =
    .label = Guardar y autocompletar direcciones
    .accesskey = G
autofill-addresses-manage-addresses-button =
    .label = Administrar direcciones y más
    .accesskey = A
addresses-list-header =
    .label = Direcciones
addreses-delete-address-button-label =
    .aria-label = Eliminar
addreses-edit-address-button-label =
    .aria-label = Editar
addresses-delete-address-prompt-title = ¿Eliminar esta dirección?
addresses-delete-address-prompt-confirm-button = Eliminar
addresses-delete-address-prompt-cancel-button = Cancelar
autofill-addresses-add-button = Añadir nueva dirección
autofill-addresses-manage-addresses-title =
    .heading = Administrar direcciones y más
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = No se han añadido direcciones
personal-info-group =
    .label = Información personal
autofill-personal-info-checkbox-message =
    .label = Guardar y autocompletar información personal
autofill-personal-info-manage-button =
    .label = Administrar información personal
passports-list-header =
    .label = Pasaportes
passports-delete-passport-button-label =
    .aria-label = Eliminar
passports-edit-passport-button-label =
    .aria-label = Editar
passports-delete-passport-prompt-title = ¿Eliminar este pasaporte?
passports-delete-passport-prompt-confirm-button = Eliminar
passports-delete-passport-prompt-cancel-button = Cancelar
autofill-passports-add-button = Añadir nuevo pasaporte
autofill-personal-info-manage-title =
    .heading = Administrar información personal
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = No se añadieron pasaportes
pane-passwords-autofill-title2 = Contraseñas y autocompletado
    .title = Contraseñas y autocompletado
preferences-passwords-autofill-header =
    .heading = Contraseñas y autocompletado
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
addresses-group =
    .label = Direcciones y más
payments-group =
    .label = Métodos de pago

## Privacy Section - History

history-remember-option-never2 =
    .description = Todas las pestañas se comportan como una pestaña privada. Cuando esta función está activada, las extensiones deben ser autorizadas.
    .label = No recordar el historial
history-remember-option-custom2 =
    .label = Personalizar historial
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } recordará su historial de navegación, descargas, formularios y búsqueda.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } usará la misma configuración que en la navegación privada, y no recordará ningún dato de su historial mientras navega por la Web.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } utilizará una configuración personalizada para su historial de navegación, descargas, formularios y búsquedas.
history-private-browsing-permanent =
    .label = Modo permanente de navegación privada
    .accesskey = n
history-remember-browser-option =
    .label = Recordar historial de navegación y descargas
    .accesskey = h
history-remember-search-option =
    .label = Recordar el historial de formularios y búsquedas
    .accesskey = f
history-clear-on-close-option =
    .label = Limpiar el historial cuando { -brand-short-name } se cierre
    .accesskey = h
history-clear-on-close-settings =
    .label = Configuración…
    .accesskey = g
history-shutdown-exceptions =
    .label = Administrar excepciones
    .accesskey = x
history-clear-button =
    .label = Limpiar historial…
    .accesskey = s
history-header2 =
    .heading = Historial
history-section-header =
    .description = Elija lo que desea que { -brand-short-name } recuerde al cerrar el navegador.
    .label = Historial
history-custom-section-header =
    .description = Personalice lo que desea que { -brand-short-name } recuerde al cerrar el navegador.
    .label = Ajustes avanzados
history-custom-button =
    .label = Seleccione qué quiere que { -brand-short-name } recuerde
history-group =
    .label = Historial
history-mode-radio-group =
    .aria-label = Historial
history-remember-option-all2 =
    .label = Recordar el historial

## Privacy Section - Site Data

sitedata-total-size-calculating = Calculando el tamaño de los datos del sitio y del caché…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Los sitios web están usando actualmente <strong>{ $value } { $unit }</strong> de espacio en disco.
sitedata-learn-more = Saber más
sitedata-delete-on-close2 =
    .label = Borrar cookies y datos del sitio cada vez que se cierre { -brand-short-name }
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = Según la configuración de su historial, { -brand-short-name } elimina las cookies y los datos del sitio de su sesión cuando cierra el navegador.
sitedata-delete-on-close-private-browsing4 =
    .heading = El historial no se guardará.
    .message = { -brand-short-name } eliminará las cookies y datos web de su sesión al cerrar el navegador.
sitedata-option-block-cross-site-trackers =
    .label = Rastreadores entre sitios
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cookies de rastreo entre sitios
sitedata-option-block-cross-site-cookies2 =
    .label = Aislar cookies entre sitios
sitedata-option-block-unvisited =
    .label = Cookies de sitios web no visitados
sitedata-option-block-all-cross-site-cookies =
    .label = Todas las cookies entre sitios (puede causar errores en los sitios web)
sitedata-option-block-all =
    .label = Todas las cookies (causará errores en sitios web)
sitedata-clear2 =
    .label = Eliminar datos de navegación
    .accesskey = l
sitedata-settings2 =
    .label = Administrar datos de navegación
    .accesskey = m
sitedata-cookies-exceptions =
    .label = Gestionar excepciones…
    .accesskey = x
sitedata-cookies-exceptions2 =
    .description = Puede especificar que sitios web tienen siempre permitido o prohibido usar cookies y datos de sitio.
    .label = Administrar excepciones
    .accesskey = x
sitedata-heading =
    .description = Gestione sus cookies, historial, caché, datos web y más.
    .label = Datos de búsqueda.
sitedata-settings3 =
    .label = Borrar datos para sitios específicos
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Seleccione la manera en la que sitios web específicos manejan las cookies y los datos web.
    .label = Administrar excepciones
    .accesskey = x
cookies-site-data-group =
    .label = Cookies y datos del sitio

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Bloqueador de avisos de cookies
cookie-banner-blocker-description = Cuando un sitio pregunta si puede utilizar cookies en el modo de navegación privada, { -brand-short-name } se niega automáticamente. Solo en sitios compatibles.
cookie-banner-learn-more = Saber más
cookie-banner-blocker-checkbox-label =
    .label = Rechazar automáticamente los avisos de cookies

## Search Section

addressbar-locbar-history-option =
    .label = Historial de navegación
    .accesskey = t
addressbar-locbar-bookmarks-option =
    .label = Marcadores
    .accesskey = M
addressbar-locbar-clipboard-option =
    .label = Portapapeles
    .accesskey = P
addressbar-locbar-openpage-option =
    .label = Abrir pestañas
    .accesskey = A
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Accesos directos
    .accesskey = s
addressbar-locbar-topsites-option =
    .label = Sitios populares
    .accesskey = t
addressbar-locbar-engines-option-1 =
    .label = Sugerir buscadores a usar
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = Acciones rápidas
    .accesskey = A
addressbar-locbar-showrecentsearches-option-2 =
    .label = Búsquedas recientes
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Tendencias en sugerencias de búsqueda
    .accesskey = T
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Obtenga sugerencias de la web relacionadas con su búsqueda.
    .label = Sugerencias de { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Apoye a { -brand-short-name } con sugerencias patrocinadas ocasionales.
    .label = Sugerencias de patrocinadores
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Obtener sugerencias de Mozilla mientras escribe
addressbar-dismissed-suggestions-label-2 =
    .description = Restaurar sugerencias rechazadas de patrocinadores y { -brand-short-name }.
    .label = Sugerencias descartadas
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Restaurar sugerencias

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Protección contra el rastreo mejorada
content-blocking-section-top-level-description = Los rastreadores le siguen en línea para recopilar información sobre sus hábitos e intereses de navegación. { -brand-short-name } bloquea muchos de estos rastreadores y otros scripts maliciosos.
content-blocking-learn-more = Saber más
content-blocking-fpi-incompatibility-warning = Está usando First Party Isolation (FPI), que anula algunas de las configuraciones de cookies de { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Está usando Resist Fingerprinting (RFP), que reemplaza algunas de las configuraciones de protección de huellas digitales de { -brand-short-name }. Esto podría provocar que algunos sitios fallen.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Estándar
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Estricto
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Personalizado
    .accesskey = P

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Equilibrado para protección y rendimiento. Las páginas se cargarán normalmente.
content-blocking-etp-strict-desc = Mayor protección, pero puede provocar que fallen algunos sitios o contenidos.
content-blocking-etp-custom-desc = Elija qué rastreadores y scripts quiere bloquear.
content-blocking-etp-blocking-desc = { -brand-short-name } bloquea lo siguiente:
content-blocking-private-windows = Rastreo de contenido en ventanas privadas
content-blocking-cross-site-cookies-in-all-windows2 = Cookies de sitios cruzados en todas las ventanas
content-blocking-cross-site-tracking-cookies = Cookies de rastreo entre sitios
content-blocking-all-cross-site-cookies-private-windows = Cookies de sitios cruzados en ventanas privadas
content-blocking-isolate-cross-site-cookies = Aislar cookies entre sitios
content-blocking-social-media-trackers = Rastreadores sociales
content-blocking-all-cookies = Todas las cookies
content-blocking-unvisited-cookies = Cookies de sitios no visitados
content-blocking-all-windows-tracking-content = Contenido de rastreo en todas las ventanas
content-blocking-all-cross-site-cookies = Todas las cookies entre sitios
content-blocking-cryptominers = Criptomineros
content-blocking-fingerprinters = Fingerprinters
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Detectores de huellas digitales, conocidos y sospechosos
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = La protección total contra las cookies contiene cookies para el sitio en el que está, así que los rastreadores no pueden usarlas para seguirle entre sitios.
content-blocking-etp-standard-tcp-rollout-learn-more = Saber más
content-blocking-etp-standard-tcp-title = Incluye la protección total contra cookies , nuestra herramienta de privacidad más potente hasta ahora
content-blocking-warning-title-2 = Algunos sitios se pueden romper la estricta protección de seguimiento.
content-blocking-warning-title-custom = Algunos sitios se pueden romper con la protección contra el rastreo personalizada.
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } recomienda usar la configuración “Corregir problemas del sitio” para reducir las funciones y el contenido rotos del sitio. Si un sitio parece roto, intente desactivar la protección contra rastreo para que ese sitio cargue todo el contenido.
content-blocking-warning-learn-how = Saber cómo
content-blocking-baseline-exceptions-3 =
    .description = Facilita la carga de sitios y funciones desbloqueando únicamente los elementos esenciales que pueden contener rastreadores. Abarca los problemas más comunes.
    .label = Corregir problemas importantes del sitio (recomendado)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Restaura elementos como vídeos en un artículo o secciones de comentarios desbloqueando elementos que puedan contener rastreadores. Esto puede reducir los problemas del sitio, pero ofrece menos protección. Debe usarse junto con correcciones para problemas graves.
    .label = Corregir problemas menores del sitio
content-blocking-baseline-uncheck-warning-dialog-title = ¿Está seguro de querer desactivar las correcciones?
content-blocking-baseline-uncheck-warning-dialog-body = Esta configuración ayuda a solucionar los problemas más comunes del sitio. Si se desactiva, es posible que algunos sitios no funcionen y { -brand-short-name } no podrá ayudar a solucionar esos problemas.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Desactivar correcciones
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Mantener las correcciones activadas
content-blocking-reload-description = Tiene que recargar las pestañas para que los cambios surtan efecto.
content-blocking-reload-tabs-button =
    .label = Recargar todas las pestañas
    .accesskey = R
content-blocking-tracking-content-label =
    .label = Contenido de rastreo
    .accesskey = T
content-blocking-tracking-protection-option-all-windows =
    .label = En todas las ventanas
    .accesskey = A
content-blocking-option-private =
    .label = Solo en ventanas privadas
    .accesskey = P
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Más información
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Criptomineros
    .accesskey = r
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Detectores de huellas digitales conocidos
    .accesskey = c
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Presuntos detectores de huellas digitales
    .accesskey = s

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Administrar excepciones…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Pausar notificaciones hasta que { -brand-short-name } se reinicie
    .accesskey = n
permissions-autoplay2 =
    .label = Reproducción automática
permissions-block-popups2 =
    .label = Bloquear ventanas emergentes y redirecciones de terceros
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Añada sitios web que puedan abrir ventanas emergentes y usar redirecciones de terceros.
    .label = Administrar excepciones
    .searchkeywords = ventanas emergentes
    .accesskey = e
permissions-addon-install-warning3 =
    .label = Mostrar una advertencia cuando los sitios web traten de instalar extensiones
    .accesskey = M
permissions-addon-exceptions2 =
    .label = Elegir qué sitios web pueden instalar extensiones
    .accesskey = E
permissions-location2 =
    .label = Ubicación
permissions-localhost2 =
    .label = Aplicaciones y servicios del dispositivo
permissions-local-network2 =
    .label = Dispositivos de red local
permissions-xr2 =
    .label = Realidad virtual
permissions-camera2 =
    .label = Cámara
permissions-microphone2 =
    .label = Micrófono
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Altavoz
permissions-notification2 =
    .label = Notificaciones
permissions-header3 =
    .description = Gestione lo que las páginas web pueden acceder, controlar o activar.
    .label = Permisos
permissions-data-section =
    .heading = Permisos y datos
pane-permissions-data-title2 = Permisos y datos
    .title = Permisos y datos

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Para garantizar que este cambio sea incluido en sus copias de seguridad, abra cada perfil y seleccione “Hacer copia de seguridad ahora” en Ajustes.
nimbus-rollouts =
    .description = Los cambios se aplicarán de forma remota.
    .label = Permitir que { -brand-short-name } mejore funciones, rendimiento y estabilidad entre actualizaciones
addon-recommendations3 =
    .description = Obtenga recomendaciones de extensiones para mejorar la experiencia de navegación.
    .label = Permitir recomendaciones personalizadas de extensiones
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = El envío de datos está desactivado para esta configuración de compilación.
collection-backlogged-crash-reports2 =
    .label = Enviar automáticamente informes de fallos
    .accesskey = c
collection-backlogged-crash-reports-description = Esto ayuda a { -vendor-short-name } a diagnosticar y solucionar problemas con el navegador. Los informes pueden incluir datos personales o confidenciales.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = ¡Mismos ajustes, nueva apariencia!
    .message = Esta página se reorganizó para facilitar la lectura y la exploración. No hubo cambios en los ajustes personales y todo sigue aquí. Sugerencia: utilice la búsqueda para ir directamente a lo necesario.
settings-redesign-promo-dismiss-button =
    .label = Entendido
privacy-segmentation-section-header = Nuevas características que mejoran su navegación
privacy-segmentation-section-description = Cuando ofrecemos funciones que usan sus datos para brindarle una experiencia más personal:
privacy-segmentation-radio-off =
    .label = Use las recomendaciones de { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Mostrar información detallada
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Nos esforzamos por ofrecerle opciones y recopilar solo los datos mínimos necesarios para mejorar { -brand-product-name } para todos.
    .label = Recopilación y uso de datos de { -brand-short-name }
    .searchkeywords = telemetría
data-collection-link = Ver el aviso de privacidad
data-collection-preferences-across-profiles =
    .message = Esta configuración se aplica a todos los perfiles de { -brand-product-name } en este dispositivo.
data-collection-profiles-link = Ver todos los perfiles
data-collection-health-report-telemetry-disabled =
    .message = Ya no permite que { -vendor-short-name } capture datos técnicos y de interacción. Todos los datos anteriores se eliminarán en 30 días.
data-collection-health-report =
    .description = Esto nos ayuda a mejorar las características, el rendimiento y la estabilidad de { -brand-product-name }.
    .label = Enviar datos técnicos y de interacción a { -vendor-short-name }
    .accesskey = r
data-collection-health-report-disabled =
    .description = El envío de informes de datos está desactivado para esta configuración de compilación.
    .label = Enviar datos técnicos y de interacción a { -vendor-short-name }
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } selecciona usuarios al azar para probar funcionalidades, lo que ayuda a mejorar la calidad para todos.
    .label = Permitir que { -brand-short-name } ejecute estudios de funcionalidades
data-collection-studies-link =
    .label = Ver los estudios de { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description =
        Esto ayuda a que { -vendor-short-name } diagnostique y arregle problemas con el navegador.
        Los informes pueden incluir datos personales o sensibles.
    .label = Enviar automáticamente los informes de fallos
    .accesskey = c
data-collection-usage-ping =
    .description = Esto ayuda a { -vendor-short-name } a estimar la cantidad de usuarios activos.
    .label = Enviar ping de uso diario a { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Seguridad
browsing-protection-group2 =
    .description = Páginas web y descargas peligrosas pueden poner en peligro sus datos y dispositivo. { -brand-short-name } las bloquea automáticamente, y le advierte sobre software peligroso o no deseado.
    .label = Protección contra contenido engañoso y software peligroso
security-enable-safe-browsing =
    .label = Bloquear contenido peligroso y engañoso
    .accesskey = B
security-enable-safe-browsing-link = Saber más
security-safe-browsing-warning =
    .message = Desactivar esta función reduce la protección ante estafas, páginas maliciosas y descargas peligrosas.
security-block-downloads =
    .label = Bloquear descargas peligrosas
    .accesskey = d
security-block-uncommon-software =
    .label = Advertirle sobre software no deseado y poco usual
    .accesskey = v

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Permitir que { -brand-short-name } confíe automáticamente en los certificados raíz de terceros que se instalen
    .accesskey = t
certs-devices-enable-fips = Habilitar FIPS
space-alert-over-5gb-settings-button =
    .label = Abrir ajustes
    .accesskey = A
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } se está quedando sin espacio en disco. </strong>Los contenidos del sitio web pueden no mostrarse correctamente. Puede limpiar los datos de sitios guardados en Ajustes > Privacidad & Seguridad> Cookies y datos del sitio.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } se está quedando sin espacio en disco.</strong> Los contenidos del sitio web pueden no mostrarse correctamente. Visite “Saber más” para optimizar su uso de disco y mejorar la experiencia de navegación.
certs-description3 =
    .description = Configure los certificados que { -brand-short-name } utiliza para verificar conexiones seguras.
    .label = Certificados
certs-view2 =
    .label = Administrar certificados
    .accesskey = c
certs-devices2 =
    .label = Administrar dispositivos de seguridad
    .accesskey = d

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Cómo funciona el modo solo-HTTPS
httpsonly-radio-enabled =
    .label = Activar el modo solo-HTTPS en todas las ventanas
httpsonly-radio-enabled-pbm =
    .label = Activar el modo solo-HTTPS solamente en ventanas privadas
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } todavía podría actualizar algunas conexiones
    .label = No activar el modo solo-HTTPS
httpsonly-group =
    .description = Solo permite conexiones seguras a sitios web. { -brand-short-name } preguntará antes de conectarse de forma insegura.
    .label = Modo solo-HTTPS
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS sobre HTTPS
dns-over-https-group2 =
    .description = Domain Name System (Sistema de Nombres de Dominio) sobre HTTPS (DoH) cifra sus consultas web para complicar que su proveedor de internet u otros  puedan ver qué páginas web está visitando.
    .label = DNS sobre HTTPS
preferences-doh-description2 = El sistema de nombres de dominio (DNS) sobre HTTPS envía los pedidos de un nombre de dominio a través de una conexión cifrada, lo que proporciona un DNS seguro y hace más difícil que otros vean qué sitio web está tratando de acceder.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Estado: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Proveedor: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = URL no válida
preferences-doh-steering-status = Usando un proveedor local
preferences-doh-status-active = Activo
preferences-doh-status-disabled = Desactivado
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Inactivo ({ $reason })
preferences-doh-group-message2 = Activar DNS sobre HTTPS usando:
preferences-doh-radio-group =
    .aria-label = Activar DNS sobre HTTPS usando:
preferences-doh-expand-section =
    .tooltiptext = Más información
preferences-doh-setting-default =
    .label = Protección predeterminada
    .accesskey = d
preferences-doh-default-desc = { -brand-short-name } decide cuándo usar DNS seguro para proteger su privacidad.
preferences-doh-default-detailed-desc-1 = Usar DNS seguro en regiones donde esté disponible
preferences-doh-default-detailed-desc-2 = Use la resolución de DNS predeterminada si hay un problema con el proveedor de DNS seguro
preferences-doh-default-detailed-desc-3 = Usar un proveedor local si es posible
preferences-doh-default-detailed-desc-4 = Desactivar cuando una VPN, control parental o políticas de empresa estén activas
preferences-doh-default-detailed-desc-5 = Desactivar cuando una red le diga a { -brand-short-name } que no debería usar DNS seguro
preferences-doh-setting-enabled =
    .label = Protección aumentada
    .accesskey = i
preferences-doh-enabled-desc = Usted controla cuándo usar DNS seguro y elige su proveedor.
preferences-doh-enabled-detailed-desc-1 = Usar el proveedor seleccionado
preferences-doh-enabled-detailed-desc-2 = Solo usar la resolución de DNS predeterminada si hay un problema con el DNS seguro
preferences-doh-setting-strict =
    .label = Protección máxima
    .accesskey = m
preferences-doh-strict-desc = { -brand-short-name } siempre usará DNS seguro. Se verá una advertencia de riesgo de seguridad antes de que usemos el DNS del sistema.
preferences-doh-strict-detailed-desc-1 = Solo usar el proveedor seleccionado
preferences-doh-strict-detailed-desc-2 = Avisar siempre si el DNS seguro no está disponible
preferences-doh-strict-detailed-desc-3 = Si el DNS seguro no está disponible los sitios no se cargarán ni funcionarán correctamente.
preferences-doh-setting-off =
    .label = Desactivado
    .accesskey = o
preferences-doh-off-desc = Usar la resolución de DNS predeterminada
preferences-doh-select-resolver = Seleccionar proveedor:
preferences-doh-manage-exceptions =
    .label = Administrar excepciones…
    .accesskey = x
preferences-doh-overview-default =
    .description = Utilizar DNS seguro en regiones donde esté disponible.
    .label = Protección predeterminada
preferences-doh-overview-custom =
    .description = Utilizar siempre DNS seguro con control sobre su proveedor y comportamiento de respaldo.
    .label = Personalizado
preferences-doh-overview-off =
    .description = Utilice su solucionador de DNS predeterminado.
    .label = Desactivado
preferences-doh-advanced-button =
    .label = Ajustes avanzados
preferences-doh-advanced-section =
    .description = El Sistema de Nombres de Dominio sobre HTTPS (DoH) cifra las búsquedas de sítios para que sea más difícil que su proveedor de internet u otras personas vean qué sitios web va a visitar.
    .label = Ajustes avanzados
preferences-doh-manage-exceptions2 =
    .label = Administrar excepciones
    .accesskey = x
preferences-doh-radio-default =
    .description = Utilizar DNS seguro en regiones donde esté disponible
    .label = Predeterminado
preferences-doh-radio-custom =
    .description = Usar siempre DNS seguro con control sobre su proveedor y el comportamiento de respaldo.
    .label = Personalizado
preferences-doh-radio-off =
    .description = Usar su servidor DNS predeterminado
    .label = Desactivado
preferences-doh-fallback-label =
    .label = Avisarme siempre si el DNS seguro no está disponible
preferences-doh-status-item-off =
    .message = DNS sobre HTTPS está desactivado
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS sobre HTTPS no está funcionando porque encontramos un error ({ $reason }) al intentar usar el proveedor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS sobre HTTPS no está funcionando porque recibimos una URL inválida ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS sobre HTTPS está utilizando el proveedor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS sobre HTTPS no está funcionando porque encontramos un error ({ $reason }) al intentar usar el proveedor local { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS sobre HTTPS está utilizando el proveedor local { $name }
preferences-doh-select-resolver-label =
    .label = Seleccionar proveedor:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Usar este proveedor para resolver DNS sobre HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Introduzca una URL de proveedor personalizada
preferences-doh-header2 =
    .heading = DNS sobre HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Seguridad de la conexión y del software
preferences-connection-link-section =
    .description = Vea cómo se mantienen seguras las conexiones, se bloquea el software dañino y se verifican los sitios web.
    .label = Seguridad de la conexión y del software
preferences-connection-link-button =
    .label = Configuración avanzada

## The following strings are used in the Download section of settings

desktop-folder-name = Escritorio
downloads-folder-name = Descargas

## Appearance page

preferences-appearance-header =
    .heading = Apariencia
browser-theme-group =
    .description = Personalice { -brand-short-name } a su manera. Los colores del tema se aplican a las barras de herramientas, menús y mensajes.
    .label = Tema del navegador
browser-theme-manage-link =
    .label = Administrar temas de { -brand-short-name }
appearance-window-density-group =
    .description = Ajusta el espacio alrededor de los elementos de la ventana tales como barras de herramientas, pestañas y barra lateral.
    .label = Densidad de ventana
appearance-window-density-radio-group =
    .aria-label = Densidad de ventana
appearance-window-density-automatic =
    .description = Espaciado estándar, compacto o táctil aplicado de forma automática
    .label = Automático (predeterminado)
appearance-window-density-automatic-no-touch =
    .description = Espaciado estándar o compacto aplicado de forma automática
    .label = Automático (predeterminado)
appearance-window-density-standard =
    .description = Espaciado balanceado para la mayoría de las pantallas
    .label = Estándar
appearance-window-density-auto-touch-mode =
    .label = Usar espaciado táctil para el modo tableta
appearance-window-density-compact =
    .description = Espaciado reducido para pantallas más pequeñas
    .label = Compacto
appearance-window-density-touch =
    .description = Elementos de ventana y de clic de mayor tamaño, optimizado para pantallas táctiles
    .label = Táctil
related-settings-group =
    .label = Ajustes relacionados
related-settings-accessibility-link =
    .label = Personalice el aumento y la fuente en Accesibilidad
related-settings-home-link =
    .label = Personalizar { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = Personalizar el diseño del navegador

## AI controls page

preferences-ai-controls-description = Siempre puede elegir en { -brand-short-name }, incluyendo si desea usar funciones mejoradas con IA. Próximamente habrá más controles.
preferences-ai-controls-block-ai-label = Bloquear mejoras de IA
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = El bloqueo implica que no verá mejoras de IA nuevas ni actuales en { -brand-short-name }, ni ventanas emergentes relacionadas con ellas. <a data-l10n-name="link">Obtenga más detalles</a> sobre lo que se incluye y cómo controlar las funciones tradicionales de aprendizaje automático, como las sugerencias de búsqueda y las recomendaciones.
preferences-ai-controls-blocked-message =
    .message = Las mejoras de IA, tanto nuevas como actuales, están bloqueadas por defecto. Para desbloquear una función específica, utilice los controles que se encuentran a continuación.
preferences-ai-controls-on-device-group =
    .description = Esto utiliza pequeños modelos de IA que se descargan en su dispositivo si utiliza la función. Este enfoque ayuda a proteger su privacidad.
    .label = IA en el dispositivo
preferences-ai-controls-translations-control =
    .description = Navegue sin problemas por la red e su idioma preferido.
    .label = Traducciones
preferences-ai-controls-translations-more-link = Más ajustes de traducciones
preferences-ai-controls-pdfjs-control =
    .description = Cuando añade imágenes a los archivos PDF, se añaden descripciones para que sean accesibles.
    .label = Texto alternativo de la imagen en el visor de PDF de { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Obtenga sugerencias para nombrar y organizar sus pestañas.
    .label = Sugerencias de grupos de pestañas
preferences-ai-controls-key-points-control =
    .description = Vea un resumen rápido antes de abrir un enlace.
    .label = Puntos clave en las vistas previas de enlaces
preferences-ai-controls-sidebar-chatbot-group =
    .description = Mantenga un chatbot a la vista mientras navega. Elija entre Anthropic Claude, ChatGPT, Copilot, Google Gemini y Le Chat Mistral.
    .label = Proveedores de chatbots en la barra lateral
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot en la barra lateral
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Disponible
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Activado
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Bloqueado
preferences-ai-controls-state-description-before = Qué significan las opciones:
preferences-ai-controls-state-description-available = <strong>Disponible:</strong> Podrá ver la función y utilizarla.
preferences-ai-controls-state-description-enabled = <strong>Activado:</strong> Ha optado por usar la función.
preferences-ai-controls-state-description-blocked = <strong>Bloqueado:</strong> No verá y no podrá usar la función. Para la IA en el dispositivo, se eliminan todos los modelos ya descargados.
preferences-ai-controls-block-confirmation-heading = ¿Bloquear las mejoras basadas en IA?
preferences-ai-controls-block-confirmation-description = No verá mejoras de IA nuevas ni actuales en { -brand-short-name }, ni ventanas emergentes relacionadas con ellas. Posteriormente, podrá desbloquear lo que quiera seguir utilizando.
preferences-ai-controls-block-confirmation-features-start = Qué se bloqueará:
preferences-ai-controls-block-confirmation-translations = Traducciones
preferences-ai-controls-block-confirmation-pdfjs = Texto alternativo de la imagen en el visor de PDF de { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Sugerencias de grupos de pestañas
preferences-ai-controls-block-confirmation-key-points = Puntos clave en las vistas previas de enlaces
preferences-ai-controls-block-confirmation-sidebar-chatbot = Proveedores de chatbots en la barra lateral
preferences-ai-controls-block-confirmation-features-after = El bloqueo también afecta a las extensiones que utilizan IA proporcionada por { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Cancelar
preferences-ai-controls-block-confirmation-confirm =
    .label = Bloquear
preferences-ai-controls-header3 =
    .heading = Controles de IA

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } está en guardia
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } recomienda algunas mejoras de seguridad
security-privacy-status-ok-label = Protección mejorada contra rastreo activada
security-privacy-status-problem-label = Hemos encontrado configuraciones que afectan a la protección
security-privacy-status-problem-helper-label = Ver problemas
security-privacy-status-pending-trackers-label = Buscando cuántos rastreadores bloqueó { -brand-short-name } en el último mes
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } rastreador bloqueado durante el último mes
       *[other] { $trackerCount } rastreadores bloqueados durante el último mes
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Tiene <a data-l10n-name="strict-tracking-protection">protección estricta</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Tiene <a data-l10n-name="custom-tracking-protection">protección personalizada</a>
security-privacy-status-up-to-date-label = Tiene la última y más segura versión de { -brand-short-name }
security-privacy-status-update-needed-label = Hay disponible una nueva versión de { -brand-short-name }.
security-privacy-status-update-error-label = { -brand-short-name } tiene problemas para actualizarse
security-privacy-status-update-checking-label = { -brand-short-name } está buscando actualizaciones
security-privacy-status-update-needed-description = Actualizar para obtener las últimas actualizaciones de velocidad, estabilidad y seguridad.
security-privacy-status-update-button-label =
    .label = Actualizar { -brand-short-name }
security-privacy-image-warning =
    .alt = Un escudo con un signo de exclamación, expresando preocupación por las advertencias de seguridad
security-privacy-image-ok =
    .alt = Un escudo con un check que muestra que no hay problemas de seguridad pendientes
security-privacy-issue-card =
    .heading = Advertencias de seguridad
issue-card-reset-button =
    .label = Restablecer
issue-card-dismiss-button =
    .aria-label = Descartar
    .tooltiptext = Descartar

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Los sitios usan rastreadores para seguirle en línea y mostrar publicidades horribles. { -brand-short-name } le protege al navegar, bloqueando automáticamente los rastreadores para que usted tenga el control de su rastro digital.
    .label = Protección mejorada contra el rastreo
preferences-etp-level-radio-group =
    .aria-label = Protección mejorada contra el rastreo
preferences-etp-level-standard =
    .description = Protecciones seguras y fiables que funcionan de forma fluida con la mayoría de los sitios web.
    .label = Estándar (predeterminada)
preferences-etp-level-strict =
    .description = Mejores protecciones que bloquean más rastreadores, pero que pueden causar que ciertas páginas dejen de funcionar correctamente.
    .label = Estricto
preferences-etp-level-custom =
    .description = Seleccione qué protecciones activar o desactivar.
    .label = Personalizado
preferences-etp-status-advanced-button =
    .label = Configuración avanzada
preferences-etp-status-protections-dashboard-link =
    .description = Vea cuántos rastreadores furtivos fueron bloqueados por { -brand-short-name }, incluyendo rastreadores de redes sociales, detectores de huellas y criptomineros.
    .label = Vea su panel de protecciones personalizado
preferences-etp-header =
    .heading = Protección contra rastreo mejorada
preferences-etp-advanced-settings-group =
    .description = Los sitios usan rastreadores para seguirle en línea y mostrar publicidades horribles. { -brand-short-name } le protege al navegar, bloqueando la mayoría de los rastreadores automáticamente para que usted tenga el control de su rastro digital.
    .label = Ajustes avanzados
preferences-etp-customize-button =
    .label = Personalizar la protección contra el rastreo
preferences-etp-reload-tabs-hint =
    .message = Recargar las pestañas para aplicar estos cambios.
preferences-etp-reload-tabs-hint-button =
    .label = Recargar todas las pestañas
preferences-etp-rfp-warning-message =
    .message = Está usando Resist Fingerprinting (RFP), que reemplaza algunas de las configuraciones de protección de huellas de { -brand-short-name }. Esto podría provocar que algunos sitios fallen.
preferences-etp-level-warning-message =
    .heading = ¡Atención! Algunos sitios pueden no funcionar como se esperaba.
    .message = Algunos sitios incluyen rastreadores en sus funciones o contenido. Cuando { -brand-short-name } los bloquea, el sitio parece estar roto. Intente usar “Solucionar problema del sitio” o desactivar la protección contra el rastreo en ese sitio.
preferences-etp-manage-exceptions-button =
    .description = Administrar los sitios web donde se desactiva la protección mejorada contra el rastreo.
    .label = Administrar excepciones
preferences-etp-customize-header =
    .heading = Personalizar la protección contra el rastreo
preferences-etp-reset =
    .description = Restablecer los ajustes a un nivel de protección predeterminado.
    .label = Restablecer personalizaciones
preferences-etp-reset-standard-button =
    .label = Restablecer a nivel estándar
preferences-etp-reset-strict-button =
    .label = Restablecer a nivel estricto
preferences-etp-custom-control-group =
    .description = Seleccione qué protecciones activar o desactivar.
    .label = Protección contra el rastreo
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Permitir todas las cookies
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Bloquear cookies entre sitios
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Aislar cookies entre sitios
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Bloquear cookies de sitios web no visitados
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Bloquear todas las cookies entre sitios (puede causar errores en los sitios web)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Bloquear todas las cookies (causará errores en los sitios web)
preferences-etp-custom-tracking-protection-enabled =
    .label = Contenido de rastreo
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Contenido de rastreo
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Criptomineros
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Detectores de huellas digitales conocidos
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Presuntos detectores de huellas digitales
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Presuntos detectores de huellas digitales

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Esto puede permitir que algunos rastreadores le sigan sin cookies.
    .label = Los detectores de huellas digitales conocidos no están bloqueados
security-privacy-issue-warning-third-party-cookies =
    .description = Las cookies de terceros se usan para rastrearle entre sitios.
    .label = Cookies de terceros activadas.
security-privacy-issue-warning-password-manager =
    .description = Los gestores de contraseñas le ayudan a almacenar contraseñas seguras para sus cuentas.
    .label = El gestor de contraseñas está desactivado
security-privacy-issue-warning-popup-blocker =
    .description = Las ventanas emergentes son disruptivas y potencialmente dañinas.
    .label = El bloqueador de ventanas emergentes (popups) está desactivado
security-privacy-issue-warning-extension-install =
    .description = Las páginas web pueden instalar extensiones en { -brand-short-name } sin pedir permiso.
    .label = Las páginas web pueden instalar extensiones
security-privacy-issue-warning-safe-browsing =
    .description = Está más expuesto ante estafas y software malicioso proveniente de páginas web.
    .label = El contenido peligroso y engañoso no está siendo bloqueado
security-privacy-issue-warning-doh =
    .description = DNS sobre HTTPS oculta a su proveedor de red qué sitios visita.
    .label = DNS sobre HTTPS desactivado
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello oculta a su proveedor de red qué sitios visita.
    .label = Encrypted Client Hello está desactivado
security-privacy-issue-warning-proxy-autodetection =
    .description = La configuración automática del proxy puede permitir que redes no fiables vigilen su actividad.
    .label = La configuración automática de proxy está activada


category-vorbit =
    .tooltiptext = cambios en about:config, agrupados de forma lógica y fácilmente accesibles
vorbit-header = Ajustes de vOrbit-lite
vorbit-warning-title = ¡Atención!
vorbit-general-heading = Comportamiento del navegador
vorbit-styling-checkbox =
    .label = Permitir customización de userChrome.css
vorbit-network-heading = Redes
vorbit-ipv6-checkbox =
    .label = Habilitar IPv6
vorbit-privacy-heading = Privacidad
vorbit-xorigin-ref-checkbox =
    .label = Limitar referer de orígenes cruzados
vorbit-broken-heading = Huella digital
vorbit-sync-checkbox =
    .label = Activar Firefox Sync
vorbit-autocopy-checkbox =
    .label = Activar la función "pegar" con el botón central del ratón
vorbit-rfp-checkbox =
    .label = Activar ResistFingerprinting
vorbit-letterboxing-checkbox =
    .label = Activar letterboxing
vorbit-security-heading = Seguridad
vorbit-goog-safe-checkbox =
    .label = Activar navegación segura de Google
vorbit-goog-safe-download-checkbox =
    .label = Escanear descargas
vorbit-extension-update-warning1 = Si no revisa el código de sus extensiones instaladas antes de cada actualización, debería activar esta opción.
vorbit-ipv6-description = Permitir que { -brand-short-name } se conecte usando IPv6.
vorbit-ipv6-warning1 = En lugar de bloquear IPv6 en el navegador, sugerimos habilitar la extensión de privacidad IPv6 en su sistema operativo.
vorbit-ocsp-description = Impedir la conexión a un sitio web si no se puede realizar la comprobación OCSP.
vorbit-sync-description = Sincroniza tus datos con otros navegadores. Requiere reinicio.
vorbit-sync-warning1 = Firefox Sync encripta los datos localmente antes de transmitirlos al servidor.
vorbit-autocopy-description = Selecciona un texto para copiarlo y luego pégalo con el botón central del ratón.
vorbit-xorigin-ref-description = Enviar el referer únicamente en el mismo origen.
vorbit-webgl-description = WebGL es un potente vector de huella digital (disminuye la privacidad).
vorbit-webgl-warning1 = Si necesitas habilitarlo, considera usar una extensión como Canvas Blocker. Cuando la página intenta crear contexto de WebGL, te pedirá primero autorización.
vorbit-rfp-description = ResistFingerprinting es la herramienta anti-huella digital líder en su clase.
vorbit-rfp-warning1 = Si necesitas desactivarlo, considera usar una extensión como Canvas Blocker.
vorbit-letterboxing-description = Letterboxing aplica márgenes alrededor de tus ventanas para ofrecer un conjunto limitado de resoluciones redondeadas.
vorbit-goog-safe-description = Si te preocupa el malware y el phishing, considera habilitarlo.
vorbit-goog-safe-download-description = Permitir que Safe Browsing (navegación segura) escanee tus descargas para identificar archivos sospechosos.
vorbit-goog-safe-download-warning1 = Todas las comprobaciones se realizan localmente.
vorbit-footer = Accesos directos útiles
vorbit-config-link = Todas las configuraciones avanzadas (about:config)
vorbit-open-profile = Abrir carpeta de perfil del usuario
content-blocking-section-top-level-description = vOrbit-lite admite – y activa por defecto – la Protección contra Rastreo Mejorada en modo Estricto. Esta es una de las configuraciones más importantes del navegador, ya que proporciona partición de estado, listas de bloqueo estrictas y otras características de privacidad muy interesantes. No recomendamos cambiar a otros modos.
pane-vorbit-title = vOrbit-lite
vorbit-extension-update-checkbox =
    .label = Actualizar extensiones automáticamente
vorbit-extension-update-description = Mantenga las extensiones actualizadas sin intervención manual. Una buena opción para su seguridad.
vorbit-ocsp-warning1 = Esto aumenta la seguridad, pero causará interrupciones cuando un servidor OCSP esté caído.
vorbit-styling-description = Habilítalo si deseas personalizar la interfaz de usuario mediante un tema cargado manualmente.
vorbit-styling-warning1 = Asegúrate de que confías en el proveedor del tema.
vorbit-xorigin-ref-warning1 = Esto puede causar problemas. Además, incluso cuando se envían, los referers seguirán siendo recortados.
vorbit-goog-safe-warning1 = Desactivado por preocupaciones de censura, pero recomendado para usuarios menos avanzados. Todas las comprobaciones se realizan localmente.
vorbit-warning-description = Elegimos cuidadosamente los ajustes predeterminados para centrarnos en la privacidad y la seguridad. Al cambiar estos ajustes, lee las descripciones para entender las implicaciones de esos cambios.
vorbit-webgl-checkbox =
    .label = Activar WebGL con los permisos por página
vorbit-ocsp-checkbox =
    .label = Aplicar fallo estricto con OCSP
vorbit-webgl-prompt-checkbox =
    .label = Activar el aviso de permiso para ocultar WebGL
vorbit-webgl-prompt-description = Muestra un aviso de permiso cuando WebGL está activado, en lugar de concederlo directamente oculta el popup que aparece cuando la página intenta crear contexto con WebGL.
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = Comportamiento del navegador
vorbit-extension-update-checkbox2 =
    .label = Actualizar complementos automáticamente
    .description = Mantén las extensiones actualizadas sin necesidad de intervenir manualmente. Una buena opción para tu seguridad.
vorbit-sync-checkbox2 =
    .label = Activar Firefox Sync
    .description = Sincroniza tus datos con otros navegadores. Es necesario reiniciar el navegador.
vorbit-autocopy-checkbox2 =
    .label = Activar pegado con el botón central
    .description = Selecciona un texto para copiarlo y, a continuación, pégalo haciendo clic con el botón central del ratón.
vorbit-styling-checkbox2 =
    .label = Permitir la personalización de userChrome.css
    .description = Activa esta opción si deseas personalizar la interfaz de usuario con un tema cargado manualmente.
vorbit-network-heading2 =
    .label = Redes
vorbit-ipv6-checkbox2 =
    .label = Activar IPv6
    .description = Permitir que { -brand-short-name } se conecte mediante IPv6.
vorbit-privacy-heading2 =
    .label = Privacidad
vorbit-xorigin-ref-checkbox2 =
    .label = Restringir las referencias de otros dominios
    .description = Enviar referencias solo si proceden del mismo origen.
vorbit-broken-heading2 =
    .label = Huella digital
vorbit-webgl-checkbox2 =
    .label = Permitir siempre WebGL
    .description = Esto permitirá siempre WebGL sin necesidad de solicitar permiso.
vorbit-webgl-prompt-checkbox2 =
    .label = Ocultar la ventana emergente de WebGL por sitio
    .description = Esto oculta la ventana emergente que aparece cuando un sitio intenta crear un contexto WebGL. Aún así, puedes abrir manualmente la ventana emergente haciendo clic en el icono de la barra de búsqueda.
vorbit-rfp-checkbox2 =
    .label = Activar ResistFingerprinting
    .description = Activa todas las medidas de mitigación de la huella digital disponibles, pero puede provocar que algunas páginas web no funcionen correctamente.
vorbit-letterboxing-checkbox2 =
    .label = Activar letterboxing
    .description = El letterboxing aplica márgenes alrededor de las ventanas para ofrecer un conjunto limitado de resoluciones redondeadas.
vorbit-security-heading2 =
    .label = Seguridad
