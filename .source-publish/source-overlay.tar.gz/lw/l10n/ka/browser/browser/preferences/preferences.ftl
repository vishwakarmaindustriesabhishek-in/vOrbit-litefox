# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = ეცნობოს ვებსაიტებს, რომ არ მსურს გაყიდონ ან გააზიარონ ჩემი მონაცემები
    .accesskey = ყ
non-technical-privacy-group =
    .label = საიტის პირადულობის პარამეტრები
do-not-track-removal3 =
    .message = აღარაა მხარდაჭერილი მოთხოვნა „არ მითვალთვალო“.
non-technical-privacy-heading =
    .label = დამატებითი უსაფრთხოება
preferences-privacy-relay-available =
    .description = ფარავს თქვენს ნამდვილ ელფოსტას უსარგებლო წერილების ასარიდებლად
    .label = შემოთავაზებული { -relay-brand-name } ელფოსტის შესანიღბად
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = პარამეტრები
category-nav-heading =
    .heading = პარამეტრები
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = პარამეტრებში ძიება
    .style = width: 15.4em
managed-notice = თქვენი ბრაუზერი იმართება დაწესებულების მიერ.
managed-notice-info-icon =
    .alt = ცნობა
managed-notice-nav =
    .label = თქვენი ბრაუზერი იმართება დაწესებულების მიერ.
tls-key-logging-notice-nav =
    .label = გარეშე პროგრამამ ან მომსახურებამ შეიძლება იხილოს თქვენი მიერ მიმოცვლილი დაშიფრული მონაცემები.
category-list =
    .aria-label = კატეგორიები
pane-general-title = მთავარი
pane-home-title = საწყისი გვერდი
pane-home-startup-title2 = მთავარი და საწყისი
    .title = მთავარი და საწყისი
pane-search-title2 = ძიება
    .title = ძიება
pane-privacy-title3 = პირადულობა და უსაფრთხოება
    .title = პირადულობა და უსაფრთხოება
pane-privacy-section =
    .heading = პირადულობა და უსაფრთხოება
pane-sync-title3 = სინქრონიზაცია
pane-ai-controls-title2 = AI-სამართავი
    .title = AI-სამართავი
pane-about-firefox-title = { -brand-short-name } შესახებ
    .title = { pane-about-firefox-title }
pane-appearance-title = იერსახე
    .title = { pane-appearance-title }
pane-downloads-title2 = ჩამოტვირთვები
    .title = ჩამოტვირთვები
pane-downloads3 =
    .heading = ჩამოტვირთვები
pane-accessibility-title = ხელმისაწვდომობა
    .title = { pane-accessibility-title }
pane-languages-title2 = ენები
    .title = ენები
preferences-languages-header3 =
    .heading = ენები
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = მოსინჯეთ ჩვენი საცდელი შესაძლებლობები! ჯერ კიდევ დამუშავებისა და დახვეწის საფეხურზეა, რის შედეგადაც შეიძლება განსხვავებულად მუშაობდეს { -brand-short-name }. ჩვენ მხოლოდ იმ შემთხვევაში გვეცნობება თქვენ მიერ გამოყენებული შესაძლებლობების შესახებ, თუ ჩართული გაქვთ <a data-l10n-name="data-collection">ტექნიკური და ურთიერთქმედების მონაცემების</a> გაგზავნა.
pane-experimental-reset =
    .label = ნაგულისხმევის აღდგენა
    .accesskey = უ
help-button-label2 = { -brand-short-name } დახმარება
    .title = { -brand-short-name } დახმარება
addons-button-label2 = გაფართოებები და თემები
    .title = გაფართოებები და თემები
focus-search =
    .key = f
close-button =
    .aria-label = დახურვა
do-not-track-removal2 =
    .label = აღარაა მხარდაჭერილი მოთხოვნა „არ მითვალთვალო“
applications-setting-new-file-types =
    .label = როგორ მოეპყრას { -brand-short-name } დანარჩენ ფაილებს?

## Browser Restart Dialog

feature-enable-requires-restart = ამ შესაძლებლობის ჩასართავად ხელახლა გაუშვით { -brand-short-name }
feature-disable-requires-restart = ამ შესაძლებლობის გამოსართავად ხელახლა გაუშვით { -brand-short-name }
should-restart-title = ხელახლა გაეშვას { -brand-short-name }
should-restart-ok = გაუშვით ხელახლა { -brand-short-name } ახლავე
cancel-no-restart-button = გაუქმება
restart-later = მოგვიანებით გაშვება

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> განსაზღვრავს ამ პარამეტრს.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> განსაზღვრავს ამ პარამეტრს.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> საჭიროებს სათავს ჩანართებს.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> განსაზღვრავს ამ პარამეტრს.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> განსაზღვრავს, თუ როგორ უკავშირდება { -brand-short-name } ინტერნეტს.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = გაფართოების ჩასართავად, გადადით <img data-l10n-name="addons-icon"/> დამატებებზე <img data-l10n-name="menu-icon"/> მენიუდან.
extension-controlled-enable-2 = ამ გაფართოების ხელახლა ჩასართავად იხილეთ <a data-l10n-name="addons-link">გაფართოებები და გაფორმებები</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } მართავს თქვენი საწყისი გვერდის ზოგიერთ პარამეტრს.

## Preferences UI Search Results

search-results-header = ძიების შედეგები
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = ვწუხვართ! შედეგები ფრაზისთვის „<span data-l10n-name="query"></span>“ ვერ მოიძებნა პარამეტრებში.
search-results-help-link = გესაჭიროებათ დახმარება? ეწვიეთ <a data-l10n-name="url">{ -brand-short-name } მხარდაჭერის გვერდს</a>

## General Section

always-check-default =
    .label = ყოველთვის შემოწმდეს, არის თუ არა { -brand-short-name } ნაგულისხმევი ბრაუზერი
    .accesskey = ვ
startup-restore-windows-and-tabs =
    .label = წინა ფანჯრებისა და ჩანართების გახსნა
    .accesskey = გ
startup-windows-launch-on-login-profile-disabled =
    .message = ამ პარამეტრის ჩასართავად „{ profile-manager-use-selected.label }“ მონიშნეთ „მოხმარებლის პროფილის არჩევის“ ფანჯარაში.
windows-launch-on-login =
    .label = გაეშვას { -brand-short-name } თავისით კომპიუტერის ჩართვისთანავე
    .accesskey = ე
windows-launch-on-login-disabled = ეს შესაძლებლობა გათიშულია Windows-ში. შესაცვლელად იხილეთ <a data-l10n-name="startup-link">Startup Apps</a> სისტემის პარამეტრებში.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = ასევე გახსნა ახალ ჩანართში
    .accesskey = ლ
disable-extension =
    .label = გაფართოების ამორთვა
preferences-data-migration-group =
    .description = გადმოიტანეთ თქვენი სანიშნები, პაროლები, ისტორია, გაფართოებები და შევსებული ველები სხვა ბრაუზერიდან.
    .label = ბრაუზერის მონაცემების გადმოტანა
preferences-data-migration-button =
    .label = მონაცემთა გადმოტანა
    .accesskey = ტ
preferences-profiles-group-header =
    .heading = პროფილები
preferences-profiles-subpane-description =
    .description = თითოეულ პროფილს დათვალიერების განცალკევებული მონაცემები და პარამეტრები აქვს, მათ შორის ისტორია, პაროლები და სხვ.
preferences-profiles-section-header =
    .description = თითოეულ პროფილს დათვალიერების განცალკევებული მონაცემები და პარამეტრები აქვს, მათ შორის ისტორია, პაროლები და სხვ.
    .label = პროფილები
preferences-manage-profiles-button =
    .label = პროფილების მართვა
preferences-profiles-settings-button =
    .label = პარამეტრები
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = ახალი პროფილი გადაიტანს თქვენი პარამეტრების, დამატებების, ისტორიისა და შენახული მონაცემების, მათ შორის სანიშნებისა და პაროლების ასლებს — ოღონდ არა თქვენი ანგარიშისა თუ დასინქრონების მონაცემებს.
    .label = არსებული პროფილის ასლი
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = პროფილი ასლისთვის
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = პროფილის არჩევა
preferences-copy-profile-button = ასლი
tabs-browsing-section =
    .heading = ჩანართები და მონახულება
pane-tabs-browsing-title2 = ჩანართები და მონახულება
    .title = ჩანართები და მონახულება
tabs-group-header2 =
    .label = ჩანართები
tabs-opening-heading =
    .label = გახსნა
tabs-interaction-heading =
    .label = ურთიერთქმედება
tabs-containers-heading =
    .label = სათავსები
tabs-closing-heading =
    .label = იხურება
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab წრიულად გადართვა ჩანართებზე ბოლო გამოყენების რიგითობით.
    .accesskey = წ
open-new-link-as-tabs =
    .label = ბმულების, ახალი ფანჯრების ნაცვლად, ახალ ჩანართებში გახსნა
    .accesskey = ჯ
open-external-link-next-to-active-tab =
    .label = გაიხსნას ბმულები პროგრამებიდან მოქმედი ჩანართების გვერდით
ask-on-close-multiple-tabs =
    .label = შეკითხვა რამდენიმე ჩანართის დახურვისას
    .accesskey = რ
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = შეკითხვა დახურვისას ღილაკებით { $quitKey }
    .accesskey = უ
warn-on-open-many-tabs =
    .label = გაფრთხილება, როცა ბევრი ჩანართის გახსნამ შესაძლოა, შეანელოს { -brand-short-name }
    .accesskey = ე
switch-to-new-tabs-2 =
    .label = ბმულის ან ფაილის ახალ ჩანართში გახსნისას მაშინვე მასზე გადასვლა
    .accesskey = ვ
show-tabs-in-taskbar =
    .label = ჩანართების შეთვალიერება Windows-ის ამოცანათა ზოლში
    .accesskey = ც
browser-containers-enabled-2 =
    .label = სათავსი ჩანართების გამოყენება
    .accesskey = ს
browser-containers-learn-more = ვრცლად
browser-containers-settings-2 =
    .label = პარამეტრების მართვა
    .accesskey = პ
containers-disable-alert-title = გსურთ ყველა სათავსი ჩანართის დახურვა?
startup-group =
    .label = ჩართვისას

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] სათავსი ჩანართების გამორთვის შემთხვევაში, სათავსი ჩანართი დაიხურება. ნამდვილად გსურთ სათავსი ჩანართების გამორთვა?
       *[other] სათავსი ჩანართების გამორთვის შემთხვევაში, { $tabCount } სათავსი ჩანართი დაიხურება. ნამდვილად გსურთ სათავსი ჩანართების გამორთვა?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] სათავსი ჩანართის დახურვა
       *[other] { $tabCount } სათავსი ჩანართის დახურვა
    }

##

containers-disable-alert-cancel-button = ჩართული დატოვება
containers-remove-alert-title = გსურთ სათავსის წაშლა?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] თუ ამ სათავსს ახლავე წაშლით, ჩანართი დაიხურება. ნამდვილად გსურთ, სათავსის წაშლა?
       *[other] თუ ამ სათავსს ახლავე წაშლით, { $count } ჩანართი დაიხურება. ნამდვილად გსურთ სათავსის წაშლა?
    }
containers-remove-ok-button = სათავსის წაშლა
containers-remove-cancel-button = სათავსის დატოვება
settings-tabs-show-image-in-preview =
    .label = შეთვალიერების ჩვენება ჩანართზე მაჩვენებლის გადატარებისას
    .accessKey = ტ
settings-tabs-drag-to-create-tab-groups =
    .label = ჩავლებით ერთმანეთზე გადადებისას ჩანართების დაჯგუფება
browser-layout-header2 =
    .label = ბრაუზერის განლაგება
browser-layout-horizontal-tabs2 =
    .description = ჩანართები ზემოთ
    .label = თარაზული ჩანართები
    .title = ჩანართები ზემოთ
browser-layout-vertical-tabs2 =
    .description = ჩანართები გვერდით ზოლზე
    .label = შვეული ჩანართები
    .title = ჩანართები გვერდით ზოლზე
browser-layout-show-sidebar2 =
    .description = სწრაფი წვდომა სანიშნებთან, ჩანართებთან, AI-თანამოსაუბრესთან და სხვ. მთავარი ფანჯრისგან თვალის მოუცილებლად.
    .label = გვერდითი ზოლის ჩვენება
page-navigation-group =
    .label = ვებგვერდზე გადაადგილება

## General Section - Language & Appearance

language-and-appearance-header = ენა და იერსახე
appearance-group2 =
    .description = ზოგიერთი ვებსაიტი იცვლის ფერებს თქვენ მიერ მითითებულის შესაბამისად. აირჩიეთ ფერთა შეხამება.
    .label = საიტის იერსახე
preferences-web-appearance-choice-auto3 =
    .label = სისტემური
    .title = თავისით შეცვლის ვებსაიტის ფონსა და შიგთავსს, როგორც განსაზღვრავს სისტემა ან { -brand-short-name } გაფორმებით.
preferences-web-appearance-choice-light2 =
    .label = ნათელი
    .title = გამოიყენეთ ნათელი იერსახე ვებსაიტის ფონისა და შიგთავსისთვის.
preferences-web-appearance-choice-dark2 =
    .label = მუქი
    .title = გამოიყენეთ მუქი იერსახე ვებსაიტის ფონისა და შიგთავსისთვის.
web-appearance-group =
    .aria-label = საიტის იერსახე
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = სიმკვეთრის თქვენ მიერ შერჩეული პარამეტრები ჩაანაცვლებს საიტის გაფორმებას.
preferences-web-appearance-link =
    .label = გააფორმეთ { -brand-short-name } გაფართოებებისა და თემების განყოფილებიდან
preferences-contrast-control-group =
    .description = ვებსაიტებზე განსხვავებული ფერებია წინა და უკანა ფონზე. სიმკვეთრის შენარჩუნებისთვის შეგიძლიათ ყველა საიტზე ერთი და იმავე ფერების მითითება.
    .label = ვებსაიტზე ფერთა გამოკვეთა
preferences-contrast-control-radio-group =
    .label = ფერების ჩანაცვლება
preferences-contrast-control-use-platform-settings =
    .label = თვითშერჩევა (სისტემის მიხედვით)
    .accesskey = ვ
preferences-contrast-control-off =
    .label = გამორთ.
    .accesskey = ო
preferences-contrast-control-custom =
    .label = მორგებული
    .accesskey = რ
preferences-colors-manage-button2 =
    .label = ფერების მართვა
    .accesskey = ფ
preferences-colors-manage-button =
    .label = ფერების მართვა…
    .accesskey = ფ
preferences-fonts-header2 =
    .label = შრიფტები
preferences-default-zoom-label =
    .label = ნაგულისხმევი ზომა
    .accesskey = ზ
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = მხოლოდ ნაწერის ზომა
    .accesskey = ზ
preferences-text-zoom-override-warning2 =
    .message = თუ „მხოლოდ ტექსტის მოახლოებაა“ ჩართული და ნაგულისხმევ მოახლოებად არაა მითითებული 100%, ზოგი საიტის შიგთავსი შესაძლოა გაუმართავად გამოჩნდეს.
language-header = ენა
choose-language-description = მიუთითეთ სასურველი ენა გვერდების საჩვენებლად
website-language-heading =
    .description = ზოგიერთი ვებგვერდი რამდენიმე ენაზეა. მიუთითეთ ენები სასურველი მიმდევრობით.
    .label = ვებსაიტის ენა
website-preferred-language =
    .label = სასურველი ენები
website-language-list =
    .aria-label = სასურველი ენები
website-add-language =
    .label = ენის დამატება
website-add-language-button =
    .aria-label = შერჩეული ენის დამატება
    .title = შერჩეული ენის დამატება
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = მოცილდეს { $locale }
    .title = მოცილდეს { $locale }
choose-button =
    .label = არჩევა…
    .accesskey = ა
choose-browser-language-description = მიუთითეთ ენა, რომლითაც მენიუს, შეტყობინებებსა და ცნობებს გაჩვენებთ { -brand-short-name }.
manage-browser-languages-button =
    .label = დამატებითის მითითება...
    .accesskey = დ
confirm-browser-language-change-description = გაუშვით { -brand-short-name } ხელახლა ცვლილებების ასახვისთვის
confirm-browser-language-change-button = მიღება და ხელახლა გაშვება
browser-language-heading =
    .description = მიუთითეთ ენა, რომლითაც მენიუს, შეტყობინებებსა და ცნობებს მოგაწვდით { -brand-short-name }.
    .label = ბრაუზერის ენა
browser-language-preferred-label =
    .label = სასურველი ენა
browser-language-fallback-label =
    .description = გამოიყენება, როცა სასურველი ენის თარგმანი არასრულია.
    .label = სათადარიგო ენა
browser-language-install-error =
    .message = { -brand-short-name } ახლა ვერ ახერხებს თქვენი ენების განახლებას. გადაამოწმეთ, ხართ თუ არა ქსელთან დაკავშირებული და სცადეთ ხელახლა.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = გამონაკლისები…
    .accesskey = ნ
settings-translations-header =
    .aria-label = თარგმანები
    .description = თარგმნეთ გვერდები ან მონიშნული ნაწერი. პირადულობის დასაცავად ნათარგმნი არ ტოვებს თქვენს მოწყობილობას.
    .label = თარგმანები
settings-translations-offer-to-translate-label =
    .label = სრული გვერდის თარგმნის შემოთავაზება
settings-translations-more-settings-button =
    .description = გამართეთ ენები, ვებსაიტები და კავშირგარეშე თარგმნა.
    .label = თარგმნის სხვა პარამეტრები
settings-translations-subpage-header =
    .heading = თარგმნის სხვა პარამეტრები
settings-translations-subpage-speed-up-translation-header =
    .description = ჩამოტვირთეთ სრული ენა კავშირგარეშე სწრაფი თარგმნისთვის.
    .label = თარგმნის ასწრაფება
settings-translations-subpage-automatic-translation-header =
    .label = ავტომატური თარგმანი
settings-translations-subpage-always-translate-header =
    .label = ყოველთვის ითარგმნოს ამ ენებიდან
settings-translations-subpage-never-translate-header =
    .label = არასდროს ითარგმნოს ამ ენებიდან
settings-translations-subpage-never-translate-sites-header =
    .label = არასდროს ითარგმნოს ეს საიტები
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = საიტის დასამატებლად, გახსენით <img data-l10n-name="translations-icon"/> თარგმნის არე, აირჩიეთ <img data-l10n-name="settings-icon"/> თარგმანის პარამეტრები, შემდეგ კი მიუთითეთ „არასდროს ითარგმნოს ეს საიტი”
settings-translations-subpage-language-select-option =
    .label = ენის დამატება
settings-translations-subpage-language-add-button =
    .aria-label = ენის დამატება
    .title = ენის დამატება
settings-translations-subpage-download-languages-header =
    .label = ენების ჩამოტვირთვა
settings-translations-subpage-download-languages-select-option =
    .label = ენის არჩევა
settings-translations-subpage-download-languages-button =
    .aria-label = ენის ჩამოტვირთვა
    .title = ენის ჩამოტვირთვა
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }ᲛᲑ)
    .label = { $language } ({ $size }ᲛᲑ)
settings-translations-subpage-no-languages-downloaded =
    .label = ენები არაა ჩამოტვირთული
settings-translations-subpage-no-languages-added =
    .label = ენები არაა დამატებული
settings-translations-subpage-download-progress = ჩამოტვირთვა მიმდინარეობს…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = { $language } ვერ ჩამოიტვირთა ({ $size }ᲛᲑ)
settings-translations-subpage-download-retry-button =
    .label = ხელახლა ცდა
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = წაიშალოს { $language } ({ $size }ᲛᲑ)?
settings-translations-subpage-download-delete-button =
    .label = წაშლა
settings-translations-subpage-download-cancel-button =
    .label = გაუქმება
settings-translations-subpage-no-sites-added =
    .label = საიტები არაა დამატებული
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = თარიღის, დროის, ციფრებისა და საზომი ერთეულებისთვის საოპერაციო სისტემას მიეთითოს „{ $localeName }“.
settings-spellcheck-header =
    .label = მართლწერის შემოწმება
check-user-spelling =
    .label = მართლწერის შემოწმება აკრეფისთანავე
    .accesskey = მ
spellcheck-download-dictionaries =
    .label = ლექსიკონის ჩამოტვირთვა
spellcheck-promo =
    .heading = როგორ მოწმდება მართლწერა
    .message = მარჯვენა წკაპით ტექსტის ველში ჩართეთ მართლწერის შემოწმება ან მიუთითეთ ენა. ყველა ველში არაა მხარდაჭერილი მართლწერა.

## Downloads - Files and applications

files-and-applications-title = ფაილები და პროგრამები
download-save-files-header =
    .label = ფაილების შესანახი მდებარეობა
download-save-where-3 =
    .aria-label = ფაილების შესანახი მდებარეობა
download-always-ask-where2 =
    .label = შენახვის ადგილის მითითება ფაილის ჩამოტვირთვამდე
    .accesskey = გ
download-private-browsing-delete2 =
    .label = პირადი ფანჯრის ჩამოტვირთვების წაშლა დახურვისას
    .accesskey = უ
applications-header = პროგრამები
applications-description = აირჩიეთ, როგორ მოეპყრას { -brand-short-name } ინტერნეტიდან ჩამოტვირთულ ფაილებს ან იმ პროგრამებს, რომელთაც გვერდების მონახულებისას იყენებთ.
applications-setting2 =
    .description = როგორ მოეპყრას { -brand-short-name } ჩამოტვირთულ ფაილებსა და მასალებს.
    .label = ფაილები და პროგრამები
applications-filter =
    .placeholder = ფაილის სახეობების ან პროგრამების ძიება
applications-type-column =
    .label = მასალის სახეობა
    .accesskey = ლ
applications-type-heading = მასალის სახეობა
applications-action-column =
    .label = ქმედება
    .accesskey = ქ
applications-action-heading = ქმედება
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } ფაილი
applications-action-save =
    .label = ფაილი შეინახება
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = { $app-name } (ნაგულისხმევი)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] macOS-ის ნაგულისხმევი პროგრამა
            [windows] Windows-ის ნაგულისხმევი პროგრამა
           *[other] სისტემის ნაგულისხმევი პროგრამა
        }
applications-use-other =
    .label = სხვა პროგრამა…
applications-select-helper = დამხმარე პროგრამის შერჩევა
applications-manage-app =
    .label = პროგრამის შესახებ…
applications-always-ask =
    .label = შეკითხვა ყოველ ჯერზე
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = გახსნის { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = როგორ მოეპყრას { -brand-short-name } დანარჩენ ფაილებს?
applications-save-for-new-types =
    .label = შეინახოს
    .accesskey = ნ
applications-save-for-new-types2 =
    .label = შეინახოს ფაილები დაუკითხავად
    .accesskey = ხ
applications-ask-before-handling =
    .label = ყოველ ჯერზე იკითხოს, გახსნას თუ შეინახოს
    .accesskey = ჯ
applications-ask-before-handling2 =
    .label = იკითხოს, გახსნას თუ შეინახოს ფაილები
    .accesskey = გ
drm-group =
    .label = ციფრული უფლებების მართვის (DRM) შიგთავსი
play-drm-content =
    .label = DRM-დაქვემდებარებული შიგთავსის გაშვება
    .accesskey = D
play-drm-content-learn-more = ვრცლად
# Variables:
# $version (string) - Firefox version
update-application-version = ვერსია { $version } <a data-l10n-name="learn-more">რა არის ახალი</a>
update-history-2 =
    .label = განახლებების ისტორიის ჩვენება
    .accesskey = ი
update-application-installation =
    .label = დაყენებული
update-application-radio-group =
    .aria-label = დაყენებული
update-application-auto-2 =
    .label = თავადვე დაყენდეს განახლებები (სასურველია)
    .accesskey = ვ
update-application-check-choose-2 =
    .label = შემოწმდეს განახლებები, ოღონდ ასარჩევად, როდის ჩაიდგას
    .accesskey = წ
update-application-background-enabled =
    .label = როცა { -brand-short-name } არაა გაშვებული
    .accesskey = ც
update-application-warning-cross-user-setting-2 =
    .message = ეს პარამეტრები აისახება Windows-ის ყველა ანგარიშსა და ყველა პროფილზე, რომელსაც იყენებს მოცემული { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = განახლების შეხსენებების იშვიათად ჩვენება
    .accesskey = ვ
update-setting-write-failure-title2 = შეცდომა, განახლების პარამეტრების შენახვისას
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } გადააწყდა შეცდომას და ცვლილება არ შეინახა. გაითვალისწინეთ, რომ განახლების ამ პარამეტრის ცვლილება საჭიროებს ქვემოთ მითითებულ ფაილში ჩაწერის ნებართვას. თქვენ ან თქვენი სისტემის ზედამხედველს, შეუძლია ამის მოგვარება მომხმარებლის ჯგუფისთვის, ფაილის სრულად განკარგვის უფლების მინიჭებით.
    
    ვერ მოხერხდა ჩაწერა ფაილში: { $path }
update-in-progress-title = განახლება მიმდინარეობს
update-in-progress-message = გსურთ, რომ განახლდეს { -brand-short-name } ამ განახლების ჩადგმით?
update-in-progress-ok-button = &უარყოფა
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &გაგრძელება

## About Firefox

about-firefox-header =
    .heading = { -brand-short-name } შესახებ

## Firefox updates

update-application-heading =
    .description = განახლბებით { -brand-short-name } უმჯობესდება სისწრაფის, მდგრადობისა და უსაფრთხოების კუთხით.
    .label = { -brand-short-name } – განახლებები
update-application-suppress-prompts-heading =
    .label = შეტყობინებები
update-application-updates-managed-by-os =
    .message = განახლებები იმართება თქვენი საოპერაციო სისტემით

## Firefox support

support-application-heading =
    .description = მოაგვარეთ ხარვეზები ან გაუზიარეთ მოსაზრებები ერთობის წევრებს.
    .label = { -brand-short-name } – მხარდაჭერა
support-get-help =
    .label = დახმარების მიღება
support-share-ideas =
    .label = მოსაზრების მოხსენება და გამოხმაურება

## Firefox newsletter

newsletter-settings-heading =
    .description = გაეცანით მითითებებს, რჩევებსა და სიახლეებს, რომ თქვენთვის მეტად შედეგიანად გამოიყენოთ { -brand-product-name }.
    .label = { -brand-product-name } – სიახლეთა ცნობარი
newsletter-sign-up-link =
    .label = შექმნა

## General Section - Performance

performance-settings-learn-more = ვრცლად
performance-allow-hw-accel =
    .label = ხელმისაწვდომობის შემთხვევაში აპარატული აჩქარების გამოყენება
    .accesskey = მ
performance-limit-content-process-option = შიგთავსის პროცესების შეზღუდვა
    .accesskey = ზ
performance-limit-content-process-enabled-desc = შიგთავსის დამატებით პროცესებს ბევრი ჩანართით სარგებლობისას შეუძლია წარმადობის გაუმჯობესება, მაგრამ ასევე გამოიყენებს მეტ მეხსიერებას.
performance-limit-content-process-blocked-desc = შიგთავსის პროცესების რაოდენობის შეცვლის შესაძლებლობას, მხოლოდ მრავალპროცესიანი { -brand-short-name } იძლევა. <a data-l10n-name="learn-more">იხილეთ, თუ როგორ უნდა შემოწმდეს ჩართულია თუ არა მრავალპროცესიანობა</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (ნაგულისხმევი)
performance-group =
    .label = წარმადობა
performance-use-recommended-settings-checkbox-2 =
    .description = ეს პარამეტრები მორგებულია თქვენს აპარატურასა და საოპერაციო სისტემაზე.
    .label = წარმადობის სასურველი პარამეტრების გამოყენება
    .accesskey = ყ

## Accessibility page

browsing-use-autoscroll =
    .label = თვითგადაადგილების გამოყენება
    .accesskey = თ
keyboard-and-scrolling-group =
    .label = კლავიატურით მოძრაობა და გადაადგილება
motion-and-link-group =
    .label = მოძრაობა და ბმულების გაფორმება
browsing-use-smooth-scrolling =
    .label = გლუვი გადაადგილების გამოყენება
    .accesskey = გ
browsing-gtk-use-non-overlay-scrollbars =
    .label = რბიის ზოლის გამოჩენა ყოველთვის
    .accesskey = რ
browsing-always-underline-links =
    .label = ბმულების ხაზგასმა ყოველთვის
    .accesskey = უ
browsing-use-onscreen-keyboard =
    .label = ეკრანული კლავიატურის ჩვენება საჭიროების შემთხვევაში
    .accesskey = კ
browsing-use-cursor-navigation =
    .label = გვერდის ნაწერებში მაჩვენებლის გამოჩენა ყოველთვის
    .accesskey = რ
browsing-use-full-keyboard-navigation =
    .label = ველებში (TAB) ღილაკით გადასვლა სამართავიდან ბმულებზე და პირიქით
    .accesskey = ვ
browsing-search-on-start-typing =
    .label = ტექსტის ძიება აკრეფის დაწყებისთანავე
    .accesskey = ტ
settings-keyboard-shortcuts-group =
    .description = მართეთ, გადაადგილებისა და ურთიერთქმედებისას როგორ გამოიყენოთ { -brand-short-name }.
    .label = კლავიატურის მალსახმობები
settings-keyboard-shortcuts-customkeys-link =
    .label = კლავიატურის მალსახმობების მორგება
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = მოირგეთ მისამართების ველის პარამეტრები საძიებოში
settings-media-group =
    .label = ფაილები
browsing-picture-in-picture-toggle-enabled-2 =
    .label = გაეშვას ეკრანი-ეკრანში
    .accesskey = კ
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = ჩანართის შეცვლისას დარჩეს გაშვებული ვიდეოები ეკრანი-ეკრანში
    .accesskey = კ
browsing-media-control =
    .label = გაშვებული ფაილების მართვა კლავიშებით, ყურსასმენით ან პროგრამულად
    .accesskey = ფ
recommendations-group =
    .label = შემოთავაზებები
browsing-cfr-recommendations =
    .label = გაფართოებების შემოთავაზებები ძიებისას
    .accesskey = შ
browsing-cfr-features =
    .label = შესაძლებლობების შემოთავაზებები გვერდების მონახულებისას
    .accesskey = ზ
browsing-group =
    .label = გვერდების მონახულება
preferences-accessibility-header =
    .heading = ხელმისაწვდომობა
preferences-default-zoom-select =
    .aria-label = ნაგულისხმევი მოახლოება
preferences-fonts-family =
    .label = შრიფტის ოჯახი
    .accesskey = ფ
preferences-fonts-size =
    .label = შრიფტის ზომა
    .accesskey = ზ
preferences-fonts-advanced-settings =
    .label = გაფართოებული პარამეტრები
    .accesskey = ო

## General Section - Proxy

network-proxy-group2 =
    .description = გამართეთ, როგორ დაუკავშირდეს { -brand-short-name } ქსელს.
    .label = შუამავლის პარამეტრები
network-proxy-connection-settings2 =
    .description = ამ პარამეტრების ცვლილებამ შეიძლება შეაფერხოს კავშირი.
    .label = გამართეთ ქსელის შუამავალი
    .accesskey = უ

## Home Section

home-new-windows-tabs-header = ახალი ფანჯრები და ჩანართები
home-new-windows-tabs-description2 = მიუთითეთ, რისი ხილვა გსურთ საწყისი გვერდის, ახალი ფანჯრებისა და ახალი ჩანართების გახსნისას.
home-section =
    .heading = მთავარი და საწყისი

## Home Section - Default Browser

home-default-browser-title =
    .label = ნაგულისხმევი ბრაუზერი
is-default-browser-2 =
    .message = { -brand-short-name } ნაგულისხმევი ბრაუზერია. გონივრული არჩევანია.
is-not-default-browser-2 =
    .message = ჰმ, { -brand-short-name } არ აგირჩევიათ ნაგულისხმევად.
set-as-my-default-browser-2 =
    .label = ნაგულისხმევად მითითება
    .accesskey = ნ

## Custom Homepage subpage

home-homepage-mode-label = საწყისი გვერდი და ახალი ფანჯრები
home-newtabs-mode-label = ახალი ჩანართები
home-restore-defaults =
    .label = ნაგულისხმევის აღდგენა
    .accesskey = ნ
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (ნაგულისხმევი)
home-mode-choice-custom =
    .label = მითითებული URL-მისამართები...
home-mode-choice-blank =
    .label = ცარიელი გვერდი
home-homepage-custom-url =
    .placeholder = URL-მისამართის ჩასმა...
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = გაფართოების მართვა
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] მიმდინარე გვერდი
           *[other] მიმდინარე გვერდები
        }
    .accesskey = მ
choose-bookmark =
    .label = სანიშნის გამოყენება…
    .accesskey = ს
home-homepage-title =
    .label = საწყისი გვერდი
home-homepage-new-windows =
    .label = ახალი ფანჯრები
home-homepage-new-tabs =
    .label = ახალი ჩანართები
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = აირჩიეთ ცალკეული საიტი
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = საიტის მისამართ(ებ)ი
home-custom-homepage-list =
    .aria-label = საიტის მისამართები
home-custom-homepage-address =
    .placeholder = შეიყვანეთ მისამართი
home-custom-homepage-address-button =
    .label = მისამართის დამატება
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = საიტები ჯერ არ დამატებულა.
home-custom-homepage-delete-address-button =
    .aria-label = მისამართის წაშლა
    .title = მისამართის წაშლა
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = ჩაანაცვლებს
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = ახლად გახსნილი გვერდები
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = სანიშნები…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = გაფართოება ({ $extension })
home-custom-homepage-header = მორგებული საწყისი გვერდი
home-custom-homepage-subpage =
    .heading = მორგებული საწყისი გვერდი

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name } – შიგთავსი
home-prefs-content-description2 = აირჩიეთ, რისი ხილვა გსურთ { -firefox-home-brand-name(case: "loc") }
home-prefs-search-header =
    .label = საძიებო ველი
home-prefs-shortcuts-header =
    .label = მალსახმობები
home-prefs-shortcuts-description = საიტები, რომლებსაც ინახავთ ან სტუმრობთ
home-prefs-shortcuts-by-option-sponsored =
    .label = მალსახმობები დამკვეთებისგან
home-prefs-recommended-by-header-generic =
    .label = შემოთავაზებული ამბები
home-prefs-recommended-by-description-generic = გამორჩეული მასალები, რომელთაც გთავაზობთ { -brand-product-name }-ოჯახი
home-prefs-stories-header =
    .label = ამბები
home-prefs-stories-description = თქვენს საქმიანობაზე მორგებული ამბები

##

home-prefs-recommended-by-learn-more = როგორ მუშაობს
home-prefs-recommended-by-option-sponsored-stories =
    .label = ამბები დამკვეთებისგან
home-prefs-highlights-option-visited-pages =
    .label = მონახულებული გვერდები
home-prefs-highlights-options-bookmarks =
    .label = სანიშნები
home-prefs-highlights-option-most-recent-download =
    .label = ბოლო ჩამოტვირთვები
home-prefs-recent-activity-header =
    .label = ბოლო მოქმედებები
home-prefs-recent-activity-description = ბოლოს ნანახი საიტებისა და მასალებიდან შერჩეული
home-prefs-weather-header =
    .label = ამინდი
home-prefs-weather-description = მოსალოდნელი ამინდისთვის თვალის შევლება
home-prefs-weather-learn-more-link = ვრცლად
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = თანადგომა – { -brand-product-name }
home-prefs-mission-message = ჩვენი დამკვეთები მხარს უჭერენ ჩვენს მიზანს უკეთესი ვებსივრცის ჩამოსაყალიბებლად
home-prefs-mission-message-learn-more-link = იხილეთ, როგორ
home-prefs-manage-topics-link = თემების მართვა
home-prefs-choose-wallpaper-link = ფონის არჩევა
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } რიგად
           *[other] { $num } რიგად
        }

## Search Section

search-show-suggestions-option =
    .label = ძიების შემოთავაზების ჩვენება
    .accesskey = ზ
search-show-suggestions-url-bar-option =
    .label = ძიების შემოთავაზებები მისამართების ველის შედეგებში
    .accesskey = ძ
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = ძიების შემოთავაზებების გამოჩენა მონახულებულ გვერდებზე წინ, მისამართების ველის შედეგებში
search-show-suggestions-private-windows-2 =
    .label = ძიების შემოთავაზებები პირად ფანჯრებში
search-suggestions-cant-show-2 =
    .message = მისამართების ველში ძიების შემოთავაზებები არ გამოჩნდება, ვინაიდან მითითებული გაქვთ, რომ { -brand-short-name } არასოდეს დაიმახსოვრებს ისტორიას.
addressbar-header-1 =
    .description = აირჩიეთ, რომელი შემოთავაზებები გამოჩნდეს თქვენი მისამართების ველში
    .label = მისამართების ველი
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = მისამართების ველში შემოთავაზებების წყაროა { -brand-short-name } და ჩვენი მოკავშირეები.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = საძიებო სიტყვების ჩვენება მისამართების ველში შედეგების გვერდზე
search-separate-default-engine-2 =
    .label = აირჩიეთ განსხვავებული საძიებო პირადი ფანჯრებისთვის
    .accesskey = რ
search-separate-default-engine-dropdown =
    .aria-label = ნაგულისხმევი საძიებო პირად ფანჯრებში
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = მისამართების ველში გადაადგილება
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = შედეგების მენიუს გამოტოვება Tab-ღილაკით გადაადგილებისას
search-suggestions-header-2 =
    .label = საძიებოს შემოთავაზებები
search-one-click-header2 = ძიების მალსახმობები
search-one-click-desc = მიუთითეთ სათადარიგო საძიებოები, რომლებიც გამოჩნდება მისამართებისა და ძიების ველების ქვემოთ საძებნი ფრაზის აკრეფისას.
search-one-click-header-3 =
    .description = აირჩიეთ რომელი საძიებო და მალსახმობი გამოჩნდეს მისამართების ველში.
    .label = დამატებითი საძიებოები
search-engine-list =
    .aria-label = საძიებოები და მალსახმობები
update-search-engine-success =
    .message = საძიებო წარმატებით განახლდა
search-edit-engine-2 =
    .title = საძიებო სისტემის ჩასწორება
search-delete-engine =
    .title = საძიებოს წაშლა
search-enable-engine =
    .title = საძიებოს ჩართვა
search-outlink-to-extensions-page =
    .title = გაფართოებებისა და გაფორმებების მართვა
search-choose-engine-column =
    .label = საძიებო სისტემა
search-choose-keyword-column =
    .label = საკვანძო სიტყვა
search-restore-default =
    .label = ნაგულისხმევი საძიებო სისტემების აღდგენა
    .accesskey = ნ
search-remove-engine =
    .label = ამოშლა
    .accesskey = ა
search-add-engine =
    .label = დამატება
    .accesskey = ტ
search-add-engine-2 =
    .label = საძიებოს დამატება
    .accesskey = ტ
search-edit-engine =
    .label = ჩასწორება
    .accesskey = წ
search-find-more-link = სხვა საძიებო სისტემების მონახვა
search-filtering-for-add-engine = საძიებოს დამატება
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = საკვანძო სიტყვა უკვე გამოყენებულია
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = თქვენ მიერ შერჩეულ საკვანძო სიტყვას უკვე იყენებს "{ $name }". გთხოვთ, შეარჩიოთ სხვა.
search-keyword-warning-bookmark = თქვენ მიერ შერჩეულ საკვანძო სიტყვას უკვე იყენებს სანიშნი. გთხოვთ, შეარჩიოთ სხვა.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = საძიებო უკვე არსებობს სახელით „{ $name }“. გთხოვთ, აირჩიოთ სხვა სახელი.
remove-engine-confirmation = ნამდვილად გსურთ ამ საძიებოს მოცილება?
remove-engine-remove = მოცილება
remove-addon-engine-alert = ამ საძიებო სისტემის მოსაცილებლად მოაცილეთ შესაბამისი დამატება.
search-engine-group =
    .label = ნაგულისხმევი საძიებო სისტემა
search-default-engine =
    .aria-label = ნაგულისხმევი საძიებო სისტემა
# Header for the search section ("search" is a noun).
search-section =
    .heading = ძიება

## Containers Section

containers-section-header2 =
    .heading = სათავსის პარამეტრები
containers-card-header2 =
    .description = განაცალკევეთ ფუნთუშები სათავსებით, რომ შეძლოთ სხვადასხვა ანგარიშის გამოიყენება ერთსა და იმავე საიტზე ან შეზღუდოთ საიტთაშორისი მიყურადება.
    .label = სათავსები
containers-add-button2 =
    .label = ახალი სათავსის დამატება
    .accesskey = დ
containers-list =
    .aria-label = სათავსები
containers-new-tab-check3 =
    .label = სათავსის შერჩევა თითოეული ახალი ჩანართისთვის
    .accesskey = რ
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = არ გამოიყენებოდეს სათავსები გარე პროგრამებით გახსნილი ბმულებისთვის
    .accesskey = რ
containers-new-tab-check2 =
    .description = ყოველი ახალი ჩანართის გახსნისას გამოჩნდება სათავსის ასარჩევი
    .label = სათავსის შერჩევა თითოეული ახალი ჩანართისთვის
    .accesskey = რ
containers-settings-button2 =
    .title = პარამეტრები
containers-remove-button3 =
    .title = წაშლა
containers-sites-card-header =
    .description = აირჩიეთ საიტისთვის სათავსი და { -brand-short-name } გამოიყენებს ყოველ ჯერზე მისი გახსნისას.
    .label = სათავსები საიტის მიხედვით
containers-sites-add-button =
    .label = ვებსაიტის დამატება
    .accesskey = ვ
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = სათავსი საიტისთვის { $site }
containers-site-remove-button =
    .title = წაშლა
containers-remove-button2 =
    .title = მოცილება

## Account and sync

sync-group-label =
    .label = სინქრონიზაცია
account-group-label2 =
    .label = ანგარიში
account-disabled-group =
    .description = ანგარიშის გამართვა მიუწვდომელია.
    .label = ანგარიში
account-placeholder2 =
    .description = შედით, რომ თქვენი მონაცემები დარჩეს ხელშეუხებელი, დაშიფრული და მყისიერად ხელმისაწვდომი ყველგან, სადაც კი გიყენიათ { -brand-short-name }.
    .label = შესული არ ხართ.
account-sync-section =
    .heading = ანგარიში და დასინქრონება
pane-account-sync-title2 = ანგარიში და დასინქრონება
    .title = ანგარიში და დასინქრონება

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = გაიყოლეთ თქვენი მონაცემები თან
sync-signedout-description2 = დაასინქრონეთ თქვენი სანიშნები, ისტორია, ჩანართები, პაროლები, დამატებები და პარამეტრები ყველა მოწყობილობაზე.
sync-signedout-account-signin3 =
    .label = სინქრონიზაციაში შესვლა
    .accesskey = ი
sync-signedout-account-signin-4 =
    .label = შედით თქვენს ანგარიშზე დასინქრონებისთვის
    .accesskey = დ
sync-signedout-account-short =
    .label = შესვლა
    .accesskey = ს
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Firefox ჩამოტვირთეთ <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android-ზე</a> ან <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS-ზე</a> თქვენს მობილურ მოწყობილობასთან სინქრონიზაციისთვის.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = პროფილის სურათის შეცვლა
    .tooltiptext = პროფილის სურათის შეცვლა
sync-profile-picture-account-problem =
    .alt = ანგარიშის პროფილის სურათი
fxa-login-rejected-warning =
    .alt = გაფრთხილება
sync-sign-out =
    .label = გამოსვლა...
    .accesskey = გ
sync-sign-out2 =
    .label = გამოსვლა
    .accesskey = გ
sync-manage-account = ანგარიშის მართვა
    .accesskey = მ
sync-manage-account2 =
    .label = ანგარიშის მართვა
    .accesskey = მ

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } გადამოწმებული არაა.
sync-signedin-unverified2 =
    .description = იხილეთ საფოსტო ყუთი ანგარიშის დასამოწმებლად და ასამოქმედებლად
    .label = { $email } ჯერ არ დამოწმებულა
sync-signedin-login-failure = ხელახლა დასაკავშირებლად გთხოვთ შედით სისტემაში { $email }
sync-signedin-login-failure2 =
    .description = კვლავ შედით მისაერთებლად და მონაცემთა დასინქრონებისთვის.
    .label = თქვენ გამოსული ხართ ანგარიშიდან { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = ანგარიშის დამოწმება
    .accesskey = წ
sync-remove-account =
    .label = ანგარიშის წაშლა
    .accesskey = წ
sync-sign-in =
    .label = შესვლა
    .accesskey = ვ

## Sync section - enabling or disabling sync.

prefs-syncing-on = დასინქრონება: ჩართ.
prefs-syncing-on-2 =
    .label = დასინქრონება ჩართ.
prefs-syncing-off = დასინქრონება: გამორ.
prefs-syncing-off-2 =
    .description = ჩართეთ სინქრონიზაცია სანიშნების, პაროლების, ისტორიისა და სხვა მონაცემების ნებისმიერ მოწყობილობაზე მისაღებად.
    .label = დასინქრონება გამორ.
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = ჩართეთ სინქრონიზაცია ამ მოწყობილობაზე, რომ მიიღოთ თქვენი სანიშნები, პაროლები, ისტორია თუ სხვ.
    .label = დასინქრონება გამორთულია
prefs-sync-turn-on-syncing =
    .label = დასინქრონების ჩართვა…
    .accesskey = ქ
prefs-sync-turn-on-syncing-2 =
    .label = დასინქრონების ჩართვა
    .accesskey = ქ
prefs-sync-offer-setup-label2 = დაასინქრონეთ თქვენი სანიშნები, ისტორია, ჩანართები, პაროლები, დამატებები და პარამეტრები ყველა მოწყობილობაზე.
prefs-sync-now-button =
    .label = დასინქრონება ახლავე
    .accesskey = ნ
prefs-sync-now-button-2 =
    .label = დასინქრონება ახლავე
    .accesskey = ნ
prefs-syncing-button =
    .label = სინქრონდება...
prefs-syncing-button-2 =
    .label = სინქრონდება...
    .title = დასინქრონება ახლავე
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = დასასინქრონებლის ასარჩევი ამიერიდან მხოლოდ ამ მოწყობილობას ეხება.

## The list of things currently syncing.

sync-syncing-across-devices-heading = ეს ერთეულები დასინქრონებული გაქვთ ყველა დაკავშირებულ მოწყობილობაში:
sync-syncing-across-devices-heading-2 = მონაცემები დასინქრონებულია მოწყობილობებს შორის.
sync-syncing-across-devices-heading-3 = მონაცემები სინქრონირდება ამ მოწყობილობაზე
sync-syncing-across-devices-empty-state2 =
    .description = ჯერ არაფერი დაგისინქრონებიათ… დაიწყეთ დასინქრონება, რომ თქვენი მონაცემები ხელთ გქონდეთ ყველა თქვენს მოწყობილობაზე.
    .label = მართეთ დასინქ. მონაცემები
sync-syncing-across-devices-empty-state3 =
    .description = ჯერ არაფერი დასინქრონებულა… აირჩიეთ, რისი დასინქრონება გსურთ ამ მოწყობილობაზე.
    .label = დასინქ. მონაცემების მართვა
sync-currently-syncing-bookmarks = სანიშნები
sync-currently-syncing-history = ისტორია
sync-currently-syncing-tabs = გახსნილი ჩანართები
sync-currently-syncing-passwords = პაროლები
sync-currently-syncing-addresses = მისამართები
sync-currently-syncing-payment-methods = გადახდის საშუალებები
sync-currently-syncing-addons = დამატებები
sync-currently-syncing-settings = პარამეტრები
sync-manage-options =
    .label = სინქრონიზაციის მართვა…
    .accesskey = მ
sync-manage-options-2 =
    .label = დასინქრონებული მონაცემების მართვა
    .accesskey = მ
settings-sync-disconnect-button =
    .label = გამოთიშვა

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = სანიშნები
    .accesskey = ს
sync-engine-history =
    .label = ისტორია
    .accesskey = ი
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = გახსნილი ჩანართები
    .tooltiptext = გახსნილი ჩანართები თქვენი სხვა მოწყობილობებიდან
    .accesskey = თ
sync-engine-tabs =
    .label = გახსნილი ჩანართები
    .tooltiptext = ყველა დასინქრონებულ მოწყობილობაზე გახსნილი ჩანართების სია
    .accesskey = ჩ
sync-engine-passwords =
    .label = პაროლები
    .tooltiptext = შენახული პაროლები
    .accesskey = პ
sync-engine-addresses2 =
    .label = მისამართები
    .tooltiptext = მისამართები, რომელთაც ინახავს { -brand-short-name }
    .accesskey = მ
sync-engine-payment-methods3 =
    .label = გადახდის საშუალებები
    .tooltiptext = შენახული გადახდის საშუალებები
    .accesskey = უ
sync-engine-addons2 =
    .label = დამატებები
    .tooltiptext = გაფართოებები და თემები, რომლებითაც აღჭურვილია { -brand-short-name } კომპიუტერზე
    .accesskey = დ
sync-engine-settings2 =
    .label = პარამეტრები
    .tooltiptext = პარამეტრები, რომლებთანაც თავსებადია { -brand-short-name }
    .accesskey = პ
sync-engine-addresses =
    .label = მისამართები
    .tooltiptext = შენახული საფოსტო მისამართები (კომპიუტერზე მხოლოდ)
    .accesskey = მ
sync-engine-payment-methods2 =
    .label = გადახდის საშუალებები
    .tooltiptext = სახელები, ბარათის ნომრები, ვადის თარიღები
    .accesskey = უ
sync-engine-addons =
    .label = დამატებები
    .tooltiptext = Firefox სამაგიდო ვერსიის გაფართოებები და თემები
    .accesskey = დ
sync-engine-settings =
    .label = პარამეტრები
    .tooltiptext = შეცვლილი მთავარი, პირადულობისა და უსაფრთხოების პარამეტრები
    .accesskey = პ
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = შენახვა
    .buttonlabelextra2 = გამოთიშვა…
    .buttonaccesskeyaccept = ხ
    .buttonaccesskeyextra2 = გ
    .style = min-width: 36em;
    .title = მართეთ, რა დასინქრონირდეს ყველა თქვენს მოწყობილობაზე
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = შენახვა
    .buttonlabelextra2 = გამოთიშვა…
    .buttonaccesskeyaccept = ხ
    .buttonaccesskeyextra2 = ო
    .style = min-width: 36em;
    .title = მართეთ, რა დასინქრონდეს ამ მოწყობილობაზე

## The device name controls.

sync-device-name-header = მოწყობილობის სახელი
sync-device-name-header-2 =
    .label = მოწყობილობის სახელი
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = მოწყობილობის სახელი
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = მოწყობილობის სახელის შეცვლა
    .accesskey = ს
sync-device-name-change =
    .label = მოწყობილობის სახელის შეცვლა…
    .accesskey = ს
sync-device-name-cancel =
    .label = გაუქმება
    .accesskey = გ
sync-device-name-save =
    .label = შენახვა
    .accesskey = ე
sync-connect-another-device = სხვა მოწყობილობასთან დაკავშირება
sync-connect-another-device-2 =
    .label = სხვა მოწყობილობასთან დაკავშირება

## Privacy Section

privacy-header = ბრაუზერის პირადულობა

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = პაროლები
    .searchkeywords = ანგარიშები
forms-passwords-header =
    .aria-label = პაროლები
    .label = პაროლები
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = პაროლის შენახვის მოთხოვნა
    .accesskey = თ
forms-manage-password-exceptions =
    .label = პაროლების გამონაკლისების მართვა
    .accesskey = ვ
forms-exceptions =
    .label = გამონაკლისები…
    .accesskey = ნ
forms-suggest-passwords =
    .label = მძლავრი პაროლის შემოთავაზება…
    .accesskey = მ
forms-breach-alerts =
    .label = ცნობები პაროლების შესახებ იერიშმიტანილი საიტებიდან
    .accesskey = შ
forms-breach-alerts-learn-more-link = ვრცლად
preferences-relay-integration-checkbox2 =
    .label = { -relay-brand-name } შემოგთავაზებთ ელფოსტის დაცვას შენიღბვით
    .accesskey = ფ
relay-integration-learn-more-link = ვრცლად
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = მომხმარებლის სახელებისა და პაროლების თვითშევსება
    .accesskey = ო
forms-fill-usernames-and-passwords-2 =
    .label = მეტსახელებისა თუ პაროლების შენახვა და თვითშევსება
    .accesskey = მ
forms-saved-passwords =
    .label = შენახული პაროლები
    .accesskey = ო
forms-saved-passwords-2 =
    .label = შენახული პაროლების მართვა
    .accesskey = უ
forms-saved-passwords-searchkeywords = საიტები, რომელთა ანგარიშის მონაცემებიც თქვენს კომპიუტერში ინახება
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = დამატებითი უსაფრთხოება
forms-primary-pw-use =
    .label = მთავარი პაროლის გამოყენება
    .accesskey = გ
forms-primary-pw-use-2 =
    .description = ამატებს უსაფრთხოების დამატებით შრეს პაროლების დასაცავად.
    .label = მთავარი პაროლის გამოყენება
    .accesskey = ყ
forms-primary-pw-set =
    .label = მთავარი პაროლის დაყენება
forms-primary-pw-on-2 = მთავარი პაროლი <strong>ᲩᲐᲠᲗ.</strong>
forms-primary-pw-on =
    .label = მთავარი პაროლი ᲩᲐᲠᲗ.
forms-primary-pw-change-2 =
    .label = ჩემი პაროლის შეცვლა
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = გამორთვა
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = საჭიროა მოწყობილობით დამოწმება პაროლების შესავსებად და სამართავად
forms-os-reauth-2 =
    .label = საჭიროა მოწყობილობით დამოწმება პაროლების სამართავად
forms-primary-pw-learn-more-link = ვრცლად
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = მთავარი პაროლის შეცვლა…
    .accesskey = მ
forms-primary-pw-change =
    .label = მთავარი პაროლის შეცვლა…
    .accesskey = მ
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = თქვენ FIPS-რეჟიმში იმყოფებით. FIPS-ს ესაჭიროება მთავარი პაროლი.
forms-master-pw-fips-desc = პაროლის შეცვლა ვერ მოხერხდა
forms-windows-sso =
    .label = Windows-ით ერთიანად შესვლის დაშვება, Microsoft-ის, სამუშაოს ან სკოლის ანგარიშებზე
forms-windows-sso-learn-more-link = ვრცლად
forms-windows-sso-desc = ანგარიშების მართვა, მოწყობილობის პარამეტრებიდან
windows-passkey-settings-label = საშვების მართვა სისტემის პარამეტრებში
privacy-panel-settings-header =
    .description = დაიხმარეთ { -brand-short-name } თქვენი მონაცემების დასაცავად ინტერნეტში.
    .label = პირადულობის განყოფილების გამართვა
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = მიტაცების ცნობების ჩვენება
    .accesskey = ც

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = მთავარი პაროლის შესაქმნელად, დაამოწმეთ Windows-ანგარიში. ეს დაგეხმარებათ დაიცვათ თქვენი ანგარიშების უსაფრთხოება.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = მთავარი პაროლის დაყენებას
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] პარამეტრების შეცვლას გადახდის საშუალებებისთვის
       *[other] { -brand-short-name } ცდილობს შეცვალოს გადახდის საშუალებების პარამეტრები. გამოიყენეთ მოწყობილობით შესვლის დამოწმება ნების მისაცემად.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = გადახდის საშუალებები
autofill-payment-methods-checkbox-message-2 =
    .label = შეინახოს და შეივსოს გადახდის მონაცემები
    .accesskey = დ
autofill-payment-methods-manage-payments-title =
    .heading = გადახდის საშუალებების მართვა
autofill-payment-methods-manage-payments-button =
    .label = გადახდის საშუალებების მართვა
    .accesskey = მ
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = საჭიროებს მოწყობილობით შესვლას თვითშევსებისთვის
    .accesskey = ვ
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = საჭიროა მოწყობილობით დამოწმება გადახდის მონაცემების შესავსებად და სამართავად
    .accesskey = ვ
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = უსაფრთხოების კოდების შენახვა
    .accesskey = უ
autofill-payment-methods-add-button = გადახდის საშუალების დამატება
payments-list-header =
    .label = გადახდის საშუალებები
payments-delete-payment-prompt-title = მოცილდეს გადახდის ეს საშუალება?
payments-delete-payment-prompt-confirm-button = წაშლა
payments-delete-payment-prompt-cancel-button = გაუქმება
payments-delete-payment-button-label =
    .aria-label = წაშლა
payments-edit-payment-button-label =
    .aria-label = ჩასწორება
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = გადახდის საშუალება არაა დამატებული
autofill-addresses-checkbox-message =
    .label = მისამართების შენახვა და თვითშევსება
    .accesskey = ნ
autofill-addresses-manage-addresses-button =
    .label = მისამართების მართვა და სხვა
    .accesskey = მ
addresses-list-header =
    .label = მისამართები
addreses-delete-address-button-label =
    .aria-label = წაშლა
addreses-edit-address-button-label =
    .aria-label = ჩასწორება
addresses-delete-address-prompt-title = წაიშალოს მისამართი?
addresses-delete-address-prompt-confirm-button = წაშლა
addresses-delete-address-prompt-cancel-button = გაუქმება
autofill-addresses-add-button = ახალი მისამართის დამატება
autofill-addresses-manage-addresses-title =
    .heading = მისამართების მართვა და სხვა
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = მისამართები არაა დამატებული
personal-info-group =
    .label = პირადი მონაცემები
autofill-personal-info-checkbox-message =
    .label = პირად მონაცემთა შენახვა და თვითშევსება
autofill-personal-info-manage-button =
    .label = პირადი მონაცემების მართვა
passports-list-header =
    .label = პასპორტები
passports-delete-passport-button-label =
    .aria-label = წაშლა
passports-edit-passport-button-label =
    .aria-label = ჩასწორება
passports-delete-passport-prompt-title = წაიშალოს ეს პასპორტი?
passports-delete-passport-prompt-confirm-button = წაშლა
passports-delete-passport-prompt-cancel-button = გაუქმება
autofill-passports-add-button = ახალი პასპორტის დამატება
autofill-personal-info-manage-title =
    .heading = პირადი მონაცემების მართვა
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = პასპორტები არ დამატებულა
pane-passwords-autofill-title2 = პაროლები და თვითშევსება
    .title = პაროლები და თვითშევსება
preferences-passwords-autofill-header =
    .heading = პაროლები და თვითშევსება
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } შენახულია
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } შენახულია
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = მისამართები და სხვა
payments-group =
    .label = გადახდის საშუალებები

## Privacy Section - History

history-remember-option-never2 =
    .description = ყველა ფანჯარა იმოქმედებს პირადი ფანჯრების მსგავსად. როცა ჩართულია, გაფართოებები საჭიროებს ნების დართვას.
    .label = არასოდეს დაიმახსოვრებს
history-remember-option-custom2 =
    .label = დაიმახსოვრებს შერჩეულს
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } შეინახავს მონახულებული გვერდების, ჩამოტვირთვების, შევსებული ველებისა და ძიების ისტორიას.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } ისარგებლებს პირადი ფანჯრის პარამეტრებით და არ შეინახავს თქვენ მიერ მონახულებული საიტების ისტორიას.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } გამოიყენებს მორგებულ პარამეტრებს მონახულებული გვერდების, ჩამოთვირთვების, შევსებული ველებისა თუ მოძიებული გვერდების მიხედვით.
history-private-browsing-permanent =
    .label = ყოველთვის პირადი დათვალიერების გამოყენება
    .accesskey = პ
history-remember-browser-option =
    .label = გვერდებისა და ჩამოტვირთვების ისტორიის დამახსოვრება
    .accesskey = გ
history-remember-search-option =
    .label = ძიებისა და ველების ისტორიის დამახსოვრება
    .accesskey = ვ
history-clear-on-close-option =
    .label = ისტორიის გასუფთავება, როცა { -brand-short-name } დაიხურება
    .accesskey = ფ
history-clear-on-close-settings =
    .label = პარამეტრები…
    .accesskey = ტ
history-shutdown-exceptions =
    .label = გამონაკლისების მართვა
    .accesskey = კ
history-clear-button =
    .label = ისტორიის გასუფთავება…
    .accesskey = ს
history-header2 =
    .heading = ისტორია
history-section-header =
    .description = აირჩიეთ, თუ რას დაიმახსოვრებს { -brand-short-name }, როცა ბრაუზერს დახურავთ.
    .label = History
history-custom-section-header =
    .description = მოირგეთ სურვილისამებრ, თუ რას დაიმახსოვრებს { -brand-short-name }, როცა დახურავთ ბრაუზერს.
    .label = გაფართოებული პარამეტრები
history-custom-button =
    .label = აირჩიეთ სურვილისამებრ, თუ რას დაიმახსოვრებს { -brand-short-name }
history-group =
    .label = ისტორია
history-mode-radio-group =
    .aria-label = ისტორია
history-remember-option-all2 =
    .label = დაიმახსოვრებს ისტორიას

## Privacy Section - Site Data

sitedata-total-size-calculating = ითვლება საიტის მუდმივი და დროებითი მონაცემების მოცულობა…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = ვებსაიტები ამჟამად იყენებს <strong>{ $value } { $unit }</strong> ადგილს დისკზე.
sitedata-learn-more = ვრცლად
sitedata-delete-on-close2 =
    .label = გასუფთავდეს ფუნთუშები და საიტის მონაცემები ყოველ ჯერზე, როცა { -brand-short-name } დაიხურება
    .accesskey = ფ
sitedata-delete-on-close-private-browsing3 =
    .message = თქვენი ისტორიის პარამეტრებიდან გამომდინარე { -brand-short-name } წაშლის ფუნთუშებსა და საიტის მონაცემებს ბრაუზერის დახურვისას.
sitedata-delete-on-close-private-browsing4 =
    .heading = ისტორია არ შეინახება.
    .message = { -brand-short-name } გაასუფთავებს ფუნთუშებსა და საიტის მონაცემებს, როცა ბრაუზერი დაიხურება.
sitedata-option-block-cross-site-trackers =
    .label = საიტთაშორისი მეთვალყურეები
sitedata-option-block-cross-site-tracking-cookies =
    .label = საიტთაშორისი მეთვალყურე ფუნთუშები
sitedata-option-block-cross-site-cookies2 =
    .label = საიტთაშორისი ფუნთუშების გამიჯვნა
sitedata-option-block-unvisited =
    .label = ფუნთუშები მოუნახულებელი საიტებიდან
sitedata-option-block-all-cross-site-cookies =
    .label = ყველა საიტთაშორისი ფუნთუშა (იწვევს ზოგი საიტის გაუმართაობას)
sitedata-option-block-all =
    .label = ყველა ფუნთუშა (იწვევს საიტების გაუმართაობას)
sitedata-clear2 =
    .label = დათვალიერების მონაცემების წაშლა
    .accesskey = წ
sitedata-settings2 =
    .label = დათვალიერების მონაცემების მართვა
    .accesskey = თ
sitedata-cookies-exceptions =
    .label = გამონაკლისების მართვა
    .accesskey = კ
sitedata-cookies-exceptions2 =
    .description = შეგიძლიათ მიუთითოთ ვებსაიტები, რომლებიც ყოველთვის ან არასდროს გამოიყენებს ფუნთუშებსა და საიტის მონაცემებს.
    .label = გამონაკლისების მართვა
    .accesskey = ლ
sitedata-heading =
    .description = მართეთ ფუნთუშები, ისტორია, მარაგები, ვებსაიტის მონაცემები და სხვ.
    .label = დათვალიერების მონაცემები
sitedata-settings3 =
    .label = გასუფთავება მონაცემების ცალკეულ საიტებზე
    .accesskey = ფ
sitedata-cookies-exceptions3 =
    .description = აირჩიეთ, როგორ მოეპყრას ცალკეული საიტი ფუნთუშებსა და სხვა მონაცემებს.
    .label = გამონაკლისების მართვა
    .accesskey = კ
cookies-site-data-group =
    .label = ფუნთუშები და საიტის მონაცემები

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = ფუნთუშის მოთხოვნების შემზღუდავი
cookie-banner-blocker-description = როდესაც საიტი მოითხოვს ფუნთუშების გამოყენებას პირად რეჟიმში, { -brand-short-name } თავადვე განუცხადებს უარს თქვენ ნაცვლად. იმუშავებს მხოლოდ მხარდაჭერილ საიტებზე.
cookie-banner-learn-more = ვრცლად
cookie-banner-blocker-checkbox-label =
    .label = ფუნთუშების მოთხოვნებზე ავტომატური უარი

## Search Section

addressbar-locbar-history-option =
    .label = დათვალიერების ისტორია
    .accesskey = ი
addressbar-locbar-bookmarks-option =
    .label = სანიშნები
    .accesskey = ს
addressbar-locbar-clipboard-option =
    .label = აღებული ასლი
    .accesskey = ლ
addressbar-locbar-openpage-option =
    .label = გახსნილი ჩანართები
    .accesskey = გ
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = მალსახმობები
    .accesskey = მ
addressbar-locbar-topsites-option =
    .label = რჩეული საიტები
    .accesskey = ჩ
addressbar-locbar-engines-option-1 =
    .label = გამოსაყენებელი საძიებოები
    .accesskey = ო
addressbar-locbar-quickactions-option =
    .label = სწრაფი მოქმედებები
    .accesskey = წ
addressbar-locbar-showrecentsearches-option-2 =
    .label = ბოლოს მოძიებული
    .accesskey = ო
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = ხშირად მოძიებულის შემოთავაზება
    .accesskey = ხ
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = შემოთავაზებები ვებსივრციდან თქვენ მიერ მოძიებულის შესაბამისად.
    .label = გთავაზობთ { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = თანადგომისთვის იხილეთ შემოთავაზებები დამკვეთებისგან, { -brand-short-name } დროდადრო რომ მოგაწვდით
    .label = შემოთავაზებები დამკვეთებისგან
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = შემოთავაზებებს აკრეფისთანავე მოგაწვდით Mozilla
addressbar-dismissed-suggestions-label-2 =
    .description = აცილებული შემოთავაზებების დაბრუნება, რომელთაც გაწვდით დამკვეთები და { -brand-short-name }.
    .label = შეთავაზებების აცილება
addressbar-restore-dismissed-suggestions-button-2 =
    .label = შემოთავაზებების დაბრუნება

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = თვალთვალისგან გაძლიერებული დაცვა
content-blocking-section-top-level-description = მეთვალყურეები თან დაგყვებათ მთელ ინტერნეტში და აგროვებს ინფორმაციას თქვენი ჩვევებისა თუ მისწრაფებების შესახებ. { -brand-short-name } ზღუდავს ამ მეთვალყურეების უმეტესობასა და სხვა მავნე კოდებსაც.
content-blocking-learn-more = ვრცლად
content-blocking-fpi-incompatibility-warning = თქვენ იყენებთ პირველი მხარის გამიჯვნას (FPI), რომლითაც { -brand-short-name } ანაცვლებს ფუნთუშების ზოგიერთ პარამეტრს.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = თუ ჩართული გაქვთ Resist Fingerprinting (RFP), რომლითაც ანაცვლებს { -brand-short-name } ამოცნობისგან დაცვის გარკვეულ პარამეტრებს, ზოგიერთი საიტი გაუმართავად შეიძლება გამოჩნდეს.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = საშუალო
    .accesskey = უ
enhanced-tracking-protection-setting-strict =
    .label = მკაცრი
    .accesskey = კ
enhanced-tracking-protection-setting-custom =
    .label = მორგებული
    .accesskey = გ

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = წონასწორული უსაფრთხოებასა და წარმადობას შორის. გვერდები ჩაიტვირთება ჩვეულებრივ.
content-blocking-etp-strict-desc = მძლავრი დაცვა, თუმცა გამოიწვევს საიტების ან შიგთავსის ნაწილის გაუმართაობას.
content-blocking-etp-custom-desc = აირჩიეთ, რომელი მეთვალყურე საშუალებები შეიზღუდოს
content-blocking-etp-blocking-desc = { -brand-short-name } ზღუდავს შემდეგს:
content-blocking-private-windows = მეთვალყურე შიგთავსი პირად ფანჯრებში
content-blocking-cross-site-cookies-in-all-windows2 = საიტთაშორისი ფუნთუშები ყველა ფანჯარაში
content-blocking-cross-site-tracking-cookies = საიტთაშორისი მეთვალყურე ფუნთუშები
content-blocking-all-cross-site-cookies-private-windows = საიტთაშორისი ფუნთუშები პირად ფანჯრებში
content-blocking-isolate-cross-site-cookies = საიტთაშორისი ფუნთუშების გამიჯვნა
content-blocking-social-media-trackers = სოციალური ქსელის მეთვალყურეები
content-blocking-all-cookies = ყველა ფუნთუშა
content-blocking-unvisited-cookies = ფუნთუშები, მოუნახულებელი საიტებიდან
content-blocking-all-windows-tracking-content = მეთვალყურე შიგთავსი ყველა ფანჯარაში
content-blocking-all-cross-site-cookies = ყველა საიტთაშორისი ფუნთუშა
content-blocking-cryptominers = კრიპტოვალუტის გამომმუშავებელი
content-blocking-fingerprinters = მომხმარებლის ამომცნობი
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = ცნობილი და სავარაუდო ამომცნობები
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = ფუნთუშებისგან ყოველმხრივი დაცვა ფუნთუშებს იმ საიტის საზღვრებშივე აქცევს, რომელზეც იმყოფებით და მეთვალყურეები ვეღარ დაგედევნებიან სხვა საიტებზე გადასვლისას.
content-blocking-etp-standard-tcp-rollout-learn-more = ვრცლად
content-blocking-etp-standard-tcp-title = მოიცავს ფუნთუშებისგან ყოველმხრივ დაცვასაც, ჩვენს არნახულად მძლავრ საშუალებას პირადულობისთვის
content-blocking-warning-title-2 = ზოგ საიტზე გაუმართაობას იწვევს თვალთვალისგან მკაცრი დაცვა
content-blocking-warning-title-custom = ზოგ საიტზე გაუმართაობას იწვევს თვალთვალისგან მორგებული დაცვა
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } გირჩევთ გამოიყენოთ „საიტზე ხარვეზების გამოსწორება“ გაუმართავი შესაძლებლობებისა და შიგთავსის შესამცირებლად. თუ საიტი ხარვეზიანია, სცადეთ ამ საიტზე თვალთვალისგან დაცვის გამორთვა შიგთავსის სრულად ჩასატვირთად.
content-blocking-warning-learn-how = იხილეთ როგორ
content-blocking-baseline-exceptions-3 =
    .description = გეხმარებათ საიტებისა და შესაძლებლობების სათანადოდ ჩატვირთვაში შეზღუდვების მოხსნით მხოლოდ ძირითად ნაწილებზე, რომლებიც შესაძლოა მეთვალყურეებსაც შეიცავდეს. აგვარებს გავრცელებული ხარვეზების უმეტესობას.
    .label = საიტზე მნიშვნელოვანი ხარვეზების გამოსწორება (სასურველია)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = აღადგენს სტატიებში გამქრალ ვიდეოებსა თუ გამოხმაურებების არეებს იმ ნაწილებზე შეზღუდვების მოხსნით, რომლებიც მეთვალყურეებს შეიძლება შეიცავდეს. ეს შეამცირებს საიტის ხარვეზებს, მაგრამ უზრუნველყოფს ნაკლებ დაცვას. მიზანშეწონილია მნიშვნელოვანი ხარვეზების გამოსასწორებლად.
    .label = საიტზე მცირე ხარვეზების გამოსწორება
content-blocking-baseline-uncheck-warning-dialog-title = ნამდვილად გსურთ ხარვეზების გამოსწორების უარყოფა?
content-blocking-baseline-uncheck-warning-dialog-body = ეს პარამეტრი გამოგადგებათ საიტის გავრცელებული ხარვეზების გამოსწორებაში. გამორთვის შემთხვევაში ზოგი საიტი გაუმართავად იმუშავებს და { -brand-short-name } ამ ხარვეზების აღმოფხვრაში ვერ დაგეხმარებათ.
content-blocking-baseline-uncheck-warning-dialog-ok-button = გასწორების გამორთვა
content-blocking-baseline-uncheck-warning-dialog-cancel-button = გასწორების დატოვება
content-blocking-reload-description = საჭიროა ჩანართების ხელახლა გახსნა ცვლილებების ასახვისთვის.
content-blocking-reload-tabs-button =
    .label = ყველა ჩანართის ხელახლა გახსნა
    .accesskey = ხ
content-blocking-tracking-content-label =
    .label = მეთვალყურე შიგთავსი
    .accesskey = თ
content-blocking-tracking-protection-option-all-windows =
    .label = ყველა ფანჯარაში
    .accesskey = ყ
content-blocking-option-private =
    .label = მხოლოდ პირად ფანჯრებში
    .accesskey = ფ
content-blocking-cookies-label =
    .label = ფუნთუშები
    .accesskey = ფ
content-blocking-expand-section =
    .tooltiptext = ვრცლად
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = კრიპტოვალუტის გამომმუშავებელი
    .accesskey = პ
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = ცნობილი ამომცნობები
    .accesskey = ც
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = სავარაუდო ამომცნობები
    .accesskey = ც

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = გამონაკლისების მართვა
    .accesskey = ლ

## Privacy Section - Permissions

permissions-notification-pause =
    .label = შეჩერდეს შეტყობინებები, სანამ { -brand-short-name } ხელახლა გაეშვება
    .accesskey = ჩ
permissions-autoplay2 =
    .label = თვითგაშვება
permissions-block-popups2 =
    .label = გარეშე მხარის მიერ გადამისამართების შეზღუდვა
    .accesskey = ზ
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = დაამატეთ ვებსაიტები ამომხტომებისა და გარეშე მხარის მიერ გადამისამართებების ნებართვით.
    .label = გამონაკლისების მართვა
    .searchkeywords = ამომხტომები
    .accesskey = ვ
permissions-addon-install-warning3 =
    .label = გაფრთხილება საიტების მიერ გაფართოების ჩადგმის მცდელობისას
    .accesskey = ხ
permissions-addon-exceptions2 =
    .label = აირჩიეთ საიტები, რომელთაც შეეძლება გაფართოებების დაყენება
    .accesskey = გ
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = საიტებისთვის მოთხოვნის ნებართვა პროგრამული ბმულების გასახსნელად.
    .accesskey = ს
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = შეზღუდული საიტების მართვა
    .accesskey = დ
permissions-location2 =
    .label = მდებარეობა
permissions-localhost2 =
    .label = მოწყობილობის პროგრამები და მომსახურებები
permissions-local-network2 =
    .label = შიდა ქსელის მოწყობილობები
permissions-xr2 =
    .label = წარმოსახვითი სინამდვილე
permissions-camera2 =
    .label = კამერა
permissions-microphone2 =
    .label = მიკროფონი
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = ხმამაღლამოლაპარაკე
permissions-notification2 =
    .label = შეტყობინებები
permissions-header3 =
    .description = განკარგეთ, საიტებს რისი წვდომა, მართვა ან ამოქმედება შეეძლება.
    .label = ნებართვები
permissions-data-section =
    .heading = ნებართვები და მონაცემები
pane-permissions-data-title2 = ნებართვები და მონაცემები
    .title = ნებართვები და მონაცემები
notifications-section-header =
    .heading = შეტყობინებები
notifications-entry-card-header =
    .description = მიუთითეთ, რომელ საიტებს შეეძლება შეტყობინებების გამოგზავნა და როგორ გამოჩნდეს ეს შეტყობინებები.
    .label = შეტყობინებები
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } ვებსაიტი
           *[other] { $count } ვებსაიტი
        }
    .label = შეტყობინების პარამეტრების მართვა
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = შეტყობინების პარამეტრების მართვა
notifications-website-card-header =
    .description = მიუთითეთ, თუ როგორ შეეძლებათ საიტებს შეტყობინებების გამოგზავნა.
    .label = ვებსაიტის შეტყობინებები
notifications-filter =
    .placeholder = საიტების ძიება
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = ვებსაიტი
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = შეტყობინებების დაშვება
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = საიტები
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = ყოველთვის
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = ნებართვა
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = არასდროს
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = ვებსაიტის შეტყობინებები არ დამატებულა.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = ვებსაიტის შეტყობინებები არ ემთხვევა მოძიებულს.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = ეს ცვლილება რომ აისახოს მარქაფში, გახსენით თითოეული პროფილი და მიუთითეთ „ახლავე დამარქაფება“ პარამეტრებიდან.
nimbus-rollouts =
    .description = ცვლილებები აისახება დაშორებულად.
    .label = ნებართვა, რომ { -brand-short-name } შეძლებს გააუმჯობესოს შესაძლებლობები, წარმადობა და მდგრადობა განახლებებს შორის შუალედებშიც
addon-recommendations3 =
    .description = მიიღეთ გაფართოებების შემოთავაზებები გვერდების თვალიერების გასაუმჯობესებლად.
    .label = გაფართოებების მორგებული შემოთავაზებების ნებართვა
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = მონაცემთა მოხსენება გათიშულია ამ გამართვის ანაწყობზე.
collection-backlogged-crash-reports2 =
    .label = უეცარი გათიშვის მოხსენებების თვითგაგზავნა
    .accesskey = ც
collection-backlogged-crash-reports-description = მისი მეშვეობით { -vendor-short-name } მოახერხებს ხარვეზების გამოვლენასა და მოგვარებას ბრაუზერში. მოხსენებები შეიძლება შეიცავდეს პირად ან საფრთხილო მონაცემებს.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = იგივე პარამეტრები ახალი იერსახით!
    .message = ეს გვერდი ახლებურად მოვაწყვეთ, იოლად რომ შეიძლებოდეს თვალის შევლება და უკეთ გაცნობა. თქვენი პირადი პარამეტრები ხელუხლებელია და ყველაფერი ისევ აქაა. რჩევა: გამოიყენეთ საძიებო პირდაპირ სასურველზე გადასასვლელად.
settings-redesign-promo-dismiss-button =
    .label = გასაგებია
privacy-segmentation-section-header = ახალი შესაძლებლობები მოხერხებულად სარგებლობისთვის
privacy-segmentation-section-description = როცა გთზავაზობთ შესაძლებლობებს თქვენი მონაცემების საფუძველზე მეტად მორგებული მომსახურებისთვის:
privacy-segmentation-radio-off =
    .label = { -brand-product-name }-შემოთავაზებების გამოყენება
privacy-segmentation-radio-on =
    .label = დაწვრილებით ჩვენება
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = ჩვენ მთელი ძალისხმევით ვცდილობთ, მოგცეთ არჩევანის საშუალება და აღვრიცხოთ მხოლოდ ის უმცირესი მონაცემები, რომლებიც მეტად წაგვადგება, რომ გავაუმჯობესოთ { -brand-product-name }.
    .label = { -brand-short-name } – მონაცემთა აღრიცხვა და გამოყენება
    .searchkeywords = telemetry
data-collection-link = იხილეთ პირადულობის დაცვის განაცხადი
data-collection-preferences-across-profiles =
    .message = მოცემულ პარამეტრებს ასახავს { -brand-product-name } თითოეულ პროფილზე ამ მოწყობილობაში.
data-collection-profiles-link = ყველა პროფილის ნახვა
data-collection-health-report-telemetry-disabled =
    .message = თქვენ გაუქმებული გაქვთ ნებართვა და შედეგად { -vendor-short-name } ვეღარ აღრიცხავს ტექნიკურ და გამოყენების მონაცემებს. აქამდე შეგროვებული ყველა მონაცემი წაიშლება 30 დღეში.
data-collection-health-report =
    .description = ეს გვეხმარება გავაუმჯობესოთ { -brand-product-name } შესაძლებლობების, წარმადობისა და მდგრადობის კუთხით.
    .label = გაეგზავნოს ტექნიკური და გამოყენების მონაცემები { -vendor-short-name }-ს
    .accesskey = ქ
data-collection-health-report-disabled =
    .description = მონაცემთა მოხსენება გათიშულია ამ გამართვის ანაწყობზე.
    .label = გაიგზავნოს ტექნიკური და გამოყენების მონაცემები, რომელთაც გაეცნობა { -vendor-short-name }
    .accesskey = ტ
data-collection-run-studies =
    .description = { -brand-short-name } შემთხვევითად არჩევს მომხმარებლებს შესაძლებლობების გამოსაცდელად ხარისხის საყოველთაო გაუმჯობესებისთვის.
    .label = ნებართვა, რომ { -brand-short-name } დააყენებს და გაუშვებს კვლევებს
data-collection-studies-link =
    .label = იხილეთ { -brand-short-name } – კვლევები
data-collection-backlogged-crash-reports =
    .description = შედეგად { -vendor-short-name } მოახერხებს ხარვეზების გამოვლენასა და მოგვარებას ბრაუზერში. მოხსენებები შეიძლება შეიცავდეს პირად ან საფრთხილო მონაცემებს.
    .label = უეცარი გათიშვის მოხსენებების თვითგაგზავნა
    .accesskey = უ
data-collection-usage-ping =
    .description = ამით { -vendor-short-name } მიახლოებით ითვლის მოქმედ მომხმარებლებს.
    .label = გაეგზავნოს დღიური მოხმარების უწყება { -vendor-short-name }-ს
    .accesskey = ზ

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = უსაფრთხოება
browsing-protection-group2 =
    .description = სახიფათო საიტები და ჩამოტვირთვები საფრთხეს უქმნის მონაცემებს მოწყობილობაზე. { -brand-short-name } თავისთავად შეზღუდავს მათ და გაგაფრთხილებთ სახიფათო ან არასასურველი პროგრამების თაობაზე.
    .label = თაღლითური შიგთავსისა და სახიფათო პროგრამებისგან დაცვა
security-enable-safe-browsing =
    .label = სახიფათო და თაღლითური შიგთავსის შეზღუდვა
    .accesskey = ღ
security-enable-safe-browsing-link = ვრცლად
security-safe-browsing-warning =
    .message = გამორთვის შედეგად შესუსტდება მავნე და თაღლითური გვერდებისგან დაცვა, აგრეთვე, სახიფათო ჩამოტვირთვების არიდება.
security-block-downloads =
    .label = სახიფათო ჩამოტვირთვების აკრძალვა
    .accesskey = ძ
security-block-uncommon-software =
    .label = გაფრთხილება არასასურველი და უჩვეულო პროგრამების შესახებ
    .accesskey = უ

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = ნებართვა, რომ { -brand-short-name } თავისთავად სანდოდ მიიჩნევს გარეშე მხარის ძირეულ სერტიფიკატებს, რომელთაც ჩააყენებთ
    .accesskey = ბ
certs-devices-enable-fips = FIPS-ის ჩართვა
space-alert-over-5gb-settings-button =
    .label = პარამეტრების გახსნა
    .accesskey = ხ
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } იუწყება, რომ დისკზე ადგილი ეწურება.</strong> საიტების შიგთავსი, შეიძლება არ გამოჩნდეს სათანადოდ. შენახული მონაცემების წაშლა და ადგილის გამოთავისუფლება შეგიძლიათ მენიუდან – პარამეტრები > პირადულობა და უსაფრთხოება > ფუნთუშები და საიტის მონაცემები.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } იუწყება, რომ დისკზე ადგილი ეწურება.</strong> საიტების შიგთავსი, შეიძლება არ გამოჩნდეს სათანადოდ. იხილეთ „ვრცლად“, თუ როგორ გამოათავისუფლოთ ადგილი დისკზე, გვერდების შეუფერხებლად მოსანახულებლად.
certs-description3 =
    .description = გამართეთ სერტიფიკატები, რომლებსაც { -brand-short-name } იყენებს დაცული კავშირების დასამოწმებლად.
    .label = სერტიფიკატები
certs-view2 =
    .label = სერტიფიკატების მართვა
    .accesskey = ტ
certs-devices2 =
    .label = უსაფრთხოების მოწყობილობათა მართვა
    .accesskey = წ

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = როგორ მუშაობს მხოლოდ-HTTPS
httpsonly-radio-enabled =
    .label = მხოლოდ-HTTPS-რეჟიმი ყველა ფანჯარაში
httpsonly-radio-enabled-pbm =
    .label = მხოლოდ-HTTPS-რეჟიმი პირად ფანჯრებში
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } ზოგ კავშირს მაინც გადაიყვანს დაცულზე
    .label = არ ამოქმედდეს მხოლოდ-HTTPS-რეჟიმი
httpsonly-group =
    .description = მხოლოდ დაცული კავშირის მქონე საიტებთან წვდომა. { -brand-short-name } ნებართვას მოითხოვს დაუცველი კავშირის დამყარებამდე.
    .label = მხოლოდ-HTTPS-რეჟიმი
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS-მოთხოვნა HTTPS-ით
dns-over-https-group2 =
    .description = საიტთა სახელების (DNS) მოთხოვნები HTTPS-ით გატარებისას იშიფრება, რაც უძნელებს თქვენი ინტერნეტის მომწოდებელსა თუ გარეშე პირებს იხილონ, რომელი ვებსაიტების მონახულებას ცდილობთ.
    .label = DNS-მოთხოვნა HTTPS-ით
preferences-doh-description2 = საიტთა სახელების გადამყვანი (DNS) მომსახურების HTTPS-ით გატარებისას საიტის მისამართის მოთხოვნები იგზავნება დაშიფრული არხით, შედეგად იქმნება დაცული DNS და გარეშე პირებს უძნელდებათ გაარკვიონ, რომელ ვებსაიტებთან ცდილობთ წვდომას.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = მდგომარეობა: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = მომწოდებელი: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = არამართებული ბმული
preferences-doh-steering-status = ადგილობრივი მომწოდებლის გამოყენებით
preferences-doh-status-active = მოქმედი
preferences-doh-status-disabled = გამორთ.
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = უქმი ({ $reason })
preferences-doh-group-message2 = ჩაირთოს DNS-მოთხოვნა HTTPS-ით:
preferences-doh-radio-group =
    .aria-label = ჩაირთოს DNS-მოთხოვნა HTTPS-ით:
preferences-doh-expand-section =
    .tooltiptext = ვრცლად
preferences-doh-setting-default =
    .label = ნაგულისხმევი უსაფრთხოება
    .accesskey = ნ
preferences-doh-default-desc = { -brand-short-name } წყვეტს, როდის გამოიყენოს დაცული DNS თქვენი პირადულობისთვის.
preferences-doh-default-detailed-desc-1 = გამოიყენება დაცული DNS იმ მხარეში, რომელშიც ხელმისაწვდომია
preferences-doh-default-detailed-desc-2 = გამოიყენება ნაგულისხმევი DNS, თუ ხარვეზითაა დაცული DNS
preferences-doh-default-detailed-desc-3 = გამოიყენება ადგილობრივი მომწოდებელი, თუ მისაწვდომია
preferences-doh-default-detailed-desc-4 = გამოირთვება, როცა VPN, მშობლის ზედამხედველობა ან დაწესებულების დებულებებია ამოქმედებული
preferences-doh-default-detailed-desc-5 = გამოირთვება, თუ ქსელის მითითებით { -brand-short-name } არ უნდა იყენებდეს დაცულ DNS-ს.
preferences-doh-setting-enabled =
    .label = გაზრდილი უსაფრთხოება
    .accesskey = გ
preferences-doh-enabled-desc = თავად საზღვრავთ, როდის გამოიყენოს დაცული DNS და ირჩევთ მომწოდებელს.
preferences-doh-enabled-detailed-desc-1 = გამოიყენება თქვენი შერჩეული მომწოდებელი
preferences-doh-enabled-detailed-desc-2 = გამოიყენება ნაგულისხმევი DNS მხოლოდ მაშინ, თუ ხარვეზითაა დაცული DNS
preferences-doh-setting-strict =
    .label = უმაღლესი უსაფრთხოება
    .accesskey = უ
preferences-doh-strict-desc = { -brand-short-name } ყოველთვის გამოიყენებს დაცულ DNS-ს. იხილავთ საშიშროების შესახებ გაფრთხილებას დაუცველ DNS-ზე გადასვლამდე.
preferences-doh-strict-detailed-desc-1 = გამოიყენება მხოლოდ თქვენი შერჩეული მომწოდებელი
preferences-doh-strict-detailed-desc-2 = ყოველთვის გამოჩნდება გაფრთხილება, როცა დაცული DNS მიუწვდომელია
preferences-doh-strict-detailed-desc-3 = თუ დაცული DNS მიუწვდომელია, საიტები არ ჩაიტვირთება ან სათანადოდ ვერ იმუშავებს
preferences-doh-setting-off =
    .label = გამორთ.
    .accesskey = ო
preferences-doh-off-desc = გამოიყენება თქვენი ნაგულისხმევი DNS-გადამყვანი
preferences-doh-select-resolver = მომწოდებლის არჩევა:
preferences-doh-manage-exceptions =
    .label = გამონაკლისების მართვა…
    .accesskey = კ
preferences-doh-overview-default =
    .description = გამოიყენება დაცული DNS იმ მხარეებში, სადაც ხელმისაწვდომია
    .label = ნაგულისხმევი უსაფრთხოება
preferences-doh-overview-custom =
    .description = ყოველთვის გამოიყენება დაცული DNS, მომწოდებლის მიერ შემოთავაზებულისა თუ არსებულის მოშველიების გარეშე.
    .label = მორგებული
preferences-doh-overview-off =
    .description = გამოიყენება თქვენი ნაგულისხმევი DNS.
    .label = გამორთ.
preferences-doh-advanced-button =
    .label = გაფართოებული პარამეტრები
preferences-doh-advanced-section =
    .description = საიტთა სახელების გადამყვანის HTTPS-არხით გატარებისას (DoH) მოძიებული მონაცემები იშიფრება, რაც უძნელებს ინტერნეტის მომწოდებელსა თუ სხვა გარეშე მხარეებს შეიტყონ, რომელი ვებსაიტების მონახულებას აპირებთ.
    .label = გაფართოებული პარამეტრები
preferences-doh-manage-exceptions2 =
    .label = გამონაკლისების მართვა
    .accesskey = ო
preferences-doh-radio-default =
    .description = გამოიყენება დაცული DNS იმ მხარეში, რომელშიც ხელმისაწვდომია
    .label = ნაგულისხმევი
preferences-doh-radio-custom =
    .description = ყოველთვის გამოიყენება დაცული DNS, მომწოდებლის მიერ შემოთავაზებულისა თუ არსებულის მოშველიების გარეშე
    .label = მორგებული
preferences-doh-radio-off =
    .description = გამოიყენება თქვენი ნაგულისხმევი DNS
    .label = გამორთ.
preferences-doh-fallback-label =
    .label = ყოველთვის გამოჩნდეს გაფრთხილება, როცა დაცული DNS მიუწვდომელია
preferences-doh-status-item-off =
    .message = DNS-მოთხოვნა HTTPS-ით გამორთ.
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS-მოთხოვნა HTTPS-ით არ მუშაობს, რადგან აწყდება შეცდომას ({ $reason }), როცა მომწოდებელია { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS-მოთხოვნა HTTPS-ით არ მუშაობს, რადგან მიღებულია უმართებულო ბმული ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS-მოთხოვნა HTTPS-ით იყენებს მომწოდებელს { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS-მოთხოვნა HTTPS-ით არ მუშაობს, რადგან აწყდება შეცდომას ({ $reason }), როცა ადგილობრივი მომწოდებელია { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS-მოთხოვნა HTTPS-ით იყენებს ადგილობრივ მომწოდებელს { $name }
preferences-doh-select-resolver-label =
    .label = მომწოდებლის არჩევა:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = ამ მომწოდებლის გამოყენება DNS-მოთხოვნისთვის HTTPS-ით.
preferences-doh-custom-provider-label =
    .aria-label = შეიყვანეთ სასურველი მომწოდებლის ბმული
preferences-doh-header2 =
    .heading = DNS-მოთხოვნა HTTPS-ით

## Connection and software security section

preferences-connection-header =
    .heading = კავშირი და პროგრამის უსაფრთხოება
preferences-connection-link-section =
    .description = იხილეთ, როგორ ხდება კავშირების დაცვა, მავნე პროგრამების შეზღუდვა და ვებსაიტების დამოწმება.
    .label = კავშირი და პროგრამის უსაფრთხოება
preferences-connection-link-button =
    .label = გაფართოებული პარამეტრები

## The following strings are used in the Download section of settings

desktop-folder-name = სამუშაო ეკრანი
downloads-folder-name = ჩამოტვირთვები

## Appearance page

preferences-appearance-header =
    .heading = იერსახე
browser-theme-group =
    .description = მოირგეთ { -brand-short-name } თქვენებურად. გაფორმება შეცვლის ხელსაწყოთა ზოლის, მენიუსა და შეტყობინებების შეფერილობას.
    .label = Browser theme
browser-theme-manage-link =
    .label = მართეთ { -brand-short-name } გაფორმებებით
appearance-window-density-group =
    .description = დაშორების განსაზღვრა ფანჯრის ნაწილების ირგვლივ, როგორიცაა ხელსაწყოთა ზოლი, ჩანართები ან გვერდითი ზოლი.
    .label = ფანჯრის სიმჭიდროვე
appearance-window-density-radio-group =
    .aria-label = ფანჯრის სიმჭიდროვე
appearance-window-density-automatic =
    .description = ჩვეულებრივი, მჭიდრო ან შეხებისთვის განკუთვნილი დაშორება შეირჩევა თავისთავად
    .label = ავტომატური (ნაგულისხმევი)
appearance-window-density-automatic-no-touch =
    .description = ჩვეულებრივი, მჭიდრო ან შეხებისთვის განკუთვნილი დაშორება შეირჩევა თავისთავად
    .label = ავტომატური (ნაგულისხმევი)
appearance-window-density-standard =
    .description = წონასწორული დაშორება ეკრანთა უმეტესობისთვის
    .label = ჩვეულებრივი
appearance-window-density-auto-touch-mode =
    .label = შეხებისთვის განკუთვნილის არჩევა პლანშეტის რეჟიმისას
appearance-window-density-compact =
    .description = შემცირებული დაშორებით მცირე ეკრანებისთვის
    .label = მჭიდრო
appearance-window-density-touch =
    .description = მოზრდილი ნაწილები თითის მისაჭერად ფანჯრებში, განკუთვნილი შეხებისთვის
    .label = შეხებისთვის
related-settings-group =
    .label = მსგავსი პარამეტრები
related-settings-accessibility-link =
    .label = მოახლოებისა და შრიფტის მორგება დამხმარე საშუალებებით
related-settings-home-link =
    .label = მოირგეთ { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = ბრაუზერში განლაგების მორგება

## AI controls page

preferences-ai-controls-description = ყოველთვის გაძლევთ { -brand-short-name } არჩევანის უფლებას, მათ შორის ხელოვნური გონის შესაძლებლობებით სარგებლობის შემთხვევაშიც. მართვის სხვა საშუალებებიც მალე დაემატება.
preferences-ai-controls-block-ai-label = შეიზღუდოს ხელგონის შესაძლებლობები?
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = შეზღუდვა გულისხმობს, რომ { -brand-short-name } აღარ გიჩვენებთ ახალ ან არსებულ AI-შესაძლებლობებს, არც მათ შესახებ ამომხტომ ცნობებს. <a data-l10n-name="link">იხილეთ ვრცლად</a>, თუ რას მოიცავს და როგორ იმართება ძველებური სახის მანქანური დასწავლის მქონე შესაძლებლობები, მათ შორის ძიებისა თუ სხვა შემოთავაზებები.
preferences-ai-controls-blocked-message =
    .message = ახალი ან არსებული AI-შესაძლებლობები შეიზღუდება ნაგულისხმევად. ცალკეულ შესაძლებლობაზე შეზღუდვის მოსახსნელად გამოიყენეთ სამართავი ქვემოთ.
preferences-ai-controls-on-device-group =
    .description = გამოყენებული იქნება ხელგონის მცირე მოდელები, რომლებიც ჩამოიტვირთება მოწყობილობაზე შესაძლებლობის გამოყენებისას. ამგვარი მიდგომა დაიცავს თქვენს პირადულობას.
    .label = მოწყობილობაზე მომუშავე AI
preferences-ai-controls-translations-control =
    .description = შეუფერხებლად მონახულეთ გვერდები სასურველ ენაზე.
    .label = თარგმანები
preferences-ai-controls-translations-more-link = თარგმნის სხვა პარამეტრები
preferences-ai-controls-pdfjs-control =
    .description = სურათების დამატებისას PDF-ებში დაერთვება აღმწერი წარწერებიც მეტი ხელმისაწვდომობისთვის.
    .label = სურათზე დართული წარწერა { -brand-short-name } PDF-მნახველში
preferences-ai-controls-tab-group-suggestions-control =
    .description = მიიღეთ შემოთავაზებები ჩანართების დალაგებისა და გადარქმევის შესახებ.
    .label = ჩანართის დაჯგუფების შემოთავაზებები
preferences-ai-controls-key-points-control =
    .description = იხილეთ მოკლე შეჯამება ბმულის გახსნამდე.
    .label = საკვანძო საკითხები ბმულის შეთვალიერებისას
preferences-ai-controls-speech-recognition-control =
    .description = საუბრის ნაწერად ქცევა ადგილობრივად.
    .label = ხმის ამოცნობა
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = დატოვეთ თანამოსაუბრე ხედვის არეში გვერდების მონახულებისას. აირჩიეთ რომელიმე მომწოდებელი და ცვალეთ ნებისმიერ დროს.
    .label = AI-თანამოსაუბრის მომწოდებლები გვერდით ზოლზე
preferences-ai-controls-sidebar-chatbot-group =
    .description = თან იქონიეთ თანამოსაუბრე ხელგონი გვერდების მონახულებისას. აირჩიეთ Anthropic Claude, ChatGPT, Copilot, Google Gemini ან Le Chat Mistral.
    .label = AI-თანამოსაუბრის მომწოდებლები გვერდით ზოლზე
preferences-ai-controls-sidebar-chatbot-control =
    .label = თანამოსაუბრე გვერდით ზოლზე
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = ხელმისაწვდომი
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = ამოქმედებული
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = შეზღუდული
preferences-ai-controls-state-description-before = რას გულისხმობს ეს პარამეტრები:
preferences-ai-controls-state-description-available = <strong>ხელმისაწვდომი:</strong> შეგიძლიათ იხილოთ და გამოიყენოთ.
preferences-ai-controls-state-description-enabled = <strong>ამოქმედებული:</strong> ჩართული გაქვთ და სარგებლობთ ამ შესაძლებლობით.
preferences-ai-controls-state-description-blocked = <strong>შეზღუდული:</strong> ვერ იხილავთ და ვერ გამოიყენებთ ამ შესაძლებლობას. მოწყობილობაზე მომუშავე ხელგონი ან წინათ ჩამოტვირთული ნებისმიერი მოდელი მოცილებულია.
preferences-ai-controls-block-confirmation-heading = შეიზღუდოს ხელგონის შესაძლებლობები?
preferences-ai-controls-block-confirmation-description = თქვენთვის აღარ გამოაჩენს { -brand-short-name } ახალ ან არსებულ AI-შესაძლებლობებს და მათ შესახებ ამომხტომ ცნობებს. მომავალში შეგეძლებათ მოხსნათ შეზღუდვა და სურვილისამებრ განაგრძოთ გამოყენება.
preferences-ai-controls-block-confirmation-features-start = რა შეიზღუდება:
preferences-ai-controls-block-confirmation-translations = თარგმანები
preferences-ai-controls-block-confirmation-pdfjs = სურათზე დართული წარწერა { -brand-short-name } PDF-მნახველში
preferences-ai-controls-block-confirmation-tab-group-suggestions = ჩანართის დაჯგუფების შემოთავაზებები
preferences-ai-controls-block-confirmation-key-points = საკვანძო საკითხები ბმულის შეთვალიერებისას
preferences-ai-controls-block-confirmation-sidebar-chatbot = AI-თანამოსაუბრის მომწოდებლები გვერდით ზოლზე
preferences-ai-controls-block-confirmation-speech-recognition = ხმის ამოცნობა
preferences-ai-controls-block-confirmation-features-after = შეზღუდვა ასევე შეეხება ხელგონით მოსარგებლე გაფართოებებს, რომელთა მუშაობასაც უზრუნველყოფს { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = გაუქმება
preferences-ai-controls-block-confirmation-confirm =
    .label = შეზღუდვა
preferences-ai-controls-header3 =
    .heading = AI-სამართავი

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } სადარაჯოზეა
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } გირჩევთ მეტი უსაფრთხოებისთვის
security-privacy-status-ok-label = თვალთვალისგან გაძლიერებული დაცვა ჩართ.
security-privacy-status-problem-label = შემჩნეულია პარამეტრები, რომლებიც გავლენას ახდენს უსაფრთხოებაზე
security-privacy-status-problem-helper-label = ხარვეზების ნახვა
security-privacy-status-pending-trackers-label = გადახედეთ, რამდენ მეთვალყურეს აკავებდა { -brand-short-name } წინა თვეში
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } მეთვალყურე შეიზღუდა წინა თვეში
       *[other] { $trackerCount } მეთვალყურე შეიზღუდა წინა თვეში
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = გიყენიათ <a data-l10n-name="strict-tracking-protection">მკაცრი დაცვა</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = გიყენიათ <a data-l10n-name="custom-tracking-protection">მორგებული დაცვა</a>
security-privacy-status-up-to-date-label = გიყენიათ უახლესი, დაცული { -brand-short-name }
security-privacy-status-update-needed-label = ახალი { -brand-short-name } ხელმისაწვდომია.
security-privacy-status-update-error-label = { -brand-short-name } დაბრკოლებას აწყდება განახლებისას
security-privacy-status-update-checking-label = { -brand-short-name } ამოწმებს განახლებებს
security-privacy-status-update-needed-description = განაახლეთ სიჩქარის, მდგრადობისა და უსაფრთხოების უკანასკნელი გაუმჯობესებისთვის.
security-privacy-status-update-button-label =
    .label = განახლდეს { -brand-short-name }
security-privacy-image-warning =
    .alt = ფარი ძახილის ნიშნით, გამოხატავს წუხილს უსაფრთხოების კუთხით არსებული შენიშვნების გამო
security-privacy-image-ok =
    .alt = ფარი მოსანიშნი ნიშნით, გამოხატავს შენიშვნების არარსებობას უსაფრთხოების კუთხით
security-privacy-issue-card =
    .heading = უსაფრთხოების შენიშვნები
issue-card-reset-button =
    .label = აღდგენა
issue-card-dismiss-button =
    .aria-label = აცილება
    .tooltiptext = აცილება

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = საიტები შეიცავს მეთვალყურეებს, რომლებიც თან დაგყვებათ მთელ ვებსივრცეში და გიგდებთ საძაგელ რეკლამებს. { -brand-short-name } დაგიფარავთ გვერდების მონახულებისას მეთვალყურეების თავისთავადი შეზღუდვით, რომ თქვენს ციფრულ კვალს თავადვე განკარგავდეთ.
    .label = თვალთვალისგან გაძლიერებული დაცვა
preferences-etp-level-radio-group =
    .aria-label = თვალთვალისგან გაძლიერებული დაცვა
preferences-etp-level-standard =
    .description = მძლავრი, საიმედო დაცვა, შეუფერხებლად რომ იმუშავებს საიტთა უმეტესობაზე.
    .label = საშუალო (ნაგულისხმევი)
preferences-etp-level-strict =
    .description = გაძლიერებული დაცვა, რომელიც უფრო მეტ მეთვალყურეს ზღუდავს, მაგრამ ზოგიერთ საიტზე შეიძლება იწვევდეს გაუმართაობებს.
    .label = მკაცრი
preferences-etp-level-custom =
    .description = დაცვის შერჩეული პარამეტრების ჩართვითა და გამორთვით.
    .label = მორგებული
preferences-etp-status-advanced-button =
    .label = გაფართოებული პარამეტრები
preferences-etp-tracker-count-enabled =
    .label = შეზღუდული მეთვალყურეების ჩვენება მისამართების ველში
preferences-etp-status-protections-dashboard-link =
    .description = იხილეთ, რამდენი გაიძვერა მეთვალყურისგან გიცავთ { -brand-short-name }, მათ შორის, სოცქსელის მიმყურადებლის, ვინაობის ამომცნობისა თუ კრიპტოგამომმუშავებლისგან.
    .label = თქვენზე მორგებული დაცვის მაჩვენებლების ნახვა
preferences-etp-header =
    .heading = თვალთვალისგან გაძლიერებული დაცვა
preferences-etp-advanced-settings-group =
    .description = საიტები შეიცავს მეთვალყურეებს, რომლებიც თან დაგყვებათ მთელ ვებსივრცეში და გიგდებთ საძაგელ რეკლამებს. { -brand-short-name } დაგიფარავთ გვერდების მონახულებისას მეთვალყურეთა უმეტესობის თავისთავადი შეზღუდვით, რომ თქვენს ციფრულ კვალს თავადვე განკარგავდეთ.
    .label = გაფართოებული პარამეტრები
preferences-etp-customize-button =
    .label = თვალთვალისგან მორგებული დაცვა
preferences-etp-reload-tabs-hint =
    .message = გააახლეთ თქვენი ჩანართები ცვლილებების ასახვისთვის.
preferences-etp-reload-tabs-hint-button =
    .label = ყველა ჩანართის გაახლება
preferences-etp-rfp-warning-message =
    .message = თუ ჩართული გაქვთ Resist Fingerprinting (RFP), რომლითაც ანაცვლებს { -brand-short-name } ამოცნობისგან დაცვის გარკვეულ პარამეტრებს, ზოგიერთი საიტი გაუმართავად შეიძლება გამოჩნდეს.
preferences-etp-level-warning-message =
    .heading = ფრთხილად! ზოგმა საიტმა შეიძლება ვერ იმუშაოს სათანადოდ.
    .message = ზოგიერთ საიტს მეთვალყურეები ჩაშენებული აქვს თავის შესაძლებლობებსა თუ შიგთავსში. როცა { -brand-short-name } ზღუდავს მათ, საიტი ხარვეზიანად გამოიყურება. მოსინჯეთ „საიტის ხარვეზების გამოსწორება“ ან გამორთეთ თვალთვალისგან დაცვა ამგვარ საიტზე.
preferences-etp-manage-exceptions-button =
    .description = ვებსაიტების მითითება, რომლებზეც გამოირთვება თვალთვალისგან გაძლიერებული დაცვა.
    .label = გამონაკლისების მართვა
preferences-etp-customize-header =
    .heading = თვალთვალისგან მორგებული დაცვა
preferences-etp-reset =
    .description = მზა პარამეტრების აღდგენა დაცვის დონის მიხედვით.
    .label = მორგებულის დაბრუნება
preferences-etp-reset-standard-button =
    .label = დაბრუნება საშუალოზე
preferences-etp-reset-strict-button =
    .label = დაბრუნება მკაცრზე
preferences-etp-custom-control-group =
    .description = დაცვის შერჩეული პარამეტრების ჩართვითა და გამორთვით.
    .label = თვალთვალისგან დაცვა
preferences-etp-custom-cookies-enabled =
    .label = ფუნთუშები
preferences-etp-custom-cookie-behavior =
    .aria-label = ფუნთუშები
preferences-etp-custom-cookie-behavior-accept-all =
    .label = ყველა ფუნთუშების მიღება
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = საიტთაშორისი მეთვალყურე ფუნთუშების შეზღუდვა
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = საიტთაშორისი ფუნთუშების
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = საიტთაშორისი ფუნთუშების გამიჯვნა
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = ფუნთუშები მოუნახულებელი გვერდებიდან
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = ყველა საიტთაშორისი ფუნთუშა (იწვევს ზოგი საიტის გაუმართაობას)
preferences-etp-custom-cookie-behavior-block-all =
    .label = ყველა ფუნთუშა (იწვევს საიტების გაუმართაობას)
preferences-etp-custom-tracking-protection-enabled =
    .label = თვალის მდევნელი შიგთავსი
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = თვალის მდევნელი შიგთავსი
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = კრიპტოგამომმუშავებლები
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = ცნობილი ამომცნობები
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = სავარაუდო ამომცნობები
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = სავარაუდო ამომცნობები

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = შედეგად შეიძლება ზოგიერთი მეთვალყურე ფუნთუშების გარეშეც გადევნებდეთ თვალს.
    .label = ცნობილი ამომცნობები არ იზღუდება
security-privacy-issue-warning-third-party-cookies =
    .description = გარეშე მხარეთა ფუნთუშები გამოიყენება თვალის მისადევნებლად სხვადასხვა ვებსაიტზე გადასვლისას.
    .label = გარეშე მხარეთა ფუნთუშები ჩართულია
security-privacy-issue-warning-password-manager =
    .description = პაროლების მმართველი გეხმარებათ მძლავრი პაროლების დამახსოვრებაში ანგარიშებისთვის.
    .label = პაროლების მმართველი გამორთულია
security-privacy-issue-warning-popup-blocker =
    .description = ამომხტომები ხელის შემშლელი და სავარაუდო ხიფათის მომტანია.
    .label = ამომხტომების შეზღუდვა გამორთულია
security-privacy-issue-warning-extension-install =
    .description = ვებსაიტებს შეეძლება გაფართოებების ჩადგმა ისე, რომ { -brand-short-name } ნებართვას არ მოითხოვს.
    .label = ვებსაიტებს შეეძლება გაფართოებების ჩადგმა
security-privacy-issue-warning-safe-browsing =
    .description = დაუცველი რჩებით ყალბი და მავნე საიტების წინაშე.
    .label = სახიფათო და თაღლითური შიგთავსი არ იზღუდება
security-privacy-issue-warning-doh2 =
    .description = DNS-მოთხოვნა HTTPS-ით გეხმარებათ მოსანახულებელი საიტების დასაფარად თქვენი ქსელის მომწოდებლისგან.
    .label = DNS-მოთხოვნა HTTPS-ით გამორთულია
security-privacy-issue-warning-ech2 =
    .description = დაშიფრული Client Hello გეხმარებათ მოსანახულებელი საიტების დასაფარად თქვენი ქსელის მომწოდებლისგან.
    .label = დაშიფრული Client Hello გათიშულია
security-privacy-issue-warning-doh =
    .description = DNS-მოთხოვნა HTTPS-ით მალავს ქსელის მომსახურების მომწოდებლისგან, თუ რომელი საიტების მონახულებას ცდილობთ.
    .label = DNS-მოთხოვნა HTTPS-ით გამორთ.
security-privacy-issue-warning-ech =
    .description = კავშირის დაშიფრული წამოწყება მალავს ქსელის მომსახურების მომწოდებლისგან, თუ რომელი საიტების მონახულებას ცდილობთ.
    .label = კავშირის დაშიფრული წამოწყება გამორთულია
security-privacy-issue-warning-proxy-autodetection =
    .description = ქსელის შუამავლის თვითგამართვამ შეიძლება არასანდო ქსელებს თქვენი მიმოცვლილი მონაცემების აღრიცხვის საშუალება მისცეს.
    .label = შუამავლის თვითგამართვა ჩართულია

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = მოიწვიეთ ვინმე, აირჩიოს ბრაუზერი, რომლისთვისაც უწინარესია პირადულობა.
    .label = გააზიარეთ { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = გააზიარეთ { -brand-product-name }


vorbit-warning-title = ყურადღებით!
vorbit-general-heading = ბრაუზერის ქცევა
vorbit-extension-update-checkbox =
    .label = დამატებების ავტომატური განახლება
vorbit-sync-checkbox =
    .label = Firefox-ის სინქრონიზაციის ჩართვა
vorbit-autocopy-checkbox =
    .label = შუა ღილაკით ჩასმის ჩართვა
vorbit-styling-checkbox =
    .label = userChrome.css -ის მორგების დაშვება
vorbit-network-heading = ქსელი
vorbit-ipv6-checkbox =
    .label = IPv6-ის ჩართვა
vorbit-privacy-heading = კონფიდენციალობა
category-vorbit =
    .tooltiptext = about:config-ის ცვლილებები, ლოგიკურად დაჯგუფებული და ადვილად ხელმისაწვდომი
pane-vorbit-title = vOrbit-lite
vorbit-header = vOrbit-lite-ის მორგება
vorbit-xorigin-ref-checkbox =
    .label = დომენთაშორისი მიმართვების შეზღუდვა
vorbit-warning-description = ჩვენ ფრთხილად ავირჩიეთ ნაგულისხმევი პარამეტრები, ფოკუსით კონფიდენციალობაზე და უსაფრთხოებაზე. როცა ამ პარამეტრების შეცვლას გადაწყვეტთ, წაიკითხეთ მათი აღწერა, რომ კარგად გაიგოთ, რა შედეგები შეიძლება, ამ პარამეტრების შეცვლამ გამოიწვიოს.
vorbit-security-heading = უსაფრთხოება
vorbit-webgl-checkbox =
    .label = WebGL-ის ჩართვა
vorbit-rfp-checkbox =
    .label = ResistFingerprinting-ის ჩართვა
vorbit-letterboxing-checkbox =
    .label = letterboxing-ის ჩართვა
vorbit-config-link = ყველა დამატებითი პარამეტრი (about:config)
vorbit-open-profile = მომხმარებლის პროფილის საქაღალდის გახსნა
vorbit-goog-safe-download-checkbox =
    .label = გადმოწერების სკანირება
vorbit-footer = სასარგებლო ბმულები
