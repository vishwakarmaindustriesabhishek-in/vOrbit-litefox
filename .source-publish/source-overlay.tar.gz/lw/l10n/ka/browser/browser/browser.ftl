# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } – პირადი რეჟიმი
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = გვერდების თვალიერება სწრაფად და დაცულად
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — პირადი თვალიერება
       *[other] { -brand-full-name } პირადი თვალიერება
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = პირადი თვალიერება
popups-infobar-dont-show-message2 =
    .label = არ გამოჩნდეს ეს ცნობა, როცა ამომხტომები ან გარეშე მხარის მიერ გადამისამართება შეზღუდულია
    .accesskey = რ
edit-popup-settings2 =
    .label = ამომხტომებისა და გარე გადამისამართებების მართვა…
    .accesskey = ვ
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] საიტის მონაცემების ნახვა
            [1] საიტის მონაცემების ნახვა (1 მეთვალყურე შეიზღუდა)
            [one] საიტის მონაცემების ნახვა ({ $count } მეთვალყურე შეიზღუდა)
           *[other] საიტის მონაცემების ნახვა ({ $count } მეთვალყურე შეიზღუდა)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } ბმული
           *[other] { $count } ბმული
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, მიმოწერები და სხვა…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = მიმოწერები, ფოსტა და სხვა…
    .accesskey = შ
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = გაზიარება…
    .accesskey = გ
urlbar-identity-button =
    .aria-label = საიტის ინფორმაციის ჩვენება

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = ჩადგმის შეტყობინების არის გახსნა
urlbar-web-notification-anchor =
    .tooltiptext = აირჩიეთ, მიიღოთ თუ არა შეტყობინებები ამ საიტისგან
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI-არეს გახსნა
urlbar-serial-notification-anchor =
    .tooltiptext = გახსენით მიმდევრობითი შეერთების არე
urlbar-eme-notification-anchor =
    .tooltiptext = DRM-პროგრამით სარგებლობის გამართვა
urlbar-web-authn-anchor =
    .tooltiptext = ვებსაიტებზე შესვლის არე
urlbar-canvas-notification-anchor =
    .tooltiptext = გრაფიკის გამოსახვის მონაცემებთან წვდომის უფლებების მართვა
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = საიტისთვის თქვენი მიკროფონის გაზიარების მართვა
urlbar-default-notification-anchor =
    .tooltiptext = შეტყობინებების არე
urlbar-geolocation-notification-anchor =
    .tooltiptext = მდებარეობის მოთხოვნის არე
urlbar-localhost-notification-anchor =
    .tooltiptext = ადგილობრივ მოწყობილობაზე წვდომის მართვა ამ საიტისთვის
urlbar-local-network-notification-anchor =
    .tooltiptext = საიტისთვის თქვენი შიდა ქსელის გაზიარების მართვა
urlbar-xr-notification-anchor =
    .tooltiptext = წარმოსახვითი სინამდვილის ნებართვების არე
urlbar-storage-access-anchor =
    .tooltiptext = დათვალიერების მოქმედებების ნებართვების არის გახსნა
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = საიტისთვის თქვენი ფანჯრების ან ეკრანის გაზიარების მართვა
urlbar-indexed-db-notification-anchor =
    .tooltiptext = კავშირგარეშე საცავის შეტყობინების არის გახსნა
urlbar-password-notification-anchor =
    .tooltiptext = პაროლის შენახვის შეტყობინების არის გახსნა
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = საიტისთვის თქვენი კამერის და/ან მიკროფონის გაზიარების მართვა
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = საიტისთვის თქვენი დინამიკების გაზიარების მართვა
urlbar-autoplay-notification-anchor =
    .tooltiptext = თვითგაშვების სამართავის გახსნა
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = მონაცემების შენახვა მუდმივ მეხსიერებაზე
urlbar-addons-notification-anchor =
    .tooltiptext = დამატების ჩადგმის შეტყობინების არის გახსნა
urlbar-search-tips-confirm = კარგი, გასაგებია
urlbar-search-tips-confirm-short = გასაგებია
urlbar-result-menu-button =
    .title = მენიუს გახსნა
urlbar-result-menu-button-feedback = გამოხმაურება
    .title = მენიუს გახსნა
urlbar-result-menu-learn-more2 = ვრცლად
    .accesskey = ლ
urlbar-result-menu-remove-from-history2 = მოცილება ისტორიიდან
    .accesskey = მ
urlbar-result-menu-tip-get-help2 = დახმარების მიღება
    .accesskey = ხ
urlbar-result-menu-dismiss-suggestion2 = ამ შეთავაზების აცილება
    .accesskey = ც
urlbar-result-menu-remove-top-site = ამ რჩეული საიტის მოცილება
    .accesskey = რ
urlbar-result-menu-manage-firefox-suggest2 = მართეთ { -firefox-suggest-brand-name }
    .accesskey = მ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = არაზუსტი მდებარეობის მოხსენება
    .accesskey = ა
urlbar-result-menu-show-less-frequently3 = იშვიათად ჩვენება
    .accesskey = ი
urlbar-result-menu-dont-show-weather-suggestions3 = ამინდის შემოთავაზებების გარეშე
    .accesskey = ა
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = არაზუსტი მდებარეობის მოხსენება
urlbar-result-menu-show-less-frequently2 = იშვიათად ჩვენება
urlbar-result-menu-dont-show-weather-suggestions2 = ამინდის შემოთავაზებების გარეშე
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = ამ შეთავაზების აცილება
    .accesskey = ც
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = ისტორიიდან ამოშლა
    .accesskey = ლ
urlbar-result-menu-learn-more =
    .label = ვრცლად
    .accesskey = ლ
urlbar-result-menu-remove-from-history =
    .label = მოცილება ისტორიიდან
    .accesskey = მ
urlbar-result-menu-tip-get-help =
    .label = დახმარების მიღება
    .accesskey = ხ
urlbar-result-menu-dismiss-suggestion =
    .label = ამ შეთავაზების აცილება
    .accesskey = ც
urlbar-result-menu-manage-firefox-suggest =
    .label = მართეთ { -firefox-suggest-brand-name }
    .accesskey = მ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = არაზუსტი მდებარეობის მოხსენება
urlbar-result-menu-show-less-frequently =
    .label = იშვიათად ჩვენება
urlbar-result-menu-dont-show-weather-suggestions =
    .label = ამინდის შემოთავაზებების გარეშე
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = მენიუს გახსნა
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = გმადლობთ გამოხმაურებისთვის
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = გმადლობთ გამოხმაურებისთვის. ამინდის შემოთავაზებებს აღარ იხილავთ.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = აკრიფეთ ნაკლები, მონახეთ მეტი: გამოიყენეთ { $engineName } საძიებოდ პირდაპირ მისამართების ველიდან.
urlbar-search-tips-redirect-2 = დაიწყეთ ძიება და შემოთავაზებებს მოგაწვდით { $engineName } ან იხილავთ დათვალიერების ისტორიიდან.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = აირჩიეთ ეს მალსახმობი, რომ უფრო სწრაფად იპოვოთ ის, რაც გჭირდებათ.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = სანიშნები
urlbar-search-mode-tabs = ჩანართები
urlbar-search-mode-history = ისტორია
urlbar-search-mode-actions = მოქმედებები

##

urlbar-geolocation-blocked =
    .tooltiptext = ამ საიტისთვის თქვენს მდებარეობასთან წვდომა შეზღუდული გაქვთ.
urlbar-localhost-blocked =
    .tooltiptext = ამ საიტისთვის ადგილობრივ მოწყობილობასთან კავშირის უფლება შეზღუდული გაქვთ.
urlbar-local-network-blocked =
    .tooltiptext = ამ საიტისთვის შიდა ქსელთან კავშირის უფლება შეზღუდული გაქვთ.
urlbar-xr-blocked =
    .tooltiptext = ამ საიტისთვის წარმოსახვითი სინამდვილის თქვენს მოწყობილობასთან წვდომა შეზღუდული გაქვთ.
urlbar-web-notifications-blocked =
    .tooltiptext = ამ საიტისთვის შეტყობინებების ჩვენების უფლება შეზღუდული გაქვთ.
urlbar-camera-blocked =
    .tooltiptext = ამ საიტისთვის თქვენი კამერის გამოყენების უფლება შეზღუდული გაქვთ.
urlbar-microphone-blocked =
    .tooltiptext = ამ საიტისთვის თქვენი მიკროფონის გამოყენების უფლება შეზღუდული გაქვთ.
urlbar-screen-blocked =
    .tooltiptext = ამ საიტისთვის თქვენი ეკრანის გაზიარების უფლება შეზღუდული გაქვთ.
urlbar-persistent-storage-blocked =
    .tooltiptext = ამ საიტისთვის, მუდმივ მეხსიერებასთან წვდომა შეზღუდული გაქვთ.
urlbar-popup-blocked2 =
    .tooltiptext = ამ საიტისთვის ამომხტომები და გარე გადამისამართებები შეზღუდული გაქვთ.
urlbar-autoplay-media-blocked =
    .tooltiptext = ამ საიტისთვის მედიაფაილების თვითგაშვების უფლება შეზღუდული გაქვთ.
urlbar-canvas-blocked =
    .tooltiptext = ამ საიტისთვის, გრაფიკის გამოსახვის მონაცემებთან წვდომის უფლება შეზღუდული გაქვთ.
urlbar-midi-blocked =
    .tooltiptext = ამ საიტისთვის MIDI წვდომის უფლება შეზღუდული გაქვთ.
urlbar-serial-blocked =
    .tooltiptext = ამ საიტისთვის მიმდევრობით საერთებელთან წვდომის უფლება შეზღუდული გაქვთ.
urlbar-install-blocked =
    .tooltiptext = ამ საიტისთვის დამატების ჩადგმის უფლება შეზღუდული გაქვთ.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = სანიშნის ჩასწორება ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = გვერდის ჩანიშვნა ({ $shortcut })
urlbar-split-view-button =
    .aria-label = გაყოფილი ხედი
    .tooltiptext = გაყოფილი ხედი

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = ჩასმა და გადასვლა
    .accesskey = ჩ
urlbar-menuitem-paste-and-search =
    .label = ჩასმა და მოძიება
    .accesskey = ს

## Searchbar context menu

clear-search-history =
    .label = ძიების ისტორიის გასუფთავება
    .accesskey = ტ

## Page Action Context Menu

page-action-manage-extension2 =
    .label = გაფართოების მართვა…
    .accesskey = ფ
page-action-remove-extension2 =
    .label = გაფართოების ამოშლა
    .accesskey = ლ

## Auto-hide Context Menu

full-screen-autohide =
    .label = ხელსაწყოთა ზოლების დამალვა
    .accesskey = დ
full-screen-exit =
    .label = სრულეკრანიანი რეჟიმიდან გამოსვლა
    .accesskey = ს

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = საძიებოდ გამოიყენეთ:
search-one-offs-change-settings-compact-button =
    .tooltiptext = ძიების პარამეტრების შეცვლა
search-one-offs-context-open-new-tab =
    .label = ძიება ახალ ჩანართში
    .accesskey = ნ
search-one-offs-context-set-as-default =
    .label = ნაგულისხმევ საძიებოდ დაყენება
    .accesskey = გ
search-one-offs-context-set-as-default-private =
    .label = ნაგულისხმევ საძიებოდ დაყენება პირად ფანჯრებში
    .accesskey = პ
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = დაემატება საძიებოდ „{ $engineName }“
    .label = დაამატეთ „{ $engineName }“
    .tooltiptext = დაემატება საძიებოდ „{ $engineName }“
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = საძიებო სისტემის დამატება
    .accesskey = ს
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = საძიებო სისტემის დამატება

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = სანიშნები ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = ჩანართები ({ $restrict })
search-one-offs-history =
    .tooltiptext = ისტორია ({ $restrict })
search-one-offs-actions =
    .tooltiptext = მოქმედებები ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = დამატებების ნახვა
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = გაფართოებები, თემები, დანამატები, დამატებები
# Opens preferences page at AI controls
quickactions-manageai = AI-სამართავის განკარგვა
quickactions-cmd-manageai = გამოირთოს ai, გაითიშოს ai, გაიმართოს ai
# Opens the bookmarks library window
quickactions-bookmarks2 = სანიშნების მართვა
quickactions-cmd-bookmarks = სანიშნები
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = უახლესი ისტორიის გასუფთავება
quickactions-cmd-clearrecenthistory2 = ფუნთუშები,, ფუნთუშების გასუფთავება, მარაგი, მომარაგებულის გასუფთავება, დათვალიერების მონაცემები, დათვალიერების მონაცემების გასუფთავება, ისტორია, უახლესი ისტორიის გასუფთავება
# Opens about:downloads page
quickactions-downloads2 = ჩამოტვირთვების ჩვენება
quickactions-cmd-downloads = ჩამოტვირთვები
# Opens about:addons page in the extensions section
quickactions-extensions = გაფართოებების მართვა
quickactions-cmd-extensions2 = გაფართოებები, დანამატები, დამატებები
# Opens Firefox View
quickactions-firefoxview = გაიხსნას { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = გაიხსნას { -firefoxview-brand-name }, { -firefoxview-brand-name }, ხედის გახსნა, ხედი
# Opens SUMO home page
quickactions-help = { -brand-product-name } – დახმარება
quickactions-cmd-help = დახმარება, მხარდაჭერა
# Opens the devtools web inspector
quickactions-inspector2 = შემმუშავებლის ხელსაწყოების გახსნა
quickactions-cmd-inspector2 = დაკვირვება, გამოკვლევა, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = სურათის არჩევა
quickactions-cmd-colorpicker = ფერის ასარჩევი, საწვეთური, ფერის არჩევა
# Opens Firefox Library
quickactions-cmd-library = ბიბლიოთეკა
quickactions-library = ბიბლიოთეკის გახსნა
# Opens about:logins
quickactions-logins2 = პაროლების მართვა
quickactions-cmd-logins = ანგარიშები და პაროლები
# Mutes all tabs playing audio
quickactions-mute = ხმოვანი ჩანართების დადუმება
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = დადუმება, ჩუ, სუ
# Opens the print dialog
quickactions-print2 = გვერდის ამობეჭდვა
quickactions-cmd-print = ამობეჭდვა
# Opens the print dialog at the save to PDF option
quickactions-savepdf = გვერდი შეინახოს, როგორც PDF
quickactions-cmd-savepdf2 = pdf, გვერდის შენახვა
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = გაიხსნას PDF-შემსწორებელი
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = პირადი ფანჯრის გახსნა
quickactions-cmd-private = პირადი თვალიერება
# Opens a SUMO article explaining how to refresh
quickactions-refresh = შეკეთდეს { -brand-short-name }
quickactions-cmd-refresh = გაახლება
# Restarts the browser
quickactions-restart = ხელახლა გაეშვას { -brand-short-name }
quickactions-cmd-restart = ხელახლა გაშვება
# Opens the screenshot tool
quickactions-screenshot3 = ეკრანის სურათის გადაღება
quickactions-cmd-screenshot2 = ეკრანის სურათი, ეკრანის სურათის გადაღება
# Opens about:translations
quickactions-translate = თარგმნა
quickactions-cmd-translate = თარგმნა
# Opens about:preferences
quickactions-settings2 = პარამეტრების მართვა
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = პარამეტრები, მახასიათებლები, გამართვა, მართვა
# Opens about:addons page in the themes section
quickactions-themes = თემების მართვა
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = თემები, გაფორმებები, დამატებები, დანამატები
# Opens a SUMO article explaining how to update the browser
quickactions-update = განახლდეს { -brand-short-name }
quickactions-cmd-update = განახლება
# Opens the view-source UI with current pages source
quickactions-viewsource2 = გვერდის წყაროს ჩვენება
quickactions-cmd-viewsource2 = წყაროს ნახვა, წყარო, გვერდის წყარო
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = გაიხსნას { -firefoxlabs-brand-name }
quickactions-cmd-labs = ცდები, ექსპერიმენტი
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = ვრცლად სწრაფი მოქმედებების შესახებ
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = დააწექით ჩანართს ასარჩევად:

## Bookmark Panel

bookmarks-add-bookmark = სანიშნის დამატება
bookmarks-edit-bookmark = სანიშნის ჩასწორება
bookmark-panel-cancel =
    .label = გაუქმება
    .accesskey = ქ
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] სანიშნის მოცილება
           *[other] { $count } სანიშნის მოცილება
        }
    .accesskey = მ
bookmark-panel-show-editor-checkbox =
    .label = ჩასწორების შესაძლებლობა შენახვისას
    .accesskey = ჩ
bookmark-panel-save-button2 =
    .label = შენახვა
    .accesskey = ხ
bookmark-panel-save-button =
    .label = შენახვა
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = მონაცემები საიტისთვის { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = კავშირის უსაფრთხოება საიტთან { $host }
identity-connection-not-secure = დაუცველი კავშირი
identity-connection-secure = კავშირი დაცულია
identity-connection-failure = კავშირი ვერ შედგა
identity-connection-internal = { -brand-short-name } – უსაფრთხო გვერდი.
identity-connection-file = ეს გვერდი თქვენს კომპიუტერში ინახება.
identity-connection-associated = ეს გვერდი გახსნილია სხვა გვერდიდან.
identity-extension-page = ეს გვერდი გახსნილია გაფართოების მიერ.
identity-active-blocked = { -brand-short-name } ზღუდავს გვერდის დაუცველ ნაწილებს.
identity-custom-root = კავშირი დამოწმებული აქვს სერტიფიკატის გამომცემს, რომელსაც ვერ ცნობს Mozilla.
identity-passive-loaded = ამ გვერდის გარკვეული ნაწილი დაუცველია (მაგალითად სურათები).
identity-active-loaded = ამ გვერდზე დაცვა გამორთული გაქვთ.
identity-weak-encryption = ეს გვერდი სუსტ დაშიფვრას იყენებს.
identity-https-only-connection-upgraded = (გადაყვანილი HTTPS-ზე)
identity-https-only-label2 = საიტის თავისთავად გადაყვანა დაცულ კავშირზე
identity-https-only-dropdown-on =
    .label = ჩართ.
identity-https-only-dropdown-off =
    .label = გამორთ.
identity-https-only-dropdown-off-temporarily =
    .label = დროებით გამორთ.
identity-https-only-info-turn-on3 = ჩართეთ HTTPS-გადაყვანა ამ საიტისთვის, თუ გსურთ, რომ { -brand-short-name } შეეცადოს უსაფრთხო კავშირზე გადასვლას შესაძლო შემთხვევებში.
identity-https-only-info-turn-off3 = თუ გვერდს ხარვეზები ექნება, დაგჭირდებათ HTTPS-გადასვლის გამორთვა ამ საიტისთვის და გვერდის დაუცველი HTTP-ით ჩატვირთვა.
identity-https-only-info-no-upgrade = ვერ გადადის HTTP დაშიფრულ არხზე.
identity-permissions-storage-access-header = საიტთაშორისი ფუნთუშები
identity-permissions-storage-access-hint = მოცემულ მხარეებს შეუძლია გამოიყენოს საიტთაშორისი ფუნთუშები და მონაცემები ამ საიტზე ყოფნისას
identity-permissions-storage-access-learn-more = ვრცლად
identity-permissions-reload-hint = ცვლილებების ასამოქმედებლად შესაძლოა, გვერდის ხელახლა ჩატვირთვა დაგჭირდეთ.
identity-clear-site-data =
    .label = საიტის ფაილებისა და მონაცემების წაშლა…
identity-connection-not-secure-security-view = თქვენი კავშირი ამ საიტთან არაა დაცული.
identity-connection-verified = თქვენ საიმედოდ ხართ დაკავშირებული ამ საიტთან.
identity-ev-owner-label2 = სერტიფიკატის მფლობელი
identity-verifier-label2 = დამმოწმებელი
identity-ev-owner-label = სერტიფიკატის მფლობელი:
identity-verifier-label = დამმოწმებელი:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = განსაზღრულია წესდების მიხედვით (ᲔᲕ) 2024/1183.
identity-description-custom-root2 = Mozilla არ ცნობს ამ სერტიფიკატის გამცემს. იგი შეიძლება დამატებულია თქვენი საოპერაციო სისტემას ან მმართველი პირის მიერ.
identity-cert-exception-overridden = უსაფრთხოების გამონაკლისი გაქვთ ამ საიტისთვის.
identity-remove-cert-exception =
    .label = გამონაკლისის წაშლა
    .accesskey = წ
identity-description-insecure = კავშირი ამ საიტთან დაუცველია. თქვენ მიერ გადაგზავნილი ინფორმაცია შესაძლოა, სხვებმაც იხილონ (მაგალითად პაროლები, შეტყობინებები, საკრედიტო ბარათების ნომრები და ა. შ.).
identity-description-weak-cipher-intro = საიტთან კავშირი სუსტ დაშიფვრას იყენებს და დაუცველია.
identity-description-weak-cipher-risk = სხვებსაც შეუძლიათ თქვენი ინფორმაციის ნახვა ან ვებსაიტის ქცევის შეცვლა.
identity-description-active-blocked2 = { -brand-short-name } ზღუდავს გვერდის დაუცველ ნაწილებს.
identity-description-passive-loaded = კავშირი დაუცველია და თქვენ მიერ ამ საიტთან გაზიარებული პირადი მონაცემები შესაძლოა, სხვებმაც იხილონ.
identity-description-passive-loaded-insecure2 = ეს ვებსაიტი შეიცავს შიგთავსს, რომელიც დაუცველია (მაგალითად სურათები).
identity-description-passive-loaded-mixed2 = მიუხედავად იმისა, რომ { -brand-short-name } ზღუდავს გარკვეულ შიგთავსს, დაუცველი ნაწილი მაინც რჩება (მაგალითად სურათები).
identity-description-active-loaded = საიტი შეიცავს შიგთავსს, რომელიც დაუცველია (როგორიცაა სკრიპტები) და მასთან კავშირი, ვერ უზრუნველყოფს პირადი მონაცემების უსაფრთხოებას.
identity-description-active-loaded-insecure = ინფორმაცია, რომელსაც ამ საიტს გაუზიარებთ შესაძლოა, სხვებმაც იხილონ (მაგალითად პაროლები, შეტყობინებები, საკრედიტო ბარათები, ა. შ.).
identity-description-tls-key-logging-heading = თქვენი კავშირის პირადულობა შესაძლოა დაუცველი იყოს
identity-description-tls-key-logging-message = გარეშე პროგრამამ ან მომსახურებამ შეიძლება იხილოს თქვენი მიმოცვლილი დაშიფრული მონაცემები ამ საიტთან.
identity-more-info-link-text =
    .label = ვრცლად

## Window controls

browser-window-minimize-button =
    .tooltiptext = ჩაკეცვა
browser-window-maximize-button =
    .tooltiptext = გაშლა
browser-window-restore-down-button =
    .tooltiptext = შემცირება
browser-window-close-button =
    .tooltiptext = დახურვა
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = დაბრუნება

## Bookmarks toolbar items

browser-import-button2 =
    .label = სანიშნების გადმოტანა…
    .tooltiptext = სხვა ბრაუზერიდან გადმოტანილ სანიშნებს გამოიყენებს { -brand-short-name }.
bookmarks-toolbar-empty-message = სწრაფი წვდომისთვის, განათავსეთ თქვენი სანიშნები აქ, სანიშნების ზოლზე. <a data-l10n-name="manage-bookmarks">სანიშნების მართვა…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = კამერა:
    .accesskey = კ
popup-select-camera-icon =
    .tooltiptext = კამერა
popup-select-microphone-device =
    .value = მიკროფონი
    .accesskey = მ
popup-select-microphone-icon =
    .tooltiptext = მიკროფონი
popup-select-speaker-icon =
    .tooltiptext = დინამიკები
popup-select-window-or-screen =
    .label = ფანჯარა ან ეკრანი:
    .accesskey = ფ
popup-all-windows-shared = ეკრანზე ნაჩვენები ყველა ფანჯარა გაზიარდება.

## WebRTC window or screen share tab switch warning

sharing-warning-window = თქვენ გაზიარებული გაქვთ { -brand-short-name }. სხვები დაინახავენ, ახალ ჩანართზე რომ გადახვალთ.
sharing-warning-screen = თქვენ გაზიარებული გაქვთ მთლიანი ეკრანი. სხვები დაინახავენ, ახალ ჩანართზე რომ გადახვალთ.
sharing-warning-proceed-to-tab =
    .label = ჩანართზე გაგრძელება
sharing-warning-disable-for-session =
    .label = ამ სეანსზე გაზიარების დაცვის გამორთვა

## WebSerial "select a port" popup

webserial-select-port-label = მიმდევრობითი საერთებლის არჩევა:
webserial-no-ports-available = მიმდევრობითი საერთებლები მიუწვდომელია

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = დახურვა
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = მოძებნეთ ან შეიყვანეთ მისამართი
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = შეიყვანეთ მისამართი
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = { $name } ძიება
    .placeholder = ინტერნეტში ძიება
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = ძიება { $name }
    .placeholder = მიუთითეთ საძიებო ფრაზა
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = ძიება სანიშნებში
    .placeholder = მიუთითეთ საძიებო ფრაზა
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = ძიება ისტორიაში
    .placeholder = მიუთითეთ საძიებო ფრაზა
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = ძიება ჩანართებში
    .placeholder = მიუთითეთ საძიებო ფრაზა
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = ძიების მოქმედებები
    .placeholder = მიუთითეთ საძიებო ფრაზა
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = საძიებოდ გამოიყენეთ { $name } ან შეიყვანეთ მისამართი
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = ბრაუზერი დაშორებული მართვის ქვეშაა (მიზეზი: { $component })
urlbar-permissions-granted =
    .tooltiptext = ამ საიტისთვის გარკვეული ნებართვები გაქვთ მითითებული.
urlbar-switch-to-tab =
    .value = გადასვლა ჩანართზე:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = გაფართოება:
urlbar-go-button2 =
    .title = მისამართზე გადასვლა
urlbar-page-action-button =
    .tooltiptext = ვებგვერდზე მოქმედებები
urlbar-revert-button =
    .tooltiptext = მისამართის ჩვენება მდებარეობის ზოლში

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = ძიება { $engine } საძიებოთი პირად ფანჯარაში
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = ძიება პირად ფანჯარაში
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine } ძიება
urlbar-result-action-sponsored = დამკვეთებისგან
urlbar-result-action-switch-tab = ჩანართზე გადასვლა
urlbar-result-action-move-tab-to-split-view = ჩანართის გადატანა გაყოფილ ხედზე
urlbar-result-action-visit = მონახულება
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = ჩანართზე გადასვლა · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = უსახელო ჯგუფი
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = აღებულ ბმულზე გადასვლა
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = დააჭირეთ Tab-ს და გამოიყენეთ { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = დააჭირეთ Tab-ს და გამოიყენეთ { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = საძიებოდ გამოიყენეთ { $engine } პირდაპირ მისამართების ველიდან
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = საძიებოდ გამოიყენეთ { $engine } პირდაპირ მისამართების ველიდან
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = ასლი
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = განუსაზღვრელი
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } – გაფართოება
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = სასურველი
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · დამკვეთისგან
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = კითხვა
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = ბოლო მონახულების თარიღია { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] ბოლოს მონახულებულია { $daysAgo } დღის წინ
       *[other] ბოლოს მონახულებულია { $daysAgo } დღის წინ
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] ბოლოს მონახულებულია { $weeksAgo } დღის წინ
       *[other] ბოლოს მონახულებულია { $weeksAgo } დღის წინ
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] ბოლოს მონახულებულია { $monthsAgo } დღის წინ
       *[other] ბოლოს მონახულებულია { $monthsAgo } დღის წინ
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = ბოლო მონახულების თარიღია { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = ჩანიშნული { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = ბოლოს მონახულებული { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = ბოლოს მონახულებული { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = ბოლოს მონახულებული { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = მიიღეთ საფონდო ბირჟის მონაცემები პირდაპირ საძიებო ველში
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = ბაზრის სიახლეებსა და მსგავს ინფორმაციას იხილავთ ჩვენი მოკავშირეებისგან, როცა თქვენი ნებართვით საძიებო სიტყვებს გაეცნობა { -vendor-short-name }. <a data-l10n-name="learn-more-link">ვრცლად</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = შემოთავაზებების ჩვენება
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = ახლა არა
urlbar-result-realtime-opt-in-dismiss = აცილება
urlbar-result-realtime-opt-in-dismiss-all2 = აღარ გამოჩნდეს ამგვარი შემოთავაზებები
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = აღარ გამოჩნდეს ბაზრის შემოთავაზებები
    .accesskey = ა
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = აღარ გამოჩნდეს ბაზრის შემოთავაზებები
urlbar-result-realtime-opt-in-dismiss-all =
    .label = აღარ გამოჩნდეს ამგვარი შემოთავაზებები
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = აღარ გამოჩნდეს ბაზრის შემოთავაზებები
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = გმადლობთ გამოხმაურებისთვის. ბაზრის შესახებ შემოთავაზებებს აღარ იხილავთ.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = საფონდო ბირჟის შემოთავაზებები
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = გმადლობთ გამოხმაურებისთვის. ამგვარ შემოთავაზებებს აღარ იხილავთ.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } დღეში
       *[other] { $name } · { $daysUntilStart } დღეში
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · დაიწყება { $daysUntilStart } დღეში
       *[other] { $name } · დაიწყება { $daysUntilStart } დღეში
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · დასრულდება { $daysUntilEnd } დღეში
       *[other] { $name } · დასრულდება { $daysUntilEnd } დღეში
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · დღეს
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · სრულდება დღეს

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine } ძიება
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - ძიება { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - { $engine } ძიება
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, საძიებოს არჩევა
urlbar-searchmode-button-no-engine2 =
    .title = მალსახმობი არაა მითითებული, მალსახმობის არჩევა
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = საკვანძო სიტყვებით ძიება გამორთულია
urlbar-searchmode-dropmarker2 =
    .title = საძიებოს არჩევა
urlbar-searchmode-bookmarks4 = სანიშნები
urlbar-searchmode-tabs4 = ჩანართები
urlbar-searchmode-history4 = ისტორია
urlbar-searchmode-actions4 = მოქმედებები
urlbar-searchmode-bookmarks3 = სანიშნები
    .accesskey = ნ
urlbar-searchmode-tabs3 = ჩანართები
    .accesskey = ჩ
urlbar-searchmode-history3 = ისტორია
    .accesskey = ტ
urlbar-searchmode-actions3 = მოქმედებები
    .accesskey = ქ
urlbar-searchmode-exit-button2 =
    .title = დახურვა
urlbar-searchmode-default2 =
    .title = ნაგულისხმევი საძიებო
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = დაამატეთ „{ $engineName }“
    .title = დაემატება საძიებოდ „{ $engineName }“
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = საძიებოდ გამოიყენეთ:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = ძიება სისტემით:
urlbar-searchmode-popup-search-settings2 = ძიების პარამეტრები
urlbar-searchmode-popup-settings2 = პარამეტრები
urlbar-searchmode-popup-search-settings = ძიების პარამეტრები
    .accesskey = პ
urlbar-searchmode-popup-settings = პარამეტრები
    .accesskey = პ

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = სანიშნების ძიება
urlbar-result-action-search-history = ისტორიის ძიება
urlbar-result-action-search-tabs = ჩანართების ძიება
urlbar-result-action-search-actions = ძიების მოქმედებები
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = გადაირთოს { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = გაიხსნას { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = გახსნა ახალ ჩანართში
    .accesskey = ლ
urlbar-view-context-menu-open-in-container-tab =
    .label = გახსნა ახალ სათავს ჩანართში
    .accesskey = ვ
urlbar-view-context-menu-open-in-window =
    .label = გახსნა ახალ ფანჯარაში
    .accesskey = ფ
urlbar-view-context-menu-open-in-private-window =
    .label = გახსნა ახალ პირად ფანჯარაში
    .accesskey = პ
urlbar-view-context-menu-open-in-tab2 = გახსნა ახალ ჩანართში
    .accesskey = ლ
urlbar-view-context-menu-open-in-container-tab2 = გახსნა ახალ სათავს ჩანართში
    .accesskey = ვ
urlbar-view-context-menu-open-in-window2 = გახსნა ახალ ფანჯარაში
    .accesskey = ფ
urlbar-view-context-menu-open-in-private-window2 = გახსნა ახალ პირად ფანჯარაში
    .accesskey = პ
urlbar-view-context-menu-search-in-tab = ძიება ახალ ჩანართში
    .accesskey = ხ
urlbar-view-context-menu-search-in-container-tab = ძიება ახალ სათავს ჩანართში
    .accesskey = ს
urlbar-view-context-menu-search-in-window = ძიება ახალ ფანჯარაში
    .accesskey = ლ
urlbar-view-context-menu-search-in-private-window = ძიება ახალ პირად ფანჯარაში
    .accesskey = პ
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = ამ მენიუს გამოტოვება Tab-ღილაკით გადაადგილებისას
    .accesskey = ტ

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } შემოთავაზებები
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = სწრაფი მოქმედებები
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = ბოლოს მოძიებული
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } ხშირად მოძიებულით
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = არ გამოჩნდეს ხშირად მოძიებული
    .accesskey = ა
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = არ გამოჩნდეს ხშირად მოძიებული
    .accesskey = გ
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = არ გამოჩნდეს ხშირად მოძიებული
    .accesskey = გ
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = გმადლობთ გამოხმაურებისთვის. ხშირად მოძიებულს აღარ იხილავთ მომავალში.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = კითხვის რეჟიმზე გადასვლა
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = კითხვის რეჟიმის დახურვა

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = გაიხსნას ეკრანი-ეკრანში ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = დაიხუროს ეკრანი-ეკრანში ({ $shortcut })
picture-in-picture-panel-header = ეკრანი-ეკრანში
picture-in-picture-panel-headline = ამ ვებსაიტს არასასურველად მიაჩნია ეკრანი-ეკრანში
picture-in-picture-panel-body = ვიდეო შეიძლება არ გამოჩნდეს ისე, როგორც დეველოპერმა განიზრახა, სანამ Picture-in-Picture ჩართულია.
picture-in-picture-enable-toggle =
    .label = ჩართვა მაინც

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> სრულ ეკრანზეა
fullscreen-warning-no-domain = დოკუმენტი სრულ ეკრანზეა
fullscreen-exit-button = სრული ეკრანიდან გამოსვლა (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = სრული ეკრანიდან გამოსვლა (esc)
fullscreen-keyboardlock-exit-button = სრული ეკრანიდან გამოსვლა (დააჭირეთ და დააყოვნეთ Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = სრული ეკრანიდან გამოსვლა (დააჭირეთ და დააყოვნეთ esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> მართავს თქვენს მაჩვენებელს. მართვის დასაბრუნებლად დააჭირეთ Esc ღილაკს.
pointerlock-warning-no-domain = ეს დოკუმენტი მართავს თქვენს მაჩვენებელს. მართვის დასაბრუნებლად დააჭირეთ Esc ღილაკს.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = სანიშნების მართვა
bookmarks-recent-bookmarks-panel-subheader = ბოლოს ჩანიშნული
bookmarks-toolbar-chevron =
    .tooltiptext = სხვა სანიშნების გამოჩენაც
bookmarks-sidebar-content =
    .aria-label = სანიშნები
bookmarks-menu-button =
    .label = სანიშნების მენიუ
bookmarks-other-bookmarks-menu =
    .label = სხვა სანიშნები
bookmarks-mobile-bookmarks-menu =
    .label = მობილურის სანიშნები

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] სანიშნების გვერდითი ზოლის დამალვა
           *[other] სანიშნების გვერდითი ზოლის ჩვენება
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] სანიშნების ხელსაწყოთა ზოლის დამალვა
           *[other] სანიშნების ხელსაწყოთა ზოლის ჩვენება
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] სანიშნების ზოლის დამალვა
           *[other] სანიშნების ზოლის გამოჩენა
        }

##

bookmarks-search =
    .label = სანიშნების ძიება
bookmarks-tools =
    .label = სანიშნების ხელსაწყოები
bookmarks-subview-edit-bookmark =
    .label = ამ სანიშნის ჩასწორება…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = სანიშნები
    .toolbarname = სანიშნების ხელსაწყოთა ზოლი
    .accesskey = ს
bookmarks-toolbar-menu =
    .label = სანიშნების ხელსაწყოთა ზოლი
bookmarks-toolbar-placeholder =
    .title = სანიშნების ზოლის ხელსაწყოები
bookmarks-toolbar-placeholder-button =
    .label = სანიშნების ზოლის ხელსაწყოები
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = მიმდინარე ჩანართის ჩანიშვნა…

## Library Panel items

library-bookmarks-menu =
    .label = სანიშნები

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = ტექსტის კოდირების გასწორება
    .tooltiptext = ამოიცნობს სათანადო კოდირებას გვერდის შიგთავსიდან

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = პარამეტრები
    .tooltiptext =
        { PLATFORM() ->
            [macos] პარამეტრების გახსნა ({ $shortcut })
           *[other] პარამეტრების გახსნა
        }
toolbar-overflow-customize-button =
    .label = ხელსაწყოთა ზოლის მორგება…
    .accesskey = ზ
toolbar-button-email-link =
    .label = ბმულის ელფოსტით გაგზავნა
    .tooltiptext = გვერდის ბმულის ელფოსტით გაგზავნა
toolbar-button-logins =
    .label = პაროლები
    .tooltiptext = იხილეთ და მართეთ შენახული პაროლები
qrcode-panel-error =
    .message = QR-კოდის შედგენა ვერ მოხერხდა. გთხოვთ, კვლავ სცადოთ.
qrcode-copy-button =
    .label = ასლი
qrcode-copy-success =
    .message = QR-კოდის ასლი აღებულია.
qrcode-copy-error =
    .message = ვერ მოხერხდა QR-კოდის ასლი აღება.
qrcode-save-button =
    .label = შენახვა
qrcode-window-title = QR-კოდი
qrcode-dialog-title = QR-კოდი
qrcode-image =
    .aria-label = QR-კოდი
qrcode-close-button =
    .aria-label = დახურვა
toolbar-button-save-page =
    .label = გვერდის შენახვა
    .tooltiptext = გვერდის შენახვა ({ $shortcut })
toolbar-button-open-file =
    .label = ფაილის გახსნა
    .tooltiptext = ფაილის გახსნა ({ $shortcut })
toolbar-button-synced-tabs =
    .label = დასინქ. ჩანართები
    .tooltiptext = ჩანართები სხვა მოწყობილობებიდან
toolbar-button-send-tab =
    .label = ჩანართის გაგზავნა
    .tooltiptext = მიმდინარე ჩანართის გაგზავნა სხვა მოწყობილობაზე
toolbar-button-new-private-window =
    .label = ახალი პირადი ფანჯარა
    .tooltiptext = ახალი პირადი ფანჯრის გახსნა ({ $shortcut })
toolbar-button-share-tab =
    .label = გაზიარება
    .tooltiptext = ამ გვერდის გაზიარება
toolbar-button-tab-groups =
    .label = ჩანართის ჯგუფები
    .tooltiptext = ჩანართის ჯგუფების ჩვენება
toolbar-button-history =
    .label = ისტორია
    .tooltiptext = ისტორიის ჩვენება ({ $shortcut })
toolbar-button-find =
    .label = ძიება
    .tooltiptext = ამ გვერდზე პოვნა ({ $shortcut })
toolbar-button-developer =
    .label = შემმუშავებლის ხელსაწყოები
    .tooltiptext = ვებშემუშავების ხელსაწყოების გახსნა ({ $shortcut })
toolbar-button-forget =
    .label = დავიწყება
    .tooltiptext = მონახულებული გვერდების ისტორიის ნაწილის დავიწყება
toolbar-zoom-controls =
    .label = ზომების მართვა
    .title = ზომების მართვა
toolbar-button-zoom-out =
    .label = დაშორება
    .tooltiptext = დაშორება ({ $shortcut })
toolbar-button-zoom-reset-tooltip = საწყის ზომაზე დაბრუნება ({ $shortcut })
toolbar-button-zoom-in =
    .label = მიახლოება
    .tooltiptext = მიახლოება ({ $shortcut })
toolbar-edit-controls =
    .label = ჩასწორების ხელსაწყოები
    .title = ჩასწორების ხელსაწყოები
toolbar-button-cut =
    .label = ამოჭრა
    .tooltiptext = ამოჭრა ({ $shortcut })
toolbar-button-copy =
    .label = ასლი
    .tooltiptext = ასლი ({ $shortcut })
toolbar-button-paste =
    .label = ჩასმა
    .tooltiptext = ჩასმა ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = ამ საიტზე ხმოვანი ან ვიდეოფაილების ნაწილი იყნებს DRM-პროგრამას, შედეგად { -brand-short-name } შესაძლოა, გიზღუდავდეთ მათ თავისუფალ გამოყენებას.
eme-notifications-drm-content-playing-manage = პარამეტრების მართვა
eme-notifications-drm-content-playing-manage-accesskey = ვ
eme-notifications-drm-content-playing-dismiss = დახურვა
eme-notifications-drm-content-playing-dismiss-accesskey = უ

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = ამ გვერდზე ზოგიერთი ხმოვანი ან ვიდეოფაილის გასაშვებად უნდა ჩართოთ DRM.
eme-notifications-drm-content-disabled-button =
    .label = ჩაირთოს DRM
    .accesskey = D
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } აყენებს ამ გვერდზე ხმოვანი ფაილის ან ვიდეოს გასაშვებად საჭირო პროგრამულ ნაწილებს. მოითმინეთ და სცადეთ ახლიდან.
decoder-doctor-no-codecs-linux-message = ვიდეოს გასაშვებად შეიძლება დაგჭირდეთ შესაბამისი ვიდეომშიფრავების დაყენება.
decoder-doctor-no-hw-acceleration-message = ვიდეოს ხარისხის გასაუმჯობესებლად, შეიძლება დაგჭირდეთ Microsoft Media Feature Pack-ის დაყენება.
decoder-doctor-no-pulse-audio-message = აუდიოს გასაშვებად, შეიძლება დაგჭირდეთ PulseAudio პროგრამა.
decoder-doctor-unsupported-libavcodec-message = libavcodec შესაძლოა, დაუცველია ან არაა მხარდაჭერილი და ვიდეოს გასაშვებად საჭიროა მისი განახლება.
decoder-doctor-decode-error-message = შეცდომა, მედიაფაილის გაშიფვრისას.
decoder-doctor-decode-warning-message = აღდგენადი შეცდომა, მედიაფაილის გაშიფვრისას.
decoder-doctor-learn-how-link = ნახეთ როგორ
decoder-doctor-report-issue-button =
    .label = საიტის ხარვეზის მოხსენება
    .accesskey = მ
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = { $pluginName } მოდული უეცრად გაითიშა.
plugin-crashed-notification-reload-button =
    .label = გვერდის ხელახლა გახსნა
    .accesskey = ხ
plugin-crashed-notification-submit-button =
    .label = უეცარი გათიშვის მოხსენების გადაგზავნა
    .accesskey = გ

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = თაღლითური საიტი!
safebrowsing-reported-attack-site-message = გვერდი მიჩნეულია მოიერიშედ!
safebrowsing-reported-unwanted-site-message = საიტი, შემჩნეულია არასასურველი პროგრამის გავრცელებაში!
safebrowsing-reported-harmful-site-message = გვერდი მიჩნეულია სახიფათოდ!
safebrowsing-get-me-out-of-here-button =
    .label = აქედან გასვლა!
    .accesskey = გ
safebrowsing-not-a-deceptive-site-button =
    .label = ეს თაღლითური საიტი არაა…
    .accesskey = მ
safebrowsing-not-an-attack-site-button =
    .label = ეს მოიერიშე საიტი არაა…
    .accesskey = ე

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = ინტერნეტთან დასაკავშირებლად, საჭიროა ამ ქსელში შესვლა.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = ქსელში შესასვლელი გვერდის გახსნა

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = ხომ არ გსურთ, იხილოთ { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = დიახ, მსურს გაიხსნას { $hostName }
    .accesskey = დ

## Password save/update panel

panel-save-update-username-2 =
    .label = მომხმარებელი
panel-save-update-password-2 =
    .label = პაროლი

##

# "More" item in macOS share menu
menu-share-more =
    .label = სხვა…
menu-share-windows =
    .label = სხვა პარამეტრები
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] ბმულის ასლი
           *[other] { $count } ბმულის ასლი
        }
    .accesskey = უ
ui-tour-info-panel-close =
    .tooltiptext = დახურვა

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = ნებართვა, რომ ამომხტომი ფანჯრების ჩვენებასა და გარე გადამისამართებებს შეძლებს { $uriHost }
    .accesskey = ხ

##

picture-in-picture-hide-toggle =
    .label = ეკრანი-ეკრანში გადამრთველის დამალვა
    .accesskey = ე

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = ეკრანი-ეკრანში გადამრთველის მარჯვნივ გადატანა
    .accesskey = ჯ
picture-in-picture-move-toggle-left =
    .label = ეკრანი-ეკრანში გადამრთველის მარცხნივ გადატანა
    .accesskey = ც

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = გადაადგილება
navbar-downloads =
    .label = ჩამოტვირთვები
navbar-overflow-2 =
    .tooltiptext = სხვა ხელსაწყოები
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = ამობეჭდვა
    .tooltiptext = გვერდის ამობეჭდვა… ({ $shortcut })
navbar-home =
    .label = საწყისი გვერდი
    .tooltiptext = { -brand-short-name } საწყისი გვერდი
navbar-library =
    .label = ბიბლიოთეკა
    .tooltiptext = იხილეთ ისტორია, შენახული სანიშნები და ა. შ.
navbar-search =
    .title = ძიება
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = ბრაუზერის ჩანართები
tabs-toolbar-new-tab =
    .label = ახალი ჩანართი
tabs-toolbar-list-all-tabs-2 =
    .label = მოძებნეთ და მართეთ ჩანართები
    .tooltiptext = მოძებნეთ და მართეთ ჩანართები
tabs-toolbar-list-all-tabs =
    .label = ყველა ჩანართის სია
    .tooltiptext = ყველა ჩანართის სია

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = ჩავლებით გადმოიტანეთ ჩანართი აქ მისამაგრებლად

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>გაიხსნას წინა ჩანართები?</strong> თუ გსურთ, { -brand-short-name } აღდგეს წინა მდგომარეობით, გახსენით მენიუ <img data-l10n-name="icon"/> და მონახეთ ისტორია.
restore-session-startup-suggestion-button = მაჩვენეთ, როგორ

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = დაწესებულების დებულებით შეზღუდულია ადგილობრივ ფაილებთან წვდომა ამ კომპიუტერზე.

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } ახლა უკვე ჩანართებსაც იპოვის
urlbar-addons-shortcut-moved-description = გაფართოებებისა და თემების გასახსნელად გამოიყენეთ { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = მალსახმობების მართვა
urlbar-addons-shortcut-moved-dismiss = გასაგებია

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } ავტომატურად აგზავნის გარკვეულ მონაცემებს { -vendor-short-name }-ში, პროდუქტის გასაუმჯობესებლად.
data-reporting-notification-button =
    .label = გასაზიარებელ მონაცემთა შერჩევა
    .accesskey = ზ
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = პირადი ფანჯარა
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = პირადი თვალიერება
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = პირადი დათვალიერების მონაცემები
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = თქვენ იმყოფებით პირად ფანჯარაში
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = ეს გეხმარებათ დაფაროთ მონახულებული გვერდები სხვებისგან ამ მოწყობილობაზე, მაგრამ ვერ გაგხდით უჩინარს ინტერნეტში. <a data-l10n-name="learn-more">ვინ შეიძლება იხილოს ჩემი მოქმედებები?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = მონაცემთა დაკარგვის არიდებას (DLP) უზრუნველყოფს { $agentName }. დაწკაპეთ ვრცლად სანახავად.
content-analysis-panel-title2 = მონაცემთა დაკარგვის არიდება
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = თქვენს დაწესებულებაში გამოიყენება <b>{ $agentName }</b> საფრთხილო მონაცემთა განკარგვისთვის გაზიარებისას. <a data-l10n-name="info">ვრცლად</a>
content-analysis-panel-title = მონაცემთა დაცვა
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = თქვენს დაწესებულებაში გამოიყენება <b>{ $agentName }</b> მონაცემთა დაკარგვის ასარიდებლად. <a data-l10n-name="info">ვრცლად</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = გაფართოებები
    .tooltiptext = გაფართოებები

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = გაფართოებები
    .tooltiptext =
        გაფართოებები
        საჭიროა ნებართვები

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = გაფართოებები
    .tooltiptext =
        გაფართოებები
        ზოგი გაფართოება არაა ნებადართული

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = გაფართოებები
    .tooltiptext =
        გაფართოებები
        ზოგიერთი გაფართოება ამორთულია

## Private browsing reset button

reset-pbm-panel-heading2 = წაიშალოს მონაცემები და გაეშვას ახალი პირადი სეანსი?
reset-pbm-panel-description3 = შედეგად წაიშლება თქვენი ისტორია, ფუნთუშები და საიტებიდანაც გამოხვალთ. თქვენი პირადი ფანჯრები დაიხურება და გაიხსნება ახალი.
reset-pbm-panel-description2 = შედეგად წაიშლება ისტორია, ფუნთუშები და საიტის ყველა სხვა მონაცემი პირადი ფანჯრის დაუხურავად.
reset-pbm-panel-always-ask-checkbox =
    .label = შეკითხვა ყოველ ჯერზე
    .accesskey = ჯ
reset-pbm-panel-cancel-button =
    .label = გაუქმება
    .accesskey = ქ
reset-pbm-panel-confirm-button2 =
    .label = პირადი სეანსის გასუფთავება
    .accesskey = უ
reset-pbm-panel-complete = პირადი სეანსის მონაცემები გასუფთავებულია
reset-pbm-toolbar-button2 =
    .label = პირადი სეანსის გასუფთავება
    .tooltiptext = პირადი სეანსის გასუფთავება

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = წაიშალოს დათვალიერების მონაცემების?
fire-button-panel-description = წაიშლება ისტორია, ფუნთუშები და საიტის მონაცემები. გამოხვალთ საიტებიდანაც. ეს ფანჯარა დაიხურება და { -brand-short-name } გახსნის ახალს.
fire-button-panel-choose-description = თუ არ გსურთ ყველაფრის წაშლა, სანაცვლოდ აირჩიეთ ცალკეული მონაცემები.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = არჩევა…
fire-button-panel-cancel-button =
    .label = გაუქმება
    .accesskey = გ
fire-button-panel-confirm-button =
    .label = ყველას წაშლა
    .accesskey = ყ
fire-button-panel-complete = დათვალიერების მონაცემები წაშლილია
fire-button-toolbar-button2 =
    .label = ზოგიერთი ან ყველა მონაცემის წაშლა
    .tooltiptext = წაშალეთ ნაწილობრივ ან სრულად თქვენი დათვალიერების მონაცემები

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } ამ გვერდის თვითგანახლებას კრძალავს.
refresh-blocked-redirect-label = { -brand-short-name } ამ გვერდის სხვა გვერდზე თვითგადამისამართებას კრძალავს.
refresh-blocked-allow =
    .label = ნებართვა
    .accesskey = ნ

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = ჩვენი დაცული, ადვილად გამოსაყენებელი შესაძლებლობა დაგეხმარებათ, დაფაროთ ვინაობა და აირიდოთ უსარგებლო წერილები ელფოსტის მისამართის შენიღბვით.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = თქვენი ელფოსტის ნიღბებზე შემოსული ყველა წერილი გადამისამართდება <strong>{ $useremail }</strong>-ზე (თუ თავად არ შეზღუდავთ).
firefox-relay-offer-legal-notice = „ელფოსტის ნიღბის გამოყენებაზე“ დაწკაპებით ეთანხმებით <label data-l10n-name="tos-url">მომსახურების პირობებსა</label> და <label data-l10n-name="privacy-url">პირადულობის განაცხადს</label>.
firefox-relay-offer-legal-notice-1 = ანგარიშისა და ელფოსტის ნიღბის შექმნით ეთანხმებით <label data-l10n-name="tos-url">მომსახურების პირობებსა</label> და <label data-l10n-name="privacy-url">პირადულობის განაცხადს</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (შეუმოწმებელი)
popup-notification-xpinstall-prompt-learn-more = იხილეთ ვრცლად დამატებების უსაფრთხოდ ჩადგმის შესახებ
popup-notification-xpinstall-prompt-block-url = ვრცლად
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = ნებართვა გაფართოების პირად ფანჯრებში გასაშვებად
    .accesskey = პ
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = ტექნიკური და ურთიერთქმედების მონაცემების გაზიარება გაფართოების შემმუშავებლისთვის
    .accesskey = ზ

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } უზღუდავს საიტს ამომხტომი ფანჯრის ჩვენებას.
       *[other] { -brand-short-name } უზღუდავს საიტს { $popupCount } ამომხტომი ფანჯრის ჩვენებას.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } უზღუდავს საიტს გარე გადამისამართებას.
        [1] { -brand-short-name } უზღუდავს საიტს ამომხტომის ჩვენებასა და გარე გადამისამართებას.
        [one] { -brand-short-name } უზღუდავს საიტს { $popupCount } ამომხტომის ჩვენებასა და გარე გადამისამართებას.
       *[other] { -brand-short-name } უზღუდავს საიტს { $popupCount } ამომხტომის ჩვენებასა და გარე გადამისამართებას.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } უზღუდავს საიტს { $popupCount }-ზე მეტი ფანჯრის ჩვენებას.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
       *[other] { -brand-short-name } უზღუდავს საიტს { $popupCount }-ზე მეტი ამომხტომის ჩვენებასა და გადამისამართებას.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] პარამეტრები
           *[other] პარამეტრები
        }
    .accesskey =
        { PLATFORM() ->
            [windows] პ
           *[other] პ
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = გაიხსნას „{ $popupURI }“
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = გამოჩნდეს „{ $redirectURI }“

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Windows-ის ფაილების მმართველი ვერ გაიხსნა. ფაილის ან საქაღალდის შერჩევა ვერ მოხერხდა.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Windows-ის ფაილების მმართველი ვერ გაიხსნა. ფაილის შენახვის ადგილი იქნება { $path }.
file-picker-failed-save-nowhere = Windows-ის ფაილების მმართველი ვერ გაიხსნა. ნაგულისხმევი საქაღალდე ვერ მოინახა; ფაილის შენახვა ვერ მოხერხდა.
file-picker-crashed-open = Windows-ის ფაილების მმართველი უეცრად გაითიშა. ფაილის ან საქაღალდის შერჩევა ვერ მოხერხდა.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows-ის ფაილების მმართველი უეცრად გაითიშა. ფაილის შენახვის ადგილი იქნება { $path }.
file-picker-crashed-save-nowhere = Windows-ის ფაილების მმართველი უეცრად გაითიშა. ნაგულისხმევი საქაღალდე ვერ მოინახა; ფაილის შენახვა ვერ მოხერხდა.
file-picker-crashed-show-in-folder =
    .label = ჩვენება საქაღალდეში
    .accessKey = ქ

## Unsigned add-ons notification

unsigned-addons-disabled-message = ერთი ან რამდენიმე ჩადგმული დამატების გადამოწმება ვერ ხერხდება, რის გამოც გამოირთვება.
unsigned-addons-disabled-learn-more =
    .label = ვრცლად
    .accesskey = ვ

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = ამ გვერდის გამო ნელდება { -brand-short-name }. შეაჩერეთ იგი, ბრაუზერის ასასწრაფებლად.
process-hang-nonspecific-tab-message = ვებგვერდის გამო ნელდება { -brand-short-name }. შეაჩერეთ იგი, ბრაუზერის ასასწრაფებლად.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = „{ $title }“ გვერდის გამო ნელდება { -brand-short-name }. შეაჩერეთ იგი, ბრაუზერის ასასწრაფებლად.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = „{ $addonName }“ გაფართოების გამო ნელდება { -brand-short-name }. შეაჩერეთ იგი, ბრაუზერის ასასწრაფებლად.
process-hang-addon-learn-more =
    .value = ვრცლად
process-hang-stop-button =
    .label = შეწყვეტა
    .accesskey = წ

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = გამართვის დასრულება
onboarding-aw-finish-setup-button =
    .label = გამართვის დასრულება
    .tooltiptext = სრულადაა გამართული { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = თვალთვალისგან გაძლიერებული დაცვა ჩართ.
trustpanel-etp-label-disabled = თვალთვალისგან გაძლიერებული დაცვა გამორთ.
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = თვალთვალისგან გაძლიერებული დაცვა: ჩართ. { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = თვალთვალისგან გაძლიერებული დაცვა: გამორთ. { $host }
trustpanel-etp-description-enabled = თუ საიტზე რამე გაუმართავად ჩანს, სინჯეთ გამორთვა.
trustpanel-etp-description-disabled = { -brand-product-name } მიიჩნევს, რომ კომპანიები ნაკლებად უნდა გადევნებდნენ თვალს. ჩვენ ვზღუდავთ რაც შეიძლება მეტ მეთვალყურეს დაცვის ჩართვისას.
trustpanel-trackercount-label = შეზღუდული მეთვალყურეების ჩვენება მისამართების ველში
trustpanel-trackercount-toggle =
    .aria-label = შეზღუდული მეთვალყურეების ჩვენება მისამართების ველში
trustpanel-connection-label-secure = კავშირი დაცულია
trustpanel-connection-label-insecure = დაუცველი კავშირი
trustpanel-header-enabled = { -brand-product-name } სადარაჯოზეა
trustpanel-description-enabled2 = დაცული ხართ. თუ რამეს შევამჩნევთ, გაცნობებთ.
trustpanel-header-enabled-insecure = ფრთხილად იყავით ამ საიტზე
trustpanel-description-enabled-insecure = { -brand-product-name } რაღაც საეჭვოს წააწყდა.
trustpanel-header-disabled = გამორთული გაქვთ დაცვა
trustpanel-description-disabled = { -brand-product-name } უქმადაა. გირჩევთ, კვლავ ჩართოთ დაცვა.
trustpanel-clear-cookies-button = ფუნთუშებისა და საიტის მონაცემების გასუფთავება
trustpanel-privacy-link = პირადულობის გამართვა
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = ფუნთუშებისა და საიტის მონაცემების გასუფთავება საიტისთვის { $host }
trustpanel-clear-cookies-description = ფუნთუშებისა და საიტის მონაცემების წაშლით შეიძლება გამოხვიდეთ შესული ანგარიშებიდან და დაგიცარიელდეთ საყიდლების კალათები.
trustpanel-clear-cookies-subview-button-clear = გასუფთავება
trustpanel-clear-cookies-subview-button-cancel = გაუქმება
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = კავშირის უსაფრთხოება საიტთან { $host }
trustpanel-siteinformation-morelink = საიტის სხვა მონაცემები
trustpanel-blocker-see-all = ყველას ნახვა
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = თვალთვალისგან დაცვა საიტისთვის { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = დაუცველი
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } მეთვალყურე შეიზღუდა
       *[other] { $count } მეთვალყურე შეიზღუდა
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } მიიჩნევს, რომ კომპანიები ნაკლებად უნდა გადევნებდნენ თვალს. ასე რომ, ჩვენ ვზღუდავთ რაც შეიძლება მეტ მათგანს.
trustpanel-blocked-header = { -brand-product-name } თქვენთვის ზღუდავს შემდეგს:
trustpanel-tracking-header = { -brand-product-name } საიტების გაუმართაობის ასარიდებლად არ ზღუდავს შემდეგს:
trustpanel-tracking-description = მეთვალყურეების შეზღუდვით ზოგიერთმა ღილაკმა, კითხვარის შესავსებმა და ანგარიშზე შესვლის ველებმა შეიძლება ვერ იმუშაოს.
trustpanel-insecure-section-header = თქვენი კავშირი დაუცველია
trustpanel-insecure-description = ამ საიტზე შეყვანილი მონაცემები დაუშიფრავია. შეიძლება ვინმე უცხომ იხილოს, მიიტაცოს ან გადააკეთოს.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } საიტთაშორისი მეთვალყურე ფუნთუშა
       *[other] { $count } საიტთაშორისი მეთვალყურე ფუნთუშა
    }
trustpanel-list-label-tracking-content = თვალის მდევნელი შიგთავსი
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] მომხმარებლის { $count } ამომცნობი
       *[other] მომხმარებლის { $count } ამომცნობი
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] სოცქსელის { $count } მეთვალყურე
       *[other] სოცქსელის { $count } მეთვალყურე
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } კრიპტოგამომმუშავებელი
       *[other] { $count } კრიპტოგამომმუშავებელი
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ზღუდავს სოცქსელის { $count } მეთვალყურეს
       *[other] { -brand-product-name } ზღუდავს სოცქსელის { $count } მეთვალყურეს
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ნებას რთავს სოცქსელის { $count } მეთვალყურეს
       *[other] { -brand-product-name } ნებას რთავს სოცქსელის { $count } მეთვალყურეს
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ზღუდავს { $count } საიტთაშორის მეთვალყურეს
       *[other] { -brand-product-name } ზღუდავს { $count } საიტთაშორის მეთვალყურეს
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ნებას რთავს { $count } საიტთაშორის მეთვალყურეს
       *[other] { -brand-product-name } ნებას რთავს { $count } საიტთაშორის მეთვალყურეს
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ზღუდავს { $count } მეთვალყურეს
       *[other] { -brand-product-name } ზღუდავს { $count } მეთვალყურეს
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ნებას რთავს { $count } მეთვალყურეს
       *[other] { -brand-product-name } ნებას რთავს { $count } მეთვალყურეს
    }
trustpanel-tracking-content-tab-list-header = მოცემული საიტები ცდილობს თვალის დევნებას:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ზღუდავს მომხმარებლის { $count } ამომცნობს
       *[other] { -brand-product-name } ზღუდავს მომხმარებლის { $count } ამომცნობს
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ნებას რთავს მომხმარებლის { $count } ამომცნობს
       *[other] { -brand-product-name } ნებას რთავს მომხმარებლის { $count } ამომცნობს
    }
trustpanel-fingerprinter-list-header = მოცემული საიტები ცდილობს, გამოგარჩიოთ სხვებისგან:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ზღუდავს { $count } კრიპტოგამომმუშავებელს
       *[other] { -brand-product-name } ზღუდავს { $count } კრიპტოგამომმუშავებელს
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ნებას რთავს { $count } კრიპტოგამომმუშავებელს
       *[other] { -brand-product-name } ნებას რთავს { $count } კრიპტოგამომმუშავებელს
    }
trustpanel-cryptominer-tab-list-header = მოცემული საიტები ცდილობს კრიპტოგამომუშავებას:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = გაქვთ ანგარიში ამ საიტზე?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } გაცნობებთ, რომ ამ საიტზე აღმოჩენილია მონაცემთა მიტაცების შემთხვევა ბოლო 12 თვის განმავლობაში. გაარკვიეთ, მოხვედრილი ხართ თუ არა დაზარალებულთა შორის.
trustpanel-breachalerts-anonymous-breached-button-dismiss = აცილება
trustpanel-breachalerts-anonymous-breached-button-check-monitor = უფასო შემოწმების დაწყება
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> მეთვალყურე შეიზღუდა ამ საიტზე
       *[other] <span data-l10n-name="count">{ $count }</span> მეთვალყურე შეიზღუდა ამ საიტზე
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>საიტი გაუმართავი ჩანს?</strong> გააახლეთ გვერდი თვალთვალისგან დაცვის დროებით შემცირებით.
reduced-protection-infobar-reload-button = გაახლება
    .accesskey = ხ
reduced-protection-infobar-never-show-button = მომავალში ჩვენების გარეშე
    .accesskey = გ


identity-allow-site-data = vOrbit-lite: მონაცემების/ქუქიების ყოველთვის დამახსოვრება ამ საიტისთვის
