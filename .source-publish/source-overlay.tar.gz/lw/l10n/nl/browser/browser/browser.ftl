# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name }-privénavigatie
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Snel en privé surfen op het web
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } – privénavigatie
       *[other] { -brand-full-name }-privénavigatie
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Privénavigatie
popups-infobar-dont-show-message2 =
    .label = Dit bericht niet tonen wanneer pop-ups of omleidingen van derden worden geblokkeerd
    .accesskey = n
edit-popup-settings2 =
    .label = Instellingen voor pop-ups en omleidingen van derden beheren…
    .accesskey = b
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Website-informatie bekijken
            [1] Website-informatie bekijken ({ $count } tracker geblokkeerd)
            [one] Website-informatie bekijken ({ $count } tracker geblokkeerd)
           *[other] Website-informatie bekijken ({ $count } trackers geblokkeerd)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } koppeling
           *[other] { $count } koppelingen
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Berichten en meer…
    .accesskey = B
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Berichten, e-mail en meer…
    .accesskey = m
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Delen…
    .accesskey = D
urlbar-identity-button =
    .aria-label = Website-informatie weergeven

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Berichtpaneel voor installatie openen
urlbar-web-notification-anchor =
    .tooltiptext = Wijzigen of u notificaties van de website kunt ontvangen
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI-paneel openen
urlbar-serial-notification-anchor =
    .tooltiptext = Paneel Serieel openen
urlbar-eme-notification-anchor =
    .tooltiptext = Gebruik van DRM-software beheren
urlbar-web-authn-anchor =
    .tooltiptext = Paneel Webauthenticatie openen
urlbar-canvas-notification-anchor =
    .tooltiptext = Canvas-extractietoestemming beheren
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Delen van uw microfoon met de website beheren
urlbar-default-notification-anchor =
    .tooltiptext = Berichtpaneel openen
urlbar-geolocation-notification-anchor =
    .tooltiptext = Paneel voor locatieaanvraag openen
urlbar-localhost-notification-anchor =
    .tooltiptext = Lokale apparaattoegang voor deze website beheren
urlbar-local-network-notification-anchor =
    .tooltiptext = Delen van uw lokale netwerktoegang met deze website beheren
urlbar-xr-notification-anchor =
    .tooltiptext = Machtigingsvenster voor virtual reality openen
urlbar-storage-access-anchor =
    .tooltiptext = Toestemmingspaneel voor surfactiviteit openen
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Delen van uw vensters of scherm met de website beheren
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Berichtpaneel voor offlineopslag openen
urlbar-password-notification-anchor =
    .tooltiptext = Berichtpaneel voor opslaan van wachtwoord openen
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Delen van uw camera en/of microfoon met de website beheren
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Delen van uw andere luidsprekers met de website beheren
urlbar-autoplay-notification-anchor =
    .tooltiptext = Paneel voor automatisch afspelen openen
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Gegevens in permanente opslag bewaren
urlbar-addons-notification-anchor =
    .tooltiptext = Berichtpaneel voor add-on-installatie openen
urlbar-search-tips-confirm = Oké, begrepen
urlbar-search-tips-confirm-short = Begrepen
urlbar-result-menu-button =
    .title = Menu openen
urlbar-result-menu-button-feedback = Feedback
    .title = Menu openen
urlbar-result-menu-learn-more2 = Meer info
    .accesskey = M
urlbar-result-menu-remove-from-history2 = Verwijderen uit geschiedenis
    .accesskey = V
urlbar-result-menu-tip-get-help2 = Hulp verkrijgen
    .accesskey = H
urlbar-result-menu-dismiss-suggestion2 = Deze suggestie verwijderen
    .accesskey = w
urlbar-result-menu-remove-top-site = Deze topwebsite verwijderen
    .accesskey = t
urlbar-result-menu-manage-firefox-suggest2 = { -firefox-suggest-brand-name } beheren
    .accesskey = b
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Onjuiste locatie melden
    .accesskey = O
urlbar-result-menu-show-less-frequently3 = Minder vaak tonen
    .accesskey = M
urlbar-result-menu-dont-show-weather-suggestions3 = Geen weersuggesties tonen
    .accesskey = G
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Onjuiste locatie melden
urlbar-result-menu-show-less-frequently2 = Minder vaak tonen
urlbar-result-menu-dont-show-weather-suggestions2 = Geen weersuggesties tonen
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Deze suggestie verwijderen
    .accesskey = w
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Verwijderen uit geschiedenis
    .accesskey = j
urlbar-result-menu-learn-more =
    .label = Meer info
    .accesskey = M
urlbar-result-menu-remove-from-history =
    .label = Verwijderen uit geschiedenis
    .accesskey = V
urlbar-result-menu-tip-get-help =
    .label = Hulp verkrijgen
    .accesskey = H
urlbar-result-menu-dismiss-suggestion =
    .label = Deze suggestie verwijderen
    .accesskey = w
urlbar-result-menu-manage-firefox-suggest =
    .label = { -firefox-suggest-brand-name } beheren
    .accesskey = b
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Onjuiste locatie melden
urlbar-result-menu-show-less-frequently =
    .label = Minder vaak tonen
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Geen weersuggesties tonen
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Menu openen
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Bedankt voor uw feedback
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Bedankt voor uw feedback. U ziet geen weersuggesties meer.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Minder typen, meer vinden: direct zoeken bij { $engineName } vanaf uw adresbalk.
urlbar-search-tips-redirect-2 = Begin in de adresbalk met zoeken om suggesties van { $engineName } en uit uw browsergeschiedenis te zien.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Selecteer deze snelkoppeling om sneller te vinden wat u nodig hebt.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Bladwijzers
urlbar-search-mode-tabs = Tabbladen
urlbar-search-mode-history = Geschiedenis
urlbar-search-mode-actions = Acties

##

urlbar-geolocation-blocked =
    .tooltiptext = U hebt locatiegegevens voor deze website geblokkeerd.
urlbar-localhost-blocked =
    .tooltiptext = U hebt lokale apparaatverbindingen voor deze website geblokkeerd.
urlbar-local-network-blocked =
    .tooltiptext = U hebt lokale netwerkverbindingen voor deze website geblokkeerd.
urlbar-xr-blocked =
    .tooltiptext = U hebt toegang tot virtual-reality-apparaten voor deze website geblokkeerd.
urlbar-web-notifications-blocked =
    .tooltiptext = U hebt notificaties voor deze website geblokkeerd.
urlbar-camera-blocked =
    .tooltiptext = U hebt uw camera voor deze website geblokkeerd.
urlbar-microphone-blocked =
    .tooltiptext = U hebt uw microfoon voor deze website geblokkeerd.
urlbar-screen-blocked =
    .tooltiptext = U hebt het delen van uw scherm voor deze website geblokkeerd.
urlbar-persistent-storage-blocked =
    .tooltiptext = U hebt permanente opslag voor deze website geblokkeerd.
urlbar-popup-blocked2 =
    .tooltiptext = U hebt pop-ups en omleidingen van derden voor deze website geblokkeerd.
urlbar-autoplay-media-blocked =
    .tooltiptext = U hebt het automatisch afspelen van media met geluid voor deze website geblokkeerd.
urlbar-canvas-blocked =
    .tooltiptext = U hebt canvas-gegevensextractie voor deze website geblokkeerd.
urlbar-midi-blocked =
    .tooltiptext = U hebt MIDI-toegang voor deze website geblokkeerd.
urlbar-serial-blocked =
    .tooltiptext = U hebt toegang tot seriële poorten voor deze website geblokkeerd.
urlbar-install-blocked =
    .tooltiptext = U hebt installatie van add-ons voor deze website geblokkeerd.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Deze bladwijzer bewerken ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Bladwijzer voor deze pagina maken ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Gesplitste weergave
    .tooltiptext = Gesplitste weergave

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Plakken & Gaan
    .accesskey = P
urlbar-menuitem-paste-and-search =
    .label = Plakken en zoeken
    .accesskey = P

## Searchbar context menu

clear-search-history =
    .label = Zoekgeschiedenis wissen
    .accesskey = Z

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Extensie beheren…
    .accesskey = E
page-action-remove-extension2 =
    .label = Extensie verwijderen
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = Werkbalken verbergen
    .accesskey = W
full-screen-exit =
    .label = Volledigschermmodus verlaten
    .accesskey = d

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Deze keer zoeken met:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Zoekinstellingen wijzigen
search-one-offs-context-open-new-tab =
    .label = Zoeken in Nieuw tabblad
    .accesskey = t
search-one-offs-context-set-as-default =
    .label = Instellen als standaardzoekmachine
    .accesskey = s
search-one-offs-context-set-as-default-private =
    .label = Als standaardzoekmachine voor privévensters instellen
    .accesskey = p
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Zoekmachine “{ $engineName }” toevoegen
    .label = “{ $engineName }” toevoegen
    .tooltiptext = Zoekmachine “{ $engineName }” toevoegen
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Zoekmachine toevoegen
    .accesskey = Z
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Zoekmachine toevoegen

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Bladwijzers ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Tabbladen ({ $restrict })
search-one-offs-history =
    .tooltiptext = Geschiedenis ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Acties ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Add-ons bekijken
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = extensies, thema’s, add-ons
# Opens preferences page at AI controls
quickactions-manageai = AI-bedieningselementen beheren
quickactions-cmd-manageai = ai uitschakelen, ai uitzetten, ai beheren
# Opens the bookmarks library window
quickactions-bookmarks2 = Bladwijzers beheren
quickactions-cmd-bookmarks = bladwijzers
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Recente geschiedenis wissen
quickactions-cmd-clearrecenthistory2 = cookies, cookies wissen, buffer, buffer wissen, navigatiegegevens, navigatiegegevens wissen, geschiedenis, recente geschiedenis wissen
# Opens about:downloads page
quickactions-downloads2 = Downloads bekijken
quickactions-cmd-downloads = downloads
# Opens about:addons page in the extensions section
quickactions-extensions = Extensies beheren
quickactions-cmd-extensions2 = extensies, add-ons
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name } openen
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = { -firefoxview-brand-name } openen, { -firefoxview-brand-name }, beeld openen, bekijken
# Opens SUMO home page
quickactions-help = Hulp voor { -brand-product-name }
quickactions-cmd-help = hulp, ondersteuning
# Opens the devtools web inspector
quickactions-inspector2 = Ontwikkelaarshulpmiddelen openen
quickactions-cmd-inspector2 = inspector, devtools, ontwikkelaarshulpmiddelen
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Kies een kleur
quickactions-cmd-colorpicker = kleurkiezer, pipet, kleur kiezen
# Opens Firefox Library
quickactions-cmd-library = bibliotheek
quickactions-library = Bibliotheek openen
# Opens about:logins
quickactions-logins2 = Wachtwoorden beheren
quickactions-cmd-logins = aanmeldingen, wachtwoorden
# Mutes all tabs playing audio
quickactions-mute = Tabbladen die audio afspelen dempen
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = dempen, stil, ssssht
# Opens the print dialog
quickactions-print2 = Pagina afdrukken
quickactions-cmd-print = afdrukken
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Pagina opslaan als PDF
quickactions-cmd-savepdf2 = pdf, pagina opslaan
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF-editor openen
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Privévenster openen
quickactions-cmd-private = privénavigatie
# Opens a SUMO article explaining how to refresh
quickactions-refresh = { -brand-short-name } opfrissen
quickactions-cmd-refresh = vernieuwen
# Restarts the browser
quickactions-restart = { -brand-short-name } herstarten
quickactions-cmd-restart = herstarten
# Opens the screenshot tool
quickactions-screenshot3 = Een schermafbeelding maken
quickactions-cmd-screenshot2 = schermafbeelding, een schermafbeelding maken
# Opens about:translations
quickactions-translate = Vertalen
quickactions-cmd-translate = vertalen
# Opens about:preferences
quickactions-settings2 = Instellingen beheren
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = instellingen, voorkeuren, opties, beheren
# Opens about:addons page in the themes section
quickactions-themes = Thema’s beheren
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = thema’s, add-ons
# Opens a SUMO article explaining how to update the browser
quickactions-update = { -brand-short-name } bijwerken
quickactions-cmd-update = bijwerken
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Paginabron bekijken
quickactions-cmd-viewsource2 = bron bekijken, bron, paginabron
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = { -firefoxlabs-brand-name } openen
quickactions-cmd-labs = labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Meer info over Snelle acties
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Druk op Tab om te selecteren:

## Bookmark Panel

bookmarks-add-bookmark = Bladwijzer toevoegen
bookmarks-edit-bookmark = Bladwijzer bewerken
bookmark-panel-cancel =
    .label = Annuleren
    .accesskey = A
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Bladwijzer verwijderen
           *[other] Bladwijzers verwijderen ({ $count })
        }
    .accesskey = v
bookmark-panel-show-editor-checkbox =
    .label = Editor tonen bij opslaan
    .accesskey = E
bookmark-panel-save-button2 =
    .label = Opslaan
    .accesskey = O
bookmark-panel-save-button =
    .label = Opslaan
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Website-informatie voor { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Verbindingsbeveiliging voor { $host }
identity-connection-not-secure = Verbinding niet beveiligd
identity-connection-secure = Verbinding beveiligd
identity-connection-failure = Verbindingsfout
identity-connection-internal = Dit is een beveiligde { -brand-short-name }-pagina.
identity-connection-file = Deze pagina is op uw computer opgeslagen.
identity-connection-associated = Deze pagina is geladen vanuit een andere pagina.
identity-extension-page = Deze pagina is geladen vanuit een extensie.
identity-active-blocked = { -brand-short-name } heeft onderdelen van deze pagina die niet zijn beveiligd geblokkeerd.
identity-custom-root = Verbinding geverifieerd door een certificaatuitgever die niet door Mozilla wordt herkend.
identity-passive-loaded = Onderdelen van deze pagina zijn niet beveiligd (zoals afbeeldingen).
identity-active-loaded = U hebt bescherming op deze pagina uitgeschakeld.
identity-weak-encryption = Deze pagina gebruikt zwakke versleuteling.
identity-https-only-connection-upgraded = (geüpgraded naar HTTPS)
identity-https-only-label2 = Deze website automatisch naar een beveiligde verbinding upgraden
identity-https-only-dropdown-on =
    .label = Aan
identity-https-only-dropdown-off =
    .label = Uit
identity-https-only-dropdown-off-temporarily =
    .label = Tijdelijk uit
identity-https-only-info-turn-on3 = Schakel upgrades naar HTTPS voor deze website in als u wilt dat { -brand-short-name } indien mogelijk de verbinding upgradet.
identity-https-only-info-turn-off3 = Als de website niet lijkt te werken, dan kunt u proberen de HTTPS-upgrade voor deze website uit te schakelen en de pagina te vernieuwen met het onveilige HTTP.
identity-https-only-info-no-upgrade = Kan HTTP-verbinding niet upgraden.
identity-permissions-storage-access-header = Cross-sitecookies
identity-permissions-storage-access-hint = Deze partijen kunnen tijdens uw bezoek aan deze website cross-sitecookies en websitegegevens gebruiken.
identity-permissions-storage-access-learn-more = Meer info
identity-permissions-reload-hint = Mogelijk dient u de pagina te vernieuwen om wijzigingen van kracht te laten worden.
identity-clear-site-data =
    .label = Cookies en websitegegevens wissen…
identity-connection-not-secure-security-view = U hebt een onbeveiligde verbinding met deze website.
identity-connection-verified = U hebt een beveiligde verbinding met deze website.
identity-ev-owner-label2 = Certificaat uitgegeven aan
identity-verifier-label2 = Geverifieerd door
identity-ev-owner-label = Certificaat uitgegeven aan:
identity-verifier-label = Geverifieerd door:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Gekwalificeerd zoals bedoeld in Verordening (EU) 2024/1183.
identity-description-custom-root2 = Mozilla herkent deze certificaatuitgever niet. Hij is mogelijk vanuit uw besturingssysteem of door een beheerder toegevoegd.
identity-cert-exception-overridden = U hebt een beveiligingsuitzondering toegevoegd voor deze website.
identity-remove-cert-exception =
    .label = Uitzondering verwijderen
    .accesskey = w
identity-description-insecure = Uw verbinding met deze website is niet privé. Gegevens die u verzendt zouden door anderen kunnen worden bekeken (zoals wachtwoorden, berichten, creditcardgegevens, etc.).
identity-description-weak-cipher-intro = Uw verbinding met deze website gebruikt zwakke versleuteling en is niet privé.
identity-description-weak-cipher-risk = Andere personen kunnen uw gegevens bekijken of het gedrag van de website aanpassen.
identity-description-active-blocked2 = { -brand-short-name } heeft onderdelen van deze pagina die niet zijn beveiligd geblokkeerd.
identity-description-passive-loaded = Uw verbinding is niet privé en gegevens die u met de website deelt zouden door anderen kunnen worden bekeken.
identity-description-passive-loaded-insecure2 = Deze website bevat inhoud die niet is beveiligd (zoals afbeeldingen).
identity-description-passive-loaded-mixed2 = Hoewel { -brand-short-name } bepaalde inhoud heeft geblokkeerd, is er nog steeds inhoud op de pagina die niet is beveiligd (zoals afbeeldingen).
identity-description-active-loaded = Deze website bevat inhoud die niet is beveiligd (zoals scripts) en uw verbinding ermee is niet privé.
identity-description-active-loaded-insecure = Gegevens die u met deze website deelt, zouden door anderen kunnen worden bekeken (zoals wachtwoorden, berichten, creditcardgegevens, etc.).
identity-description-tls-key-logging-heading = Uw verbinding is mogelijk niet privé
identity-description-tls-key-logging-message = Een app of service kan uw versleutelde verkeer van deze website zien.
identity-more-info-link-text =
    .label = Meer informatie

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimaliseren
browser-window-maximize-button =
    .tooltiptext = Maximaliseren
browser-window-restore-down-button =
    .tooltiptext = Kleiner venster herstellen
browser-window-close-button =
    .tooltiptext = Sluiten
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Terug

## Bookmarks toolbar items

browser-import-button2 =
    .label = Bladwijzers importeren…
    .tooltiptext = Bladwijzers uit een andere browser naar { -brand-short-name } importeren.
bookmarks-toolbar-empty-message = Plaats voor snelle toegang uw bladwijzers hier op de bladwijzerwerkbalk. <a data-l10n-name="manage-bookmarks">Bladwijzers beheren…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Camera:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = Camera
popup-select-microphone-device =
    .value = Microfoon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Microfoon
popup-select-speaker-icon =
    .tooltiptext = Luidsprekers
popup-select-window-or-screen =
    .label = Venster of scherm:
    .accesskey = V
popup-all-windows-shared = Alle zichtbare vensters op uw scherm worden gedeeld.

## WebRTC window or screen share tab switch warning

sharing-warning-window = U deelt { -brand-short-name }. Anderen kunnen zien wanneer u naar een nieuw tabblad wisselt.
sharing-warning-screen = U deelt uw volledige scherm. Anderen kunnen zien wanneer u naar een nieuw tabblad wisselt.
sharing-warning-proceed-to-tab =
    .label = Doorgaan naar tabblad
sharing-warning-disable-for-session =
    .label = Deelbescherming voor deze sessie uitschakelen

## WebSerial "select a port" popup

webserial-select-port-label = Selecteer een seriële poort:
webserial-no-ports-available = Geen seriële poorten beschikbaar

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Sluiten
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Voer zoekterm of adres in
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Voer adres in
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Zoeken met { $name }
    .placeholder = Zoeken op het web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Zoeken op { $name }
    .placeholder = Voer zoektermen in
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Zoeken in bladwijzers
    .placeholder = Voer zoektermen in
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Zoeken in geschiedenis
    .placeholder = Voer zoektermen in
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Zoeken in tabbladen
    .placeholder = Voer zoektermen in
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Acties doorzoeken
    .placeholder = Voer zoektermen in
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Voer zoekterm voor { $name } of adres in
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Browser wordt op afstand beheerd (reden: { $component })
urlbar-permissions-granted =
    .tooltiptext = U hebt deze website aanvullende toestemmingen gegeven.
urlbar-switch-to-tab =
    .value = Wisselen naar tabblad:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Extensie:
urlbar-go-button2 =
    .title = Naar het adres in de locatiebalk gaan
urlbar-page-action-button =
    .tooltiptext = Pagina-acties
urlbar-revert-button =
    .tooltiptext = Adres in de locatiebalk tonen

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Zoeken met { $engine } in een privévenster
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Zoeken in een privévenster
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Zoeken met { $engine }
urlbar-result-action-sponsored = Gesponsord
urlbar-result-action-switch-tab = Wisselen naar tabblad
urlbar-result-action-move-tab-to-split-view = Tabblad naar gesplitste weergave verplaatsen
urlbar-result-action-visit = Bezoeken
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Wisselen naar tabblad · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Naamloze groep
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Bezoeken vanaf klembord
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Druk op Tab om te zoeken met { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Druk op Tab om te zoeken met { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Met { $engine } rechtstreeks vanuit de adresbalk zoeken
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = { $engine } rechtstreeks vanuit de adresbalk doorzoeken
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopiëren
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = ongedefinieerd
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name }-extensie
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Aanbevolen
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> in { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Gesponsord
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Vragen
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Uw laatste bezoek was op { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Uw laatste bezoek was { $daysAgo } dag geleden
       *[other] Uw laatste bezoek was { $daysAgo } dagen geleden
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Uw laatste bezoek was { $weeksAgo } week geleden
       *[other] Uw laatste bezoek was { $weeksAgo } weken geleden
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Uw laatste bezoek was { $monthsAgo } maand geleden
       *[other] Uw laatste bezoek was { $monthsAgo } maanden geleden
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Uw laatste bezoek was op { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Bladwijzer gemaakt op { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Laatst bezocht { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Laatst bezocht { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Laatst bezocht { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Ontvang beursgegevens rechtstreeks in uw zoekbalk
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Toon beursupdates en meer van onze partners wanneer u zoekopdrachtgegevens deelt met { -vendor-short-name }. <a data-l10n-name="learn-more-link">Meer info</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Suggesties tonen
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Niet nu
urlbar-result-realtime-opt-in-dismiss = Sluiten
urlbar-result-realtime-opt-in-dismiss-all2 = Deze suggesties niet tonen
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Geen beurssuggesties tonen
    .accesskey = G
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Geen beurssuggesties tonen
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Deze suggesties niet tonen
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Geen beurssuggesties tonen
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Bedankt voor uw feedback. U ziet geen beurssuggesties meer.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Aandelenmarktsuggesties
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Bedankt voor uw feedback. U ziet deze suggesties niet meer.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · Over { $daysUntilStart } dag
       *[other] { $name } · Over { $daysUntilStart } dagen
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Start over { $daysUntilStart } dag
       *[other] { $name } · Start over { $daysUntilStart } dagen
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Eindigt over { $daysUntilEnd } dag
       *[other] { $name } · Eindigt over { $daysUntilEnd } dagen
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Vandaag
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Eindigt vandaag

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Zoeken met { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } – Zoeken in { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } – Zoeken met { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, kies een zoekmachine
urlbar-searchmode-button-no-engine2 =
    .title = Geen snelkoppeling geselecteerd, kies een snelkoppeling
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Zoeken op trefwoorden is uitgeschakeld
urlbar-searchmode-dropmarker2 =
    .title = Kies een zoekmachine
urlbar-searchmode-bookmarks4 = Bladwijzers
urlbar-searchmode-tabs4 = Tabbladen
urlbar-searchmode-history4 = Geschiedenis
urlbar-searchmode-actions4 = Acties
urlbar-searchmode-bookmarks3 = Bladwijzers
    .accesskey = B
urlbar-searchmode-tabs3 = Tabbladen
    .accesskey = T
urlbar-searchmode-history3 = Geschiedenis
    .accesskey = G
urlbar-searchmode-actions3 = Acties
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Sluiten
urlbar-searchmode-default2 =
    .title = Standaardzoekmachine
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = “{ $engineName }” toevoegen
    .title = Zoekmachine “{ $engineName }” toevoegen
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Deze keer zoeken met:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Zoeken met:
urlbar-searchmode-popup-search-settings2 = Zoekinstellingen
urlbar-searchmode-popup-settings2 = Instellingen
urlbar-searchmode-popup-search-settings = Zoekinstellingen
    .accesskey = Z
urlbar-searchmode-popup-settings = Instellingen
    .accesskey = I

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Bladwijzers doorzoeken
urlbar-result-action-search-history = Geschiedenis doorzoeken
urlbar-result-action-search-tabs = Tabbladen doorzoeken
urlbar-result-action-search-actions = Acties doorzoeken
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Omschakelen naar { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } openen

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Openen in nieuw tabblad
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = Openen in nieuw containertabblad
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = Openen in nieuw venster
    .accesskey = u
urlbar-view-context-menu-open-in-private-window =
    .label = Openen in nieuw privévenster
    .accesskey = v
urlbar-view-context-menu-open-in-tab2 = Openen in nieuw tabblad
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = Openen in nieuw containertabblad
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = Openen in nieuw venster
    .accesskey = u
urlbar-view-context-menu-open-in-private-window2 = Openen in nieuw privévenster
    .accesskey = v
urlbar-view-context-menu-search-in-tab = Zoeken in nieuw tabblad
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = Zoeken in nieuw containertabblad
    .accesskey = c
urlbar-view-context-menu-search-in-window = Zoeken in nieuw venster
    .accesskey = v
urlbar-view-context-menu-search-in-private-window = Zoeken in nieuw privévenster
    .accesskey = p
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Dit menu overslaan bij gebruik van de tab-toets
    .accesskey = o

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine }-suggesties
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Snelle acties
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Recente zoekopdrachten
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Trending op { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Geen trending zoekopdrachten tonen
    .accesskey = G
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Geen trending zoekopdrachten tonen
    .accesskey = G
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Geen trending zoekopdrachten tonen
    .accesskey = G
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Bedankt voor uw feedback. U ziet geen trending zoekopdrachten meer.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Lezerweergave openen
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Lezerweergave sluiten

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Picture-in-picture openen ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Picture-in-picture sluiten ({ $shortcut })
picture-in-picture-panel-header = Picture-in-Picture
picture-in-picture-panel-headline = Deze website raadt Picture-in-Picture niet aan
picture-in-picture-panel-body = Video’s worden mogelijk niet getoond zoals de ontwikkelaar het bedoeld heeft, terwijl Picture-in-Picture is ingeschakeld.
picture-in-picture-enable-toggle =
    .label = Toch inschakelen

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> gebruikt nu het volledige scherm
fullscreen-warning-no-domain = Dit document gebruikt nu het volledige scherm
fullscreen-exit-button = Volledig scherm verlaten (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Volledig scherm verlaten (esc)
fullscreen-keyboardlock-exit-button = Volledig scherm verlaten (Esc ingedrukt houden)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Volledig scherm verlaten (esc ingedrukt houden)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> heeft de controle over uw aanwijzer. Druk op Esc om de controle weer over te nemen.
pointerlock-warning-no-domain = Dit document heeft de controle over uw aanwijzer. Druk op Esc om de controle weer over te nemen.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Bladwijzers beheren
bookmarks-recent-bookmarks-panel-subheader = Recente bladwijzers
bookmarks-toolbar-chevron =
    .tooltiptext = Meer bladwijzers tonen
bookmarks-sidebar-content =
    .aria-label = Bladwijzers
bookmarks-menu-button =
    .label = Bladwijzermenu
bookmarks-other-bookmarks-menu =
    .label = Andere bladwijzers
bookmarks-mobile-bookmarks-menu =
    .label = Mobiel-bladwijzers

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Bladwijzerzijbalk verbergen
           *[other] Bladwijzerzijbalk weergeven
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Bladwijzerwerkbalk verbergen
           *[other] Bladwijzerwerkbalk weergeven
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Bladwijzerwerkbalk verbergen
           *[other] Bladwijzerwerkbalk tonen
        }

##

bookmarks-search =
    .label = Bladwijzers doorzoeken
bookmarks-tools =
    .label = Bladwijzerhulpmiddelen
bookmarks-subview-edit-bookmark =
    .label = Deze bladwijzer bewerken…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Bladwijzers
    .toolbarname = Bladwijzerwerkbalk
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Bladwijzerwerkbalk
bookmarks-toolbar-placeholder =
    .title = Bladwijzerwerkbalkitems
bookmarks-toolbar-placeholder-button =
    .label = Bladwijzerwerkbalkitems
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Bladwijzer voor huidige tabblad maken…

## Library Panel items

library-bookmarks-menu =
    .label = Bladwijzers

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Tekstcodering repareren
    .tooltiptext = De juiste tekstcodering raden vanuit de pagina-inhoud

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Instellingen
    .tooltiptext =
        { PLATFORM() ->
            [macos] Instellingen openen ({ $shortcut })
           *[other] Instellingen openen
        }
toolbar-overflow-customize-button =
    .label = Werkbalk aanpassen…
    .accesskey = a
toolbar-button-email-link =
    .label = Koppeling e-mailen
    .tooltiptext = Een koppeling naar deze pagina e-mailen
toolbar-button-logins =
    .label = Wachtwoorden
    .tooltiptext = Uw opgeslagen wachtwoorden bekijken en beheren
qrcode-panel-error =
    .message = Aanmaken van QR-code is mislukt. Probeer het opnieuw.
qrcode-copy-button =
    .label = Kopiëren
qrcode-copy-success =
    .message = QR-code naar klembord gekopieerd.
qrcode-copy-error =
    .message = Kopiëren van QR-code mislukt.
qrcode-save-button =
    .label = Opslaan
qrcode-window-title = QR-code
qrcode-dialog-title = QR-code
qrcode-image =
    .aria-label = QR-code
qrcode-close-button =
    .aria-label = Sluiten
toolbar-button-save-page =
    .label = Pagina opslaan
    .tooltiptext = Deze pagina opslaan ({ $shortcut })
toolbar-button-open-file =
    .label = Bestand openen
    .tooltiptext = Een bestand openen ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Gesynchroniseerde tabbladen
    .tooltiptext = Tabbladen van andere apparaten tonen
toolbar-button-send-tab =
    .label = Tabblad verzenden
    .tooltiptext = Huidige tabblad naar ander apparaat verzenden
toolbar-button-new-private-window =
    .label = Nieuw privévenster
    .tooltiptext = Een nieuw privénavigatievenster openen ({ $shortcut })
toolbar-button-share-tab =
    .label = Delen
    .tooltiptext = Deze pagina delen
toolbar-button-tab-groups =
    .label = Tabbladgroepen
    .tooltiptext = Uw tabbladgroepen tonen
toolbar-button-history =
    .label = Geschiedenis
    .tooltiptext = Uw geschiedenis tonen ({ $shortcut })
toolbar-button-find =
    .label = Zoeken
    .tooltiptext = Zoeken op deze pagina ({ $shortcut })
toolbar-button-developer =
    .label = Ontwikkelaar
    .tooltiptext = Hulpmiddelen voor webontwikkelaars openen ({ $shortcut })
toolbar-button-forget =
    .label = Vergeten
    .tooltiptext = Bepaalde navigatiegeschiedenis vergeten
toolbar-zoom-controls =
    .label = Zoombediening
    .title = Zoombediening
toolbar-button-zoom-out =
    .label = Uitzoomen
    .tooltiptext = Uitzoomen ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Zoomniveau terugzetten ({ $shortcut })
toolbar-button-zoom-in =
    .label = Inzoomen
    .tooltiptext = Inzoomen ({ $shortcut })
toolbar-edit-controls =
    .label = Bedieningselementen voor bewerken
    .title = Bedieningselementen voor bewerken
toolbar-button-cut =
    .label = Knippen
    .tooltiptext = Knippen ({ $shortcut })
toolbar-button-copy =
    .label = Kopiëren
    .tooltiptext = Kopiëren ({ $shortcut })
toolbar-button-paste =
    .label = Plakken
    .tooltiptext = Plakken ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Sommige audio- of videobestanden op deze pagina gebruiken DRM-software die { -brand-short-name } kan beperken in wat u ermee wilt doen.
eme-notifications-drm-content-playing-manage = Instellingen beheren
eme-notifications-drm-content-playing-manage-accesskey = b
eme-notifications-drm-content-playing-dismiss = Sluiten
eme-notifications-drm-content-playing-dismiss-accesskey = S

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = U moet DRM inschakelen om bepaalde audio of video op deze pagina af te spelen.
eme-notifications-drm-content-disabled-button =
    .label = DRM inschakelen
    .accesskey = D
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } installeert onderdelen die nodig zijn voor het afspelen van de audio of video op deze pagina. Probeer het later opnieuw.
decoder-doctor-no-codecs-linux-message = Om video af te spelen, dient u mogelijk de vereiste videocodecs te installeren.
decoder-doctor-no-hw-acceleration-message = Om de videokwaliteit te verbeteren, dient u mogelijk Microsofts Media Feature Pack te installeren.
decoder-doctor-no-pulse-audio-message = Om audio af te spelen, dient u mogelijk de vereiste PulseAudio-software te installeren.
decoder-doctor-unsupported-libavcodec-message = libavcodec kan kwetsbaar zijn of wordt niet ondersteund, en dient te worden bijgewerkt om video af te spelen.
decoder-doctor-decode-error-message = Er is een fout opgetreden tijdens het decoderen van een mediabron.
decoder-doctor-decode-warning-message = Er is een herstelbare fout opgetreden tijdens het decoderen van een mediabron.
decoder-doctor-learn-how-link = Meer info
decoder-doctor-report-issue-button =
    .label = Websiteprobleem melden
    .accesskey = W
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = De { $pluginName }-plug-in is gecrasht.
plugin-crashed-notification-reload-button =
    .label = Pagina vernieuwen
    .accesskey = n
plugin-crashed-notification-submit-button =
    .label = Een crashrapport verzenden
    .accesskey = c

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Misleidende website!
safebrowsing-reported-attack-site-message = Gerapporteerde aanvalswebsite!
safebrowsing-reported-unwanted-site-message = Gerapporteerde website met ongewenste software!
safebrowsing-reported-harmful-site-message = Gerapporteerde schadelijke website!
safebrowsing-get-me-out-of-here-button =
    .label = Haal me hier vandaan!
    .accesskey = H
safebrowsing-not-a-deceptive-site-button =
    .label = Dit is geen misleidende website…
    .accesskey = m
safebrowsing-not-an-attack-site-button =
    .label = Dit is geen aanvalswebsite…
    .accesskey = a

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = U moet zich aanmelden bij dit netwerk voordat u toegang hebt tot het internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Aanmeldingspagina voor netwerk openen

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Wilde u naar { $hostName } gaan?
keyword-uri-fixup-go-to-button =
    .label = Ja, ik wil naar { $hostName }
    .accesskey = J

## Password save/update panel

panel-save-update-username-2 =
    .label = Gebruikersnaam
panel-save-update-password-2 =
    .label = Wachtwoord

##

# "More" item in macOS share menu
menu-share-more =
    .label = Meer…
menu-share-windows =
    .label = Meer opties
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Koppeling kopiëren
           *[other] { $count } koppelingen kopiëren
        }
    .accesskey = p
ui-tour-info-panel-close =
    .tooltiptext = Sluiten

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Pop-ups en omleidingen van derden toestaan voor { $uriHost }
    .accesskey = P

##

picture-in-picture-hide-toggle =
    .label = Picture-in-picture-knop verbergen
    .accesskey = v

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Picture-in-picture-schakelaar naar de rechterzijde verplaatsen
    .accesskey = z
picture-in-picture-move-toggle-left =
    .label = Picture-in-picture-schakelaar naar de linkerzijde verplaatsen
    .accesskey = j

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigatie
navbar-downloads =
    .label = Downloads
navbar-overflow-2 =
    .tooltiptext = Meer hulpmiddelen
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Afdrukken
    .tooltiptext = Deze pagina afdrukken… ({ $shortcut })
navbar-home =
    .label = Startpagina
    .tooltiptext = { -brand-short-name }-startpagina
navbar-library =
    .label = Bibliotheek
    .tooltiptext = Geschiedenis, opgeslagen bladwijzers en meer bekijken
navbar-search =
    .title = Zoeken
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Browsertabbladen
tabs-toolbar-new-tab =
    .label = Nieuw tabblad
tabs-toolbar-list-all-tabs-2 =
    .label = Tabbladen zoeken en beheren
    .tooltiptext = Tabbladen zoeken en beheren
tabs-toolbar-list-all-tabs =
    .label = Alle tabbladtitels tonen
    .tooltiptext = Alle tabbladtitels tonen

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Sleep het tabblad hierheen om het vast te zetten

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Eerdere tabbladen openen?</strong> U kunt uw vorige sessie herstellen vanuit het toepassingsmenu van { -brand-short-name } <img data-l10n-name="icon"/>, onder Geschiedenis.
restore-session-startup-suggestion-button = Tonen hoe

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Uw organisatie heeft toegang tot lokale bestanden op deze computer geblokkeerd

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } doorzoekt nu tabbladen
urlbar-addons-shortcut-moved-description = Gebruik { $addonsShortcut } om extensies en thema’s te openen.
urlbar-addons-shortcut-moved-change-shortcuts = Sneltoetsen beheren
urlbar-addons-shortcut-moved-dismiss = Begrepen

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } verzendt automatisch een aantal gegevens naar { -vendor-short-name }, zodat we uw ervaring kunnen verbeteren.
data-reporting-notification-button =
    .label = Kiezen wat ik deel
    .accesskey = K
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Privénavigatie
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Privénavigatie
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Privénavigatie-info
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = U bevindt zich in een privévenster
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Dit helpt uw navigatie op dit apparaat voor anderen verborgen te houden, maar maakt u online niet onzichtbaar. <a data-l10n-name="learn-more">Wie kan mijn activiteit zien?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Voorkomen van gegevensverlies (Data Loss Prevention – DLP) door { $agentName }. Klik voor meer info.
content-analysis-panel-title2 = Voorkomen van gegevensverlies
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Uw organisatie gebruikt <b>{ $agentName }</b> om te beheren hoe gevoelige gegevens mogen worden gedeeld. <a data-l10n-name="info">Meer info</a>
content-analysis-panel-title = Gegevensbescherming
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Uw organisatie gebruikt <b>{ $agentName }</b> om u te beschermen tegen gegevensverlies. <a data-l10n-name="info">Meer info</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Extensies
    .tooltiptext = Extensies

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Extensies
    .tooltiptext =
        Extensies
        Machtigingen benodigd

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Extensies
    .tooltiptext =
        Extensies
        Sommige extensies zijn niet toegestaan

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Extensies
    .tooltiptext =
        Extensies
        Sommige extensies zijn uitgeschakeld

## Private browsing reset button

reset-pbm-panel-heading2 = Gegevens wissen en een nieuwe privésessie starten?
reset-pbm-panel-description3 = Dit wist uw geschiedenis en cookies, en meldt u af bij websites. Uw privévensters worden gesloten en er wordt een nieuw venster geopend.
reset-pbm-panel-description2 = Hierdoor worden geschiedenis, cookies en alle overige websitegegevens verwijderd zonder uw privévenster te sluiten.
reset-pbm-panel-always-ask-checkbox =
    .label = Mij altijd vragen
    .accesskey = M
reset-pbm-panel-cancel-button =
    .label = Annuleren
    .accesskey = A
reset-pbm-panel-confirm-button2 =
    .label = Privésessie wissen
    .accesskey = w
reset-pbm-panel-complete = Privésessiegegevens verwijderd
reset-pbm-toolbar-button2 =
    .label = Privésessie wissen
    .tooltiptext = Privésessie wissen

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Alle navigatiegegevens verwijderen?
fire-button-panel-description = Hiermee worden geschiedenis, cookies en websitegegevens verwijderd. U wordt bij websites afgemeld. Dit venster wordt gesloten en { -brand-short-name } zal een nieuw venster openen.
fire-button-panel-choose-description = Als u niet alles wilt verwijderen, kies dan specifieke gegevens.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Kiezen…
fire-button-panel-cancel-button =
    .label = Annuleren
    .accesskey = A
fire-button-panel-confirm-button =
    .label = Alles verwijderen
    .accesskey = A
fire-button-panel-complete = Navigatiegegevens verwijderd
fire-button-toolbar-button2 =
    .label = Sommige of alle gegevens verwijderen
    .tooltiptext = Een deel van of al uw navigatiegegevens verwijderen

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } heeft voorkomen dat deze pagina automatisch werd herladen.
refresh-blocked-redirect-label = { -brand-short-name } heeft voorkomen dat deze pagina automatisch werd doorgestuurd naar een andere pagina.
refresh-blocked-allow =
    .label = Toestaan
    .accesskey = T

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Onze veilige, gebruiksvriendelijke maskers beschermen uw identiteit en voorkomen spam door uw e-mailadres te verbergen.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Alle e-mailberichten die naar uw e-mailmaskers worden verzonden, worden doorgestuurd naar <strong>{ $useremail }</strong> (tenzij u besluit ze te blokkeren).
firefox-relay-offer-legal-notice = Door op ‘E-mailmasker gebruiken’ te klikken, gaat u akkoord met de <label data-l10n-name="tos-url">Servicevoorwaarden</label> en <label data-l10n-name="privacy-url">Privacyverklaring</label>.
firefox-relay-offer-legal-notice-1 = Door te registreren en een e-mailmasker aan te maken, gaat u akkoord met de <label data-l10n-name="tos-url">Servicevoorwaarden</label> en <label data-l10n-name="privacy-url">Privacyverklaring</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Niet geverifieerd)
popup-notification-xpinstall-prompt-learn-more = Meer info over het veilig installeren van add-ons
popup-notification-xpinstall-prompt-block-url = Details bekijken
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Toestaan dat extensie in privévensters wordt uitgevoerd
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Technische en interactiegegevens delen met extensieontwikkelaar
    .accesskey = d

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } heeft voorkomen dat deze website een pop-upvenster opende.
       *[other] { -brand-short-name } heeft voorkomen dat deze website { $popupCount } pop-upvensters opende.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } heeft voorkomen dat deze website doorstuurde.
        [1] { -brand-short-name } heeft voorkomen dat deze website een pop-upvenster opende en doorstuurde.
        [one] { -brand-short-name } heeft voorkomen dat deze website een pop-upvenster opende en doorstuurde.
       *[other] { -brand-short-name } heeft voorkomen dat deze website { $popupCount } pop-upvensters opende en doorstuurde.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } heeft voorkomen dat deze website meer dan { $popupCount } pop-upvensters opende.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } heeft voorkomen dat deze website meer dan { $popupCount } pop-upvenster opende en doorstuurde.
       *[other] { -brand-short-name } heeft voorkomen dat deze website meer dan { $popupCount } pop-upvensters opende en doorstuurde.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Opties
           *[other] Voorkeuren
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] V
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = “{ $popupURI }” tonen
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = ‘{ $redirectURI }’ tonen

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Het Windows-bestandsdialoogvenster kon niet worden geopend. Er is geen bestand of map geselecteerd.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Het Windows-bestandsdialoogvenster kon niet worden geopend. Het bestand wordt opgeslagen in { $path }.
file-picker-failed-save-nowhere = Het Windows-bestandsdialoogvenster kon niet worden geopend. Er is geen standaardmap gevonden; het bestand zal niet worden opgeslagen.
file-picker-crashed-open = Het Windows-bestandsdialoogvenster is gecrasht. Er is geen bestand of map geselecteerd.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Het Windows-bestandsdialoogvenster is gecrasht. Het bestand wordt opgeslagen in { $path }.
file-picker-crashed-save-nowhere = Het Windows-bestandsdialoogvenster is gecrasht. Er is geen standaardmap gevonden; het bestand zal niet worden opgeslagen.
file-picker-crashed-show-in-folder =
    .label = In map tonen
    .accessKey = m

## Unsigned add-ons notification

unsigned-addons-disabled-message = Een of meer geïnstalleerde add-ons kunnen niet worden geverifieerd en zijn uitgeschakeld.
unsigned-addons-disabled-learn-more =
    .label = Meer info
    .accesskey = M

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Deze pagina vertraagt { -brand-short-name }. Stop deze pagina om uw browser te versnellen.
process-hang-nonspecific-tab-message = Een webpagina vertraagt { -brand-short-name }. Stop die pagina om uw browser te versnellen.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = ‘{ $title }’ vertraagt { -brand-short-name }. Stop die pagina om uw browser te versnellen.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = ‘{ $addonName }’ vertraagt { -brand-short-name }. Stop die extensie om uw browser te versnellen.
process-hang-addon-learn-more =
    .value = Meer info
process-hang-stop-button =
    .label = Stoppen
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Instellen voltooien
onboarding-aw-finish-setup-button =
    .label = Instellen voltooien
    .tooltiptext = Instellen { -brand-short-name } voltooien

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Verbeterde bescherming tegen volgen is ingeschakeld
trustpanel-etp-label-disabled = Verbeterde bescherming tegen volgen is uitgeschakeld
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Verbeterde bescherming tegen volgen: aan voor { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Verbeterde bescherming tegen volgen: uit voor { $host }
trustpanel-etp-description-enabled = Als iets op deze website niet werkt, probeer dan beschermingen uit te schakelen.
trustpanel-etp-description-disabled = { -brand-product-name } vindt dat bedrijven u minder moeten volgen. Als u bescherming inschakelt, blokkeren we zoveel mogelijk trackers.
trustpanel-trackercount-label = Aantal geblokkeerde trackers tonen in adresbalk
trustpanel-trackercount-toggle =
    .aria-label = Aantal geblokkeerde trackers tonen in adresbalk
trustpanel-connection-label-secure = Verbinding beveiligd
trustpanel-connection-label-insecure = Verbinding niet beveiligd
trustpanel-header-enabled = { -brand-product-name } staat op wacht
trustpanel-description-enabled2 = U bent beschermd. Als we iets ontdekken, laten we u dat weten.
trustpanel-header-enabled-insecure = Wees voorzichtig op deze website
trustpanel-description-enabled-insecure = { -brand-product-name } heeft iets verdachts opgemerkt.
trustpanel-header-disabled = U hebt beschermingen uitgeschakeld
trustpanel-description-disabled = { -brand-product-name } staat niet op wacht. We raden u aan beschermingen weer in te schakelen.
trustpanel-clear-cookies-button = Cookies en websitegegevens wissen
trustpanel-privacy-link = Privacyinstellingen
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Cookies en websitegegevens wissen voor { $host }
trustpanel-clear-cookies-description = Het verwijderen van cookies en websitegegevens kan u bij websites afmelden en winkelwagentjes leegmaken.
trustpanel-clear-cookies-subview-button-clear = Wissen
trustpanel-clear-cookies-subview-button-cancel = Annuleren
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Verbindingsbescherming voor { $host }
trustpanel-siteinformation-morelink = Meer website-informatie
trustpanel-blocker-see-all = Alles bekijken
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Bescherming tegen volgen voor { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Niet beveiligd
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } tracker geblokkeerd
       *[other] { $count } trackers geblokkeerd
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } vindt dat bedrijven u minder moeten volgen. Dus blokkeren we er zoveel als we kunnen.
trustpanel-blocked-header = { -brand-product-name } heeft het volgende voor u geblokkeerd:
trustpanel-tracking-header = { -brand-product-name } staat het volgende toe, zodat websites blijven werken:
trustpanel-tracking-description = Zonder trackers werken sommige knoppen, formulieren en aanmeldvelden mogelijk niet.
trustpanel-insecure-section-header = Uw verbinding is niet beveiligd
trustpanel-insecure-description = De gegevens die u naar deze website verzendt, zijn niet versleuteld. Ze kunnen worden bekeken, gestolen of gewijzigd.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } cross-site-trackingcookie
       *[other] { $count } cross-site-trackingcookies
    }
trustpanel-list-label-tracking-content = Volginhoud
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } fingerprinter
       *[other] { $count } fingerprinters
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } sociale-mediatracker
       *[other] { $count } sociale-mediatrackers
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } cryptominer
       *[other] { $count } cryptominers
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } sociale-mediatracker geblokkeerd
       *[other] { -brand-product-name } heeft { $count } sociale-mediatrackers geblokkeerd
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } sociale-mediatracker toegestaan
       *[other] { -brand-product-name } heeft { $count } sociale-mediatrackers toegestaan
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } cross-site-trackingcookie geblokkeerd
       *[other] { -brand-product-name } heeft { $count } cross-site-trackingcookies geblokkeerd
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } cross-site-trackingcookie toegestaan
       *[other] { -brand-product-name } heeft { $count } cross-site-trackingcookies toegestaan
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } tracker geblokkeerd
       *[other] { -brand-product-name } heeft { $count } trackers geblokkeerd
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } tracker toegestaan
       *[other] { -brand-product-name } heeft { $count } trackers toegestaan
    }
trustpanel-tracking-content-tab-list-header = Deze websites proberen u te volgen:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } fingerprinter geblokkeerd
       *[other] { -brand-product-name } heeft { $count } fingerprinters geblokkeerd
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } fingerprinter toegestaan
       *[other] { -brand-product-name } heeft { $count } fingerprinters toegestaan
    }
trustpanel-fingerprinter-list-header = Deze websites proberen een vingerafdruk van u te maken:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } cryptominer geblokkeerd
       *[other] { -brand-product-name } heeft { $count } cryptominers geblokkeerd
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } heeft { $count } cryptominer toegestaan
       *[other] { -brand-product-name } heeft { $count } cryptominers toegestaan
    }
trustpanel-cryptominer-tab-list-header = Deze websites proberen te cryptominen:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Hebt u een account op deze website?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } heeft vastgesteld dat deze website in de afgelopen 12 maanden door een datalek is getroffen. Ontdek of u getroffen bent.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Sluiten
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Gratis scan starten
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> tracker geblokkeerd op deze website
       *[other] <span data-l10n-name="count">{ $count }</span> trackers geblokkeerd op deze website
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Ziet de website er niet goed uit?</strong> Vernieuw de pagina om tijdelijk uw bescherming tegen volgen te verlagen.
reduced-protection-infobar-reload-button = Vernieuwen
    .accesskey = V
reduced-protection-infobar-never-show-button = Niet meer tonen
    .accesskey = N


identity-allow-site-data = Altijd cookies/gegevens van deze site opslaan
urlbar-webgl-notification-anchor =
    .tooltiptext = WebGL-contexten aanmaken beheren
urlbar-webgl-blocked =
    .tooltiptext = Je hebt het aanmaken van WebGL-contexten op deze website geblokkeerd.
