# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Websites vertellen mijn gegevens niet te verkopen of te delen
    .accesskey = s
non-technical-privacy-group =
    .label = Websiteprivacyvoorkeuren
do-not-track-removal3 =
    .message = We ondersteunen de functie ‘Niet volgen’ niet meer.
non-technical-privacy-heading =
    .label = Aanvullende beschermingen
preferences-privacy-relay-available =
    .description = Verbergt uw echte e-mailadres om uw Postvak IN te beschermen tegen spam.
    .label = { -relay-brand-name }-e-mailmaskers voorstellen
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Instellingen
category-nav-heading =
    .heading = Instellingen
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Zoeken in Instellingen
    .style = width: 15.4em
managed-notice = Uw browser wordt door uw organisatie beheerd.
managed-notice-info-icon =
    .alt = Informatie
managed-notice-nav =
    .label = Uw browser wordt door uw organisatie beheerd.
tls-key-logging-notice-nav =
    .label = Een app of service kan uw versleutelde verkeer zien.
category-list =
    .aria-label = Categorieën
pane-general-title = Algemeen
pane-home-title = Startpagina
pane-home-startup-title2 = Startpagina en opstarten
    .title = Startpagina en opstarten
pane-search-title2 = Zoeken
    .title = Zoeken
pane-privacy-title3 = Privacy en Beveiliging
    .title = Privacy en Beveiliging
pane-privacy-section =
    .heading = Privacy en Beveiliging
pane-sync-title3 = Synchronisatie
pane-ai-controls-title2 = AI-bedieningselementen
    .title = AI-bedieningselementen
pane-about-firefox-title = Over { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Vormgeving
    .title = { pane-appearance-title }
pane-downloads-title2 = Downloads
    .title = Downloads
pane-downloads3 =
    .heading = Downloads
pane-accessibility-title = Toegankelijkheid
    .title = { pane-accessibility-title }
pane-languages-title2 = Talen
    .title = Talen
preferences-languages-header3 =
    .heading = Talen
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Probeer onze experimentele functies! Ze zijn in ontwikkeling en in de groei, wat van invloed kan zijn op de manier waarop { -brand-short-name } werkt. We ontvangen alleen gegevens over uw gebruik van deze functies als u <a data-l10n-name="data-collection">technische en interactiegegevens</a> hebt ingeschakeld.
pane-experimental-reset =
    .label = Standaardwaarden herstellen
    .accesskey = h
help-button-label2 = { -brand-short-name } Support
    .title = { -brand-short-name } Support
addons-button-label2 = Extensies & Thema’s
    .title = Extensies & Thema’s
focus-search =
    .key = f
close-button =
    .aria-label = Sluiten
do-not-track-removal2 =
    .label = We ondersteunen het ‘Niet volgen’-signaal niet meer
applications-setting-new-file-types =
    .label = Wat moet { -brand-short-name } met andere bestanden doen?

## Browser Restart Dialog

feature-enable-requires-restart = U moet { -brand-short-name } herstarten om deze functie in te schakelen.
feature-disable-requires-restart = U moet { -brand-short-name } herstarten om deze functie uit te schakelen.
should-restart-title = { -brand-short-name } herstarten
should-restart-ok = { -brand-short-name } nu herstarten
cancel-no-restart-button = Annuleren
restart-later = Later herstarten

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> beheert deze instelling.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> beheert deze instelling.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> vereist containertabbladen.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> beheert deze instelling.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name="icon"/> <strong>{ $name }</strong> beheert hoe { -brand-short-name } verbinding maakt met het internet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Ga naar <img data-l10n-name="addons-icon"/> Add-ons in het menu <img data-l10n-name="menu-icon"/> om de extensie in te schakelen.
extension-controlled-enable-2 = Bezoek <a data-l10n-name="addons-link">Extensies en thema’s</a> om deze extensie weer in te schakelen.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } beheert een aantal instellingen van uw startpagina.

## Preferences UI Search Results

search-results-header = Zoekresultaten
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Sorry! Er zijn geen resultaten in Instellingen voor ‘<span data-l10n-name="query"></span>’.
search-results-help-link = Hulp nodig? Bezoek <a data-l10n-name="url">{ -brand-short-name } Support</a>

## General Section

always-check-default =
    .label = Altijd controleren of { -brand-short-name } uw standaardbrowser is
    .accesskey = c
startup-restore-windows-and-tabs =
    .label = Eerdere vensters en tabbladen openen
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = Schakel deze voorkeur in door ‘{ profile-manager-use-selected.label }’ in het venster ‘Gebruikersprofiel kiezen’ aan te vinken.
windows-launch-on-login =
    .label = { -brand-short-name } automatisch openen bij het opstarten van uw computer
    .accesskey = a
windows-launch-on-login-disabled = Deze voorkeur is uitgeschakeld in Windows. Ga naar <a data-l10n-name="startup-link">Apps > Opstarten</a> in Systeeminstellingen om dit te wijzigen.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Ook een nieuw tabblad openen
    .accesskey = w
disable-extension =
    .label = Extensie uitschakelen
preferences-data-migration-group =
    .description = Importeer uw bladwijzers, wachtwoorden, geschiedenis, extensies en gegevens voor automatisch invullen vanuit een andere browser.
    .label = Browsergegevens importeren
preferences-data-migration-button =
    .label = Gegevens importeren
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profielen
preferences-profiles-subpane-description =
    .description = Elk profiel heeft aparte navigatiegegevens en -instellingen, waaronder geschiedenis, wachtwoorden en meer.
preferences-profiles-section-header =
    .description = Elk profiel heeft aparte navigatiegegevens en -instellingen, waaronder geschiedenis, wachtwoorden en meer.
    .label = Profielen
preferences-manage-profiles-button =
    .label = Profielen beheren
preferences-profiles-settings-button =
    .label = Instellingen
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Het nieuwe profiel kopieert uw instellingen, add-ons, geschiedenis en opgeslagen gegevens zoals bladwijzers en wachtwoorden – maar niet uw account- of synchronisatiegegevens.
    .label = Een bestaand profiel kopiëren
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Te kopiëren profiel
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Profiel selecteren
preferences-copy-profile-button = Kopiëren
tabs-browsing-section =
    .heading = Tabbladen en navigeren
pane-tabs-browsing-title2 = Tabbladen en navigeren
    .title = Tabbladen en navigeren
tabs-group-header2 =
    .label = Tabbladen
tabs-opening-heading =
    .label = Openen
tabs-interaction-heading =
    .label = Interactie
tabs-containers-heading =
    .label = Containers
tabs-closing-heading =
    .label = Sluiten
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab doorloopt tabbladen in onlangs gebruikte volgorde
    .accesskey = T
open-new-link-as-tabs =
    .label = Koppelingen openen in tabbladen in plaats van nieuwe vensters
    .accesskey = v
open-external-link-next-to-active-tab =
    .label = Koppelingen van apps openen naast uw actieve tabblad
ask-on-close-multiple-tabs =
    .label = Vragen voor het sluiten van meerdere tabbladen
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Vragen voor afsluiten met { $quitKey }
    .accesskey = v
warn-on-open-many-tabs =
    .label = Waarschuwen als het openen van meerdere tabbladen { -brand-short-name } zou kunnen vertragen
    .accesskey = o
switch-to-new-tabs-2 =
    .label = Als een koppeling of media in een nieuw tabblad wordt geopend, er meteen naartoe gaan
    .accesskey = k
show-tabs-in-taskbar =
    .label = Tabbladvoorbeelden in de Windows-taakbalk tonen
    .accesskey = k
browser-containers-enabled-2 =
    .label = Containertabbladen gebruiken
    .accesskey = n
browser-containers-learn-more = Meer info
browser-containers-settings-2 =
    .label = Instellingen beheren
    .accesskey = i
containers-disable-alert-title = Alle containertabbladen sluiten?
startup-group =
    .label = Opstarten

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Als u nu containertabbladen uitschakelt, zal { $tabCount } containertabblad worden gesloten. Weet u zeker dat u containertabbladen wilt uitschakelen?
       *[other] Als u nu containertabbladen uitschakelt, zullen { $tabCount } containertabbladen worden gesloten. Weet u zeker dat u containertabbladen wilt uitschakelen?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] { $tabCount } containertabblad sluiten
       *[other] { $tabCount } containertabbladen sluiten
    }

##

containers-disable-alert-cancel-button = Ingeschakeld houden
containers-remove-alert-title = Deze container verwijderen?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Als u deze container nu verwijdert, zal { $count } containertabblad worden gesloten. Weet u zeker dat u deze container wilt verwijderen?
       *[other] Als u deze container nu verwijdert, zullen { $count } containertabbladen worden gesloten. Weet u zeker dat u deze container wilt verwijderen?
    }
containers-remove-ok-button = Deze container verwijderen
containers-remove-cancel-button = Deze container niet verwijderen
settings-tabs-show-image-in-preview =
    .label = Een afbeeldingsvoorbeeld tonen als u een tabblad aanwijst
    .accessKey = w
settings-tabs-drag-to-create-tab-groups =
    .label = Tabbladen naar elkaar verslepen om tabbladgroepen te maken
browser-layout-header2 =
    .label = Browserindeling
browser-layout-horizontal-tabs2 =
    .description = Tabbladen bovenaan
    .label = Horizontale tabbladen
    .title = Tabbladen bovenaan
browser-layout-vertical-tabs2 =
    .description = Tabbladen aan zijkant, in de zijbalk
    .label = Verticale tabbladen
    .title = Tabbladen aan zijkant, in de zijbalk
browser-layout-show-sidebar2 =
    .description = Benader snel bladwijzers, tabbladen van uw telefoon, AI-chatbots en meer zonder uw hoofdvenster te verlaten.
    .label = Zijbalk tonen
page-navigation-group =
    .label = Paginanavigatie

## General Section - Language & Appearance

language-and-appearance-header = Taal en Vormgeving
appearance-group2 =
    .description = Sommige websites wijzigen hun kleuren om zich aan uw voorkeuren aan te passen. Kies uw kleurenschema.
    .label = Uiterlijk van de website
preferences-web-appearance-choice-auto3 =
    .label = Systeem
    .title = Automatisch website-achtergronden en inhoud wijzigen op basis van uw systeeminstellingen en { -brand-short-name }-thema.
preferences-web-appearance-choice-light2 =
    .label = Licht
    .title = Een lichte uitstraling voor website-achtergronden en -inhoud gebruiken.
preferences-web-appearance-choice-dark2 =
    .label = Donker
    .title = Een donkere uitstraling voor website-achtergronden en -inhoud gebruiken.
web-appearance-group =
    .aria-label = Uiterlijk van de website
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Uw instellingen voor contrastregeling hebben voorrang op het uiterlijk van de website.
preferences-web-appearance-link =
    .label = U kunt { -brand-short-name }-thema’s beheren in Extensies en thema’s
preferences-contrast-control-group =
    .description = Websites gebruiken een keur aan voorgrond- en achtergrondkleuren. Voor consistent contrast kunt u dezelfde kleuren op verschillende websites gebruiken.
    .label = Websitecontrast
preferences-contrast-control-radio-group =
    .label = Kleuren overschrijven
preferences-contrast-control-use-platform-settings =
    .label = Automatisch (systeeminstellingen gebruiken)
    .accesskey = A
preferences-contrast-control-off =
    .label = Uit
    .accesskey = U
preferences-contrast-control-custom =
    .label = Aangepast
    .accesskey = g
preferences-colors-manage-button2 =
    .label = Kleuren beheren
    .accesskey = K
preferences-colors-manage-button =
    .label = Kleuren beheren…
    .accesskey = K
preferences-fonts-header2 =
    .label = Lettertypen
preferences-default-zoom-label =
    .label = Standaard zoom
    .accesskey = z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Alleen tekst inzoomen
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Als ‘Alleen tekst zoomen’ is ingeschakeld en uw standaardzoom is niet 100%, geven sommige websites inhoud mogelijk niet correct weer.
language-header = Taal
choose-language-description = Talen van uw voorkeur kiezen voor het weergeven van webpagina’s
website-language-heading =
    .description = Sommige webpagina’s worden getoond in meerdere talen. Kies talen in de volgorde van uw voorkeur.
    .label = Websitetaal
website-preferred-language =
    .label = Voorkeurstalen
website-language-list =
    .aria-label = Voorkeurstalen
website-add-language =
    .label = Taal toevoegen
website-add-language-button =
    .aria-label = Geselecteerde taal toevoegen
    .title = Geselecteerde taal toevoegen
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = { $locale } verwijderen
    .title = { $locale } verwijderen
choose-button =
    .label = Kiezen…
    .accesskey = z
choose-browser-language-description = Kies de talen die worden gebruikt voor het weergeven van menu’s, berichten en notificaties van { -brand-short-name }.
manage-browser-languages-button =
    .label = Alternatieven instellen…
    .accesskey = l
confirm-browser-language-change-description = Herstart { -brand-short-name } om deze wijzigingen toe te passen
confirm-browser-language-change-button = Toepassen en herstarten
browser-language-heading =
    .description = Kies de taal die wordt gebruikt om menu’s, berichten en notificaties van { -brand-short-name } te tonen.
    .label = Browsertaal
browser-language-preferred-label =
    .label = Voorkeurstaal
browser-language-fallback-label =
    .description = Gebruikt wanneer de vertaling naar de voorkeurstaal onvolledig is.
    .label = Reservetaal
browser-language-install-error =
    .message = { -brand-short-name } kan uw talen momenteel niet bijwerken. Controleer of u met het internet bent verbonden of probeer het opnieuw.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Uitzonderingen…
    .accesskey = z
settings-translations-header =
    .aria-label = Vertalingen
    .description = Vertaal pagina’s of geselecteerde tekst. Om uw privacy te beschermen, blijven vertalingen op uw apparaat.
    .label = Vertalingen
settings-translations-offer-to-translate-label =
    .label = Volledige paginavertaling aanbieden
settings-translations-more-settings-button =
    .description = Voorkeuren voor talen, websites en offlinevertaling instellen.
    .label = Meer vertaalinstellingen
settings-translations-subpage-header =
    .heading = Meer vertaalinstellingen
settings-translations-subpage-speed-up-translation-header =
    .description = Download volledige talen voor snellere vertalingen en om offline te vertalen.
    .label = Vertaling versnellen
settings-translations-subpage-automatic-translation-header =
    .label = Automatische vertaling
settings-translations-subpage-always-translate-header =
    .label = Deze talen altijd vertalen
settings-translations-subpage-never-translate-header =
    .label = Deze talen nooit vertalen
settings-translations-subpage-never-translate-sites-header =
    .label = Deze websites nooit vertalen
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Open om een website toe te voegen het <img data-l10n-name="translations-icon"/> vertaalpaneel, selecteer <img data-l10n-name="settings-icon"/> vertaalinstellingen en kies ‘Deze website nooit vertalen’
settings-translations-subpage-language-select-option =
    .label = Taal toevoegen
settings-translations-subpage-language-add-button =
    .aria-label = Taal toevoegen
    .title = Taal toevoegen
settings-translations-subpage-download-languages-header =
    .label = Talen downloaden
settings-translations-subpage-download-languages-select-option =
    .label = Taal selecteren
settings-translations-subpage-download-languages-button =
    .aria-label = Taal downloaden
    .title = Taal downloaden
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Geen talen gedownload
settings-translations-subpage-no-languages-added =
    .label = Geen talen toegevoegd
settings-translations-subpage-download-progress = Download bezig…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Kan { $language } niet downloaden ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Opnieuw proberen
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = { $language } ({ $size } MB) verwijderen?
settings-translations-subpage-download-delete-button =
    .label = Verwijderen
settings-translations-subpage-download-cancel-button =
    .label = Annuleren
settings-translations-subpage-no-sites-added =
    .label = Geen websites toegevoegd
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = De instellingen voor ‘{ $localeName }’ van uw besturingssysteem gebruiken om data, tijden, getallen en metingen op te maken.
settings-spellcheck-header =
    .label = Spellingscontrole
check-user-spelling =
    .label = Uw spelling controleren tijdens het typen
    .accesskey = s
spellcheck-download-dictionaries =
    .label = Woordenboeken downloaden
spellcheck-promo =
    .heading = Spellingscontrole gebruiken
    .message = Klik met uw rechtermuisknop op een tekstveld om spellingscontrole in of uit te schakelen of om de taal te wijzigen. Niet alle velden ondersteunen spellingscontrole.

## Downloads - Files and applications

files-and-applications-title = Bestanden en Toepassingen
download-save-files-header =
    .label = Bestanden opslaan in
download-save-where-3 =
    .aria-label = Bestanden opslaan in
download-always-ask-where2 =
    .label = Vragen waar bestanden moeten worden opgeslagen voor het downloaden
    .accesskey = V
download-private-browsing-delete2 =
    .label = Downloads vanuit privévensters bij sluiten verwijderen
    .accesskey = D
applications-header = Toepassingen
applications-description = Kies hoe { -brand-short-name } omgaat met de bestanden die u van het web downloadt of de toepassingen die u tijdens het surfen gebruikt.
applications-setting2 =
    .description = Kies hoe { -brand-short-name } omgaat met gedownloade bestanden en inhoud.
    .label = Bestanden en toepassingen
applications-filter =
    .placeholder = Bestandstypen of toepassingen zoeken
applications-type-column =
    .label = Inhoudstype
    .accesskey = t
applications-type-heading = Inhoudstype
applications-action-column =
    .label = Actie
    .accesskey = A
applications-action-heading = Actie
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension }-bestand
applications-action-save =
    .label = Bestand opslaan
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = { $app-name } gebruiken
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = { $app-name } gebruiken (standaard)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Standaardtoepassing in macOS gebruiken
            [windows] Standaardtoepassing in Windows gebruiken
           *[other] Standaard systeemtoepassing gebruiken
        }
applications-use-other =
    .label = Andere gebruiken…
applications-select-helper = Hulptoepassing selecteren
applications-manage-app =
    .label = Toepassingsdetails…
applications-always-ask =
    .label = Altijd vragen
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Openen in { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Wat moet { -brand-short-name } met andere bestanden doen?
applications-save-for-new-types =
    .label = Bestanden opslaan
    .accesskey = o
applications-save-for-new-types2 =
    .label = Bestanden automatisch opslaan
    .accesskey = p
applications-ask-before-handling =
    .label = Vragen of bestanden geopend of opgeslagen moeten worden
    .accesskey = V
applications-ask-before-handling2 =
    .label = Vragen om bestanden te openen of op te slaan
    .accesskey = V
drm-group =
    .label = Digital Rights Management (DRM)-inhoud
play-drm-content =
    .label = DRM-beheerde inhoud afspelen
    .accesskey = D
play-drm-content-learn-more = Meer info
# Variables:
# $version (string) - Firefox version
update-application-version = Versie { $version } <a data-l10n-name="learn-more">Wat is er nieuw</a>
update-history-2 =
    .label = Updategeschiedenis tonen
    .accesskey = d
update-application-installation =
    .label = Installatie
update-application-radio-group =
    .aria-label = Installatie
update-application-auto-2 =
    .label = Updates automatisch installeren (aanbevolen)
    .accesskey = U
update-application-check-choose-2 =
    .label = Controleren op updates, maar kiezen wanneer u wilt installeren
    .accesskey = C
update-application-background-enabled =
    .label = Als { -brand-short-name } niet wordt uitgevoerd
    .accesskey = A
update-application-warning-cross-user-setting-2 =
    .message = Deze instelling is van toepassing op alle Windows-accounts en { -brand-short-name }-profielen die deze installatie van { -brand-short-name } gebruiken.
update-application-suppress-prompts-2 =
    .label = Minder updateherinneringen tonen
    .accesskey = n
update-setting-write-failure-title2 = Fout bij opslaan update-instellingen
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } heeft een fout aangetroffen en heeft deze wijziging niet opgeslagen. Merk op dat voor het instellen van deze update-instelling schrijfrechten voor onderstaand bestand benodigd zijn. U of uw systeembeheerder kan deze fout oplossen door de groep Gebruikers volledige toegang tot dit bestand te geven.
    
    Kon niet schrijven naar bestand: { $path }
update-in-progress-title = Update wordt uitgevoerd
update-in-progress-message = Wilt u dat { -brand-short-name } doorgaat met deze update?
update-in-progress-ok-button = &Verwerpen
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Doorgaan

## About Firefox

about-firefox-header =
    .heading = Over { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Updates verbeteren de snelheid, stabiliteit en beveiliging van { -brand-short-name }.
    .label = { -brand-short-name }-updates
update-application-suppress-prompts-heading =
    .label = Notificaties
update-application-updates-managed-by-os =
    .message = Updates worden door uw besturingssysteem beheerd

## Firefox support

support-application-heading =
    .description = Problemen oplossen of ideeën delen met de gemeenschap.
    .label = { -brand-short-name }-ondersteuning
support-get-help =
    .label = Hulp verkrijgen
support-share-ideas =
    .label = Ideeën en feedback delen

## Firefox newsletter

newsletter-settings-heading =
    .description = Ontvang handleidingen, advies en nieuws om uw { -brand-product-name }-ervaring te optimaliseren.
    .label = { -brand-product-name }-nieuwsbrief
newsletter-sign-up-link =
    .label = Registreren

## General Section - Performance

performance-settings-learn-more = Meer info
performance-allow-hw-accel =
    .label = Hardwareversnelling gebruiken wanneer beschikbaar
    .accesskey = v
performance-limit-content-process-option = Limiet van inhoudsprocessen
    .accesskey = L
performance-limit-content-process-enabled-desc = Extra inhoudsprocessen kunnen de prestaties bij het gebruik van meerdere tabbladen verbeteren, maar zullen ook meer geheugen gebruiken.
performance-limit-content-process-blocked-desc = Aanpassen van het aantal inhoudsprocessen is alleen mogelijk met multiprocess-{ -brand-short-name }. <a data-l10n-name="learn-more">Informatie over het controleren of multiprocess is ingeschakeld</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (standaard)
performance-group =
    .label = Prestaties
performance-use-recommended-settings-checkbox-2 =
    .description = Deze instellingen zijn aangepast voor uw hardware en besturingssysteem.
    .label = Aanbevolen prestatie-instellingen gebruiken
    .accesskey = A

## Accessibility page

browsing-use-autoscroll =
    .label = Automatisch scrollen gebruiken
    .accesskey = m
keyboard-and-scrolling-group =
    .label = Toetsenbordnavigatie en scrollen
motion-and-link-group =
    .label = Bewegings- en koppelingsstijl
browsing-use-smooth-scrolling =
    .label = Vloeiend scrollen gebruiken
    .accesskey = e
browsing-gtk-use-non-overlay-scrollbars =
    .label = Schuifbalken altijd tonen
    .accesskey = o
browsing-always-underline-links =
    .label = Koppelingen altijd onderstrepen
    .accesskey = s
browsing-use-onscreen-keyboard =
    .label = Een schermtoetsenbord tonen wanneer nodig
    .accesskey = c
browsing-use-cursor-navigation =
    .label = Altijd de pijltoetsen gebruiken om binnen pagina’s te navigeren
    .accesskey = o
browsing-use-full-keyboard-navigation =
    .label = Gebruik de tab-toets om de focus te verplaatsen tussen formulierbesturingselementen en koppelingen
    .accesskey = t
browsing-search-on-start-typing =
    .label = Naar tekst zoeken wanneer u begint met typen
    .accesskey = t
settings-keyboard-shortcuts-group =
    .description = Bepaal hoe u beweegt en interactie hebt met { -brand-short-name }.
    .label = Sneltoetsen
settings-keyboard-shortcuts-customkeys-link =
    .label = Sneltoetsen aanpassen
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Adresbalkinstellingen in Zoeken aanpassen
settings-media-group =
    .label = Media
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Picture-in-picture gebruiken
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Video’s in Picture-in-picture blijven afspelen bij het wisselen van tabbladen
    .accesskey = w
browsing-media-control =
    .label = Beheer media via toetsenbord, headset of virtuele interface
    .accesskey = v
recommendations-group =
    .label = Aanbevelingen
browsing-cfr-recommendations =
    .label = Extensies aanbevelen terwijl u surft
    .accesskey = a
browsing-cfr-features =
    .label = Functies aanbevelen terwijl u surft
    .accesskey = F
browsing-group =
    .label = Navigeren
preferences-accessibility-header =
    .heading = Toegankelijkheid
preferences-default-zoom-select =
    .aria-label = Standaard zoom
preferences-fonts-family =
    .label = Lettertypefamilie
    .accesskey = f
preferences-fonts-size =
    .label = Lettergrootte
    .accesskey = g
preferences-fonts-advanced-settings =
    .label = Geavanceerde instellingen
    .accesskey = a

## General Section - Proxy

network-proxy-group2 =
    .description = Configureren hoe { -brand-short-name } verbindt met het internet.
    .label = Proxyinstellingen
network-proxy-connection-settings2 =
    .description = Wijzigen van deze instellingen kan verbindingsproblemen veroorzaken
    .label = Proxy configureren
    .accesskey = P

## Home Section

home-new-windows-tabs-header = Nieuwe vensters en tabbladen
home-new-windows-tabs-description2 = Kies wat u ziet bij het openen van uw startpagina, nieuwe vensters, en nieuwe tabbladen.
home-section =
    .heading = Startpagina en opstarten

## Home Section - Default Browser

home-default-browser-title =
    .label = Standaardbrowser
is-default-browser-2 =
    .message = { -brand-short-name } is uw standaardbrowser. Goede keuze.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } is niet uw standaardbrowser.
set-as-my-default-browser-2 =
    .label = Standaard maken
    .accesskey = m

## Custom Homepage subpage

home-homepage-mode-label = Startpagina en nieuwe vensters
home-newtabs-mode-label = Nieuwe tabbladen
home-restore-defaults =
    .label = Standaardwaarden herstellen
    .accesskey = S
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (standaard)
home-mode-choice-custom =
    .label = Aangepaste URL’s…
home-mode-choice-blank =
    .label = Lege pagina
home-homepage-custom-url =
    .placeholder = Plak een URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Extensie beheren
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Huidige pagina gebruiken
           *[other] Huidige pagina’s gebruiken
        }
    .accesskey = u
choose-bookmark =
    .label = Bladwijzer gebruiken…
    .accesskey = B
home-homepage-title =
    .label = Startpagina
home-homepage-new-windows =
    .label = Nieuwe vensters
home-homepage-new-tabs =
    .label = Nieuwe tabbladen
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Kies een specifieke website
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Websiteadres(sen)
home-custom-homepage-list =
    .aria-label = Websiteadressen
home-custom-homepage-address =
    .placeholder = Voer adres in
home-custom-homepage-address-button =
    .label = Adres toevoegen
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Nog geen websites toegevoegd.
home-custom-homepage-delete-address-button =
    .aria-label = Adres verwijderen
    .title = Adres verwijderen
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Vervangen door
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Huidige geopende pagina’s
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Bladwijzers…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Extensie ({ $extension })
home-custom-homepage-header = Aangepaste startpagina
home-custom-homepage-subpage =
    .heading = Aangepaste startpagina

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name }-inhoud
home-prefs-content-description2 = Kies welke inhoud u op uw { -firefox-home-brand-name }-scherm wilt laten weergeven.
home-prefs-search-header =
    .label = Zoeken op het web
home-prefs-shortcuts-header =
    .label = Snelkoppelingen
home-prefs-shortcuts-description = Opgeslagen of bezochte websites
home-prefs-shortcuts-by-option-sponsored =
    .label = Gesponsorde snelkoppelingen
home-prefs-recommended-by-header-generic =
    .label = Aanbevolen verhalen
home-prefs-recommended-by-description-generic = Uitzonderlijke inhoud, verzameld door de { -brand-product-name }-familie
home-prefs-stories-header =
    .label = Verhalen
home-prefs-stories-description = Gepersonaliseerde verhalen op basis van uw activiteit

##

home-prefs-recommended-by-learn-more = Hoe het werkt
home-prefs-recommended-by-option-sponsored-stories =
    .label = Gesponsorde verhalen
home-prefs-highlights-option-visited-pages =
    .label = Bezochte pagina’s
home-prefs-highlights-options-bookmarks =
    .label = Bladwijzers
home-prefs-highlights-option-most-recent-download =
    .label = Meest recent gedownload
home-prefs-recent-activity-header =
    .label = Recente activiteit
home-prefs-recent-activity-description = Een selectie van recente websites en inhoud
home-prefs-weather-header =
    .label = Weer
home-prefs-weather-description = De weersverwachting van vandaag in een oogopslag
home-prefs-weather-learn-more-link = Meer info
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = { -brand-product-name } ondersteunen
home-prefs-mission-message = Onze sponsors steunen onze missie om een beter web te bouwen
home-prefs-mission-message-learn-more-link = Lees hier hoe
home-prefs-manage-topics-link = Onderwerpen beheren
home-prefs-choose-wallpaper-link = Kies een achtergrond
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } rij
           *[other] { $num } rijen
        }

## Search Section

search-show-suggestions-option =
    .label = Zoeksuggesties tonen
    .accesskey = Z
search-show-suggestions-url-bar-option =
    .label = Zoeksuggesties in adresbalkresultaten tonen
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Zoeksuggesties boven browsergeschiedenis tonen in adresbalkresultaten
search-show-suggestions-private-windows-2 =
    .label = Zoeksuggesties in privévensters
search-suggestions-cant-show-2 =
    .message = Zoeksuggesties worden niet in locatiebalkresultaten getoond, omdat u { -brand-short-name } hebt geconfigureerd om nooit geschiedenis te onthouden.
addressbar-header-1 =
    .description = Kies welke suggesties in uw adresbalk worden getoond
    .label = Adresbalk
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Suggesties van { -brand-short-name } en onze partners in uw adresbalk.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Zoektermen in de adresbalk op resultaatpagina’s tonen
search-separate-default-engine-2 =
    .label = Een andere standaardzoekmachine gebruiken in privévensters
    .accesskey = g
search-separate-default-engine-dropdown =
    .aria-label = Standaardzoekmachine in privévensters
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Adresbalknavigatie
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Het resultatenmenu overslaan bij gebruik van de tab-toets om de focus te verplaatsen
search-suggestions-header-2 =
    .label = Zoekmachinesuggesties
search-one-click-header2 = Zoeksnelkoppelingen
search-one-click-desc = Kies de alternatieve zoekmachines die onder de adresbalk en zoekbalk verschijnen als u een sleutelwoord begint in te voeren.
search-one-click-header-3 =
    .description = Kies welke zoekmachines en snelkoppelingen in uw adresbalk verschijnen.
    .label = Extra zoekmachines
search-engine-list =
    .aria-label = Zoekmachines en snelkoppelingen
update-search-engine-success =
    .message = Zoekmachine met succes bijgewerkt
search-edit-engine-2 =
    .title = Zoekmachine bewerken
search-delete-engine =
    .title = Zoekmachine verwijderen
search-enable-engine =
    .title = Zoekmachine inschakelen
search-outlink-to-extensions-page =
    .title = In extensies en thema’s beheren
search-choose-engine-column =
    .label = Zoekmachine
search-choose-keyword-column =
    .label = Sleutelwoord
search-restore-default =
    .label = Standaardzoekmachines terugzetten
    .accesskey = S
search-remove-engine =
    .label = Verwijderen
    .accesskey = V
search-add-engine =
    .label = Toevoegen
    .accesskey = T
search-add-engine-2 =
    .label = Zoekmachine toevoegen
    .accesskey = t
search-edit-engine =
    .label = Bewerken
    .accesskey = w
search-find-more-link = Meer zoekmachines zoeken
search-filtering-for-add-engine = Zoekmachine toevoegen
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Dubbel sleutelwoord
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = U hebt een sleutelwoord gekozen dat momenteel wordt gebruikt door ‘{ $name }’. Kies een ander.
search-keyword-warning-bookmark = U hebt een sleutelwoord gekozen dat momenteel wordt gebruikt door een bladwijzer. Kies een ander.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Er is al een zoekmachine met de naam ‘{ $name }’. Kies een andere naam.
remove-engine-confirmation = Weet u zeker dat u deze zoekmachine wilt verwijderen?
remove-engine-remove = Verwijderen
remove-addon-engine-alert = Verwijder de geassocieerde add-on om deze zoekmachine te verwijderen.
search-engine-group =
    .label = Standaardzoekmachine
search-default-engine =
    .aria-label = Standaardzoekmachine
# Header for the search section ("search" is a noun).
search-section =
    .heading = Zoeken

## Containers Section

containers-section-header2 =
    .heading = Containerinstellingen
containers-card-header2 =
    .description = Cookies per container scheiden, zodat u verschillende accounts op dezelfde website kunt gebruiken en cross-sitetracking kunt beperken.
    .label = Containers
containers-add-button2 =
    .label = Nieuwe container toevoegen
    .accesskey = v
containers-list =
    .aria-label = Containers
containers-new-tab-check3 =
    .label = Selecteer een container voor elk nieuw tabblad
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Gebruik geen containers voor koppelingen die vanuit externe apps worden geopend
    .accesskey = G
containers-new-tab-check2 =
    .description = Dit opent het containermenu telkens als u op de knop om een nieuw tabblad te openen drukt.
    .label = Selecteer een container voor elk nieuw tabblad
    .accesskey = S
containers-settings-button2 =
    .title = Instellingen
containers-remove-button3 =
    .title = Verwijderen
containers-sites-card-header =
    .description = Kies een container voor een website en { -brand-short-name } zal deze elke keer gebruiken als de website wordt geopend.
    .label = Website-specifieke containers
containers-sites-add-button =
    .label = Website toevoegen
    .accesskey = W
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Container voor { $site }
containers-site-remove-button =
    .title = Verwijderen
containers-remove-button2 =
    .title = Verwijderen

## Account and sync

sync-group-label =
    .label = Synchronisatie
account-group-label2 =
    .label = Account
account-disabled-group =
    .description = Accountinstellingen zijn niet beschikbaar.
    .label = Account
account-placeholder2 =
    .description = Meld u aan en houd uw gegevens privé, versleuteld en direct toegankelijk, overal waar u { -brand-short-name } gebruikt.
    .label = U bent niet aangemeld
account-sync-section =
    .heading = Account en synchronisatie
pane-account-sync-title2 = Account en synchronisatie
    .title = Account en synchronisatie

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Neem uw web mee
sync-signedout-description2 = Synchroniseer uw bladwijzers, geschiedenis, tabbladen, wachtwoorden, add-ons en instellingen op al uw apparaten.
sync-signedout-account-signin3 =
    .label = Aanmelden om te synchroniseren…
    .accesskey = a
sync-signedout-account-signin-4 =
    .label = Meld u aan bij uw account om te beginnen met synchroniseren
    .accesskey = a
sync-signedout-account-short =
    .label = Aanmelden
    .accesskey = m
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Download Firefox voor <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> of <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> om met uw mobiele apparaat te synchroniseren.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Profielafbeelding wijzigen
    .tooltiptext = Profielafbeelding wijzigen
sync-profile-picture-account-problem =
    .alt = Accountprofielafbeelding
fxa-login-rejected-warning =
    .alt = Waarschuwing
sync-sign-out =
    .label = Afmelden…
    .accesskey = f
sync-sign-out2 =
    .label = Afmelden
    .accesskey = f
sync-manage-account = Account beheren
    .accesskey = b
sync-manage-account2 =
    .label = Account beheren
    .accesskey = b

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } is niet geverifieerd.
sync-signedin-unverified2 =
    .description = Controleer uw Postvak IN om uw account te bevestigen en officieel te maken.
    .label = { $email } is nog niet bevestigd
sync-signedin-login-failure = Meld u aan om { $email } opnieuw te verbinden
sync-signedin-login-failure2 =
    .description = Meld u weer aan om opnieuw te verbinden en te beginnen met synchroniseren van uw gegevens.
    .label = U bent afgemeld bij { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Account verifiëren
    .accesskey = v
sync-remove-account =
    .label = Account verwijderen
    .accesskey = r
sync-sign-in =
    .label = Aanmelden
    .accesskey = m

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synchroniseren: AAN
prefs-syncing-on-2 =
    .label = Synchroniseren is AAN
prefs-syncing-off = Synchroniseren: UIT
prefs-syncing-off-2 =
    .description = Schakel synchronisatie in om op elk apparaat uw bladwijzers, wachtwoorden, geschiedenis en meer te ontvangen.
    .label = Synchroniseren is UIT
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Schakel synchronisatie in om uw bladwijzers, wachtwoorden, geschiedenis en meer op dit apparaat te ontvangen.
    .label = Synchroniseren is UIT
prefs-sync-turn-on-syncing =
    .label = Synchronisatie inschakelen…
    .accesskey = S
prefs-sync-turn-on-syncing-2 =
    .label = Synchronisatie inschakelen
    .accesskey = S
prefs-sync-offer-setup-label2 = Synchroniseer uw bladwijzers, geschiedenis, tabbladen, wachtwoorden, add-ons en instellingen op al uw apparaten.
prefs-sync-now-button =
    .label = Nu synchroniseren
    .accesskey = N
prefs-sync-now-button-2 =
    .label = Nu synchroniseren
    .accesskey = N
prefs-syncing-button =
    .label = Synchroniseren…
prefs-syncing-button-2 =
    .label = Synchroniseren…
    .title = Nu synchroniseren
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Uw synchronisatiekeuzes zijn nu alleen op dit apparaat van toepassing.

## The list of things currently syncing.

sync-syncing-across-devices-heading = U synchroniseert deze items tussen al uw verbonden apparaten:
sync-syncing-across-devices-heading-2 = Gegevens tussen apparaten gesynchroniseerd
sync-syncing-across-devices-heading-3 = Gegevens die op dit apparaat worden gesynchroniseerd
sync-syncing-across-devices-empty-state2 =
    .description = U synchroniseert niets… nog niet. Begin met synchroniseren om al uw gegevens op al uw apparaten te ontvangen.
    .label = Gesynchroniseerde gegevens beheren
sync-syncing-across-devices-empty-state3 =
    .description = U synchroniseert niets… nog niet. Kies wat u op dit apparaat wilt synchroniseren.
    .label = Gesynchroniseerde gegevens beheren
sync-currently-syncing-bookmarks = Bladwijzers
sync-currently-syncing-history = Geschiedenis
sync-currently-syncing-tabs = Open tabbladen
sync-currently-syncing-passwords = Wachtwoorden
sync-currently-syncing-addresses = Adressen
sync-currently-syncing-payment-methods = Betalingsmethoden
sync-currently-syncing-addons = Add-ons
sync-currently-syncing-settings = Instellingen
sync-manage-options =
    .label = Synchronisatie beheren…
    .accesskey = b
sync-manage-options-2 =
    .label = Gesynchroniseerde gegevens beheren
    .accesskey = b
settings-sync-disconnect-button =
    .label = Verbreken

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Bladwijzers
    .accesskey = B
sync-engine-history =
    .label = Geschiedenis
    .accesskey = G
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Open tabbladen
    .tooltiptext = Open tabbladen van uw andere apparaten
    .accesskey = t
sync-engine-tabs =
    .label = Open tabbladen
    .tooltiptext = Een lijst van wat op alle gesynchroniseerde apparaten is geopend
    .accesskey = t
sync-engine-passwords =
    .label = Wachtwoorden
    .tooltiptext = Door u opgeslagen wachtwoorden
    .accesskey = W
sync-engine-addresses2 =
    .label = Adressen
    .tooltiptext = Adressen die u in de { -brand-short-name } hebt opgeslagen
    .accesskey = e
sync-engine-payment-methods3 =
    .label = Betalingsmethoden
    .tooltiptext = Uw opgeslagen betalingsmethoden
    .accesskey = n
sync-engine-addons2 =
    .label = Add-ons
    .tooltiptext = Extensies en thema’s die u aan { -brand-short-name } voor desktop hebt toegevoegd
    .accesskey = A
sync-engine-settings2 =
    .label = Instellingen
    .tooltiptext = { -brand-short-name }-instellingen waar van toepassing
    .accesskey = I
sync-engine-addresses =
    .label = Adressen
    .tooltiptext = Postadressen die u hebt opgeslagen (alleen desktop)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = Betalingsmethoden
    .tooltiptext = Namen, kaartnummers en vervaldata
    .accesskey = n
sync-engine-addons =
    .label = Add-ons
    .tooltiptext = Extensies en thema’s voor Firefox op desktops
    .accesskey = A
sync-engine-settings =
    .label = Instellingen
    .tooltiptext = Door u gewijzigde algemene, privacy- en beveiligingsinstellingen
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Opslaan
    .buttonlabelextra2 = Verbinding verbreken…
    .buttonaccesskeyaccept = s
    .buttonaccesskeyextra2 = v
    .style = min-width: 36em;
    .title = Beheren wat wordt gesynchroniseerd op al uw verbonden apparaten
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Opslaan
    .buttonlabelextra2 = Verbinding verbreken…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Beheren wat op dit apparaat wordt gesynchroniseerd

## The device name controls.

sync-device-name-header = Apparaatnaam
sync-device-name-header-2 =
    .label = Apparaatnaam
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Apparaatnaam
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Apparaatnaam wijzigen
    .accesskey = w
sync-device-name-change =
    .label = Apparaatnaam wijzigen…
    .accesskey = w
sync-device-name-cancel =
    .label = Annuleren
    .accesskey = A
sync-device-name-save =
    .label = Opslaan
    .accesskey = s
sync-connect-another-device = Een ander apparaat verbinden
sync-connect-another-device-2 =
    .label = Een ander apparaat verbinden

## Privacy Section

privacy-header = Browserprivacy

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Wachtwoorden
    .searchkeywords = aanmeldingen
forms-passwords-header =
    .aria-label = Wachtwoorden
    .label = Wachtwoorden
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Vragen om wachtwoorden op te slaan
    .accesskey = V
forms-manage-password-exceptions =
    .label = Wachtwoorduitzonderingen beheren
    .accesskey = b
forms-exceptions =
    .label = Uitzonderingen…
    .accesskey = t
forms-suggest-passwords =
    .label = Sterke wachtwoorden voorstellen
    .accesskey = S
forms-breach-alerts =
    .label = Waarschuwingen over wachtwoorden voor getroffen websites tonen
    .accesskey = f
forms-breach-alerts-learn-more-link = Meer info
preferences-relay-integration-checkbox2 =
    .label = { -relay-brand-name }-e-mailmaskers voorstellen om uw e-mailadres te beschermen
    .accesskey = r
relay-integration-learn-more-link = Meer info
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Gebruikersnamen en wachtwoorden automatisch invullen
    .accesskey = v
forms-fill-usernames-and-passwords-2 =
    .label = Gebruikersnamen en wachtwoorden opslaan en automatisch invullen
    .accesskey = v
forms-saved-passwords =
    .label = Opgeslagen wachtwoorden
    .accesskey = d
forms-saved-passwords-2 =
    .label = Opgeslagen wachtwoorden beheren
    .accesskey = g
forms-saved-passwords-searchkeywords = Aanmeldingen voor de volgende websites zijn op uw computer opgeslagen
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Aanvullende beschermingen
forms-primary-pw-use =
    .label = Een hoofdwachtwoord gebruiken
    .accesskey = h
forms-primary-pw-use-2 =
    .description = Voegt een extra beveiligingslaag toe om uw opgeslagen wachtwoorden te beschermen.
    .label = Een hoofdwachtwoord gebruiken
    .accesskey = g
forms-primary-pw-set =
    .label = Hoofdwachtwoord instellen
forms-primary-pw-on-2 = Hoofdwachtwoord is <strong>AAN</strong>
forms-primary-pw-on =
    .label = Hoofdwachtwoord is AAN
forms-primary-pw-change-2 =
    .label = Hoofdwachtwoord wijzigen
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Uitschakelen
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Apparaataanmelding voor invullen en beheren van wachtwoorden vereisen
forms-os-reauth-2 =
    .label = Apparaataanmelding voor beheren van wachtwoorden vereisen
forms-primary-pw-learn-more-link = Meer info
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Hoofdwachtwoord wijzigen…
    .accesskey = z
forms-primary-pw-change =
    .label = Hoofdwachtwoord wijzigen…
    .accesskey = H
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = U bent momenteel in FIPS-modus. FIPS vereist een ingesteld hoofdwachtwoord.
forms-master-pw-fips-desc = Wachtwoordwijziging mislukt
forms-windows-sso =
    .label = Windows-single-sign-on toestaan voor Microsoft-, werk- en schoolaccounts
forms-windows-sso-learn-more-link = Meer info
forms-windows-sso-desc = Accounts beheren in uw apparaatinstellingen
windows-passkey-settings-label = Wachtwoordsleutels beheren in systeeminstellingen
privacy-panel-settings-header =
    .description = Ontvang hulp om uw online gegevens te beschermen in { -brand-short-name }.
    .label = Instellingen privacypaneel
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Berichten over datalekken tonen
    .accesskey = d

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Voer uw aanmeldgegevens voor Windows in om een hoofdwachtwoord in te stellen. Hierdoor wordt de beveiliging van uw accounts beschermd.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = een hoofdwachtwoord aanmaken
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] instellingen voor betalingsmethoden wijzigen
       *[other] { -brand-short-name } probeert de instellingen voor betalingsmethoden te wijzigen. Gebruik uw apparaataanmelding om dit toe te staan.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Betalingsmethoden
autofill-payment-methods-checkbox-message-2 =
    .label = Betalingsgegevens opslaan en automatisch invullen
    .accesskey = B
autofill-payment-methods-manage-payments-title =
    .heading = Betalingsmethoden beheren
autofill-payment-methods-manage-payments-button =
    .label = Betalingsmethoden beheren
    .accesskey = b
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Apparaataanmelding voor automatisch invullen vereisen
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Apparaataanmelding voor automatisch invullen en beheren van betalingsmethoden vereisen
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Beveiligingscodes opslaan
    .accesskey = c
autofill-payment-methods-add-button = Nieuwe betalingsmethode toevoegen
payments-list-header =
    .label = Betalingsmethoden
payments-delete-payment-prompt-title = Deze betalingsmethode verwijderen?
payments-delete-payment-prompt-confirm-button = Verwijderen
payments-delete-payment-prompt-cancel-button = Annuleren
payments-delete-payment-button-label =
    .aria-label = Verwijderen
payments-edit-payment-button-label =
    .aria-label = Bewerken
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Geen betalingsmethoden toegevoegd
autofill-addresses-checkbox-message =
    .label = Adressen opslaan en automatisch invullen
    .accesskey = o
autofill-addresses-manage-addresses-button =
    .label = Adressen en meer beheren
    .accesskey = b
addresses-list-header =
    .label = Adressen
addreses-delete-address-button-label =
    .aria-label = Verwijderen
addreses-edit-address-button-label =
    .aria-label = Bewerken
addresses-delete-address-prompt-title = Dit adres verwijderen?
addresses-delete-address-prompt-confirm-button = Verwijderen
addresses-delete-address-prompt-cancel-button = Annuleren
autofill-addresses-add-button = Nieuw adres toevoegen
autofill-addresses-manage-addresses-title =
    .heading = Adressen en meer beheren
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Geen adressen toegevoegd
personal-info-group =
    .label = Persoonlijke gegevens
autofill-personal-info-checkbox-message =
    .label = Persoonlijke gegevens opslaan en automatisch invullen
autofill-personal-info-manage-button =
    .label = Persoonlijke gegevens beheren
passports-list-header =
    .label = Paspoorten
passports-delete-passport-button-label =
    .aria-label = Verwijderen
passports-edit-passport-button-label =
    .aria-label = Bewerken
passports-delete-passport-prompt-title = Dit paspoort verwijderen?
passports-delete-passport-prompt-confirm-button = Verwijderen
passports-delete-passport-prompt-cancel-button = Annuleren
autofill-passports-add-button = Nieuw paspoort toevoegen
autofill-personal-info-manage-title =
    .heading = Persoonlijke gegevens beheren
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Geen paspoorten toegevoegd
pane-passwords-autofill-title2 = Wachtwoorden en automatisch invullen
    .title = Wachtwoorden en automatisch invullen
preferences-passwords-autofill-header =
    .heading = Wachtwoorden en automatisch invullen
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adressen en meer
payments-group =
    .label = Betalingsmethoden

## Privacy Section - History

history-remember-option-never2 =
    .description = Elk venster wordt beschouwd als een privévenster. Indien ingeschakeld, dienen extensies te worden toegestaan.
    .label = Nooit geschiedenis onthouden
history-remember-option-custom2 =
    .label = Geschiedenis aanpassen
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } zal uw browser-, download-, formulier- en zoekgeschiedenis onthouden.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } zal dezelfde instellingen gebruiken als bij Privénavigatie, en geen geschiedenis onthouden terwijl u over het web surft.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } gebruikt aangepaste instellingen voor uw browser-, download-, formulier- en zoekgeschiedenis.
history-private-browsing-permanent =
    .label = Altijd de privénavigatiemodus gebruiken
    .accesskey = m
history-remember-browser-option =
    .label = Navigatie- en downloadgeschiedenis onthouden
    .accesskey = v
history-remember-search-option =
    .label = Zoek- en formuliergeschiedenis onthouden
    .accesskey = f
history-clear-on-close-option =
    .label = Geschiedenis wissen zodra { -brand-short-name } sluit
    .accesskey = w
history-clear-on-close-settings =
    .label = Instellingen…
    .accesskey = s
history-shutdown-exceptions =
    .label = Uitzonderingen beheren
    .accesskey = z
history-clear-button =
    .label = Geschiedenis wissen…
    .accesskey = G
history-header2 =
    .heading = Geschiedenis
history-section-header =
    .description = Kies wat u { -brand-short-name } wilt laten onthouden als u de browser afsluit.
    .label = Geschiedenis
history-custom-section-header =
    .description = Pas aan wat u { -brand-short-name } wilt laten onthouden als u de browser afsluit.
    .label = Geavanceerde instellingen
history-custom-button =
    .label = Kies wat u wilt dat { -brand-short-name } onthoudt
history-group =
    .label = Geschiedenis
history-mode-radio-group =
    .aria-label = Geschiedenis
history-remember-option-all2 =
    .label = Geschiedenis onthouden

## Privacy Section - Site Data

sitedata-total-size-calculating = Grootte van websitegegevens en buffer berekenen…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Websites gebruiken momenteel <strong>{ $value } { $unit }</strong> aan schijfruimte.
sitedata-learn-more = Meer info
sitedata-delete-on-close2 =
    .label = Cookies en websitegegevens wissen telkens wanneer u { -brand-short-name } afsluit
    .accesskey = C
sitedata-delete-on-close-private-browsing3 =
    .message = Op basis van uw geschiedenisinstellingen verwijdert { -brand-short-name } cookies en websitegegevens uit uw sessie wanneer u de browser sluit.
sitedata-delete-on-close-private-browsing4 =
    .heading = Geschiedenis wordt niet opgeslagen.
    .message = { -brand-short-name } wist cookies en websitegegevens van uw sessie als u de browser afsluit.
sitedata-option-block-cross-site-trackers =
    .label = Cross-site-trackers
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cross-site-trackingcookies
sitedata-option-block-cross-site-cookies2 =
    .label = Cross-sitecookies isoleren
sitedata-option-block-unvisited =
    .label = Cookies van niet-bezochte websites
sitedata-option-block-all-cross-site-cookies =
    .label = Alle cross-sitecookies (kan ervoor zorgen dat websites niet goed werken)
sitedata-option-block-all =
    .label = Alle cookies (zal ervoor zorgen dat websites niet goed werken)
sitedata-clear2 =
    .label = Navigatiegegevens wissen
    .accesskey = w
sitedata-settings2 =
    .label = Navigatiegegevens beheren
    .accesskey = b
sitedata-cookies-exceptions =
    .label = Uitzonderingen beheren…
    .accesskey = z
sitedata-cookies-exceptions2 =
    .description = U kunt opgeven welke websites altijd of nooit cookies en websitegegevens mogen gebruiken.
    .label = Uitzonderingen beheren
    .accesskey = z
sitedata-heading =
    .description = Uw cookies, geschiedenis, buffer en websitegegevens en meer beheren.
    .label = Navigatiegegevens
sitedata-settings3 =
    .label = Gegevens voor specifieke websites wissen
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Kies hoe specifieke websites omgaan met cookies en websitegegevens.
    .label = Uitzonderingen beheren
    .accesskey = z
cookies-site-data-group =
    .label = Cookies en websitegegevens

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Blokkering van cookiebanners
cookie-banner-blocker-description = Wanneer een website vraagt of cookies in de privénavigatiemodus mogen worden gebruikt, weigert { -brand-short-name } automatisch voor u. Alleen op ondersteunde websites.
cookie-banner-learn-more = Meer info
cookie-banner-blocker-checkbox-label =
    .label = Cookiebanners automatisch weigeren

## Search Section

addressbar-locbar-history-option =
    .label = Navigatiegeschiedenis
    .accesskey = g
addressbar-locbar-bookmarks-option =
    .label = Bladwijzers
    .accesskey = d
addressbar-locbar-clipboard-option =
    .label = Klembord
    .accesskey = K
addressbar-locbar-openpage-option =
    .label = Open tabbladen
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Snelkoppelingen
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = Topwebsites
    .accesskey = T
addressbar-locbar-engines-option-1 =
    .label = Te gebruiken zoekmachines voor suggesties
    .accesskey = z
addressbar-locbar-quickactions-option =
    .label = Snelle acties
    .accesskey = S
addressbar-locbar-showrecentsearches-option-2 =
    .label = Recente zoekopdrachten
    .accesskey = z
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Trending zoeksuggesties
    .accesskey = T
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Ontvang suggesties van het web gerelateerd aan uw zoekopdracht.
    .label = Suggesties van { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Ondersteun { -brand-short-name } met af en toe gesponsorde suggesties.
    .label = Suggesties van sponsors
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Suggesties van Mozilla ophalen terwijl u typt
addressbar-dismissed-suggestions-label-2 =
    .description = Gesloten suggesties van sponsors en { -brand-short-name } herstellen.
    .label = Gesloten suggesties
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Suggesties herstellen

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Verbeterde bescherming tegen volgen
content-blocking-section-top-level-description = Trackers volgen u online om gegevens over uw surfgedrag en interesses te verzamelen. { -brand-short-name } blokkeert veel van deze trackers en andere kwaadwillende scripts.
content-blocking-learn-more = Meer info
content-blocking-fpi-incompatibility-warning = U gebruikt First Party Isolation (FPI), dat een aantal cookie-instellingen van { -brand-short-name } overschrijft.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = U gebruikt Resist Fingerprinting (RFP), dat een aantal van de { -brand-short-name }-instellingen voor bescherming tegen fingerprinting vervangt. Dit kan ervoor zorgen dat sommige websites niet goed werken.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standaard
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Streng
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Aangepast
    .accesskey = A

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Gebalanceerd voor bescherming en prestaties. Pagina’s laden normaal.
content-blocking-etp-strict-desc = Sterkere bescherming, maar kan er voor zorgen dat sommige websites of inhoud niet werken.
content-blocking-etp-custom-desc = Kies welke trackers en scripts u wilt blokkeren.
content-blocking-etp-blocking-desc = { -brand-short-name } blokkeert het volgende:
content-blocking-private-windows = Volginhoud in privévensters
content-blocking-cross-site-cookies-in-all-windows2 = Cross-site-cookies in alle vensters
content-blocking-cross-site-tracking-cookies = Cross-site-trackingcookies
content-blocking-all-cross-site-cookies-private-windows = Cross-site-cookies in privévensters
content-blocking-isolate-cross-site-cookies = Cross-sitecookies isoleren
content-blocking-social-media-trackers = Sociale-mediatrackers
content-blocking-all-cookies = Alle cookies
content-blocking-unvisited-cookies = Cookies van niet-bezochte websites
content-blocking-all-windows-tracking-content = Volginhoud in alle vensters
content-blocking-all-cross-site-cookies = Alle cross-sitecookies
content-blocking-cryptominers = Cryptominers
content-blocking-fingerprinters = Fingerprinters
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Bekende en verdachte fingerprinters
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Totale cookiebescherming sluit cookies in op de website die u bezoekt, zodat trackers ze niet kunnen gebruiken om u tussen websites te volgen.
content-blocking-etp-standard-tcp-rollout-learn-more = Meer info
content-blocking-etp-standard-tcp-title = Bevat Totale cookiebescherming, onze krachtigste privacyfunctie ooit
content-blocking-warning-title-2 = Sommige websites werken mogelijk niet goed met strikte bescherming tegen volgen
content-blocking-warning-title-custom = Sommige websites werken mogelijk niet goed met aangepaste bescherming tegen volgen
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } raadt het gebruik van de instellingen voor ‘Problemen met website oplossen’ aan om defecte websitefuncties en -inhoud te verminderen. Als een website niet lijkt te werken, probeer dan bescherming tegen volgen voor die website uit te schakelen om alle inhoud te laden.
content-blocking-warning-learn-how = Meer info
content-blocking-baseline-exceptions-3 =
    .description = Helpt websites en functies te laden door alleen essentiële elementen die trackers kunnen bevatten te deblokkeren. Dekt de meest voorkomende problemen.
    .label = Grote problemen met de website verhelpen (aanbevolen)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Herstelt zaken als video’s in een artikel of commentaarsecties door elementen die trackers kunnen bevatten te deblokkeren. Dit kan problemen met de website verminderen, maar biedt minder bescherming. Moet worden gebruikt met oplossingen voor grote problemen.
    .label = Kleine problemen met de website oplossen
content-blocking-baseline-uncheck-warning-dialog-title = Weet u zeker dat u oplossingen wilt uitschakelen?
content-blocking-baseline-uncheck-warning-dialog-body = Deze instelling helpt bij het oplossen van de meest voorkomende websiteproblemen. Als u de functie uitschakelt, werken sommige websites mogelijk niet, en kan { -brand-short-name } niet helpen bij het oplossen van die problemen.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Oplossingen uitschakelen
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Oplossingen ingeschakeld houden
content-blocking-reload-description = U dient uw tabbladen te vernieuwen om deze wijzigingen toe te passen.
content-blocking-reload-tabs-button =
    .label = Alle tabbladen vernieuwen
    .accesskey = A
content-blocking-tracking-content-label =
    .label = Volginhoud
    .accesskey = V
content-blocking-tracking-protection-option-all-windows =
    .label = In alle vensters
    .accesskey = a
content-blocking-option-private =
    .label = Alleen in privévensters
    .accesskey = r
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Meer informatie
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Cryptominers
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Bekende fingerprinters
    .accesskey = B
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Verdachte fingerprinters
    .accesskey = V

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Uitzonderingen beheren…
    .accesskey = z

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Notificaties pauzeren totdat { -brand-short-name } wordt herstart
    .accesskey = N
permissions-autoplay2 =
    .label = Automatisch afspelen
permissions-block-popups2 =
    .label = Pop-ups en omleidingen van derden blokkeren
    .accesskey = b
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Voeg websites toe die pop-ups mogen openen en doorleidingen van derden mogen gebruiken.
    .label = Uitzonderingen beheren
    .searchkeywords = popups
    .accesskey = z
permissions-addon-install-warning3 =
    .label = Waarschuwing tonen wanneer websites extensies proberen te installeren
    .accesskey = W
permissions-addon-exceptions2 =
    .label = Kiezen welke websites extensies mogen installeren
    .accesskey = x
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Websites toestaan te vragen om app-koppelingen te openen.
    .accesskey = W
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Geblokkeerde websites beheren
    .accesskey = G
permissions-location2 =
    .label = Locatie
permissions-localhost2 =
    .label = Apparaatapps en -services
permissions-local-network2 =
    .label = Lokale netwerkapparaten
permissions-xr2 =
    .label = Virtual Reality
permissions-camera2 =
    .label = Camera
permissions-microphone2 =
    .label = Microfoon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Luidspreker
permissions-notification2 =
    .label = Notificaties
permissions-header3 =
    .description = Beheren welke websites kunnen benaderen, aansturen of starten.
    .label = Toestemmingen
permissions-data-section =
    .heading = Toestemmingen en gegevens
pane-permissions-data-title2 = Toestemmingen en gegevens
    .title = Toestemmingen en gegevens
notifications-section-header =
    .heading = Notificaties
notifications-entry-card-header =
    .description = Kies welke websites notificaties kunnen sturen, en hoe die notificaties verschijnen.
    .label = Notificaties
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } website
           *[other] { $count } websites
        }
    .label = Notificatie-instellingen beheren
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Website-notificatie-instellingen beheren
notifications-website-card-header =
    .description = Kies hoe websites notificaties kunnen verzenden.
    .label = Websitenotificaties
notifications-filter =
    .placeholder = Websites doorzoeken
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Website
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Notificaties toestaan
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Websites
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Altijd
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Toestaan
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Nooit
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Geen websitenotificaties toegevoegd.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Er komen geen websitenotificaties overeen met uw zoekopdracht.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Open elk profiel en kies ‘Nu een reservekopie maken’ in Instellingen om ervoor te zorgen dat deze wijziging in uw reservekopieën wordt opgenomen.
nimbus-rollouts =
    .description = Wijzigingen worden op afstand uitgerold.
    .label = { -brand-short-name } toestaan om functies, prestaties en stabiliteit tussen updates te verbeteren
addon-recommendations3 =
    .description = Ontvang extensieaanbevelingen om uw surfervaring te verbeteren.
    .label = Gepersonaliseerde extensieaanbevelingen toestaan
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Gegevensrapportage is uitgeschakeld voor deze buildconfiguratie.
collection-backlogged-crash-reports2 =
    .label = Automatisch crashrapporten verzenden
    .accesskey = r
collection-backlogged-crash-reports-description = Dit helpt { -vendor-short-name } problemen met de browser te analyseren en op te lossen. Rapporten kunnen persoonlijke of gevoelige gegevens bevatten.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Dezelfde instellingen, nieuwe vormgeving!
    .message = We hebben deze pagina opnieuw geordend, waardoor deze makkelijker te scannen en verkennen is. Uw persoonlijke instellingen zijn niet gewijzigd, en alles is er nog. Tip: gebruik de zoekfunctie om direct naar wat u nodig hebt te springen.
settings-redesign-promo-dismiss-button =
    .label = Begrepen
privacy-segmentation-section-header = Nieuwe functies die uw browsen verbeteren
privacy-segmentation-section-description = Wanneer we functies aanbieden die uw gegevens gebruiken om u een meer persoonlijke ervaring te bieden:
privacy-segmentation-radio-off =
    .label = { -brand-product-name }-aanbevelingen gebruiken
privacy-segmentation-radio-on =
    .label = Detailinformatie tonen
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = We streven ernaar om u keuzes te bieden en verzamelen alleen de gegevens die minimaal nodig zijn om { -brand-product-name } voor iedereen te verbeteren.
    .label = { -brand-short-name }-gegevensverzameling en -gebruik
    .searchkeywords = telemetrie
data-collection-link = Privacyverklaring bekijken
data-collection-preferences-across-profiles =
    .message = Deze instellingen zijn van toepassing op elk { -brand-product-name }-profiel op dit apparaat.
data-collection-profiles-link = Alle profielen bekijken
data-collection-health-report-telemetry-disabled =
    .message = U staat { -vendor-short-name } niet langer toe technische en interactiegegevens vast te leggen. Alle eerdere gegevens worden binnen 30 dagen verwijderd.
data-collection-health-report =
    .description = Dit helpt ons de functies, prestaties en stabiliteit van { -brand-product-name } te verbeteren.
    .label = Technische en interactiegegevens naar { -vendor-short-name } verzenden
    .accesskey = r
data-collection-health-report-disabled =
    .description = Gegevensrapportage is uitgeschakeld voor deze buildconfiguratie.
    .label = Technische en interactiegegevens naar { -vendor-short-name } verzenden
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } selecteert willekeurig gebruikers om functies te testen, wat helpt de kwaliteit voor iedereen te verbeteren.
    .label = { -brand-short-name } toestaan om functieonderzoeken uit te voeren
data-collection-studies-link =
    .label = { -brand-short-name }-onderzoeken weergeven
data-collection-backlogged-crash-reports =
    .description = Dit helpt { -vendor-short-name } problemen met de browser te identificeren en verhelpen. Rapporten kunnen persoonlijke of gevoelige gegevens bevatten.
    .label = Automatisch crashrapporten verzenden
    .accesskey = c
data-collection-usage-ping =
    .description = Dit helpt { -vendor-short-name } bij het schatten van actieve gebruikers.
    .label = Ping voor dagelijks gebruik naar { -vendor-short-name } verzenden
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Beveiliging
browsing-protection-group2 =
    .description = Gevaarlijke websites en downloads kunnen uw gegevens en apparaat in gevaar brengen. { -brand-short-name } blokkeert ze automatisch, en waarschuwt u voor riskante of ongewenste software.
    .label = Bescherming tegen misleidende inhoud en gevaarlijke software
security-enable-safe-browsing =
    .label = Gevaarlijke en misleidende inhoud blokkeren
    .accesskey = b
security-enable-safe-browsing-link = Meer info
security-safe-browsing-warning =
    .message = Door dit uit te schakelen, vermindert de bescherming tegen oplichting, kwaadwillende websites en gevaarlijke downloads.
security-block-downloads =
    .label = Gevaarlijke downloads blokkeren
    .accesskey = G
security-block-uncommon-software =
    .label = Waarschuwen voor ongewenste en ongebruikelijke software
    .accesskey = s

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = { -brand-short-name } toestaan om door u geïnstalleerde rootcertificaten van derden automatisch te vertrouwen
    .accesskey = t
certs-devices-enable-fips = FIPS inschakelen
space-alert-over-5gb-settings-button =
    .label = Instellingen openen
    .accesskey = o
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } heeft bijna geen schijfruimte meer.</strong> Inhoud van websites wordt mogelijk niet goed weergegeven. U kunt opgeslagen gegevens wissen in Instellingen > Privacy & Beveiliging > Cookies en websitegegevens.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } heeft bijna geen schijfruimte meer.</strong> Inhoud van websites wordt mogelijk niet goed weergegeven. Bezoek ‘Meer info’ om uw schijfgebruik te optimaliseren voor betere prestaties.
certs-description3 =
    .description = De certificaten die { -brand-short-name } gebruikt om beveiligde verbindingen te verifiëren configureren.
    .label = Certificaten
certs-view2 =
    .label = Certificaten beheren
    .accesskey = C
certs-devices2 =
    .label = Beveiligingsapparaten beheren
    .accesskey = a

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Hoe Alleen-HTTPS werkt
httpsonly-radio-enabled =
    .label = Alleen-HTTPS-modus in alle vensters inschakelen
httpsonly-radio-enabled-pbm =
    .label = Alleen-HTTPS-modus uitsluitend in privévensters inschakelen
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } kan nog steeds sommige verbindingen upgraden
    .label = Alleen-HTTPS-modus niet inschakelen
httpsonly-group =
    .description = Staat alleen beveiligde verbindingen met websites toe. { -brand-short-name } zal vragen voordat een onveilige verbinding wordt gemaakt.
    .label = Alleen-HTTPS-modus
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS over HTTPS
dns-over-https-group2 =
    .description = Domain Name System over HTTPS (DoH) versleutelt websitezoekopdrachten, dus het is moeilijker voor uw internetprovider of anderen om te zien welke websites u gaat bezoeken.
    .label = DNS over HTTPS
preferences-doh-description2 = Domain Name System (DNS) over HTTPS verzendt uw aanvraag voor een domeinnaam via een versleutelde verbinding, waardoor een veilige DNS wordt geboden en het voor anderen moeilijker wordt om te zien welke website u gaat bezoeken.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Status: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Provider: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Ongeldige URL
preferences-doh-steering-status = Lokale provider wordt gebruikt
preferences-doh-status-active = Actief
preferences-doh-status-disabled = Uit
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Niet actief ({ $reason })
preferences-doh-group-message2 = DNS over HTTPS inschakelen via:
preferences-doh-radio-group =
    .aria-label = DNS over HTTPS inschakelen via:
preferences-doh-expand-section =
    .tooltiptext = Meer informatie
preferences-doh-setting-default =
    .label = Standaard bescherming
    .accesskey = S
preferences-doh-default-desc = { -brand-short-name } bepaalt wanneer beveiligde DNS moet worden gebruikt om uw privacy te beschermen.
preferences-doh-default-detailed-desc-1 = Beveiligde DNS gebruiken in regio’s waar dit beschikbaar is
preferences-doh-default-detailed-desc-2 = Uw standaard DNS-resolver gebruiken als er een probleem is met de beveiligde-DNS-provider
preferences-doh-default-detailed-desc-3 = Indien mogelijk lokale provider gebruiken
preferences-doh-default-detailed-desc-4 = Uitschakelen als VPN, ouderlijk toezicht of bedrijfsbeleid actief zijn
preferences-doh-default-detailed-desc-5 = Uitschakelen als een netwerk { -brand-short-name } vertelt geen beveiligde DNS te gebruiken
preferences-doh-setting-enabled =
    .label = Verhoogde bescherming
    .accesskey = h
preferences-doh-enabled-desc = U bepaalt wanneer beveiligde DNS wordt gebruikt en kiest uw provider.
preferences-doh-enabled-detailed-desc-1 = De aanbieder die u selecteert gebruiken
preferences-doh-enabled-detailed-desc-2 = Alleen uw standaard DNS-resolver gebruiken als er een probleem met beveiligde DNS is
preferences-doh-setting-strict =
    .label = Max. bescherming
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } gebruikt altijd beveiligde DNS. U ziet een beveiligingswaarschuwing voordat we de DNS van uw systeem gebruiken.
preferences-doh-strict-detailed-desc-1 = Alleen de door u geselecteerde provider gebruiken
preferences-doh-strict-detailed-desc-2 = Altijd waarschuwen als beveiligde DNS niet beschikbaar is
preferences-doh-strict-detailed-desc-3 = Als beveiligde DNS niet beschikbaar is, laden websites niet of werken ze niet goed
preferences-doh-setting-off =
    .label = Uit
    .accesskey = U
preferences-doh-off-desc = Uw standaard DNS-resolver gebruiken
preferences-doh-select-resolver = Kies provider:
preferences-doh-manage-exceptions =
    .label = Uitzonderingen beheren…
    .accesskey = z
preferences-doh-overview-default =
    .description = Veilige DNS gebruiken in regio’s waar deze beschikbaar is.
    .label = Standaard bescherming
preferences-doh-overview-custom =
    .description = Altijd veilige DNS gebruiken met controle over uw provider en terugvalgedrag.
    .label = Aangepast
preferences-doh-overview-off =
    .description = Uw standaard-DNS-resolver gebruiken.
    .label = Uit
preferences-doh-advanced-button =
    .label = Geavanceerde instellingen
preferences-doh-advanced-section =
    .description = Domain Name System over HTTPS (DoH) versleutelt websitezoekopdrachten, dus het is moeilijker voor uw internetprovider of anderen om te zien welke websites u gaat bezoeken.
    .label = Geavanceerde instellingen
preferences-doh-manage-exceptions2 =
    .label = Uitzonderingen beheren
    .accesskey = z
preferences-doh-radio-default =
    .description = Veilige DNS gebruiken in regio’s waar dit beschikbaar is.
    .label = Standaard
preferences-doh-radio-custom =
    .description = Altijd veilige DNS gebruiken met controle over uw provider en terugvalgedrag.
    .label = Aangepast
preferences-doh-radio-off =
    .description = Uw standaard DNS-resolver gebruiken.
    .label = Uit
preferences-doh-fallback-label =
    .label = Mij altijd waarschuwen als beveiligde DNS niet beschikbaar is
preferences-doh-status-item-off =
    .message = DNS over HTTPS is uitgeschakeld
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS over HTTPS werkt niet, omdat er een fout ({ $reason }) is opgetreden bij het gebruik van de provider { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS over HTTPS werkt niet, omdat we een ongeldige URL hebben ontvangen ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS over HTTPS gebruikt de provider { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS over HTTPS werkt niet, omdat er een fout ({ $reason }) is opgetreden bij het gebruik van de lokale provider { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS over HTTPS gebruikt de lokale provider { $name }
preferences-doh-select-resolver-label =
    .label = Kies provider:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Deze provider gebruiken voor het oplossen van DNS over HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Voer een aangepaste provider-URL in
preferences-doh-header2 =
    .heading = DNS over HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Verbindings- en softwarebeveiliging
preferences-connection-link-section =
    .description = Zie hoe verbindingen veilig blijven, schadelijke software wordt geblokkeerd en websites worden geverifieerd.
    .label = Verbindings- en softwarebeveiliging
preferences-connection-link-button =
    .label = Geavanceerde instellingen

## The following strings are used in the Download section of settings

desktop-folder-name = Bureaublad
downloads-folder-name = Downloads

## Appearance page

preferences-appearance-header =
    .heading = Vormgeving
browser-theme-group =
    .description = Geef { -brand-short-name } uw eigen stijl. Themakleuren zijn van toepassing op werkbalken, menu’s en berichten.
    .label = Browserthema
browser-theme-manage-link =
    .label = { -brand-short-name }-thema’s beheren
appearance-window-density-group =
    .description = Pas de ruimte rondom vensterelementen, zoals de werkbalk, tabbladen en de zijbalk aan.
    .label = Vensterdichtheid
appearance-window-density-radio-group =
    .aria-label = Vensterdichtheid
appearance-window-density-automatic =
    .description = Standaard, compacte of aanraakspatiëring wordt automatisch toegepast
    .label = Automatisch (standaard)
appearance-window-density-automatic-no-touch =
    .description = Standaard of compacte spatiëring wordt automatisch toegepast
    .label = Automatisch (standaard)
appearance-window-density-standard =
    .description = Uitgebalanceerde spatiëring voor de meeste schermen
    .label = Standaard
appearance-window-density-auto-touch-mode =
    .label = Aanraakspatiëring gebruiken voor tabletmodus
appearance-window-density-compact =
    .description = Gereduceerde spatiëring voor kleinere schermen
    .label = Compact
appearance-window-density-touch =
    .description = Grotere vensterelementen zoals klikdoelen, geoptimaliseerd voor aanraakschermen
    .label = Aanraking
related-settings-group =
    .label = Gerelateerde instellingen
related-settings-accessibility-link =
    .label = Instellingen voor zoomen en lettertype aanpassen in Toegankelijkheid
related-settings-home-link =
    .label = { -firefox-home-brand-name } aanpassen
related-settings-tabs-browsing-link =
    .label = Browseropmaak aanpassen

## AI controls page

preferences-ai-controls-description = U hebt altijd een keuze in { -brand-short-name }, waaronder het al dan niet gebruiken van met AI verbeterde functies. Binnenkort meer bedieningselementen.
preferences-ai-controls-block-ai-label = AI-verbeteringen blokkeren
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Blokkeren betekent dat u geen nieuwe of huidige AI-verbeteringen in { -brand-short-name } ziet, of pop-ups daarover. <a data-l10n-name="link">Ontdek meer</a> over wat er is inbegrepen en hoe u traditionele functies voor machine learning kunt beheren, zoals zoeksuggesties en aanbevelingen.
preferences-ai-controls-blocked-message =
    .message = Nieuwe en huidige AI-verbeteringen worden standaard geblokkeerd. Gebruik de onderstaande knoppen om een specifieke functie te deblokkeren.
preferences-ai-controls-on-device-group =
    .description = Deze gebruiken kleine AI-modellen die naar uw apparaat worden gedownload als u de functie gebruikt. Deze benadering helpt uw privacy te beschermen.
    .label = AI op apparaat
preferences-ai-controls-translations-control =
    .description = Surf naadloos over het web in uw voorkeurstaal.
    .label = Vertalingen
preferences-ai-controls-translations-more-link = Meer vertaalinstellingen
preferences-ai-controls-pdfjs-control =
    .description = Als u afbeeldingen aan PDF’s toevoegt, voegt dit beschrijvingen toe om ze toegankelijk te maken.
    .label = Alternatieve tekst bij afbeeldingen in { -brand-short-name }-pdf-lezer
preferences-ai-controls-tab-group-suggestions-control =
    .description = Ontvang suggesties om uw tabbladen een naam te geven en te ordenen.
    .label = Suggesties voor tabbladgroepen
preferences-ai-controls-key-points-control =
    .description = Bekijk een snelle samenvatting voordat u een koppeling opent.
    .label = Hoofdpunten in voorbeelden van koppelingen
preferences-ai-controls-speech-recognition-control =
    .description = Spraak lokaal transcriberen.
    .label = Spraakherkenning
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Houd een chatbot onder handbereik terwijl u surft. Kies uit meerdere providers en stap op elk gewenst moment over.
    .label = AI-chatbotproviders in de zijbalk
preferences-ai-controls-sidebar-chatbot-group =
    .description = Houd een chatbot binnen handbereik tijdens het surfen. Kies uit Anthropic Claude, ChatGPT, Copilot, Google Gemini en Le Chat Mistral.
    .label = AI-chatbotproviders in de zijbalk
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot in zijbalk
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Beschikbaar
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Ingeschakeld
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Geblokkeerd
preferences-ai-controls-state-description-before = Wat de opties betekenen:
preferences-ai-controls-state-description-available = <strong>Beschikbaar:</strong> u ziet de functie en kunt deze gebruiken.
preferences-ai-controls-state-description-enabled = <strong>Ingeschakeld:</strong> u hebt zich aangemeld voor het gebruik van de functie.
preferences-ai-controls-state-description-blocked = <strong>Geblokkeerd:</strong> u ziet de functie niet en kunt deze niet gebruiken. Reeds gedownloade modellen voor AI op het apparaat worden verwijderd.
preferences-ai-controls-block-confirmation-heading = AI-verbeteringen blokkeren?
preferences-ai-controls-block-confirmation-description = U ziet geen nieuwe of huidige AI-verbeteringen in { -brand-short-name }, of pop-ups daarover. Daarna kunt u alles wat u wilt blijven gebruiken deblokkeren.
preferences-ai-controls-block-confirmation-features-start = Wat wordt geblokkeerd:
preferences-ai-controls-block-confirmation-translations = Vertalingen
preferences-ai-controls-block-confirmation-pdfjs = Alternatieve tekst bij afbeeldingen in { -brand-short-name }-pdf-lezer
preferences-ai-controls-block-confirmation-tab-group-suggestions = Suggesties voor tabbladgroepen
preferences-ai-controls-block-confirmation-key-points = Hoofdpunten in voorbeelden van koppelingen
preferences-ai-controls-block-confirmation-sidebar-chatbot = Chatbotproviders in zijbalk
preferences-ai-controls-block-confirmation-speech-recognition = Spraakherkenning
preferences-ai-controls-block-confirmation-features-after = Blokkeren heeft ook invloed op extensies die AI van { -brand-short-name } gebruiken.
preferences-ai-controls-block-confirmation-cancel =
    .label = Annuleren
preferences-ai-controls-block-confirmation-confirm =
    .label = Blokkeren
preferences-ai-controls-header3 =
    .heading = AI-bedieningselementen

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } staat op wacht
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } beveelt enkele beveiligingsverbeteringen aan
security-privacy-status-ok-label = Verbeterde bescherming tegen volgen is ingeschakeld
security-privacy-status-problem-label = We hebben instellingen gevonden die invloed hebben op uw bescherming
security-privacy-status-problem-helper-label = Problemen bekijken
security-privacy-status-pending-trackers-label = Opzoeken hoeveel trackers { -brand-short-name } de afgelopen maand heeft geblokkeerd
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } tracker geblokkeerd in de afgelopen maand
       *[other] { $trackerCount } trackers geblokkeerd in de afgelopen maand
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = U hebt <a data-l10n-name="strict-tracking-protection">strenge bescherming</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = U hebt <a data-l10n-name="custom-tracking-protection">aangepaste bescherming</a>
security-privacy-status-up-to-date-label = U hebt de nieuwste, veiligste versie van { -brand-short-name }
security-privacy-status-update-needed-label = Er is een nieuwe versie van { -brand-short-name } beschikbaar.
security-privacy-status-update-error-label = { -brand-short-name } heeft problemen met zichzelf bijwerken
security-privacy-status-update-checking-label = { -brand-short-name } controleert op updates
security-privacy-status-update-needed-description = Werk bij voor de nieuwste snelheids-, stabiliteits- en beveiligingsupdates.
security-privacy-status-update-button-label =
    .label = { -brand-short-name } bijwerken
security-privacy-image-warning =
    .alt = Een schild met een uitroepteken, dat zijn bezorgdheid uit over uw beveiligingswaarschuwingen
security-privacy-image-ok =
    .alt = Een schild met een vinkje, dat aangeeft dat u geen openstaande beveiligingsproblemen hebt
security-privacy-issue-card =
    .heading = Beveiligingswaarschuwingen
issue-card-reset-button =
    .label = Herinitialiseren
issue-card-dismiss-button =
    .aria-label = Sluiten
    .tooltiptext = Sluiten

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Websites gebruiken trackers om u online te volgen en enge advertenties te tonen. { -brand-short-name } schermt u af tijdens het surfen, waarbij de meeste trackers automatisch worden geblokkeerd, zodat u de controle hebt over uw digitale spoor.
    .label = Verbeterde bescherming tegen volgen
preferences-etp-level-radio-group =
    .aria-label = Verbeterde bescherming tegen volgen
preferences-etp-level-standard =
    .description = Sterke, betrouwbare bescherming die soepel werkt met de meeste websites.
    .label = Standaard (standaard)
preferences-etp-level-strict =
    .description = Sterkere bescherming die meer trackers blokkeert, maar kan ervoor zorgen dat sommige websites niet werken.
    .label = Streng
preferences-etp-level-custom =
    .description = Kies welke beschermingsmaatregelen u in of uit wilt schakelen.
    .label = Aangepast
preferences-etp-status-advanced-button =
    .label = Geavanceerde instellingen
preferences-etp-tracker-count-enabled =
    .label = Aantal geblokkeerde trackers tonen in adresbalk
preferences-etp-status-protections-dashboard-link =
    .description = Bekijk hoeveel stiekeme trackers { -brand-short-name } voor u heeft geblokkeerd, waaronder socialemediatrackers, fingerprinters en cryptominers.
    .label = Uw gepersonaliseerde beschermingsdashboard bekijken
preferences-etp-header =
    .heading = Verbeterde bescherming tegen volgen
preferences-etp-advanced-settings-group =
    .description = Websites gebruiken trackers om u online te volgen en enge advertenties te tonen. { -brand-short-name } schermt u af tijdens het surfen, waarbij trackers automatisch worden geblokkeerd, zodat u de controle hebt over uw digitale spoor.
    .label = Geavanceerde instellingen
preferences-etp-customize-button =
    .label = Bescherming tegen volgen aanpassen
preferences-etp-reload-tabs-hint =
    .message = Vernieuw uw tabbladen om deze wijzigingen toe te passen.
preferences-etp-reload-tabs-hint-button =
    .label = Alle tabbladen vernieuwen
preferences-etp-rfp-warning-message =
    .message = U gebruikt Resist Fingerprinting (RFP), dat een aantal van de { -brand-short-name }-instellingen voor bescherming tegen fingerprinting vervangt. Dit kan ervoor zorgen dat sommige websites niet goed werken.
preferences-etp-level-warning-message =
    .heading = Let op! Sommige websites werken mogelijk niet zoals verwacht.
    .message = Sommige websites bouwen trackers in hun functies of inhoud. Wanneer { -brand-short-name } ze blokkeert, ziet de website er defect uit. Probeer ‘Websiteprobleem oplossen’ te gebruiken of bescherming tegen volgen voor die website uit te schakelen.
preferences-etp-manage-exceptions-button =
    .description = Websites waar Verbeterde bescherming tegen volgen is uitgeschakeld beheren.
    .label = Uitzonderingen beheren
preferences-etp-customize-header =
    .heading = Bescherming tegen volgen aanpassen
preferences-etp-reset =
    .description = Instellingen terugzetten naar een voorgedefinieerd beschermingsniveau.
    .label = Aanpassingen herinitialiseren
preferences-etp-reset-standard-button =
    .label = Terugzetten naar standaard
preferences-etp-reset-strict-button =
    .label = Terugzetten naar streng
preferences-etp-custom-control-group =
    .description = Kies welke beschermingsinstellingen u in of uit wilt schakelen.
    .label = Bescherming tegen volgen
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Alle cookies toestaan
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Cross-site-trackingcookies blokkeren
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Cross-sitecookies blokkeren
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Cross-sitecookies isoleren
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Cookies van niet-bezochte websites blokkeren
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Alle cross-sitecookies blokkeren (kan ervoor zorgen dat websites niet goed werken)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Alle cookies blokkeren (websites zullen niet goed werken)
preferences-etp-custom-tracking-protection-enabled =
    .label = Volginhoud
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Volginhoud
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Cryptominers
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Bekende fingerprinters
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Verdachte fingerprinters
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Verdachte fingerprinters

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Dit kan ervoor zorgen dat sommige trackers u volgen zonder cookies.
    .label = Bekende fingerprinters worden niet geblokkeerd
security-privacy-issue-warning-third-party-cookies =
    .description = Cookies van derden worden gebruikt om u tussen websites te volgen.
    .label = Cookies van derden zijn ingeschakeld
security-privacy-issue-warning-password-manager =
    .description = Wachtwoordenbeheerders helpen u sterke wachtwoorden voor uw accounts op te slaan.
    .label = Wachtwoordenbeheerder is uitgeschakeld
security-privacy-issue-warning-popup-blocker =
    .description = Pop-ups zijn verstorend en mogelijk schadelijk.
    .label = Pop-upblokkering is uitgeschakeld
security-privacy-issue-warning-extension-install =
    .description = Websites kunnen zonder te vragen extensies in { -brand-short-name } installeren.
    .label = Websites kunnen extensies installeren
security-privacy-issue-warning-safe-browsing =
    .description = Uw kwetsbaarheid voor scams en malware van websites is verhoogd.
    .label = Gevaarlijke en misleidende inhoud wordt niet geblokkeerd
security-privacy-issue-warning-doh2 =
    .description = DNS over HTTPS helpt voor uw internetaanbieder te verbergen welke websites u op het punt staat te bezoeken.
    .label = DNS over HTTPS is uitgeschakeld
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello helpt voor uw internetaanbieder te verbergen welke websites u op het punt staat te bezoeken.
    .label = Encrypted Client Hello is uitgeschakeld
security-privacy-issue-warning-doh =
    .description = DNS over HTTPS verbergt voor uw netwerkbeheerder welke websites u bezoekt.
    .label = DNS over HTTPS is uitgeschakeld
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello verbergt voor uw netwerkbeheerder welke websites u bezoekt.
    .label = Encrypted Client Hello is uitgeschakeld
security-privacy-issue-warning-proxy-autodetection =
    .description = Automatische proxyconfiguratie kan niet-vertrouwde netwerken uw activiteit laten monitoren.
    .label = Automatische proxyconfiguratie is ingeschakeld

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Nodig iemand uit om de browser te kiezen die privacy voorop stelt.
    .label = { -brand-product-name } delen
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = { -brand-product-name } delen


pane-vorbit-title = vOrbit-lite
vorbit-header = vOrbit-lite-instellingen
vorbit-warning-title = Let op!
vorbit-general-heading = Browsergedrag
vorbit-extension-update-checkbox =
    .label = Add-ons automatisch bijwerken
vorbit-sync-checkbox =
    .label = Firefox-synchronisatie inschakelen
vorbit-autocopy-checkbox =
    .label = Plakken met middelste muisknop
vorbit-styling-checkbox =
    .label = Aanpassen van userChrome.css toestaan
vorbit-network-heading = Netwerk
vorbit-ipv6-checkbox =
    .label = IPv6 gebruiken
vorbit-privacy-heading = Privacy
vorbit-xorigin-ref-checkbox =
    .label = Verwijzingen van dezelfde oorsprong beperken
vorbit-security-heading = Beveiliging
vorbit-ocsp-checkbox =
    .label = OCSP-mislukking afdwingen
vorbit-goog-safe-checkbox =
    .label = Google Safe Browsing gebruiken
vorbit-goog-safe-download-checkbox =
    .label = Downloads scannen
vorbit-extension-update-warning1 = Als u de code van uw add-ons niet telkens wilt controleren, raden wij aan deze optie in te schakelen.
vorbit-ipv6-description = Sta toe dat { -brand-short-name } verbinding maakt via IPv6.
vorbit-ipv6-warning1 = In plaats van IPv6 te blokkeren, raden we aan de IPv6-privacy-extensie van uw besturingssysteem in te schakelen.
vorbit-ocsp-description = Voorkom dat een website kan worden geladen als de OCSP-controle niet kan worden uitgevoerd.
vorbit-ocsp-warning1 = Dit verbetert de beveiliging, maar kan ook tot storingen leiden als de OCSP-server platligt.
vorbit-sync-description = Synchroniseer uw gegevens met andere browsers. Herstart vereist.
vorbit-autocopy-description = Selecteer tekst om te kopiëren en plak de tekst door middel van de middelste muisklik.
vorbit-styling-warning1 = Zorg dat u de leverancier van het thema vertrouwt.
vorbit-xorigin-ref-description = Verstuur alleen een verwijzing als de site dezelfde herkomst heeft.
vorbit-webgl-description = Hierdoor wordt per website om toegangsrechten gevraagd.
vorbit-webgl-warning1 = Als een site WebGL nodig heeft, wordt eerst om uw toestemming gevraagd.
vorbit-rfp-description = ResistFingerprinting is het beste anti-fingerprintinghulpmiddel.
vorbit-goog-safe-download-description = Sta toe dat Safe Browsing uw downloads scant op ongewenste bestanden.
vorbit-goog-safe-download-warning1 = Alle controles worden op uw computer uitgevoerd.
vorbit-footer = Nuttige links
vorbit-config-link = Alle geavanceerde instellingen (about:config)
vorbit-open-profile = Profielmap openen
category-vorbit =
    .tooltiptext = about:config-wijzigingen, logisch ingedeeld en makkelijk te vinden
vorbit-broken-heading = Fingerprinting
vorbit-rfp-checkbox =
    .label = ResistFingerprinting inschakelen
vorbit-extension-update-description = Houd add-ons bijgewerkt, zodat u hier niet zelf verantwoordelijk voor bent. Een uitstekende beveiligingskeus.
vorbit-xorigin-ref-warning1 = Let op: dit kan leiden tot storingen. Bovendien worden verwijzingen alsnog ingekort na het versturen.
vorbit-rfp-warning1 = Als u het daadwerkelijk niet nodig heeft, overweeg dan een add-on als Canvas Blocker.
vorbit-warning-description = We hebben de standaardinstellingen zorgvuldig afgestemd op privacy en beveiliging. Als u deze instellingen wilt aanpassen, lees dan eerst de beschrijvingen door, zodat u weet welke gevolgen dit heeft.
vorbit-letterboxing-checkbox =
    .label = Letterboxing inschakelen
vorbit-styling-description = Schakel dit in als u de vormgeving wilt aanpassen op basis van een thema buiten de browserinstellingen om.
vorbit-letterboxing-description = Letterboxing past marges rond uw vensters toe, zodat er slechts een beperkt aantal resoluties wordt doorgegeven.
vorbit-goog-safe-description = Als u zich zorgen maakt over malware en phishing, schakel deze optie dan in.
vorbit-goog-safe-warning1 = Dit is uitgeschakeld vanwege zorgen over censuur, maar aanbevolen voor gebruikers met minder expertise. Alle controles worden lokaal uitgevoerd.
vorbit-webgl-checkbox =
    .label = WebGL inschakelen met afzonderlijke siterechten
vorbit-sync-warning1 = Firefox Sync versleutelt uw gegevens op uw computer voorafgaand aan de synchronisatie.
content-blocking-section-top-level-description = vOrbit-lite ondersteunt verbeterde bescherming tegen volgen op het strenge niveau en schakelt dit standaard in. Dit is een van de belangrijkste instellingen van de browsers, daar deze instelling onder andere zorgt voor strenge blokkadelijsten en andere nuttige privacyfuncties. Wij raden het kiezen van een ander niveau af.
vorbit-webgl-prompt-checkbox =
    .label = WebGL-toegangspop-up verbergen
vorbit-webgl-prompt-description = Hierdoor wordt geen vraag gesteld als een site toegang tot WebGL nodig heeft. U kunt dit scherm alsnog oproepen door op pictogram in het zoekvak te klikken.
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = Browsergedrag
vorbit-extension-update-checkbox2 =
    .label = Add-ons automatisch bijwerken
    .description = Houd extensies up-to-date, zonder handmatige ingreep. Dit vergroot de veiligheid.
vorbit-sync-checkbox2 =
    .label = Firefox Sync inschakelen
    .description = Synchroniseer uw gegevens met andere browsers. Herstart vereist.
vorbit-autocopy-checkbox2 =
    .label = Plakken met middelste muisknop
    .description = Selecteer tekst om te kopiëren en plak met een druk op de middelste muisknop.
vorbit-styling-checkbox2 =
    .label = userChrome.css-aanpassingen toestaan
    .description = Schakel in als u de vormgeving tot in de puntjes naar eigen hand wilt zetten.
vorbit-network-heading2 =
    .label = Netwerk
vorbit-ipv6-checkbox2 =
    .label = IPv6 inschakelen
    .description = Sta { -brand-short-name } toe om verbinding te maken met behulp van IPv6.
vorbit-privacy-heading2 =
    .label = Privacy
vorbit-xorigin-ref-checkbox2 =
    .label = Kruisbestuiving van doorverwijzingen beperken
    .description = Verwijs alleen door als de bron gelijk is.
vorbit-broken-heading2 =
    .label = Vingerafdrukken
vorbit-webgl-checkbox2 =
    .label = WebGL altijd toestaan
    .description = Schakel WebGL altijd in, zonder toestemming te vragen.
vorbit-webgl-prompt-checkbox2 =
    .label = WebGL-melding per site verbergen
    .description = Toon geen pop-up bij elke site die toegang tot WebGL wil. U kunt de melding bekijken door op het desbetreffende pictogram in de zoekbalk te klikken.
vorbit-rfp-checkbox2 =
    .label = ResistFingerprinting inschakelen
    .description = Schakel alle beschikbare methoden om vingerafdrukken te voorkomen in. Let op: sommige websites functioneren hierdoor mogelijk niet goed.
vorbit-letterboxing-checkbox2 =
    .label = Letterboxing inschakelen
    .description = Letterboxing voorziet vensters van marges, zodat slechts een fractie van de beschikbare resoluties kan worden doorgegeven.
vorbit-security-heading2 =
    .label = Beveiliging
