# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = Eccezioni
permissions-close-key =
    .key = w
permissions-address = Indirizzo del sito web
    .accesskey = n
permissions-block =
    .label = Blocca
    .accesskey = B
permissions-disable-etp =
    .label = Aggiungi eccezione
    .accesskey = A
permissions-session =
    .label = Consenti per la sessione
    .accesskey = e
permissions-allow =
    .label = Consenti
    .accesskey = C
permissions-add =
    .label = Aggiungi
    .accesskey = A
permissions-button-off =
    .label = Disattiva
    .accesskey = D
permissions-button-off-temporarily =
    .label = Disattiva temporaneamente
    .accesskey = m
permissions-site-name =
    .label = Sito web
permissions-status =
    .label = Stato
permissions-remove =
    .label = Rimuovi sito web
    .accesskey = R
permissions-remove-all =
    .label = Rimuovi tutti i siti web
    .accesskey = t
permissions-save-changes-2 =
    .buttonlabelaccept = Salva modifiche
    .buttonaccesskeyaccept = S
permission-dialog =
    .buttonlabelaccept = Salva modifiche
    .buttonaccesskeyaccept = S
permissions-autoplay-menu = Impostazione predefinita per tutti i siti web:
permissions-searchbox =
    .placeholder = Cerca sito web
permissions-capabilities-autoplay-allow =
    .label = Consenti audio e video
permissions-capabilities-autoplay-block =
    .label = Blocca audio
permissions-capabilities-autoplay-blockall =
    .label = Blocca audio e video
permissions-capabilities-allow =
    .label = Consenti
permissions-capabilities-block =
    .label = Blocca
permissions-capabilities-prompt =
    .label = Chiedi sempre
permissions-capabilities-listitem-allow =
    .value = Consenti
permissions-capabilities-listitem-block =
    .value = Blocca
permissions-capabilities-listitem-allow-session =
    .value = Consenti per la sessione
permissions-capabilities-listitem-off =
    .value = Disattivato
permissions-capabilities-listitem-off-temporarily =
    .value = Disattivato temporaneamente

## Invalid Hostname Dialog

permissions-invalid-uri-title = Il nome inserito per il server non è valido
permissions-invalid-uri-label = Inserire un nome valido per il server

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Eccezioni per protezione antitracciamento avanzata
permissions-exceptions-manage-etp-desc = È possibile specificare per quali siti web la protezione antitracciamento avanzata sarà disattivata. Inserire l’indirizzo esatto del sito web da gestire e fare clic su Aggiungi eccezione.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Eccezioni - Cookie e dati dei siti web
permissions-exceptions-cookie-desc = È possibile specificare quali siti web potranno o meno salvare cookie e dati. Inserire l’indirizzo esatto del sito web da gestire e fare clic su Blocca, Consenti per la sessione o Consenti.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Eccezioni - Cancellazione cronologia alla chiusura
permissions-exceptions-shutdown-clearing-desc = È possibile specificare quali siti web conserveranno i propri dati quando { -brand-short-name } cancellerà la cronologia alla chiusura. Digitare l’indirizzo esatto del sito che si desidera aggiungere e fare clic su Consenti.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Eccezioni - Modalità solo HTTPS
permissions-exceptions-https-only-desc2 = È possibile disattivare la modalità solo HTTPS per determinati siti. { -brand-short-name } non cercherà di aggiornare la connessione alla versione sicura HTTPS per questi siti.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Siti web con permesso - Pop-up e reindirizzamenti di terze parti
permissions-exceptions-popup-desc2 = È possibile specificare quali siti web possono aprire finestre pop-up ed essere reindirizzati da frame di terze parti.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Eccezioni - Password salvate
permissions-exceptions-saved-passwords-desc = { -brand-short-name } non salverà le password per i siti elencati qui.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Siti web con permesso - Installazione componenti
permissions-exceptions-addons-desc = È possibile specificare quali siti web avranno il permesso di installare componenti aggiuntivi. Inserire l’indirizzo esatto del sito web a cui dare il permesso e fare clic su Consenti.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Riproduzione automatica
permissions-site-autoplay-desc = È possibile specificare quali siti web non seguono le impostazioni predefinite per la riproduzione automatica.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi notifiche
permissions-site-notification-desc = I seguenti siti web hanno richiesto il permesso di inviare notifiche. È possibile specificare quali siti web potranno inviarle o bloccare direttamente le nuove richieste.
permissions-site-notification-disable-label =
    .label = Blocca nuove richieste di inviare notifiche
permissions-site-notification-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di inviare notifiche. Il blocco delle notifiche potrebbe comportare il malfunzionamento di alcuni siti web.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Consenti notifiche dai siti web quando { -brand-short-name } è chiuso
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Si applicano anche le impostazioni di notifica del sistema operativo.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi posizione
permissions-site-location-desc = I seguenti siti web hanno richiesto il permesso di accedere alla posizione corrente. È possibile specificare quali siti web potranno accedere a questa informazione o bloccare direttamente le nuove richieste.
permissions-site-location-disable-label =
    .label = Blocca nuove richieste di accesso alla posizione corrente
permissions-site-location-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere alla posizione corrente. L’impossibilità di accedere alla posizione potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi per la realtà virtuale
permissions-site-xr-desc = I seguenti siti web hanno richiesto il permesso di accedere ai dispositivi per realtà virtuale. È possibile specificare quali siti web potranno accedere a questi dispositivi o bloccare direttamente le nuove richieste.
permissions-site-xr-disable-label =
    .label = Blocca nuove richieste di accesso ai dispositivi per realtà virtuale
permissions-site-xr-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere ai dispositivi per realtà virtuale. L’impossibilità di accedere ai dispositivi potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Impostazioni - Siti bloccati per link alle app
permissions-site-app-links-desc = A questi siti è impedito chiedere di aprire link ad app, come quelli per la posta elettronica (“mailto:”). Rimuovi un sito per consentirgli di chiederlo di nuovo.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi fotocamera
permissions-site-camera-desc = I seguenti siti web hanno richiesto il permesso di utilizzare la fotocamera. È possibile specificare quali siti web potranno accedere al dispositivo o bloccare direttamente le nuove richieste.
permissions-site-camera-disable-label =
    .label = Blocca nuove richieste di accesso alla fotocamera
permissions-site-camera-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere alla fotocamera. L’impossibilità di accedere al dispositivo potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Impostazioni - App e servizi del dispositivo
permissions-site-localhost-desc = Questi siti web hanno richiesto l’accesso ad app e servizi su questo dispositivo. Puoi scegliere di consentire o impedire ai siti di eseguire questa operazione.
permissions-site-localhost-disable-label =
    .label = Blocca nuove richieste di accesso ad app e servizi su questo dispositivo
permissions-site-localhost-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere ad app e servizi su questo dispositivo. Questo potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Impostazioni - Dispositivi di rete locale
permissions-site-local-network-desc = Questi siti web hanno richiesto l’accesso ad app e servizi su dispositivi connessi alla tua rete Wi-Fi o locale. Puoi scegliere di consentire o impedire ai siti di eseguire questa operazione.
permissions-site-local-network-disable-label =
    .label = Blocca nuove richieste di accesso ad app e servizi su dispositivi connessi alla tua rete Wi-Fi o locale.
permissions-site-local-network-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere ad app e servizi su dispositivi connessi al tuo Wi-Fi o dispositivi di rete locale. Questo potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi microfono
permissions-site-microphone-desc = I seguenti siti web hanno richiesto il permesso di utilizzare il microfono. È possibile specificare quali siti web potranno accedere al dispositivo o bloccare direttamente le nuove richieste.
permissions-site-microphone-disable-label =
    .label = Blocca nuove richieste di accesso al microfono
permissions-site-microphone-disable-desc = Verrà impedito a qualunque sito web non presente nell’elenco di richiedere il permesso di accedere al microfono. L’impossibilità di accedere al dispositivo potrebbe comportare il malfunzionamento di alcuni siti web.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Impostazioni - Permessi altoparlanti
permissions-site-speaker-desc = I seguenti siti web hanno richiesto il permesso di selezionare un dispositivo di uscita audio. È possibile specificare quali siti web potranno effettuare questa selezione.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Eccezioni per DNS su HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } non utilizzerà un DNS sicuro per questi siti e i relativi sottodomini.
permissions-doh-entry-field = Inserire il nome di dominio del sito web
    .accesskey = d
permissions-doh-add-exception =
    .label = Aggiungi
    .accesskey = A
permissions-doh-col =
    .label = Dominio
permissions-doh-remove =
    .label = Rimuovi
    .accesskey = R
permissions-doh-remove-all =
    .label = Rimuovi tutti
    .accesskey = u


