# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "private-browsing-shortcut-title" in installer/custom.ftl
private-browsing-shortcut-text-2 = { -brand-shortcut-name } — Navigazione anonima
# This MUST match the translation of "brief-app-desc" in installer/custom.ftl
browser-shortcut-description = Navigazione veloce e riservata
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Navigazione anonima
       *[other] { -brand-full-name } Navigazione anonima
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Navigazione anonima
popups-infobar-dont-show-message2 =
    .label = Non mostrare questo messaggio quando vengono bloccate finestre pop-up o reindirizzamenti di terze parti
    .accesskey = N
edit-popup-settings2 =
    .label = Gestisci impostazioni pop-up e reindirizzamenti di terze parti…
    .accesskey = G
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Visualizza informazioni sul sito
            [one] Visualizza informazioni sul sito ({ $count } elemento tracciante bloccato)
           *[other] Visualizza informazioni sul sito ({ $count } elementi traccianti bloccati)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = { $count } link
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Messaggi e altro…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Messaggi, Mail e altro…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Condividi…
    .accesskey = C
urlbar-identity-button =
    .aria-label = Visualizza informazioni sul sito

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Apri il pannello con il messaggio di installazione
urlbar-web-notification-anchor =
    .tooltiptext = Decidi se ricevere notifiche da questo sito
urlbar-midi-notification-anchor =
    .tooltiptext = Apri pannello MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Apri pannello seriale
urlbar-eme-notification-anchor =
    .tooltiptext = Gestisci l’utilizzo del software DRM
urlbar-web-authn-anchor =
    .tooltiptext = Apri pannello autenticazione web
urlbar-canvas-notification-anchor =
    .tooltiptext = Accedere ai dati dei canvas
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Gestisci la condivisione del microfono con il sito
urlbar-default-notification-anchor =
    .tooltiptext = Apri il pannello dei messaggi
urlbar-geolocation-notification-anchor =
    .tooltiptext = Apri il pannello con l’indirizzo della richiesta
urlbar-localhost-notification-anchor =
    .tooltiptext = Gestisci l’accesso ai dispositivi locali per questo sito
urlbar-local-network-notification-anchor =
    .tooltiptext = Gestisci la condivisione dell’accesso alla rete locale con questo sito
urlbar-xr-notification-anchor =
    .tooltiptext = Apri il pannello dei permessi per la realtà virtuale
urlbar-storage-access-anchor =
    .tooltiptext = Apri il pannello relativo ai permessi per la navigazione
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Gestisci la condivisione delle finestre o dello schermo con il sito
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Apri il pannello con il messaggio relativo all’archiviazione non in linea per le app
urlbar-password-notification-anchor =
    .tooltiptext = Apri il pannello per il salvataggio delle password
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Gestisci la condivisione di fotocamera e/o microfono con il sito
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Gestisci la condivisione di altri altoparlanti con il sito
urlbar-autoplay-notification-anchor =
    .tooltiptext = Apri il pannello relativo alla riproduzione automatica
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Salvataggio dati nell’archivio permanente
urlbar-addons-notification-anchor =
    .tooltiptext = Apri il pannello con il messaggio di installazione componente aggiuntivo
urlbar-search-tips-confirm = OK
urlbar-search-tips-confirm-short = OK
urlbar-result-menu-button =
    .title = Apri menu
urlbar-result-menu-button-feedback = Feedback
    .title = Apri menu
urlbar-result-menu-learn-more2 = Ulteriori informazioni
    .accesskey = U
urlbar-result-menu-remove-from-history2 = Rimuovi dalla cronologia
    .accesskey = R
urlbar-result-menu-tip-get-help2 = Ricevi assistenza
    .accesskey = a
urlbar-result-menu-dismiss-suggestion2 = Ignora questo suggerimento
    .accesskey = u
urlbar-result-menu-remove-top-site = Rimuovi questo sito principale
    .accesskey = m
urlbar-result-menu-manage-firefox-suggest2 = Gestisci { -firefox-suggest-brand-name }
    .accesskey = G
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Segnala posizione non precisa
    .accesskey = S
urlbar-result-menu-show-less-frequently3 = Mostra meno frequentemente
    .accesskey = M
urlbar-result-menu-dont-show-weather-suggestions3 = Non mostrare suggerimenti sul meteo
    .accesskey = N
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Segnala posizione non precisa
urlbar-result-menu-show-less-frequently2 = Mostra meno frequentemente
urlbar-result-menu-dont-show-weather-suggestions2 = Non mostrare suggerimenti sul meteo
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Ignora questo suggerimento
    .accesskey = n
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Rimuovi dalla cronologia
    .accesskey = c
urlbar-result-menu-learn-more =
    .label = Ulteriori informazioni
    .accesskey = U
urlbar-result-menu-remove-from-history =
    .label = Rimuovi dalla cronologia
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = Ricevi assistenza
    .accesskey = a
urlbar-result-menu-dismiss-suggestion =
    .label = Ignora questo suggerimento
    .accesskey = u
urlbar-result-menu-manage-firefox-suggest =
    .label = Gestisci { -firefox-suggest-brand-name }
    .accesskey = G
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Segnala posizione non precisa
urlbar-result-menu-show-less-frequently =
    .label = Mostra meno frequentemente
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Non mostrare suggerimenti sul meteo
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Apri menu
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Grazie per il tuo feedback
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Grazie per il tuo feedback. I suggerimenti sul meteo non verranno più visualizzati.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Scrivi di meno e trova più risultati: cerca con { $engineName } direttamente dalla barra degli indirizzi.
urlbar-search-tips-redirect-2 = Inizia le tue ricerche dalla barra degli indirizzi per visualizzare suggerimenti da { $engineName } e dalla cronologia di navigazione.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Seleziona questa scorciatoia per trovare ciò che ti serve più rapidamente.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Segnalibri
urlbar-search-mode-tabs = Schede
urlbar-search-mode-history = Cronologia
urlbar-search-mode-actions = Azioni

##

urlbar-geolocation-blocked =
    .tooltiptext = Il rilevamento della posizione è bloccato per questo sito web.
urlbar-localhost-blocked =
    .tooltiptext = Le connessioni ai dispositivi locali sono bloccate per questo sito web.
urlbar-local-network-blocked =
    .tooltiptext = Le connessioni alla rete locale sono bloccate per questo sito web.
urlbar-xr-blocked =
    .tooltiptext = L’accesso ai dispositivi per realtà virtuale è bloccato per questo sito web.
urlbar-web-notifications-blocked =
    .tooltiptext = Le notifiche sono bloccate per questo sito web.
urlbar-camera-blocked =
    .tooltiptext = La fotocamera è bloccata per questo sito web.
urlbar-microphone-blocked =
    .tooltiptext = Il microfono è bloccato per questo sito web.
urlbar-screen-blocked =
    .tooltiptext = La condivisione dello schermo è bloccata per questo sito web.
urlbar-persistent-storage-blocked =
    .tooltiptext = Il salvataggio dati nell’archivio permanente è bloccato per questo sito web.
urlbar-popup-blocked2 =
    .tooltiptext = Pop-up e reindirizzamenti di terze parti sono bloccati per questo sito web.
urlbar-autoplay-media-blocked =
    .tooltiptext = La riproduzione automatica di contenuti sonori è bloccata per questo sito web.
urlbar-canvas-blocked =
    .tooltiptext = L’accesso ai dati dei canvas è bloccato per questo sito web.
urlbar-midi-blocked =
    .tooltiptext = L’accesso alle funzioni MIDI è bloccato per questo sito web.
urlbar-serial-blocked =
    .tooltiptext = L’accesso alla porta seriale è bloccato per questo sito web.
urlbar-install-blocked =
    .tooltiptext = L’installazione di componenti aggiuntivi è bloccata per questo sito.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Modifica questo segnalibro ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Aggiungi ai segnalibri ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Schermo diviso
    .tooltiptext = Schermo diviso

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Incolla e vai
    .accesskey = n
urlbar-menuitem-paste-and-search =
    .label = Incolla e cerca
    .accesskey = c

## Searchbar context menu

clear-search-history =
    .label = Cancella la cronologia di ricerca
    .accesskey = n

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Gestisci estensione…
    .accesskey = G
page-action-remove-extension2 =
    .label = Rimuovi estensione
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = Nascondi barre degli strumenti
    .accesskey = N
full-screen-exit =
    .label = Esci da schermo intero
    .accesskey = E

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Adesso cerca con:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Modifica le impostazioni di ricerca
search-one-offs-context-open-new-tab =
    .label = Cerca in una nuova scheda
    .accesskey = n
search-one-offs-context-set-as-default =
    .label = Imposta come motore di ricerca predefinito
    .accesskey = m
search-one-offs-context-set-as-default-private =
    .label = Imposta come motore di ricerca predefinito in finestre anonime
    .accesskey = a
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Aggiungi motore di ricerca “{ $engineName }”
    .label = Aggiungi “{ $engineName }”
    .tooltiptext = Aggiungi motore di ricerca “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Aggiungi motore di ricerca
    .accesskey = A
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Aggiungi motore di ricerca

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Segnalibri ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Schede ({ $restrict })
search-one-offs-history =
    .tooltiptext = Cronologia ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Azioni ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Visualizza componenti aggiuntivi
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = estensioni, temi, componenti aggiuntivi
# Opens preferences page at AI controls
quickactions-manageai = Gestisci controlli IA
quickactions-cmd-manageai = disattiva ia, disattiva ai, spegni ia, spegni ai, gestisci ia, gestisci ai
# Opens the bookmarks library window
quickactions-bookmarks2 = Gestisci segnalibri
quickactions-cmd-bookmarks = segnalibri
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Cancella la cronologia recente
quickactions-cmd-clearrecenthistory2 = cookie, elimina cookie, cache, elimina cache, dati di navigazione, elimina dati navigazione, cancella dati navigazione, cronologia, elimina cronologia recente, cancella cronologia
# Opens about:downloads page
quickactions-downloads2 = Mostra download
quickactions-cmd-downloads = download
# Opens about:addons page in the extensions section
quickactions-extensions = Gestisci estensioni
quickactions-cmd-extensions2 = estensioni, componenti aggiuntivi
# Opens Firefox View
quickactions-firefoxview = Apri { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = apri { -firefoxview-brand-name }, { -firefoxview-brand-name }, apri view, view
# Opens SUMO home page
quickactions-help = Supporto per { -brand-product-name }
quickactions-cmd-help = supporto, aiuto, assistenza
# Opens the devtools web inspector
quickactions-inspector2 = Apri strumenti di sviluppo
quickactions-cmd-inspector2 = analisi pagina, strumenti di sviluppo, sviluppo, inspector, devtools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Scegli un colore
quickactions-cmd-colorpicker = selettore colore, contagocce, seleziona colore, eyedropper
# Opens Firefox Library
quickactions-cmd-library = libreria
quickactions-library = Apri libreria
# Opens about:logins
quickactions-logins2 = Gestisci password
quickactions-cmd-logins = credenziali, password
# Mutes all tabs playing audio
quickactions-mute = Disattiva audio delle schede che riproducono suoni
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = silenzia, zittisci, sssssh
# Opens the print dialog
quickactions-print2 = Stampa pagina
quickactions-cmd-print = stampa
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Salva pagina come PDF
quickactions-cmd-savepdf2 = pdf, salva pagina
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Apri editor PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Apri finestra anonima
quickactions-cmd-private = navigazione anonima, incognito
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Ripristina { -brand-short-name }
quickactions-cmd-refresh = ripristina
# Restarts the browser
quickactions-restart = Riavvia { -brand-short-name }
quickactions-cmd-restart = riavvia
# Opens the screenshot tool
quickactions-screenshot3 = Cattura schermata
quickactions-cmd-screenshot2 = screenshot, schermata, cattura schermata, acquisisci schermata
# Opens about:translations
quickactions-translate = Traduci
quickactions-cmd-translate = traduci
# Opens about:preferences
quickactions-settings2 = Gestisci impostazioni
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = impostazioni, preferenze, opzioni, gestisci
# Opens about:addons page in the themes section
quickactions-themes = Gestisci temi
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temi, componenti aggiuntivi
# Opens a SUMO article explaining how to update the browser
quickactions-update = Aggiorna { -brand-short-name }
quickactions-cmd-update = aggiorna
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Visualizza sorgente pagina
quickactions-cmd-viewsource2 = Visualizza sorgente, sorgente, sorgente pagina
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Apri { -firefoxlabs-brand-name }
quickactions-cmd-labs = lab, labs, esperimento, esperimenti
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Ulteriori informazioni sulle azioni rapide
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Premi il tasto di tabulazione per selezionare:

## Bookmark Panel

bookmarks-add-bookmark = Aggiungi segnalibro
bookmarks-edit-bookmark = Modifica segnalibro
bookmark-panel-cancel =
    .label = Annulla
    .accesskey = A
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [1] Elimina segnalibro
           *[other] Elimina { $count } segnalibri
        }
    .accesskey = s
bookmark-panel-show-editor-checkbox =
    .label = Visualizza editor quando si salva
    .accesskey = V
bookmark-panel-save-button2 =
    .label = Salva
    .accesskey = S
bookmark-panel-save-button =
    .label = Salva
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 28em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Informazioni sito { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Sicurezza connessione per { $host }
identity-connection-not-secure = Connessione non sicura
identity-connection-secure = Connessione sicura
identity-connection-failure = Errore di connessione
identity-connection-internal = Questa è una pagina sicura di { -brand-short-name }.
identity-connection-file = Questa pagina è salvata sul dispositivo in uso.
identity-connection-associated = Questa pagina è caricata da un’altra pagina.
identity-extension-page = Questa pagina è caricata da un’estensione.
identity-active-blocked = Alcuni elementi non sicuri di questa pagina sono stati bloccati da { -brand-short-name }.
identity-custom-root = Connessione verificata da un’autorità di certificazione non riconosciuta da Mozilla.
identity-passive-loaded = Alcuni elementi di questa pagina non sono sicuri (ad esempio immagini).
identity-active-loaded = La protezione è disattivata per questa pagina.
identity-weak-encryption = Questa pagina utilizza una crittografia debole.
identity-https-only-connection-upgraded = (aggiornato a HTTPS)
identity-https-only-label2 = Aggiorna automaticamente questo sito a una connessione sicura
identity-https-only-dropdown-on =
    .label = Attiva
identity-https-only-dropdown-off =
    .label = Disattivata
identity-https-only-dropdown-off-temporarily =
    .label = Disattivata temporaneamente
identity-https-only-info-turn-on3 = Attiva l’aggiornamento a HTTPS per questo sito per fare in modo che { -brand-short-name } aggiorni la connessione quando possibile.
identity-https-only-info-turn-off3 = Se la pagina non funziona correttamente, prova a disattivare l’aggiornamento a HTTPS per questo sito. Il sito verrà ricaricato usando una connessione HTTP non sicura.
identity-https-only-info-no-upgrade = Impossibile aggiornare la connessione da HTTP.
identity-permissions-storage-access-header = Cookie intersito
identity-permissions-storage-access-hint = Questi soggetti possono utilizzare cookie intersito e dati dei siti web quando ti trovi in questo sito.
identity-permissions-storage-access-learn-more = Ulteriori informazioni
identity-permissions-reload-hint = Potrebbe essere necessario ricaricare la pagina per rendere effettive le modifiche.
identity-clear-site-data =
    .label = Elimina cookie e dati dei siti web…
identity-connection-not-secure-security-view = La connessione con questo sito non è sicura.
identity-connection-verified = La connessione con questo sito è sicura.
identity-ev-owner-label2 = Certificato rilasciato a
identity-verifier-label2 = Verificata da
identity-ev-owner-label = Certificato rilasciato a:
identity-verifier-label = Verificata da:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Qualificato in base al Regolamento (UE) 2024/1183.
identity-description-custom-root2 = Mozilla non riconosce il soggetto che ha emesso questo certificato. Potrebbe essere stato aggiunto dal sistema operativo o da un amministratore.
identity-cert-exception-overridden = È stata aggiunta un’eccezione di sicurezza per questo sito.
identity-remove-cert-exception =
    .label = Elimina eccezione
    .accesskey = E
identity-description-insecure = La connessione con questo sito non è privata. Le informazioni inviate, come ad esempio password, messaggi, dati delle carte di credito, ecc. potrebbero essere visibili ad altri soggetti.
identity-description-weak-cipher-intro = La connessione con questo sito web utilizza una crittografia debole e non è privata.
identity-description-weak-cipher-risk = Altri soggetti potrebbero visualizzare le informazioni trasmesse o modificare il comportamento del sito.
identity-description-active-blocked2 = Alcuni elementi non sicuri di questa pagina sono stati bloccati da { -brand-short-name }.
identity-description-passive-loaded = La connessione non è privata e le informazioni trasmesse al sito potrebbero essere visibili ad altri soggetti.
identity-description-passive-loaded-insecure2 = Alcuni elementi di questo sito web non sono sicuri (ad esempio immagini).
identity-description-passive-loaded-mixed2 = Nonostante alcuni elementi siano stati bloccati da { -brand-short-name }, in questa pagina sono ancora presenti elementi non sicuri (ad esempio immagini).
identity-description-active-loaded = La connessione con questo sito web non è sicura in quanto presenta contenuti non sicuri (ad esempio script).
identity-description-active-loaded-insecure = Le informazioni inviate, come ad esempio password, messaggi, dati delle carte di credito, ecc. potrebbero essere visibili ad altri soggetti.
identity-description-tls-key-logging-heading = La connessione potrebbe non essere privata
identity-description-tls-key-logging-message = Un’app o un servizio potrebbe visualizzare il tuo traffico crittato da questo sito.
identity-more-info-link-text =
    .label = Ulteriori informazioni

## Window controls

browser-window-minimize-button =
    .tooltiptext = Riduci a icona
browser-window-maximize-button =
    .tooltiptext = Ingrandisci
browser-window-restore-down-button =
    .tooltiptext = Ripristina dimensioni
browser-window-close-button =
    .tooltiptext = Chiudi
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Ritorna

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importa segnalibri…
    .tooltiptext = Importa i segnalibri di un altro browser in { -brand-short-name }.
bookmarks-toolbar-empty-message = Salva i tuoi segnalibri qui, nella barra dei segnalibri, per accedervi più rapidamente. <a data-l10n-name="manage-bookmarks">Gestisci i segnalibri…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Fotocamera:
    .accesskey = F
popup-select-camera-icon =
    .tooltiptext = Fotocamera
popup-select-microphone-device =
    .value = Microfono:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Microfono
popup-select-speaker-icon =
    .tooltiptext = Altoparlanti
popup-select-window-or-screen =
    .label = Finestra o schermo:
    .accesskey = F
popup-all-windows-shared = Tutte le finestre visibili sullo schermo verranno condivise.

## WebRTC window or screen share tab switch warning

sharing-warning-window = { -brand-short-name } è attualmente condiviso. Altre persone possono vedere quando passi a un’altra scheda.
sharing-warning-screen = L’intero schermo è attualmente condiviso. Altre persone possono vedere quando passi a un’altra scheda.
sharing-warning-proceed-to-tab =
    .label = Passa alla scheda
sharing-warning-disable-for-session =
    .label = Disattiva avvisi relativi alla condivisione in questa sessione

## WebSerial "select a port" popup

webserial-select-port-label = Seleziona una porta seriale:
webserial-no-ports-available = Nessuna porta seriale disponibile

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Chiudi
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Cerca o inserisci un indirizzo
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Inserisci un indirizzo
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Cerca con { $name }
    .placeholder = Cerca sul Web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Cerca in { $name }
    .placeholder = Immetti i termini di ricerca
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Cerca nei segnalibri
    .placeholder = Immetti i termini di ricerca
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Cerca nella cronologia
    .placeholder = Immetti i termini di ricerca
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Cerca nelle schede
    .placeholder = Immetti i termini di ricerca
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Cerca nelle azioni
    .placeholder = Immetti i termini di ricerca
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Cerca con { $name } o inserisci un indirizzo
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Il browser è attualmente controllato da remoto (motivo: { $component })
urlbar-permissions-granted =
    .tooltiptext = Sono stati concessi permessi aggiuntivi a questo sito web.
urlbar-switch-to-tab =
    .value = Passa alla scheda:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Estensione:
urlbar-go-button2 =
    .title = Vai all’URL inserito nella barra degli indirizzi
urlbar-page-action-button =
    .tooltiptext = Azioni per la pagina
urlbar-revert-button =
    .tooltiptext = Mostra l’indirizzo nella barra degli indirizzi

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Cerca con { $engine } in una finestra anonima
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Cerca in una finestra anonima
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Cerca con { $engine }
urlbar-result-action-sponsored = Sponsorizzato
urlbar-result-action-switch-tab = Passa alla scheda
urlbar-result-action-move-tab-to-split-view = Sposta scheda in schermo diviso
urlbar-result-action-visit = Apri
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Passa alla scheda · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Gruppo senza nome
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Apri indirizzo dagli appunti
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Premi il tasto di tabulazione (Tab) per cercare con { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Premi il tasto di tabulazione (Tab) per cercare in { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Cerca con { $engine } direttamente dalla barra degli indirizzi
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Cerca in { $engine } direttamente dalla barra degli indirizzi
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Copia
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = indefinito
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Estensione per { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Consigliato
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> in { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> in { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Sponsorizzato
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Chiedi
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Ultima visita { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Ultima visita { $daysAgo } giorno fa
       *[other] Ultima visita { $daysAgo } giorni fa
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Ultima visita { $weeksAgo } settimana fa
       *[other] Ultima visita { $weeksAgo } settimane fa
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Ultima visita { $monthsAgo } mese fa
       *[other] Ultima visita { $monthsAgo } mesi fa
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Ultima visita { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Aggiunto ai segnalibri { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Ultima visita { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Ultima visita { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Ultima visita { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Ottieni informazioni sui mercati azionari direttamente nella barra di ricerca
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Mostra gli aggiornamenti sui mercati e altro ancora dai nostri partner quando condividi i dati relativi ai termini di ricerca con { -vendor-short-name }. <a data-l10n-name="learn-more-link">Ulteriori informazioni</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Mostra suggerimenti
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Non adesso
urlbar-result-realtime-opt-in-dismiss = Chiudi
urlbar-result-realtime-opt-in-dismiss-all2 = Non mostrare questi suggerimenti
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Non mostrare suggerimenti sui mercati
    .accesskey = N
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Non mostrare suggerimenti sui mercati
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Non mostrare questi suggerimenti
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Non mostrare suggerimenti sui mercati
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Grazie per il tuo feedback. I suggerimenti sui mercati non verranno più visualizzati.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Suggerimenti sui mercati azionari
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Grazie per il tuo feedback. Questi suggerimenti non verranno più visualizzati.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · Tra { $daysUntilStart } giorno
       *[other] { $name } · Tra { $daysUntilStart } giorni
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Inizia tra { $daysUntilStart } giorno
       *[other] { $name } · Inizia tra { $daysUntilStart } giorni
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Termina tra { $daysUntilEnd } giorno
       *[other] { $name } · Termina tra { $daysUntilEnd } giorni
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Oggi
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Termina oggi

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Cerca con { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Cerca { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Cerca con { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, scegli un motore di ricerca
urlbar-searchmode-button-no-engine2 =
    .title = Nessuna scorciatoia selezionata, scegline una
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = La ricerca tramite parole chiave è disattivata
urlbar-searchmode-dropmarker2 =
    .title = Scegli un motore di ricerca
urlbar-searchmode-bookmarks4 = Segnalibri
urlbar-searchmode-tabs4 = Schede
urlbar-searchmode-history4 = Cronologia
urlbar-searchmode-actions4 = Azioni
urlbar-searchmode-bookmarks3 = Segnalibri
    .accesskey = S
urlbar-searchmode-tabs3 = Schede
    .accesskey = S
urlbar-searchmode-history3 = Cronologia
    .accesskey = C
urlbar-searchmode-actions3 = Azioni
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Chiudi
urlbar-searchmode-default2 =
    .title = Motore di ricerca predefinito
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Aggiungi “{ $engineName }”
    .title = Aggiungi motore di ricerca “{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Adesso cerca con:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Cerca con:
urlbar-searchmode-popup-search-settings2 = Impostazioni ricerca
urlbar-searchmode-popup-settings2 = Impostazioni
urlbar-searchmode-popup-search-settings = Impostazioni ricerca
    .accesskey = r
urlbar-searchmode-popup-settings = Impostazioni
    .accesskey = m

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Cerca nei segnalibri
urlbar-result-action-search-history = Cerca nella cronologia
urlbar-result-action-search-tabs = Cerca nelle schede
urlbar-result-action-search-actions = Cerca nelle azioni
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Passa a { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Apri { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Apri in nuova scheda
    .accesskey = n
urlbar-view-context-menu-open-in-container-tab =
    .label = Apri in nuova scheda contenitore
    .accesskey = o
urlbar-view-context-menu-open-in-window =
    .label = Apri in nuova finestra
    .accesskey = f
urlbar-view-context-menu-open-in-private-window =
    .label = Apri in nuova finestra anonima
    .accesskey = m
urlbar-view-context-menu-open-in-tab2 = Apri in nuova scheda
    .accesskey = n
urlbar-view-context-menu-open-in-container-tab2 = Apri in nuova scheda contenitore
    .accesskey = o
urlbar-view-context-menu-open-in-window2 = Apri in nuova finestra
    .accesskey = f
urlbar-view-context-menu-open-in-private-window2 = Apri in nuova finestra anonima
    .accesskey = m
urlbar-view-context-menu-search-in-tab = Cerca in una nuova scheda
    .accesskey = s
urlbar-view-context-menu-search-in-container-tab = Cerca in una nuova scheda contenitore
    .accesskey = c
urlbar-view-context-menu-search-in-window = Cerca in una nuova finestra
    .accesskey = f
urlbar-view-context-menu-search-in-private-window = Cerca in una nuova finestra anonima
    .accesskey = a
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Salta questo menu quando usi il tasto Tab
    .accesskey = m

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Suggerimenti da { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Azioni rapide
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Ricerche recenti
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Di tendenza su { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Non mostrare ricerche di tendenza
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Non mostrare ricerche di tendenza
    .accesskey = z
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Non mostrare ricerche di tendenza
    .accesskey = z
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Grazie per il tuo feedback. Le ricerche di tendenza non verranno più visualizzate.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Attiva Modalità lettura
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Chiudi Modalità lettura

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Apri Picture-in-Picture ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Chiudi Picture-in-Picture ({ $shortcut })
picture-in-picture-panel-header = Picture-in-Picture
picture-in-picture-panel-headline = Questo sito web sconsiglia l’utilizzo di Picture-in-Picture
picture-in-picture-panel-body = I video potrebbero non essere visualizzati come previsto dallo sviluppatore utilizzando Picture-in-Picture.
picture-in-picture-enable-toggle =
    .label = Attiva comunque

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> è ora visualizzato a schermo intero
fullscreen-warning-no-domain = Questo documento è ora visualizzato a schermo intero
fullscreen-exit-button = Esci da schermo intero (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Esci da schermo intero (esc)
fullscreen-keyboardlock-exit-button = Esci da schermo intero (tieni premuto Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Esci da schermo intero (tieni premuto esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> sta controllando il puntatore del mouse. Premere Esc per riprenderne il controllo.
pointerlock-warning-no-domain = Questo documento sta controllando il puntatore del mouse. Premere Esc per riprenderne il controllo.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Gestisci segnalibri
bookmarks-recent-bookmarks-panel-subheader = Segnalibri recenti
bookmarks-toolbar-chevron =
    .tooltiptext = Visualizza altri segnalibri
bookmarks-sidebar-content =
    .aria-label = Segnalibri
bookmarks-menu-button =
    .label = Menu segnalibri
bookmarks-other-bookmarks-menu =
    .label = Altri segnalibri
bookmarks-mobile-bookmarks-menu =
    .label = Segnalibri da dispositivi mobile

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Nascondi la barra laterale dei segnalibri
           *[other] Visualizza la barra laterale dei segnalibri
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Nascondi la barra dei segnalibri
           *[other] Visualizza la barra dei segnalibri
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Nascondi la barra dei segnalibri
           *[other] Visualizza la barra dei segnalibri
        }

##

bookmarks-search =
    .label = Cerca nei segnalibri
bookmarks-tools =
    .label = Strumenti per i segnalibri
bookmarks-subview-edit-bookmark =
    .label = Modifica segnalibro…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Segnalibri
    .toolbarname = Barra dei segnalibri
    .accesskey = s
bookmarks-toolbar-menu =
    .label = Barra dei segnalibri
bookmarks-toolbar-placeholder =
    .title = Elementi della barra dei segnalibri
bookmarks-toolbar-placeholder-button =
    .label = Elementi della barra dei segnalibri
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Aggiungi scheda corrente ai segnalibri…

## Library Panel items

library-bookmarks-menu =
    .label = Segnalibri

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Correggi codifica testo
    .tooltiptext = Cerca di identificare la codifica testo corretta in base al contenuto della pagina

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Impostazioni
    .tooltiptext =
        { PLATFORM() ->
            [macos] Apri le impostazioni ({ $shortcut })
           *[other] Apri le impostazioni
        }
toolbar-overflow-customize-button =
    .label = Personalizza barra degli strumenti…
    .accesskey = z
toolbar-button-email-link =
    .label = Invia link
    .tooltiptext = Invia link a questa pagina per email
toolbar-button-logins =
    .label = Password
    .tooltiptext = Visualizza e gestisci le password salvate
qrcode-panel-error =
    .message = Generazione del codice QR non riuscita. Riprova.
qrcode-copy-button =
    .label = Copia
qrcode-copy-success =
    .message = Codice QR copiato negli appunti.
qrcode-copy-error =
    .message = Impossibile copiare il codice QR.
qrcode-save-button =
    .label = Salva
qrcode-window-title = Codice QR
qrcode-dialog-title = Codice QR
qrcode-image =
    .aria-label = Codice QR
qrcode-close-button =
    .aria-label = Chiudi
toolbar-button-save-page =
    .label = Salva pagina
    .tooltiptext = Salva questa pagina ({ $shortcut })
toolbar-button-open-file =
    .label = Apri file
    .tooltiptext = Apri file ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Schede sincronizzate
    .tooltiptext = Visualizza schede da altri dispositivi
toolbar-button-send-tab =
    .label = Invia scheda
    .tooltiptext = Invia la scheda corrente a un altro dispositivo
toolbar-button-new-private-window =
    .label = Nuova finestra anonima
    .tooltiptext = Apri una nuova finestra anonima ({ $shortcut })
toolbar-button-share-tab =
    .label = Condividi
    .tooltiptext = Condividi questa pagina
toolbar-button-tab-groups =
    .label = Gruppi di schede
    .tooltiptext = Visualizza i gruppi di schede
toolbar-button-history =
    .label = Cronologia
    .tooltiptext = Visualizza la cronologia ({ $shortcut })
toolbar-button-find =
    .label = Trova
    .tooltiptext = Trova in questa pagina ({ $shortcut })
toolbar-button-developer =
    .label = Sviluppo
    .tooltiptext = Apri gli strumenti di sviluppo ({ $shortcut })
toolbar-button-forget =
    .label = Dimentica
    .tooltiptext = Elimina alcune informazioni dalla cronologia di navigazione
toolbar-zoom-controls =
    .label = Controlli zoom
    .title = Controlli per gestire lo zoom
toolbar-button-zoom-out =
    .label = Riduci zoom
    .tooltiptext = Riduci zoom ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Reimposta il livello di zoom ({ $shortcut })
toolbar-button-zoom-in =
    .label = Aumenta zoom
    .tooltiptext = Aumenta zoom ({ $shortcut })
toolbar-edit-controls =
    .label = Controlli di modifica
    .title = Controlli per la modifica del testo
toolbar-button-cut =
    .label = Taglia
    .tooltiptext = Taglia ({ $shortcut })
toolbar-button-copy =
    .label = Copia
    .tooltiptext = Copia ({ $shortcut })
toolbar-button-paste =
    .label = Incolla
    .tooltiptext = Incolla ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = codiceqr
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = codiceqr-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Alcuni contenuti audio o video in questo sito utilizzano software DRM. Questo potrebbe limitare le azioni disponibili per l’utente in { -brand-short-name }.
eme-notifications-drm-content-playing-manage = Gestisci impostazioni
eme-notifications-drm-content-playing-manage-accesskey = G
eme-notifications-drm-content-playing-dismiss = Chiudi
eme-notifications-drm-content-playing-dismiss-accesskey = C

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = È necessario attivare il DRM per riprodurre i contenuti video o audio presenti in questa pagina.
eme-notifications-drm-content-disabled-button =
    .label = Attiva DRM
    .accesskey = A
eme-notifications-drm-content-cdm-installing-message = Installazione in corso dei componenti necessari per riprodurre i contenuti audio o video presenti in questa pagina. Riprovare più tardi.
decoder-doctor-no-codecs-linux-message = Per riprodurre il video potrebbe essere necessario installare i codec richiesti.
decoder-doctor-no-hw-acceleration-message = Per migliorare la qualità del video potrebbe essere necessario installare Media Feature Pack di Microsoft.
decoder-doctor-no-pulse-audio-message = Per riprodurre l’audio potrebbe essere necessario installare il software PulseAudio.
decoder-doctor-unsupported-libavcodec-message = La libreria libavcodec potrebbe essere vulnerabile o non supportata. Per riprodurre i video è necessario aggiornarla.
decoder-doctor-decode-error-message = Si è verificato un errore durante la decodifica di una risorsa multimediale.
decoder-doctor-decode-warning-message = Si è verificato un errore reversibile durante la decodifica di una risorsa multimediale.
decoder-doctor-learn-how-link = Scopri come
decoder-doctor-report-issue-button =
    .label = Segnala il problema con questo sito
    .accesskey = S
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Si è verificato un arresto anomalo del plugin { $pluginName }.
plugin-crashed-notification-reload-button =
    .label = Ricarica la pagina
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = Invia segnalazione dell’arresto anomalo
    .accesskey = n

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Sito ingannevole
safebrowsing-reported-attack-site-message = Segnalato sito malevolo
safebrowsing-reported-unwanted-site-message = Segnalato sito contenente software indesiderato
safebrowsing-reported-harmful-site-message = Segnalato sito dannoso
safebrowsing-get-me-out-of-here-button =
    .label = Allontanarsi da questo sito
    .accesskey = A
safebrowsing-not-a-deceptive-site-button =
    .label = Non è un sito ingannevole…
    .accesskey = N
safebrowsing-not-an-attack-site-button =
    .label = Non è un sito malevolo…
    .accesskey = N

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = È necessario accedere alla rete per navigare in Internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Apri la pagina di accesso alla rete

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Forse volevi aprire { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Sì, apri { $hostName }
    .accesskey = S

## Password save/update panel

panel-save-update-username-2 =
    .label = Nome utente
panel-save-update-password-2 =
    .label = Password

##

# "More" item in macOS share menu
menu-share-more =
    .label = Altro…
menu-share-windows =
    .label = Altre opzioni
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label = Copia { $count } link
    .accesskey = k
ui-tour-info-panel-close =
    .tooltiptext = Chiudi

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Consenti pop-up e reindirizzamenti di terze parti per { $uriHost }
    .accesskey = z

##

picture-in-picture-hide-toggle =
    .label = Nascondi selettore Picture-in-Picture
    .accesskey = N

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Sposta selettore Picture-in-Picture a destra
    .accesskey = d
picture-in-picture-move-toggle-left =
    .label = Sposta selettore Picture-in-Picture a sinistra
    .accesskey = s

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigazione
navbar-downloads =
    .label = Download
navbar-overflow-2 =
    .tooltiptext = Altri strumenti
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Stampa
    .tooltiptext = Stampa questa pagina… ({ $shortcut })
navbar-home =
    .label = Pagina iniziale
    .tooltiptext = Pagina iniziale di { -brand-short-name }
navbar-library =
    .label = Libreria
    .tooltiptext = Visualizza cronologia, password salvate e altro ancora
navbar-search =
    .title = Cerca
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Schede del browser
tabs-toolbar-new-tab =
    .label = Nuova scheda
tabs-toolbar-list-all-tabs-2 =
    .label = Cerca e gestisci schede
    .tooltiptext = Cerca e gestisci schede
tabs-toolbar-list-all-tabs =
    .label = Elenco di tutte le schede
    .tooltiptext = Elenco di tutte le schede

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Trascina qui una scheda per appuntarla

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Vuoi riaprire le schede aperte in precedenza?</strong> È possibile ripristinare la sessione precedente dal menu <img data-l10n-name="icon"/> di { -brand-short-name }, nella sezione Cronologia.
restore-session-startup-suggestion-button = Mostra come fare

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = La tua organizzazione ha bloccato l’accesso ai file locali su questo computer

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = Ora { $searchTabsShortcut } cerca nelle schede
urlbar-addons-shortcut-moved-description = Per aprire estensioni e temi puoi usare { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Gestisci scorciatoie
urlbar-addons-shortcut-moved-dismiss = OK

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = Alcune informazioni vengono inviate automaticamente a { -vendor-short-name } da { -brand-short-name } per migliorarne l’utilizzo.
data-reporting-notification-button =
    .label = Scegli cosa condividere
    .accesskey = S
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Navigazione anonima
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Navigazione anonima
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Informazioni sulla navigazione anonima
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Ti trovi in una finestra anonima
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Questo impedisce agli altri utenti di questo dispositivo di accedere a informazioni sulla tua navigazione, ma non ti rende invisibile online. <a data-l10n-name="learn-more">Chi può vedere la mia attività?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Prevenzione perdita dati (DLP) tramite { $agentName }. Fai clic per ulteriori informazioni.
content-analysis-panel-title2 = Protezione dalla perdita di dati
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = La tua organizzazione utilizza <b>{ $agentName }</b> per gestire la condivisione di dati sensibili. <a data-l10n-name="info">Ulteriori informazioni</a>
content-analysis-panel-title = Protezione dati
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = La tua organizzazione utilizza <b>{ $agentName }</b> per proteggersi da eventuali perdite di dati. <a data-l10n-name="info">Ulteriori informazioni</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Estensioni
    .tooltiptext = Estensioni

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Estensioni
    .tooltiptext =
        Estensioni
        Permessi richiesti

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Estensioni
    .tooltiptext =
        Estensioni
        Alcune estensioni non sono consentite

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Estensioni
    .tooltiptext =
        Estensioni
        Alcune estensioni sono disattivate

## Private browsing reset button

reset-pbm-panel-heading2 = Cancellare i dati e iniziare una nuova sessione anonima?
reset-pbm-panel-description3 = Questa operazione cancella la cronologia e i cookie e ti disconnette dai siti. Le finestre anonime verranno chiuse e se ne aprirà una nuova.
reset-pbm-panel-description2 = Questa operazione elimina la cronologia, i cookie e tutti gli altri dati dei siti senza chiudere la finestra anonima.
reset-pbm-panel-always-ask-checkbox =
    .label = Chiedi sempre
    .accesskey = C
reset-pbm-panel-cancel-button =
    .label = Annulla
    .accesskey = A
reset-pbm-panel-confirm-button2 =
    .label = Cancella sessione anonima
    .accesskey = C
reset-pbm-panel-complete = Dati della sessione anonima eliminati
reset-pbm-toolbar-button2 =
    .label = Cancella sessione anonima
    .tooltiptext = Cancella sessione anonima

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Eliminare tutti i dati di navigazione?
fire-button-panel-description = Questa operazione elimina cronologia, cookie e dati dei siti web. Verrai disconnesso dai siti. Questa finestra verrà chiusa e { -brand-short-name } ne aprirà una nuova.
fire-button-panel-choose-description = Se non vuoi eliminare tutto, seleziona i dati che desideri eliminare.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Scegli…
fire-button-panel-cancel-button =
    .label = Annulla
    .accesskey = A
fire-button-panel-confirm-button =
    .label = Elimina tutto
    .accesskey = E
fire-button-panel-complete = Dati di navigazione eliminati
fire-button-toolbar-button2 =
    .label = Elimina alcuni o tutti i dati
    .tooltiptext = Elimina in parte o del tutto i dati di navigazione

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } ha impedito a questa pagina di ricaricarsi automaticamente.
refresh-blocked-redirect-label = { -brand-short-name } ha impedito a questa pagina il reindirizzamento automatico verso un’altra pagina.
refresh-blocked-allow =
    .label = Consenti
    .accesskey = C

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = I nostri alias di posta elettronica, sicuri e facili da utilizzare, proteggono la tua identità e bloccano lo spam nascondendo il tuo indirizzo reale.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Tutte le email inviate al tuo alias verranno inoltrate a <strong>{ $useremail }</strong> (a meno che tu non decida di bloccarle).
firefox-relay-offer-legal-notice = Facendo clic su “Utilizza alias di posta elettronica” accetti le <label data-l10n-name="tos-url">condizioni di utilizzo del servizio</label> e l’<label data-l10n-name="privacy-url">informativa sulla privacy</label>.
firefox-relay-offer-legal-notice-1 = Registrandoti e creando un alias di posta elettronica accetti le <label data-l10n-name="tos-url">condizioni di utilizzo del servizio</label> e l’<label data-l10n-name="privacy-url">informativa sulla privacy</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (non verificato)
popup-notification-xpinstall-prompt-learn-more = Scopri come installare componenti aggiuntivi in completa sicurezza
popup-notification-xpinstall-prompt-block-url = Mostra dettagli
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Consenti il funzionamento dell’estensione in finestre anonime
    .accesskey = a
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Condividi dati tecnici e di interazione con lo sviluppatore dell’estensione
    .accesskey = v

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } ha impedito a questo sito di aprire una finestra pop-up.
       *[other] { -brand-short-name } ha impedito a questo sito di aprire { $popupCount } finestre pop-up.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } ha impedito a questo sito di reindirizzare.
        [one] { -brand-short-name } ha impedito a questo sito di aprire una finestra pop-up e reindirizzare.
       *[other] { -brand-short-name } ha impedito a questo sito di aprire { $popupCount } finestre pop-up e reindirizzare.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } ha impedito a questo sito di aprire più di { $popupCount } finestre pop-up.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message = { -brand-short-name } ha impedito a questo sito di aprire più di { $popupCount } finestre pop-up e reindirizzare.
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Opzioni
           *[other] Preferenze
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] r
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Visualizza “{ $popupURI }”
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Mostra “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Impossibile aprire la finestra di selezione file di Windows. Non è stato selezionato alcun file o cartella.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Impossibile aprire la finestra di selezione file di Windows. Il file verrà salvato come { $path }.
file-picker-failed-save-nowhere = Impossibile aprire la finestra di selezione file di Windows. Non è stata trovata una cartella predefinita e il file non verrà salvato.
file-picker-crashed-open = La finestra di selezione file di Windows si è chiusa in modo anomalo. Non è stato selezionato alcun file o cartella.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = La finestra di selezione file di Windows si è chiusa in modo anomalo. Il file verrà salvato come { $path }.
file-picker-crashed-save-nowhere = La finestra di selezione file di Windows si è chiusa in modo anomalo. Non è stata trovata una cartella predefinita e il file non verrà salvato.
file-picker-crashed-show-in-folder =
    .label = Mostra nella cartella
    .accessKey = M

## Unsigned add-ons notification

unsigned-addons-disabled-message = Alcuni dei componenti aggiuntivi installati sono stati disattivati in quanto non è stato possibile verificarli.
unsigned-addons-disabled-learn-more =
    .label = Ulteriori informazioni
    .accesskey = U

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Questa pagina sta rallentando { -brand-short-name }. Si consiglia di bloccarla per velocizzare il browser.
process-hang-nonspecific-tab-message = Il funzionamento di { -brand-short-name } è rallentato da una pagina web. Si consiglia di bloccarla per velocizzare il browser.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” sta rallentando { -brand-short-name }. Si consiglia di bloccare la pagina per velocizzare il browser.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” sta rallentando { -brand-short-name }. Si consiglia di bloccare l’estensione per velocizzare il browser.
process-hang-addon-learn-more =
    .value = Ulteriori informazioni
process-hang-stop-button =
    .label = Blocca
    .accesskey = B

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Completa la configurazione
onboarding-aw-finish-setup-button =
    .label = Completa configurazione
    .tooltiptext = Completa la configurazione di { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = La protezione antitracciamento avanzata è attiva
trustpanel-etp-label-disabled = La protezione antitracciamento avanzata è disattivata
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Protezione antitracciamento avanzata: attiva per { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Protezione antitracciamento avanzata: disattivata per { $host }
trustpanel-etp-description-enabled = Se qualcosa non funziona su questo sito, prova a disattivare le protezioni.
trustpanel-etp-description-disabled = { -brand-product-name } ritiene che le aziende dovrebbero seguirti di meno. Blocchiamo il maggior numero possibile di elementi traccianti quando attivi le protezioni.
trustpanel-trackercount-label = Mostra gli elementi traccianti bloccati nella barra degli indirizzi
trustpanel-trackercount-toggle =
    .aria-label = Mostra gli elementi traccianti bloccati nella barra degli indirizzi
trustpanel-connection-label-secure = Connessione sicura
trustpanel-connection-label-insecure = Connessione non sicura
trustpanel-header-enabled = { -brand-product-name } è in allerta
trustpanel-description-enabled2 = Sei protetto. Se rileviamo qualcosa, te lo faremo sapere.
trustpanel-header-enabled-insecure = Fai attenzione su questo sito
trustpanel-description-enabled-insecure = { -brand-product-name } ha notato qualcosa di sospetto.
trustpanel-header-disabled = Hai disattivato le protezioni
trustpanel-description-disabled = { -brand-product-name } è fuori servizio. Ti consigliamo di riattivare le protezioni.
trustpanel-clear-cookies-button = Elimina cookie e dati dei siti web
trustpanel-privacy-link = Impostazioni per la privacy
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Elimina cookie e dati dei siti web per { $host }
trustpanel-clear-cookies-description = La rimozione di cookie e dati dei siti web potrebbe disconnetterti dai siti e svuotare eventuali carrelli in sospeso.
trustpanel-clear-cookies-subview-button-clear = Elimina
trustpanel-clear-cookies-subview-button-cancel = Annulla
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Protezioni per la connessione a { $host }
trustpanel-siteinformation-morelink = Ulteriori informazioni sul sito
trustpanel-blocker-see-all = Mostra tutti
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Protezioni antitracciamento per { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Non sicuro
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } tracciante bloccato
       *[other] { $count } traccianti bloccati
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } ritiene che le aziende dovrebbero seguirti di meno. Per questo motivo ne blocchiamo il maggior numero possibile.
trustpanel-blocked-header = { -brand-product-name } ha bloccato questi elementi per proteggerti:
trustpanel-tracking-header = { -brand-product-name } ha consentito questi elementi per evitare malfunzionamenti nei siti:
trustpanel-tracking-description = Senza elementi traccianti, alcuni pulsanti, moduli e campi di accesso potrebbero non funzionare.
trustpanel-insecure-section-header = La connessione non è sicura
trustpanel-insecure-description = I dati che stai inviando a questo sito non sono crittati. Potrebbero venire visualizzati, rubati o alterati.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } cookie tracciante intersito
       *[other] { $count } cookie traccianti intersito
    }
trustpanel-list-label-tracking-content = Contenuti traccianti
trustpanel-list-label-fingerprinter = { $count } fingerprinter
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } tracciante dei social media
       *[other] { $count } traccianti dei social media
    }
trustpanel-list-label-cryptominer = { $count } cryptominer
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloccato { $count } tracciante dei social media
       *[other] { -brand-product-name } ha bloccato { $count } traccianti dei social media
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha consentito { $count } tracciante dei social media
       *[other] { -brand-product-name } ha consentito { $count } traccianti dei social media
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloccato { $count } cookie tracciante intersito
       *[other] { -brand-product-name } ha bloccato { $count } cookie traccianti intersito
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha consentito { $count } cookie tracciante intersito
       *[other] { -brand-product-name } ha consentito { $count } cookie traccianti intersito
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha bloccato { $count } elemento tracciante
       *[other] { -brand-product-name } ha bloccato { $count } elementi traccianti
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } ha consentito { $count } elemento tracciante
       *[other] { -brand-product-name } ha consentito { $count } elementi traccianti
    }
trustpanel-tracking-content-tab-list-header = Questi siti stanno cercando di tracciarti:
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name } ha bloccato { $count } fingerprinter
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name } ha consentito { $count } fingerprinter
trustpanel-fingerprinter-list-header = Questi siti stanno cercando di acquisire il fingerprint:
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name } ha bloccato { $count } cryptominer
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name } ha consentito { $count } cryptominer
trustpanel-cryptominer-tab-list-header = Questi siti stanno tentando di effettuare cryptomining:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Hai un account su questo sito?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } ha rilevato una violazione di dati in questo sito negli ultimi 12 mesi. Verifica se sei stato coinvolto.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Chiudi
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Avvia scansione gratuita
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> elemento tracciante bloccato in questo sito
       *[other] <span data-l10n-name="count">{ $count }</span> elementi traccianti bloccati in questo sito
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Il sito non funziona?</strong> Ricarica la pagina per ridurre temporaneamente la protezione antitracciamento.
reduced-protection-infobar-reload-button = Ricarica
    .accesskey = R
reduced-protection-infobar-never-show-button = Non mostrare di nuovo
    .accesskey = N


identity-allow-site-data = vOrbit-lite: Salva sempre i cookie e i dati per questo sito
urlbar-webgl-notification-anchor =
    .tooltiptext = Gestione dei permessi di creazione del contesto WebGL
urlbar-webgl-blocked =
    .tooltiptext = Hai bloccato la creazione del contesto WebGL.
