# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } 隱私瀏覽模式
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = 又快又有隱私地上網
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — 隱私瀏覽模式
       *[other] { -brand-full-name } 隱私瀏覽模式
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = 隱私瀏覽模式
popups-infobar-dont-show-message2 =
    .label = 封鎖彈出型視窗或第三方重新導向時，不要顯示此訊息
    .accesskey = D
edit-popup-settings2 =
    .label = 管理彈出型視窗與第三方重新導向選項…
    .accesskey = M
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] 檢視網站資訊
            [1] 檢視網站資訊（已封鎖 1 組追蹤器）
           *[other] 檢視網站資訊（已封鎖 { $count } 組追蹤器）
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = { $count } 個鏈結
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop、訊息等等…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = 訊息、郵件與更多…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = 分享…
    .accesskey = h
urlbar-identity-button =
    .aria-label = 檢視網站資訊

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = 開啟安裝訊息面板
urlbar-web-notification-anchor =
    .tooltiptext = 變更您是否要收到來自此網站的通知
urlbar-midi-notification-anchor =
    .tooltiptext = 開啟 MIDI 面板
urlbar-serial-notification-anchor =
    .tooltiptext = 開啟序列埠面板
urlbar-eme-notification-anchor =
    .tooltiptext = 管理 DRM 軟體使用
urlbar-web-authn-anchor =
    .tooltiptext = 開啟 Web 身份驗證面板
urlbar-canvas-notification-anchor =
    .tooltiptext = 管理 canvas 資料取得權限
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = 管理您是否要與網站分享麥克風
urlbar-default-notification-anchor =
    .tooltiptext = 開啟訊息面板
urlbar-geolocation-notification-anchor =
    .tooltiptext = 開啟位置請求面板
urlbar-localhost-notification-anchor =
    .tooltiptext = 管理此網站對本機裝置的存取權限
urlbar-local-network-notification-anchor =
    .tooltiptext = 管理您對此網站分享的區域網路存取權限
urlbar-xr-notification-anchor =
    .tooltiptext = 開啟虛擬實境權限面板
urlbar-storage-access-anchor =
    .tooltiptext = 開啟瀏覽活動權限面板
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = 管理您是否要與網站分享視窗或畫面
urlbar-indexed-db-notification-anchor =
    .tooltiptext = 開啟離線儲存訊息面板
urlbar-password-notification-anchor =
    .tooltiptext = 開啟儲存密碼訊息面板
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = 管理您是否要與網站分享攝影機及/或麥克風
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = 管理是否要與網站分享其他音效輸出裝置
urlbar-autoplay-notification-anchor =
    .tooltiptext = 開啟自動播放面板
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = 將資料儲存於持續性儲存空間
urlbar-addons-notification-anchor =
    .tooltiptext = 開啟附加元件安裝訊息面板
urlbar-search-tips-confirm = 好的，知道了
urlbar-search-tips-confirm-short = 知道了！
urlbar-result-menu-button =
    .title = 開啟選單
urlbar-result-menu-button-feedback = 意見回饋
    .title = 開啟選單
urlbar-result-menu-learn-more2 = 了解更多
    .accesskey = L
urlbar-result-menu-remove-from-history2 = 從紀錄移除
    .accesskey = Ｒ
urlbar-result-menu-tip-get-help2 = 取得幫助
    .accesskey = h
urlbar-result-menu-dismiss-suggestion2 = 忽略此建議
    .accesskey = D
urlbar-result-menu-remove-top-site = 移除此熱門網站
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = 管理 { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = 回報位置不準確
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = 減少顯示
    .accesskey = f
urlbar-result-menu-dont-show-weather-suggestions3 = 不要顯示天氣建議
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = 回報位置不準確
urlbar-result-menu-show-less-frequently2 = 減少顯示
urlbar-result-menu-dont-show-weather-suggestions2 = 不要顯示天氣建議
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = 忽略此建議
    .accesskey = i
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = 從紀錄移除
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = 了解更多
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = 從紀錄移除
    .accesskey = Ｒ
urlbar-result-menu-tip-get-help =
    .label = 取得幫助
    .accesskey = h
urlbar-result-menu-dismiss-suggestion =
    .label = 忽略此建議
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = 管理 { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = 回報位置不準確
urlbar-result-menu-show-less-frequently =
    .label = 減少顯示
urlbar-result-menu-dont-show-weather-suggestions =
    .label = 不要顯示天氣建議
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = 開啟選單
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = 感謝您的意見回饋！
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = 感謝您的意見回饋，不再會看到天氣建議。

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = 打得更少，找到更多：直接從網址列進行 { $engineName } 搜尋。
urlbar-search-tips-redirect-2 = 在網址列進行搜尋，就可看見由 { $engineName } 及瀏覽紀錄提供的搜尋建議。
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = 使用此捷徑，讓您更快找到想要的東西。

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = 書籤
urlbar-search-mode-tabs = 分頁
urlbar-search-mode-history = 瀏覽紀錄
urlbar-search-mode-actions = 動作

##

urlbar-geolocation-blocked =
    .tooltiptext = 您已封鎖此網站取得您所在位置資訊的權限。
urlbar-localhost-blocked =
    .tooltiptext = 您已封鎖此網站對本機裝置的連線。
urlbar-local-network-blocked =
    .tooltiptext = 您已封鎖此網站對區域網路的連線。
urlbar-xr-blocked =
    .tooltiptext = 您已封鎖此網站的虛擬實境裝置存取權限。
urlbar-web-notifications-blocked =
    .tooltiptext = 您已封鎖此網站推送通知的權限。
urlbar-camera-blocked =
    .tooltiptext = 您已封鎖此網站的攝影機存取權限。
urlbar-microphone-blocked =
    .tooltiptext = 您已封鎖此網站存取您麥克風的權限。
urlbar-screen-blocked =
    .tooltiptext = 您已封鎖此網站分享您螢幕畫面的權限。
urlbar-persistent-storage-blocked =
    .tooltiptext = 您已封鎖此網站儲存資料至持續性儲存空間。
urlbar-popup-blocked2 =
    .tooltiptext = 您已封鎖此網站的彈出型視窗與第三方重新導向。
urlbar-autoplay-media-blocked =
    .tooltiptext = 您已封鎖此網站自動播放有聲音的媒體內容。
urlbar-canvas-blocked =
    .tooltiptext = 您已封鎖此網站讀取 canvas 資料的權限。
urlbar-midi-blocked =
    .tooltiptext = 您已封鎖此網站的 MIDI 存取權限。
urlbar-serial-blocked =
    .tooltiptext = 您已封鎖此網站的序列埠存取權限。
urlbar-install-blocked =
    .tooltiptext = 您已封鎖此網站安裝附加元件。
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = 編輯此書籤 ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = 將本頁加入書籤 ({ $shortcut })
urlbar-split-view-button =
    .aria-label = 分割畫面
    .tooltiptext = 分割畫面

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = 貼上並瀏覽
    .accesskey = G
urlbar-menuitem-paste-and-search =
    .label = 貼上並搜尋
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = 清除搜尋記錄
    .accesskey = h

## Page Action Context Menu

page-action-manage-extension2 =
    .label = 管理擴充套件…
    .accesskey = E
page-action-remove-extension2 =
    .label = 移除擴充套件
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = 隱藏工具列
    .accesskey = H
full-screen-exit =
    .label = 離開全螢幕模式
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = 這次使用下列搜尋引擎搜尋：
search-one-offs-change-settings-compact-button =
    .tooltiptext = 修改搜尋設定
search-one-offs-context-open-new-tab =
    .label = 在新分頁中搜尋
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = 設為預設搜尋引擎
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = 設為隱私瀏覽模式中的預設搜尋引擎
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName }（{ $alias }）
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = 新增「{ $engineName }」搜尋引擎
    .label = 新增「{ $engineName }」
    .tooltiptext = 新增「{ $engineName }」搜尋引擎
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = 新增搜尋引擎
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = 新增搜尋引擎

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = 書籤（{ $restrict }）
search-one-offs-tabs =
    .tooltiptext = 分頁（{ $restrict }）
search-one-offs-history =
    .tooltiptext = 瀏覽紀錄（{ $restrict }）
search-one-offs-actions =
    .tooltiptext = 動作（{ $restrict }）

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = 檢視附加元件
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = 擴充套件, 佈景主題, 布景主題, 附加元件, 套件, 外掛, extensions, themes, addons, add-ons
# Opens preferences page at AI controls
quickactions-manageai = 管理 AI 控制選項
quickactions-cmd-manageai = 停用 AI, 關閉 AI, 管理 AI, disable ai, off ai, manage ai
# Opens the bookmarks library window
quickactions-bookmarks2 = 管理書籤
quickactions-cmd-bookmarks = 書籤, 我的最愛, bookmarks, favorite, my favorite
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = 清除最近瀏覽記錄
quickactions-cmd-clearrecenthistory2 = Cookie, 清除 Cookie, 快取, 清除快取, 上網資料, 瀏覽資料, 網頁資料, 網站資料, 清除上網資料, 清除瀏覽資料, 清除網頁資料, 清除網站資料, 瀏覽紀錄, 瀏覽記錄, 歷史紀錄, 歷史記錄, 清除瀏覽紀錄, 清除瀏覽記錄, 清除歷史紀錄, 清除歷史記錄, cookies, clear cookies, cache, clear cache, browsing data, clear browsing data, history, clear recent history
# Opens about:downloads page
quickactions-downloads2 = 檢視下載項目
quickactions-cmd-downloads = 下載項目, 下載, downloads
# Opens about:addons page in the extensions section
quickactions-extensions = 管理擴充套件
quickactions-cmd-extensions2 = 擴充套件, 佈景主題, 布景主題, 主題, 附加元件, 套件, 外掛, extensions, addons, add-ons
# Opens Firefox View
quickactions-firefoxview = 開啟 { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = 開啟 { -firefoxview-brand-name }, { -firefoxview-brand-name }, 開啟 view, view
# Opens SUMO home page
quickactions-help = { -brand-product-name } 說明
quickactions-cmd-help = 說明, 支援, 幫助, 協助, help, support
# Opens the devtools web inspector
quickactions-inspector2 = 開啟開發者工具
quickactions-cmd-inspector2 = 檢測器, 開發者工具, inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = 挑選色彩
quickactions-cmd-colorpicker = 取色器, 挑色器, 拾色器, 顏色選擇器, 挑選顏色, 滴管, color picker, eyedropper, pick color
# Opens Firefox Library
quickactions-cmd-library = 收藏庫
quickactions-library = 開啟收藏庫
# Opens about:logins
quickactions-logins2 = 管理密碼
quickactions-cmd-logins = 登入資訊, 密碼, 帳號, logins, passwords
# Mutes all tabs playing audio
quickactions-mute = 將正在播放音訊的分頁靜音
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = 靜音,噓
# Opens the print dialog
quickactions-print2 = 列印頁面
quickactions-cmd-print = 列印, print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = 儲存頁面為 PDF 檔
quickactions-cmd-savepdf2 = PDF, 儲存頁面, 另存頁面, save page
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = 開啟 PDF 編輯器
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = 開啟隱私視窗
quickactions-cmd-private = 隱私瀏覽, 無痕模式, private browsing
# Opens a SUMO article explaining how to refresh
quickactions-refresh = 重新整理 { -brand-short-name }
quickactions-cmd-refresh = 重新整理, refresh
# Restarts the browser
quickactions-restart = 重新啟動 { -brand-short-name }
quickactions-cmd-restart = 重新啟動, 重開, restart
# Opens the screenshot tool
quickactions-screenshot3 = 拍攝畫面擷圖
quickactions-cmd-screenshot2 = 擷圖, 截圖, 擷取, 截取, 快照, screenshot, take a screenshot
# Opens about:translations
quickactions-translate = 翻譯
quickactions-cmd-translate = 翻譯, translate
# Opens about:preferences
quickactions-settings2 = 管理設定
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = 設定, 偏好設定, 選項, 管理, settings, preferences, options, manage
# Opens about:addons page in the themes section
quickactions-themes = 管理佈景主題
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = 佈景主題, 附加元件, 套件, 外掛, themes, add-ons, addons
# Opens a SUMO article explaining how to update the browser
quickactions-update = 更新 { -brand-short-name }
quickactions-cmd-update = 更新, update
# Opens the view-source UI with current pages source
quickactions-viewsource2 = 檢視原始碼
quickactions-cmd-viewsource2 = 原始碼, 檢視原始碼, 源碼, 頁面原始碼, view source, source, page source
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = 開啟 { -firefoxlabs-brand-name }
quickactions-cmd-labs = 實驗, 實驗室, 測試, 搶先, labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = 了解更多快速操作的相關資訊
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = 按 Tab 鍵選擇：

## Bookmark Panel

bookmarks-add-bookmark = 新增書籤
bookmarks-edit-bookmark = 編輯書籤
bookmark-panel-cancel =
    .label = 取消
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [1] 移除書籤
           *[other] 移除 { $count } 筆書籤
        }
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = 儲存時顯示編輯器
    .accesskey = S
bookmark-panel-save-button2 =
    .label = 儲存
    .accesskey = a
bookmark-panel-save-button =
    .label = 儲存
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = { $host } 的網站資訊
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = { $host } 的連線安全性
identity-connection-not-secure = 不安全連線
identity-connection-secure = 安全連線
identity-connection-failure = 連線失敗
identity-connection-internal = 這是安全的 { -brand-short-name } 頁面。
identity-connection-file = 此頁面位於您的電腦上。
identity-connection-associated = 此頁面是從其他頁面載入的。
identity-extension-page = 此頁面是擴充套件頁面。
identity-active-blocked = { -brand-short-name } 已經封鎖此頁面中不安全的部分。
identity-custom-root = 連線是由 Mozilla 不認識的憑證簽發者所驗證。
identity-passive-loaded = 本頁面中的部分內容（例如圖片）並不安全。
identity-active-loaded = 您已停用此頁面中的保護。
identity-weak-encryption = 此頁面使用了弱強度的加密。
identity-https-only-connection-upgraded = （升級 HTTPS）
identity-https-only-label2 = 自動將與此網站的連線升級為安全連線
identity-https-only-dropdown-on =
    .label = 開啟
identity-https-only-dropdown-off =
    .label = 關閉
identity-https-only-dropdown-off-temporarily =
    .label = 暫時關閉
identity-https-only-info-turn-on3 = 若您想要 { -brand-short-name } 盡可能升級使用安全連線，請對此網站開啟 HTTPS 升級。
identity-https-only-info-turn-off3 = 若網頁外觀看起來不正常，您可能會想要針對此網站關閉 HTTPS 升級，使用不安全的 HTTP 重新載入。
identity-https-only-info-no-upgrade = 無法將網站連線從 HTTP 升級。
identity-permissions-storage-access-header = 跨網站 Cookie
identity-permissions-storage-access-hint = 當您開啟此網站時，這些網站可以使用跨網站 Cookie，並且取得您在此網站的資料。
identity-permissions-storage-access-learn-more = 了解更多
identity-permissions-reload-hint = 您可能需要重新載入頁面才能讓變更生效。
identity-clear-site-data =
    .label = 清除 Cookie 與網站資料…
identity-connection-not-secure-security-view = 您並未安全地連線至此網站。
identity-connection-verified = 您正安全地連線至此網站。
identity-ev-owner-label2 = 憑證簽發給
identity-verifier-label2 = 驗證機構
identity-ev-owner-label = 憑證簽發給：
identity-verifier-label = 驗證機構：
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = 符合歐盟（EU）2024/1183 法規規範。
identity-description-custom-root2 = Mozilla 不認識此憑證簽發者，可能是由您的作業系統或網路管理員所加入的。
identity-cert-exception-overridden = 您已將此網站加入例外清單。
identity-remove-cert-exception =
    .label = 移除例外
    .accesskey = R
identity-description-insecure = 您對此網站的連線並不私密。發送的資訊（像是密碼、訊息、信用卡等等）可能會被其他人看到。
identity-description-weak-cipher-intro = 您與此網站間的連線使用了弱強度的加密，並不私密。
identity-description-weak-cipher-risk = 其他人可以看到您的資訊，或修改網站的行為。
identity-description-active-blocked2 = { -brand-short-name } 已經封鎖此頁面中不安全的部分。
identity-description-passive-loaded = 您的連線並不私密，提供給此網站的資訊可能會被其他人看到。
identity-description-passive-loaded-insecure2 = 此網站包含不安全的內容（例如圖片）。
identity-description-passive-loaded-mixed2 = 雖然 { -brand-short-name } 已經封鎖部分內容，但頁面中還是有不安全的內容（例如圖片）。
identity-description-active-loaded = 此網站包含不安全的內容（例如指令碼），與其之間的連線並不私密。
identity-description-active-loaded-insecure = 您提供給此網站的資訊（例如密碼、訊息、信用卡號等等）可能會被其他人看到。
identity-description-tls-key-logging-heading = 您的連線可能不私密
identity-description-tls-key-logging-message = 其他應用程式或服務可能會看到您與此網站間的加密傳輸資料。
identity-more-info-link-text =
    .label = 更多資訊

## Window controls

browser-window-minimize-button =
    .tooltiptext = 最小化
browser-window-maximize-button =
    .tooltiptext = 最大化
browser-window-restore-down-button =
    .tooltiptext = 還原大小
browser-window-close-button =
    .tooltiptext = 關閉
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = 返回

## Bookmarks toolbar items

browser-import-button2 =
    .label = 匯入書籤…
    .tooltiptext = 將其他瀏覽器的書籤匯入到 { -brand-short-name }。
bookmarks-toolbar-empty-message = 可將書籤放到這個書籤工具列上，方便快速開啟。<a data-l10n-name="manage-bookmarks">管理書籤…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = 攝影機:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = 攝影機
popup-select-microphone-device =
    .value = 麥克風:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = 麥克風
popup-select-speaker-icon =
    .tooltiptext = 音效輸出裝置
popup-select-window-or-screen =
    .label = 視窗或畫面:
    .accesskey = W
popup-all-windows-shared = 將分享您畫面上所有可見的視窗。

## WebRTC window or screen share tab switch warning

sharing-warning-window = 您正在分享 { -brand-short-name }，切換到新分頁時會被其他人看到。
sharing-warning-screen = 您正在分享完整畫面，切換到新分頁時會被其他人看到。
sharing-warning-proceed-to-tab =
    .label = 繼續前往分頁
sharing-warning-disable-for-session =
    .label = 在此階段停用分享保護

## WebSerial "select a port" popup

webserial-select-port-label = 選擇序列埠：
webserial-no-ports-available = 無序列埠可以使用

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = 關閉
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = 搜尋或輸入網址
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = 請輸入網址
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = 使用 { $name } 搜尋
    .placeholder = 搜尋 Web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = 搜尋 { $name }
    .placeholder = 輸入搜尋詞彙
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = 搜尋書籤
    .placeholder = 輸入搜尋詞彙
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = 搜尋瀏覽紀錄
    .placeholder = 輸入搜尋詞彙
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = 搜尋分頁
    .placeholder = 輸入搜尋詞彙
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = 搜尋動作
    .placeholder = 輸入搜尋詞彙
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = 使用 { $name } 搜尋或輸入網址
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = 瀏覽器正被遠端控制中（原因: { $component }）
urlbar-permissions-granted =
    .tooltiptext = 您已授予此網站更多權限。
urlbar-switch-to-tab =
    .value = 切換到分頁：
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = 擴充套件:
urlbar-go-button2 =
    .title = 按此前往網址列中的網址
urlbar-page-action-button =
    .tooltiptext = 頁面操作
urlbar-revert-button =
    .tooltiptext = 在網址列顯示網址

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = 於隱私瀏覽視窗使用 { $engine } 搜尋
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = 用隱私瀏覽視窗搜尋
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = 使用 { $engine } 進行搜尋
urlbar-result-action-sponsored = 贊助項目
urlbar-result-action-switch-tab = 切換至該分頁
urlbar-result-action-move-tab-to-split-view = 將分頁移動到分割畫面
urlbar-result-action-visit = 前往
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = 切換到分頁 · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = 未命名群組
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = 開啟剪貼簿中的網址
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = 按 Tab 鍵，使用 { $engine } 搜尋
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = 按 Tab 鍵，搜尋 { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = 從網址列直接使用 { $engine } 搜尋
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = 從網址列直接搜尋 { $engine }
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = 複製
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = 未定義
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } 擴充套件
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = 推薦
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = { $region } { $city } 氣溫 <strong>{ $temperature }°{ $unit }</strong>
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = { $country } { $region } { $city } 氣溫 <strong>{ $temperature }°{ $unit }</strong>
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = { $city } 氣溫 <strong>{ $temperature }°{ $unit }</strong>
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider }∙贊助資訊
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = 詢問
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = 您上次於 { $date } 造訪
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days = 您上次於 { $daysAgo } 天前造訪
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks = 您上次於 { $weeksAgo } 週前造訪
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months = 您上次於 { $monthsAgo } 個月前造訪
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = 您上次於 { $date } 造訪
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = 於 { $date } 加入書籤
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = 上次於{ $date }造訪
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = 上次於 { $date } 造訪
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = 上次於 { $date } 造訪

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = 直接從搜尋列中獲得股票市場資料
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = 與 { -vendor-short-name } 分享您的搜尋資料，獲得更多來自我們的夥伴的金融市場更新資訊。<a data-l10n-name="learn-more-link">更多資訊</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = 顯示搜尋建議
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = 現在不要
urlbar-result-realtime-opt-in-dismiss = 知道了！
urlbar-result-realtime-opt-in-dismiss-all2 = 不要顯示這些建議
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = 不要顯示金融市場建議
    .accesskey = n
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = 不要顯示金融市場建議
urlbar-result-realtime-opt-in-dismiss-all =
    .label = 不要顯示這些建議
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = 不要顯示金融市場建議
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = 感謝您的意見回饋，不再會看到金融市場建議。
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = 股市建議
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = 感謝您的意見回饋，不再會看到建議資訊。

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · 明天
       *[other] { $name } · { $daysUntilStart } 天後
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · 明天開始
       *[other] { $name } · { $daysUntilStart } 天後開始
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · 明天結束
       *[other] { $name } · { $daysUntilEnd } 天後結束
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · 今天
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · 今天結束

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = 使用 { $engine } 進行搜尋
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - 搜尋{ $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - 使用 { $engine } 搜尋
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }，挑選一套搜尋引擎
urlbar-searchmode-button-no-engine2 =
    .title = 未選擇捷徑，請挑選一個捷徑
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = 已停用關鍵字搜尋
urlbar-searchmode-dropmarker2 =
    .title = 挑選一套搜尋引擎
urlbar-searchmode-bookmarks4 = 書籤
urlbar-searchmode-tabs4 = 分頁
urlbar-searchmode-history4 = 瀏覽紀錄
urlbar-searchmode-actions4 = 動作
urlbar-searchmode-bookmarks3 = 書籤
    .accesskey = B
urlbar-searchmode-tabs3 = 分頁
    .accesskey = T
urlbar-searchmode-history3 = 瀏覽紀錄
    .accesskey = H
urlbar-searchmode-actions3 = 動作
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = 關閉
urlbar-searchmode-default2 =
    .title = 預設搜尋引擎
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = 新增「{ $engineName }」
    .title = 新增「{ $engineName }」搜尋引擎
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = 這次使用下列搜尋引擎搜尋：
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = 使用其他引擎搜尋：
urlbar-searchmode-popup-search-settings2 = 搜尋設定
urlbar-searchmode-popup-settings2 = 設定
urlbar-searchmode-popup-search-settings = 搜尋設定
    .accesskey = S
urlbar-searchmode-popup-settings = 設定
    .accesskey = S

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = 搜尋書籤
urlbar-result-action-search-history = 搜尋瀏覽記錄
urlbar-result-action-search-tabs = 搜尋分頁
urlbar-result-action-search-actions = 搜尋動作
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = 切換到 { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = 開啟 { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = 用新分頁開啟
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = 用新容器分頁開啟
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = 用新視窗開啟
    .accesskey = N
urlbar-view-context-menu-open-in-private-window =
    .label = 用新隱私視窗開啟
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = 用新分頁開啟
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = 用新容器分頁開啟
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = 用新視窗開啟
    .accesskey = N
urlbar-view-context-menu-open-in-private-window2 = 用新隱私視窗開啟
    .accesskey = P
urlbar-view-context-menu-search-in-tab = 在新分頁中搜尋
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = 在新容器分頁中搜尋
    .accesskey = i
urlbar-view-context-menu-search-in-window = 在新視窗中搜尋
    .accesskey = N
urlbar-view-context-menu-search-in-private-window = 在新隱私視窗中搜尋
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = 使用 Tab 鍵時略過此選單
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } 建議
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = 快速操作
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = 最近搜尋內容
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } 上的熱門趨勢
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = 不要顯示搜尋趨勢
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = 不要顯示搜尋趨勢
    .accesskey = D
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = 不要顯示搜尋趨勢
    .accesskey = D
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = 感謝您的意見回饋，不再會看到熱門搜尋趨勢。

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = 進入閱讀畫面
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = 關閉閱讀畫面

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = 開啟子母畫面（{ $shortcut }）
picture-in-picture-urlbar-button-close =
    .tooltiptext = 關閉子母畫面（{ $shortcut }）
picture-in-picture-panel-header = 子母畫面
picture-in-picture-panel-headline = 此網站不建議使用子母畫面功能
picture-in-picture-panel-body = 開啟子母畫面功能時，影片可能無法如開發者所預期的顯示。
picture-in-picture-enable-toggle =
    .label = 還是開啟

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 已進入全螢幕模式
fullscreen-warning-no-domain = 此文件已進入全螢幕模式
fullscreen-exit-button = 離開全螢幕模式（Esc）
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = 離開全螢幕模式（Esc）
fullscreen-keyboardlock-exit-button = 結束全螢幕（長按 Esc 鍵）
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = 結束全螢幕（長按 esc 鍵）
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 可控制您的滑鼠游標，按 Esc 取回控制權。
pointerlock-warning-no-domain = 此文件可控制您的滑鼠游標，按 Esc 取回控制權。

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = 管理書籤
bookmarks-recent-bookmarks-panel-subheader = 最近加入的書籤
bookmarks-toolbar-chevron =
    .tooltiptext = 顯示更多書籤
bookmarks-sidebar-content =
    .aria-label = 書籤
bookmarks-menu-button =
    .label = 書籤選單
bookmarks-other-bookmarks-menu =
    .label = 其他書籤
bookmarks-mobile-bookmarks-menu =
    .label = 行動書籤

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] 隱藏書籤側邊欄
           *[other] 檢視書籤欄
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] 隱藏書籤工具列
           *[other] 檢視書籤工具列
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] 隱藏書籤工具列
           *[other] 顯示書籤工具列
        }

##

bookmarks-search =
    .label = 搜尋書籤
bookmarks-tools =
    .label = 書籤工具
bookmarks-subview-edit-bookmark =
    .label = 編輯此書籤…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = 書籤
    .toolbarname = 書籤工具列
    .accesskey = B
bookmarks-toolbar-menu =
    .label = 書籤工具列
bookmarks-toolbar-placeholder =
    .title = 書籤工具列項目
bookmarks-toolbar-placeholder-button =
    .label = 書籤工具列項目
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = 將目前分頁加入書籤…

## Library Panel items

library-bookmarks-menu =
    .label = 書籤

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = 修復文字編碼
    .tooltiptext = 根據訊息內容猜測正確的文字編碼

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = 設定
    .tooltiptext =
        { PLATFORM() ->
            [macos] 開啟設定頁面（{ $shortcut }）
           *[other] 開啟設定頁面
        }
toolbar-overflow-customize-button =
    .label = 自訂工具列…
    .accesskey = C
toolbar-button-email-link =
    .label = 寄送鏈結
    .tooltiptext = 寄出本頁面的鏈結
toolbar-button-logins =
    .label = 密碼
    .tooltiptext = 檢視與管理您儲存的密碼
qrcode-panel-error =
    .message = QR Code 產生失敗，請再試一次。
qrcode-copy-button =
    .label = 複製
qrcode-copy-success =
    .message = 已將 QR Code 複製至剪貼簿。
qrcode-copy-error =
    .message = QR Code 複製失敗。
qrcode-save-button =
    .label = 儲存
qrcode-window-title = QR Code
qrcode-dialog-title = QR Code
qrcode-image =
    .aria-label = QR Code
qrcode-close-button =
    .aria-label = 關閉
toolbar-button-save-page =
    .label = 儲存本頁
    .tooltiptext = 儲存此頁面 ({ $shortcut })
toolbar-button-open-file =
    .label = 開啟檔案
    .tooltiptext = 開啟檔案（{ $shortcut }）
toolbar-button-synced-tabs =
    .label = 同步的分頁
    .tooltiptext = 顯示來自其他裝置的分頁
toolbar-button-send-tab =
    .label = 傳送分頁
    .tooltiptext = 將目前分頁傳送到另一台裝置
toolbar-button-new-private-window =
    .label = 開新隱私視窗
    .tooltiptext = 新增隱私瀏覽視窗 ({ $shortcut })
toolbar-button-share-tab =
    .label = 分享
    .tooltiptext = 分享此頁面
toolbar-button-tab-groups =
    .label = 分頁群組
    .tooltiptext = 顯示您的分頁群組
toolbar-button-history =
    .label = 瀏覽紀錄
    .tooltiptext = 顯示您的瀏覽紀錄（{ $shortcut }）
toolbar-button-find =
    .label = 尋找
    .tooltiptext = 在此頁面中尋找（{ $shortcut }）
toolbar-button-developer =
    .label = 開發者
    .tooltiptext = 開啟網頁開發者工具（{ $shortcut }）
toolbar-button-forget =
    .label = 忘記
    .tooltiptext = 忘掉一些瀏覽紀錄
toolbar-zoom-controls =
    .label = 縮放控制
    .title = 縮放控制
toolbar-button-zoom-out =
    .label = 縮小
    .tooltiptext = 縮小（{ $shortcut }）
toolbar-button-zoom-reset-tooltip = 重設頁面縮放大小（{ $shortcut }）
toolbar-button-zoom-in =
    .label = 放大
    .tooltiptext = 放大（{ $shortcut }）
toolbar-edit-controls =
    .label = 編輯控制元件
    .title = 編輯控制
toolbar-button-cut =
    .label = 剪下
    .tooltiptext = 剪下（{ $shortcut }）
toolbar-button-copy =
    .label = 複製
    .tooltiptext = 複製（{ $shortcut }）
toolbar-button-paste =
    .label = 貼上
    .tooltiptext = 貼上（{ $shortcut }）

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = 此網站的某些影音內容需要使用 DRM 軟體，可能會限制 { -brand-short-name } 能讓您使用的功能。
eme-notifications-drm-content-playing-manage = 管理設定
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = 知道了！
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = 您必須開啟 DRM 才能播放此頁面中的某些影音內容。
eme-notifications-drm-content-disabled-button =
    .label = 開啟 DRM
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } 正在安裝讓您播放此頁面中的影音內容的元件，請稍後再試。
decoder-doctor-no-codecs-linux-message = 您可能需要安裝必需的視訊解碼器才能播放影片。
decoder-doctor-no-hw-acceleration-message = 若要改善影片播放品質，您可能需要安裝微軟的 Media Feature Pack。
decoder-doctor-no-pulse-audio-message = 要播放音效，您可能必須安裝 PulseAudio 軟體套件。
decoder-doctor-unsupported-libavcodec-message = libavcodec 可能不安全或不受支援，要用來播放影片前請先更新。
decoder-doctor-decode-error-message = 解碼媒體資源時發生錯誤。
decoder-doctor-decode-warning-message = 解碼媒體資源時發生可恢復的錯誤。
decoder-doctor-learn-how-link = 了解要怎麼做
decoder-doctor-report-issue-button =
    .label = 回報網站問題
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = { $pluginName } 外掛程式發生錯誤，已經關閉。
plugin-crashed-notification-reload-button =
    .label = 重新載入網頁
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = 送出一份錯誤報告
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = 詐騙網站！
safebrowsing-reported-attack-site-message = 這是已知的有害網站！
safebrowsing-reported-unwanted-site-message = 已檢舉為不安全的軟體網站！
safebrowsing-reported-harmful-site-message = 已檢舉為有害網站！
safebrowsing-get-me-out-of-here-button =
    .label = 帶我離開這裡！
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = 這不是詐騙網站…
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = 這不是有害網站…
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = 您必須先登入才能瀏覽網際網路。
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = 開啟網路登入頁面

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = 您是不是要去 { $hostName }？
keyword-uri-fixup-go-to-button =
    .label = 是，請帶我到 { $hostName }
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = 使用者名稱
panel-save-update-password-2 =
    .label = 密碼

##

# "More" item in macOS share menu
menu-share-more =
    .label = 更多…
menu-share-windows =
    .label = 更多選項
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] 複製鏈結
           *[other] 複製 { $count } 個鏈結
        }
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = 關閉

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = 允許 { $uriHost } 的彈出型視窗與第三方重新導向
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = 隱藏子母畫面切換按鈕
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = 將子母畫面切換按鈕移到右側
    .accesskey = R
picture-in-picture-move-toggle-left =
    .label = 將子母畫面切換按鈕移到左側
    .accesskey = L

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = 導覽
navbar-downloads =
    .label = 下載
navbar-overflow-2 =
    .tooltiptext = 更多工具
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = 列印
    .tooltiptext = 列印此頁面… ({ $shortcut })
navbar-home =
    .label = 首頁
    .tooltiptext = { -brand-short-name } 首頁
navbar-library =
    .label = 收藏庫
    .tooltiptext = 檢視瀏覽紀錄、已存書籤等資料
navbar-search =
    .title = 搜尋
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = 瀏覽器分頁
tabs-toolbar-new-tab =
    .label = 開新分頁
tabs-toolbar-list-all-tabs-2 =
    .label = 搜尋與管理分頁
    .tooltiptext = 搜尋與管理分頁
tabs-toolbar-list-all-tabs =
    .label = 列出所有分頁
    .tooltiptext = 列出所有分頁

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = 將分頁放到此處即可釘選

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>想開啟先前的分頁？</strong>您可以從 { -brand-short-name } 應用程式選單 <img data-l10n-name="icon"/> 當中的「歷史」重新開啟先前的瀏覽階段。
restore-session-startup-suggestion-button = 告訴我如何作

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = 您的組織已封鎖存取此電腦中的本機檔案。

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } 現在也會搜尋分頁
urlbar-addons-shortcut-moved-description = 若要開啟擴充套件與佈景主題，請按下 { $addonsShortcut }。
urlbar-addons-shortcut-moved-change-shortcuts = 管理快速鍵
urlbar-addons-shortcut-moved-dismiss = 知道了！

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } 將會自動傳送一些資料給 { -vendor-short-name }，讓我們能夠改善您的使用體驗。
data-reporting-notification-button =
    .label = 選擇我要分享的項目
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = 隱私瀏覽
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = 隱私瀏覽模式
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = 隱私瀏覽資訊
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = 您在隱私瀏覽視窗當中
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = 此功能可幫助您隱藏本裝置上的瀏覽紀錄，不被其他人看見，但無法讓您在網路上完全隱身。<a data-l10n-name="learn-more">還有誰可能看得到我的上網行為？</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = 由 { $agentName } 提供資料遺失保護（DLP）功能。點擊此處即可取得更多資訊。
content-analysis-panel-title2 = 資料外洩防護
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = 您的組織使用 <b>{ $agentName }</b> 來控制敏感資料的分享方式。<a data-l10n-name="info">更多資訊</a>
content-analysis-panel-title = 資料保護
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = 您的組織使用 <b>{ $agentName }</b> 來防止資料遺失。<a data-l10n-name="info">更多資訊</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = 擴充套件
    .tooltiptext = 擴充套件

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = 擴充套件
    .tooltiptext = 擴充套件需要權限

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = 擴充套件
    .tooltiptext =
        擴充套件
        不允許某些擴充套件

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = 擴充套件
    .tooltiptext =
        擴充套件
        某些擴充套件已停用

## Private browsing reset button

reset-pbm-panel-heading2 = 要清除資料並重新開始隱私瀏覽階段嗎？
reset-pbm-panel-description3 = 將清除您的瀏覽紀錄與 Cookie，並將您從網站登出。將關閉您的隱私視窗並重新開啟新視窗。
reset-pbm-panel-description2 = 不用關閉隱私瀏覽視窗，即可清除瀏覽紀錄、Cookie 以及所有其他網站資料。
reset-pbm-panel-always-ask-checkbox =
    .label = 每次都問我
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = 取消
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = 清除隱私瀏覽階段
    .accesskey = l
reset-pbm-panel-complete = 已刪除瀏覽階段資料
reset-pbm-toolbar-button2 =
    .label = 清除隱私瀏覽階段
    .tooltiptext = 清除隱私瀏覽階段

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = 要刪除所有瀏覽資料嗎？
fire-button-panel-description = 將清除瀏覽紀錄、Cookie 與網站資料，並將您登出所有網站。此視窗將會關閉，接著 { -brand-short-name } 會開啟新視窗。
fire-button-panel-choose-description = 若不想刪除所有資料，可以只選擇特定資料進行刪除。
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = 選擇…
fire-button-panel-cancel-button =
    .label = 取消
    .accesskey = C
fire-button-panel-confirm-button =
    .label = 全部刪除
    .accesskey = D
fire-button-panel-complete = 已刪除瀏覽資料
fire-button-toolbar-button2 =
    .label = 刪除部分或全部資料
    .tooltiptext = 刪除您部分或全部的瀏覽資料

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } 已阻止本頁面自動重新載入。
refresh-blocked-redirect-label = { -brand-short-name } 已阻止本頁面自動重新導向到其他網頁。
refresh-blocked-allow =
    .label = 允許
    .accesskey = A

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = 我們安全易用的轉寄信箱，可隱藏您的實際信箱，並保護您的身分並防止垃圾信入侵。
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = 所有寄到您的轉寄信箱中的郵件，將會再轉寄到 <strong>{ $useremail }</strong>，除非您決定要封鎖此轉寄信箱。
firefox-relay-offer-legal-notice = 若點擊「使用轉寄信箱」，代表您同意<label data-l10n-name="tos-url">服務條款</label>與<label data-l10n-name="privacy-url">隱私權公告</label>。
firefox-relay-offer-legal-notice-1 = 若註冊並建立轉寄信箱，代表您同意<label data-l10n-name="tos-url">服務條款</label>與<label data-l10n-name="privacy-url">隱私權公告</label>。

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = （未驗證）
popup-notification-xpinstall-prompt-learn-more = 了解如何於安裝附加元件時確保安全的更多資訊
popup-notification-xpinstall-prompt-block-url = 檢視詳細資訊
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = 允許擴充套件於隱私瀏覽視窗中執行
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = 分享技術與互動資料給擴充套件開發者
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [1] { -brand-short-name } 封鎖了此網站開啟的彈出型視窗。
       *[other] { -brand-short-name } 封鎖了此網站的 { $popupCount } 個彈出型視窗。
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } 封鎖了此網站的重新導向。
        [1] { -brand-short-name } 封鎖了此網站的彈出型視窗與重新導向。
       *[other] { -brand-short-name } 封鎖了此網站的 { $popupCount } 個彈出型視窗與重新導向。
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } 封鎖了此網站開啟超過 { $popupCount } 個彈出型視窗。
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message = { -brand-short-name } 已封鎖此網站超過 { $popupCount } 個彈出型視窗與重新導向。
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] 選項
           *[other] 偏好設定
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = 顯示「{ $popupURI }」
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = 顯示「{ $redirectURI }」

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = 無法開啟 Windows 檔案對話框，無法選擇任何檔案或資料夾。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = 無法開啟 Windows 檔案對話框，檔案將儲存至 { $path }。
file-picker-failed-save-nowhere = 無法開啟 Windows 檔案對話框，找不到預設資料夾，無法儲存檔案。
file-picker-crashed-open = Windows 檔案對話框發生錯誤，無法選擇任何檔案或資料夾。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows 檔案對話框發生錯誤，檔案將儲存至 { $path }。
file-picker-crashed-save-nowhere = Windows 檔案對話框發生錯誤，找不到預設資料夾，無法儲存檔案。
file-picker-crashed-show-in-folder =
    .label = 於資料夾顯示
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = 已安裝的附加元件中有一組以上尚未通過驗證，已被停用。
unsigned-addons-disabled-learn-more =
    .label = 了解更多
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = 這張網頁讓您的 { -brand-short-name } 變慢了，可停止處理這張網頁，恢復原本的速度。
process-hang-nonspecific-tab-message = 有張網頁讓您的 { -brand-short-name } 變慢了，可停止處理該網頁，恢復原本的速度。
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = 「{ $title }」讓您的 { -brand-short-name } 變慢了，可停止處理該網頁，恢復原本的速度。
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = 「{ $addonName }」讓您的 { -brand-short-name } 變慢了，可停止處理該擴充套件，恢復原本的速度。
process-hang-addon-learn-more =
    .value = 了解更多
process-hang-stop-button =
    .label = 停止
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = 完成設定
onboarding-aw-finish-setup-button =
    .label = 完成設定
    .tooltiptext = 完成設定 { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = 已開啟加強型追蹤保護
trustpanel-etp-label-disabled = 已關閉加強型追蹤保護
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = 加強型追蹤保護：對 { $host } 開啟
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = 加強型追蹤保護：對 { $host } 關閉
trustpanel-etp-description-enabled = 若此網站功能異常，可嘗試關閉保護。
trustpanel-etp-description-disabled = { -brand-product-name } 認為大企業們應該少追蹤您一點。開啟保護後，我們會盡可能封鎖追蹤器。
trustpanel-trackercount-label = 在網址列顯示追蹤器封鎖數量
trustpanel-trackercount-toggle =
    .aria-label = 在網址列顯示追蹤器封鎖數量
trustpanel-connection-label-secure = 連線安全
trustpanel-connection-label-insecure = 連線不安全
trustpanel-header-enabled = { -brand-product-name } 警戒中
trustpanel-description-enabled2 = 您已受到保護，若我們發現某些不安全的地方會再通知您。
trustpanel-header-enabled-insecure = 在此網站請小心
trustpanel-description-enabled-insecure = { -brand-product-name } 發現某些東西有點可疑。
trustpanel-header-disabled = 您已關閉保護
trustpanel-description-disabled = 已關閉 { -brand-product-name } 的追蹤保護，建議您重新開啟。
trustpanel-clear-cookies-button = 清除 Cookie 與網站資料
trustpanel-privacy-link = 隱私權設定
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = 清除 { $host } 的 Cookie 與網站資料
trustpanel-clear-cookies-description = 清除 Cookie 與網站資料，可能會將您從某些網站登出，或清除購物車內容。
trustpanel-clear-cookies-subview-button-clear = 清除
trustpanel-clear-cookies-subview-button-cancel = 取消
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = { $host } 的連線保護
trustpanel-siteinformation-morelink = 更多網站資訊
trustpanel-blocker-see-all = 檢視全部
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = { $host } 的追蹤保護
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = 不安全
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label = 已封鎖 { $count } 組追蹤器

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } 認為大企業們應該少追蹤您一點，我們會盡可能封鎖追蹤器。
trustpanel-blocked-header = { -brand-product-name } 為您封鎖了下列項目：
trustpanel-tracking-header = { -brand-product-name } 放行了下列項目，讓網站不致於故障：
trustpanel-tracking-description = 如果完全沒有追蹤器，某些按鈕、表單、登入欄位可能無法運作。
trustpanel-insecure-section-header = 您的連線並不安全
trustpanel-insecure-description = 您傳送到此網站的資料未經加密，可能會被其他人檢視、竊取、竄改。
trustpanel-list-label-tracking-cookies = { $count } 個跨網站追蹤 Cookie
trustpanel-list-label-tracking-content = 追蹤用內容
trustpanel-list-label-fingerprinter = { $count } 個數位指紋追蹤程式
trustpanel-list-label-social-tracking = { $count } 個社群網路追蹤器
trustpanel-list-label-cryptominer = { $count } 個加密貨幣採礦程式
trustpanel-social-tracking-blocking-tab-header = { -brand-product-name } 已封鎖 { $count } 個社群網路追蹤器
trustpanel-social-tracking-not-blocking-tab-header = { -brand-product-name } 已放行 { $count } 個社群網路追蹤器
trustpanel-tracking-cookies-blocking-tab-header = { -brand-product-name } 已封鎖 { $count } 個跨網站追蹤 Cookie
trustpanel-tracking-cookies-not-blocking-tab-header = { -brand-product-name } 已放行 { $count } 個跨網站追蹤 Cookie
trustpanel-tracking-content-blocking-tab-header = { -brand-product-name } 已封鎖 { $count } 組追蹤器
trustpanel-tracking-content-not-blocking-tab-header = { -brand-product-name } 已放行 { $count } 組追蹤器
trustpanel-tracking-content-tab-list-header = 下列網站嘗試追蹤您：
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name } 已封鎖 { $count } 組數位指紋追蹤程式
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name } 已放行 { $count } 組數位指紋追蹤程式
trustpanel-fingerprinter-list-header = 下列網站嘗試對您建立數位指紋：
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name } 已封鎖 { $count } 組加密貨幣採礦程式
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name } 已放行 { $count } 組加密貨幣採礦程式
trustpanel-cryptominer-tab-list-header = 下列網站嘗試挖礦：
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = 有在這個網站註冊過帳號嗎？
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } 發現此網站在過去 12 個月內曾發生資料外洩事件，看看您是否受到影響。
trustpanel-breachalerts-anonymous-breached-button-dismiss = 知道了！
trustpanel-breachalerts-anonymous-breached-button-check-monitor = 進行免費掃描
trustpanel-blocker-section-header2 = 已封鎖此網站上的 <span data-l10n-name="count">{ $count }</span> 組追蹤器

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>網站看來怪怪的？</strong>請重新載入頁面以暫時降低追蹤保護等級。
reduced-protection-infobar-reload-button = 重新載入
    .accesskey = R
reduced-protection-infobar-never-show-button = 不要再顯示
    .accesskey = D


identity-allow-site-data = vOrbit-lite：始終為本網站儲存 cookie/數據
urlbar-webgl-notification-anchor =
    .tooltiptext = 管理 WebGL 環境創建權限
urlbar-webgl-blocked =
    .tooltiptext = 您已阻止此網站創建 WebGL 環境。
