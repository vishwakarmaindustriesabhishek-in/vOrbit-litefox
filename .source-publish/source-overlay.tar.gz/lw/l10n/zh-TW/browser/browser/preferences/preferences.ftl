# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = 告訴網站不要銷售或分享我的資料
    .accesskey = s
non-technical-privacy-group =
    .label = 網站隱私權偏好設定
do-not-track-removal3 =
    .message = 我們不再支援「Do Not Track」功能
non-technical-privacy-heading =
    .label = 其他保護
preferences-privacy-relay-available =
    .description = 隱藏您的實際電子郵件地址，避免收到垃圾信。
    .label = 建議 { -relay-brand-name } 轉寄信箱
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = 設定
category-nav-heading =
    .heading = 設定
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = 搜尋選項
    .style = width: 15.4em
managed-notice = 您的瀏覽器受到組織管理。
managed-notice-info-icon =
    .alt = 資訊
managed-notice-nav =
    .label = 您的瀏覽器受到組織管理。
tls-key-logging-notice-nav =
    .label = 其他應用程式或服務可能會看到您的加密傳輸資料。
category-list =
    .aria-label = 分類
pane-general-title = 一般
pane-home-title = 首頁
pane-home-startup-title2 = 首頁與啟動
    .title = 首頁與啟動
pane-search-title2 = 搜尋
    .title = 搜尋
pane-privacy-title3 = 隱私權與安全性
    .title = 隱私權與安全性
pane-privacy-section =
    .heading = 隱私權與安全性
pane-sync-title3 = 同步
pane-ai-controls-title2 = AI 控制
    .title = AI 控制
pane-about-firefox-title = 關於 { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = 外觀設定
    .title = { pane-appearance-title }
pane-downloads-title2 = 下載
    .title = 下載
pane-downloads3 =
    .heading = 下載
pane-accessibility-title = 輔助功能
    .title = { pane-accessibility-title }
pane-languages-title2 = 語言
    .title = 語言
preferences-languages-header3 =
    .heading = 語言
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = 請試用看看我們實驗中的功能！這些功能仍在開發進化中，可能會影響 { -brand-short-name } 的運作。若您開啟捕捉<a data-l10n-name="data-collection">技術與互動資料</a>，我們則會接收您對這些功能的使用方式資料。
pane-experimental-reset =
    .label = 回復為預設值
    .accesskey = R
help-button-label2 = { -brand-short-name } 技術支援
    .title = { -brand-short-name } 技術支援
addons-button-label2 = 擴充套件與佈景主題
    .title = 擴充套件與佈景主題
focus-search =
    .key = f
close-button =
    .aria-label = 關閉
do-not-track-removal2 =
    .label = 我們不再支援「Do Not Track」訊號
applications-setting-new-file-types =
    .label = { -brand-short-name } 應如何處理其他檔案？

## Browser Restart Dialog

feature-enable-requires-restart = 必須重新啟動 { -brand-short-name } 才能啟用此功能。
feature-disable-requires-restart = 必須重新啟動 { -brand-short-name } 才能停用此功能。
should-restart-title = 重新啟動 { -brand-short-name }
should-restart-ok = 立刻重新啟動 { -brand-short-name }
cancel-no-restart-button = 取消
restart-later = 稍後再重新啟動

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> 此設定受 <strong>{ $name }</strong> 控制。
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> 此設定受 <strong>{ $name }</strong> 控制。
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = 使用 <img data-l10n-name="icon"/> <strong>{ $name }</strong> 必須開啟容器分頁功能。
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> 此設定受 <strong>{ $name }</strong> 控制。
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name="icon"/> <strong>{ $name }</strong> 會控制 { -brand-short-name } 連線到網際網路的方式。
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = 要啟用這套擴充套件，請到 <img data-l10n-name="menu-icon"/> 選單中的 <img data-l10n-name="addons-icon"/> 附加元件。
extension-controlled-enable-2 = 請到<a data-l10n-name="addons-link">擴充套件與佈景主題</a>重新啟用此擴充套件。
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } 會控制您的部分首頁設定。

## Preferences UI Search Results

search-results-header = 搜尋結果
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = 抱歉！沒有「<span data-l10n-name="query"></span>」的選項搜尋結果。
search-results-help-link = 需要幫忙嗎？請到 <a data-l10n-name="url">{ -brand-short-name } 技術支援</a>

## General Section

always-check-default =
    .label = 總是檢查 { -brand-short-name } 是否為您的預設瀏覽器
    .accesskey = w
startup-restore-windows-and-tabs =
    .label = 開啟先前的視窗與分頁
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = 勾選「選擇使用者設定檔」視窗中的「{ profile-manager-use-selected.label }」開啟此設定。
windows-launch-on-login =
    .label = 電腦開機時自動開啟 { -brand-short-name }
    .accesskey = O
windows-launch-on-login-disabled = 已在 Windows 停用此偏好設定。若要變更，請到系統設定中的<a data-l10n-name="startup-link">啟動應用程式</a>頁面調整設定。
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = 也開啟新分頁
    .accesskey = n
disable-extension =
    .label = 停用擴充套件
preferences-data-migration-group =
    .description = 從其他瀏覽器匯入您的書籤、密碼、上網紀錄、擴充套件、表單自動填寫資料。
    .label = 匯入瀏覽器資料
preferences-data-migration-button =
    .label = 匯入資料
    .accesskey = m
preferences-profiles-group-header =
    .heading = 設定檔
preferences-profiles-subpane-description =
    .description = 每套設定檔的瀏覽資料與設定（包含瀏覽紀錄、網頁密碼等等）各自獨立，不互相影響。
preferences-profiles-section-header =
    .description = 每套設定檔的上網資料與設定（包含瀏覽紀錄、網頁密碼等等）各自獨立，不互相影響。
    .label = 設定檔
preferences-manage-profiles-button =
    .label = 管理設定檔
preferences-profiles-settings-button =
    .label = 設定
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = 將從您現有設定檔複製設定、附加元件、瀏覽紀錄、書籤密碼等儲存的資料，但不會複製登入的帳號或同步資訊。
    .label = 複製現有設定檔
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = 要複製的設定檔
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = 選擇設定檔
preferences-copy-profile-button = 複製
tabs-browsing-section =
    .heading = 分頁與瀏覽
pane-tabs-browsing-title2 = 分頁與瀏覽
    .title = 分頁與瀏覽
tabs-group-header2 =
    .label = 分頁
tabs-opening-heading =
    .label = 開啟
tabs-interaction-heading =
    .label = 互動
tabs-containers-heading =
    .label = 容器
tabs-closing-heading =
    .label = 關閉
ctrl-tab-recently-used-order =
    .label = 按下 Ctrl+Tab 時，依照最近使用分頁的順序切換分頁標籤
    .accesskey = T
open-new-link-as-tabs =
    .label = 以分頁開啟鏈結，而不使用新視窗
    .accesskey = w
open-external-link-next-to-active-tab =
    .label = 將應用程式開啟的分頁，開啟於目前瀏覽分頁旁
ask-on-close-multiple-tabs =
    .label = 關閉多個分頁前先問我
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = 按 { $quitKey } 離開之前先問我
    .accesskey = b
warn-on-open-many-tabs =
    .label = 開啟多個分頁時，警告我可能會拖慢 { -brand-short-name }
    .accesskey = d
switch-to-new-tabs-2 =
    .label = 用新分頁開啟鏈結或媒體內容後，自動切換至該分頁
    .accesskey = h
show-tabs-in-taskbar =
    .label = 在 Windows 工作列顯示分頁預覽圖
    .accesskey = k
browser-containers-enabled-2 =
    .label = 使用容器分頁
    .accesskey = n
browser-containers-learn-more = 了解更多
browser-containers-settings-2 =
    .label = 管理設定
    .accesskey = i
containers-disable-alert-title = 要關閉所有容器分頁嗎？
startup-group =
    .label = 啟動

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc = 若您現在停用容器分頁，將關閉 { $tabCount } 個分頁。您真的要停用容器分頁嗎？
containers-disable-alert-ok-button = 關閉 { $tabCount } 個容器分頁

##

containers-disable-alert-cancel-button = 保持開啟
containers-remove-alert-title = 要移除這個容器嗎？
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg = 若您現在移除此容器，將關閉 { $count } 個容器分頁。您確定要移除此容器嗎？
containers-remove-ok-button = 移除此容器
containers-remove-cancel-button = 不要移除此容器
settings-tabs-show-image-in-preview =
    .label = 當滑鼠移動到分頁標籤上時，顯示分頁預覽
    .accessKey = h
settings-tabs-drag-to-create-tab-groups =
    .label = 將分頁拖曳到一起，即可建立分頁群組
browser-layout-header2 =
    .label = 瀏覽器版面
browser-layout-horizontal-tabs2 =
    .description = 分頁放置於畫面頂端
    .label = 水平分頁標籤
    .title = 分頁放置於畫面頂端
browser-layout-vertical-tabs2 =
    .description = 分頁放置於側邊欄
    .label = 垂直分頁標籤
    .title = 分頁放置於側邊欄
browser-layout-show-sidebar2 =
    .description = 不用離開主畫面就能快速開啟書籤、手機上的分頁、AI 聊天機器人等功能。
    .label = 顯示側邊欄
page-navigation-group =
    .label = 頁面導航

## General Section - Language & Appearance

language-and-appearance-header = 語言與外觀
appearance-group2 =
    .description = 某些網站可依照您的偏好來調整顯示配色，請選擇您偏好的配色模式。
    .label = 網站外觀
preferences-web-appearance-choice-auto3 =
    .label = 系統
    .title = 自動依照您的系統設定與 { -brand-short-name } 佈景主題來調整網站背景與內容。
preferences-web-appearance-choice-light2 =
    .label = 亮色
    .title = 在網站背景與內容使用亮色外觀。
preferences-web-appearance-choice-dark2 =
    .label = 暗色
    .title = 在網站背景與內容使用暗色外觀。
web-appearance-group =
    .aria-label = 網站外觀
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = 您選擇的對比設定會蓋過網站外觀的配色。
preferences-web-appearance-link =
    .label = 到擴充套件與佈景主題管理 { -brand-short-name } 的佈景主題
preferences-contrast-control-group =
    .description = 網站會使用各種不同的背景色與前景色。為了維持一致的對比，可以在不同網站間使用相同的色彩。
    .label = 網站對比
preferences-contrast-control-radio-group =
    .label = 覆蓋色彩
preferences-contrast-control-use-platform-settings =
    .label = 自動（使用系統設定）
    .accesskey = A
preferences-contrast-control-off =
    .label = 關閉
    .accesskey = O
preferences-contrast-control-custom =
    .label = 自訂
    .accesskey = C
preferences-colors-manage-button2 =
    .label = 管理色彩
    .accesskey = C
preferences-colors-manage-button =
    .label = 管理色彩…
    .accesskey = C
preferences-fonts-header2 =
    .label = 字型
preferences-default-zoom-label =
    .label = 預設縮放比例
    .accesskey = z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = 只縮放文字
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = 若開啟了「只縮放文字」，且您的預設縮放比例並非 100%，某些網站可能無法正確顯示內容。
language-header = 語言
choose-language-description = 請選擇瀏覽支援多國語言的網頁時要優先顯示哪種語言
website-language-heading =
    .description = 一張網頁有時候會有不同語言的版本，請選擇要顯示的語言版本順序。
    .label = 網站語言
website-preferred-language =
    .label = 偏好語言
website-language-list =
    .aria-label = 偏好語言
website-add-language =
    .label = 新增語言
website-add-language-button =
    .aria-label = 新增選擇的語言
    .title = 新增選擇的語言
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = 移除 { $locale }
    .title = 移除 { $locale }
choose-button =
    .label = 選擇…
    .accesskey = o
choose-browser-language-description = 請選擇 { -brand-short-name } 要用來顯示選單、介面訊息以及通知內容的語言。
manage-browser-languages-button =
    .label = 設定其他語言…
    .accesskey = l
confirm-browser-language-change-description = 重新啟動 { -brand-short-name } 來套用變更
confirm-browser-language-change-button = 套用並重新啟動
browser-language-heading =
    .description = 請選擇 { -brand-short-name } 要用來顯示選單、訊息、通知的語言。
    .label = 瀏覽器語言
browser-language-preferred-label =
    .label = 偏好語言
browser-language-fallback-label =
    .description = 當偏好使用的語言在地化不完整時，所使用的備用語言
    .label = 備用語言
browser-language-install-error =
    .message = { -brand-short-name } 目前無法更新您的語言套件。請確認您是否已連線至網際網路，或可再試一次。
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = 例外網站…
    .accesskey = x
settings-translations-header =
    .aria-label = 翻譯
    .description = 翻譯頁面或選擇的文字。為了保護隱私，翻譯會保存在您的裝置上。
    .label = 翻譯
settings-translations-offer-to-translate-label =
    .label = 提供全頁翻譯
settings-translations-more-settings-button =
    .description = 設定語言、網站、離線翻譯的偏好設定。
    .label = 更多翻譯設定
settings-translations-subpage-header =
    .heading = 更多翻譯設定
settings-translations-subpage-speed-up-translation-header =
    .description = 下載完整翻譯套件，以離線翻譯，也能更快完成。
    .label = 加速翻譯
settings-translations-subpage-automatic-translation-header =
    .label = 自動翻譯
settings-translations-subpage-always-translate-header =
    .label = 總是翻譯下列語言
settings-translations-subpage-never-translate-header =
    .label = 永不翻譯下列語言
settings-translations-subpage-never-translate-sites-header =
    .label = 永不翻譯下列網站
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = 若要新增網站，開啟 <img data-l10n-name="translations-icon"/> 翻譯面板，選擇 <img data-l10n-name="settings-icon"/> 翻譯設定，然後選擇「永不翻譯此網站」
settings-translations-subpage-language-select-option =
    .label = 新增語言
settings-translations-subpage-language-add-button =
    .aria-label = 新增語言
    .title = 新增語言
settings-translations-subpage-download-languages-header =
    .label = 下載語言
settings-translations-subpage-download-languages-select-option =
    .label = 選擇語言
settings-translations-subpage-download-languages-button =
    .aria-label = 下載語言
    .title = 下載語言
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language }（{ $size }MB）
    .label = { $language }（{ $size }MB）
settings-translations-subpage-no-languages-downloaded =
    .label = 未下載語言
settings-translations-subpage-no-languages-added =
    .label = 未新增語言
settings-translations-subpage-download-progress = 下載中…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = 無法下載 { $language }（{ $size }MB）
settings-translations-subpage-download-retry-button =
    .label = 重試
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = 要刪除 { $language }（{ $size }MB）嗎？
settings-translations-subpage-download-delete-button =
    .label = 刪除
settings-translations-subpage-download-cancel-button =
    .label = 取消
settings-translations-subpage-no-sites-added =
    .label = 未新增網站
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = 使用您作業系統的「{ $localeName }」語系來顯示日期、時間、數字、單位。
settings-spellcheck-header =
    .label = 拼字檢查
check-user-spelling =
    .label = 打字時即時檢查拼字
    .accesskey = t
spellcheck-download-dictionaries =
    .label = 下載字典套件
spellcheck-promo =
    .heading = 如何進行拼字檢查
    .message = 對文字欄位按右鍵，即可開關拼字檢查功能或更改語言。不是所有輸入欄位都支援拼字檢查。

## Downloads - Files and applications

files-and-applications-title = 檔案與應用程式
download-save-files-header =
    .label = 儲存檔案到
download-save-where-3 =
    .aria-label = 儲存檔案到
download-always-ask-where2 =
    .label = 下載檔案前，先詢問要將檔案儲存至何處。
    .accesskey = A
download-private-browsing-delete2 =
    .label = 關閉隱私視窗時清除下載項目
    .accesskey = D
applications-header = 應用程式
applications-description = 選擇 { -brand-short-name } 要如何處理您上網時下載的檔案。
applications-setting2 =
    .description = 選擇 { -brand-short-name } 要如何處理下載的檔案與內容。
    .label = 檔案與應用程式
applications-filter =
    .placeholder = 搜尋檔案類型或應用程式
applications-type-column =
    .label = 內容類型
    .accesskey = t
applications-type-heading = 內容類型
applications-action-column =
    .label = 動作
    .accesskey = A
applications-action-heading = 動作
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } 檔案
applications-action-save =
    .label = 儲存檔案
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = 使用 { $app-name } 開啟
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = 使用 { $app-name } 開啟（預設）
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] 使用 macOS 預設應用程式
            [windows] 使用 Windows 預設應用程式
           *[other] 使用系統預設應用程式
        }
applications-use-other =
    .label = 使用其他程式…
applications-select-helper = 選取對應程式
applications-manage-app =
    .label = 程式詳細資訊…
applications-always-ask =
    .label = 總是詢問
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description }（{ $type }）
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending }（{ $type }）
applications-open-inapp =
    .label = 用 { -brand-short-name } 開啟

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = { -brand-short-name } 應如何處理其他檔案？
applications-save-for-new-types =
    .label = 儲存檔案
    .accesskey = S
applications-save-for-new-types2 =
    .label = 自動儲存檔案
    .accesskey = S
applications-ask-before-handling =
    .label = 詢問要直接開啟還是儲存檔案
    .accesskey = A
applications-ask-before-handling2 =
    .label = 詢問要直接開啟還是儲存檔案
    .accesskey = A
drm-group =
    .label = 數位權利管理（DRM）內容
play-drm-content =
    .label = 播放 DRM 內容
    .accesskey = P
play-drm-content-learn-more = 了解更多
# Variables:
# $version (string) - Firefox version
update-application-version = { $version } 版<a data-l10n-name="learn-more">有什麼新鮮事</a>
update-history-2 =
    .label = 顯示更新紀錄
    .accesskey = p
update-application-installation =
    .label = 安裝
update-application-radio-group =
    .aria-label = 安裝
update-application-auto-2 =
    .label = 自動安裝更新（推薦）
    .accesskey = A
update-application-check-choose-2 =
    .label = 自動檢查更新，但讓我選擇何時安裝
    .accesskey = C
update-application-background-enabled =
    .label = 當 { -brand-short-name } 未執行時
    .accesskey = w
update-application-warning-cross-user-setting-2 =
    .message = 此設定將套用到本電腦上的所有 Windows 帳號及此份 { -brand-short-name } 的所有 { -brand-short-name } 設定檔。
update-application-suppress-prompts-2 =
    .label = 減少更新提醒
    .accesskey = n
update-setting-write-failure-title2 = 儲存更新設定時發生錯誤
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } 遇到錯誤，並未儲存此變更。請注意: 調整此更新選項，需要能夠寫入下列檔案的權限。您或您的系統管理員可以透過授予使用者此檔案的完整控制權，來解決本問題。
    
    無法寫入下列檔案: { $path }
update-in-progress-title = 更新中
update-in-progress-message = 您希望 { -brand-short-name } 使用此更新繼續嗎？
update-in-progress-ok-button = 捨棄 (&D)
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = 繼續 (&C)

## About Firefox

about-firefox-header =
    .heading = 關於 { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = 軟體更新可改善 { -brand-short-name } 的速度、穩定性、安全性。
    .label = { -brand-short-name } 更新
update-application-suppress-prompts-heading =
    .label = 通知
update-application-updates-managed-by-os =
    .message = 軟體更新由您的作業系統管理

## Firefox support

support-application-heading =
    .description = 疑難排解問題，或與社群分享點子。
    .label = { -brand-short-name } 技術支援
support-get-help =
    .label = 取得幫助
support-share-ideas =
    .label = 分享想法與意見回饋

## Firefox newsletter

newsletter-settings-heading =
    .description = 訂閱使用秘訣、建議與相關新聞，讓 { -brand-product-name } 為您發揮最大威力。
    .label = { -brand-product-name } 電子報
newsletter-sign-up-link =
    .label = 訂閱

## General Section - Performance

performance-settings-learn-more = 了解更多
performance-allow-hw-accel =
    .label = 可用時開啟硬體加速
    .accesskey = r
performance-limit-content-process-option = 內容處理程序數量限制
    .accesskey = L
performance-limit-content-process-enabled-desc = 調高內容處理程序的數量，可改善開啟多個分頁時的效能，但也會使用更多記憶體。
performance-limit-content-process-blocked-desc = 僅能在多程序的 { -brand-short-name } 當中修改內容處理程序數量。<a data-l10n-name="learn-more">了解如何確認多程序模式是否已開啟</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num }（預設）
performance-group =
    .label = 效能
performance-use-recommended-settings-checkbox-2 =
    .description = 下列設定是根據您的系統硬體與作業系統設定自動選擇。
    .label = 使用推薦的效能設定
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = 使用自動捲動
    .accesskey = a
keyboard-and-scrolling-group =
    .label = 鍵盤導航與捲動
motion-and-link-group =
    .label = 移動與鏈結樣式
browsing-use-smooth-scrolling =
    .label = 使用平滑捲動
    .accesskey = m
browsing-gtk-use-non-overlay-scrollbars =
    .label = 總是顯示捲動列
    .accesskey = o
browsing-always-underline-links =
    .label = 總是幫鏈結加上底線
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = 需要時顯示觸控鍵盤
    .accesskey = k
browsing-use-cursor-navigation =
    .label = 總是使用鍵盤方向鍵瀏覽網頁（鍵盤瀏覽）
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = 使用 Tab 鍵在表單控制元件與鏈結間移動焦點
    .accesskey = t
browsing-search-on-start-typing =
    .label = 打字時直接搜尋頁面文字（隨打即找）
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = 控制您如何移動游標以及與 { -brand-short-name } 互動。
    .label = 快速鍵
settings-keyboard-shortcuts-customkeys-link =
    .label = 自訂快速鍵
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = 前往「搜尋」自訂網址列設定
settings-media-group =
    .label = 媒體
browsing-picture-in-picture-toggle-enabled-2 =
    .label = 使用子母畫面
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = 切換分頁時，於子母畫面中繼續播放影片
    .accesskey = s
browsing-media-control =
    .label = 使用鍵盤、耳機或虛擬介面控制媒體內容播放行為
    .accesskey = V
recommendations-group =
    .label = 推薦
browsing-cfr-recommendations =
    .label = 隨您上網推薦擴充套件
    .accesskey = R
browsing-cfr-features =
    .label = 隨您上網推薦新功能
    .accesskey = f
browsing-group =
    .label = 瀏覽
preferences-accessibility-header =
    .heading = 輔助功能
preferences-default-zoom-select =
    .aria-label = 預設縮放比例
preferences-fonts-family =
    .label = 字體樣式
    .accesskey = D
preferences-fonts-size =
    .label = 字體大小
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = 進階設定
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .description = 設定 { -brand-short-name } 要如何連線到網際網路。
    .label = Proxy 設定值
network-proxy-connection-settings2 =
    .description = 更改這些設定可能會造成連線問題
    .label = 設定 Proxy
    .accesskey = p

## Home Section

home-new-windows-tabs-header = 新視窗與分頁
home-new-windows-tabs-description2 = 選擇開啟首頁、新視窗和新分頁時要看到的內容。
home-section =
    .heading = 首頁與啟動

## Home Section - Default Browser

home-default-browser-title =
    .label = 預設瀏覽器
is-default-browser-2 =
    .message = 選得好！{ -brand-short-name } 是您的預設瀏覽器。
is-not-default-browser-2 =
    .message = 嗯… { -brand-short-name } 不是您的預設瀏覽器。
set-as-my-default-browser-2 =
    .label = 設為預設瀏覽器
    .accesskey = D

## Custom Homepage subpage

home-homepage-mode-label = 首頁與新視窗
home-newtabs-mode-label = 新分頁
home-restore-defaults =
    .label = 回復為預設值
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name }（預設）
home-mode-choice-custom =
    .label = 自訂網址…
home-mode-choice-blank =
    .label = 空白頁
home-homepage-custom-url =
    .placeholder = 貼上網址…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = 管理擴充套件
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] 使用目前頁面
           *[other] 使用目前所有頁面
        }
    .accesskey = C
choose-bookmark =
    .label = 使用書籤…
    .accesskey = B
home-homepage-title =
    .label = 首頁
home-homepage-new-windows =
    .label = 新視窗
home-homepage-new-tabs =
    .label = 新分頁
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = 選擇特定網站
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = 網站網址
home-custom-homepage-list =
    .aria-label = 網站網址
home-custom-homepage-address =
    .placeholder = 請輸入網址
home-custom-homepage-address-button =
    .label = 新增網址
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = 尚未加入任何網站。
home-custom-homepage-delete-address-button =
    .aria-label = 刪除地址
    .title = 刪除地址
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = 取代為
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = 目前開啟的頁面
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = 書籤…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = 擴充套件（{ $extension }）
home-custom-homepage-header = 自訂首頁
home-custom-homepage-subpage =
    .heading = 自訂首頁

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name }內容
home-prefs-content-description2 = 選擇要在您的 { -firefox-home-brand-name }畫面顯示哪些內容。
home-prefs-search-header =
    .label = 網頁搜尋
home-prefs-shortcuts-header =
    .label = 捷徑
home-prefs-shortcuts-description = 您儲存或造訪過的網站
home-prefs-shortcuts-by-option-sponsored =
    .label = 贊助捷徑
home-prefs-recommended-by-header-generic =
    .label = 推薦的文章
home-prefs-recommended-by-description-generic = 由 { -brand-product-name } 產品家族精選的內容文章
home-prefs-stories-header =
    .label = 文章
home-prefs-stories-description = 依照您的上網行為，提供個人化文章推薦

##

home-prefs-recommended-by-learn-more = 原理是什麼
home-prefs-recommended-by-option-sponsored-stories =
    .label = 贊助內容
home-prefs-highlights-option-visited-pages =
    .label = 造訪過的頁面
home-prefs-highlights-options-bookmarks =
    .label = 書籤
home-prefs-highlights-option-most-recent-download =
    .label = 最新下載
home-prefs-recent-activity-header =
    .label = 近期動態
home-prefs-recent-activity-description = 近期造訪過的網站與內容精選
home-prefs-weather-header =
    .label = 天氣
home-prefs-weather-description = 快速了解本日天氣
home-prefs-weather-learn-more-link = 更多資訊
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = 支持 { -brand-product-name }
home-prefs-mission-message = 贊助商支持我們打造出一個更好的網路環境的使命
home-prefs-mission-message-learn-more-link = 看看是如何達成的
home-prefs-manage-topics-link = 管理主題
home-prefs-choose-wallpaper-link = 挑選一張背景圖
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } 行
           *[other] { $num } 行
        }

## Search Section

search-show-suggestions-option =
    .label = 顯示搜尋建議
    .accesskey = S
search-show-suggestions-url-bar-option =
    .label = 在網址列結果中顯示搜尋建議
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = 在網址列顯示的結果中，將搜尋建議放在瀏覽紀錄前面
search-show-suggestions-private-windows-2 =
    .label = 隱私瀏覽視窗中的搜尋建議
search-suggestions-cant-show-2 =
    .message = 由於您已經設定 { -brand-short-name } 不要記住瀏覽紀錄，網址列中將不會顯示建議搜尋結果。
addressbar-header-1 =
    .description = 選擇要在網址列顯示哪些建議
    .label = 網址列
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = 將在網址列顯示來自 { -brand-short-name } 與我們的夥伴所提供的建議。
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = 在結果頁的網址列顯示搜尋詞彙
search-separate-default-engine-2 =
    .label = 於隱私瀏覽視窗使用不同的預設搜尋引擎
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = 隱私瀏覽視窗中的預設搜尋引擎
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = 網址列導航
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = 使用 Tab 鍵移動焦點時，跳過結果選單
search-suggestions-header-2 =
    .label = 搜尋引擎建議
search-one-click-header2 = 搜尋快速鍵
search-one-click-desc = 請選擇當您在網址列或搜尋列輸入關鍵字時，可選用的其他搜尋引擎。
search-one-click-header-3 =
    .description = 選擇要在網址列顯示哪些搜尋引擎與捷徑。
    .label = 其他搜尋引擎
search-engine-list =
    .aria-label = 搜尋引擎與快速鍵
update-search-engine-success =
    .message = 已成功更新搜尋引擎
search-edit-engine-2 =
    .title = 編輯搜尋引擎
search-delete-engine =
    .title = 刪除搜尋引擎
search-enable-engine =
    .title = 啟用搜尋引擎
search-outlink-to-extensions-page =
    .title = 於擴充套件與佈景主題管理
search-choose-engine-column =
    .label = 搜尋引擎
search-choose-keyword-column =
    .label = 關鍵字
search-restore-default =
    .label = 還原預設搜尋引擎
    .accesskey = d
search-remove-engine =
    .label = 移除
    .accesskey = r
search-add-engine =
    .label = 新增
    .accesskey = A
search-add-engine-2 =
    .label = 新增搜尋引擎
    .accesskey = A
search-edit-engine =
    .label = 編輯
    .accesskey = E
search-find-more-link = 尋找更多搜尋引擎
search-filtering-for-add-engine = 新增搜尋引擎
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = 關鍵字重複
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = 您選用的關鍵字目前正被「{ $name }」所使用，請另選一個。
search-keyword-warning-bookmark = 您選用的關鍵字目前正被書籤項目所使用，請另選一個。
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = 已有名稱為「{ $name }」的搜尋引擎，請改用其他名稱。
remove-engine-confirmation = 您確定要刪除此搜尋引擎嗎？
remove-engine-remove = 移除
remove-addon-engine-alert = 若要移除此搜尋引擎，請先移除相關的附加元件。
search-engine-group =
    .label = 預設搜尋引擎
search-default-engine =
    .aria-label = 預設搜尋引擎
# Header for the search section ("search" is a noun).
search-section =
    .heading = 搜尋

## Containers Section

containers-section-header2 =
    .heading = 容器設定
containers-card-header2 =
    .description = 依照容器分隔 Cookie，這樣您就可以在一個網站登入不同帳號，並且限制跨網站追蹤。
    .label = 容器
containers-add-button2 =
    .label = 新增容器
    .accesskey = A
containers-list =
    .aria-label = 容器
containers-new-tab-check3 =
    .label = 選擇要分別使用哪個容器來開啟分頁
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = 不要將來自外部應用程式的鏈結放入容器開啟
    .accesskey = D
containers-new-tab-check2 =
    .description = 將在您每次按下「開啟新分頁」後，開啟容器選單。
    .label = 選擇要分別使用哪個容器來開啟分頁
    .accesskey = S
containers-settings-button2 =
    .title = 設定
containers-remove-button3 =
    .title = 刪除
containers-sites-card-header =
    .description = 為特定網站選擇容器，{ -brand-short-name } 就會使用該容器開啟該網站。
    .label = 特定網站容器
containers-sites-add-button =
    .label = 新增網站
    .accesskey = w
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = { $site } 的容器
containers-site-remove-button =
    .title = 刪除
containers-remove-button2 =
    .title = 移除

## Account and sync

sync-group-label =
    .label = 同步
account-group-label2 =
    .label = 帳號
account-disabled-group =
    .description = 暫時無法調整帳號設定。
    .label = 帳號
account-placeholder2 =
    .description = 登入後即可將您的資料用有隱私、加密的方式即時同步到您所有裝置上的 { -brand-short-name }。
    .label = 您尚未登入
account-sync-section =
    .heading = 帳號與同步
pane-account-sync-title2 = 帳號與同步
    .title = 帳號與同步

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = 把 Web 隨身帶著走
sync-signedout-description2 = 在您所有裝置間同步書籤、歷史紀錄、分頁、密碼、附加元件與各種選項。
sync-signedout-account-signin3 =
    .label = 登入進行同步…
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = 登入您的帳號後即可開始同步
    .accesskey = i
sync-signedout-account-short =
    .label = 登入
    .accesskey = i
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = 下載 Firefox for<img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a>或<img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a>以與您的行動裝置同步。

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = 更改個人資料照片
    .tooltiptext = 更改個人資料照片
sync-profile-picture-account-problem =
    .alt = 帳號個人資料照片
fxa-login-rejected-warning =
    .alt = 警告
sync-sign-out =
    .label = 登出…
    .accesskey = g
sync-sign-out2 =
    .label = 登出
    .accesskey = g
sync-manage-account = 管理帳號
    .accesskey = o
sync-manage-account2 =
    .label = 管理帳號
    .accesskey = o

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } 未驗證。
sync-signedin-unverified2 =
    .description = 請收信進行確認，正式讓帳號生效。
    .label = { $email } 尚未完成確認
sync-signedin-login-failure = 請登入以重新連線 { $email }
sync-signedin-login-failure2 =
    .description = 重新登入後即可重新連線，並且同步您的資料。
    .label = 您已登出 { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = 確認帳號
    .accesskey = V
sync-remove-account =
    .label = 移除帳號
    .accesskey = p
sync-sign-in =
    .label = 登入
    .accesskey = g

## Sync section - enabling or disabling sync.

prefs-syncing-on = 同步：開啟
prefs-syncing-on-2 =
    .label = 已開啟同步
prefs-syncing-off = 同步：關閉
prefs-syncing-off-2 =
    .description = 開啟同步後，即可在您的所有裝置中有相同的書籤、密碼、瀏覽紀錄與更多資訊。
    .label = 已關閉同步
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = 開啟同步功能即可在此裝置上同步您的書籤、密碼、瀏覽紀錄與更多資訊。
    .label = 已關閉同步
prefs-sync-turn-on-syncing =
    .label = 開啟同步…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = 開啟同步
    .accesskey = s
prefs-sync-offer-setup-label2 = 在您所有裝置間同步書籤、歷史紀錄、分頁、密碼、附加元件與各種選項。
prefs-sync-now-button =
    .label = 立刻同步
    .accesskey = N
prefs-sync-now-button-2 =
    .label = 立刻同步
    .accesskey = N
prefs-syncing-button =
    .label = 同步中…
prefs-syncing-button-2 =
    .label = 同步中…
    .title = 立刻同步
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = 現在起，您選擇的同步項目只會套用至此裝置。

## The list of things currently syncing.

sync-syncing-across-devices-heading = 您連線的裝置會同步下列項目：
sync-syncing-across-devices-heading-2 = 在不同裝置間同步的資料
sync-syncing-across-devices-heading-3 = 此裝置正在同步的資料
sync-syncing-across-devices-empty-state2 =
    .description = 您目前沒有同步任何資料。開始同步即可將所有資料同步到您的所有裝置上。
    .label = 管理要同步的資料
sync-syncing-across-devices-empty-state3 =
    .description = 您還沒有同步任何東西，選擇要在此裝置同步哪些資料。
    .label = 管理要同步的資料
sync-currently-syncing-bookmarks = 書籤
sync-currently-syncing-history = 瀏覽紀錄
sync-currently-syncing-tabs = 開啟的分頁
sync-currently-syncing-passwords = 密碼
sync-currently-syncing-addresses = 地址
sync-currently-syncing-payment-methods = 付款方式
sync-currently-syncing-addons = 附加元件
sync-currently-syncing-settings = 選項
sync-manage-options =
    .label = 管理同步…
    .accesskey = M
sync-manage-options-2 =
    .label = 管理要同步的資料
    .accesskey = M
settings-sync-disconnect-button =
    .label = 取消連線

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = 書籤
    .accesskey = m
sync-engine-history =
    .label = 瀏覽紀錄
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = 開啟的分頁
    .tooltiptext = 開啟您其他裝置上的分頁
    .accesskey = t
sync-engine-tabs =
    .label = 開啟的分頁
    .tooltiptext = 所有同步設備中，開啟的網頁清單
    .accesskey = T
sync-engine-passwords =
    .label = 密碼
    .tooltiptext = 您已儲存的密碼
    .accesskey = P
sync-engine-addresses2 =
    .label = 地址
    .tooltiptext = 您儲存於 { -brand-short-name } 的地址
    .accesskey = e
sync-engine-payment-methods3 =
    .label = 付款方式
    .tooltiptext = 您儲存的付款方式
    .accesskey = n
sync-engine-addons2 =
    .label = 附加元件
    .tooltiptext = 您已安裝到 { -brand-short-name } 桌面版的擴充套件與佈景主題
    .accesskey = A
sync-engine-settings2 =
    .label = 設定
    .tooltiptext = 適用的 { -brand-short-name } 設定
    .accesskey = s
sync-engine-addresses =
    .label = 地址
    .tooltiptext = 您儲存的郵政地址（僅桌機）
    .accesskey = e
sync-engine-payment-methods2 =
    .label = 付款方式
    .tooltiptext = 持卡人姓名、卡號、到期日
    .accesskey = n
sync-engine-addons =
    .label = 附加元件
    .tooltiptext = Firefox 桌機版的擴充套件與佈景主題
    .accesskey = A
sync-engine-settings =
    .label = 選項
    .tooltiptext = 您調整過的一般、隱私權與安全性選項
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = 儲存
    .buttonlabelextra2 = 取消連線…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = 管理要在您連結的裝置間同步哪些資料
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = 儲存
    .buttonlabelextra2 = 中斷連線…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = 管理要在此裝置上同步哪些資料

## The device name controls.

sync-device-name-header = 裝置名稱
sync-device-name-header-2 =
    .label = 裝置名稱
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = 裝置名稱
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = 更改裝置名稱
    .accesskey = h
sync-device-name-change =
    .label = 更改裝置名稱…
    .accesskey = h
sync-device-name-cancel =
    .label = 取消
    .accesskey = n
sync-device-name-save =
    .label = 儲存
    .accesskey = v
sync-connect-another-device = 連結其他裝置
sync-connect-another-device-2 =
    .label = 連結其他裝置

## Privacy Section

privacy-header = 瀏覽器隱私權

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = 密碼
    .searchkeywords = 登入資訊
forms-passwords-header =
    .aria-label = 密碼
    .label = 密碼
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = 提示儲存密碼
    .accesskey = A
forms-manage-password-exceptions =
    .label = 管理密碼例外
    .accesskey = M
forms-exceptions =
    .label = 例外網站…
    .accesskey = x
forms-suggest-passwords =
    .label = 建議一組安全的密碼
    .accesskey = S
forms-breach-alerts =
    .label = 針對發生過資料外洩的網站顯示密碼警告
    .accesskey = b
forms-breach-alerts-learn-more-link = 了解更多
preferences-relay-integration-checkbox2 =
    .label = 為您建議 { -relay-brand-name } 郵件轉寄信箱，幫助您保護實際信箱
    .accesskey = r
relay-integration-learn-more-link = 了解更多
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = 自動填寫帳號與密碼
    .accesskey = F
forms-fill-usernames-and-passwords-2 =
    .label = 儲存並自動填寫使用者名稱與密碼
    .accesskey = f
forms-saved-passwords =
    .label = 已儲存的密碼
    .accesskey = d
forms-saved-passwords-2 =
    .label = 管理已儲存的密碼
    .accesskey = d
forms-saved-passwords-searchkeywords = 您的電腦上儲存了下列網站的登入資訊
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = 其他保護
forms-primary-pw-use =
    .label = 使用主控密碼
    .accesskey = U
forms-primary-pw-use-2 =
    .description = 為您儲存的密碼再加上一層保護。
    .label = 使用主控密碼
    .accesskey = U
forms-primary-pw-set =
    .label = 設定主控密碼
forms-primary-pw-on-2 = 主控密碼已<strong>開啟</strong>
forms-primary-pw-on =
    .label = 已開啟主控密碼
forms-primary-pw-change-2 =
    .label = 更改主控密碼
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = 關閉主控密碼
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = 填寫與管理密碼時需進行裝置登入驗證
forms-os-reauth-2 =
    .label = 需要驗證登入資訊才能管理密碼
forms-primary-pw-learn-more-link = 了解更多
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = 變更主控密碼…
    .accesskey = M
forms-primary-pw-change =
    .label = 變更主控密碼…
    .accesskey = P
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = 您目前使用 FIPS 模式。FIPS 模式需要有主控密碼。
forms-master-pw-fips-desc = 密碼變更失敗
forms-windows-sso =
    .label = 允許使用 Windows 單一登入系統，登入微軟、工作單位、學校提供的帳號
forms-windows-sso-learn-more-link = 了解更多
forms-windows-sso-desc = 可到您的裝置設定畫面管理帳號
windows-passkey-settings-label = 到系統設定中管理密碼金鑰
privacy-panel-settings-header =
    .description = 使用 { -brand-short-name } 時，獲得保護您線上個人資訊的協助。
    .label = 隱私權面板設定
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = 顯示偵測到資料外洩的訊息
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = 請在下方輸入您的 Windows 登入帳號密碼才能建立主控密碼。這個動作是為了保護您的登入資訊安全。
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = 建立主控密碼
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] 更改付款方式設定
       *[other] { -brand-short-name } 正嘗試更改付款方式設定，請進行裝置登入驗證。
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = 付款方式
autofill-payment-methods-checkbox-message-2 =
    .label = 儲存並自動填寫付款資訊
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = 管理付款方式
autofill-payment-methods-manage-payments-button =
    .label = 管理付款方式
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = 要求裝置登入才能自動填寫
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = 自動填寫與管理付款資訊時，需進行裝置登入驗證
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = 儲存安全碼
    .accesskey = c
autofill-payment-methods-add-button = 新增付款方式
payments-list-header =
    .label = 付款方式
payments-delete-payment-prompt-title = 要刪除這筆付款方式嗎？
payments-delete-payment-prompt-confirm-button = 刪除
payments-delete-payment-prompt-cancel-button = 取消
payments-delete-payment-button-label =
    .aria-label = 刪除
payments-edit-payment-button-label =
    .aria-label = 編輯
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = 未新增付款方式
autofill-addresses-checkbox-message =
    .label = 儲存並自動填寫地址
    .accesskey = S
autofill-addresses-manage-addresses-button =
    .label = 管理地址與更多資訊
    .accesskey = M
addresses-list-header =
    .label = 地址
addreses-delete-address-button-label =
    .aria-label = 刪除
addreses-edit-address-button-label =
    .aria-label = 編輯
addresses-delete-address-prompt-title = 要刪除這筆地址嗎？
addresses-delete-address-prompt-confirm-button = 刪除
addresses-delete-address-prompt-cancel-button = 取消
autofill-addresses-add-button = 新增地址
autofill-addresses-manage-addresses-title =
    .heading = 管理地址與更多資訊
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = 未新增地址
personal-info-group =
    .label = 個人資訊
autofill-personal-info-checkbox-message =
    .label = 儲存並自動填寫個人資訊
autofill-personal-info-manage-button =
    .label = 管理個人資訊
passports-list-header =
    .label = 護照資訊
passports-delete-passport-button-label =
    .aria-label = 刪除
passports-edit-passport-button-label =
    .aria-label = 編輯
passports-delete-passport-prompt-title = 要刪除這組護照資訊嗎？
passports-delete-passport-prompt-confirm-button = 刪除
passports-delete-passport-prompt-cancel-button = 取消
autofill-passports-add-button = 新增護照資訊
autofill-personal-info-manage-title =
    .heading = 管理個人資訊
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = 未加入護照資訊
pane-passwords-autofill-title2 = 密碼與自動填寫
    .title = 密碼與自動填寫
preferences-passwords-autofill-header =
    .heading = 密碼與自動填寫
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } 已儲存
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } 已儲存
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = 地址與更多資訊
payments-group =
    .label = 付款方式

## Privacy Section - History

history-remember-option-never2 =
    .description = 每個視窗都是隱私視窗，開啟此選項後，需要再允許擴充套件才能運作。
    .label = 不保留歷史記錄
history-remember-option-custom2 =
    .label = 自訂瀏覽紀錄行為
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } 將記住您的瀏覽、下載、表單填寫與搜尋紀錄。
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } 不會儲存任何瀏覽記錄，如同在隱私瀏覽狀態下執行。
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } 會針對您的瀏覽、下載、表單填寫與搜尋紀錄使用您自訂的選項。
history-private-browsing-permanent =
    .label = 總是使用隱私瀏覽模式
    .accesskey = p
history-remember-browser-option =
    .label = 保留瀏覽與下載紀錄
    .accesskey = b
history-remember-search-option =
    .label = 保留我的搜尋列與表單輸入的內容
    .accesskey = f
history-clear-on-close-option =
    .label = 結束 { -brand-short-name } 時清除歷史記錄
    .accesskey = r
history-clear-on-close-settings =
    .label = 設定…
    .accesskey = t
history-shutdown-exceptions =
    .label = 管理例外網站
    .accesskey = x
history-clear-button =
    .label = 清除瀏覽記錄…
    .accesskey = s
history-header2 =
    .heading = 瀏覽紀錄
history-section-header =
    .description = 選擇關閉瀏覽器時，{ -brand-short-name } 要記住哪些項目。
    .label = 瀏覽紀錄
history-custom-section-header =
    .description = 調整關閉瀏覽器時，{ -brand-short-name } 要記住哪些項目。
    .label = 進階設定
history-custom-button =
    .label = 選擇 { -brand-short-name } 要記住哪些項目
history-group =
    .label = 瀏覽紀錄
history-mode-radio-group =
    .aria-label = 瀏覽紀錄
history-remember-option-all2 =
    .label = 保留所有歷史記錄

## Privacy Section - Site Data

sitedata-total-size-calculating = 正在計算網站資料與快取大小…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = 網站資料目前使用了 <strong>{ $value } { $unit }</strong> 磁碟空間。
sitedata-learn-more = 了解更多
sitedata-delete-on-close2 =
    .label = 每次關閉 { -brand-short-name } 時都清除 Cookie 與網站資料
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = 依照您的瀏覽紀錄設定，當您關閉瀏覽器後，{ -brand-short-name } 會自動刪除瀏覽階段中產生的 Cookie 與網站資料。
sitedata-delete-on-close-private-browsing4 =
    .heading = 不儲存瀏覽紀錄。
    .message = 關閉瀏覽器時，{ -brand-short-name } 會自動清除 Cookie 與網站資料。
sitedata-option-block-cross-site-trackers =
    .label = 跨網站追蹤器
sitedata-option-block-cross-site-tracking-cookies =
    .label = 跨網站追蹤 Cookie
sitedata-option-block-cross-site-cookies2 =
    .label = 隔離跨網站 Cookie
sitedata-option-block-unvisited =
    .label = 來自未造訪過網站的 Cookie
sitedata-option-block-all-cross-site-cookies =
    .label = 所有跨網站 Cookie（可能會造成網站運作不正常）
sitedata-option-block-all =
    .label = 所有 Cookie（會造成網站不正常）
sitedata-clear2 =
    .label = 清除瀏覽資料
    .accesskey = l
sitedata-settings2 =
    .label = 管理瀏覽資料
    .accesskey = M
sitedata-cookies-exceptions =
    .label = 管理例外網站…
    .accesskey = X
sitedata-cookies-exceptions2 =
    .description = 您可以指定哪些網站總是可以，或永遠不可儲存 Cookie 與網站資料。
    .label = 管理例外網站
    .accesskey = x
sitedata-heading =
    .description = 管理您的 Cookie、瀏覽紀錄、快取、網站資料與更多資料。
    .label = 瀏覽資料
sitedata-settings3 =
    .label = 清除特定網站資料
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = 針對特定網站決定要如何處理 Cookie 與網站資料。
    .label = 管理例外網站
    .accesskey = x
cookies-site-data-group =
    .label = Cookie 與網站資料

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Cookie 橫幅封鎖器
cookie-banner-blocker-description = 當支援此功能的網站在隱私瀏覽模式中詢問是否可以設定 Cookie 時，{ -brand-short-name } 會自動為您拒絕。
cookie-banner-learn-more = 了解更多
cookie-banner-blocker-checkbox-label =
    .label = 自動拒絕 Cookie 橫幅

## Search Section

addressbar-locbar-history-option =
    .label = 瀏覽紀錄
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = 書籤
    .accesskey = k
addressbar-locbar-clipboard-option =
    .label = 剪貼簿
    .accesskey = C
addressbar-locbar-openpage-option =
    .label = 開啟的分頁
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = 捷徑
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = 熱門網站
    .accesskey = T
addressbar-locbar-engines-option-1 =
    .label = 建議要使用的搜尋引擎
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = 快速操作
    .accesskey = Q
addressbar-locbar-showrecentsearches-option-2 =
    .label = 最近搜尋內容
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = 熱門搜尋建議
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = 取得您搜尋內容的相關建議。
    .label = 來自 { -brand-short-name } 的建議
addressbar-locbar-suggest-sponsored-option-2 =
    .description = 讓贊助商偶爾顯示廣告，支持 { -brand-short-name } 的發展。
    .label = 來自贊助商的建議
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = 一邊打字，一邊從 Mozilla 取得建議
addressbar-dismissed-suggestions-label-2 =
    .description = 重新顯示被忽略的贊助商與 { -brand-short-name } 建議項目。
    .label = 忽略的建議
addressbar-restore-dismissed-suggestions-button-2 =
    .label = 還原建議

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = 加強型追蹤保護
content-blocking-section-top-level-description = 追蹤器會在網路上跟蹤您，收集您的興趣與喜好。{ -brand-short-name } 會封鎖許多追蹤器與其他有害指令碼。
content-blocking-learn-more = 了解更多
content-blocking-fpi-incompatibility-warning = 您已開啟第一方隔離（FPI）功能，會蓋掉 { -brand-short-name } 的某些 Cookie 設定。
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = 您開啟了 Resist Fingerprinting (RFP) 功能，將蓋過 { -brand-short-name } 的部分數位指紋追蹤保護設定。此功能可能造成某些網站運作不正常。

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = 標準
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = 嚴格
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = 自訂
    .accesskey = C

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = 兼顧保護與效能。網站可正常運作。
content-blocking-etp-strict-desc = 保護更強大，但可能會導致某些網站或內容故障。
content-blocking-etp-custom-desc = 選擇要封鎖哪些追蹤器與指令碼。
content-blocking-etp-blocking-desc = { -brand-short-name } 會封鎖下列項目：
content-blocking-private-windows = 隱私視窗中的追蹤內容
content-blocking-cross-site-cookies-in-all-windows2 = 所有視窗中的跨網站 Cookie
content-blocking-cross-site-tracking-cookies = 跨網站追蹤 Cookie
content-blocking-all-cross-site-cookies-private-windows = 隱私視窗中的跨網站 Cookie
content-blocking-isolate-cross-site-cookies = 隔離跨網站 Cookie
content-blocking-social-media-trackers = 社群網路追蹤器
content-blocking-all-cookies = 所有 Cookie
content-blocking-unvisited-cookies = 來自未造訪過網站的 Cookie
content-blocking-all-windows-tracking-content = 所有視窗中的追蹤內容
content-blocking-all-cross-site-cookies = 所有跨網站 Cookie
content-blocking-cryptominers = 加密貨幣採礦程式
content-blocking-fingerprinters = 數位指紋追蹤程式
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = 已知與疑似的數位指紋追蹤程式
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = 全方位 Cookie 保護功能會將 Cookie 限制於您所在的網站當中，這樣追蹤器就無法透過 Cookie 在不同網站間追蹤您。
content-blocking-etp-standard-tcp-rollout-learn-more = 了解更多
content-blocking-etp-standard-tcp-title = 包含我們有史以來最強大的隱私保護功能 — 全方位 Cookie 保護
content-blocking-warning-title-2 = 使用嚴格的追蹤保護功能時，某些網站可能會故障
content-blocking-warning-title-custom = 自訂追蹤保護功能時，某些網站可能會故障
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } 建議使用「修正網站問題」選項，減少發生網站功能或內容故障的可能。若網站看來故障了，也可以針對該網站關閉追蹤保護，以載入所有內容。
content-blocking-warning-learn-how = 了解要怎麼做
content-blocking-baseline-exceptions-3 =
    .description = 不封鎖可能包含追蹤器的重要功能，以幫助載入網站內容與功能。能解決大多數常見問題。
    .label = 修正網站的主要問題（建議）
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = 不封鎖可能包含追蹤器的網頁元素，以恢復文章中的影片，或是留言區塊等功能。這個選項可更加減少網站問題，但同時也較無保護。必須用於修正網站的主要問題。
    .label = 修正網站的小問題
content-blocking-baseline-uncheck-warning-dialog-title = 您確定要關閉修正功能嗎？
content-blocking-baseline-uncheck-warning-dialog-body = 此選項可幫助修正大部分常見的網站問題。若您關閉此選項，某些網站可能會無法正常運作，{ -brand-short-name } 也無法幫助排解這類問題。
content-blocking-baseline-uncheck-warning-dialog-ok-button = 關閉修正
content-blocking-baseline-uncheck-warning-dialog-cancel-button = 保持修正
content-blocking-reload-description = 需要重新載入分頁才能套用變更。
content-blocking-reload-tabs-button =
    .label = 重新載入所有分頁
    .accesskey = R
content-blocking-tracking-content-label =
    .label = 追蹤用內容
    .accesskey = T
content-blocking-tracking-protection-option-all-windows =
    .label = 所有視窗
    .accesskey = A
content-blocking-option-private =
    .label = 僅在隱私瀏覽視窗
    .accesskey = p
content-blocking-cookies-label =
    .label = Cookie
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = 更多資訊
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = 加密貨幣採礦程式
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = 已知的數位指紋追蹤程式
    .accesskey = K
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = 疑似是數位指紋追蹤程式
    .accesskey = S

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = 管理例外網站…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = 暫停通知到 { -brand-short-name } 重新啟動後
    .accesskey = n
permissions-autoplay2 =
    .label = 自動播放
permissions-block-popups2 =
    .label = 封鎖彈出型視窗與第三方重新導向
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = 加入可以開啟彈出型視窗，或重新導向到第三方網站的網站。
    .label = 管理例外網站
    .searchkeywords = 彈出型視窗, popups
    .accesskey = E
permissions-addon-install-warning3 =
    .label = 網站嘗試安裝擴充套件時，顯示警告
    .accesskey = W
permissions-addon-exceptions2 =
    .label = 選擇可以安裝擴充套件的網站
    .accesskey = E
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = 允許網站詢問您是否可開啟應用程式鏈結。
    .accesskey = A
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = 管理封鎖的網站
    .accesskey = M
permissions-location2 =
    .label = 位置
permissions-localhost2 =
    .label = 裝置應用程式與服務
permissions-local-network2 =
    .label = 區域網路裝置
permissions-xr2 =
    .label = 虛擬實境
permissions-camera2 =
    .label = 攝影機
permissions-microphone2 =
    .label = 麥克風
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = 喇叭
permissions-notification2 =
    .label = 通知
permissions-header3 =
    .description = 管理網站能夠存取、控制、觸發哪些項目。
    .label = 權限
permissions-data-section =
    .heading = 權限與資料
pane-permissions-data-title2 = 權限與資料
    .title = 權限與資料
notifications-section-header =
    .heading = 通知
notifications-entry-card-header =
    .description = 選擇哪些網站可以傳送通知，以及要如何顯示。
    .label = 通知
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
           *[other] { $count } 個網站
        }
    .label = 管理通知設定
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = 管理網站通知設定
notifications-website-card-header =
    .description = 選擇網站可如何傳送通知。
    .label = 網站通知
notifications-filter =
    .placeholder = 搜尋網站
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = 網站
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = 允許通知
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = 網站
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = 總是
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = 允許
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = 永不
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = 尚未新增任何網站通知。
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = 沒有任何符合您搜尋條件的網站通知。

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = 若要讓此變更在備份中生效，請開啟每個設定檔，並到「設定」當中選擇「立即備份」。
nimbus-rollouts =
    .description = 變更將從遠端自動推出。
    .label = 允許 { -brand-short-name } 在新版本推出前改進功能、效能、穩定度
addon-recommendations3 =
    .description = 依照您的使用方式推薦擴充套件，改進您的上網體驗。
    .label = 允許個人化推薦的擴充套件
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = 進行編譯設定時，已停用了資料回報功能。
collection-backlogged-crash-reports2 =
    .label = 自動傳送錯誤報告
    .accesskey = c
collection-backlogged-crash-reports-description = 此資料可幫助 { -vendor-short-name } 找出瀏覽器的問題並進行修正。報告內容可能會包含私人或敏感資料。
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = 設定不變，全新外觀！
    .message = 我們重新調整了此頁面，讓您更簡單就能掃描與探索。您的個人設定均未更動，也都在原處。小秘訣：可使用搜尋功能直達您要的設定項目。
settings-redesign-promo-dismiss-button =
    .label = 知道了！
privacy-segmentation-section-header = 能加強您上網體驗的新功能
privacy-segmentation-section-description = 當我們推出會使用您的資料來提供更個人化的上網體驗的新功能時：
privacy-segmentation-radio-off =
    .label = 使用 { -brand-product-name } 推薦設定
privacy-segmentation-radio-on =
    .label = 顯示詳細資訊
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = 我們盡力提供您不同選擇，也只會收集最少而必須的資料，以用於為所有人改善 { -brand-product-name }。
    .label = { -brand-short-name } 資料收集與使用
    .searchkeywords = telemetry
data-collection-link = 檢視隱私權公告
data-collection-preferences-across-profiles =
    .message = 此設定將套用到此裝置中的所有 { -brand-product-name } 設定檔。
data-collection-profiles-link = 檢視所有設定檔
data-collection-health-report-telemetry-disabled =
    .message = 將不再允許 { -vendor-short-name } 捕捉技術與互動資料，之前收集的資料將於 30 天內刪除。
data-collection-health-report =
    .description = 此資料可幫助我們改進 { -brand-product-name } 產品功能、效能與穩定度。
    .label = 傳送技術與互動資料給 { -vendor-short-name }
    .accesskey = r
data-collection-health-report-disabled =
    .description = 此版本進行編譯設定時，停用了資料回報功能。
    .label = 傳送技術與互動資料給 { -vendor-short-name }
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } 會隨機選擇使用者來測試功能，幫助為每個人改進品質。
    .label = 允許 { -brand-short-name } 進行功能研究
data-collection-studies-link =
    .label = 檢視 { -brand-short-name } 所進行的研究
data-collection-backlogged-crash-reports =
    .description = 此報告可幫助 { -vendor-short-name } 找出瀏覽器的問題並進行修正。報告內容可能會包含私人或敏感資料。
    .label = 自動傳送錯誤報告
    .accesskey = c
data-collection-usage-ping =
    .description = 此資訊可幫助 { -vendor-short-name } 估算活躍使用者數。
    .label = 傳送每日使用情況回報給 { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = 安全性
browsing-protection-group2 =
    .description = 危險網站與下載項目，可能會讓您的資料與裝置遭受風險。{ -brand-short-name } 會自動封鎖這類資料並警告。
    .label = 詐欺內容與危險網站保護
security-enable-safe-browsing =
    .label = 封鎖危險及詐騙內容
    .accesskey = B
security-enable-safe-browsing-link = 了解更多
security-safe-browsing-warning =
    .message = 關閉此功能將減少對詐騙、惡意網站，以及危險下載項目的保護。
security-block-downloads =
    .label = 封鎖危險的下載項目
    .accesskey = D
security-block-uncommon-software =
    .label = 下載不安全或不常見的軟體時警告您
    .accesskey = C

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = 允許 { -brand-short-name } 自動信任您安裝的第三方根憑證
    .accesskey = t
certs-devices-enable-fips = 啟用 FIPS
space-alert-over-5gb-settings-button =
    .label = 開啟選項
    .accesskey = O
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } 的磁碟空間不足。</strong>網站內容可能無法正確顯示。您可以到「設定 > 隱私權與安全性 > Cookie 與網站資料」清除目前儲存的網站資料。
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } 的磁碟空間不足。</strong>網站內容可能無法正確顯示。請點擊「瞭解更多」清理磁碟空間，讓您有更好的瀏覽體驗。
certs-description3 =
    .description = 設定 { -brand-short-name } 要用來確認加密連線的憑證。
    .label = 憑證
certs-view2 =
    .label = 管理憑證
    .accesskey = C
certs-devices2 =
    .label = 管理安全裝置
    .accesskey = D

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = 純 HTTPS 模式的運作原理是什麼？
httpsonly-radio-enabled =
    .label = 在所有視窗都開啟純 HTTPS 模式
httpsonly-radio-enabled-pbm =
    .label = 僅在隱私瀏覽視窗開啟純 HTTPS 模式
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } 可能還是會將某些連線升級為 HTTPS 連線
    .label = 不要開啟純 HTTPS 模式
httpsonly-group =
    .description = 僅允許對網站使用安全連線。{ -brand-short-name } 會在進行不安全連線前先詢問。
    .label = 純 HTTPS 模式
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS over HTTPS
dns-over-https-group2 =
    .description = Domain Name System over HTTPS（DoH）會將網站查詢行為加密，讓您的電信業者或其他人更難看出您準備要造訪的網站。
    .label = DNS over HTTPS
preferences-doh-description2 = DNS over HTTPS 會將您的網域名稱查詢請求加密後傳送，使其他人更難得知您要開啟的網站，讓 DNS 查詢變得安全。
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = 狀態：{ $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = 提供者：{ $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = 網址無效
preferences-doh-steering-status = 使用本機提供者
preferences-doh-status-active = 啟用
preferences-doh-status-disabled = 關閉
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = 未啟用（{ $reason }）
preferences-doh-group-message2 = 使用下列方式開啟 DNS over HTTPS：
preferences-doh-radio-group =
    .aria-label = 使用下列方式開啟 DNS over HTTPS：
preferences-doh-expand-section =
    .tooltiptext = 更多資訊
preferences-doh-setting-default =
    .label = 預設保護
    .accesskey = D
preferences-doh-default-desc = { -brand-short-name } 會為您決定使用安全 DNS 的時機，以保護您的隱私。
preferences-doh-default-detailed-desc-1 = 在可用安全 DNS 的地區就使用
preferences-doh-default-detailed-desc-2 = 若無法使用安全 DNS 提供者，就使用您的預設 DNS 解析器。
preferences-doh-default-detailed-desc-3 = 盡可能使用本機提供者
preferences-doh-default-detailed-desc-4 = 當 VPN、家長監護設定或企業政策生效時就關閉
preferences-doh-default-detailed-desc-5 = 當網路裝置告訴 { -brand-short-name } 不該使用安全 DNS 時就關閉
preferences-doh-setting-enabled =
    .label = 加強保護
    .accesskey = I
preferences-doh-enabled-desc = 由您決定何時使用安全 DNS，並選擇提供者。
preferences-doh-enabled-detailed-desc-1 = 使用您選擇的提供者
preferences-doh-enabled-detailed-desc-2 = 只在無法使用安全 DNS 提供者時，使用您的預設 DNS 解析器。
preferences-doh-setting-strict =
    .label = 最大保護
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } 總是會使用安全 DNS。若我們需要使用系統 DNS 時，您會看到安全性警告。
preferences-doh-strict-detailed-desc-1 = 只使用您選擇的提供者
preferences-doh-strict-detailed-desc-2 = 無法使用安全 DNS 時總是警告我
preferences-doh-strict-detailed-desc-3 = 若無法使用安全 DNS，就不開啟網站或無法正常運作
preferences-doh-setting-off =
    .label = 關閉
    .accesskey = O
preferences-doh-off-desc = 使用您系統預設的 DNS 解析器
preferences-doh-select-resolver = 選擇提供者：
preferences-doh-manage-exceptions =
    .label = 管理例外網站…
    .accesskey = x
preferences-doh-overview-default =
    .description = 在可用的地方就使用安全 DNS。
    .label = 預設保護
preferences-doh-overview-custom =
    .description = 總是使用安全 DNS，自行控管 DNS 業者與備用行為。
    .label = 自訂
preferences-doh-overview-off =
    .description = 使用您的預設 DNS 解析器。
    .label = 關閉
preferences-doh-advanced-button =
    .label = 進階設定
preferences-doh-advanced-section =
    .description = Domain Name System over HTTPS（DoH）會將網站查詢行為加密，讓您的電信業者或其他人更難看出您準備要造訪的網站。
    .label = 進階設定
preferences-doh-manage-exceptions2 =
    .label = 管理例外
    .accesskey = x
preferences-doh-radio-default =
    .description = 在可用地區就使用安全 DNS 進行查詢
    .label = 預設
preferences-doh-radio-custom =
    .description = 總是使用安全 DNS，並自行控制提供者與備用行為
    .label = 自訂
preferences-doh-radio-off =
    .description = 使用預設的 DNS 解析器
    .label = 關閉
preferences-doh-fallback-label =
    .label = 無法使用安全 DNS 時，總是警告我
preferences-doh-status-item-off =
    .message = DNS over HTTPS 已關閉
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = 由於嘗試使用提供者 { $name } 時遇到錯誤（{ $reason }），DNS over HTTPS 無法運作
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = 由於收到無效網址（{ $reason }），DNS over HTTPS 無法運作
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = 正在使用 { $name } 提供的 DNS over HTTPS 服務
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = 由於嘗試使用本地提供者 { $name } 時遇到錯誤（{ $reason }），DNS over HTTPS 無法運作
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = 正在使用 { $name } 本地提供者的 DNS over HTTPS 服務
preferences-doh-select-resolver-label =
    .label = 選擇提供者：
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = 使用此提供者進行 DNS over HTTPS 解析
preferences-doh-custom-provider-label =
    .aria-label = 輸入自訂提供者網址
preferences-doh-header2 =
    .heading = DNS over HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = 連線與軟體安全性
preferences-connection-link-section =
    .description = 看看如何保持連線安全、封鎖有害軟體，以及如何驗證網站身分。
    .label = 連線與軟體安全性
preferences-connection-link-button =
    .label = 進階設定

## The following strings are used in the Download section of settings

desktop-folder-name = 桌面
downloads-folder-name = 下載

## Appearance page

preferences-appearance-header =
    .heading = 外觀設定
browser-theme-group =
    .description = 用您的風格妝點 { -brand-short-name }。佈景主題可調整工具列、選單、訊息的色彩。
    .label = 瀏覽器佈景主題
browser-theme-manage-link =
    .label = 管理 { -brand-short-name } 的佈景主題
appearance-window-density-group =
    .description = 調整工具列、分頁標籤、側邊欄等視窗元素周圍的間距
    .label = 視窗密度
appearance-window-density-radio-group =
    .aria-label = 視窗密度
appearance-window-density-automatic =
    .description = 會自動套用標準、緊密或觸控模式間距
    .label = 自動（預設值）
appearance-window-density-automatic-no-touch =
    .description = 會自動套用標準或緊密模式間距
    .label = 自動（預設值）
appearance-window-density-standard =
    .description = 適合大多數螢幕使用的標準間距
    .label = 標準
appearance-window-density-auto-touch-mode =
    .label = 在平板電腦模式中使用觸控大小
appearance-window-density-compact =
    .description = 為小螢幕減少間距
    .label = 緊密
appearance-window-density-touch =
    .description = 放大視窗元素與點擊區，為觸控螢幕最佳化
    .label = 觸控
related-settings-group =
    .label = 相關設定
related-settings-accessibility-link =
    .label = 到「輔助功能」自訂縮放與字型設定
related-settings-home-link =
    .label = 自訂 { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = 自訂瀏覽器版面

## AI controls page

preferences-ai-controls-description = 您可隨時在 { -brand-short-name } 決定是否使用 AI 強化功能。即將推出更多控制設定。
preferences-ai-controls-block-ai-label = 封鎖 AI 強化功能
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = 封鎖的話，代表您不會在 { -brand-short-name } 看到目前已有，或新推出的 AI 強化功能，或是任何有關這些功能的彈出提示。若需有關包含哪些功能、如何控制傳統機器學習技術的相關功能（如搜尋建議）的相關資訊，<a data-l10n-name="link">請參考此處</a>。
preferences-ai-controls-blocked-message =
    .message = 預設會封鎖目前提供與新推出的 AI 強化功能，可使用下列控制元件解除封鎖特定功能。
preferences-ai-controls-on-device-group =
    .description = 這些功能會下載小型 AI 模型到您的裝置上運作，這樣可以幫助保護您的隱私。
    .label = 本機裝置上的 AI
preferences-ai-controls-translations-control =
    .description = 用您偏好的語言，無縫瀏覽網頁。
    .label = 翻譯
preferences-ai-controls-translations-more-link = 更多翻譯設定
preferences-ai-controls-pdfjs-control =
    .description = 當您新增圖片到 PDF 當中時，根據圖片內容加入描述，讓圖片更有親和力。
    .label = { -brand-short-name } PDF 檢視器中的圖片替代文字
preferences-ai-controls-tab-group-suggestions-control =
    .description = 取得為分頁命名與整理分頁的建議。
    .label = 分頁群組建議
preferences-ai-controls-key-points-control =
    .description = 在開啟鏈結之前先看一下快速摘要。
    .label = 預覽鏈結當中的重點資訊
preferences-ai-controls-speech-recognition-control =
    .description = 在本機轉錄語音。
    .label = 語音辨識
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = 上網時，在畫面中保留聊天機器人。可從多套服務任選，也可隨時切換。
    .label = 側邊欄中的 AI 聊天機器人
preferences-ai-controls-sidebar-chatbot-group =
    .description = 上網時也在畫面中留一塊空間給聊天機器人。從 Anthropic Claude、ChatGPT、Copilot、Google Gemini 及 Le Chat Mistral 當中挑選一套。
    .label = 側邊欄中的 AI 聊天機器人
preferences-ai-controls-sidebar-chatbot-control =
    .label = 側邊欄中的聊天機器人
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = 可用
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = 啟用
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = 封鎖
preferences-ai-controls-state-description-before = 選項的意思：
preferences-ai-controls-state-description-available = <strong>可用：</strong>您會看到這個功能，也能使用。
preferences-ai-controls-state-description-enabled = <strong>啟用：</strong>您主動選擇要使用此功能。
preferences-ai-controls-state-description-blocked = <strong>封鎖：</strong>您不會看到這個功能，也不能使用。也會移除所有在裝置內運作的 AI 模型。
preferences-ai-controls-block-confirmation-heading = 要封鎖 AI 強化功能嗎？
preferences-ai-controls-block-confirmation-description = 您不會在 { -brand-short-name } 看到目前已有，或新推出的 AI 強化功能，或是任何有關這些功能的彈出提示。但之後還是可以解除封鎖任何想要使用的功能。
preferences-ai-controls-block-confirmation-features-start = 會封鎖哪些功能：
preferences-ai-controls-block-confirmation-translations = 翻譯
preferences-ai-controls-block-confirmation-pdfjs = { -brand-short-name } PDF 檢視器中的圖片替代文字
preferences-ai-controls-block-confirmation-tab-group-suggestions = 分頁群組建議
preferences-ai-controls-block-confirmation-key-points = 預覽鏈結當中的重點資訊
preferences-ai-controls-block-confirmation-sidebar-chatbot = 側邊欄中的聊天機器人
preferences-ai-controls-block-confirmation-speech-recognition = 語音辨識
preferences-ai-controls-block-confirmation-features-after = 封鎖功能也會影響使用由 { -brand-short-name } 提供的 AI 功能的擴充套件。
preferences-ai-controls-block-confirmation-cancel =
    .label = 取消
preferences-ai-controls-block-confirmation-confirm =
    .label = 封鎖
preferences-ai-controls-header3 =
    .heading = AI 控制

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } 警戒中
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } 建議進行某些安全性改進
security-privacy-status-ok-label = 已開啟加強型追蹤保護
security-privacy-status-problem-label = 我們發現會影響您保護的設定
security-privacy-status-problem-helper-label = 檢視問題
security-privacy-status-pending-trackers-label = 正在查詢 { -brand-short-name } 上個月封鎖了多少追蹤器
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label = 上個月封鎖了 { $trackerCount } 組追蹤器
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = 您開啟了<a data-l10n-name="strict-tracking-protection">嚴格保護</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = 您開啟了<a data-l10n-name="custom-tracking-protection">自訂保護</a>
security-privacy-status-up-to-date-label = 您已經安裝最新、最安全的 { -brand-short-name }
security-privacy-status-update-needed-label = 已推出新版的 { -brand-short-name }。
security-privacy-status-update-error-label = { -brand-short-name } 更新時遇到問題
security-privacy-status-update-checking-label = { -brand-short-name } 正在檢查更新
security-privacy-status-update-needed-description = 獲得最新的速度、穩定性、安全性更新。
security-privacy-status-update-button-label =
    .label = 更新 { -brand-short-name }
security-privacy-image-warning =
    .alt = 一副加上驚嘆號的盾牌，表達對您的安全性警告的擔憂
security-privacy-image-ok =
    .alt = 一副打勾的盾牌，表示您目前沒有待處理的安全性問題
security-privacy-issue-card =
    .heading = 安全性警告
issue-card-reset-button =
    .label = 重設
issue-card-dismiss-button =
    .aria-label = 知道了！
    .tooltiptext = 知道了！

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = 網站會使用追蹤器在線上跟蹤您，並顯示可怕的廣告。{ -brand-short-name } 會在您上網時自動封鎖追蹤器，讓您可自行掌握自己的數位足跡。
    .label = 加強型追蹤保護
preferences-etp-level-radio-group =
    .aria-label = 加強型追蹤保護
preferences-etp-level-standard =
    .description = 強大又可靠的保護機制，可順暢開啟大多數網站。
    .label = 標準（預設）
preferences-etp-level-strict =
    .description = 保護機制更強大，封鎖更多追蹤器，但某些網站可能會故障。
    .label = 嚴格
preferences-etp-level-custom =
    .description = 自行決定開關哪些保護項目。
    .label = 自訂
preferences-etp-status-advanced-button =
    .label = 進階設定
preferences-etp-tracker-count-enabled =
    .label = 在網址列顯示追蹤器封鎖數量
preferences-etp-status-protections-dashboard-link =
    .description = 看看 { -brand-short-name } 已為您封鎖多少社群媒體追蹤器、數位指紋追蹤程式、加密貨幣採礦程式等類型的追蹤器。
    .label = 檢視您的個人化保護儀表板
preferences-etp-header =
    .heading = 加強型追蹤保護
preferences-etp-advanced-settings-group =
    .description = 網站會使用追蹤器在線上跟蹤您，並顯示可怕的廣告。{ -brand-short-name } 會在您上網時自動封鎖大多數的追蹤器，讓您可自行掌握自己的數位足跡。
    .label = 進階設定
preferences-etp-customize-button =
    .label = 自訂追蹤保護
preferences-etp-reload-tabs-hint =
    .message = 重新載入分頁才能套用變更。
preferences-etp-reload-tabs-hint-button =
    .label = 重新載入所有分頁
preferences-etp-rfp-warning-message =
    .message = 您開啟了 Resist Fingerprinting（RFP）功能，將蓋過 { -brand-short-name } 的部分數位指紋追蹤保護設定。此功能可能造成某些網站運作不正常。
preferences-etp-level-warning-message =
    .heading = 注意！某些網站可能會無法正常運作。
    .message = 某些網站會直接在功能或內容當中建立追蹤器。當 { -brand-short-name } 封鎖追蹤器後，這些功能就會故障。可以嘗試使用「修正網站問題」功能或針對該網站關閉追蹤保護機制。
preferences-etp-manage-exceptions-button =
    .description = 管理要針對哪些網站停用加強型追蹤保護功能。
    .label = 管理例外網站
preferences-etp-customize-header =
    .heading = 自訂追蹤保護
preferences-etp-reset =
    .description = 將選項重設回預先設計的保護等級。
    .label = 重設自訂項目
preferences-etp-reset-standard-button =
    .label = 重設為標準
preferences-etp-reset-strict-button =
    .label = 重設為嚴格
preferences-etp-custom-control-group =
    .description = 選擇要開啟或關閉哪些保護項目。
    .label = 追蹤保護
preferences-etp-custom-cookies-enabled =
    .label = Cookie
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookie
preferences-etp-custom-cookie-behavior-accept-all =
    .label = 所有網站都可使用 Cookie
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = 封鎖跨網站追蹤 Cookie
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = 封鎖跨網站 Cookie
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = 隔離跨網站 Cookie
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = 封鎖來自未造訪過網站的 Cookie
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = 封鎖所有跨網站 Cookie（可能會造成網站運作不正常）
preferences-etp-custom-cookie-behavior-block-all =
    .label = 封鎖所有 Cookie（會造成網站不正常）
preferences-etp-custom-tracking-protection-enabled =
    .label = 追蹤用內容
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = 追蹤用內容
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = 加密貨幣採礦程式
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = 已知的數位指紋追蹤程式
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = 疑似是數位指紋追蹤程式
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = 疑似是數位指紋追蹤程式

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = 可能會讓某些追蹤器不設定 Cookie 就能追蹤您。
    .label = 未封鎖已知的數位指紋追蹤程式
security-privacy-issue-warning-third-party-cookies =
    .description = 某些網站可透過第三方 Cookie 在不同網站間追蹤您。
    .label = 已開啟第三方 Cookie
security-privacy-issue-warning-password-manager =
    .description = 密碼管理員可幫助您儲存網站的高強度密碼。
    .label = 已停用密碼管理員
security-privacy-issue-warning-popup-blocker =
    .description = 彈出型視窗很干擾人，也可能有害。
    .label = 已停用彈出型視窗封鎖器
security-privacy-issue-warning-extension-install =
    .description = 不用先詢問您，網站就可以直接安裝擴充套件到 { -brand-short-name }。
    .label = 網站可直接安裝擴充套件
security-privacy-issue-warning-safe-browsing =
    .description = 您暴露到詐騙與惡意軟體網站的機會將增加。
    .label = 不封鎖危險或詐騙內容
security-privacy-issue-warning-doh2 =
    .description = DNS over HTTPS 可幫助您對電信業者隱藏您將造訪的網站資訊。
    .label = 已停用 DNS over HTTPS
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello 可幫助您對電信業者隱藏您將造訪的網站資訊。
    .label = 已停用 Encrypted Client Hello
security-privacy-issue-warning-doh =
    .description = DNS over HTTPS 可對您的電信業者隱藏您造訪過的網站。
    .label = 已停用 DNS over HTTPS
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello 功能可對您的電信業者隱藏您造訪過的網站。
    .label = 已停用 Encrypted Client Hello
security-privacy-issue-warning-proxy-autodetection =
    .description = Proxy 自動設定功能可能會讓未受信任的網路監控您的上網行為。
    .label = 已開啟 Proxy 自動設定

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = 邀請其他人選用將隱私看得最重要的瀏覽器。
    .label = 分享 { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = 分享 { -brand-product-name }


pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = about:config 更改，邏輯分組且易於訪問
vorbit-header = vOrbit-lite 首選項
vorbit-warning-title = 注意！
vorbit-warning-description = 我們仔細選擇預設設定，專注於隱私和安全。更改這些設定時，請閱讀描述以了解這些更改的影響。
vorbit-ocsp-checkbox =
    .label = 強制執行 OCSP 硬失敗
vorbit-goog-safe-checkbox =
    .label = 啟用 Google 安全瀏覽
vorbit-goog-safe-download-checkbox =
    .label = 掃描下載
vorbit-ocsp-description = 如果無法執行 OCSP 檢查，則阻止連接到網站。
vorbit-ocsp-warning1 = 這樣會提高安全性，但當 OCSP 伺服器當機時會導致故障。
vorbit-goog-safe-description = 如果您擔心惡意軟體和網路釣魚，請考慮啟用它。
vorbit-goog-safe-warning1 = 因擔心審查而禁用，但推薦給不太高級的用戶。所有檢查都在本地進行。
vorbit-goog-safe-download-description = 允許安全瀏覽掃描您的下載，以識別可疑文件。
vorbit-goog-safe-download-warning1 = 所有檢查都在本地進行。
vorbit-footer = 有用的連結
vorbit-config-link = 所有進階設定 (about:config)
vorbit-open-profile = 打開用戶設定檔目錄
content-blocking-section-top-level-description = vOrbit-lite 預設支援並啟用嚴格模式下的增強跟蹤保護。這是瀏覽器中最重要的設置之一，因為它提供狀態分區、嚴格的阻止列表和其他精妙的隱私功能。我們不建議更改為其他模式。
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = 瀏覽器行為
vorbit-extension-update-checkbox2 =
    .label = 自動更新附加元件
    .description = 無需手動操作即可讓擴充套件保持在最新狀態。這有助於保障您的安全性。
vorbit-sync-checkbox2 =
    .label = 啟用 Firefox 同步
    .description = 將您的資料與其他瀏覽器同步。需重新啟動。
vorbit-autocopy-checkbox2 =
    .label = 啟用滑鼠中鍵貼上
    .description = 選取文字以進行複製，接著按滑鼠中鍵即可貼上。
vorbit-styling-checkbox2 =
    .label = 允許自訂 userChrome.css
    .description = 若您希望透過手動載入的佈景主題來自訂使用者介面，請啟用此選項。
vorbit-network-heading2 =
    .label = 網路
vorbit-ipv6-checkbox2 =
    .label = 啟用 IPv6
    .description = 允許 { -brand-short-name } 使用 IPv6 連線。
vorbit-privacy-heading2 =
    .label = 隱私權
vorbit-xorigin-ref-checkbox2 =
    .label = 限制跨來源參照位址
    .description = 僅在同源時傳送參照位址。
vorbit-broken-heading2 =
    .label = 數位指紋追蹤
vorbit-webgl-checkbox2 =
    .label = 一律允許 WebGL
    .description = 這將一律允許 WebGL，無須要求權限。
vorbit-webgl-prompt-checkbox2 =
    .label = 隱藏個別網站的 WebGL 彈出式視窗
    .description = 此選項會隱藏當網站嘗試建立 WebGL 環境時所顯示的彈出式視窗。您仍可透過點擊搜尋列中的圖示來手動喚出提示。
vorbit-rfp-checkbox2 =
    .label = 啟用 ResistFingerprinting
    .description = 啟用所有可用的數位指紋防護措施，但可能導致部分網站無法正常運作。
vorbit-letterboxing-checkbox2 =
    .label = 啟用視窗留白
    .description = 視窗留白會在您的視窗周圍加上邊距，以便回傳一組有限的取整解析度。
vorbit-security-heading2 =
    .label = 安全性
