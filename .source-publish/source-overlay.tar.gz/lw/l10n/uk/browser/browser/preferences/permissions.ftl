# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 36em
    .title = Винятки
permissions-close-key =
    .key = w
permissions-address = Адреса сайту
    .accesskey = д
permissions-block =
    .label = Блокувати
    .accesskey = Б
permissions-disable-etp =
    .label = Додати виняток
    .accesskey = в
permissions-session =
    .label = Дозволити на сеанс
    .accesskey = о
permissions-allow =
    .label = Дозволити
    .accesskey = Д
permissions-add =
    .label = Додати
    .accesskey = о
permissions-button-off =
    .label = Вимкнути
    .accesskey = В
permissions-button-off-temporarily =
    .label = Вимкнути тимчасово
    .accesskey = т
permissions-site-name =
    .label = Вебсайт
permissions-status =
    .label = Стан
permissions-remove =
    .label = Вилучити вебсайт
    .accesskey = л
permissions-remove-all =
    .label = Вилучити всі вебсайти
    .accesskey = с
permissions-save-changes-2 =
    .buttonlabelaccept = Зберегти зміни
    .buttonaccesskeyaccept = З
permission-dialog =
    .buttonlabelaccept = Зберегти зміни
    .buttonaccesskeyaccept = З
permissions-autoplay-menu = Типово для всіх вебсайтів:
permissions-searchbox =
    .placeholder = Пошук по сайту
permissions-capabilities-autoplay-allow =
    .label = Дозволити аудіо та відео
permissions-capabilities-autoplay-block =
    .label = Блокувати аудіо
permissions-capabilities-autoplay-blockall =
    .label = Блокувати аудіо та відео
permissions-capabilities-allow =
    .label = Дозволити
permissions-capabilities-block =
    .label = Блокувати
permissions-capabilities-prompt =
    .label = Завжди питати
permissions-capabilities-listitem-allow =
    .value = Дозволити
permissions-capabilities-listitem-block =
    .value = Блокувати
permissions-capabilities-listitem-allow-session =
    .value = Дозволити на сеанс
permissions-capabilities-listitem-off =
    .value = Вимкнено
permissions-capabilities-listitem-off-temporarily =
    .value = Вимкнено тимчасово

## Invalid Hostname Dialog

permissions-invalid-uri-title = Введено неправильне мережеве ім'я сервера
permissions-invalid-uri-label = Введіть правильне мережеве ім'я сервера

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Винятки для розширеного захисту від стеження
permissions-exceptions-manage-etp-desc = Ви можете вказати, для яких вебсайтів вимкнути розширений захист від стеження. Введіть точну адресу сайту, для якого потрібно виконати зміни, а потім натисніть "Додати виняток".

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Винятки – файли cookie та дані сайтів
permissions-exceptions-cookie-desc = Ви можете вказати, яким вебсайтам завжди дозволяти, а яким ніколи не дозволяти використовувати файли cookie та дані сайтів.  Введіть точну адресу сайту, який ви хочете додати, потім натисніть Блокувати, Дозволити на сеанс чи Дозволити.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Винятки – HTTPS-режим
permissions-exceptions-https-only-desc2 = Ви можете вимкнути HTTPS-режим для певних вебсайтів. { -brand-short-name } не намагатиметься оновити з'єднання, щоб захистити ці сайти за допомогою HTTPS.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Дозволені сайти – спливні вікна та сторонні переспрямування
permissions-exceptions-popup-desc2 = Ви можете вказати вебсайти, для яких дозволяється відкриття спливних вікон і переспрямування за допомогою сторонніх фреймів.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Винятки – Збережені паролі
permissions-exceptions-saved-passwords-desc = { -brand-short-name } не зберігатиме паролі для зазначених тут сайтів.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Дозволені вебсайти - Встановлення додатків
permissions-exceptions-addons-desc = Ви можете вказати, яким сайтам дозволено встановлювати додатки. Введіть точну адресу кожного сайту і натисніть кнопку Дозволити.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Автовідтворення
permissions-site-autoplay-desc = Тут ви можете керувати сайтами, що не дотримуються ваших типових налаштувань автовідтворення.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи сповіщень
permissions-site-notification-desc = Зазначені тут вебсайти запитували дозвіл надсилати вам сповіщення. Ви можете вказати, яким вебсайтам дозволяється надсилати вам сповіщення. Ви також можете блокувати нові запити про надсилання сповіщень.
permissions-site-notification-disable-label =
    .label = Блокувати нові запити про отримання сповіщень
permissions-site-notification-disable-desc = Це не дозволить будь-яким переліченим вгорі вебсайтам запитувати дозвіл про надсилання сповіщень. Блокування сповіщень може вплинути на деякі функції вебсайтів.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи розташування
permissions-site-location-desc = Зазначені тут вебсайти запитували дозвіл на доступ до вашого розташування. Ви можете вказати, яким вебсайтам дозволяється отримувати доступ до вашого розташування. Ви також можете блокувати нові запити на доступ до вашого розташування.
permissions-site-location-disable-label =
    .label = Блокувати нові запити про отримання доступу до вашого розташування
permissions-site-location-disable-desc = Це не дозволить будь-яким переліченим вгорі вебсайтам запитувати дозвіл на отримання доступу до вашого розташування. Блокування доступу до розташування може вплинути на деякі функції вебсайтів.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи віртуальної реальності
permissions-site-xr-desc = Зазначені вебсайти запитували дозвіл на доступ до ваших пристроїв віртуальної реальності. Ви можете вказати, яким вебсайтам дозволено отримувати доступ до пристроїв віртуальної реальності. Ви також можете блокувати нові запити на доступ до пристроїв віртуальної реальності.
permissions-site-xr-disable-label =
    .label = Блокувати нові запити про отримання доступу до ваших пристроїв віртуальної реальності
permissions-site-xr-disable-desc = Це не дозволить будь-яким переліченим вгорі вебсайтам запитувати дозвіл на отримання доступу до ваших пристроїв віртуальної реальності. Блокування доступу до пристроїв віртуальної реальності може вплинути на роботу деяких функцій вебсайту.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи камери
permissions-site-camera-desc = Зазначені тут вебсайти запитували дозвіл на доступ до вашої камери. Ви можете вказати, яким вебсайтам дозволяється отримувати доступ до вашої камери. Ви також можете блокувати нові запити на доступ до вашої камери.
permissions-site-camera-disable-label =
    .label = Блокувати нові запити про отримання доступу до вашої камери
permissions-site-camera-disable-desc = Це не дозволить будь-яким переліченим вгорі вебсайтам запитувати дозвіл на отримання доступу до вашої камери. Блокування доступу до камери може вплинути на деякі функції вебсайтів.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Налаштування – Програми та служби пристрою
permissions-site-localhost-desc = Ці вебсайти подали запит на доступ до програм і служб на цьому пристрої. Ви можете дозволити або заборонити доступ.
permissions-site-localhost-disable-label =
    .label = Блокувати нові запити на доступ до програм і служб на цьому пристрої
permissions-site-localhost-disable-desc = Ця дія заборонить будь-яким вебсайтам, крім зазначених вище, запитувати доступ до програм і служб на цьому пристрої. Це може вплинути на роботу певних функцій вебсайтів.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Налаштування – Пристрої локальної мережі
permissions-site-local-network-desc = Ці вебсайти запитують доступ до програм і служб на пристроях, під'єднаних до вашої мережі Wi-Fi або локальної мережі. Ви можете дозволити або заборонити доступ.
permissions-site-local-network-disable-label =
    .label = Блокувати нові запити на доступ до програм і служб на пристроях, під'єднаних до вашої мережі Wi-Fi або локальної мережі.
permissions-site-local-network-disable-desc = Ця дія заборонить будь-яким веб-сайтам, крім зазначених вище, запитувати доступ до програм і служб на пристроях, під'єднаних до вашої мережі Wi-Fi або локальної мережі. Це може вплинути на роботу певних функцій вебсайтів.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи мікрофону
permissions-site-microphone-desc = Зазначені тут вебсайти запитували дозвіл на доступ до вашого мікрофону. Ви можете вказати, яким вебсайтам дозволяється отримувати доступ до вашого мікрофону. Ви також можете блокувати нові запити на доступ до вашого мікрофону.
permissions-site-microphone-disable-label =
    .label = Блокувати нові запити про отримання доступу до вашого мікрофону
permissions-site-microphone-disable-desc = Це не дозволить будь-яким переліченим вгорі вебсайтам запитувати дозвіл на отримання доступу до вашого мікрофону. Блокування доступу до мікрофону може вплинути на деякі функції вебсайтів.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Налаштування - Дозволи гучномовців
permissions-site-speaker-desc = Ці вебсайти запитували дозвіл на вибір пристрою виводу звуку. Ви можете вказати, яким вебсайтам дозволено вибирати пристрій аудіовиводу.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Винятки вебсайтів для DNS через HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } не використовуватиме захищену DNS на цих сайтах та їхніх піддоменах.
permissions-doh-entry-field = Введіть доменне ім'я вебсайту
    .accesskey = о
permissions-doh-add-exception =
    .label = Додати
    .accesskey = т
permissions-doh-col =
    .label = Домен
permissions-doh-remove =
    .label = Вилучити
    .accesskey = В
permissions-doh-remove-all =
    .label = Вилучити все
    .accesskey = и


