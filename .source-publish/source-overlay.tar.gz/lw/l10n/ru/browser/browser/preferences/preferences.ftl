# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Сообщать веб-сайтам, чтобы они не продавали и не разглашали мои данные
    .accesskey = ы
non-technical-privacy-group =
    .label = Настройки конфиденциальности веб-сайта
do-not-track-removal3 =
    .message = Мы больше не поддерживаем функцию «Не отслеживать».
non-technical-privacy-heading =
    .label = Дополнительная защита
preferences-privacy-relay-available =
    .description = Скрывает ваш реальный адрес электронной почты, чтобы защитить ваш почтовый ящик от спама.
    .label = Предлагать псевдонимы электронной почты { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Настройки
category-nav-heading =
    .heading = Настройки
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Поиск в настройках
    .style = width: 15.4em
managed-notice = Ваш браузер управляется Вашей организацией.
managed-notice-info-icon =
    .alt = Информация
managed-notice-nav =
    .label = Ваш браузер управляется Вашей организацией.
tls-key-logging-notice-nav =
    .label = Приложение или сервис могут просматривать ваш зашифрованный трафик.
category-list =
    .aria-label = Категории
pane-general-title = Основные
pane-home-title = Начало
pane-home-startup-title2 = Домашняя страница и запуск
    .title = Домашняя страница и запуск
pane-search-title2 = Поиск
    .title = Поиск
pane-privacy-title3 = Приватность и защита
    .title = Приватность и защита
pane-privacy-section =
    .heading = Приватность и защита
pane-sync-title3 = Синхронизация
pane-ai-controls-title2 = Управление ИИ
    .title = Управление ИИ
pane-about-firefox-title = О { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Внешний вид
    .title = { pane-appearance-title }
pane-downloads-title2 = Загрузки
    .title = Загрузки
pane-downloads3 =
    .heading = Загрузки
pane-accessibility-title = Поддержка доступности
    .title = { pane-accessibility-title }
pane-languages-title2 = Языки
    .title = Языки
preferences-languages-header3 =
    .heading = Языки
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Попробуйте наши экспериментальные возможности! Они находятся в разработке и развитии, что может повлиять на работу { -brand-short-name }. Мы получаем данные об использовании вами этих функций, только если у вас включены <a data-l10n-name="data-collection">технические данные и данные о взаимодействии</a>.
pane-experimental-reset =
    .label = Восстановить значения по умолчанию
    .accesskey = с
help-button-label2 = Поддержка { -brand-short-name }
    .title = Поддержка { -brand-short-name }
addons-button-label2 = Расширения и темы
    .title = Расширения и темы
focus-search =
    .key = f
close-button =
    .aria-label = Закрыть
do-not-track-removal2 =
    .label = Мы больше не поддерживаем сигнал «Не отслеживать»
applications-setting-new-file-types =
    .label = Что { -brand-short-name } должен делать с другими файлами?

## Browser Restart Dialog

feature-enable-requires-restart = Для включения этого режима необходимо перезапустить { -brand-short-name }.
feature-disable-requires-restart = Для отключения этого режима необходимо перезапустить { -brand-short-name }.
should-restart-title = Перезапуск { -brand-short-name }
should-restart-ok = Перезапустить { -brand-short-name } сейчас
cancel-no-restart-button = Отмена
restart-later = Перезапустить позже

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> управляет этой настройкой.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> управляет этой настройкой.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> требует для своей работы «Вкладки в контейнере».
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> управляет этой настройкой.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> контролирует способ соединения { -brand-short-name } с Интернетом.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Чтобы включить расширение, перейдите в пункт <img data-l10n-name="addons-icon"/> «Дополнения» в меню <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Чтобы снова включить это расширение, посетите <a data-l10n-name="addons-link">Расширения и темы</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } контролирует некоторые настройки вашей домашней страницы.

## Preferences UI Search Results

search-results-header = Результаты поиска
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Извините! В настройках не найдено результатов по запросу «<span data-l10n-name="query"></span>».
search-results-help-link = Нужна помощь? Зайдите на <a data-l10n-name="url">сайт поддержки { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Всегда проверять, является ли { -brand-short-name } вашим браузером по умолчанию
    .accesskey = а
startup-restore-windows-and-tabs =
    .label = Открывать предыдущие окна и вкладки
    .accesskey = п
startup-windows-launch-on-login-profile-disabled =
    .message = Включите эту настройку, установив флажок «{ profile-manager-use-selected.label }» в окне «Выбор профиля пользователя».
windows-launch-on-login =
    .label = Открывать { -brand-short-name } автоматически при загрузке компьютера
    .accesskey = м
windows-launch-on-login-disabled = Эта настройка отключена в Windows. Чтобы изменить это, откройте <a data-l10n-name="startup-link">Автозагрузка приложений</a> в настройках системы.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Также открыть новую вкладку
    .accesskey = n
disable-extension =
    .label = Отключить расширение
preferences-data-migration-group =
    .description = Перенесите свои закладки, пароли, историю, расширения и данные автозаполнения из другого браузера.
    .label = Импорт данных браузера
preferences-data-migration-button =
    .label = Импорт данных
    .accesskey = м
preferences-profiles-group-header =
    .heading = Профили
preferences-profiles-subpane-description =
    .description = Каждый профиль имеет отдельные данные и настройки просмотра, включая историю просмотра, пароли и пр.
preferences-profiles-section-header =
    .description = Каждый профиль имеет отдельные данные и настройки просмотра, включая историю просмотра, пароли и пр.
    .label = Профили
preferences-manage-profiles-button =
    .label = Управление профилями
preferences-profiles-settings-button =
    .label = Настройки
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = В новом профиле будут скопированы ваши настройки, дополнения, история и сохранённые данные, такие как закладки и пароли, но не ваш аккаунт или информация синхронизации.
    .label = Копировать существующий профиль
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Профиль для копирования
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Выбрать профиль
preferences-copy-profile-button = Копировать
tabs-browsing-section =
    .heading = Вкладки и просмотр
pane-tabs-browsing-title2 = Вкладки и просмотр
    .title = Вкладки и просмотр
tabs-group-header2 =
    .label = Вкладки
tabs-opening-heading =
    .label = Открытие
tabs-interaction-heading =
    .label = Взаимодействие
tabs-containers-heading =
    .label = Контейнеры
tabs-closing-heading =
    .label = Закрытие
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab переключает между вкладками в порядке недавнего использования
    .accesskey = ж
open-new-link-as-tabs =
    .label = Открывать ссылки во вкладках вместо новых окон
    .accesskey = ы
open-external-link-next-to-active-tab =
    .label = Открывайте ссылки из приложений рядом с активной вкладкой
ask-on-close-multiple-tabs =
    .label = Спрашивать перед закрытием нескольких вкладок
    .accesskey = ь
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Спрашивать перед выходом с помощью { $quitKey }
    .accesskey = и
warn-on-open-many-tabs =
    .label = Предупреждать, когда открытие нескольких вкладок может замедлить { -brand-short-name }
    .accesskey = р
switch-to-new-tabs-2 =
    .label = При открытии ссылок или медиа в новой вкладке, переключаться на них немедленно
    .accesskey = р
show-tabs-in-taskbar =
    .label = Отображать эскизы вкладок на панели задач Windows
    .accesskey = б
browser-containers-enabled-2 =
    .label = Использовать вкладки в контейнере
    .accesskey = т
browser-containers-learn-more = Подробнее
browser-containers-settings-2 =
    .label = Управление настройками
    .accesskey = ш
containers-disable-alert-title = Закрыть все вкладки в контейнере?
startup-group =
    .label = Запуск

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Если вы отключите сейчас вкладки в контейнере, { $tabCount } вкладка в контейнере будет закрыта. Вы уверены, что хотите отключить вкладки в контейнере?
        [few] Если вы отключите сейчас вкладки в контейнере, { $tabCount } вкладки в контейнере будут закрыты. Вы уверены, что хотите отключить вкладки в контейнере?
       *[many] Если вы отключите сейчас вкладки в контейнере, { $tabCount } вкладок в контейнере будут закрыты. Вы уверены, что хотите отключить вкладки в контейнере?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Закрыть { $tabCount } вкладку в контейнере
        [few] Закрыть { $tabCount } вкладки в контейнере
       *[many] Закрыть { $tabCount } вкладок в контейнере
    }

##

containers-disable-alert-cancel-button = Оставить включёнными
containers-remove-alert-title = Удалить этот контейнер?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Если вы удалите сейчас этот контейнер, { $count } вкладка в контейнере будет закрыта. Вы уверены, что хотите удалить этот контейнер?
        [few] Если вы удалите сейчас этот контейнер, { $count } вкладки в контейнере будут закрыты. Вы уверены, что хотите удалить этот контейнер?
       *[many] Если вы удалите сейчас этот контейнер, { $count } вкладок в контейнере будут закрыты. Вы уверены, что хотите удалить этот контейнер?
    }
containers-remove-ok-button = Удалить этот контейнер
containers-remove-cancel-button = Не удалять этот контейнер
settings-tabs-show-image-in-preview =
    .label = Отображать предпросмотр изображения при наведении на вкладку
    .accessKey = h
settings-tabs-drag-to-create-tab-groups =
    .label = Перетаскивайте вкладки, чтобы создать группы вкладок
browser-layout-header2 =
    .label = Внешний вид браузера
browser-layout-horizontal-tabs2 =
    .description = Вкладки вверху
    .label = Горизонтальные вкладки
    .title = Вкладки вверху
browser-layout-vertical-tabs2 =
    .description = Вкладки сбоку, на боковой панели
    .label = Вертикальные вкладки
    .title = Вкладки сбоку, на боковой панели
browser-layout-show-sidebar2 =
    .description = Быстрый доступ к закладкам, вкладкам с телефона, ИИ-чат-ботам и многому другому, не покидая основного вида.
    .label = Показать боковую панель
page-navigation-group =
    .label = Навигация по странице

## General Section - Language & Appearance

language-and-appearance-header = Язык и внешний вид
appearance-group2 =
    .description = Некоторые веб-сайты изменяют свои цвета, чтобы удовлетворять вашим предпочтениям. Выберите вашу цветовую схему.
    .label = Внешний вид веб-сайтов
preferences-web-appearance-choice-auto3 =
    .label = Системная
    .title = Автоматически изменяет фон веб-сайта и содержимое на основе настроек вашей системы и темы { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Светлая
    .title = Использовать светлый вид для фона и содержимого сайтов.
preferences-web-appearance-choice-dark2 =
    .label = Тёмная
    .title = Использовать тёмный вид для фона и содержимого сайтов.
web-appearance-group =
    .aria-label = Внешний вид сайтов
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Ваши настройки контрастности переопределяют внешний вид сайтов.
preferences-web-appearance-link =
    .label = Управляйте темами { -brand-short-name } в разделе «Расширения и темы»
preferences-contrast-control-group =
    .description = Веб-сайты используют различные цвета переднего плана и фона. Для обеспечения постоянного контраста вы можете использовать одни и те же цвета на разных веб-сайтах.
    .label = Контраст веб-сайта
preferences-contrast-control-radio-group =
    .label = Переопределять цвета
preferences-contrast-control-use-platform-settings =
    .label = Автоматически (использовать системные настройки)
    .accesskey = Ф
preferences-contrast-control-off =
    .label = Откл.
    .accesskey = Щ
preferences-contrast-control-custom =
    .label = Персональная
    .accesskey = Ц
preferences-colors-manage-button2 =
    .label = Управление цветами
    .accesskey = м
preferences-colors-manage-button =
    .label = Управление цветами…
    .accesskey = м
preferences-fonts-header2 =
    .label = Шрифты
preferences-default-zoom-label =
    .label = Масштаб по умолчанию
    .accesskey = ш
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Только текст
    .accesskey = о
preferences-text-zoom-override-warning2 =
    .message = Если включено «Масштабировать только текст» и масштаб по умолчанию не 100%, то некоторые сайты могут отображать содержимое некорректно.
language-header = Язык
choose-language-description = Выберите язык, предпочитаемый вами для отображения страниц
website-language-heading =
    .description = Некоторые веб-страницы отображаются на нескольких языках. Выберите языки в удобном для вас порядке.
    .label = Язык веб-сайта
website-preferred-language =
    .label = Предпочитаемые языки
website-language-list =
    .aria-label = Предпочитаемые языки
website-add-language =
    .label = Добавить язык
website-add-language-button =
    .aria-label = Добавить выбранный язык
    .title = Добавить выбранный язык
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Удалить: { $locale }
    .title = Удалить: { $locale }
choose-button =
    .label = Выбрать…
    .accesskey = ы
choose-browser-language-description = Выберите язык отображения меню, сообщений и уведомлений от { -brand-short-name }.
manage-browser-languages-button =
    .label = Выбрать альтернативные…
    .accesskey = ы
confirm-browser-language-change-description = Перезапустите { -brand-short-name } для применения этих изменений
confirm-browser-language-change-button = Применить и перезапустить
browser-language-heading =
    .description = Выберите язык, использующийся для отображения меню, сообщений и уведомлений от { -brand-short-name }.
    .label = Язык браузера
browser-language-preferred-label =
    .label = Предпочитаемый язык
browser-language-fallback-label =
    .description = Используется, когда локализация предпочитаемого языка не завершена.
    .label = Резервный язык
browser-language-install-error =
    .message = { -brand-short-name } не может обновить ваши языки прямо сейчас. Проверьте, что вы подключены к Интернету, или попробуйте снова.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Исключения…
    .accesskey = л
settings-translations-header =
    .aria-label = Переводы
    .description = Переводите страницы или выделенный текст. Чтобы защитить вашу конфиденциальность, переводы сохраняются на вашем устройстве.
    .label = Переводы
settings-translations-offer-to-translate-label =
    .label = Предлагать полный перевод страницы
settings-translations-more-settings-button =
    .description = Установите настройки для языков, веб-сайтов и автономного перевода.
    .label = Все настройки перевода
settings-translations-subpage-header =
    .heading = Все настройки перевода
settings-translations-subpage-speed-up-translation-header =
    .description = Скачивайте полные версии языков для более быстрого перевода и для перевода в автономном режиме.
    .label = Ускорить перевод
settings-translations-subpage-automatic-translation-header =
    .label = Автоматический перевод
settings-translations-subpage-always-translate-header =
    .label = Всегда переводить с этих языков
settings-translations-subpage-never-translate-header =
    .label = Никогда не переводить с этих языков
settings-translations-subpage-never-translate-sites-header =
    .label = Никогда не переводить эти сайты
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Чтобы добавить сайт, откройте панель перевода <img data-l10n-name="translations-icon"/>, выберите <img data-l10n-name="settings-icon"/> настройки перевода, затем выберите «Никогда не переводить этот сайт»
settings-translations-subpage-language-select-option =
    .label = Добавить язык
settings-translations-subpage-language-add-button =
    .aria-label = Добавить язык
    .title = Добавить язык
settings-translations-subpage-download-languages-header =
    .label = Скачать языки
settings-translations-subpage-download-languages-select-option =
    .label = Выберите язык
settings-translations-subpage-download-languages-button =
    .aria-label = Скачать язык
    .title = Скачать язык
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } МБ)
    .label = { $language } ({ $size } МБ)
settings-translations-subpage-no-languages-downloaded =
    .label = Ни одного языка не загружено
settings-translations-subpage-no-languages-added =
    .label = Языки не добавлены
settings-translations-subpage-download-progress = Идёт скачивание…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Не удалось загрузить { $language } ({ $size } МБ)
settings-translations-subpage-download-retry-button =
    .label = Попробовать снова
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Удалить: { $language } ({ $size } МБ)?
settings-translations-subpage-download-delete-button =
    .label = Удалить
settings-translations-subpage-download-cancel-button =
    .label = Отмена
settings-translations-subpage-no-sites-added =
    .label = Сайты не добавлены
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Использовать настройки «{ $localeName }» вашей операционной системы для форматирования даты, времени, чисел и единиц измерения
settings-spellcheck-header =
    .label = Проверка орфографии
check-user-spelling =
    .label = Проверять орфографию при наборе текста
    .accesskey = в
spellcheck-download-dictionaries =
    .label = Скачать словари
spellcheck-promo =
    .heading = Как использовать проверку орфографии
    .message = Щёлкните правой кнопкой мыши текстовое поле, чтобы включить или отключить проверку орфографии или изменить язык. Не все поля поддерживают проверку орфографии.

## Downloads - Files and applications

files-and-applications-title = Файлы и приложения
download-save-files-header =
    .label = Путь для сохранения файлов
download-save-where-3 =
    .aria-label = Путь для сохранения файлов
download-always-ask-where2 =
    .label = Спрашивать, где сохранять файлы, перед загрузкой
    .accesskey = Ф
download-private-browsing-delete2 =
    .label = Удалять загрузки приватного окна при закрытии
    .accesskey = В
applications-header = Приложения
applications-description = Выберите, как { -brand-short-name } будет обрабатывать файлы, скачиваемые из Интернета, или приложения, используемые при работе в Интернете.
applications-setting2 =
    .description = Выберите, как { -brand-short-name } обрабатывает скачанные файлы и содержимое.
    .label = Файлы и приложения
applications-filter =
    .placeholder = Поиск типов файлов или приложений
applications-type-column =
    .label = Тип содержимого
    .accesskey = о
applications-type-heading = Тип содержимого
applications-action-column =
    .label = Действие
    .accesskey = е
applications-action-heading = Действие
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } файл
applications-action-save =
    .label = Сохранить файл
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Использовать { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Использовать { $app-name } (по умолчанию)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Использовать приложение macOS по умолчанию
            [windows] Использовать приложение Windows по умолчанию
           *[other] Использовать системное приложение по умолчанию
        }
applications-use-other =
    .label = Использовать другое…
applications-select-helper = Выберите вспомогательное приложение
applications-manage-app =
    .label = Сведения о приложении…
applications-always-ask =
    .label = Всегда спрашивать
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Открыть в { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Что { -brand-short-name } должен делать с другими файлами?
applications-save-for-new-types =
    .label = Сохранять файлы
    .accesskey = я
applications-save-for-new-types2 =
    .label = Автоматически сохранять файлы
    .accesskey = Ы
applications-ask-before-handling =
    .label = Спрашивать, открывать или сохранять файлы
    .accesskey = ш
applications-ask-before-handling2 =
    .label = Спрашивать, открывать или сохранять файлы
    .accesskey = Ф
drm-group =
    .label = Содержимое, использующее средства защиты авторских прав (DRM)
play-drm-content =
    .label = Воспроизводить защищённое DRM содержимое
    .accesskey = п
play-drm-content-learn-more = Подробнее
# Variables:
# $version (string) - Firefox version
update-application-version = Версия { $version } <a data-l10n-name="learn-more">Что нового</a>
update-history-2 =
    .label = Показать журнал обновлений
    .accesskey = ж
update-application-installation =
    .label = Установка
update-application-radio-group =
    .aria-label = Установка
update-application-auto-2 =
    .label = Автоматически устанавливать обновления (рекомендуется)
    .accesskey = Ф
update-application-check-choose-2 =
    .label = Проверять наличие обновлений, но выбирать, когда их устанавливать
    .accesskey = С
update-application-background-enabled =
    .label = Когда { -brand-short-name } не запущен
    .accesskey = а
update-application-warning-cross-user-setting-2 =
    .message = Эта настройка применится ко всем учётным записям Windows и профилям { -brand-short-name }, использующим эту установку { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Показывать меньше напоминаний об обновлениях
    .accesskey = n
update-setting-write-failure-title2 = Ошибка при сохранении настроек обновления
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } столкнулся с ошибкой и не смог сохранить это изменение. Обратите внимание, что для изменения этой настройки обновления необходимо разрешение на запись в указанный ниже файл. Вы или системный администратор можете исправить эту проблему, если предоставите группе «Пользователи» полный доступ к этому файлу.
    
    Не удалось произвести запись в файл: { $path }
update-in-progress-title = Идёт обновление
update-in-progress-message = Вы хотите продолжить обновление { -brand-short-name }?
update-in-progress-ok-button = &Отменить
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Продолжить

## About Firefox

about-firefox-header =
    .heading = О { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Обновления улучшают скорость, стабильность и безопасность { -brand-short-name }.
    .label = Обновления { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Уведомления
update-application-updates-managed-by-os =
    .message = Обновления управляются вашей операционной системой

## Firefox support

support-application-heading =
    .description = Устраняйте неполадки или делитесь идеями с сообществом.
    .label = Поддержка { -brand-short-name }
support-get-help =
    .label = Получить помощь
support-share-ideas =
    .label = Делитесь идеями и отзывами

## Firefox newsletter

newsletter-settings-heading =
    .description = Получайте руководства, новости и советы о том, как сделать вашу работу с { -brand-product-name } максимально комфортной.
    .label = Новостная рассылка { -brand-product-name }
newsletter-sign-up-link =
    .label = Подписаться

## General Section - Performance

performance-settings-learn-more = Подробнее
performance-allow-hw-accel =
    .label = По возможности использовать аппаратное ускорение
    .accesskey = л
performance-limit-content-process-option = Максимальное число процессов контента
    .accesskey = в
performance-limit-content-process-enabled-desc = Дополнительные процессы контента могут улучшить производительность при работе со множеством вкладок, но также повысят потребление памяти.
performance-limit-content-process-blocked-desc = Изменение числа процессов контента возможно только во многопроцессном { -brand-short-name }. <a data-l10n-name="learn-more">Узнайте, как проверить, включена ли многопроцессность</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (по умолчанию)
performance-group =
    .label = Производительность
performance-use-recommended-settings-checkbox-2 =
    .description = Эти настройки привязаны к вашему устройству и операционной системе.
    .label = Использовать рекомендуемые настройки производительности
    .accesskey = Г

## Accessibility page

browsing-use-autoscroll =
    .label = Использовать автоматическую прокрутку
    .accesskey = а
keyboard-and-scrolling-group =
    .label = Навигация и прокрутка с помощью клавиатуры
motion-and-link-group =
    .label = Стили движений и ссылок
browsing-use-smooth-scrolling =
    .label = Использовать плавную прокрутку
    .accesskey = п
browsing-gtk-use-non-overlay-scrollbars =
    .label = Всегда показывать полосы прокрутки
    .accesskey = о
browsing-always-underline-links =
    .label = Всегда подчёркивать ссылки
    .accesskey = е
browsing-use-onscreen-keyboard =
    .label = При необходимости показывать сенсорную клавиатуру
    .accesskey = с
browsing-use-cursor-navigation =
    .label = Всегда использовать клавиши курсора для навигации по страницам
    .accesskey = к
browsing-use-full-keyboard-navigation =
    .label = Использовать клавишу табуляции для перемещения фокуса между элементами управления формой и ссылками.
    .accesskey = е
browsing-search-on-start-typing =
    .label = Искать текст на странице по мере его набора
    .accesskey = И
settings-keyboard-shortcuts-group =
    .description = Контролируйте, как вы перемещаетесь и взаимодействуете с { -brand-short-name }
    .label = Сочетания клавиш
settings-keyboard-shortcuts-customkeys-link =
    .label = Настроить горячие клавиши
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Настройка параметров адресной строки в Поиске
settings-media-group =
    .label = Медиа
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Использовать Картинку-в-Картинке
    .accesskey = у
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Продолжать воспроизводить видео в режиме «Картинка в картинке» при переключении вкладок
    .accesskey = ы
browsing-media-control =
    .label = Управлять воспроизведением звука или видео с помощью клавиатуры, гарнитуры или виртуального интерфейса
    .accesskey = У
recommendations-group =
    .label = Рекомендации
browsing-cfr-recommendations =
    .label = Рекомендовать расширения при просмотре
    .accesskey = р
browsing-cfr-features =
    .label = Рекомендовать функции при просмотре
    .accesskey = ф
browsing-group =
    .label = Просмотр сети
preferences-accessibility-header =
    .heading = Поддержка доступности
preferences-default-zoom-select =
    .aria-label = Масштаб по умолчанию
preferences-fonts-family =
    .label = Тип шрифта
    .accesskey = В
preferences-fonts-size =
    .label = Размер шрифта
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = Дополнительные настройки
    .accesskey = Ф

## General Section - Proxy

network-proxy-group2 =
    .description = Настройте способ подключения { -brand-short-name } к интернету.
    .label = Настройки прокси
network-proxy-connection-settings2 =
    .description = Изменение этих настроек может привести к проблемам с подключением
    .label = Настроить прокси
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Новые окна и вкладки
home-new-windows-tabs-description2 = Выберите, что вы хотите увидеть, когда откроете домашнюю страницу, новые окна и новые вкладки.
home-section =
    .heading = Домашняя страница и запуск

## Home Section - Default Browser

home-default-browser-title =
    .label = Браузер по умолчанию
is-default-browser-2 =
    .message = { -brand-short-name } — ваш браузер по умолчанию. Хороший выбор.
is-not-default-browser-2 =
    .message = Псс, { -brand-short-name } не является вашим браузером по умолчанию.
set-as-my-default-browser-2 =
    .label = Сделать браузером по умолчанию
    .accesskey = у

## Custom Homepage subpage

home-homepage-mode-label = Домашняя страница и новые окна
home-newtabs-mode-label = Новые вкладки
home-restore-defaults =
    .label = Восстановить по умолчанию
    .accesskey = о
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name(case: "nominative_uppercase") } (по умолчанию)
home-mode-choice-custom =
    .label = Мои URL-адреса…
home-mode-choice-blank =
    .label = Пустая страница
home-homepage-custom-url =
    .placeholder = Вставьте URL-адрес…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Управление расширением
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Использовать текущую страницу
           *[other] Использовать текущие страницы
        }
    .accesskey = п
choose-bookmark =
    .label = Использовать закладку…
    .accesskey = в
home-homepage-title =
    .label = Домашняя страница
home-homepage-new-windows =
    .label = Новые окна
home-homepage-new-tabs =
    .label = Новые вкладки
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Выбрать определённый сайт
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Адрес(а) веб-сайтов
home-custom-homepage-list =
    .aria-label = Адреса веб-сайтов
home-custom-homepage-address =
    .placeholder = Введите адрес
home-custom-homepage-address-button =
    .label = Добавить адрес
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Пока не добавлено ни одного веб-сайта.
home-custom-homepage-delete-address-button =
    .aria-label = Удалить адрес
    .title = Удалить адрес
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Заменить на
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Текущие открытые страницы
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Закладки…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Расширение ({ $extension })
home-custom-homepage-header = Настраиваемая домашняя страница
home-custom-homepage-subpage =
    .heading = Настраиваемая домашняя страница

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Содержимое { -firefox-home-brand-name(case: "genitive") }
home-prefs-content-description2 = Выберите, какое содержимое вы хотите видеть на экране { -firefox-home-brand-name(case: "genitive") }.
home-prefs-search-header =
    .label = Поиск в Интернете
home-prefs-shortcuts-header =
    .label = Ярлыки
home-prefs-shortcuts-description = Сохранённые или посещаемые сайты
home-prefs-shortcuts-by-option-sponsored =
    .label = Спонсируемые ярлыки
home-prefs-recommended-by-header-generic =
    .label = Рекомендуемые истории
home-prefs-recommended-by-description-generic = Исключительный контент, курируемый семейством { -brand-product-name }
home-prefs-stories-header =
    .label = Истории
home-prefs-stories-description = Персонализированные истории на основе вашей активности

##

home-prefs-recommended-by-learn-more = Как это работает
home-prefs-recommended-by-option-sponsored-stories =
    .label = Статьи спонсоров
home-prefs-highlights-option-visited-pages =
    .label = Посещённые страницы
home-prefs-highlights-options-bookmarks =
    .label = Закладки
home-prefs-highlights-option-most-recent-download =
    .label = Недавние загрузки
home-prefs-recent-activity-header =
    .label = Последние действия
home-prefs-recent-activity-description = Подборка недавних сайтов и контента
home-prefs-weather-header =
    .label = Погода
home-prefs-weather-description = Краткий прогноз на сегодня
home-prefs-weather-learn-more-link = Подробнее
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Поддержите { -brand-product-name }
home-prefs-mission-message = Наши спонсоры поддерживают нашу миссию по построению лучшего Интернета
home-prefs-mission-message-learn-more-link = Узнать как
home-prefs-manage-topics-link = Управление темами
home-prefs-choose-wallpaper-link = Выберите обои
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } строка
            [few] { $num } строки
           *[many] { $num } строк
        }

## Search Section

search-show-suggestions-option =
    .label = Показывать поисковые предложения
    .accesskey = ы
search-show-suggestions-url-bar-option =
    .label = Отображать поисковые предложения при использовании адресной строки
    .accesskey = ж
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Отображать поисковые предложения перед историей посещений в результатах адресной строки
search-show-suggestions-private-windows-2 =
    .label = Поисковые предложения в приватных окнах
search-suggestions-cant-show-2 =
    .message = При использовании адресной строки поисковые предложения отображаться не будут, так как вы настроили { -brand-short-name } никогда не запоминать историю.
addressbar-header-1 =
    .description = Выберите, какие предложения отображаются в вашей адресной строке
    .label = Адресная строка
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Предложения от { -brand-short-name } и наших партнёров в вашей адресной строке.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Показывать поисковые запросы в адресной строке на страницах с результатами
search-separate-default-engine-2 =
    .label = Использовать другую поисковую систему по умолчанию в приватных окнах
    .accesskey = Г
search-separate-default-engine-dropdown =
    .aria-label = Поисковая система по умолчанию в приватных окнах
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Навигация адресной строки
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Пропускать меню результатов, когда вы используете клавишу табуляции для перемещения фокуса
search-suggestions-header-2 =
    .label = Предложения поисковых систем
search-one-click-header2 = Значки поисковых систем
search-one-click-desc = Выберите иные поисковые системы, которые появятся под адресной строкой и строкой поиска, когда вы начнёте вводить ключевое слово.
search-one-click-header-3 =
    .description = Выбрать. какие поисковые системы и их сокращения появляются в вашей адресной строке.
    .label = Дополнительные поисковые системы
search-engine-list =
    .aria-label = Поисковые системы и значки
update-search-engine-success =
    .message = Поисковая система успешно обновлена
search-edit-engine-2 =
    .title = Изменение поисковой системы
search-delete-engine =
    .title = Удалить поисковую систему
search-enable-engine =
    .title = Включить поисковую систему
search-outlink-to-extensions-page =
    .title = Управление в расширениях и темах
search-choose-engine-column =
    .label = Поисковая система
search-choose-keyword-column =
    .label = Ключевое слово
search-restore-default =
    .label = Восстановить поисковые системы по умолчанию
    .accesskey = а
search-remove-engine =
    .label = Удалить
    .accesskey = и
search-add-engine =
    .label = Добавить
    .accesskey = в
search-add-engine-2 =
    .label = Добавить поисковую систему
    .accesskey = Ф
search-edit-engine =
    .label = Изменить
    .accesskey = У
search-find-more-link = Найти другие поисковые системы
search-filtering-for-add-engine = Добавить поисковик
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Ключевое слово уже используется
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Выбранное ключевое слово уже используется «{ $name }». Пожалуйста, выберите другое.
search-keyword-warning-bookmark = Выбранное ключевое слово уже используется одной из закладок. Пожалуйста, выберите другое.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Поисковая система с именем «{ $name }» уже существует. Пожалуйста, выберите другое имя.
remove-engine-confirmation = Вы уверены, что хотите удалить эту поисковую систему?
remove-engine-remove = Удалить
remove-addon-engine-alert = Чтобы удалить эту поисковую систему, удалите связанное с ней дополнение.
search-engine-group =
    .label = Поисковая система по умолчанию
search-default-engine =
    .aria-label = Поисковая система по умолчанию
# Header for the search section ("search" is a noun).
search-section =
    .heading = Поиск

## Containers Section

containers-section-header2 =
    .heading = Настройки контейнера
containers-card-header2 =
    .description = Разделите куки по контейнерам, и таким образом вы сможете использовать разные аккаунты на одном и том же сайте и ограничить межсайтовое отслеживание.
    .label = Контейнеры
containers-add-button2 =
    .label = Добавить новый контейнер
    .accesskey = Ф
containers-list =
    .aria-label = Контейнеры
containers-new-tab-check3 =
    .label = Выбирать контейнер для каждой новой вкладки
    .accesskey = Ы
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Не использовать контейнеры для ссылок, открываемых из внешних приложений
    .accesskey = В
containers-new-tab-check2 =
    .description = Это вызывает меню контейнеров каждый раз, когда вы нажимаете кнопку открытия новой вкладки.
    .label = Выбирать контейнер для каждой новой вкладки
    .accesskey = Ы
containers-settings-button2 =
    .title = Настройки
containers-remove-button3 =
    .title = Удалить
containers-sites-card-header =
    .description = Выберите контейнер для определённого сайта, и { -brand-short-name } будет использовать его при каждом открытии этого сайта.
    .label = Контейнеры для сайтов
containers-sites-add-button =
    .label = Добавить веб-сайт
    .accesskey = w
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Контейнер для { $site }
containers-site-remove-button =
    .title = Удалить
containers-remove-button2 =
    .title = Удалить

## Account and sync

sync-group-label =
    .label = Синхронизация
account-group-label2 =
    .label = Аккаунт
account-disabled-group =
    .description = Настройки аккаунта недоступны.
    .label = Аккаунт
account-placeholder2 =
    .description = Войдите и сохраните свои данные в конфиденциальности, зашифрованными и мгновенно доступными везде, где вы используете { -brand-short-name }.
    .label = Вы не вошли
account-sync-section =
    .heading = Аккаунт и синхронизация
pane-account-sync-title2 = Аккаунт и синхронизация
    .title = Аккаунт и синхронизация

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Возьмите свой Интернет с собой
sync-signedout-description2 = Синхронизируйте свои закладки, историю, вкладки, пароли, дополнения и настройки со всеми своими устройствами.
sync-signedout-account-signin3 =
    .label = Войти в Синхронизацию…
    .accesskey = о
sync-signedout-account-signin-4 =
    .label = Войдите в свой аккаунт, чтобы начать синхронизацию
    .accesskey = ш
sync-signedout-account-short =
    .label = Войти
    .accesskey = ш
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Скачайте Firefox для <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> или <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a>, чтобы синхронизироваться со своим мобильным устройством.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Изменить фотографию в профиле
    .tooltiptext = Изменить фотографию в профиле
sync-profile-picture-account-problem =
    .alt = Фото профиля аккаунта
fxa-login-rejected-warning =
    .alt = Предупреждение
sync-sign-out =
    .label = Выйти…
    .accesskey = ы
sync-sign-out2 =
    .label = Выйти
    .accesskey = ы
sync-manage-account = Управление аккаунтом
    .accesskey = в
sync-manage-account2 =
    .label = Управление аккаунтом
    .accesskey = в

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } не подтверждён.
sync-signedin-unverified2 =
    .description = Проверьте свой почтовый ящик, чтобы подтвердить свой аккаунт и сделать его официальным.
    .label = { $email } ещё не подтвержден
sync-signedin-login-failure = Войдите для повтора соединения с { $email }
sync-signedin-login-failure2 =
    .description = Войдите снова, чтобы переподключиться и начать синхронизацию ваших данных.
    .label = Вы вышли из { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Подтвердить профиль
    .accesskey = м
sync-remove-account =
    .label = Удалить аккаунт
    .accesskey = л
sync-sign-in =
    .label = Войти
    .accesskey = о

## Sync section - enabling or disabling sync.

prefs-syncing-on = Синхронизация: ВКЛЮЧЕНА
prefs-syncing-on-2 =
    .label = Синхронизация ВКЛЮЧЕНА
prefs-syncing-off = Синхронизация: ОТКЛЮЧЕНА
prefs-syncing-off-2 =
    .description = Включите синхронизацию, чтобы получить доступ к вашим закладкам, паролям, истории и пр. на любом устройстве.
    .label = Синхронизация ОТКЛЮЧЕНА
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Включите синхронизацию, чтобы получить свои закладки, пароли, историю и многое другое на этом устройстве.
    .label = Синхронизация ОТКЛЮЧЕНА
prefs-sync-turn-on-syncing =
    .label = Включить синхронизацию…
    .accesskey = ю
prefs-sync-turn-on-syncing-2 =
    .label = Включить синхронизацию
    .accesskey = ю
prefs-sync-offer-setup-label2 = Синхронизируйте свои закладки, историю, вкладки, пароли, дополнения и настройки со всеми своими устройствами.
prefs-sync-now-button =
    .label = Синхронизировать
    .accesskey = т
prefs-sync-now-button-2 =
    .label = Синхронизировать
    .accesskey = т
prefs-syncing-button =
    .label = Синхронизирую…
prefs-syncing-button-2 =
    .label = Синхронизирую…
    .title = Синхронизировать
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Ваши настройки синхронизации теперь применимы только к этому устройству.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Вы синхронизируете эти элементы на всех подключённых устройствах:
sync-syncing-across-devices-heading-2 = Данные между устройствами синхронизированы
sync-syncing-across-devices-heading-3 = Синхронизация данных на этом устройстве
sync-syncing-across-devices-empty-state2 =
    .description = Вы ничего не синхронизируете... пока. Запустите синхронизацию, чтобы получить все ваши данные на всех ваших устройствах.
    .label = Управление синхронизированными данными
sync-syncing-across-devices-empty-state3 =
    .description = Вы ничего не синхронизируете… пока. Выберите, что синхронизировать на этом устройстве.
    .label = Управление синхронизированными данными
sync-currently-syncing-bookmarks = Закладки
sync-currently-syncing-history = Историю
sync-currently-syncing-tabs = Открытые вкладки
sync-currently-syncing-passwords = Пароли
sync-currently-syncing-addresses = Адреса
sync-currently-syncing-payment-methods = Способы оплаты
sync-currently-syncing-addons = Дополнения
sync-currently-syncing-settings = Настройки
sync-manage-options =
    .label = Управление синхронизацией…
    .accesskey = Ь
sync-manage-options-2 =
    .label = Управление синхронизированными данными
    .accesskey = Ь
settings-sync-disconnect-button =
    .label = Отсоединиться

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Закладки
    .accesskey = к
sync-engine-history =
    .label = Историю
    .accesskey = т
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Открытые вкладки
    .tooltiptext = Открывайте вкладки с других ваших устройств
    .accesskey = е
sync-engine-tabs =
    .label = Открытые вкладки
    .tooltiptext = Список того, что открыто на всех синхронизированных устройствах
    .accesskey = л
sync-engine-passwords =
    .label = Пароли
    .tooltiptext = Сохранённые пароли
    .accesskey = з
sync-engine-addresses2 =
    .label = Адреса
    .tooltiptext = Адреса, которые вы сохранили в { -brand-short-name }
    .accesskey = у
sync-engine-payment-methods3 =
    .label = Способы оплаты
    .tooltiptext = Способы оплаты, которые вы сохранили
    .accesskey = т
sync-engine-addons2 =
    .label = Дополнения
    .tooltiptext = Расширения и темы, которые вы добавили в { -brand-short-name } для компьютера
    .accesskey = Ф
sync-engine-settings2 =
    .label = Настройки
    .tooltiptext = Настройки { -brand-short-name }, где применимо
    .accesskey = ы
sync-engine-addresses =
    .label = Адреса
    .tooltiptext = Сохранённые вами почтовые адреса (только для компьютера)
    .accesskey = с
sync-engine-payment-methods2 =
    .label = Способы оплаты
    .tooltiptext = Имена, номера карт и даты истечения срока действия
    .accesskey = т
sync-engine-addons =
    .label = Дополнения
    .tooltiptext = Расширения и темы для Firefox на компьютере
    .accesskey = п
sync-engine-settings =
    .label = Настройки
    .tooltiptext = Изменённые вами общие настройки, настройки приватности и безопасности
    .accesskey = а
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Сохранить
    .buttonlabelextra2 = Отключить…
    .buttonaccesskeyaccept = Ы
    .buttonaccesskeyextra2 = В
    .style = min-width: 36em;
    .title = Управляйте синхронизируемыми данными на всех подключённых устройствах
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Сохранить
    .buttonlabelextra2 = Отсоединить…
    .buttonaccesskeyaccept = Ы
    .buttonaccesskeyextra2 = В
    .style = min-width: 36em;
    .title = Управляйте тем, что синхронизируется на этом устройстве

## The device name controls.

sync-device-name-header = Имя устройства
sync-device-name-header-2 =
    .label = Имя устройства
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Имя устройства
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Изменить имя устройства
    .accesskey = м
sync-device-name-change =
    .label = Изменить имя устройства…
    .accesskey = м
sync-device-name-cancel =
    .label = Отмена
    .accesskey = е
sync-device-name-save =
    .label = Сохранить
    .accesskey = х
sync-connect-another-device = Подключить другое устройство
sync-connect-another-device-2 =
    .label = Подключить другое устройство

## Privacy Section

privacy-header = Приватность браузера

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Пароли
    .searchkeywords = логины
forms-passwords-header =
    .aria-label = Пароли
    .label = Пароли
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Запрашивать сохранение паролей
    .accesskey = ф
forms-manage-password-exceptions =
    .label = Управление исключениями для паролей
    .accesskey = Ь
forms-exceptions =
    .label = Исключения…
    .accesskey = ю
forms-suggest-passwords =
    .label = Предлагать надёжные пароли
    .accesskey = ы
forms-breach-alerts =
    .label = Показывать уведомления о паролях для взломанных сайтов
    .accesskey = ы
forms-breach-alerts-learn-more-link = Подробнее
preferences-relay-integration-checkbox2 =
    .label = Предлагать псевдонимы электронной почты { -relay-brand-name } для защиты вашего адреса электронной почты
    .accesskey = к
relay-integration-learn-more-link = Подробнее
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Автоматически заполнять имена пользователей и пароли
    .accesskey = а
forms-fill-usernames-and-passwords-2 =
    .label = Сохранять и автоматически заполнять имена пользователей и пароли
    .accesskey = а
forms-saved-passwords =
    .label = Сохранённые пароли
    .accesskey = в
forms-saved-passwords-2 =
    .label = Управление сохранёнными паролями
    .accesskey = в
forms-saved-passwords-searchkeywords = На вашем компьютере хранятся логины для следующих сайтов
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Дополнительная защита
forms-primary-pw-use =
    .label = Использовать основной пароль
    .accesskey = с
forms-primary-pw-use-2 =
    .description = Добавляет дополнительный уровень безопасности для защиты ваших сохранённых паролей.
    .label = Использовать основной пароль
    .accesskey = Г
forms-primary-pw-set =
    .label = Установить основной пароль
forms-primary-pw-on-2 = Основной пароль <strong>ВКЛЮЧЁН</strong>
forms-primary-pw-on =
    .label = Основной пароль ВКЛЮЧЁН
forms-primary-pw-change-2 =
    .label = Изменить основной пароль
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Отключить
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Требовать вход на устройстве для заполнения и управления паролями
forms-os-reauth-2 =
    .label = Требовать вход на устройстве для управления паролями
forms-primary-pw-learn-more-link = Подробнее
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Изменить мастер-пароль…
    .accesskey = з
forms-primary-pw-change =
    .label = Изменить основной пароль…
    .accesskey = з
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = Ранее — мастер-пароль
forms-primary-pw-fips-title = Сейчас вы находитесь в режиме FIPS. Для работы в этом режиме необходимо установить основной пароль.
forms-master-pw-fips-desc = Смена пароля не удалась
forms-windows-sso =
    .label = Разрешить единый вход Windows для учётных записей Microsoft, учётных записей на работе и в учебных заведениях
forms-windows-sso-learn-more-link = Подробнее
forms-windows-sso-desc = Управление аккаунтами в настройках вашего устройства
windows-passkey-settings-label = Управление ключами доступа в системных настройках
privacy-panel-settings-header =
    .description = Получите помощь по защите вашей информации онлайн в { -brand-short-name }.
    .label = Настройки панели приватности
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Показать сообщения об утечках
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Чтобы создать основной пароль, введите ваши учётные данные для входа в Windows. Это поможет защитить безопасность ваших аккаунтов.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = создать основной пароль
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] изменить настройки способов оплаты
       *[other] { -brand-short-name } пытается изменить настройки способов оплаты. Используйте вход на устройстве, чтобы разрешить это.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Способы оплаты
autofill-payment-methods-checkbox-message-2 =
    .label = Сохранять и автозаполнять платёжную информацию
    .accesskey = з
autofill-payment-methods-manage-payments-title =
    .heading = Управление способами оплаты
autofill-payment-methods-manage-payments-button =
    .label = Управление способами оплаты
    .accesskey = ь
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Требовать вход на устройстве для автозаполнения
    .accesskey = щ
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Требовать входа с устройства для автозаполнения и управления способами платежей
    .accesskey = щ
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Сохраните коды безопасности
    .accesskey = с
autofill-payment-methods-add-button = Добавить новый способ оплаты
payments-list-header =
    .label = Способы оплаты
payments-delete-payment-prompt-title = Удалить этот способ оплаты?
payments-delete-payment-prompt-confirm-button = Удалить
payments-delete-payment-prompt-cancel-button = Отмена
payments-delete-payment-button-label =
    .aria-label = Удалить
payments-edit-payment-button-label =
    .aria-label = Изменить
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Способы оплаты не добавлены
autofill-addresses-checkbox-message =
    .label = Сохранять и автоматически заполнять адреса
    .accesskey = Ы
autofill-addresses-manage-addresses-button =
    .label = Управление адресами и другим
    .accesskey = Ь
addresses-list-header =
    .label = Адреса
addreses-delete-address-button-label =
    .aria-label = Удалить
addreses-edit-address-button-label =
    .aria-label = Изменить
addresses-delete-address-prompt-title = Удалить этот адрес?
addresses-delete-address-prompt-confirm-button = Удалить
addresses-delete-address-prompt-cancel-button = Отмена
autofill-addresses-add-button = Добавить новый адрес
autofill-addresses-manage-addresses-title =
    .heading = Управление адресами и другим
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Адреса не добавлены
personal-info-group =
    .label = Персданные
autofill-personal-info-checkbox-message =
    .label = Сохранять и автоматически заполнять персданные
autofill-personal-info-manage-button =
    .label = Управление персданными
passports-list-header =
    .label = Паспорта
passports-delete-passport-button-label =
    .aria-label = Удалить
passports-edit-passport-button-label =
    .aria-label = Изменить
passports-delete-passport-prompt-title = Удалить этот паспорт?
passports-delete-passport-prompt-confirm-button = Удалить
passports-delete-passport-prompt-cancel-button = Отмена
autofill-passports-add-button = Добавить новый паспорт
autofill-personal-info-manage-title =
    .heading = Управление персданными
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Не добавлено ни одного паспорта
pane-passwords-autofill-title2 = Пароли и автозаполнение
    .title = Пароли и автозаполнение
preferences-passwords-autofill-header =
    .heading = Пароли и автозаполнение
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } сохранён
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } сохранён
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Адреса и другое
payments-group =
    .label = Способы оплаты

## Privacy Section - History

history-remember-option-never2 =
    .description = Каждое окно работает как приватное окно. Если включено, расширения должны быть разрешены.
    .label = Никогда не запоминать историю
history-remember-option-custom2 =
    .label = Настройка истории
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } будет помнить историю посещений, загрузок, поиска и сохранять данные форм.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } будет использовать те же настройки, что и в приватном режиме, и не будет помнить историю вашей работы с сайтами.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } будет использовать собственные настройки для истории посещений, загрузок, форм и поиска.
history-private-browsing-permanent =
    .label = Всегда работать в приватном режиме
    .accesskey = и
history-remember-browser-option =
    .label = Помнить историю посещений и загрузок
    .accesskey = и
history-remember-search-option =
    .label = Помнить историю поиска и данных форм
    .accesskey = и
history-clear-on-close-option =
    .label = Удалять историю при закрытии { -brand-short-name }
    .accesskey = я
history-clear-on-close-settings =
    .label = Параметры…
    .accesskey = ы
history-shutdown-exceptions =
    .label = Управление исключениями
    .accesskey = x
history-clear-button =
    .label = Удалить историю…
    .accesskey = л
history-header2 =
    .heading = История
history-section-header =
    .description = Выберите, что { -brand-short-name } должен запоминать, когда вы закрываете браузер.
    .label = История
history-custom-section-header =
    .description = Настройте, что вы хотите, чтобы запоминал { -brand-short-name } при закрытии браузера.
    .label = Дополнительные настройки
history-custom-button =
    .label = Выберите, что { -brand-short-name } должен запоминать
history-group =
    .label = История
history-mode-radio-group =
    .aria-label = История
history-remember-option-all2 =
    .label = Запоминать историю

## Privacy Section - Site Data

sitedata-total-size-calculating = Вычисление объёма данных сайтов и кеша…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Веб-сайты сейчас занимают <strong>{ $value } { $unit }</strong> на диске.
sitedata-learn-more = Подробнее
sitedata-delete-on-close2 =
    .label = Удалять куки и данные сайтов при каждом закрытии { -brand-short-name }
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = Основываясь на ваших настройках истории, { -brand-short-name } удаляет куки и данные сайтов из вашей сессии, когда вы закрываете браузер.
sitedata-delete-on-close-private-browsing4 =
    .heading = История не будет сохраняться.
    .message = { -brand-short-name } удаляет куки и данные сайтов из вашего сеанса, когда вы закрываете браузер.
sitedata-option-block-cross-site-trackers =
    .label = Межсайтовые трекеры
sitedata-option-block-cross-site-tracking-cookies =
    .label = Межсайтовые отслеживающие куки
sitedata-option-block-cross-site-cookies2 =
    .label = Изолировать межсайтовые куки
sitedata-option-block-unvisited =
    .label = Куки с непосещённых сайтов
sitedata-option-block-all-cross-site-cookies =
    .label = Все межсайтовые куки (может нарушить работу сайтов)
sitedata-option-block-all =
    .label = Все куки (нарушит работу веб-сайтов)
sitedata-clear2 =
    .label = Удалить данные веб-сёрфинга
    .accesskey = Ш
sitedata-settings2 =
    .label = Управление данными веб-сёрфинга
    .accesskey = Ь
sitedata-cookies-exceptions =
    .label = Управление исключениями…
    .accesskey = ю
sitedata-cookies-exceptions2 =
    .description = Вы можете указать, каким веб-сайтам всегда разрешено или никогда не разрешено использовать куки и данные сайта.
    .label = Управление исключениями
    .accesskey = Ч
sitedata-heading =
    .description = Управляйте своими куками, историей, кэшем, данными веб-сайтов и пр.
    .label = Данные просмотра
sitedata-settings3 =
    .label = Удалять данные для выбранных сайтов
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Выберите, как отдельные сайты обрабатывают куки и данные сайтов.
    .label = Управление исключениями
    .accesskey = x
cookies-site-data-group =
    .label = Куки и данные сайтов

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Блокировщик уведомления о куки
cookie-banner-blocker-description = Когда сайт спрашивает, могут ли они использовать куки в режиме приватного просмотра, { -brand-short-name } автоматически отказывается от этого для вас. Только на поддерживаемых сайтах.
cookie-banner-learn-more = Подробнее
cookie-banner-blocker-checkbox-label =
    .label = Автоматически отказываться от уведомлениях о куки

## Search Section

addressbar-locbar-history-option =
    .label = из журнала посещений
    .accesskey = ж
addressbar-locbar-bookmarks-option =
    .label = из закладок
    .accesskey = д
addressbar-locbar-clipboard-option =
    .label = из буфера обмена
    .accesskey = м
addressbar-locbar-openpage-option =
    .label = из открытых вкладок
    .accesskey = к
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = из ярлыков
    .accesskey = з
addressbar-locbar-topsites-option =
    .label = из топа сайтов
    .accesskey = й
addressbar-locbar-engines-option-1 =
    .label = Предлагать использование поисковых систем
    .accesskey = ф
addressbar-locbar-quickactions-option =
    .label = Быстрые действия
    .accesskey = ы
addressbar-locbar-showrecentsearches-option-2 =
    .label = Недавние запросы
    .accesskey = к
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Популярные поисковые предложения
    .accesskey = е
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Получать предложения из сети на основе вашего поиска.
    .label = Предложения от { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Поддержите { -brand-short-name } периодическими предложениями от спонсоров.
    .label = Предложения от спонсоров
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Получать предложения от Mozilla по мере набора
addressbar-dismissed-suggestions-label-2 =
    .description = Восстановить отклонённые предложения от спонсоров и { -brand-short-name }.
    .label = Скрытые предложения
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Восстановить предложения

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Улучшенная защита от отслеживания
content-blocking-section-top-level-description = Трекеры отслеживают вас в Интернете, чтобы собирать сведения о ваших привычках и интересах. { -brand-short-name } блокирует многие из этих трекеров и других вредоносных скриптов.
content-blocking-learn-more = Подробнее
content-blocking-fpi-incompatibility-warning = Вы используете First Party Isolation (FPI), которая переопределяет некоторые настройки кук { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Вы используете функцию защиты от сборщиков цифровых отпечатков (RFP), которая заменяет некоторые настройки защиты от сборщиков цифровых отпечатков { -brand-short-name }. Это может привести к неработоспособности некоторых сайтов.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Стандартная
    .accesskey = н
enhanced-tracking-protection-setting-strict =
    .label = Строгая
    .accesskey = о
enhanced-tracking-protection-setting-custom =
    .label = Персональная
    .accesskey = а

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Золотая середина: защита и производительность. Страницы будут загружаться нормально.
content-blocking-etp-strict-desc = Усиленная защита может вызывать проблемы с некоторыми сайтами и их содержимым.
content-blocking-etp-custom-desc = Выберите, какие трекеры и скрипты необходимо блокировать.
content-blocking-etp-blocking-desc = { -brand-short-name } блокирует следующее:
content-blocking-private-windows = Отслеживающее содержимое в приватных окнах
content-blocking-cross-site-cookies-in-all-windows2 = Межсайтовые куки во всех окнах
content-blocking-cross-site-tracking-cookies = Межсайтовые отслеживающие куки
content-blocking-all-cross-site-cookies-private-windows = Межсайтовые куки в приватных окнах
content-blocking-isolate-cross-site-cookies = Изолировать межсайтовые куки
content-blocking-social-media-trackers = Трекеры соцсетей
content-blocking-all-cookies = Все куки
content-blocking-unvisited-cookies = Куки с непосещённых сайтов
content-blocking-all-windows-tracking-content = Отслеживающее содержимое во всех окнах
content-blocking-all-cross-site-cookies = Все межсайтовые куки
content-blocking-cryptominers = Криптомайнеры
content-blocking-fingerprinters = Сборщики цифровых отпечатков
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Известные и предполагаемые сборщики цифровых отпечатков
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Полная защита от кук ограничивает работу кук сайтом, на котором вы находитесь, чтобы трекеры не могли использовать их для слежки за вами от сайта к сайту.
content-blocking-etp-standard-tcp-rollout-learn-more = Подробнее
content-blocking-etp-standard-tcp-title = Включает полную защиту от кук, нашу самую мощную функцию защиты приватности.
content-blocking-warning-title-2 = Некоторые сайты могут не работать со строгой защитой от отслеживания
content-blocking-warning-title-custom = Некоторые сайты могут не работать с персональной защитой от отслеживания
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } рекомендует использовать настройки «Устранение проблем с сайтом», чтобы уменьшить количество неработоспособных сайтов и содержимого. Если сайт кажется неработающим, попробуйте отключить защиту от отслеживания на этом сайте, чтобы загрузить всё содержимое.
content-blocking-warning-learn-how = Подробнее
content-blocking-baseline-exceptions-3 =
    .description = Помогает загружать сайты и функции, разблокируя только необходимые элементы, которые могут содержать трекеры. Покрывает наиболее распространённые проблемы.
    .label = Устранение основных проблем с сайтами (рекомендуется)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Восстанавливает такие вещи, как видео в статье или комментарии, разблокируя элементы, которые могут содержать трекеры. Это может уменьшить проблемы с сайтом, но даст более слабую защиту. Должен использоваться с исправлениями для основных проблем.
    .label = Устранение незначительных проблем с сайтами
content-blocking-baseline-uncheck-warning-dialog-title = Вы уверены, что хотите отключить исправления?
content-blocking-baseline-uncheck-warning-dialog-body = Эта настройка помогает устранить наиболее распространённые проблемы с сайтами. Если вы отключите её, некоторые сайты могут не работать, и { -brand-short-name } не сможет помочь устранить эти проблемы.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Отключить исправления
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Оставить исправления включёнными
content-blocking-reload-description = Вам понадобится обновить свои вкладки, чтобы применить эти изменения.
content-blocking-reload-tabs-button =
    .label = Обновить все вкладки
    .accesskey = н
content-blocking-tracking-content-label =
    .label = Отслеживающее содержимое
    .accesskey = ж
content-blocking-tracking-protection-option-all-windows =
    .label = Во всех окнах
    .accesskey = е
content-blocking-option-private =
    .label = Только в приватных окнах
    .accesskey = и
content-blocking-cookies-label =
    .label = Куки
    .accesskey = и
content-blocking-expand-section =
    .tooltiptext = Дополнительные сведения
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Криптомайнеры
    .accesskey = п
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Известные цифровые отпечатки
    .accesskey = в
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Подозреваемые цифровые отпечатки
    .accesskey = о

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Управление исключениями…
    .accesskey = е

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Отключить уведомления до перезапуска { -brand-short-name }
    .accesskey = ю
permissions-autoplay2 =
    .label = Автовоспроизведение
permissions-block-popups2 =
    .label = Блокировать всплывающие окна и сторонние перенаправления
    .accesskey = И
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Добавьте веб-сайты, которые могут открывать всплывающие окна и использовать сторонние переадресации.
    .label = Управление исключениями
    .searchkeywords = всплывающие окна
    .accesskey = У
permissions-addon-install-warning3 =
    .label = Показывать предупреждение при попытке веб-сайтов установить расширения
    .accesskey = Ц
permissions-addon-exceptions2 =
    .label = Выбрать, какие веб-сайты могут устанавливать расширения
    .accesskey = У
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Разрешать сайтам запрашивать открытие ссылок на приложения.
    .accesskey = Ф
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Управление заблокированными сайтами
    .accesskey = Ь
permissions-location2 =
    .label = Местоположение
permissions-localhost2 =
    .label = Приложения и службы устройства
permissions-local-network2 =
    .label = Устройства локальной сети
permissions-xr2 =
    .label = Виртуальная реальность
permissions-camera2 =
    .label = Камера
permissions-microphone2 =
    .label = Микрофон
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Динамик
permissions-notification2 =
    .label = Уведомления
permissions-header3 =
    .description = Управляйте тем, к чему веб-сайты имеют доступ, что могут контролировать и запускать.
    .label = Разрешения
permissions-data-section =
    .heading = Разрешения и данные
pane-permissions-data-title2 = Разрешения и данные
    .title = Разрешения и данные
notifications-section-header =
    .heading = Уведомления
notifications-entry-card-header =
    .description = Выберите, какие веб-сайты могут отправлять уведомления и как эти уведомления будут отображаться.
    .label = Уведомления
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } веб-сайт
            [few] { $count } веб-сайта
           *[many] { $count } веб-сайтов
        }
    .label = Управление настройками уведомлений
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Управление настройками уведомлений веб-сайтов
notifications-website-card-header =
    .description = Выберите, как веб-сайты могут отправлять уведомления.
    .label = Уведомления веб-сайтов
notifications-filter =
    .placeholder = Поиск веб-сайтов
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Веб-сайт
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Разрешить уведомления
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Веб-сайты
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Всегда
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Разрешить
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Никогда
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Уведомления от веб-сайтов не добавлены.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Сайтов с уведомлениями, соответствующих вашему запросу, не найдено.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Чтобы убедиться, что это изменение включено в ваши резервные копии, откройте каждый профиль и выберите «Создать резервную копию» в настройках.
nimbus-rollouts =
    .description = Изменения будут внедряться удалённо.
    .label = Разрешить { -brand-short-name } улучшать функциональность, производительность и стабильность между обновлениями
addon-recommendations3 =
    .description = Получать рекомендации расширений, чтобы улучшить свою работу в Интернете.
    .label = Разрешить персонализированные рекомендации расширений
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Для этой конфигурации сборки отправка данных отключена.
collection-backlogged-crash-reports2 =
    .label = Автоматически отправлять сообщения о падениях
    .accesskey = с
collection-backlogged-crash-reports-description = Это помогает { -vendor-short-name } диагностировать и устранять проблемы с браузером. Отчёты могут содержать личные или важные данные.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Те же настройки, новый вид!
    .message = Мы перестроили эту страницу, чтобы её было проще сканировать и изучать. Ваши личные настройки не изменились, и всё по-прежнему здесь. Совет: используйте поиск, чтобы сразу перейти к тому, что вам нужно.
settings-redesign-promo-dismiss-button =
    .label = Понятно
privacy-segmentation-section-header = Новые возможности, улучшающие ваш просмотр сети
privacy-segmentation-section-description = Когда мы предлагаем возможности, которые используют ваши данные, чтобы улучшить персонализацию браузера:
privacy-segmentation-radio-off =
    .label = Использовать советы { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Показать подробные сведения
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Мы стремимся предоставить вам возможность выбора и собираем только минимальные данные, необходимые для улучшения { -brand-product-name } для всех и каждого.
    .label = Сбор и использование данных { -brand-short-name }
    .searchkeywords = телеметрия
data-collection-link = Просмотреть Уведомление о конфиденциальности
data-collection-preferences-across-profiles =
    .message = Эти настройки применяются ко всем профилям { -brand-product-name } на этом устройстве.
data-collection-profiles-link = Просмотреть все профили
data-collection-health-report-telemetry-disabled =
    .message = Вы больше не разрешаете { -vendor-short-name } собирать технические данные и данные взаимодействия. Все собранные ранее данные будут удалены в течение 30 дней.
data-collection-health-report =
    .description = Это поможет нам улучшить возможности, производительность и стабильность { -brand-product-name }.
    .label = Отправлять технические данные и данные взаимодействия в { -vendor-short-name }
    .accesskey = к
data-collection-health-report-disabled =
    .description = Для этой конфигурации сборки отчёты о данных отключены.
    .label = Отправлять технические данные и данные взаимодействия в { -vendor-short-name }
    .accesskey = к
data-collection-run-studies =
    .description = { -brand-short-name } случайным образом выбирает пользователей для тестирования функций, что помогает повысить качество работы для всех.
    .label = Разрешить { -brand-short-name } проводить исследования функций
data-collection-studies-link =
    .label = Просмотреть исследования { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = Это помогает { -vendor-short-name } диагностировать и исправлять проблемы в браузере. Отчёты могут содержать персональные или конфиденциальные данные.
    .label = Автоматически отправлять сообщения о падениях
    .accesskey = c
data-collection-usage-ping =
    .description = Это помогает { -vendor-short-name } оценить активных пользователей.
    .label = Отправлять ежедневный пинг использования в { -vendor-short-name }
    .accesskey = г

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Защита
browsing-protection-group2 =
    .description = Опасные сайты и загрузки могут подвергнуть риску ваши данные и устройство. { -brand-short-name } автоматически блокирует их и предупреждает вас о рискованном или нежелательном программном обеспечении.
    .label = Защита от поддельного содержимого и вредоносных программ
security-enable-safe-browsing =
    .label = Блокировать опасное и обманывающее содержимое
    .accesskey = л
security-enable-safe-browsing-link = Подробнее
security-safe-browsing-warning =
    .message = Отключение этой функции ослабляет защиту от мошенничества, вредоносных сайтов и вредоносных загрузок.
security-block-downloads =
    .label = Блокировать опасные загрузки
    .accesskey = к
security-block-uncommon-software =
    .label = Предупреждать о нежелательных и редко загружаемых приложениях
    .accesskey = ж

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Разрешить { -brand-short-name } автоматически доверять установленным вами сторонним корневым сертификатам.
    .accesskey = е
certs-devices-enable-fips = Использовать FIPS
space-alert-over-5gb-settings-button =
    .label = Открыть настройки
    .accesskey = к
space-alert-over-5gb-message2 = <strong>У { -brand-short-name } заканчивается место на диске.</strong> Содержимое сайтов может отображаться неправильно. Вы можете удалить сохранённые данные через «Настройки» > «Приватность и защита» > «Куки и данные сайтов».
space-alert-under-5gb-message2 = <strong>У { -brand-short-name } заканчивается место на диске.</strong> Содержимое сайтов может отображаться неправильно. Щёлкните «Подробнее», чтобы уменьшить использование вашего диска для улучшения работы в Интернете.
certs-description3 =
    .description = Настройте сертификаты, которые { -brand-short-name } использует для проверки защищённых подключений.
    .label = Сертификаты
certs-view2 =
    .label = Управление сертификатами
    .accesskey = С
certs-devices2 =
    .label = Управление устройствами защиты
    .accesskey = В

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Как работает «Только HTTPS»
httpsonly-radio-enabled =
    .label = Включить режим «Только HTTPS» во всех окнах
httpsonly-radio-enabled-pbm =
    .label = Включить режим «Только HTTPS» только в приватных окнах
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } сможет всё ещё переключать некоторые соединения
    .label = Не включать режим «Только HTTPS»
httpsonly-group =
    .description = Разрешает только защищённые соединения с веб-сайтами. { -brand-short-name } будет спрашивать перед незащищённым соединением.
    .label = Режим «Только HTTPS»
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS через HTTPS
dns-over-https-group2 =
    .description = Система доменных имён по протоколу HTTPS (DoH) шифрует поиск по сайту, поэтому вашему интернет-провайдеру или другим пользователям сложнее узнать, какие веб-сайты вы собираетесь посетить.
    .label = DNS через HTTPS
preferences-doh-description2 = Система доменных имён (DNS) через HTTPS отправляет ваш запрос на доменное имя через зашифрованное соединение, обеспечивая безопасный DNS и мешая другим увидеть, к какому веб-сайту вы собираетесь получить доступ.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Состояние: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Поставщик: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Некорректный URL
preferences-doh-steering-status = Использование местного поставщика
preferences-doh-status-active = Активно
preferences-doh-status-disabled = Отключено
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Неактивно ({ $reason })
preferences-doh-group-message2 = Включить DNS через HTTPS, используя:
preferences-doh-radio-group =
    .aria-label = Включить DNS через HTTPS, используя:
preferences-doh-expand-section =
    .tooltiptext = Подробная информация
preferences-doh-setting-default =
    .label = Защиту по умолчанию
    .accesskey = м
preferences-doh-default-desc = { -brand-short-name } решает, когда использовать безопасный DNS для защиты вашей конфиденциальности.
preferences-doh-default-detailed-desc-1 = Использовать безопасный DNS в регионах, где он доступен
preferences-doh-default-detailed-desc-2 = Использовать разрешение DNS по умолчанию, если имеется проблема с поставщиком безопасного DNS.
preferences-doh-default-detailed-desc-3 = Использовать местного поставщика, если это возможно
preferences-doh-default-detailed-desc-4 = Отключить, когда активны VPN, родительский контроль или корпоративные политики.
preferences-doh-default-detailed-desc-5 = Отключить, когда сеть сообщает { -brand-short-name }, что она не должна использовать безопасный DNS.
preferences-doh-setting-enabled =
    .label = Повышенную защиту
    .accesskey = ы
preferences-doh-enabled-desc = Вы сами решаете, когда использовать безопасный DNS, и выбираете своего поставщика.
preferences-doh-enabled-detailed-desc-1 = Использовать выбранного вами поставщика
preferences-doh-enabled-detailed-desc-2 = Использовать разрешение DNS по умолчанию только в том случае, если есть проблема с безопасным DNS
preferences-doh-setting-strict =
    .label = Максимальную защиту
    .accesskey = к
preferences-doh-strict-desc = { -brand-short-name } всегда будет использовать безопасный DNS. Вы увидите предупреждение об угрозе безопасности, прежде чем мы будем использовать DNS вашей системы.
preferences-doh-strict-detailed-desc-1 = Использовать только выбранного вами поставщика
preferences-doh-strict-detailed-desc-2 = Всегда предупреждать, если безопасный DNS недоступен
preferences-doh-strict-detailed-desc-3 = Если безопасный DNS недоступен, сайты не будут загружаться или работать должным образом.
preferences-doh-setting-off =
    .label = Отключить
    .accesskey = ю
preferences-doh-off-desc = Использовать разрешение DNS по умолчанию
preferences-doh-select-resolver = Выбрать поставщика:
preferences-doh-manage-exceptions =
    .label = Управление исключениями…
    .accesskey = ю
preferences-doh-overview-default =
    .description = Используйте защищённый DNS в регионах, где он доступен.
    .label = Защита по умолчанию
preferences-doh-overview-custom =
    .description = Всегда используйте безопасный DNS с контролем над вашим провайдером и с резервным поведением.
    .label = Персональная
preferences-doh-overview-off =
    .description = Используйте свой DNS-резолвер по умолчанию
    .label = Отключено
preferences-doh-advanced-button =
    .label = Дополнительные настройки
preferences-doh-advanced-section =
    .description = Система доменных имён по протоколу HTTPS (DoH) шифрует поиск сайтов, поэтому вашему интернет-провайдеру или другим пользователям сложнее узнать, какие веб-сайты вы собираетесь посетить.
    .label = Дополнительные настройки
preferences-doh-manage-exceptions2 =
    .label = Управление исключениями
    .accesskey = x
preferences-doh-radio-default =
    .description = Использовать защищённый DNS в регионах, где он доступен
    .label = По умолчанию
preferences-doh-radio-custom =
    .description = Всегда использовать защищённый DNS с контролем над вашим провайдером и резервным поведением
    .label = Персональный
preferences-doh-radio-off =
    .description = Использовать ваш DNS-резолвер по умолчанию
    .label = Отключён
preferences-doh-fallback-label =
    .label = Всегда предупреждать, если безопасный DNS недоступен
preferences-doh-status-item-off =
    .message = DNS через HTTPS отключён
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS через HTTPS не работает, так как мы столкнулись с ошибкой ({ $reason }) при попытке использовать провайдера { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS через HTTPS не работает, потому что мы получили некорректный URL ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS через HTTPS использует провайдера { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS через HTTPS не работает, так как мы столкнулись с ошибкой ({ $reason }) при попытке использовать местного провайдера { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS через HTTPS использует местного провайдера { $name }
preferences-doh-select-resolver-label =
    .label = Выбрать провайдера:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Использовать этого провайдера для резолвинга DNS через HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Введите URL своего провайдера
preferences-doh-header2 =
    .heading = DNS через HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Безопасность подключения и ПО
preferences-connection-link-section =
    .description = Посмотрите, как обеспечивается безопасность подключений, блокируется вредоносное программное обеспечение и проверяются веб-сайты.
    .label = Безопасность подключения и ПО
preferences-connection-link-button =
    .label = Дополнительные настройки

## The following strings are used in the Download section of settings

desktop-folder-name = Рабочий стол
downloads-folder-name = Загрузки

## Appearance page

preferences-appearance-header =
    .heading = Внешний вид
browser-theme-group =
    .description = Настраивайте { -brand-short-name } на свой вкус. Цвета тем применяются к панелям, меню и сообщениям.
    .label = Тема браузера
browser-theme-manage-link =
    .label = Управление темами { -brand-short-name }
appearance-window-density-group =
    .description = Настройте расстояние между элементами окна, такими как панель инструментов, вкладки и боковая панель.
    .label = Плотность окна
appearance-window-density-radio-group =
    .aria-label = Плотность окна
appearance-window-density-automatic =
    .description = Стандартный, компактный или сенсорный интервал устанавливается автоматически
    .label = Автоматически (по умолчанию)
appearance-window-density-automatic-no-touch =
    .description = Стандартное или компактное расстояние устанавливается автоматически
    .label = Автоматически (по умолчанию)
appearance-window-density-standard =
    .description = Сбалансированный интервал для большинства экранов
    .label = Стандартная
appearance-window-density-auto-touch-mode =
    .label = Использовать сенсорный интервал для планшетного режима
appearance-window-density-compact =
    .description = Снижает интервал для небольших экранов
    .label = Компактная
appearance-window-density-touch =
    .description = Увеличенные элементы окна и цели для нажатий, оптимизированные для сенсорных экранов
    .label = Сенсорная
related-settings-group =
    .label = Связанные настройки
related-settings-accessibility-link =
    .label = Настройте масштаб и шрифт в Доступности
related-settings-home-link =
    .label = Настройка { -firefox-home-brand-name(case: "genitive") }
related-settings-tabs-browsing-link =
    .label = Настроить макет браузера

## AI controls page

preferences-ai-controls-description = В { -brand-short-name } у вас всегда есть выбор, в том числе использовать ли функции, улучшенные с помощью ИИ. Скоро будет ещё больше элементов управления.
preferences-ai-controls-block-ai-label = Блокировать ИИ-улучшения
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Блокировка означает, что вы не увидите новые или текущие ИИ-улучшения в { -brand-short-name }, а также всплывающие окна о них. <a data-l10n-name="link">Узнайте больше</a> о том, что включено и как управлять типичными функциями машинного обучения, такими как поисковые предложения и рекомендации.
preferences-ai-controls-blocked-message =
    .message = Новые и текущие ИИ-улучшения заблокированы по умолчанию. Чтобы разблокировать какую-либо функцию, используйте расположенные ниже элементы управления.
preferences-ai-controls-on-device-group =
    .description = Они используют небольшие модели ИИ, которые загружаются на ваше устройство, если вы используете эту функцию. Такой подход помогает защитить вашу конфиденциальность.
    .label = ИИ на устройстве
preferences-ai-controls-translations-control =
    .description = Просматривайте бесшовно веб-страницы на выбранном вами языке.
    .label = Переводы
preferences-ai-controls-translations-more-link = Другие настройки переводов
preferences-ai-controls-pdfjs-control =
    .description = Когда вы добавляете изображения в PDF, к ним добавляются описания, чтобы улучшить их доступность.
    .label = Альтернативный текст изображения в средстве просмотра PDF { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Получите предложения по названию и упорядочению ваших вкладок.
    .label = Предложения для групп вкладок
preferences-ai-controls-key-points-control =
    .description = Ознакомьтесь с краткой информацией, прежде чем открывать ссылку.
    .label = Ключевые моменты в предпросмотре ссылок
preferences-ai-controls-speech-recognition-control =
    .description = Транскрибируйте речь локально.
    .label = Распознавание речи
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Держите чат-бот на виду при веб-сёрфинге. Выбирайте из множества провайдеров и переключайтесь в любое время.
    .label = Провайдеры ИИ-чатбота на боковой панели
preferences-ai-controls-sidebar-chatbot-group =
    .description = Держите в поле зрения чат-бот во время просмотра. Выбирайте между Anthropic Claude, ChatGPT, Copilot, Google Gemini и Le Chat Mistral.
    .label = ИИ-провайдеры на боковой панели
preferences-ai-controls-sidebar-chatbot-control =
    .label = Чат-бот на боковой панели
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Доступно
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Включено
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Заблокировано
preferences-ai-controls-state-description-before = Что означают параметры:
preferences-ai-controls-state-description-available = <strong>Доступно:</strong> Вы увидите эту функцию и сможете её использовать.
preferences-ai-controls-state-description-enabled = <strong>Включено:</strong> Вы согласились использовать эту функцию.
preferences-ai-controls-state-description-blocked = <strong>Заблокировано:</strong> Вы не увидите и не сможете использовать эту функцию. Для ИИ на устройстве любые уже загруженные модели удаляются.
preferences-ai-controls-block-confirmation-heading = Блокировать ИИ-улучшения?
preferences-ai-controls-block-confirmation-description = Вы не увидите новых или текущих улучшений ИИ в { -brand-short-name } или всплывающих окон о них. После этого вы можете разблокировать всё, что захотите продолжить использовать.
preferences-ai-controls-block-confirmation-features-start = Что будет заблокировано:
preferences-ai-controls-block-confirmation-translations = Переводы
preferences-ai-controls-block-confirmation-pdfjs = Альтернативный текст изображения в средстве просмотра PDF { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Предложения для групп вкладок
preferences-ai-controls-block-confirmation-key-points = Ключевые моменты в предпросмотре ссылок
preferences-ai-controls-block-confirmation-sidebar-chatbot = Провайдеры чат-ботов на боковой панели
preferences-ai-controls-block-confirmation-speech-recognition = Распознавание речи
preferences-ai-controls-block-confirmation-features-after = Блокировка также распространяется на расширения, использующие ИИ от { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Отмена
preferences-ai-controls-block-confirmation-confirm =
    .label = Блокировать
preferences-ai-controls-header3 =
    .heading = Управление ИИ

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } на страже
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } рекомендует некоторые улучшения безопасности
security-privacy-status-ok-label = Улучшенная защита от отслеживания включена
security-privacy-status-problem-label = Мы обнаружили настройки, влияющие на вашу защиту
security-privacy-status-problem-helper-label = Просмотреть проблемы
security-privacy-status-pending-trackers-label = Поиск числа трекеров, заблокированных { -brand-short-name } за последний месяц
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } трекер заблокирован за последний месяц
        [few] { $trackerCount } трекера заблокированы за последний месяц
       *[many] { $trackerCount } трекеров заблокировано за последний месяц
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = У вас включена <a data-l10n-name="strict-tracking-protection">строгая защита</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = У вас включена <a data-l10n-name="custom-tracking-protection">пользовательская защита</a>
security-privacy-status-up-to-date-label = У вас установлена последняя и безопасная версия { -brand-short-name }
security-privacy-status-update-needed-label = Доступна новая версия { -brand-short-name }.
security-privacy-status-update-error-label = У { -brand-short-name } возникли проблемы с обновлением
security-privacy-status-update-checking-label = { -brand-short-name } проверяет наличие обновлений
security-privacy-status-update-needed-description = Обновитесь, чтобы получить последние обновления скорости, стабильности и безопасности.
security-privacy-status-update-button-label =
    .label = Обновить { -brand-short-name }
security-privacy-image-warning =
    .alt = Щит с восклицательным знаком, выражающим обеспокоенность вашими предупреждениями безопасности
security-privacy-image-ok =
    .alt = Щит с флажком, показывающий, что у вас нет нерешённых проблем с безопасностью
security-privacy-issue-card =
    .heading = Предупреждения безопасности
issue-card-reset-button =
    .label = Сбросить
issue-card-dismiss-button =
    .aria-label = Убрать
    .tooltiptext = Убрать

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Сайты используют трекеры, чтобы следить за вами в интернете и показывать жуткую рекламу. { -brand-short-name } защищает вас во время просмотра, автоматически блокируя трекеры, чтобы вы могли контролировать свой цифровой след.
    .label = Улучшенная защита от отслеживания
preferences-etp-level-radio-group =
    .aria-label = Улучшенная защита от отслеживания
preferences-etp-level-standard =
    .description = Надежная защита, которая безотказно работает с большинством веб-сайтов.
    .label = Стандартная (по умолчанию)
preferences-etp-level-strict =
    .description = Более надёжная защита, которая блокирует большее количество трекеров, но может привести к неработоспособности некоторых сайтов.
    .label = Строгая
preferences-etp-level-custom =
    .description = Выберите, какую защиту включить, а какую отключить.
    .label = Персональная
preferences-etp-status-advanced-button =
    .label = Дополнительные настройки
preferences-etp-tracker-count-enabled =
    .label = Показывать количество заблокированных трекеров в адресной строке
preferences-etp-status-protections-dashboard-link =
    .description = Посмотрите, сколько скрытых трекеров { -brand-short-name } заблокировал для вас, включая трекеры в социальных сетях, сборщики цифровых отпечатков и криптомайнеры.
    .label = Просмотр персонализированной панели защиты
preferences-etp-header =
    .heading = Улучшенная защита от отслеживания
preferences-etp-advanced-settings-group =
    .description = Сайты используют трекеры, чтобы следить за вами в интернете и показывать жуткую рекламу. { -brand-short-name } защищает вас во время просмотра, автоматически блокируя большинство трекеров, чтобы вы могли контролировать свой цифровой след.
    .label = Дополнительные настройки
preferences-etp-customize-button =
    .label = Настроить защиту от отслеживания
preferences-etp-reload-tabs-hint =
    .message = Обновите свои вкладки, чтобы применить эти изменения.
preferences-etp-reload-tabs-hint-button =
    .label = Обновить все вкладки
preferences-etp-rfp-warning-message =
    .message = Вы используете функцию защиты от сборщиков цифровых отпечатков (RFP), которая заменяет некоторые настройки защиты от сборщиков цифровых отпечатков { -brand-short-name }. Это может привести к неработоспособности некоторых сайтов.
preferences-etp-level-warning-message =
    .heading = Внимание! Некоторые сайты могут работать не так, как ожидалось.
    .message = Некоторые сайты встраивают трекеры в свои функции или контент. Когда { -brand-short-name } блокирует их, сайт выглядит неработоспособным. Попробуйте воспользоваться функцией ”Устранить проблему с сайтом" или отключить защиту от отслеживания на этом сайте.
preferences-etp-manage-exceptions-button =
    .description = Управляйте веб-сайтами, на которых отключена Улучшенная защита от отслеживания.
    .label = Управление исключениями
preferences-etp-customize-header =
    .heading = Настроить защиту от отслеживания
preferences-etp-reset =
    .description = Восстановить настройки, чтобы установить предустановленный уровень защиты.
    .label = Сбросить настройки
preferences-etp-reset-standard-button =
    .label = Сбросить на стандартную
preferences-etp-reset-strict-button =
    .label = Сбросить на строгую
preferences-etp-custom-control-group =
    .description = Выберите, какую защиту включить или отключить.
    .label = Защита от отслеживания
preferences-etp-custom-cookies-enabled =
    .label = Куки
preferences-etp-custom-cookie-behavior =
    .aria-label = Куки
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Принимать все куки
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Блокировать межсайтовые отслеживающие куки
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Блокировать межсайтовые куки
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Изолировать межсайтовые куки
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Блокировать куки с непосещённых веб-сайтов
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Блокировать все межсайтовые куки (может нарушить работу веб-сайтов)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Блокировать все куки (нарушит работу веб-сайтов)
preferences-etp-custom-tracking-protection-enabled =
    .label = Отслеживающее содержимое
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Отслеживающее содержимое
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Криптомайнеры
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Известные цифровые отпечатки
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Подозреваемые цифровые отпечатки
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Подозреваемые цифровые отпечатки

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Это может позволить некоторым трекерам следить за вами без использования куков.
    .label = Известные сборщики цифровых отпечатков не блокируются
security-privacy-issue-warning-third-party-cookies =
    .description = Сторонние куки используются, чтобы отслеживать ваши перемещения между веб-сайтами.
    .label = Сторонние куки включены
security-privacy-issue-warning-password-manager =
    .description = Менеджеры паролей помогут вам сохранить надёжные пароли для ваших аккаунтов.
    .label = Управление паролями отключено
security-privacy-issue-warning-popup-blocker =
    .description = Всплывающие окна мешают работе и потенциально опасны.
    .label = Блокировщик всплывающих окон отключён
security-privacy-issue-warning-extension-install =
    .description = Веб-сайты могут устанавливать расширения в { -brand-short-name } без запроса.
    .label = Веб-сайты могут устанавливать расширения
security-privacy-issue-warning-safe-browsing =
    .description = Повышается ваша подверженность мошенничеству и вредоносному ПО с веб-сайтов.
    .label = Опасное и обманывающее содержимое не блокируется
security-privacy-issue-warning-doh2 =
    .description = DNS через HTTPS помогает скрыть, какие сайты вы собираетесь посетить, от вашего интернет-провайдера.
    .label = DNS через HTTPS отключён
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello помогает скрыть, как сайты вы собираетесь посетить, от вашего интернет-провайдера
    .label = Encrypted Client Hello отключён
security-privacy-issue-warning-doh =
    .description = DNS через HTTPS скрывает от вашего сетевого провайдера, какие сайты вы посещаете.
    .label = DNS через HTTPS отключён
security-privacy-issue-warning-ech =
    .description = Зашифрованное приветствие клиента (ECH) скрывает от вашего сетевого провайдера, какие сайты вы посещаете.
    .label = Зашифрованное приветствие клиента отключено
security-privacy-issue-warning-proxy-autodetection =
    .description = Автоматическая настройка прокси может позволить ненадежным сетям отслеживать вашу активность.
    .label = Автонастройка прокси включена

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Предложите кому-нибудь выбрать браузер, ставящий приватность на первое место.
    .label = Поделитесь { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Поделитесь { -brand-product-name }


vorbit-goog-safe-download-checkbox =
    .label = Проверять скачанные файла
vorbit-extension-update-description = Всегда обновлять расширения без уточнения. Хорошая практика для вашей безопасности.
pane-vorbit-title = vOrbit-lite
vorbit-header = Настройки vOrbit-lite
vorbit-warning-title = Внимание!
vorbit-general-heading = Поведение браузера
vorbit-extension-update-checkbox =
    .label = Автообновление расширений
vorbit-sync-checkbox =
    .label = Синхронизация Firefox
vorbit-autocopy-checkbox =
    .label = Вставка средней кнопкой мыши
vorbit-styling-checkbox =
    .label = Изменение интерфейса через userChrome.css
vorbit-network-heading = Сеть
vorbit-ipv6-checkbox =
    .label = Использовать IPv6
vorbit-privacy-heading = Конфиденциальность
vorbit-broken-heading = Отслеживание
vorbit-letterboxing-checkbox =
    .label = Использовать обрамление страниц (леттербоксинг)
vorbit-security-heading = Безопасность
vorbit-ocsp-checkbox =
    .label = Принудительная отмена подключения при ошибках OCSP
vorbit-goog-safe-checkbox =
    .label = Безопасный просмотр Google (Safe Browsing)
vorbit-extension-update-warning1 = Если вы не проверяете исходный код всех расширений перед обновлением, вам стоит включить эту опцию.
vorbit-ipv6-description = Разрешить { -brand-short-name } подключаться по IPv6.
vorbit-ipv6-warning1 = Вместо блокировки IPv6 в браузере стоит воспользоваться расширением конфиденциальности IPv6 в ОС.
category-vorbit =
    .tooltiptext = изменения about:config, логически сгруппированные и легкодоступные
vorbit-xorigin-ref-checkbox =
    .label = Ограничить межсайтовые referrer'ы
vorbit-ocsp-description = Не подключаться к веб-сайтам, когда выполнение проверки OCSP невозможно.
vorbit-ocsp-warning1 = Эта опция повышает безопасность но может создать неудобства при неполадках с серверами OCSP.
vorbit-sync-description = Синхронизировать данные между браузерами. Потребуется перезапуск.
vorbit-sync-warning1 = Синхронизация Firefox шифрует данные локально перед отправкой на сервер.
vorbit-autocopy-description = Выделите и скопируйте текст, затем вставьте его нажатием на колесо мыши.
vorbit-styling-description = Позволяет изменять интерфейс браузера сторонними темами.
vorbit-styling-warning1 = Устанавливайте темы только от авторов, которым вы доверяете.
vorbit-xorigin-ref-description = Отправлять referrer только тому сайту, который указан в referrer.
vorbit-xorigin-ref-warning1 = Может приводить к поломкам сайтов. Кроме того, даже отправленные referrer'ы будут обрезаны.
vorbit-webgl-warning1 = Когда сайт попробует создать контекст WebGL, у вас будет запрошено разрешение.
vorbit-rfp-description = ResistFingerprinting – лучший в своём роде инструмент защиты от отпечатков.
vorbit-auto-decline-canvas-description = Автоматически блокировать доступ к canvas'у веб-сайтам, не уточняя у пользователя.
vorbit-letterboxing-description = Леттербоксинг помещает веб-страницы в рамку, чтобы сайты не могли точно определить разрешение экрана.
vorbit-goog-safe-description = Если вы обеспокоены защитой от вредоносного ПО и фишинга, стоит включить эту опцию.
vorbit-goog-safe-download-warning1 = Все проверки выполняются локально.
vorbit-footer = Полезные ссылки
vorbit-config-link = Все продвинутые настройки (about:config)
vorbit-open-profile = Открыть каталог профиля
vorbit-warning-description = Мы тщательно поработали над подбором настроек по умолчанию, чтобы обеспечить максимальную конфиденциальность и безопасность. Ознакомьтесь с описаниями настроек для получения представления о том, что влечёт их изменение.
vorbit-webgl-checkbox =
    .label = Использовать WebGL
vorbit-goog-safe-download-description = Разрешить безопасному просмотру проверять скачиваемые файлы на опасность.
vorbit-webgl-description = WebGL – отличный инструмент для создания цифровых отпечатков.
vorbit-goog-safe-warning1 = Эта опция выключена из-за беспокойства возможностью цензуры со стороны Google, но менее продвинутым пользователям мы рекомендуем её включить. Все проверки выполняются локально.
vorbit-auto-decline-canvas-warning1 = Разрешить доступ к canvas'у по-прежнему можно будет через адресную строку.
content-blocking-section-top-level-description = vOrbit-lite поддерживает использование и включает по умолчанию Улучшенную защиту от отслеживания в Строгом режиме. Это одна из самых важных настроек в браузере, т.к. она обеспечивает разделение состояний, использует строгие блокирующие списки и другие эффективные настройки для конфиденциальности. Понижение режима на менее строгий не рекомендуется.
vorbit-rfp-checkbox =
    .label = Препятствовать созданию отпечатков (ResistFingerprinting)
vorbit-rfp-warning1 = Если вы хотите его выключить, советуем установить расширение вроде Canvas Blocker.
vorbit-webgl-prompt-checkbox =
    .label = Включить запрос на разрешение WebGL
vorbit-webgl-prompt-description = Если WebGL включён, на конкретном сайте появляется запрос на разрешение вместо автоматического предоставления доступа.
permissions-webgl2 =
    .label = WebGL
