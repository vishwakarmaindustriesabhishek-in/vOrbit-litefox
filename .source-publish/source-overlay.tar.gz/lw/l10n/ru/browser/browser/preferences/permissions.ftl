# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 55em
    .title = Исключения
permissions-close-key =
    .key = w
permissions-address = Адрес веб-сайта
    .accesskey = е
permissions-block =
    .label = Блокировать
    .accesskey = л
permissions-disable-etp =
    .label = Добавить исключение
    .accesskey = и
permissions-session =
    .label = Разрешить на сессию
    .accesskey = с
permissions-allow =
    .label = Разрешить
    .accesskey = з
permissions-add =
    .label = Добавить
    .accesskey = Ф
permissions-button-off =
    .label = Отключить
    .accesskey = ю
permissions-button-off-temporarily =
    .label = Временно отключить
    .accesskey = е
permissions-site-name =
    .label = Веб-сайт
permissions-status =
    .label = Состояние
permissions-remove =
    .label = Удалить веб-сайт
    .accesskey = д
permissions-remove-all =
    .label = Удалить все веб-сайты
    .accesskey = в
permissions-save-changes-2 =
    .buttonlabelaccept = Сохранить изменения
    .buttonaccesskeyaccept = х
permission-dialog =
    .buttonlabelaccept = Сохранить изменения
    .buttonaccesskeyaccept = х
permissions-autoplay-menu = По умолчанию для всех веб-сайтов:
permissions-searchbox =
    .placeholder = Поиск по веб-сайту
permissions-capabilities-autoplay-allow =
    .label = Разрешить аудио и видео
permissions-capabilities-autoplay-block =
    .label = Блокировать аудио
permissions-capabilities-autoplay-blockall =
    .label = Блокировать аудио и видео
permissions-capabilities-allow =
    .label = Разрешить
permissions-capabilities-block =
    .label = Блокировать
permissions-capabilities-prompt =
    .label = Всегда спрашивать
permissions-capabilities-listitem-allow =
    .value = Разрешить
permissions-capabilities-listitem-block =
    .value = Блокировать
permissions-capabilities-listitem-allow-session =
    .value = Разрешить на сессию
permissions-capabilities-listitem-off =
    .value = Отключить
permissions-capabilities-listitem-off-temporarily =
    .value = Временно отключить

## Invalid Hostname Dialog

permissions-invalid-uri-title = Введено некорректное сетевое имя сервера
permissions-invalid-uri-label = Введите корректное сетевое имя сервера.

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Исключения для улучшенной защиты от отслеживания
permissions-exceptions-manage-etp-desc = Вы можете указать, на каких сайтах отключить «Улучшенную защиту от отслеживания». Введите точный адрес сайта, которым вы хотите управлять, и нажмите «Добавить исключение».

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Исключения — Куки и данные сайтов
permissions-exceptions-cookie-desc = Вы можете указать, каким веб-сайтам разрешено всегда или никогда использовать куки и данные сайтов.  Введите точный адрес сайта и нажмите кнопку «Блокировать», «Разрешить на сессию» или «Разрешить».

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Исключения — Удаление истории при выходе
permissions-exceptions-shutdown-clearing-desc = Вы можете указать, какие веб-сайты будут сохранять свои данные, когда { -brand-short-name } удалит историю при закрытии. Введите точный адрес сайта, которым вы хотите управлять, и нажмите кнопку «Разрешить».

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Исключения — Режим «Только HTTPS»
permissions-exceptions-https-only-desc2 = Вы можете отключить режим «Только HTTPS» для определённых веб-сайтов. { -brand-short-name } не будет пытаться переключать соединение на защищённый HTTPS для этих сайтов.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Разрешённые веб-сайты — Всплывающие окна и сторонние перенаправления
permissions-exceptions-popup-desc2 = Вы можете указать, каким веб-сайтам разрешено открывать всплывающие окна и перенаправляться сторонними фреймами.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Исключения — сохранённые пароли
permissions-exceptions-saved-passwords-desc = { -brand-short-name } не сохраняет пароли для перечисленных здесь сайтов.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Разрешённые веб-сайты — Установка дополнений
permissions-exceptions-addons-desc = Вы можете указать, каким веб-сайтам разрешено устанавливать дополнения. Введите точный адрес каждого сайта и нажмите кнопку «Разрешить».

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Настройки — Автовоспроизведение
permissions-site-autoplay-desc = Вы можете указать, какие сайты не будут следовать вашим настройкам автовоспроизведения по умолчанию.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Настройки — Разрешения на отправку уведомлений
permissions-site-notification-desc = Следующие веб-сайты запросили разрешение отправлять вам уведомления. Вы можете указать каким веб-сайтам разрешено отправлять вам уведомления. Вы также можете блокировать новые запросы с просьбами разрешить отправлять вам уведомления.
permissions-site-notification-disable-label =
    .label = Блокировать новые запросы на отправку вам уведомлений
permissions-site-notification-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать разрешение на отправку уведомлений. Блокировка уведомлений может нарушить некоторые функции веб-сайта.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Разрешить веб-сайтам уведомления при закрытии { -brand-short-name }
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Также действуют настройки уведомлений вашей ОС.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Настройки — Разрешения на доступ к местоположению
permissions-site-location-desc = Следующие веб-сайты запросили разрешение на доступ к вашему местоположению. Вы можете указать каким веб-сайтам разрешено получать доступ к вашему местоположению. Вы также можете блокировать новые запросы с просьбами разрешить доступ к вашему местоположению.
permissions-site-location-disable-label =
    .label = Блокировать новые запросы на доступ к вашему местоположению
permissions-site-location-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать разрешение на доступ к вашему местоположению. Блокировка доступа к вашему местоположению может нарушить некоторые функции веб-сайта.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Параметры — Разрешения виртуальной реальности
permissions-site-xr-desc = Следующие веб-сайты запросили разрешение на доступ к вашим устройствам виртуальной реальности. Вы можете указать каким веб-сайтам разрешено получать доступ к вашим устройствам виртуальной реальности. Вы также можете блокировать новые запросы с просьбами разрешить доступ к вашим устройствам виртуальной реальности.
permissions-site-xr-disable-label =
    .label = Запретить новые запросы на доступ к вашим устройствам виртуальной реальности
permissions-site-xr-disable-desc = Это не позволит сайтам, кроме перечисленных выше, запрашивать разрешение на доступ к устройствам виртуальной реальности. Запрет доступа к вашим устройствам виртуальной реальности может нарушить некоторые функции сайта.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Настройки - Заблокированные сайты для ссылок приложений
permissions-site-app-links-desc = Эти сайты не могут просить открыть ссылки на приложения, такие как почтовые клиенты (mailto:). Удалить сайт, чтобы он мог запросить это снова.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Настройки — Разрешения на доступ к камере
permissions-site-camera-desc = Следующие сайты запросили разрешение на доступ к вашей камере. Вы можете указать каким сайтам разрешено получать доступ к вашей камере. Вы также можете запретить новые запросы с просьбами разрешить доступ к вашей камере.
permissions-site-camera-disable-label =
    .label = Блокировать новые запросы на доступ к вашей камере
permissions-site-camera-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать разрешение на доступ к вашей камере. Блокировка доступа к вашей камере может нарушить некоторые функции веб-сайта.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Параметры — Приложения и службы устройства
permissions-site-localhost-desc = Следующие веб-сайты запросили доступ к приложениям и службам на этом устройстве. Вы можете разрешить или запретить сайтам это делать.
permissions-site-localhost-disable-label =
    .label = Блокировать новые запросы на доступ к приложениям и службам на этом устройстве
permissions-site-localhost-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать доступ к приложениям и службам на этом устройстве. Это может нарушить некоторые функции веб-сайтов.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Параметры — Локальные сетевые устройства
permissions-site-local-network-desc = Эти веб-сайты запросили доступ к приложениям и службам на устройствах, подключенных к вашему Wi-Fi или локальной сети. Вы можете разрешить или запретить сайтам это делать.
permissions-site-local-network-disable-label =
    .label = Запретить новые запросы на доступ к приложениям и службам на устройствах, подключенных к вашему Wi-Fi или локальной сети.
permissions-site-local-network-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать доступ к приложениям и службам на устройствах, подключенных к вашему Wi-Fi или локальной сети. Это может нарушить некоторые функции веб-сайтов.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Настройки — Разрешения на доступ к микрофону
permissions-site-microphone-desc = Следующие веб-сайты запросили разрешение на доступ к вашему микрофону. Вы можете указать каким веб-сайтам разрешено получать доступ к вашему микрофону. Вы также можете блокировать новые запросы с просьбами разрешить доступ к вашему микрофону.
permissions-site-microphone-disable-label =
    .label = Блокировать новые запросы на доступ к вашему микрофону
permissions-site-microphone-disable-desc = Это не позволит веб-сайтам, кроме перечисленных выше, запрашивать разрешение на доступ к вашему микрофону. Блокировка доступа к вашему микрофону может нарушить некоторые функции веб-сайта.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Параметры — Разрешения на доступ к динамику
permissions-site-speaker-desc = Следующие сайты запросили выбор устройства вывода звука. Вы можете указать, каким сайтам разрешено выбирать устройство вывода звука.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Исключения сайтов для DNS через HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } не будет использовать безопасный DNS для этих сайтов и их поддоменов.
permissions-doh-entry-field = Введите доменное имя сайта
    .accesskey = м
permissions-doh-add-exception =
    .label = Добавить
    .accesskey = б
permissions-doh-col =
    .label = Домен
permissions-doh-remove =
    .label = Удалить
    .accesskey = л
permissions-doh-remove-all =
    .label = Удалить все
    .accesskey = с


