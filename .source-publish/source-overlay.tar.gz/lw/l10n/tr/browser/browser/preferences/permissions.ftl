# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = İstisnalar
permissions-close-key =
    .key = w
permissions-address = Site adresi
    .accesskey = d
permissions-block =
    .label = Engelle
    .accesskey = E
permissions-disable-etp =
    .label = İstisna ekle
    .accesskey = e
permissions-session =
    .label = Oturum boyunca izin ver
    .accesskey = r
permissions-allow =
    .label = İzin ver
    .accesskey = z
permissions-add =
    .label = Ekle
    .accesskey = E
permissions-button-off =
    .label = Kapat
    .accesskey = K
permissions-button-off-temporarily =
    .label = Geçici olarak kapat
    .accesskey = G
permissions-site-name =
    .label = Web sitesi
permissions-status =
    .label = Durum
permissions-remove =
    .label = Siteyi sil
    .accesskey = S
permissions-remove-all =
    .label = Tüm siteleri sil
    .accesskey = e
permissions-save-changes-2 =
    .buttonlabelaccept = Değişiklikleri kaydet
    .buttonaccesskeyaccept = D
permission-dialog =
    .buttonlabelaccept = Değişiklikleri kaydet
    .buttonaccesskeyaccept = D
permissions-autoplay-menu = Tüm web siteleri için varsayılan:
permissions-searchbox =
    .placeholder = Web sitesi ara
permissions-capabilities-autoplay-allow =
    .label = Ses ve videoya izin ver
permissions-capabilities-autoplay-block =
    .label = Sesi engelle
permissions-capabilities-autoplay-blockall =
    .label = Ses ve videoyu engelle
permissions-capabilities-allow =
    .label = İzin ver
permissions-capabilities-block =
    .label = Engelle
permissions-capabilities-prompt =
    .label = Her zaman sor
permissions-capabilities-listitem-allow =
    .value = İzin ver
permissions-capabilities-listitem-block =
    .value = Engelle
permissions-capabilities-listitem-allow-session =
    .value = Oturum boyunca izin ver
permissions-capabilities-listitem-off =
    .value = Kapalı
permissions-capabilities-listitem-off-temporarily =
    .value = Geçici olarak kapalı

## Invalid Hostname Dialog

permissions-invalid-uri-title = Geçersiz sunucu adı girildi
permissions-invalid-uri-label = Lütfen geçerli bir sunucu adı girin

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Gelişmiş İzlenme Koruması İstisnaları
permissions-exceptions-manage-etp-desc = Gelişmiş izlenme korumasının hangi sitelerde kapalı kalacağını belirleyebilirsiniz. Yönetmek istediğiniz sitenin tam adresini yazıp “İstisna ekle”ye tıklayın.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = İstisnalar - Çerezler ve Site Verileri
permissions-exceptions-cookie-desc = Hangi web sitelerinin çerezleri ve site verilerini her zaman kullanabileceğini veya hiç kullanmayacağını belirleyebilirsiniz.  Yönetmek istediğiniz sitenin tam adresini yazıp “Engelle”, “Oturum boyunca izin ver” veya “İzin ver”e tıklayın.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = İstisnalar - Kapanırken geçmişi temizle
permissions-exceptions-shutdown-clearing-desc = { -brand-short-name } kapanırken geçmişi temizlediğinde hangi sitelerin verilerini tutacağını belirleyebilirsiniz. Yönetmek istediğiniz sitenin tam adresini yazıp “İzin ver”e tıklayın.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = İstisnalar - Yalnızca HTTPS Modu
permissions-exceptions-https-only-desc2 = Belirli web siteleri için yalnızca HTTPS modunu kapatabilirsiniz. Böylece { -brand-short-name }, bu sitelerde HTTPS güvenliğini sağlamak üzere bağlantıyı yükseltme girişiminde bulunmaz.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = İzin Verilen Siteler - Açılır Pencereler ve Üçüncü Taraf Yönlendirmeleri
permissions-exceptions-popup-desc2 = Hangi sitelerin açılır pencere gösterebileceğini ve üçüncü taraf çerçeveler tarafından yeniden yönlendirilebileceğini belirleyebilirsiniz.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = İstisnalar - Kayıtlı Parolalar
permissions-exceptions-saved-passwords-desc = { -brand-short-name } bu listedeki sitelerin parolalarını kaydetmeyecektir.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = İzin Verilen Siteler - Eklenti Yükleme
permissions-exceptions-addons-desc = Hangi sitelerin eklenti yükleyebileceğini belirleyebilirsiniz. İzin vermek istediğiniz sitenin tam adresini yazdıktan sonra İzin ver’e tıklayın.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Otomatik Oynat
permissions-site-autoplay-desc = Varsayılan otomatik oynatma ayarlarınıza uymasını istemediğiniz siteleri buradan yönetebilirsiniz.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Bildirim İzinleri
permissions-site-notification-desc = Aşağıdaki web siteleri size bildirim gönderme isteğinde bulundu. Hangi web sitelerine bildirim gönderme izni vereceğinizi seçebilirsiniz. Ayrıca yeni bildirim gönderme isteklerini tamamen engelleyebilirsiniz.
permissions-site-notification-disable-label =
    .label = Bildirim gönderme isteklerini sormadan engelle
permissions-site-notification-disable-desc = Yukarıdaki listede bulunmayan hiçbir web sitesi size bildirim gönderme isteğinde bulunamayacaktır. Bildirimleri engellerseniz bazı site özellikleri çalışmayabilir.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = { -brand-short-name } kapalıyken web sitesi bildirimine izin ver
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = İşletim sisteminizin bildirim ayarları da geçerlidir.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Konum İzinleri
permissions-site-location-desc = Aşağıdaki web siteleri konumunuza erişme isteğinde bulundu. Hangi web sitelerinin konumunuzu öğrenebileceğini seçebilirsiniz. Ayrıca konumunuzu öğrenme isteklerini tamamen engelleyebilirsiniz.
permissions-site-location-disable-label =
    .label = Konumumu öğrenme isteklerini sormadan engelle
permissions-site-location-disable-desc = Yukarıdaki listede bulunmayan hiçbir web sitesi konumunuzu öğrenme isteğinde bulunamayacaktır. Konumunuzun öğrenilmesini engellerseniz bazı site özellikleri çalışmayabilir.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Sanal Gerçeklik İzinleri
permissions-site-xr-desc = Aşağıdaki web siteleri sanal gerçeklik cihazlarınıza erişme isteğinde bulundu. Hangi web sitelerinin sanal gerçeklik cihazlarınıza erişebileceğini seçebilirsiniz. Ayrıca sanal gerçeklik cihazlarınıza erişim isteklerini tamamen engelleyebilirsiniz.
permissions-site-xr-disable-label =
    .label = Sanal gerçeklik cihazlarına erişme isteklerini sormadan engelle
permissions-site-xr-disable-desc = Yukarıdaki listede bulunmayan hiçbir web sitesi sanal gerçeklik cihazlarınıza erişme isteğinde bulunamayacaktır. Sanal gerçeklik cihazlarınıza erişimi engellerseniz bazı site özellikleri çalışmayabilir.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Ayarlar - Uygulama Bağlantılarında Engellenen Siteler
permissions-site-app-links-desc = Bu sitelerin e-posta (mailto:) vb. uygulama bağlantılarını açmayı istemesi engellendi. İstekte bulunmasına izin vermek istediğiniz siteleri listeden kaldırın.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Kamera İzinleri
permissions-site-camera-desc = Aşağıdaki web siteleri kameranıza erişme isteğinde bulundu. Hangi web sitelerinin kameranıza erişebileceğini seçebilirsiniz. Ayrıca kameranıza erişme isteklerini tamamen engelleyebilirsiniz.
permissions-site-camera-disable-label =
    .label = Kamerama erişme isteklerini sormadan engelle
permissions-site-camera-disable-desc = Yukarıdaki listede bulunmayan hiçbir web sitesi kameranıza erişme isteğinde bulunamayacaktır. Kamera erişimini engellerseniz bazı site özellikleri çalışmayabilir.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Ayarlar - Cihaz uygulamaları ve hizmetleri
permissions-site-localhost-desc = Aşağıdaki siteler bu cihazdaki uygulama ve hizmetlere erişmek istedi. Erişime izin vermeyi veya erişimi engellemeyi seçebilirsiniz.
permissions-site-localhost-disable-label =
    .label = Bu cihazdaki uygulama ve hizmetlere erişim isteklerini engelle
permissions-site-localhost-disable-desc = Yukarıdaki listede bulunmayan hiçbir site bu cihazdaki uygulama ve hizmetlere erişim isteğinde bulunamayacaktır. Bu ayarı etkinleştirmeniz bazı sitelerin özelliklerini bozabilir.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Ayarlar - Yerel Ağ Cihazları
permissions-site-local-network-desc = Aşağıdaki siteler Wi-Fi veya yerel ağınıza bağlı cihazlardaki uygulama ve hizmetlere erişmek istedi. Erişime izin vermeyi veya erişimi engellemeyi seçebilirsiniz.
permissions-site-local-network-disable-label =
    .label = Wi-Fi veya yerel ağıma bağlı cihazlardaki uygulama ve hizmetlere erişim için yapılacak yeni istekleri engelle.
permissions-site-local-network-disable-desc = Yukarıdaki listede bulunmayan hiçbir site, Wi-Fi veya yerel ağınızdaki cihazlarda bulunan uygulama ve hizmetlere erişim isteğinde bulunamayacaktır. Bu ayarı etkinleştirmeniz bazı sitelerin özelliklerini bozabilir.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Ayarlar - Mikrofon İzinleri
permissions-site-microphone-desc = Aşağıdaki web siteleri mikrofonunuza erişme isteğinde bulundu. Hangi web sitelerinin mikrofonunuza erişebileceğini seçebilirsiniz. Ayrıca mikrofonunuza erişme isteklerini tamamen engelleyebilirsiniz.
permissions-site-microphone-disable-label =
    .label = Mikrofonuma erişme isteklerini sormadan engelle
permissions-site-microphone-disable-desc = Yukarıdaki listede bulunmayan hiçbir web sitesi mikrofonunuza erişme isteğinde bulunamayacaktır. Mikrofon erişimini engellerseniz bazı site özellikleri çalışmayabilir.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Ayarlar - Ses Aygıtı İzinleri
permissions-site-speaker-desc = Aşağıdaki siteler ses çıkış cihazını seçmek istedi. Hangi sitelerin ses çıkış cihazını seçebileceğini belirtebilirsiniz.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = HTTPS üzerinden DNS için web sitesi istisnaları
permissions-exceptions-manage-doh-desc = { -brand-short-name } bu sitelerde ve alt alan adlarında güvenli DNS kullanmayacaktır.
permissions-doh-entry-field = Web sitesinin alan adını yazın
    .accesskey = W
permissions-doh-add-exception =
    .label = Ekle
    .accesskey = E
permissions-doh-col =
    .label = Alan adı
permissions-doh-remove =
    .label = Kaldır
    .accesskey = K
permissions-doh-remove-all =
    .label = Tümünü kaldır
    .accesskey = T


