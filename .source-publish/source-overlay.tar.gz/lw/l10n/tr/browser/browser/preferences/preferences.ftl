# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Web sitelerine verilerimi satmamalarını ve paylaşmamalarını söyle
    .accesskey = W
non-technical-privacy-group =
    .label = Web sitesi gizlilik tercihleri
do-not-track-removal3 =
    .message = “Do Not Track” özelliğini artık desteklemiyoruz.
non-technical-privacy-heading =
    .label = Ek korumalar
preferences-privacy-relay-available =
    .description = Gerçek e-posta adresinizi gizleyerek gelen kutunuzu spam’den korur.
    .label = { -relay-brand-name } e-posta maskeleri öner
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Ayarlar
category-nav-heading =
    .heading = Ayarlar
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Ayarlarda ara
    .style = width: 15.4em
managed-notice = Tarayıcınız kuruluşunuz tarafından yönetiliyor.
managed-notice-info-icon =
    .alt = Bilgi
managed-notice-nav =
    .label = Tarayıcınız kuruluşunuz tarafından yönetiliyor.
tls-key-logging-notice-nav =
    .label = Şifrelenmiş trafiğiniz bir uygulama veya hizmet tarafından görülebilir.
category-list =
    .aria-label = Kategoriler
pane-general-title = Genel
pane-home-title = Giriş Sayfası
pane-home-startup-title2 = Giriş sayfası ve başlangıç
    .title = Giriş sayfası ve başlangıç
pane-search-title2 = Arama
    .title = Arama
pane-privacy-title3 = Gizlilik ve güvenlik
    .title = Gizlilik ve güvenlik
pane-privacy-section =
    .heading = Gizlilik ve güvenlik
pane-sync-title3 = Eşitleme
pane-ai-controls-title2 = Yapay zekâ kontrolleri
    .title = Yapay zekâ kontrolleri
pane-about-firefox-title = { -brand-short-name } hakkında
    .title = { pane-about-firefox-title }
pane-appearance-title = Görünüm
    .title = { pane-appearance-title }
pane-downloads-title2 = İndirilenler
    .title = İndirilenler
pane-downloads3 =
    .heading = İndirilenler
pane-accessibility-title = Erişilebilirlik
    .title = { pane-accessibility-title }
pane-languages-title2 = Diller
    .title = Diller
preferences-languages-header3 =
    .heading = Diller
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Deneysel özelliklerimizi deneyin! Bu özellikler henüz geliştirme aşamasında oldukları için her an değişebilir ve { -brand-short-name } uygulamasının çalışma şeklini etkileyebilir. <a data-l10n-name="data-collection">Teknik verileri ve etkileşim verilerini</a> açtıysanız bu özellikleri kullanımınızla ilgili veri toplayabiliriz.
pane-experimental-reset =
    .label = Varsayılanları geri yükle
    .accesskey = V
help-button-label2 = { -brand-short-name } desteği
    .title = { -brand-short-name } desteği
addons-button-label2 = Uzantılar ve temalar
    .title = Uzantılar ve temalar
focus-search =
    .key = f
close-button =
    .aria-label = Kapat
do-not-track-removal2 =
    .label = Artık “Do Not Track” sinyalini desteklemiyoruz
applications-setting-new-file-types =
    .label = { -brand-short-name } diğer dosyalarla ne yapsın?

## Browser Restart Dialog

feature-enable-requires-restart = Bu özelliği etkinleştirmek için { -brand-short-name } yeniden başlatılmalıdır.
feature-disable-requires-restart = Bu özelliği devre dışı bırakmak için { -brand-short-name } yeniden başlatılmalıdır.
should-restart-title = { -brand-short-name } tarayıcısını yeniden başlat
should-restart-ok = { -brand-short-name } tarayıcısını yeniden başlat
cancel-no-restart-button = Vazgeç
restart-later = Daha sonra yeniden başlat

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> Bu ayarı <strong>{ $name }</strong> yönetiyor.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> Bu ayarı <strong>{ $name }</strong> yönetiyor.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kapsayıcı sekmelere ihtiyaç duyuyor.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> Bu ayarı <strong>{ $name }</strong> yönetiyor.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> { -brand-short-name } tarayıcınızın internete nasıl bağlanacağını <strong>{ $name }</strong> kontrol ediyor.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Uzantıyı etkinleştirmek için <img data-l10n-name="menu-icon"/> menüdeki <img data-l10n-name="addons-icon"/> Eklentiler bölümüne gidin.
extension-controlled-enable-2 = Bu uzantıyı yeniden etkinleştirmek için <a data-l10n-name="addons-link">Uzantılar ve temalar</a> sayfasına gidin.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = Bazı giriş sayfası ayarlarınızı { $name } yönetiyor.

## Preferences UI Search Results

search-results-header = Arama sonuçları
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Kusura bakmayın, ayarlarda “<span data-l10n-name="query"></span>” ile ilgili bir sonuç bulamadık.
search-results-help-link = Yardım mı gerekiyor? <a data-l10n-name="url">{ -brand-short-name } Destek</a>’i ziyaret edin.

## General Section

always-check-default =
    .label = Varsayılan tarayıcımın { -brand-short-name } olup olmadığını her zaman denetle
    .accesskey = V
startup-restore-windows-and-tabs =
    .label = Önceki pencereleri ve sekmeleri aç
    .accesskey = Ö
startup-windows-launch-on-login-profile-disabled =
    .message = “Kullanıcı profilini seçin” penceresindeki “{ profile-manager-use-selected.label }” seçeneğini işaretleyerek bu tercihi etkinleştirin.
windows-launch-on-login =
    .label = Bilgisayarım açıldığında { -brand-short-name } tarayıcısını otomatik olarak aç
    .accesskey = B
windows-launch-on-login-disabled = Bu tercih Windows’ta devre dışıdır. Değiştirmek için sistem ayarlarındaki <a data-l10n-name="startup-link">Başlangıç Uygulamaları</a> kısmına bakabilirsiniz.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Ayrıca yeni sekme aç
    .accesskey = n
disable-extension =
    .label = Uzantıyı etkisizleştir
preferences-data-migration-group =
    .description = Başka bir tarayıcıdaki yer imlerinizi, parolalarınızı, geçmişinizi, uzantılarınızı ve otomatik doldurma verilerinizi buraya aktarın.
    .label = Tarayıcı verilerini içe aktar
preferences-data-migration-button =
    .label = Verileri içe aktar
    .accesskey = V
preferences-profiles-group-header =
    .heading = Profiller
preferences-profiles-subpane-description =
    .description = Her profilin gezinti verileri ve ayarları, geçmişi, parolaları ve diğer bilgileri birbirinden ayrıdır.
preferences-profiles-section-header =
    .description = Her profilin gezinti verileri ve ayarları, geçmişi, parolaları ve diğer bilgileri birbirinden ayrıdır.
    .label = Profiller
preferences-manage-profiles-button =
    .label = Profilleri yönet
preferences-profiles-settings-button =
    .label = Ayarlar
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Ayarlar, eklentiler, geçmiş, yer imleri ve parolalar gibi kayıtlı verileriniz yeni profile kopyalanır ama hesabınız ve eşitleme bilgileriniz kopyalanmaz.
    .label = Mevcut bir profili kopyala
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Kopyalanacak profil
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Profil seçin
preferences-copy-profile-button = Kopyala
tabs-browsing-section =
    .heading = Sekmeler ve gezinti
pane-tabs-browsing-title2 = Sekmeler ve gezinti
    .title = Sekmeler ve gezinti
tabs-group-header2 =
    .label = Sekmeler
tabs-opening-heading =
    .label = Açılış
tabs-interaction-heading =
    .label = Etkileşim
tabs-containers-heading =
    .label = Kapsayıcılar
tabs-closing-heading =
    .label = Kapanış
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab, sekmeler arasında son kullanıldıkları sırayla atlasın
    .accesskey = T
open-new-link-as-tabs =
    .label = Bağlantıları yeni pencere yerine yeni sekmede aç
    .accesskey = B
open-external-link-next-to-active-tab =
    .label = Uygulamalardan gelen bağlantıları etkin sekmenin yanında aç
ask-on-close-multiple-tabs =
    .label = Birden fazla sekmeyi kapatırken bana sor
    .accesskey = i
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = { $quitKey } ile çıkış yaparken bana sor
    .accesskey = ı
warn-on-open-many-tabs =
    .label = Birden çok sekme açmanın { -brand-short-name } uygulamasını yavaşlatabileceği durumlarda beni uyar
    .accesskey = k
switch-to-new-tabs-2 =
    .label = Bağlantıları ve ortam dosyalarını yeni sekmede açtığımda hemen o sekmeye geç
    .accesskey = o
show-tabs-in-taskbar =
    .label = Sekme ön izlemelerini Windows görev çubuğunda göster
    .accesskey = ö
browser-containers-enabled-2 =
    .label = Kapsayıcı sekmeleri kullan
    .accesskey = m
browser-containers-learn-more = Daha fazla bilgi al
browser-containers-settings-2 =
    .label = Ayarları yönet
    .accesskey = A
containers-disable-alert-title = Tüm kapsayıcı sekmeler kapatılsın mı?
startup-group =
    .label = Başlangıç

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Kapsayıcı Sekmeler’i şimdi devre dışı bırakırsanız { $tabCount } kapsayıcı sekme kapatılacaktır. Bu özelliği devre dışı bırakmak istediğinizden emin misiniz?
       *[other] Kapsayıcı Sekmeler’i şimdi devre dışı bırakırsanız { $tabCount } kapsayıcı sekme kapatılacaktır. Bu özelliği devre dışı bırakmak istediğinizden emin misiniz?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] { $tabCount } kapsayıcı sekmeyi kapat
       *[other] { $tabCount } kapsayıcı sekmeyi kapat
    }

##

containers-disable-alert-cancel-button = Vazgeç
containers-remove-alert-title = Bu kapsayıcı silinsin mi?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Bu kapsayıcıyı şimdi silerseniz { $count } kapsayıcı sekmesi kapanacaktır. Kapsayıcıyı silmek istediğinizden emin misiniz?
       *[other] Bu kapsayıcıyı şimdi silerseniz { $count } kapsayıcı sekmesi kapanacaktır. Kapsayıcıyı silmek istediğinizden emin misiniz?
    }
containers-remove-ok-button = Bu kapsayıcıyı sil
containers-remove-cancel-button = Bu kapsayıcıyı silme
settings-tabs-show-image-in-preview =
    .label = Bir sekmenin üzerine geldiğimde sekme ön izlemesini göster
    .accessKey = ö
settings-tabs-drag-to-create-tab-groups =
    .label = Sekmeleri bir araya sürükleyince sekme grubu oluştur
browser-layout-header2 =
    .label = Tarayıcı düzeni
browser-layout-horizontal-tabs2 =
    .description = Sekmeler üstte
    .label = Yatay sekmeler
    .title = Sekmeler üstte
browser-layout-vertical-tabs2 =
    .description = Sekmeler yanda, kenar çubuğunda
    .label = Dikey sekmeler
    .title = Sekmeler yanda, kenar çubuğunda
browser-layout-show-sidebar2 =
    .description = Ana görünümünüzden ayrılmadan yer imlerine, telefonunuzdaki sekmelere ve YZ sohbet botlarına hızlıca erişin.
    .label = Kenar çubuğunu göster
page-navigation-group =
    .label = Sayfada gezinti

## General Section - Language & Appearance

language-and-appearance-header = Dil ve görünüm
appearance-group2 =
    .description = Bazı siteler renklerini tercihlerinize uyacak şekilde değiştirir. Tercih ettiğiniz renk şemasını seçin.
    .label = Web sitesi görünümü
preferences-web-appearance-choice-auto3 =
    .label = Sistem
    .title = Web sitesi arka planlarını ve içeriğini sistem ayarlarıma ve { -brand-short-name } temama göre otomatik olarak değiştir.
preferences-web-appearance-choice-light2 =
    .label = Açık
    .title = Web sitesi arka planları ve içeriğinde açık bir görünüm kullan.
preferences-web-appearance-choice-dark2 =
    .label = Koyu
    .title = Web sitesi arka planları ve içeriğinde koyu bir görünüm kullan.
web-appearance-group =
    .aria-label = Web sitesi görünümü
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Kontrast denetimi ayarlarınız web sitesi görünümünü geçersiz kılıyor.
preferences-web-appearance-link =
    .label = { -brand-short-name } temalarını Uzantılar ve Temalar sayfasından yönetebilirsiniz.
preferences-contrast-control-group =
    .description = Web siteleri çeşitli ön plan ve arka plan renkleri kullanır. Tutarlı bir kontrast için tüm sitelerde aynı renkleri kullanabilirsiniz.
    .label = Web sitesi kontrastı
preferences-contrast-control-radio-group =
    .label = Renkleri geçersiz kıl
preferences-contrast-control-use-platform-settings =
    .label = Otomatik (Sistem ayarlarını kullan)
    .accesskey = O
preferences-contrast-control-off =
    .label = Kapalı
    .accesskey = K
preferences-contrast-control-custom =
    .label = Özel
    .accesskey = Ö
preferences-colors-manage-button2 =
    .label = Renkleri yönet
    .accesskey = R
preferences-colors-manage-button =
    .label = Renkleri yönet…
    .accesskey = R
preferences-fonts-header2 =
    .label = Yazı tipleri
preferences-default-zoom-label =
    .label = Varsayılan yakınlaştırma
    .accesskey = m
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = %{ $percentage }
preferences-zoom-text-only =
    .label = Sadece metni yakınlaştır
    .accesskey = S
preferences-text-zoom-override-warning2 =
    .message = “Sadece metni yakınlaştır” açıksa ve varsayılan yakınlaştırmanız %100 değilse bazı sitelerdeki içerikler düzgün görüntülenemeyebilir.
language-header = Dil
choose-language-description = Sayfaları hangi dilde görmeyi tercih ettiğinizi seçin
website-language-heading =
    .description = Bazı web sayfaları birden fazla dilde sunulabilir. Bu sayfaların görüntüleneceği dilleri tercih sıranıza göre seçin.
    .label = Web sitesi dili
website-preferred-language =
    .label = Tercih edilen diller
website-language-list =
    .aria-label = Tercih edilen diller
website-add-language =
    .label = Dil ekle
website-add-language-button =
    .aria-label = Seçilen dili ekle
    .title = Seçilen dili ekle
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = { $locale } dilini kaldır
    .title = { $locale } dilini kaldır
choose-button =
    .label = Seç…
    .accesskey = S
choose-browser-language-description = { -brand-short-name } menülerini, iletilerini ve bildirimlerini gösterirken kullanılacak dilleri seçin.
manage-browser-languages-button =
    .label = Alternatifleri ayarla…
    .accesskey = l
confirm-browser-language-change-description = Bu değişiklikleri uygulamak için { -brand-short-name } tarayıcısını yeniden başlatın
confirm-browser-language-change-button = Uygula ve yeniden başlat
browser-language-heading =
    .description = { -brand-short-name } menülerinde, iletilerinde ve bildirimlerinde kullanılacak dili seçin.
    .label = Tarayıcı dili
browser-language-preferred-label =
    .label = Tercih edilen dil
browser-language-fallback-label =
    .description = Tercih edilen dilin çevirileri eksikse kullanılır.
    .label = Yedek dil
browser-language-install-error =
    .message = { -brand-short-name } şu anda dillerinizi güncelleyemiyor. İnternet bağlantınızı kontrol edip yeniden deneyin.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = İstisnalar…
    .accesskey = s
settings-translations-header =
    .aria-label = Çeviriler
    .description = Sayfaları veya seçilen metni çevirin. Gizliliğinizi korumak için çeviriler cihazınızdan dışarı çıkmaz.
    .label = Çeviriler
settings-translations-offer-to-translate-label =
    .label = Sayfaları çevirmeyi öner
settings-translations-more-settings-button =
    .description = Diller, web siteleri ve çevrimdışı çeviri için tercihlerinizi ayarlayın.
    .label = Diğer çeviri ayarları
settings-translations-subpage-header =
    .heading = Diğer çeviri ayarları
settings-translations-subpage-speed-up-translation-header =
    .description = Daha hızlı çeviri ve çevrimdışı çeviri için tüm dilleri indirin.
    .label = Çeviriyi hızlandır
settings-translations-subpage-automatic-translation-header =
    .label = Otomatik çeviri
settings-translations-subpage-always-translate-header =
    .label = Bu dilleri her zaman çevir
settings-translations-subpage-never-translate-header =
    .label = Bu dilleri asla çevirme
settings-translations-subpage-never-translate-sites-header =
    .label = Bu siteleri asla çevirme
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Site eklemek isterseniz <img data-l10n-name="translations-icon"/> çeviri panelini açın, <img data-l10n-name="settings-icon"/> çeviri ayarlarını seçip “Bu siteyi asla çevirme”yi seçin
settings-translations-subpage-language-select-option =
    .label = Dil ekle
settings-translations-subpage-language-add-button =
    .aria-label = Dil ekle
    .title = Dil ekle
settings-translations-subpage-download-languages-header =
    .label = Dilleri indir
settings-translations-subpage-download-languages-select-option =
    .label = Dil seçin
settings-translations-subpage-download-languages-button =
    .aria-label = Dili indir
    .title = Dili indir
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Hiçbir dil indirilmedi
settings-translations-subpage-no-languages-added =
    .label = Hiçbir dil eklenmedi
settings-translations-subpage-download-progress = İndirme devam ediyor…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = { $language } indirilemedi ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Yeniden dene
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = { $language } ({ $size } MB) silinsin mi?
settings-translations-subpage-download-delete-button =
    .label = Sil
settings-translations-subpage-download-cancel-button =
    .label = Vazgeç
settings-translations-subpage-no-sites-added =
    .label = Hiçbir site eklenmedi
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Tarih, saat, sayı ve ölçüleri biçimlendirmek için “{ $localeName }” işletim sistemi ayarlarımı kullan
settings-spellcheck-header =
    .label = Yazım denetimi
check-user-spelling =
    .label = Yazarken yazım denetimi yap
    .accesskey = Y
spellcheck-download-dictionaries =
    .label = Sözlük indir
spellcheck-promo =
    .heading = Yazım denetimi nasıl kullanılır?
    .message = Yazım denetimini açıp kapatmak veya dil değiştirmek için metin alanlarına sağ tıklayın. Bazı alanlar yazım denetimini desteklemeyebilir.

## Downloads - Files and applications

files-and-applications-title = Dosyalar ve uygulamalar
download-save-files-header =
    .label = Dosya kayıt yeri
download-save-where-3 =
    .aria-label = Dosya kayıt yeri
download-always-ask-where2 =
    .label = Dosyaları indirmeden önce nereye kaydedileceğini sor
    .accesskey = D
download-private-browsing-delete2 =
    .label = Gizli pencere kapatıldığında o pencerede indirilenleri sil
    .accesskey = G
applications-header = Uygulamalar
applications-description = { -brand-short-name } tarayıcısının web’den indirdiğiniz dosyaları veya web’de gezinirken kullandığınız uygulamaları nasıl ele alacağını seçin.
applications-setting2 =
    .description = { -brand-short-name } tarayıcısının indirilen dosyaları ve içerikleri nasıl ele alacağını seçin.
    .label = Dosyalar ve uygulamalar
applications-filter =
    .placeholder = Dosya türlerinde ve uygulamalarda ara
applications-type-column =
    .label = İçerik türü
    .accesskey = t
applications-type-heading = İçerik türü
applications-action-column =
    .label = Eylem
    .accesskey = E
applications-action-heading = Eylem
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } dosyası
applications-action-save =
    .label = Dosyayı kaydet
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = { $app-name } kullan
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = { $app-name } kullan (varsayılan)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Varsayılan macOS uygulamasını kullan
            [windows] Varsayılan Windows uygulamasını kullan
           *[other] Varsayılan sistem uygulamasını kullan
        }
applications-use-other =
    .label = Başka uygulama kullan…
applications-select-helper = Yardımcı uygulamayı seçin
applications-manage-app =
    .label = Uygulama ayrıntıları…
applications-always-ask =
    .label = Her zaman sor
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = { -brand-short-name } ile aç

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = { -brand-short-name } diğer dosyalarla ne yapsın?
applications-save-for-new-types =
    .label = Dosyaları kaydet
    .accesskey = D
applications-save-for-new-types2 =
    .label = Dosyaları otomatik olarak kaydet
    .accesskey = o
applications-ask-before-handling =
    .label = Dosyaları açmayı veya kaydetmeyi sor
    .accesskey = o
applications-ask-before-handling2 =
    .label = Dosyaları açmayı veya kaydetmeyi sor
    .accesskey = a
drm-group =
    .label = Sayısal Hak Yönetimi (DRM) içerikleri
play-drm-content =
    .label = DRM denetimli içerikleri oynat
    .accesskey = D
play-drm-content-learn-more = Daha fazla bilgi al
# Variables:
# $version (string) - Firefox version
update-application-version = Sürüm { $version } <a data-l10n-name="learn-more">Yeni neler var?</a>
update-history-2 =
    .label = Güncelleme geçmişini göster
    .accesskey = c
update-application-installation =
    .label = Kurulum
update-application-radio-group =
    .aria-label = Kurulum
update-application-auto-2 =
    .label = Güncellemeleri otomatik olarak yükle (Önerilir)
    .accesskey = ü
update-application-check-choose-2 =
    .label = Güncellemeleri denetle ama ne zaman yükleneceğini ben seçeceğim
    .accesskey = n
update-application-background-enabled =
    .label = { -brand-short-name } kapalıyken
    .accesskey = k
update-application-warning-cross-user-setting-2 =
    .message = Bu ayar, bu { -brand-short-name } kurulumunu kullanan tüm Windows hesaplarına ve { -brand-short-name } profillerine uygulanacaktır.
update-application-suppress-prompts-2 =
    .label = Daha az güncelleme hatırlatıcısı göster
    .accesskey = D
update-setting-write-failure-title2 = Güncelleme ayarları kaydedilirken hata oluştu
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } bir hatayla karşılaştı ve bu değişikliği kaydetmedi. Bu güncelleme ayarının değiştirilmesi için aşağıdaki dosyaya yazma izninizin olması gerekir. Siz veya sistem yöneticiniz bu dosya için Kullanıcılar grubuna tam denetim vererek hatayı giderebilirsiniz.
    
    Dosyaya yazılamadı: { $path }
update-in-progress-title = Güncelleme sürüyor
update-in-progress-message = { -brand-short-name } bu güncellemeyi uygulamaya devam etsin mi?
update-in-progress-ok-button = &Vazgeç
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Devam et

## About Firefox

about-firefox-header =
    .heading = { -brand-short-name } hakkında

## Firefox updates

update-application-heading =
    .description = Güncellemeler { -brand-short-name } tarayıcınızın hızını, kararlılığını ve güvenliğini artırır.
    .label = { -brand-short-name } güncellemeleri
update-application-suppress-prompts-heading =
    .label = Bildirimler
update-application-updates-managed-by-os =
    .message = Güncellemeler işletim sisteminiz tarafından yönetiliyor

## Firefox support

support-application-heading =
    .description = Sorunları giderin ve fikirlerinizi topluluğumuzla paylaşın.
    .label = { -brand-short-name } desteği
support-get-help =
    .label = Yardım alın
support-share-ideas =
    .label = Fikirlerinizi ve görüşlerinizi paylaşın

## General Section - Performance

performance-settings-learn-more = Daha fazla bilgi al
performance-allow-hw-accel =
    .label = Mümkün olduğunda donanım ivmelenmesini kullan
    .accesskey = d
performance-limit-content-process-option = İçerik işlemi sınırı
    .accesskey = L
performance-limit-content-process-enabled-desc = Daha fazla içerik işlemine izin verdiğinizde, çok sayıda sekme açıkken performans artar ama daha fazla bellek kullanılır.
performance-limit-content-process-blocked-desc = İçerik işlemi sayısını değiştirmek yalnızca çok işlemli { -brand-short-name } ile mümkündür. <a data-l10n-name="learn-more">Çok işlemin etkin olup olmadığını kontrol etmeyi öğrenin</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (varsayılan)
performance-group =
    .label = Performans
performance-use-recommended-settings-checkbox-2 =
    .description = Bu ayarlar bilgisayarınızın donanımına ve işletim sistemine göre seçilmiştir.
    .label = Önerilen performans ayarlarını kullan
    .accesskey = Ö

## Accessibility page

browsing-use-autoscroll =
    .label = Otomatik kaydırmayı kullan
    .accesskey = a
keyboard-and-scrolling-group =
    .label = Klavye ile gezinti ve kaydırma
motion-and-link-group =
    .label = Hareket ve bağlantı stili
browsing-use-smooth-scrolling =
    .label = Akıcı kaydırmayı kullan
    .accesskey = c
browsing-gtk-use-non-overlay-scrollbars =
    .label = Kaydırma çubuklarını her zaman göster
    .accesskey = u
browsing-always-underline-links =
    .label = Bağlantıların altını her zaman çiz
    .accesskey = h
browsing-use-onscreen-keyboard =
    .label = Gerektiğinde dokunmatik klavyeyi göster
    .accesskey = d
browsing-use-cursor-navigation =
    .label = Sayfaların içinde hareket etmek için her zaman ok tuşlarını kullan
    .accesskey = S
browsing-use-full-keyboard-navigation =
    .label = Form alanları ve bağlantılar arasında geçiş yapmak için sekme tuşunu kullan
    .accesskey = F
browsing-search-on-start-typing =
    .label = Yazmaya başladığımda metin araması yap
    .accesskey = z
settings-keyboard-shortcuts-group =
    .description = { -brand-short-name } tarayıcısında gezinmeyi ve işlem yapmayı kolaylaştırın.
    .label = Klavye kısayolları
settings-keyboard-shortcuts-customkeys-link =
    .label = Klavye kısayollarını özelleştir
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Adres çubuğu ayarlarını “Arama” sayfasından özelleştir
settings-media-group =
    .label = Ortam
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Görüntü içinde görüntüyü kullan
    .accesskey = G
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Sekme değiştirdiğimde videoları görüntü içinde görüntü modunda oynatmaya devam et
    .accesskey = k
browsing-media-control =
    .label = Medya oynatmayı klavye, kulaklık veya sanal arayüzle yönet
    .accesskey = M
recommendations-group =
    .label = Öneriler
browsing-cfr-recommendations =
    .label = Gezinirken yeni uzantılar öner
    .accesskey = e
browsing-cfr-features =
    .label = Gezinirken yeni özellikler öner
    .accesskey = n
browsing-group =
    .label = Gezinti
preferences-accessibility-header =
    .heading = Erişilebilirlik
preferences-default-zoom-select =
    .aria-label = Varsayılan yakınlaştırma
preferences-fonts-family =
    .label = Yazı tipi ailesi
    .accesskey = Y
preferences-fonts-size =
    .label = Yazı tipi boyutu
    .accesskey = b
preferences-fonts-advanced-settings =
    .label = Gelişmiş ayarlar
    .accesskey = G

## General Section - Proxy

network-proxy-group2 =
    .description = { -brand-short-name } tarayıcısının internete nasıl bağlanacağını yapılandırın.
    .label = Vekil sunucu ayarları
network-proxy-connection-settings2 =
    .description = Bu ayarları değiştirmeniz bağlantı sorunlarına yol açabilir
    .label = Vekil sunucuyu yapılandır
    .accesskey = V

## Home Section

home-new-windows-tabs-header = Yeni pencere ve sekmeler
home-new-windows-tabs-description2 = Giriş sayfanızı, yeni pencereleri ve yeni sekmeleri açtığınızda ne görmek istediğinizi seçin.
home-section =
    .heading = Giriş sayfası ve başlangıç

## Home Section - Default Browser

home-default-browser-title =
    .label = Varsayılan tarayıcı
is-default-browser-2 =
    .message = { -brand-short-name } varsayılan tarayıcınız. İyi bir seçim yaptınız.
is-not-default-browser-2 =
    .message = { -brand-short-name } varsayılan tarayıcınız değil.
set-as-my-default-browser-2 =
    .label = Varsayılan yap
    .accesskey = a

## Custom Homepage subpage

home-homepage-mode-label = Giriş sayfası ve yeni pencereler
home-newtabs-mode-label = Yeni sekmeler
home-restore-defaults =
    .label = Varsayılanları geri yükle
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Varsayılan)
home-mode-choice-custom =
    .label = Özel adresler…
home-mode-choice-blank =
    .label = Boş sayfa
home-homepage-custom-url =
    .placeholder = Adres yapıştır…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Uzantıyı yönet
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Geçerli sayfayı kullan
           *[other] Geçerli sayfaları kullan
        }
    .accesskey = s
choose-bookmark =
    .label = Yer imi kullan…
    .accesskey = m
home-homepage-title =
    .label = Giriş sayfası
home-homepage-new-windows =
    .label = Yeni pencereler
home-homepage-new-tabs =
    .label = Yeni sekmeler
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Belirli bir site seç
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Web sitesi adres(ler)i
home-custom-homepage-list =
    .aria-label = Site adresleri
home-custom-homepage-address =
    .placeholder = Adres yazın
home-custom-homepage-address-button =
    .label = Adres ekle
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Henüz hiç site eklenmedi.
home-custom-homepage-delete-address-button =
    .aria-label = Adresi sil
    .title = Adresi sil
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Bununla değiştir:
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Şu anda açık olan sayfalar
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Yer imleri…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Uzantı ({ $extension })
home-custom-homepage-header = Özel giriş sayfası
home-custom-homepage-subpage =
    .heading = Özel giriş sayfası

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name } içerikleri
home-prefs-content-description2 = { -firefox-home-brand-name } ekranınızda görmek istediğiniz içerikleri seçin.
home-prefs-search-header =
    .label = Web araması
home-prefs-shortcuts-header =
    .label = Kısayollar
home-prefs-shortcuts-description = Kaydettiğiniz veya ziyaret ettiğiniz siteler
home-prefs-shortcuts-by-option-sponsored =
    .label = Sponsorlu kısayollar
home-prefs-recommended-by-header-generic =
    .label = Önerilen makaleler
home-prefs-recommended-by-description-generic = { -brand-product-name } ailesinin seçtiği harika içerikler
home-prefs-stories-header =
    .label = Haberler
home-prefs-stories-description = Etkinliğinize göre kişiselleştirilmiş haberler

##

home-prefs-recommended-by-learn-more = Nasıl çalışır?
home-prefs-recommended-by-option-sponsored-stories =
    .label = Sponsorlu haberler
home-prefs-highlights-option-visited-pages =
    .label = Ziyaret ettiğim sayfalar
home-prefs-highlights-options-bookmarks =
    .label = Yer imleri
home-prefs-highlights-option-most-recent-download =
    .label = Son indirme
home-prefs-recent-activity-header =
    .label = Son etkinlikler
home-prefs-recent-activity-description = Son kullanılan siteler ve içeriklerden bir seçki
home-prefs-weather-header =
    .label = Hava durumu
home-prefs-weather-description = Bugünkü hava durumu tahmini
home-prefs-weather-learn-more-link = Daha fazla bilgi al
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = { -brand-product-name } tarayıcısını destekleyin
home-prefs-mission-message = Sponsorlarımız daha iyi bir web inşa etme misyonumuzu destekliyor
home-prefs-mission-message-learn-more-link = Nasıl mı?
home-prefs-manage-topics-link = Konuları yönet
home-prefs-choose-wallpaper-link = Duvar kâğıdı seç
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } satır
           *[other] { $num } satır
        }

## Search Section

search-show-suggestions-option =
    .label = Arama önerilerini göster
    .accesskey = ö
search-show-suggestions-url-bar-option =
    .label = Adres çubuğu sonuçlarında arama önerilerini göster
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Adres çubuğu sonuçlarında arama önerilerini gezinti geçmişinden önce göster
search-show-suggestions-private-windows-2 =
    .label = Gizli pencerelerde arama önerileri
search-suggestions-cant-show-2 =
    .message = { -brand-short-name } tarayıcısını geçmişi hatırlamayacak şekilde ayarladığınız için konum çubuğu sonuçlarında arama önerileri gösterilmeyecektir.
addressbar-header-1 =
    .description = Adres çubuğunuzda hangi önerilerin gösterileceğini seçin
    .label = Adres çubuğu
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = { -brand-short-name } ve iş ortaklarımızdan gelen öneriler adres çubuğunuzda görünür.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Sonuç sayfalarındayken adres çubuğunda arama terimlerini göster
search-separate-default-engine-2 =
    .label = Gizli pencerelerde farklı bir varsayılan arama motoru kullan
    .accesskey = G
search-separate-default-engine-dropdown =
    .aria-label = Gizli pencerelerde varsayılan arama motoru
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Adres çubuğunda gezinme
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Odağı değiştirmek için tab tuşunu kullanırken sonuçlar menüsünü atla
search-suggestions-header-2 =
    .label = Arama motoru önerileri
search-one-click-header2 = Arama kısayolları
search-one-click-desc = Anahtar kelimeleri yazmaya başladığınızda adres çubuğunun ve arama çubuğunun altında görünecek alternatif arama motorlarını seçin.
search-one-click-header-3 =
    .description = Adres çubuğunda görünecek arama motorlarını ve kısayolları seçin.
    .label = Ek arama motorları
search-engine-list =
    .aria-label = Arama motorları ve kısayollar
update-search-engine-success =
    .message = Arama motoru başarıyla güncellendi
search-edit-engine-2 =
    .title = Arama motorunu düzenle
search-delete-engine =
    .title = Arama motorunu sil
search-enable-engine =
    .title = Arama motorunu etkinleştir
search-outlink-to-extensions-page =
    .title = Uzantılarda ve temalarda yönet
search-choose-engine-column =
    .label = Arama motoru
search-choose-keyword-column =
    .label = Anahtar kelime
search-restore-default =
    .label = Varsayılan arama motorlarını geri yükle
    .accesskey = V
search-remove-engine =
    .label = Kaldır
    .accesskey = K
search-add-engine =
    .label = Ekle
    .accesskey = E
search-add-engine-2 =
    .label = Arama motoru ekle
    .accesskey = A
search-edit-engine =
    .label = Düzenle
    .accesskey = D
search-find-more-link = Daha fazla arama motoru bul
search-filtering-for-add-engine = Motor ekle
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Tekrarlanan Anahtar Kelime
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Şu anda “{ $name }” tarafından kullanılan bir anahtar kelime seçtiniz. Lütfen başka bir şey seçin.
search-keyword-warning-bookmark = Şu anda bir yer imi tarafından kullanılan bir anahtar kelime seçtiniz. Lütfen başka bir şey seçin.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = “{ $name }” adında bir arama motoru zaten var. Lütfen başka bir ad seçin.
remove-engine-confirmation = Bu arama motorunu silmek istediğinizden emin misiniz?
remove-engine-remove = Sil
remove-addon-engine-alert = Bu arama motorunu silebilmek için ilgili eklentiyi kaldırın.
search-engine-group =
    .label = Varsayılan arama motoru
search-default-engine =
    .aria-label = Varsayılan arama motoru
# Header for the search section ("search" is a noun).
search-section =
    .heading = Arama

## Containers Section

containers-section-header2 =
    .heading = Kapsayıcı ayarları
containers-card-header2 =
    .description = Aynı sitede farklı hesaplar kullanmak ve siteler arası takibi sınırlamak için kapsayıcıları kullanarak çerezleri ayırabilirsiniz.
    .label = Kapsayıcılar
containers-add-button2 =
    .label = Yeni kapsayıcı ekle
    .accesskey = Y
containers-list =
    .aria-label = Kapsayıcılar
containers-new-tab-check3 =
    .label = Her yeni sekme için kapsayıcı seç
    .accesskey = H
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Harici uygulamalardan açılan bağlantılar için kapsayıcı kullanma
    .accesskey = a
containers-new-tab-check2 =
    .description = “Yeni sekme aç” düğmesine her bastığınızda kapsayıcılar menüsü açılacaktır.
    .label = Her yeni sekme için kapsayıcı seç
    .accesskey = H
containers-settings-button2 =
    .title = Ayarlar
containers-remove-button3 =
    .title = Sil
containers-sites-card-header =
    .description = Özel kapsayıcı seçtiğiniz siteleri her açtığınızda { -brand-short-name } bu kapsayıcıyı kullanır.
    .label = Siteye özel kapsayıcılar
containers-sites-add-button =
    .label = Web sitesi ekle
    .accesskey = W
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = { $site } kapsayıcısı
containers-site-remove-button =
    .title = Sil
containers-remove-button2 =
    .title = Sil

## Account and sync

sync-group-label =
    .label = Eşitleme
account-group-label2 =
    .label = Hesap
account-disabled-group =
    .description = Hesap ayarları kullanılamıyor.
    .label = Hesap
account-placeholder2 =
    .description = Giriş yaparak verilerinizi gizli ve şifrelenmiş halde tutarken { -brand-short-name } kullandığınız her yerden onlara erişebilirsiniz.
    .label = Giriş yapmadınız
account-sync-section =
    .heading = Hesap ve eşitleme
pane-account-sync-title2 = Hesap ve eşitleme
    .title = Hesap ve eşitleme

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Web’inizi yanınızda taşıyın
sync-signedout-description2 = Yer imlerinizi, geçmişinizi, sekmelerinizi, parolalarınızı, eklentilerinizi ve ayarlarınızı tüm cihazlarınız arasında eşitleyin.
sync-signedout-account-signin3 =
    .label = Eşitlemek için giriş yap…
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = Eşitlemeyi başlatmak için hesabınıza giriş yapın
    .accesskey = i
sync-signedout-account-short =
    .label = Giriş yap
    .accesskey = G
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Mobil cihazınızla eşitleme yapmak isterseniz <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> veya <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> için Firefox’u indirin.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Profil resmini değiştir
    .tooltiptext = Profil resmini değiştir
sync-profile-picture-account-problem =
    .alt = Hesap profil resmi
fxa-login-rejected-warning =
    .alt = Uyarı
sync-sign-out =
    .label = Çıkış yap…
    .accesskey = k
sync-sign-out2 =
    .label = Çıkış yap
    .accesskey = k
sync-manage-account = Hesabı yönet
    .accesskey = H
sync-manage-account2 =
    .label = Hesabı yönet
    .accesskey = H

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } doğrulanmamış.
sync-signedin-unverified2 =
    .description = Hesabınızı onaylayıp etkinleştirmek için gelen kutunuzu kontrol edin.
    .label = { $email } henüz onaylanmadı
sync-signedin-login-failure = Yeniden { $email } hesabınıza bağlanmak için lütfen giriş yapın
sync-signedin-login-failure2 =
    .description = Yeniden bağlanıp verilerinizi eşitlemeye başlamak için tekrar giriş yapın.
    .label = { $email } hesabından çıkış yaptınız
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Hesabı doğrula
    .accesskey = H
sync-remove-account =
    .label = Hesabı kaldır
    .accesskey = H
sync-sign-in =
    .label = Giriş yap
    .accesskey = G

## Sync section - enabling or disabling sync.

prefs-syncing-on = Eşitleme: AÇIK
prefs-syncing-on-2 =
    .label = Eşitleme AÇIK
prefs-syncing-off = Eşitleme: KAPALI
prefs-syncing-off-2 =
    .description = Yer imlerinize, parolalarınıza, geçmişinize ve diğer verilerinize başka cihazlardan erişmek isterseniz eşitlemeyi açın.
    .label = Eşitleme KAPALI
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Yer imlerinizi, parolalarınızı, geçmişinizi ve diğer verilerinizi bu cihaza almak için eşitlemeyi açın.
    .label = Eşitleme KAPALI
prefs-sync-turn-on-syncing =
    .label = Eşitlemeyi başlat…
    .accesskey = E
prefs-sync-turn-on-syncing-2 =
    .label = Eşitlemeyi başlat
    .accesskey = E
prefs-sync-offer-setup-label2 = Yer imlerinizi, geçmişinizi, sekmelerinizi, parolalarınızı, eklentilerinizi ve ayarlarınızı tüm cihazlarınız arasında eşitleyin.
prefs-sync-now-button =
    .label = Şimdi eşitle
    .accesskey = m
prefs-sync-now-button-2 =
    .label = Şimdi eşitle
    .accesskey = m
prefs-syncing-button =
    .label = Eşitleniyor…
prefs-syncing-button-2 =
    .label = Eşitleniyor…
    .title = Şimdi eşitle
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Eşitleme tercihleriniz artık yalnızca bu cihaz için geçerli.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Aşağıdaki öğeler tüm bağlı cihazlarınız arasında eşitleniyor:
sync-syncing-across-devices-heading-2 = Cihazlar arasında eşitlenen veriler
sync-syncing-across-devices-heading-3 = Bu cihazda eşitlenen veriler
sync-syncing-across-devices-empty-state2 =
    .description = Henüz hiçbir şeyi eşitlemediniz. Verilerinizi tüm cihazlarınıza taşımak için eşitlemeyi başlatın.
    .label = Eşitlenen verileri yönet
sync-syncing-across-devices-empty-state3 =
    .description = Henüz hiçbir şeyi eşitlemiyorsunuz. Bu cihazda nelerin eşitleneceğini seçin.
    .label = Eşitlenen verileri yönet
sync-currently-syncing-bookmarks = Yer imleri
sync-currently-syncing-history = Geçmiş
sync-currently-syncing-tabs = Açık sekmeler
sync-currently-syncing-passwords = Parolalar
sync-currently-syncing-addresses = Adresler
sync-currently-syncing-payment-methods = Ödeme yöntemleri
sync-currently-syncing-addons = Eklentiler
sync-currently-syncing-settings = Ayarlar
sync-manage-options =
    .label = Eşitlemeyi yönet…
    .accesskey = E
sync-manage-options-2 =
    .label = Eşitlenen verileri yönet
    .accesskey = E
settings-sync-disconnect-button =
    .label = Bağlantıyı kes

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Yer imleri
    .accesskey = m
sync-engine-history =
    .label = Geçmiş
    .accesskey = G
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Açık sekmeler
    .tooltiptext = Diğer cihazlarınızdaki açık sekmeler
    .accesskey = k
sync-engine-tabs =
    .label = Açık sekmeler
    .tooltiptext = Eşitlenen tüm cihazlarınızdaki açık sekmelerin listesi
    .accesskey = s
sync-engine-passwords =
    .label = Parolalar
    .tooltiptext = Kaydettiğiniz parolalar
    .accesskey = P
sync-engine-addresses2 =
    .label = Adresler
    .tooltiptext = { -brand-short-name } tarayıcısına kaydettiğiniz adresler
    .accesskey = d
sync-engine-payment-methods3 =
    .label = Ödeme yöntemleri
    .tooltiptext = Kaydettiğiniz ödeme yöntemleri
    .accesskey = Ö
sync-engine-addons2 =
    .label = Eklentiler
    .tooltiptext = { -brand-short-name } tarayıcısının bilgisayar sürümüne eklediğiniz uzantılar ve temalar
    .accesskey = E
sync-engine-settings2 =
    .label = Ayarlar
    .tooltiptext = Eşitlenebilen { -brand-short-name } ayarları
    .accesskey = A
sync-engine-addresses =
    .label = Adresler
    .tooltiptext = Kaydettiğiniz posta adresleri (yalnızca masaüstü)
    .accesskey = A
sync-engine-payment-methods2 =
    .label = Ödeme yöntemleri
    .tooltiptext = Adlar, kart numaraları ve son kullanma tarihleri
    .accesskey = n
sync-engine-addons =
    .label = Eklentiler
    .tooltiptext = Masaüstü Firefox uzantıları ve temaları
    .accesskey = t
sync-engine-settings =
    .label = Ayarlar
    .tooltiptext = Değiştirdiğiniz genel ayarlar, gizlilik ayarları ve güvenlik ayarları
    .accesskey = A
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Kaydet
    .buttonlabelextra2 = Bağlantıyı kes…
    .buttonaccesskeyaccept = K
    .buttonaccesskeyextra2 = B
    .style = min-width: 36em;
    .title = Bağlı tüm cihazlarınızda nelerin eşitleneceğini yönetin
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Kaydet
    .buttonlabelextra2 = Bağlantıyı kes…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Bu cihazda nelerin eşitleneceğini yönet

## The device name controls.

sync-device-name-header = Cihaz adı
sync-device-name-header-2 =
    .label = Cihaz adı
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Cihaz adı
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Cihaz adını değiştir
    .accesskey = C
sync-device-name-change =
    .label = Cihaz adını değiştir…
    .accesskey = C
sync-device-name-cancel =
    .label = İptal
    .accesskey = t
sync-device-name-save =
    .label = Kaydet
    .accesskey = K
sync-connect-another-device = Başka bir cihaz bağla
sync-connect-another-device-2 =
    .label = Başka bir cihaz bağla

## Privacy Section

privacy-header = Tarayıcı gizliliği

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Parolalar
    .searchkeywords = hesaplar
forms-passwords-header =
    .aria-label = Parolalar
    .label = Parolalar
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Parolaları kaydetmeyi öner
    .accesskey = P
forms-manage-password-exceptions =
    .label = Parola istisnalarını yönet
    .accesskey = r
forms-exceptions =
    .label = İstisnalar…
    .accesskey = s
forms-suggest-passwords =
    .label = Güçlü parola öner
    .accesskey = ü
forms-breach-alerts =
    .label = Veri ihlaline uğrayan sitelerdeki parolalarla ilgili uyarı göster
    .accesskey = V
forms-breach-alerts-learn-more-link = Daha fazla bilgi al
preferences-relay-integration-checkbox2 =
    .label = E-posta adresimi korumak için { -relay-brand-name } e-posta maskeleri öner
    .accesskey = r
relay-integration-learn-more-link = Daha fazla bilgi al
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Kullanıcı adı ve parolaları otomatik doldur
    .accesskey = d
forms-fill-usernames-and-passwords-2 =
    .label = Kullanıcı adlarını ve parolaları kaydedip otomatik doldur
    .accesskey = u
forms-saved-passwords =
    .label = Kayıtlı parolalar
    .accesskey = o
forms-saved-passwords-2 =
    .label = Kayıtlı parolaları yönet
    .accesskey = a
forms-saved-passwords-searchkeywords = Aşağıdaki sitelerin giriş bilgileri bilgisayarınızda kayıtlıdır
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Ek korumalar
forms-primary-pw-use =
    .label = Ana parola kullan
    .accesskey = n
forms-primary-pw-use-2 =
    .description = Kayıtlı parolalarınızı korumak için ekstra bir güvenlik katmanı ekler.
    .label = Ana parola kullan
    .accesskey = A
forms-primary-pw-set =
    .label = Ana parola belirle
forms-primary-pw-on-2 = Ana parola <strong>AÇIK</strong>
forms-primary-pw-on =
    .label = Ana parola AÇIK
forms-primary-pw-change-2 =
    .label = Ana parolayı değiştir
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Kapat
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Parolaları doldurmak ve yönetmek için cihazdan giriş yapmayı zorunlu tut
forms-os-reauth-2 =
    .label = Parolaları yönetmek için cihazdan giriş yapmayı zorunlu tut
forms-primary-pw-learn-more-link = Daha fazla bilgi al
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Ana parolayı değiştir…
    .accesskey = d
forms-primary-pw-change =
    .label = Ana parolayı değiştir…
    .accesskey = d
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Şu anda FIPS kipindesiniz. FIPS için boş olmayan bir ana parola gereklidir.
forms-master-pw-fips-desc = Parola değiştirme başarısız
forms-windows-sso =
    .label = Microsoft, iş ve okul hesapları için Windows çoklu oturum açmaya izin ver
forms-windows-sso-learn-more-link = Daha fazla bilgi al
forms-windows-sso-desc = Hesapları cihaz ayarlarınızdan yönetebilirsiniz
windows-passkey-settings-label = Geçiş anahtarlarını sistem ayarlarından yönetebilirsiniz
privacy-panel-settings-header =
    .description = İnternette bilgilerinizi koruma konusunda { -brand-short-name } size destek olabilir.
    .label = Gizlilik paneli ayarları
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = İhlal edilmiş site uyarılarını göster
    .accesskey = h

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Ana parola oluşturmak için Windows hesap bilgilerinizi girin. Bu sayede hesaplarınızı daha güvenli bir şekilde koruyabiliriz.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = ana parola oluşturma
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] ödeme yöntemi ayarlarını değiştirme
       *[other] { -brand-short-name }, ödeme yöntemi ayarlarını değiştirmeye çalışıyor. Buna izin vermek için cihazınızdan giriş yapın.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Ödeme yöntemleri
autofill-payment-methods-checkbox-message-2 =
    .label = Ödeme bilgilerini kaydet ve otomatik doldur
    .accesskey = Ö
autofill-payment-methods-manage-payments-title =
    .heading = Ödeme yöntemlerini yönet
autofill-payment-methods-manage-payments-button =
    .label = Ödeme yöntemlerini yönet
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Otomatik doldurma için cihazda oturum açmayı zorunlu kıl
    .accesskey = O
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Ödeme yöntemlerini otomatik doldurmak ve yönetmek için cihazdan giriş yapmayı zorunlu tut
    .accesskey = Ö
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Güvenlik kodlarını kaydet
    .accesskey = G
autofill-payment-methods-add-button = Yeni ödeme yöntemi ekle
payments-list-header =
    .label = Ödeme yöntemleri
payments-delete-payment-prompt-title = Bu ödeme yöntemi silinsin mi?
payments-delete-payment-prompt-confirm-button = Sil
payments-delete-payment-prompt-cancel-button = Vazgeç
payments-delete-payment-button-label =
    .aria-label = Sil
payments-edit-payment-button-label =
    .aria-label = Düzenle
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Hiç ödeme yöntemi eklenmedi
autofill-addresses-checkbox-message =
    .label = Adresleri kaydedip otomatik doldur
    .accesskey = A
autofill-addresses-manage-addresses-button =
    .label = Adresleri ve diğer bilgileri yönet
    .accesskey = d
addresses-list-header =
    .label = Adresler
addreses-delete-address-button-label =
    .aria-label = Sil
addreses-edit-address-button-label =
    .aria-label = Düzenle
addresses-delete-address-prompt-title = Bu adres silinsin mi?
addresses-delete-address-prompt-confirm-button = Sil
addresses-delete-address-prompt-cancel-button = Vazgeç
autofill-addresses-add-button = Yeni adres ekle
autofill-addresses-manage-addresses-title =
    .heading = Adresleri ve diğer bilgileri yönet
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Hiç adres eklenmedi
personal-info-group =
    .label = Kişisel bilgiler
autofill-personal-info-checkbox-message =
    .label = Kişisel bilgileri kaydet ve otomatik doldur
autofill-personal-info-manage-button =
    .label = Kişisel bilgileri yönet
passports-list-header =
    .label = Pasaportlar
passports-delete-passport-button-label =
    .aria-label = Sil
passports-edit-passport-button-label =
    .aria-label = Düzenle
passports-delete-passport-prompt-title = Bu pasaport silinsin mi?
passports-delete-passport-prompt-confirm-button = Sil
passports-delete-passport-prompt-cancel-button = Vazgeç
autofill-passports-add-button = Yeni pasaport ekle
autofill-personal-info-manage-title =
    .heading = Kişisel bilgileri yönet
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Hiç pasaport eklenmedi
pane-passwords-autofill-title2 = Parolalar ve otomatik doldurma
    .title = Parolalar ve otomatik doldurma
preferences-passwords-autofill-header =
    .heading = Parolalar ve otomatik doldurma
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adresler ve diğer bilgiler
payments-group =
    .label = Ödeme yöntemleri

## Privacy Section - History

history-remember-option-never2 =
    .description = Tüm pencereler gizli pencere gibi çalışır. Bu ayarı açtığınızda uzantılara da izin vermeniz gerekir.
    .label = Geçmişi asla hatırlama
history-remember-option-custom2 =
    .label = Geçmişi özelleştir
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } gezinti, indirme, form ve arama geçmişlerinizi hatırlayacak.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } Gizli Gezinti ile aynı ayarları kullanacak ve siz internette gezerken geçmişle ilgili hiçbir şeyi hatırlamayacak.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } gezinti, indirme, form ve arama geçmişleriniz için özel ayarlar kullanacak.
history-private-browsing-permanent =
    .label = Her zaman gizli gezinti kipini kullan
    .accesskey = m
history-remember-browser-option =
    .label = Gezinti ve indirme geçmişini hatırla
    .accesskey = T
history-remember-search-option =
    .label = Arama ve form geçmişini hatırla
    .accesskey = f
history-clear-on-close-option =
    .label = { -brand-short-name } kapatılınca geçmişi temizle
    .accesskey = e
history-clear-on-close-settings =
    .label = Ayarlar…
    .accesskey = A
history-shutdown-exceptions =
    .label = İstisnaları yönet
    .accesskey = t
history-clear-button =
    .label = Geçmişi temizle…
    .accesskey = G
history-header2 =
    .heading = Geçmiş
history-section-header =
    .description = { -brand-short-name } tarayıcısını kapattığınızda nelerin hatırlanacağını seçin.
    .label = Geçmiş
history-custom-section-header =
    .description = { -brand-short-name } tarayıcısını kapattığınızda tarayıcının neleri hatırlayacağını özelleştirin.
    .label = Gelişmiş ayarlar
history-custom-button =
    .label = { -brand-short-name } tarayıcınızın neleri hatırlayacağını seçin
history-group =
    .label = Geçmiş
history-mode-radio-group =
    .aria-label = Geçmiş
history-remember-option-all2 =
    .label = Geçmişi hatırla

## Privacy Section - Site Data

sitedata-total-size-calculating = Site verilerinin ve önbelleğin boyutu hesaplanıyor…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Web siteleri şu anda <strong>{ $value } { $unit }</strong> disk alanı kullanıyor.
sitedata-learn-more = Daha fazla bilgi al
sitedata-delete-on-close2 =
    .label = { -brand-short-name } tarayıcısını her kapattığımda çerezleri ve site verilerini temizle
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = { -brand-short-name }, geçmiş ayarlarınıza bağlı olarak, tarayıcıyı kapattığınızda oturumunuzdaki çerezleri ve site verilerini siler.
sitedata-delete-on-close-private-browsing4 =
    .heading = Geçmiş kaydedilmeyecek.
    .message = { -brand-short-name }, tarayıcıyı kapattığınızda oturumunuzdaki çerezleri ve site verilerini temizleyecektir.
sitedata-option-block-cross-site-trackers =
    .label = Siteler arası takip kodları
sitedata-option-block-cross-site-tracking-cookies =
    .label = Siteler arası takip çerezleri
sitedata-option-block-cross-site-cookies2 =
    .label = Siteler arası çerezleri izole et
sitedata-option-block-unvisited =
    .label = Ziyaret etmediğim sitelerden gelen çerezler
sitedata-option-block-all-cross-site-cookies =
    .label = Tüm siteler arası çerezler (Bazı siteler düzgün çalışmayabilir)
sitedata-option-block-all =
    .label = Tüm çerezler (Birçok site düzgün çalışmayabilir)
sitedata-clear2 =
    .label = Gezinti verilerini temizle
    .accesskey = G
sitedata-settings2 =
    .label = Gezinti verilerini yönet
    .accesskey = z
sitedata-cookies-exceptions =
    .label = İstisnaları yönet…
    .accesskey = İ
sitedata-cookies-exceptions2 =
    .description = Hangi sitelerin çerezleri ve site verilerini her zaman kullanabileceğini veya hiçbir zaman kullanamayacağını belirleyebilirsiniz.
    .label = İstisnaları yönet
    .accesskey = s
sitedata-heading =
    .description = Çerezleri, geçmişi, önbelleği, site verilerini ve diğer verileri yönetin.
    .label = Gezinti verileri
sitedata-settings3 =
    .label = Belirli sitelerin verilerini temizle
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Belli sitelerin çerezlere ve site verilerine nasıl davranacağını seçin.
    .label = İstisnaları yönet
    .accesskey = t
cookies-site-data-group =
    .label = Çerezler ve site verileri

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Çerez bildirimi engelleyici
cookie-banner-blocker-description = Siteler gizli gezinti modunda çerezleri kullanıp kullanamayacağını sorduğunda { -brand-short-name } bu istekleri otomatik olarak reddeder. Yalnızca desteklenen sitelerde çalışır.
cookie-banner-learn-more = Daha fazla bilgi al
cookie-banner-blocker-checkbox-label =
    .label = Çerez bildirimlerini otomatik olarak reddet

## Search Section

addressbar-locbar-history-option =
    .label = Gezinti geçmişi
    .accesskey = G
addressbar-locbar-bookmarks-option =
    .label = Yer imleri
    .accesskey = Y
addressbar-locbar-clipboard-option =
    .label = Pano
    .accesskey = P
addressbar-locbar-openpage-option =
    .label = Açık sekmeler
    .accesskey = s
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Kısayollar
    .accesskey = K
addressbar-locbar-topsites-option =
    .label = Sık kullanılanlar
    .accesskey = S
addressbar-locbar-engines-option-1 =
    .label = Kullanabileceğim arama motorlarını öner
    .accesskey = u
addressbar-locbar-quickactions-option =
    .label = Hızlı eylemler
    .accesskey = H
addressbar-locbar-showrecentsearches-option-2 =
    .label = Son aramalar
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Arama trendi önerileri
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Aramanızla ilgili web sitesi önerileri alın.
    .label = { -brand-short-name } önerileri
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Ara sıra görünecek sponsorlu önerilerle { -brand-short-name } tarayıcınızı destekleyin.
    .label = Sponsorlardan öneriler
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Yazarken Mozilla’dan öneriler al
addressbar-dismissed-suggestions-label-2 =
    .description = Sponsorlardan ve { -brand-short-name } tarayıcısından gelen kapatılmış önerileri geri getir.
    .label = Kapatılan öneriler
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Önerileri geri yükle

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Gelişmiş izlenme koruması
content-blocking-section-top-level-description = Takip kodları, gezinti alışkanlıklarınız ve ilgi alanlarınız hakkında bilgi toplamak için internette sizi takip eder. { -brand-short-name } bu takip kodlarının ve diğer kötü amaçlı betiklerin çoğunu engeller.
content-blocking-learn-more = Daha fazla bilgi al
content-blocking-fpi-incompatibility-warning = First Party Isolation (FPI) özelliğini kullanıyorsunuz. Bu özellik, bazı { -brand-short-name } çerez ayarlarını geçersiz kılar.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Resist Fingerprinting (RFP) özelliğini kullanıyorsunuz. { -brand-short-name } tarayıcısının bazı parmak izi koruma ayarlarını değiştiren bu özellik bazı sitelerin bozulmasına yol açabilir.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standart
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Sıkı
    .accesskey = S
enhanced-tracking-protection-setting-custom =
    .label = Özel
    .accesskey = Ö

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Dengeli koruma ve performans. Sayfalar normal şekilde yüklenir.
content-blocking-etp-strict-desc = Daha güçlü koruma, ama bazı siteler ve içerikler düzgün çalışmayabilir.
content-blocking-etp-custom-desc = Hangi takip kodlarının ve betiklerin engelleneceğini seçin.
content-blocking-etp-blocking-desc = { -brand-short-name } aşağıdakileri engeller:
content-blocking-private-windows = Gizli pencerelerde takip amaçlı içerikler
content-blocking-cross-site-cookies-in-all-windows2 = Tüm pencerelerde siteler arası çerezler
content-blocking-cross-site-tracking-cookies = Siteler arası takip çerezleri
content-blocking-all-cross-site-cookies-private-windows = Gizli pencerelerde siteler arası çerezler
content-blocking-isolate-cross-site-cookies = Siteler arası çerezleri izole et
content-blocking-social-media-trackers = Sosyal medya takip kodları
content-blocking-all-cookies = Tüm çerezler
content-blocking-unvisited-cookies = Ziyaret etmediğim sitelerden gelen çerezler
content-blocking-all-windows-tracking-content = Tüm pencerelerde takip amaçlı içerikler
content-blocking-all-cross-site-cookies = Tüm siteler arası çerezler
content-blocking-cryptominers = Kripto madencileri
content-blocking-fingerprinters = Parmak izi toplayıcılar
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Bilinen ve şüpheli parmak izi toplayıcılar
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Komple çerez koruması, çerezleri sadece bulunduğunuz sitenin kullanabileceği şekilde sınırlar. Bu sayede çerezler hangi sitelerde gezindiğinizi izlemek için kullanılamaz.
content-blocking-etp-standard-tcp-rollout-learn-more = Daha fazla bilgi al
content-blocking-etp-standard-tcp-title = Şimdiye kadarki en güçlü gizlilik özelliğimiz olan komple çerez korumasını içerir
content-blocking-warning-title-2 = Sıkı izlenme koruması bazı siteleri bozabilir
content-blocking-warning-title-custom = Özel izlenme koruması bazı siteleri bozabilir
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name }, site özelliklerinin ve içeriklerinin bozulma ihtimalini azaltmak için “Site sorunlarını düzelt” ayarlarını kullanmanızı önerir. Bir site bozuk görünüyorsa o sitenin tüm içeriğini yüklemek için izlenme korumasını kapatmayı deneyin.
content-blocking-warning-learn-how = Nasıl yapılacağını öğrenin
content-blocking-baseline-exceptions-3 =
    .description = Yalnızca takip kodu içerebilecek temel öğelerin engelini kaldırarak sitelerin ve özelliklerin yüklenmesine yardımcı olur. En yaygın sorunları kapsar.
    .label = Önemli site sorunlarını düzelt (önerilir)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Takip kodu içerebilecek öğelerin engelini kaldırarak, makalelerdeki veya yorum bölümlerindeki videolar gibi öğeleri geri yükler. Bu işlem site sorunlarını azaltabilir ama daha az koruma sağlar. Büyük sorunlara yönelik düzeltmelerle birlikte kullanılmalıdır.
    .label = Küçük site sorunlarını düzelt
content-blocking-baseline-uncheck-warning-dialog-title = Düzeltmeleri kapatmak istediğinizden emin misiniz?
content-blocking-baseline-uncheck-warning-dialog-body = Bu ayar en yaygın site sorunlarını giderir. Bu ayarı kapatırsanız bazı siteler çalışmayabilir ve { -brand-short-name } bu sorunları gidermenize yardımcı olamaz.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Düzeltmeleri kapat
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Düzeltmeleri açık tut
content-blocking-reload-description = Bu değişiklikleri uygulamak için sekmelerinizi tazelemeniz gerekiyor.
content-blocking-reload-tabs-button =
    .label = Sekmeleri tazele
    .accesskey = S
content-blocking-tracking-content-label =
    .label = Takip amaçlı içerikler
    .accesskey = T
content-blocking-tracking-protection-option-all-windows =
    .label = Tüm pencerelerde
    .accesskey = m
content-blocking-option-private =
    .label = Yalnızca gizli pencerelerde
    .accesskey = z
content-blocking-cookies-label =
    .label = Çerezler
    .accesskey = e
content-blocking-expand-section =
    .tooltiptext = Daha fazla bilgi
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Kripto madencileri
    .accesskey = m
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Bilinen parmak izi toplayıcılar
    .accesskey = B
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Şüpheli parmak izi toplayıcılar
    .accesskey = Ş

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = İstisnaları yönet…
    .accesskey = n

## Privacy Section - Permissions

permissions-notification-pause =
    .label = { -brand-short-name } yeniden başlatılana dek bildirimleri duraklat
    .accesskey = b
permissions-autoplay2 =
    .label = Otomatik oynatma
permissions-block-popups2 =
    .label = Açılır pencereleri ve üçüncü taraf yönlendirmelerini engelle
    .accesskey = A
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Açılır pencere açabilecek ve üçüncü taraf  yönlendirmeleri kullanabilecek siteleri ekleyin.
    .label = İstisnaları yönet
    .searchkeywords = popups
    .accesskey = s
permissions-addon-install-warning3 =
    .label = Siteler uzantı yüklemeye çalıştığında uyarı göster
    .accesskey = z
permissions-addon-exceptions2 =
    .label = Uzantı yükleyebilecek siteleri seç
    .accesskey = U
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Sitelerin uygulama bağlantılarını açmayı istemesine izin ver.
    .accesskey = S
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Engellenen siteleri yönet
    .accesskey = E
permissions-location2 =
    .label = Konum
permissions-localhost2 =
    .label = Cihaz uygulamaları ve hizmetleri
permissions-local-network2 =
    .label = Yerel ağ cihazları
permissions-xr2 =
    .label = Sanal gerçeklik
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Hoparlör
permissions-notification2 =
    .label = Bildirimler
permissions-header3 =
    .description = Sitelerin erişebileceği, yönetebileceği ve tetikleyebileceği şeyleri yönetin.
    .label = İzinler
permissions-data-section =
    .heading = İzinler ve veriler
pane-permissions-data-title2 = İzinler ve veriler
    .title = İzinler ve veriler
notifications-section-header =
    .heading = Bildirimler
notifications-entry-card-header =
    .description = Hangi sitelerin bildirim gönderebileceğini ve bu uyarıların nasıl görüneceğini seçin.
    .label = Bildirimler
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } web sitesi
           *[other] { $count } web sitesi
        }
    .label = Bildirim ayarlarını yönet
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Web sitesi bildirim ayarlarını yönet
notifications-website-card-header =
    .description = Web sitelerinin nasıl bildirim gönderebileceğini seçin.
    .label = Web sitesi bildirimleri
notifications-filter =
    .placeholder = Web sitelerinde ara
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Web sitesi
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Bildirimlere izin ver
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Web siteleri
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Her zaman
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = İzin ver
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Asla
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Hiç web sitesi bildirimi eklenmedi.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Aramanızla eşleşen hiçbir web sitesi bildirimi bulunamadı.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Bu değişikliğin yedeklerinize dahil edildiğinden emin olmak için her profili açıp Ayarlar menüsünden “Şimdi yedekle”yi seçin.
nimbus-rollouts =
    .description = Değişiklikler uzaktan uygulanacaktır.
    .label = { -brand-short-name } tarayıcısının güncellemeler arasında özellikleri, performansı ve kararlılığı iyileştirmesine izin ver
addon-recommendations3 =
    .description = Gezinti deneyiminizi geliştirmek için uzantı önerileri alın.
    .label = Kişiselleştirilmiş uzantı önerilerine izin ver
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Bu sürümün yapılandırmasında veri raporlama devre dışı bırakılmış.
collection-backlogged-crash-reports2 =
    .label = Çökme raporlarını otomatik olarak gönder
    .accesskey = m
collection-backlogged-crash-reports-description = Bu sayede { -vendor-short-name }, tarayıcıyla ilgili sorunları tanılayıp düzeltebilir. Raporlar kişisel veya hassas veriler içerebilir.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Aynı ayarlar, yeni görünüm!
    .message = Bu sayfada gezinmeyi ve keşfetmeyi kolaylaştırmak için sayfayı yeniden düzenledik. Kişisel ayarlarınız değişmedi ve her şey hâlâ burada. İpucu: Aradığınız şeyi anında bulmak için arama çubuğunu kullanabilirsiniz.
settings-redesign-promo-dismiss-button =
    .label = Anladım
privacy-segmentation-section-header = Gezintinizi iyileştiren yeni özellikler
privacy-segmentation-section-description = Size daha kişisel bir deneyim sunmak için verilerinizi kullanan özellikler sunduğumuzda:
privacy-segmentation-radio-off =
    .label = { -brand-product-name } önerilerini kullan
privacy-segmentation-radio-on =
    .label = Ayrıntılı bilgileri göster
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Size tercih hakkı sunmaya ve { -brand-product-name } tarayıcısını tüm kullanıcılarımız için iyileştirmemizi sağlayacak minimum miktarda veri toplamaya özen gösteriyoruz.
    .label = { -brand-short-name } veri toplama ve kullanma izinleri
    .searchkeywords = telemetri
data-collection-link = Gizlilik bildirimini görüntüle
data-collection-preferences-across-profiles =
    .message = Bu ayarlar bu cihazdaki tüm { -brand-product-name } profilleri için geçerlidir.
data-collection-profiles-link = Tüm profilleri göster
data-collection-health-report-telemetry-disabled =
    .message = Artık { -vendor-short-name }’nın teknik veri ve etkileşim verisi toplamasına izin vermiyorsunuz. Eski verilerinizin hepsi 30 gün içinde silinecektir.
data-collection-health-report =
    .description = Bu, { -brand-product-name } tarayıcısının özelliklerini, performansını ve kararlılığını geliştirmemize yardımcı olur.
    .label = Teknik verileri ve etkileşim verilerini { -vendor-short-name }’ya gönder
    .accesskey = r
data-collection-health-report-disabled =
    .description = Bu sürümün yapılandırmasında veri raporlama devre dışı bırakılmış.
    .label = Teknik verileri ve etkileşim verilerini { -vendor-short-name }’ya gönder
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } bazı özellikleri test edecek kullanıcıları rastgele seçer. Böylece tarayıcının kalitesini herkes için artırabiliriz.
    .label = { -brand-short-name } tarayıcısının özelliklerle ilgili araştırmalar yürütmesine izin ver
data-collection-studies-link =
    .label = { -brand-short-name } araştırmalarını göster
data-collection-backlogged-crash-reports =
    .description = Bu sayede { -vendor-short-name }, tarayıcıyla ilgili sorunları tanılayıp düzeltebilir. Raporlar kişisel veya hassas veriler içerebilir.
    .label = Çökme raporlarını otomatik olarak gönder
    .accesskey = ö
data-collection-usage-ping =
    .description = Bu sayede { -vendor-short-name } aktif kullanıcı sayısını tahmin edebilir.
    .label = Günlük kullanım ping’ini { -vendor-short-name }’ya gönder
    .accesskey = n

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Güvenlik
browsing-protection-group2 =
    .description = Tehlikeli siteler ve indirmeler verilerinizi ve cihazınızı riske atabilir. { -brand-short-name } bunları otomatik olarak engeller, riskli veya istenmeyen yazılımlara karşı sizi uyarır.
    .label = Aldatıcı içerik ve tehlikeli yazılım koruması
security-enable-safe-browsing =
    .label = Tehlikeli ve aldatıcı içerikleri engelle
    .accesskey = T
security-enable-safe-browsing-link = Daha fazla bilgi al
security-safe-browsing-warning =
    .message = Bu ayarı kapatırsanız dolandırıcılığa, kötü amaçlı sitelere ve tehlikeli indirmelere karşı korumanız zayıflar.
security-block-downloads =
    .label = Tehlikeli indirmeleri engelle
    .accesskey = i
security-block-uncommon-software =
    .label = İstenmeyen ve bilinmeyen yazılımlar hakkında beni uyar
    .accesskey = b

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = { -brand-short-name } yüklediğim üçüncü taraf kök sertifikalarına otomatik olarak güvenebilsin
    .accesskey = t
certs-devices-enable-fips = FIPS’i etkinleştir
space-alert-over-5gb-settings-button =
    .label = Ayarları aç
    .accesskey = A
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } tarafından kullanılabilen disk alanı azaldı.</strong> Site içerikleri düzgün görüntülenemeyebilir. Depolanan verileri Ayarlar > Gizlilik ve Güvenlik > Çerezler ve site verileri kısmından temizleyebilirsiniz.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } tarafından kullanılabilen disk alanı azaldı.</strong> Site içerikleri düzgün görüntülenemeyebilir. Daha iyi bir gezinti deneyimi için disk kullanımınızı iyileştirmek isterseniz “Daha fazla bilgi al” sayfasını ziyaret edin.
certs-description3 =
    .description = { -brand-short-name } tarayıcısının güvenli bağlantıları doğrulamak için kullandığı sertifikaları yapılandırın.
    .label = Sertifikalar
certs-view2 =
    .label = Sertifikaları yönet
    .accesskey = e
certs-devices2 =
    .label = Güvenlik aygıtlarını yönet
    .accesskey = G

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Yalnızca HTTPS modu nasıl çalışır?
httpsonly-radio-enabled =
    .label = Yalnızca HTTPS modunu tüm pencerelerde etkinleştir
httpsonly-radio-enabled-pbm =
    .label = Yalnızca HTTPS modunu yalnızca gizli pencerelerde etkinleştir
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } yine de bazı bağlantıları HTTPS’e yükseltebilir
    .label = Yalnızca HTTPS modunu etkinleştirme
httpsonly-group =
    .description = Web sitelerine yalnızca güvenli bağlantı kurulmasına izin verir. { -brand-short-name } güvensiz bir bağlantı kurmadan önce size sorar.
    .label = Yalnızca HTTPS modu
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = HTTPS üzerinden DNS
dns-over-https-group2 =
    .description = HTTPS Üzerinden Alan Adı Sistemi (DoH), site sorgularını şifreleyerek internet sağlayıcınızın ve başkalarının hangi siteleri ziyaret edeceğinizi görmesini zorlaştırır.
    .label = HTTPS üzerinden DNS
preferences-doh-description2 = HTTPS Üzerinden Alan Adı Sistemi (DNS), alan adı isteklerinizi şifreli bir bağlantı üzerinden göndererek güvenli bir DNS sağlar. Böylece hangi web sitelerine eriştiğinizi başkalarının görmesi zorlaştır.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Durum: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Sağlayıcı: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Geçersiz URL
preferences-doh-steering-status = Yerel sağlayıcı kullanılıyor
preferences-doh-status-active = Etkin
preferences-doh-status-disabled = Kapalı
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Etkin değil ({ $reason })
preferences-doh-group-message2 = HTTPS üzerinden DNS’i etkinleştir:
preferences-doh-radio-group =
    .aria-label = HTTPS üzerinden DNS’i etkinleştir:
preferences-doh-expand-section =
    .tooltiptext = Daha fazla bilgi
preferences-doh-setting-default =
    .label = Varsayılan koruma
    .accesskey = V
preferences-doh-default-desc = Gizliliğinizi korumak için ne zaman güvenli DNS kullanılacağına { -brand-short-name } karar verir.
preferences-doh-default-detailed-desc-1 = Desteklenen bölgelerde güvenli DNS kullanılır
preferences-doh-default-detailed-desc-2 = Güvenli DNS sağlayıcınızda sorun yaşanırsa varsayılan DNS çözümleyiciniz kullanılır
preferences-doh-default-detailed-desc-3 = Mümkünse yerel bir sağlayıcı kullanılır
preferences-doh-default-detailed-desc-4 = VPN, ebeveyn denetimleri veya kurumsal ilkeler etkinse güvenli DNS kapanır
preferences-doh-default-detailed-desc-5 = Ağınız { -brand-short-name } tarayıcısına güvenli DNS kullanmama isteği gönderirse güvenli DNS kapanır
preferences-doh-setting-enabled =
    .label = Artırılmış koruma
    .accesskey = A
preferences-doh-enabled-desc = Güvenli DNS’in ne zaman kullanılacağını siz belirler ve sağlayıcınızı siz seçersiniz.
preferences-doh-enabled-detailed-desc-1 = Seçtiğiniz sağlayıcı kullanılır
preferences-doh-enabled-detailed-desc-2 = Yalnızca güvenli DNS sağlayıcınızda sorun yaşanırsa varsayılan DNS çözümleyiciniz kullanılır
preferences-doh-setting-strict =
    .label = Maksimum koruma
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } her zaman güvenli DNS kullanır. Sistem DNS’inizi kullanmadan önce bir güvenlik uyarısı gösterir.
preferences-doh-strict-detailed-desc-1 = Sadece seçtiğiniz sağlayıcıyı kullanır
preferences-doh-strict-detailed-desc-2 = Güvenli DNS kullanılamazsa sizi her zaman uyarır
preferences-doh-strict-detailed-desc-3 = Güvenli DNS kullanılamazsa siteler açılmaz veya düzgün çalışmaz
preferences-doh-setting-off =
    .label = Kapalı
    .accesskey = K
preferences-doh-off-desc = Varsayılan DNS çözümleyicinizi kullanır
preferences-doh-select-resolver = Sağlayıcıyı seçin:
preferences-doh-manage-exceptions =
    .label = İstisnaları yönet…
    .accesskey = s
preferences-doh-overview-default =
    .description = Desteklenen bölgelerde güvenli DNS kullanılır.
    .label = Varsayılan koruma
preferences-doh-overview-custom =
    .description = Her zaman güvenli DNS kullanılır. Sağlayıcıyı ve hata durumunda ne yapılacağını siz seçebilirsiniz.
    .label = Özel
preferences-doh-overview-off =
    .description = Varsayılan DNS çözümleyiciniz kullanılır.
    .label = Kapalı
preferences-doh-advanced-button =
    .label = Gelişmiş ayarlar
preferences-doh-advanced-section =
    .description = HTTPS Üzerinden Alan Adı Sistemi (DoH), site sorgularını şifreleyerek internet sağlayıcınızın ve başkalarının hangi siteleri ziyaret edeceğinizi görmesini zorlaştırır.
    .label = Gelişmiş ayarlar
preferences-doh-manage-exceptions2 =
    .label = İstisnaları yönet
    .accesskey = ö
preferences-doh-radio-default =
    .description = Desteklenen bölgelerde güvenli DNS kullanılır
    .label = Varsayılan
preferences-doh-radio-custom =
    .description = Her zaman güvenli DNS kullanılır. Sağlayıcıyı ve hata durumunda ne yapılacağını siz seçebilirsiniz
    .label = Özel
preferences-doh-radio-off =
    .description = Varsayılan DNS çözümleyiciniz kullanılır
    .label = Kapalı
preferences-doh-fallback-label =
    .label = Güvenli DNS kullanılamazsa beni her zaman uyar
preferences-doh-status-item-off =
    .message = HTTPS üzerinden DNS kapalı
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = { $name } sağlayıcısını kullanmaya çalışırken bir hatayla ({ $reason }) karşılaştığımız için HTTPS üzerinden DNS çalışmıyor
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = Geçersiz bir URL aldığımız için HTTPS üzerinden DNS çalışmıyor ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = HTTPS üzerinden DNS özelliği { $name } sağlayıcısını kullanıyor
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = Yerel { $name } sağlayıcısını kullanmaya çalışırken bir hatayla ({ $reason }) karşılaştığımız için HTTPS üzerinden DNS çalışmıyor
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = HTTPS üzerinden DNS özelliği yerel { $name } sağlayıcısını kullanıyor
preferences-doh-select-resolver-label =
    .label = Sağlayıcıyı seçin:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = HTTPS üzerinden DNS çözümlemesi için bu sağlayıcıyı kullan
preferences-doh-custom-provider-label =
    .aria-label = Özel sağlayıcının adresini girin
preferences-doh-header2 =
    .heading = HTTPS üzerinden DNS

## Connection and software security section

preferences-connection-header =
    .heading = Bağlantı ve yazılım güvenliği
preferences-connection-link-section =
    .description = Bağlantıların nasıl güvende kaldığını, zararlı yazılımların nasıl engellendiğini ve sitelerin nasıl doğrulandığını görün.
    .label = Bağlantı ve yazılım güvenliği
preferences-connection-link-button =
    .label = Gelişmiş ayarlar

## The following strings are used in the Download section of settings

desktop-folder-name = Masaüstü
downloads-folder-name = İndirilenler

## Appearance page

preferences-appearance-header =
    .heading = Görünüm
browser-theme-group =
    .description = { -brand-short-name } tarayıcınıza istediğiniz tarzı katın. Tema renkleri araç çubuklarına, menülere ve iletilere uygulanır.
    .label = Tarayıcı teması
browser-theme-manage-link =
    .label = { -brand-short-name } temalarını yönet
appearance-window-density-group =
    .description = Araç çubuğu, sekmeler ve kenar çubuğu gibi pencere öğelerinin etrafındaki boşlukları ayarlayın.
    .label = Pencere yoğunluğu
appearance-window-density-radio-group =
    .aria-label = Pencere yoğunluğu
appearance-window-density-automatic =
    .description = Standart, kompakt veya dokunmatik yoğunluğu otomatik olarak uygulanır
    .label = Otomatik (varsayılan)
appearance-window-density-automatic-no-touch =
    .description = Standart ve kompakt yoğunluk otomatik olarak uygulanır
    .label = Otomatik (varsayılan)
appearance-window-density-standard =
    .description = Çoğu ekran için dengeli yoğunluk ayarı
    .label = Standart
appearance-window-density-auto-touch-mode =
    .label = Tablet modundayken dokunma aralığını kullan
appearance-window-density-compact =
    .description = Küçük ekranlar için daraltılmış boşluklar
    .label = Kompakt
appearance-window-density-touch =
    .description = Dokunmatik ekranlar için optimize edilmiş büyük pencere öğeleri ve tıklama hedefleri
    .label = Dokunmatik
related-settings-group =
    .label = İlgili ayarlar
related-settings-accessibility-link =
    .label = Yakınlaştırma ve yazı tipi ayarlarını “Erişilebilirlik” sayfasından özelleştir
related-settings-home-link =
    .label = { -firefox-home-brand-name } sayfasını özelleştir
related-settings-tabs-browsing-link =
    .label = Tarayıcı düzenini özelleştir

## AI controls page

preferences-ai-controls-description = { -brand-short-name } ile her zaman tercih hakkına sahipsiniz. Yapay zekâ destekli özellikleri kullanıp kullanmamak da sizin tercihiniz. Yakında başka kontrol imkânları da sunacağız.
preferences-ai-controls-block-ai-label = Yapay zekâ geliştirmelerini engelle
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Engellemeyi seçtiğinizde { -brand-short-name } tarayıcısında mevcut ve ileride eklenecek yapay zekâ geliştirmelerini görmez, onlarla ilgili tanıtımlar almazsınız. Bu özelliklere nelerin dahil olduğunu, arama önerileri ve uzantı önerileri gibi geleneksel makine öğrenimi özelliklerini nasıl kontrol edebileceğinizi <a data-l10n-name="link">buradan öğrenebilirsiniz</a>.
preferences-ai-controls-blocked-message =
    .message = Yeni ve mevcut yapay zekâ geliştirmeleri varsayılan olarak engelleniyor. Belirli bir özelliğin engelini kaldırmak isterseniz aşağıdaki düğmeleri kullanabilirsiniz.
preferences-ai-controls-on-device-group =
    .description = Bu özellikleri kullanırsanız cihazınıza indirilen küçük yapay zekâ modelleri kullanılır. Bu yaklaşım gizliliğinizin korunmasını sağlar.
    .label = Yerel yapay zekâ
preferences-ai-controls-translations-control =
    .description = Web’de tercih ettiğiniz dilde dolaşabilirsiniz.
    .label = Çeviri
preferences-ai-controls-translations-more-link = Diğer çeviri ayarları
preferences-ai-controls-pdfjs-control =
    .description = PDF’lere resim eklediğinizde bu özellik, resimleri daha erişilebilir kılmak için onlara açıklama ekler.
    .label = { -brand-short-name } PDF görüntüleyicisinde resim alternatif metni
preferences-ai-controls-tab-group-suggestions-control =
    .description = Sekmelerinizi adlandırmak ve organize etmek için öneriler alabilirsiniz.
    .label = Sekme grubu önerileri
preferences-ai-controls-key-points-control =
    .description = Bağlantılara tıklamadan önce hızlı özetlerini görebilirsiniz.
    .label = Bağlantı ön izlemelerinde önemli noktalar
preferences-ai-controls-speech-recognition-control =
    .description = Konuşmayı bu cihazda metne dönüştür.
    .label = Konuşma tanıma
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Web’de gezinirken sohbet botunuz gözünüzün önünde olsun. Seçtiğiniz sağlayıcıyı istediğiniz zaman değiştirebilirsiniz.
    .label = Kenar çubuğunda yapay zekâ sohbet botu sağlayıcıları
preferences-ai-controls-sidebar-chatbot-group =
    .description = Web’de gezinirken istediğiniz sohbet botunu açık tutabilirsiniz. Anthropic Claude, ChatGPT, Copilot, Google Gemini ve Le Chat Mistral arasından seçim yapabilirsiniz.
    .label = Kenar çubuğunda yapay zekâ sohbet botu sağlayıcıları
preferences-ai-controls-sidebar-chatbot-control =
    .label = Kenar çubuğunda sohbet botu
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Kullanılabilir
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Etkin
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Engellendi
preferences-ai-controls-state-description-before = Seçenekler ne anlama geliyor?
preferences-ai-controls-state-description-available = <strong>Kullanılabilir:</strong> Bu özelliği görecek ve kullanabileceksiniz.
preferences-ai-controls-state-description-enabled = <strong>Etkin:</strong> Bu özelliği kullanıyorsunuz.
preferences-ai-controls-state-description-blocked = <strong>Engellendi:</strong> Bu özelliği görmeyecek ve kullanamayacaksınız. Yerel yapay zekâ özellikleri için daha önce indirilmiş olan modeller kaldırılacaktır.
preferences-ai-controls-block-confirmation-heading = Yapay zekâ geliştirmeleri engellensin mi?
preferences-ai-controls-block-confirmation-description = { -brand-short-name } tarayıcısında yeni ve mevcut yapay zekâ geliştirmelerini ve bunlarla ilgili tanıtımları görmeyeceksiniz. Kullanmaya devam etmek istediğiniz özelliklerin engelini kaldırabilirsiniz.
preferences-ai-controls-block-confirmation-features-start = Neler engellenecek?
preferences-ai-controls-block-confirmation-translations = Çeviriler
preferences-ai-controls-block-confirmation-pdfjs = { -brand-short-name } PDF görüntüleyicisinde resim alternatif metni
preferences-ai-controls-block-confirmation-tab-group-suggestions = Sekme grubu önerileri
preferences-ai-controls-block-confirmation-key-points = Bağlantı ön izlemelerinde önemli noktalar
preferences-ai-controls-block-confirmation-sidebar-chatbot = Kenar çubuğundaki sohbet botu sağlayıcıları
preferences-ai-controls-block-confirmation-speech-recognition = Konuşma tanıma
preferences-ai-controls-block-confirmation-features-after = Engelleme, { -brand-short-name } tarafından sağlanan yapay zekâ özelliklerini kullanan uzantıları da etkiler.
preferences-ai-controls-block-confirmation-cancel =
    .label = Vazgeç
preferences-ai-controls-block-confirmation-confirm =
    .label = Engelle
preferences-ai-controls-header3 =
    .heading = Yapay zekâ kontrolleri

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } sizi koruyor
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } bazı güvenlik iyileştirmeleri öneriyor
security-privacy-status-ok-label = Gelişmiş izlenme koruması açık
security-privacy-status-problem-label = Korumanızı etkileyen ayarlar bulduk
security-privacy-status-problem-helper-label = Sorunları göster
security-privacy-status-pending-trackers-label = Geçen ay { -brand-short-name } tarayıcınızın kaç takip kodunu engellediği hesaplanıyor
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] Geçen ay { $trackerCount } takip kodu engellendi
       *[other] Geçen ay { $trackerCount } takip kodu engellendi
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = <a data-l10n-name="strict-tracking-protection">Sıkı korumayı</a> kullanıyorsunuz
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = <a data-l10n-name="custom-tracking-protection">Özel korumayı</a> kullanıyorsunuz
security-privacy-status-up-to-date-label = { -brand-short-name } tarayıcısının en yeni ve en güvenli sürümünü kullanıyorsunuz
security-privacy-status-update-needed-label = Yeni bir { -brand-short-name } sürümü çıktı.
security-privacy-status-update-error-label = { -brand-short-name } kendi kendini güncelleyemedi
security-privacy-status-update-checking-label = { -brand-short-name } güncellemeleri denetliyor
security-privacy-status-update-needed-description = En yeni hız, kararlılık ve güvenlik güncellemeleri için güncelleme yapın.
security-privacy-status-update-button-label =
    .label = { -brand-short-name } tarayıcısını güncelle
security-privacy-image-warning =
    .alt = Güvenlik uyarılarınızla ilgili endişemizi ifade eden ünlem işaretli bir kalkan
security-privacy-image-ok =
    .alt = Başka güvenlik sorununuz olmadığını gösteren, onay işaretli bir kalkan
security-privacy-issue-card =
    .heading = Güvenlik uyarıları
issue-card-reset-button =
    .label = Sıfırla
issue-card-dismiss-button =
    .aria-label = Kapat
    .tooltiptext = Kapat

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Siteler internette sizi takip etmek ve rahatsız edici reklamlar göstermek için takip kodlarını kullanır. { -brand-short-name }, internette gezinirken sizi korur ve takip kodlarını otomatik olarak engelleyerek dijital izinizin kontrolünü size verir.
    .label = Gelişmiş izlenme koruması
preferences-etp-level-radio-group =
    .aria-label = Gelişmiş izlenme koruması
preferences-etp-level-standard =
    .description = Çoğu sitede sorunsuz çalışan güçlü ve güvenilir korumalar.
    .label = Standart (varsayılan)
preferences-etp-level-strict =
    .description = Daha fazla takip kodunu engelleyen ama bazı sitelerin bozulmasına yol açabilen daha güçlü korumalar.
    .label = Sıkı
preferences-etp-level-custom =
    .description = Hangi korumaları açmak veya kapatmak istediğinizi seçin.
    .label = Özel
preferences-etp-status-advanced-button =
    .label = Gelişmiş ayarlar
preferences-etp-tracker-count-enabled =
    .label = Engellenen takip kodu sayısını adres çubuğunda göster
preferences-etp-status-protections-dashboard-link =
    .description = { -brand-short-name } tarayıcınızın sosyal medya takipçileri, parmak izi toplayıcılar ve kripto madencileri gibi kaç adet sinsi takip kodunu engellediğini görün.
    .label = Size özel korumalar panosuna bakın
preferences-etp-header =
    .heading = Gelişmiş izlenme koruması
preferences-etp-advanced-settings-group =
    .description = Siteler internette sizi takip etmek ve rahatsız edici reklamlar göstermek için takip kodlarını kullanır. { -brand-short-name }, internette gezinirken sizi korur ve çoğu takip kodunu otomatik olarak engelleyerek dijital izinizin kontrolünü size verir.
    .label = Gelişmiş ayarlar
preferences-etp-customize-button =
    .label = İzlenme korumasını özelleştir
preferences-etp-reload-tabs-hint =
    .message = Bu değişiklikleri uygulamak için sekmelerinizi tazeleyin.
preferences-etp-reload-tabs-hint-button =
    .label = Tüm sekmeleri tazele
preferences-etp-rfp-warning-message =
    .message = Resist Fingerprinting (RFP) özelliğini kullanıyorsunuz. { -brand-short-name } tarayıcısının bazı parmak izi koruma ayarlarını değiştiren bu özellik bazı sitelerin bozulmasına yol açabilir.
preferences-etp-level-warning-message =
    .heading = Dikkat! Bazı siteler beklenildiği gibi çalışmayabilir.
    .message = Bazı siteler özelliklerine veya içeriklerine takip kodları yerleştirir. { -brand-short-name } bunları engellediğinde site bozuk görünebilir. “Site sorununu düzelt” seçeneğini kullanmayı veya o sitede izlenme korumasını kapatmayı deneyin.
preferences-etp-manage-exceptions-button =
    .description = Gelişmiş izlenme korumasının kapalı olacağı siteleri yönetin.
    .label = İstisnaları yönet
preferences-etp-customize-header =
    .heading = İzlenme korumasını özelleştir
preferences-etp-reset =
    .description = Ayarları hazır koruma düzeylerinden birine geri döndür.
    .label = Özelleştirmeleri sıfırla
preferences-etp-reset-standard-button =
    .label = Standart ayarlara dön
preferences-etp-reset-strict-button =
    .label = Sıkı ayarlara dön
preferences-etp-custom-control-group =
    .description = Hangi korumaları açmak veya kapatmak istediğinizi seçin.
    .label = İzlenme koruması
preferences-etp-custom-cookies-enabled =
    .label = Çerezler
preferences-etp-custom-cookie-behavior =
    .aria-label = Çerezler
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Tüm çerezlere izin ver
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Siteler arası takip çerezlerini engelle
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Siteler arası çerezleri engelle
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Siteler arası çerezleri izole et
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Ziyaret etmediğim sitelerden gelen çerezleri engelle
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Tüm siteler arası çerezleri engelle (Bazı siteler düzgün çalışmayabilir)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Tüm çerezleri engelle (Siteler düzgün çalışmaz)
preferences-etp-custom-tracking-protection-enabled =
    .label = Takip amaçlı içerikler
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Takip amaçlı içerikler
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Kripto madencileri
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Bilinen parmak izi toplayıcılar
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Şüpheli parmak izi toplayıcılar
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Şüpheli parmak izi toplayıcılar

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Bu durumda bazı takip kodları sizi çerezler olmadan da izleyebilir.
    .label = Bilinen parmak izi toplayıcılar engellenmiyor
security-privacy-issue-warning-third-party-cookies =
    .description = Üçüncü taraf çerezleri web siteleri arasında sizi takip etmek için kullanılır.
    .label = Üçüncü taraf çerezleri etkin
security-privacy-issue-warning-password-manager =
    .description = Parola yöneticileri hesaplarınız için güçlü parolaları depolamanıza yardımcı olur.
    .label = Parola yöneticisi devre dışı
security-privacy-issue-warning-popup-blocker =
    .description = Açılır pencereler rahatsız edici ve bazen de zararlı olabilir.
    .label = Açılır pencere engelleyici devre dışı
security-privacy-issue-warning-extension-install =
    .description = Web siteleri size sormadan { -brand-short-name } tarayıcısına uzantı yükleyebilir.
    .label = Web siteleri uzantı yükleyebilir
security-privacy-issue-warning-safe-browsing =
    .description = Sitelerden kaynaklanan dolandırıcılık ve kötü amaçlı yazılımlara maruz kalma riskiniz şu anda daha yüksek.
    .label = Tehlikeli ve yanıltıcı içerikler engellenmiyor
security-privacy-issue-warning-doh2 =
    .description = HTTPS üzerinden DNS, ziyaret ettiğiniz siteleri ağ sağlayıcınızdan gizlemenize yardımcı olur.
    .label = HTTPS üzerinden DNS devre dışı
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello, ziyaret ettiğiniz siteleri ağ sağlayıcınızdan gizlemenize yardımcı olur.
    .label = Encrypted Client Hello devre dışı
security-privacy-issue-warning-doh =
    .description = HTTPS üzerinden DNS, hangi siteleri ziyaret ettiğinizi servis sağlayıcınızdan gizler.
    .label = HTTPS üzerinden DNS devre dışı
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello, ziyaret ettiğiniz siteleri servis sağlayıcınızdan gizler.
    .label = Encrypted Client Hello devre dışı
security-privacy-issue-warning-proxy-autodetection =
    .description = Vekil sunucu otomatik yapılandırması, güvenilmeyen ağların web’de yaptıklarınızı izlemesine olanak verebilir.
    .label = Vekil sunucu otomatik yapılandırması etkin

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Gizliliği ilk sıraya koyan tarayıcıyı arkadaşlarınıza önerin.
    .label = { -brand-product-name } tarayıcısını paylaş
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = { -brand-product-name } tarayıcısını paylaş


vorbit-header = vOrbit-lite Ayarları
vorbit-warning-title = Dikkat!
vorbit-network-heading = Bağlantı ayarları
vorbit-ipv6-checkbox =
    .label = IPv6'yı etkinleştir
vorbit-privacy-heading = Mahremiyet
vorbit-xorigin-ref-checkbox =
    .label = İnternet sitelerinin hangi siteden yönlendirildiğinizi görmesini engelle
vorbit-broken-heading = Parmak izi
vorbit-webgl-checkbox =
    .label = WebGL'yi etkinleştir
vorbit-security-heading = Güvenlik
pane-vorbit-title = vOrbit-lite
vorbit-styling-checkbox =
    .label = userChrome.css dosyasıyla arayüz özelleştirmelerine izin ver
vorbit-rfp-checkbox =
    .label = Parmak izi korumasını etkinleştir
vorbit-letterboxing-checkbox =
    .label = Sahte çerçeveyle parmak izi koruması
vorbit-warning-description = Gizliliğe ve güvenliğe odaklanmak için varsayılan ayarları dikkatlice seçiyoruz. Bu ayarları değiştirirken, bu değişikliklerin etkilerini anlamak için açıklamaları okuyun.
vorbit-general-heading = Tarayıcı Davranışı
vorbit-extension-update-checkbox =
    .label = Eklentileri kendiliğinden güncelle
vorbit-autocopy-checkbox =
    .label = Orta tıklamayla yapıştırmayı etkinleştir
vorbit-sync-checkbox =
    .label = Firefox Sync'i etkinleştir
vorbit-goog-safe-download-checkbox =
    .label = İndirilen dosyaları güvenlik riski için tara
vorbit-config-link = Bütün ileri düzey ayarlar (about:config)
vorbit-styling-warning1 = Temayı etkinleştirmeden önce temayı edindiğiniz kaynağın güvenilir olduğuna emin olun.
vorbit-xorigin-ref-description = Sadece geldiğiniz site aynıysa hangi siteden yönlendirildiğiniz bilgisinin gönderilmesine izin verin.
vorbit-webgl-warning1 = Gerçekten WebGL'yi kullanmanız gerekiyorsa, mahremiyetinizi güçlendirmek açısından Canvas Blocker gibi eklentilere göz atın.
vorbit-sync-description = Tarayıcı verilerinizi diğer tarayıcılarla senkronize edin. Etkinleştirdikten sonra tarayıcıyı yeniden başlatmanız gereklidir.
vorbit-sync-warning1 = Firefox Sync hizmeti, verilerinizi sunucuya göndermeden önce cihazınızda yerel olarak şifreler.
vorbit-autocopy-description = Bir metni kopyalayın, ardından farenin orta tuşuyla yapıştırın.
vorbit-footer = Faydalı bağlantılar
vorbit-open-profile = Kullanıcı profili klasörünü açın
vorbit-goog-safe-download-warning1 = Bütün bağlantı denetimleri cihazınızda yerel olarak yapılır, gizlilik açısından bir zararı yoktur.
vorbit-goog-safe-description = Zararlı yazılımlardan yahut oltalama saldırılarından çekiniyorsanız, bu ayarı etkinleştirebilirsiniz.
vorbit-extension-update-warning1 = Eğer eklentilerinizin kaynak kodunu her güncellemeden önce gözden geçirmiyorsanız, bu seçeneği etkinleştirmelisiniz.
vorbit-extension-update-description = Uzantıları elle müdahale olmadan güncel tutun. Güvenliğiniz için iyi bir seçimdir.
vorbit-styling-description = Elle yüklenmiş bir temayla arayüz özelleştirmesi yapmak istiyorsanız bu seçeneği etkinleştirin.
category-vorbit =
    .tooltiptext = about:config seçenekleri, doğrudan ve kolay kullanım için gruplandırılmış şekilde
vorbit-ocsp-checkbox =
    .label = Sertifika doğrulanamazsa siteye erişimin engellenmesini zorunlu kıl
vorbit-ipv6-description = { -brand-short-name } tarafından IPv6 kullanımına izin ver.
vorbit-ipv6-warning1 = IPv6'yı tarayıcı düzeyinde engellemek yerine, işletim sisteminizde IPv6 gizlilik uzantısını kullanmanızı öneririz.
vorbit-ocsp-description = OCSP kontrolü gerçekleştirilemiyorsa bir web sitesine bağlanmayı engelleyin.
vorbit-xorigin-ref-warning1 = Bu özellik bazı sıkıntılara yol açabilir. Ek olarak, kaynak bilgisi gönderilse dahi kırpılmış olarak gönderilir.
vorbit-webgl-description = WebGL, tarayıcı parmak izi için bir zafiyettir.
vorbit-rfp-description = Parmak izi koruması, parmak izi takibine alanında en iyisidir.
vorbit-rfp-warning1 = Bu ayar mahremiyetiniz açısından çok değerlidir. Gerçekten bu ayar size sıkıntı çıkarıyorsa ve devre dışı bırakmanız gerekiyorsa, Canvas Blocker gibi bir eklentiyle mahremiyetinizi destekleyin.
vorbit-letterboxing-description = Sahte çerçeve koruması, tarayıcı pencerenize boşluklar ekleyerek gerçek ekran çözünürlüğünüzü maskeler. Parmak izi takibine karşı iyi bir tercihtir.
vorbit-goog-safe-warning1 = Sansür endişelerinden dolayı varsayılan olarak etkin değildir, ileri düzey bir kullanıcı değilseniz etkinleştirmeniz önerilir. Bütün bağlantı denetimleri cihazınızda yerel olarak yapılır.
vorbit-goog-safe-download-description = Şüpheli dosya tespiti için indirdiğiniz dosyaların güvenlik taramasından geçmesine izin verin.
content-blocking-section-top-level-description = vOrbit-lite gelişmiş izleme korumasını varsayılan olarak sıkı düzeyde etkinleştirir. Bu ayar, sunduklarıyla mahremiyetiniz açısından en önemli ayarlardan biridir. Devre dışı bırakmanızı yahut sıkı düzeyden başka bir düzeye geçmenizi asla tavsiye etmiyoruz.
vorbit-ocsp-warning1 = Bu tercih güvenliğiniz açısından iyidir, fakat sertifika doğrulayıcısı çalışmadığında bazı sıkıntılar baş gösterebilir.
vorbit-goog-safe-checkbox =
    .label = Google Güvenli Tarama hizmetini etkinleştir
