# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } Gizli Gezinti
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Hızlı ve gizli web gezintisi
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Gizli Gezinti
       *[other] { -brand-full-name } Gizli Gezinti
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Gizli Gezinti
popups-infobar-dont-show-message2 =
    .label = Açılır pencereler veya üçüncü taraf yönlendirmeleri engellendiğinde bu mesajı gösterme
    .accesskey = A
edit-popup-settings2 =
    .label = Açılır pencere ve üçüncü taraf yönlendirmesi ayarlarını yönet…
    .accesskey = A
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Site bilgilerini göster
            [1] Site bilgilerini göster ({ $count } takip kodu engellendi)
            [one] Site bilgilerini göster ({ $count } takip kodu engellendi)
           *[other] Site bilgilerini göster ({ $count } takip kodu engellendi)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } bağlantı
           *[other] { $count } bağlantı
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Mesajlar ve diğerleri…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Mesajlar, Mail ve diğerleri…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Paylaş…
    .accesskey = P
urlbar-identity-button =
    .aria-label = Site bilgilerini göster

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Yükleme mesajı panelini aç
urlbar-web-notification-anchor =
    .tooltiptext = Sitenin bildirim gönderip gönderemeyeceğini ayarlayın
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI panelini aç
urlbar-serial-notification-anchor =
    .tooltiptext = Seri panelini aç
urlbar-eme-notification-anchor =
    .tooltiptext = DRM yazılımı kullanımını yönet
urlbar-web-authn-anchor =
    .tooltiptext = Web kimlik doğrulaması panelini aç
urlbar-canvas-notification-anchor =
    .tooltiptext = Canvas veri ayıklama iznini yönet
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Siteyle mikrofonumu paylaşmayı yönet
urlbar-default-notification-anchor =
    .tooltiptext = Mesaj panelini aç
urlbar-geolocation-notification-anchor =
    .tooltiptext = Konum isteği panelini aç
urlbar-localhost-notification-anchor =
    .tooltiptext = Bu site için yerel cihaz erişimini yönet
urlbar-local-network-notification-anchor =
    .tooltiptext = Bu siteyle yerel ağ erişimini paylaşmayı yönet
urlbar-xr-notification-anchor =
    .tooltiptext = Sanal gerçeklik izin panelini aç
urlbar-storage-access-anchor =
    .tooltiptext = Gezinme etkinliği izin panelini aç
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Siteyle pencerelerimi veya ekranımı paylaşmayı yönet
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Çevrimdışı depolama mesajı panelini aç
urlbar-password-notification-anchor =
    .tooltiptext = Parolayı kaydet mesajı panelini aç
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Siteyle kamera ve/veya mikrofonumu paylaşmayı yönet
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Siteyle diğer ses aygıtlarımı paylaşmayı yönet
urlbar-autoplay-notification-anchor =
    .tooltiptext = Otomatik oynatma panelini aç
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Kalıcı depolama alanında veri depola
urlbar-addons-notification-anchor =
    .tooltiptext = Eklenti yükleme mesajı panelini aç
urlbar-search-tips-confirm = Tamam, anladım
urlbar-search-tips-confirm-short = Anladım
urlbar-result-menu-button =
    .title = Menüyü aç
urlbar-result-menu-button-feedback = Görüş bildir
    .title = Menüyü aç
urlbar-result-menu-learn-more2 = Daha fazla bilgi al
    .accesskey = D
urlbar-result-menu-remove-from-history2 = Geçmişten sil
    .accesskey = G
urlbar-result-menu-tip-get-help2 = Yardım al
    .accesskey = Y
urlbar-result-menu-dismiss-suggestion2 = Bu öneriyi kapat
    .accesskey = B
urlbar-result-menu-remove-top-site = Sık kullanılanlardan sil
    .accesskey = S
urlbar-result-menu-manage-firefox-suggest2 = { -firefox-suggest-brand-name } yönet
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Hatalı konum bildir
    .accesskey = H
urlbar-result-menu-show-less-frequently3 = Daha az göster
    .accesskey = D
urlbar-result-menu-dont-show-weather-suggestions3 = Hava durumu önerilerini gösterme
    .accesskey = H
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Hatalı konum bildir
urlbar-result-menu-show-less-frequently2 = Daha az göster
urlbar-result-menu-dont-show-weather-suggestions2 = Hava durumu önerilerini gösterme
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Bu öneriyi kapat
    .accesskey = B
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Geçmişten sil
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = Daha fazla bilgi al
    .accesskey = D
urlbar-result-menu-remove-from-history =
    .label = Geçmişten sil
    .accesskey = G
urlbar-result-menu-tip-get-help =
    .label = Yardım al
    .accesskey = Y
urlbar-result-menu-dismiss-suggestion =
    .label = Bu öneriyi kapat
    .accesskey = B
urlbar-result-menu-manage-firefox-suggest =
    .label = { -firefox-suggest-brand-name } yönet
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Hatalı konum bildir
urlbar-result-menu-show-less-frequently =
    .label = Daha az göster
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Hava durumu önerilerini gösterme
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Menüyü aç
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Geri bildiriminiz için teşekkürler
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Geri bildiriminiz için teşekkür ederiz. Artık hava durumu önerilerini görmeyeceksiniz.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Daha az yazın, daha çok bulun: Adres çubuğunuzdan { $engineName } ile arama yapın.
urlbar-search-tips-redirect-2 = { $engineName } ve gezinti geçmişinizden gelen önerileri görmek için adres çubuğunda arama yapmaya başlayın.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Aradığınızı daha hızlı bulmak için bu kısayolu seçin.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Yer imleri
urlbar-search-mode-tabs = Sekmeler
urlbar-search-mode-history = Geçmiş
urlbar-search-mode-actions = Eylemler

##

urlbar-geolocation-blocked =
    .tooltiptext = Bu sitenin konumunuzu öğrenmesini engellediniz.
urlbar-localhost-blocked =
    .tooltiptext = Bu sitenin yerel cihaz bağlantılarını engellediniz.
urlbar-local-network-blocked =
    .tooltiptext = Bu sitenin yerel ağ bağlantılarını engellediniz.
urlbar-xr-blocked =
    .tooltiptext = Bu sitenin sanal gerçeklik cihazlarına erişimini engellediniz.
urlbar-web-notifications-blocked =
    .tooltiptext = Bu sitenin bildirim göndermesini engellediniz.
urlbar-camera-blocked =
    .tooltiptext = Bu sitenin kameranızı kullanmasını engellediniz.
urlbar-microphone-blocked =
    .tooltiptext = Bu sitenin mikrofonunuzu kullanmasını engellediniz.
urlbar-screen-blocked =
    .tooltiptext = Bu sitenin ekranınızı paylaşmasını engellediniz.
urlbar-persistent-storage-blocked =
    .tooltiptext = Bu sitenin kalıcı veri depolamasını engellediniz.
urlbar-popup-blocked2 =
    .tooltiptext = Bu sitede açılır pencereleri ve üçüncü taraf yönlendirmelerini engellediniz.
urlbar-autoplay-media-blocked =
    .tooltiptext = Bu sitenin sesli medya dosyalarını otomatik oynatmasını engellediniz.
urlbar-canvas-blocked =
    .tooltiptext = Bu sitenin canvas’tan veri ayıklamasını engellediniz.
urlbar-midi-blocked =
    .tooltiptext = Bu sitenin MIDI erişimini engellediniz.
urlbar-serial-blocked =
    .tooltiptext = Bu sitenin seri bağlantı noktası erişimini engellediniz.
urlbar-install-blocked =
    .tooltiptext = Bu sitenin eklenti yüklemesini engellediniz.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Bu yer imini düzenle ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Bu sayfayı yer imlerine ekle ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Ayrık görünüm
    .tooltiptext = Ayrık görünüm

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Yapıştır ve git
    .accesskey = Y
urlbar-menuitem-paste-and-search =
    .label = Yapıştır ve ara
    .accesskey = Y

## Searchbar context menu

clear-search-history =
    .label = Arama geçmişini temizle
    .accesskey = t

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Uzantıyı yönet…
    .accesskey = U
page-action-remove-extension2 =
    .label = Uzantıyı kaldır
    .accesskey = k

## Auto-hide Context Menu

full-screen-autohide =
    .label = Araç çubuklarını gizle
    .accesskey = A
full-screen-exit =
    .label = Tam ekran kipinden çık
    .accesskey = T

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Bir de bununla aramayı deneyin:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Arama ayarlarını değiştir
search-one-offs-context-open-new-tab =
    .label = Yeni sekmede ara
    .accesskey = s
search-one-offs-context-set-as-default =
    .label = Varsayılan arama motoru yap
    .accesskey = m
search-one-offs-context-set-as-default-private =
    .label = Gizli pencerelerde varsayılan arama motoru olarak ayarla
    .accesskey = G
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = “{ $engineName }” arama motorunu ekle
    .label = “{ $engineName }” arama motorunu ekle
    .tooltiptext = “{ $engineName }” arama motorunu ekle
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Arama motoru ekle
    .accesskey = A
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Arama motoru ekle

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Yer imleri ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Sekmeler ({ $restrict })
search-one-offs-history =
    .tooltiptext = Geçmiş ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Eylemler ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Eklentileri görüntüle
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = uzantılar, temalar, eklentiler
# Opens preferences page at AI controls
quickactions-manageai = Yapay zekâ kontrollerini yönet
quickactions-cmd-manageai = yapay zekâyı devre dışı bırak, yapay zekâyı kapat, yapay zekâyı yönet, yapay zekayı devre dışı bırak, yapay zekayı kapat, yapay zekayı yönet, ai kapat, ai devre dışı, ai yönet
# Opens the bookmarks library window
quickactions-bookmarks2 = Yer imlerini yönet
quickactions-cmd-bookmarks = yer imleri
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Yakın geçmişi temizle
quickactions-cmd-clearrecenthistory2 = çerezleri temizle, önbellek, önbelleği temizle, gezinti verilerini temizle, geçmiş, yakın geçmişi temizle
# Opens about:downloads page
quickactions-downloads2 = İndirilenleri göster
quickactions-cmd-downloads = indirilenler
# Opens about:addons page in the extensions section
quickactions-extensions = Uzantıları yönet
quickactions-cmd-extensions2 = uzantılar, eklentiler
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name }’u aç
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = { -firefoxview-brand-name }’u aç, { -firefoxview-brand-name }, view’u aç, view
# Opens SUMO home page
quickactions-help = { -brand-product-name } yardımı
quickactions-cmd-help = yardım, destek
# Opens the devtools web inspector
quickactions-inspector2 = Geliştirici araçlarını aç
quickactions-cmd-inspector2 = denetçi, geliştirici araçları, inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Renk seç
quickactions-cmd-colorpicker = renk seçici, damlalık
# Opens Firefox Library
quickactions-cmd-library = arşiv
quickactions-library = Arşivi aç
# Opens about:logins
quickactions-logins2 = Parolaları yönet
quickactions-cmd-logins = hesaplar, parolalar
# Mutes all tabs playing audio
quickactions-mute = Ses çalan sekmeleri sessize al
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = sessiz, sus, şşt
# Opens the print dialog
quickactions-print2 = Sayfayı yazdır
quickactions-cmd-print = yazdır
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Sayfayı PDF olarak kaydet
quickactions-cmd-savepdf2 = pdf, sayfayı kaydet
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF düzenleyicisini aç
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Gizli pencere aç
quickactions-cmd-private = gizli gezinti
# Opens a SUMO article explaining how to refresh
quickactions-refresh = { -brand-short-name } tarayıcısını yenile
quickactions-cmd-refresh = tazele
# Restarts the browser
quickactions-restart = { -brand-short-name } tarayıcısını yeniden başlat
quickactions-cmd-restart = yeniden başlat
# Opens the screenshot tool
quickactions-screenshot3 = Ekran görüntüsü al
quickactions-cmd-screenshot2 = ekran görüntüsü al
# Opens about:translations
quickactions-translate = Çevir
quickactions-cmd-translate = çevir
# Opens about:preferences
quickactions-settings2 = Ayarları yönet
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = ayarlar, tercihler, seçenekler
# Opens about:addons page in the themes section
quickactions-themes = Temaları yönet
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temalar, eklentiler
# Opens a SUMO article explaining how to update the browser
quickactions-update = { -brand-short-name } tarayıcısını güncelle
quickactions-cmd-update = güncelle
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Sayfa kaynağını göster
quickactions-cmd-viewsource2 = kaynağı göster, kaynak, sayfa kaynağı
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = { -firefoxlabs-brand-name }’i aç
quickactions-cmd-labs = labs, deney
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Hızlı eylemler hakkında daha fazla bilgi alın
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Seçmek için Tab tuşuna basın:

## Bookmark Panel

bookmarks-add-bookmark = Yer imi ekle
bookmarks-edit-bookmark = Yer imini düzenle
bookmark-panel-cancel =
    .label = Vazgeç
    .accesskey = z
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Yer imini sil
           *[other] { $count } yer imini sil
        }
    .accesskey = s
bookmark-panel-show-editor-checkbox =
    .label = Kaydederken düzenleyiciyi göster
    .accesskey = d
bookmark-panel-save-button2 =
    .label = Kaydet
    .accesskey = K
bookmark-panel-save-button =
    .label = Kaydet
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = { $host } site bilgileri
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = { $host } bağlantı güvenliği
identity-connection-not-secure = Bağlantı güvenli değil
identity-connection-secure = Bağlantı güvenli
identity-connection-failure = Bağlantı hatası
identity-connection-internal = Burası güvenli bir { -brand-short-name } sayfasıdır.
identity-connection-file = Bu sayfa bilgisayarınızda depolanıyor.
identity-connection-associated = Bu sayfa başka bir sayfa üzerinden yüklendi.
identity-extension-page = Bu sayfa bir uzantı üzerinden yüklendi.
identity-active-blocked = { -brand-short-name } bu sayfanın güvenli olmayan kısımlarını engelledi.
identity-custom-root = Bağlantı, Mozilla’nın tanımadığı bir sertifika yayıncısı tarafından doğrulandı.
identity-passive-loaded = Bu sayfanın bazı kısımları (örneğin resimler) güvenli değil.
identity-active-loaded = Bu sayfada korumayı devre dışı bıraktınız.
identity-weak-encryption = Bu sayfada zayıf şifreleme kullanılıyor.
identity-https-only-connection-upgraded = (HTTPS’e yükseltildi)
identity-https-only-label2 = Bu siteyi otomatik olarak güvenli bağlantıya yükselt
identity-https-only-dropdown-on =
    .label = Açık
identity-https-only-dropdown-off =
    .label = Kapalı
identity-https-only-dropdown-off-temporarily =
    .label = Geçici olarak kapalı
identity-https-only-info-turn-on3 = Mümkün olduğunda { -brand-short-name } tarayıcınızın güvenli bağlantıya geçmesini istiyorsanız bu site için HTTPS yükseltmelerini açın.
identity-https-only-info-turn-off3 = Sayfa düzgün çalışmazsa bu site için HTTPS yükseltmelerini kapatarak siteyi güvensiz HTTP ile yüklemeyi deneyebilirsiniz.
identity-https-only-info-no-upgrade = HTTP bağlantısı yükseltilemedi.
identity-permissions-storage-access-header = Siteler arası çerezler
identity-permissions-storage-access-hint = Aşağıdaki siteler, siz bu sitedeyken başka sitelerin çerezlerini ve site verilerini kullanabilir.
identity-permissions-storage-access-learn-more = Daha fazla bilgi al
identity-permissions-reload-hint = Değişikliklerin uygulanması için bu sayfayı tazelemeniz gerekebilir.
identity-clear-site-data =
    .label = Çerezleri ve site verilerini temizle…
identity-connection-not-secure-security-view = Bu siteye güvenli bir şekilde bağlanmadınız.
identity-connection-verified = Bu siteye güvenli bir şekilde bağlandınız.
identity-ev-owner-label2 = Sertifika sahibi
identity-verifier-label2 = Doğrulayan
identity-ev-owner-label = Sertifika sahibi:
identity-verifier-label = Doğrulayan:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = 2024/1183 Sayılı AB Regülasyonu’na uygundur.
identity-description-custom-root2 = Mozilla bu sertifika yayıncısını tanımıyor. İşletim sisteminiz üzerinden veya sistem yöneticiniz tarafından eklenmiş olabilir.
identity-cert-exception-overridden = Bu site için güvenlik istisnası eklediniz.
identity-remove-cert-exception =
    .label = İstisnayı sil
    .accesskey = s
identity-description-insecure = Bu siteye bağlantınız size özel değil. Gönderdiğiniz bilgiler (parolalar, mesajlar, kredi kartı bilgileri vb.) başkaları tarafından görülebilir.
identity-description-weak-cipher-intro = Bu siteye bağlantınız zayıf bir şifreleme kullanıyor ve gizli değil.
identity-description-weak-cipher-risk = Başkaları bilgilerinizi görebilir veya web sitesinin davranışını değiştirebilir.
identity-description-active-blocked2 = { -brand-short-name } bu sayfanın güvenli olmayan kısımlarını engelledi.
identity-description-passive-loaded = Bağlantınız size özel değil ve bu siteyle paylaştığınız bilgiler başkaları tarafından görülebilir.
identity-description-passive-loaded-insecure2 = Bu sitede güvenli olmayan içerikler (resimler vb.) var.
identity-description-passive-loaded-mixed2 = { -brand-short-name } bazı içerikleri engellemiş olmasına rağmen bu sayfada hâlâ güvenli olmayan içerikler (örn. resimler) var.
identity-description-active-loaded = Bu web sitesinde güvenli olmayan içerikler var (örn. betikler) ve siteye olan bağlantınız gizli değil.
identity-description-active-loaded-insecure = Bu siteyle paylaştığınız bilgiler (örn. parolalar, mesajlar, kredi kartı bilgileri vb.) başkaları tarafından görülebilir.
identity-description-tls-key-logging-heading = Bağlantınız gizli olmayabilir
identity-description-tls-key-logging-message = Bir uygulama veya hizmet bu siteden gelen şifrelenmiş trafiğinizi görebilir.
identity-more-info-link-text =
    .label = Daha fazla bilgi

## Window controls

browser-window-minimize-button =
    .tooltiptext = Küçült
browser-window-maximize-button =
    .tooltiptext = Ekranı kapla
browser-window-restore-down-button =
    .tooltiptext = Geri küçült
browser-window-close-button =
    .tooltiptext = Kapat
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Geri dön

## Bookmarks toolbar items

browser-import-button2 =
    .label = Yer imlerini içe aktar…
    .tooltiptext = Başka bir tarayıcıdaki yer imlerini { -brand-short-name } tarayıcısına aktar.
bookmarks-toolbar-empty-message = Hızlıca erişmek istediğiniz yer imlerinizi yer imleri araç çubuğuna yerleştirebilirsiniz. <a data-l10n-name="manage-bookmarks">Yer imlerini yönet…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Ses aygıtları
popup-select-window-or-screen =
    .label = Pencere veya ekran:
    .accesskey = P
popup-all-windows-shared = Ekranınızdaki tüm görünür pencereler paylaşılacaktır.

## WebRTC window or screen share tab switch warning

sharing-warning-window = { -brand-short-name } tarayıcınızı paylaşıyorsunuz. Yeni bir sekmeye geçerseniz diğer kullanıcılar bunu görebilir.
sharing-warning-screen = Tüm ekranınızı paylaşıyorsunuz. Yeni bir sekmeye geçerseniz diğer kullanıcılar bunu görebilir.
sharing-warning-proceed-to-tab =
    .label = Sekmeye devam et
sharing-warning-disable-for-session =
    .label = Bu oturumda paylaşım korumasını devre dışı bırak

## WebSerial "select a port" popup

webserial-select-port-label = Bir seri bağlantı noktası seçin:
webserial-no-ports-available = Kullanılabilir seri bağlantı noktası yok

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Kapat
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Arama yapın veya adres yazın
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Adres yazın
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = { $name } ile ara
    .placeholder = Web’de ara
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = { $name } ile ara
    .placeholder = Aranacak terimleri yazın
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Yer imlerinde ara
    .placeholder = Aranacak terimleri yazın
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Geçmişte ara
    .placeholder = Aranacak terimleri yazın
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Sekmelerde ara
    .placeholder = Aranacak terimleri yazın
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Eylemlerde ara
    .placeholder = Aranacak terimleri yazın
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = { $name } ile arama yapın veya adres yazın
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Tarayıcı uzaktan kontrol ediliyor (sebep: { $component })
urlbar-permissions-granted =
    .tooltiptext = Bu siteye ek izinler verdiniz.
urlbar-switch-to-tab =
    .value = Sekmeye geç:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Uzantı:
urlbar-go-button2 =
    .title = Konum çubuğundaki adrese git
urlbar-page-action-button =
    .tooltiptext = Sayfa eylemleri
urlbar-revert-button =
    .tooltiptext = Konum çubuğunda adresi göster

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Gizli pencerede { $engine } ile ara
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Gizli pencerede ara
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine } ile ara
urlbar-result-action-sponsored = Sponsorlu
urlbar-result-action-switch-tab = Sekmeye geç
urlbar-result-action-move-tab-to-split-view = Sekmeyi ayrık görünüme taşı
urlbar-result-action-visit = Ziyaret et
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Sekmeye geç · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Adsız grup
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Panodan ziyaret et
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = { $engine } ile aramak için Tab tuşuna basın
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = { $engine } ile aramak için Tab tuşuna basın
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = { $engine } ile doğrudan adres çubuğundan arama yapın
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = { $engine } ile doğrudan adres çubuğundan arama yapın
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopyala
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = tanımsız
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } uzantısı
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Öneriliyor
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = { $region }, { $city } şu anda <strong>{ $temperature } °{ $unit }</strong>
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = { $city }, { $region }, { $country } şu anda <strong>{ $temperature } °{ $unit }</strong>
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = { $city } şu anda <strong>{ $temperature } °{ $unit }</strong>
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Sponsorlu
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Sor
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = En son { $date } ziyaret ettiniz
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] En son { $daysAgo } gün önce ziyaret ettiniz
       *[other] En son { $daysAgo } gün önce ziyaret ettiniz
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] En son { $weeksAgo } hafta önce ziyaret ettiniz
       *[other] En son { $weeksAgo } hafta önce ziyaret ettiniz
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] En son { $monthsAgo } ay önce ziyaret ettiniz
       *[other] En son { $monthsAgo } ay önce ziyaret ettiniz
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = En son { $date } tarihinde ziyaret ettiniz
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = { $date } tarihinde yer imlerine eklendi
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Son ziyaret: { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Son ziyaret: { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Son ziyaret: { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Borsa verilerine doğrudan arama çubuğunuzdan ulaşın
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Borsa verilerini ve iş ortaklarımızdan gelen haberleri görmek için arama sorgusu verilerinizi { -vendor-short-name } ile paylaşabilirsiniz. <a data-l10n-name="learn-more-link">Daha fazla bilgi alın</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Önerileri göster
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Şimdi değil
urlbar-result-realtime-opt-in-dismiss = Kapat
urlbar-result-realtime-opt-in-dismiss-all2 = Bu önerileri gösterme
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Borsa önerilerini gösterme
    .accesskey = B
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Borsa önerilerini gösterme
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Bu önerileri gösterme
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Borsa önerilerini gösterme
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Geri bildiriminiz için teşekkür ederiz. Artık borsa önerilerini görmeyeceksiniz.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Borsa önerileri
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Geri bildiriminiz için teşekkür ederiz. Artık bu önerileri görmeyeceksiniz.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } gün sonra
       *[other] { $name } · { $daysUntilStart } gün sonra
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } gün sonra başlıyor
       *[other] { $name } · { $daysUntilStart } gün sonra başlıyor
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · { $daysUntilEnd } gün sonra bitiyor
       *[other] { $name } · { $daysUntilEnd } gün sonra bitiyor
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Bugün
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Bugün bitiyor

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine } ile ara
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - { $localSearchMode } araması
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - { $engine } ile ara
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, arama motorunu değiştir
urlbar-searchmode-button-no-engine2 =
    .title = Kısayol seçilmemiş, kısayol seçin
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Anahtar kelimeyle arama devre dışı
urlbar-searchmode-dropmarker2 =
    .title = Bir arama motoru seçin
urlbar-searchmode-bookmarks4 = Yer imleri
urlbar-searchmode-tabs4 = Sekmeler
urlbar-searchmode-history4 = Geçmiş
urlbar-searchmode-actions4 = Eylemler
urlbar-searchmode-bookmarks3 = Yer imleri
    .accesskey = Y
urlbar-searchmode-tabs3 = Sekmeler
    .accesskey = S
urlbar-searchmode-history3 = Geçmiş
    .accesskey = G
urlbar-searchmode-actions3 = Eylemler
    .accesskey = E
urlbar-searchmode-exit-button2 =
    .title = Kapat
urlbar-searchmode-default2 =
    .title = Varsayılan arama motoru
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = “{ $engineName }” arama motorunu ekle
    .title = “{ $engineName }” arama motorunu ekle
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Burada ara:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Bununla ara:
urlbar-searchmode-popup-search-settings2 = Arama ayarları
urlbar-searchmode-popup-settings2 = Ayarlar
urlbar-searchmode-popup-search-settings = Arama ayarları
    .accesskey = A
urlbar-searchmode-popup-settings = Ayarlar
    .accesskey = A

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Yer imlerinde ara
urlbar-result-action-search-history = Geçmişte ara
urlbar-result-action-search-tabs = Sekmelerde ara
urlbar-result-action-search-actions = İşlemlerde ara
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = { $group } grubuna geç
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } grubunu aç

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Yeni sekmede aç
    .accesskey = Y
urlbar-view-context-menu-open-in-container-tab =
    .label = Yeni kapsayıcı sekmede aç
    .accesskey = k
urlbar-view-context-menu-open-in-window =
    .label = Yeni pencerede aç
    .accesskey = e
urlbar-view-context-menu-open-in-private-window =
    .label = Yeni gizli pencerede aç
    .accesskey = z
urlbar-view-context-menu-open-in-tab2 = Yeni sekmede aç
    .accesskey = Y
urlbar-view-context-menu-open-in-container-tab2 = Yeni kapsayıcı sekmede aç
    .accesskey = k
urlbar-view-context-menu-open-in-window2 = Yeni pencerede aç
    .accesskey = e
urlbar-view-context-menu-open-in-private-window2 = Yeni gizli pencerede aç
    .accesskey = z
urlbar-view-context-menu-search-in-tab = Yeni sekmede ara
    .accesskey = s
urlbar-view-context-menu-search-in-container-tab = Yeni kapsayıcı sekmede ara
    .accesskey = k
urlbar-view-context-menu-search-in-window = Yeni pencerede ara
    .accesskey = e
urlbar-view-context-menu-search-in-private-window = Yeni gizli pencerede ara
    .accesskey = z
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Tab tuşunu kullanırken bu menüyü atla
    .accesskey = T

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } Önerileri
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Hızlı Eylemler
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Son Aramalar
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } arama trendleri
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Arama trendlerini gösterme
    .accesskey = A
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Arama trendlerini gösterme
    .accesskey = A
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Arama trendlerini gösterme
    .accesskey = A
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Geri bildiriminiz için teşekkür ederiz. Artık arama trendlerini görmeyeceksiniz.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Okuyucu Görünümü'ne geç
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Okuyucu görünümünü kapat

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Görüntü içinde görüntüyü aç ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Görüntü içinde görüntüyü kapat ({ $shortcut })
picture-in-picture-panel-header = Görüntü içinde görüntü
picture-in-picture-panel-headline = Bu web sitesi görüntü içinde görüntüyü önermiyor
picture-in-picture-panel-body = Görüntü içinde görüntüyü açarsanız videolar geliştiricinin amaçladığı gibi görünmeyebilir.
picture-in-picture-enable-toggle =
    .label = Yine de etkinleştir

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> artık tam ekran
fullscreen-warning-no-domain = Bu belge artık tam ekran
fullscreen-exit-button = Tam ekrandan çık (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Tam ekrandan çık (esc)
fullscreen-keyboardlock-exit-button = Tam ekrandan çık (Esc tuşunu basılı tutun)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Tam ekrandan çık (esc tuşunu basılı tutun)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> işaretçinizi kontrol ediyor. Kontrolü geri almak için Esc tuşuna basın.
pointerlock-warning-no-domain = Bu belge işaretçinizi kontrol ediyor. Kontrolü geri almak için Esc tuşuna basın.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Yer imlerini yönet
bookmarks-recent-bookmarks-panel-subheader = Son yer imleri
bookmarks-toolbar-chevron =
    .tooltiptext = Daha fazla yer imi göster
bookmarks-sidebar-content =
    .aria-label = Yer imleri
bookmarks-menu-button =
    .label = Yer imleri menüsü
bookmarks-other-bookmarks-menu =
    .label = Diğer yer imleri
bookmarks-mobile-bookmarks-menu =
    .label = Mobil yer imleri

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Yer imleri kenar çubuğunu gizle
           *[other] Yer imleri kenar çubuğunu göster
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Yer imleri araç çubuğunu gizle
           *[other] Yer imleri araç çubuğunu göster
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Yer imleri araç çubuğunu gizle
           *[other] Yer imleri araç çubuğunu göster
        }

##

bookmarks-search =
    .label = Yer imlerinde ara
bookmarks-tools =
    .label = Yer imi araçları
bookmarks-subview-edit-bookmark =
    .label = Bu yer imini düzenle…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Yer imleri
    .toolbarname = Yer imleri araç çubuğu
    .accesskey = Y
bookmarks-toolbar-menu =
    .label = Yer imleri araç çubuğu
bookmarks-toolbar-placeholder =
    .title = Yer imleri araç çubuğu öğeleri
bookmarks-toolbar-placeholder-button =
    .label = Yer imleri araç çubuğu öğeleri
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Bu sekmeyi yer imlerine ekle…

## Library Panel items

library-bookmarks-menu =
    .label = Yer imleri

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Metin kodlamasını onar
    .tooltiptext = Sayfa içeriğinden doğru metin kodlamasını tahmin et

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Ayarlar
    .tooltiptext =
        { PLATFORM() ->
            [macos] Ayarları aç ({ $shortcut })
           *[other] Ayarları aç
        }
toolbar-overflow-customize-button =
    .label = Araç çubuğunu özelleştir…
    .accesskey = u
toolbar-button-email-link =
    .label = Bağlantıyı e-postala
    .tooltiptext = Bu sayfanın linkini e-postayla gönder
toolbar-button-logins =
    .label = Parolalar
    .tooltiptext = Kayıtlı parolalarımı görüntüle ve yönet
qrcode-panel-error =
    .message = QR kodu oluşturulamadı. Lütfen yeniden deneyin.
qrcode-copy-button =
    .label = Kopyala
qrcode-copy-success =
    .message = QR kodu panoya kopyalandı.
qrcode-copy-error =
    .message = QR kodu kopyalanamadı.
qrcode-save-button =
    .label = Kaydet
qrcode-window-title = QR kodu
qrcode-dialog-title = QR kodu
qrcode-image =
    .aria-label = QR kodu
qrcode-close-button =
    .aria-label = Kapat
toolbar-button-save-page =
    .label = Sayfayı kaydet
    .tooltiptext = Bu sayfayı kaydet ({ $shortcut })
toolbar-button-open-file =
    .label = Dosya aç
    .tooltiptext = Dosya aç ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Eşitlenmiş sekmeler
    .tooltiptext = Diğer cihazlardaki sekmeleri göster
toolbar-button-send-tab =
    .label = Sekmeyi gönder
    .tooltiptext = Geçerli sekmeyi başka bir cihaza gönder
toolbar-button-new-private-window =
    .label = Yeni gizli pencere
    .tooltiptext = Yeni bir Gizli Gezinti penceresi aç ({ $shortcut })
toolbar-button-share-tab =
    .label = Paylaş
    .tooltiptext = Bu sayfayı paylaş
toolbar-button-tab-groups =
    .label = Sekme grupları
    .tooltiptext = Sekme gruplarımı göster
toolbar-button-history =
    .label = Geçmiş
    .tooltiptext = Geçmişimi göster ({ $shortcut })
toolbar-button-find =
    .label = Bul
    .tooltiptext = Bu sayfada bul ({ $shortcut })
toolbar-button-developer =
    .label = Geliştirici
    .tooltiptext = Web geliştirici araçlarını aç ({ $shortcut })
toolbar-button-forget =
    .label = Unut
    .tooltiptext = Gezinti geçmişimin bir kısmını unut
toolbar-zoom-controls =
    .label = Yakınlaştırma düğmeleri
    .title = Yakınlaştırma düğmeleri
toolbar-button-zoom-out =
    .label = Uzaklaştır
    .tooltiptext = Uzaklaştır ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Yakınlaştırma düzeyini sıfırla ({ $shortcut })
toolbar-button-zoom-in =
    .label = Yakınlaştır
    .tooltiptext = Yakınlaştır ({ $shortcut })
toolbar-edit-controls =
    .label = Düzenleme düğmeleri
    .title = Düzenleme düğmeleri
toolbar-button-cut =
    .label = Kes
    .tooltiptext = Kes ({ $shortcut })
toolbar-button-copy =
    .label = Kopyala
    .tooltiptext = Kopyala ({ $shortcut })
toolbar-button-paste =
    .label = Yapıştır
    .tooltiptext = Yapıştır ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrkodu
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrkodu-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Bu sitedeki bazı ses veya videolar DRM yazılımı kullanıyor. Bu yazılım, { -brand-short-name } ile yapabileceklerinizi kısıtlayabilir.
eme-notifications-drm-content-playing-manage = Ayarları yönet
eme-notifications-drm-content-playing-manage-accesskey = A
eme-notifications-drm-content-playing-dismiss = Kapat
eme-notifications-drm-content-playing-dismiss-accesskey = K

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Bu sayfadaki bazı ses veya videoları oynatmak için DRM’i etkinleştirmelisiniz.
eme-notifications-drm-content-disabled-button =
    .label = DRM’i etkinleştir
    .accesskey = D
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } bu sayfadaki ses ve videoyu oynatmak için gereken bileşenleri yüklüyor. Lütfen daha sonra tekrar deneyin.
decoder-doctor-no-codecs-linux-message = Video oynatmak için gereken video codec’lerini yüklemeniz gerekebilir.
decoder-doctor-no-hw-acceleration-message = Video kalitesini yükseltmek için Microsoft’tan Media Feature Pack’i yüklemeniz gerekebilir.
decoder-doctor-no-pulse-audio-message = Ses çalmak için gereken PulseAudio yazılımını yüklemeniz gerekebilir.
decoder-doctor-unsupported-libavcodec-message = libavcodec güvenli değil veya desteklenmiyor. Video oynatmak için güncellenmesi gerekiyor.
decoder-doctor-decode-error-message = Bir multimedya kaynağı çözülürken hata oluştu.
decoder-doctor-decode-warning-message = Bir multimedya kaynağı çözülürken kurtarılabilir bir hata oluştu.
decoder-doctor-learn-how-link = Nasıl yapılacağını öğren
decoder-doctor-report-issue-button =
    .label = Site sorununu bildir
    .accesskey = S
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = { $pluginName } yan uygulaması çöktü.
plugin-crashed-notification-reload-button =
    .label = Sayfayı tazele
    .accesskey = S
plugin-crashed-notification-submit-button =
    .label = Çökme raporu gönder
    .accesskey = r

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Aldatıcı site!
safebrowsing-reported-attack-site-message = Saldırı sitesi olarak bildirilmiş!
safebrowsing-reported-unwanted-site-message = İstenmeyen yazılım sitesi!
safebrowsing-reported-harmful-site-message = Bu sitenin zararlı olabileceği bildirildi!
safebrowsing-get-me-out-of-here-button =
    .label = Beni buradan kurtar!
    .accesskey = k
safebrowsing-not-a-deceptive-site-button =
    .label = Bu site aldatıcı değil…
    .accesskey = d
safebrowsing-not-an-attack-site-button =
    .label = Bu bir saldırı sitesi değil…
    .accesskey = d

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = İnternete erişebilmek için önce bu ağa giriş yapmalısınız.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Ağa giriş sayfasını aç

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = { $hostName } adresine mi gitmek istemiştiniz?
keyword-uri-fixup-go-to-button =
    .label = Evet, { $hostName } adresine git
    .accesskey = E

## Password save/update panel

panel-save-update-username-2 =
    .label = Kullanıcı adı
panel-save-update-password-2 =
    .label = Parola

##

# "More" item in macOS share menu
menu-share-more =
    .label = Daha fazla…
menu-share-windows =
    .label = Diğer seçenekler
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Bağlantıyı kopyala
           *[other] { $count } bağlantıyı kopyala
        }
    .accesskey = B
ui-tour-info-panel-close =
    .tooltiptext = Kapat

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = { $uriHost } için açılır pencerelere ve üçüncü taraf yönlendirmelerine izin ver
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = Görüntü içinde görüntü düğmesini gizle
    .accesskey = G

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Görüntü içinde görüntü düğmesini sağa taşı
    .accesskey = G
picture-in-picture-move-toggle-left =
    .label = Görüntü içinde görüntü düğmesini sola taşı
    .accesskey = ö

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Gezinme
navbar-downloads =
    .label = İndirilenler
navbar-overflow-2 =
    .tooltiptext = Daha fazla araç
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Yazdır
    .tooltiptext = Bu sayfayı yazdır… ({ $shortcut })
navbar-home =
    .label = Başlangıç
    .tooltiptext = { -brand-short-name } Giriş Sayfası
navbar-library =
    .label = Arşiv
    .tooltiptext = Geçmişinize, kayıtlı yer imlerinize ve daha fazlasına bakın
navbar-search =
    .title = Ara
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Tarayıcı sekmeleri
tabs-toolbar-new-tab =
    .label = Yeni sekme
tabs-toolbar-list-all-tabs-2 =
    .label = Sekmeleri ara ve yönet
    .tooltiptext = Sekmeleri ara ve yönet
tabs-toolbar-list-all-tabs =
    .label = Tüm sekmeleri listele
    .tooltiptext = Tüm sekmeleri listele

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Sekmeyi sabitlemek için buraya bırakın

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Önceki sekmeler açılsın mı?</strong> Önceki oturumunuzu { -brand-short-name } menüsündeki (<img data-l10n-name="icon"/>) “Geçmiş” kısmından geri yükleyebilirsiniz.
restore-session-startup-suggestion-button = Nasıl yapacağımı göster

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Kuruluşunuz bu bilgisayardaki yerel dosyalara erişimi engelledi

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } artık sekmelerde arama yapıyor
urlbar-addons-shortcut-moved-description = Uzantıları ve temaları açmak için { $addonsShortcut } kısayolunu kullanın.
urlbar-addons-shortcut-moved-change-shortcuts = Kısayolları yönet
urlbar-addons-shortcut-moved-dismiss = Tamam

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name }, deneyiminizi geliştirebilmemiz için bazı verileri otomatik olarak { -vendor-short-name } sunucularına gönderir.
data-reporting-notification-button =
    .label = Ne paylaşacağımı seç
    .accesskey = N
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Gizli gezinti
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Gizli gezinti
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Gizli gezinti bilgileri
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Gizli penceredesiniz
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Bu pencere, gezintinizi bu bilgisayardaki diğer kullanıcılardan gizler ama sizi internette görünmez yapmaz. <a data-l10n-name="learn-more">Gezdiğim siteleri kimler görebilir?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = { $agentName } veri kaybı önleme (DLP). Daha fazla bilgi için tıklayın.
content-analysis-panel-title2 = Veri kaybı önleme
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Kuruluşunuz hassas verilerin nasıl paylaşılabileceğini denetlemek için <b>{ $agentName }</b> kullanıyor. <a data-l10n-name="info">Daha fazla bilgi alın</a>
content-analysis-panel-title = Veri koruması
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Kuruluşunuz veri kaybını önlemek için <b>{ $agentName }</b> kullanıyor. <a data-l10n-name="info">Daha fazla bilgi al</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Uzantılar
    .tooltiptext = Uzantılar

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Uzantılar
    .tooltiptext =
        Uzantılar
        İzin gerekli

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Uzantılar
    .tooltiptext = Bazı uzantılara izin verilmiyor

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Uzantılar
    .tooltiptext =
        Uzantılar
        Bazı uzantılar devre dışı

## Private browsing reset button

reset-pbm-panel-heading2 = Veriler temizlenip yeni bir gizli oturum başlatılsın mı?
reset-pbm-panel-description3 = Bu işlem, geçmişinizi ve çerezlerinizi temizleyip sitelerdeki oturumlarınızı kapatır. Gizli pencereleriniz kapanır ve yeni bir gizli pencere açılır.
reset-pbm-panel-description2 = Bu işlem, gizli pencerenizi kapatmadan geçmişi, çerezleri ve tüm site verilerini siler.
reset-pbm-panel-always-ask-checkbox =
    .label = Her zaman sor
    .accesskey = H
reset-pbm-panel-cancel-button =
    .label = Vazgeç
    .accesskey = V
reset-pbm-panel-confirm-button2 =
    .label = Gizli oturumu temizle
    .accesskey = z
reset-pbm-panel-complete = Gizli oturum verileri silindi
reset-pbm-toolbar-button2 =
    .label = Gizli oturumu temizle
    .tooltiptext = Gizli oturumu temizle

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Tüm gezinti verileri silinsin mi?
fire-button-panel-description = Bu işlem geçmişi, çerezleri ve site verilerini siler. Sitelerdeki oturumlarınız sonlandırılır. Bu pencere kapanır ve yeni bir { -brand-short-name } penceresi açılır.
fire-button-panel-choose-description = Her şeyi silmek istemiyorsanız yalnızca silinecek verileri seçin.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Seç…
fire-button-panel-cancel-button =
    .label = Vazgeç
    .accesskey = V
fire-button-panel-confirm-button =
    .label = Tümünü sil
    .accesskey = T
fire-button-panel-complete = Gezinti verileri silindi
fire-button-toolbar-button2 =
    .label = Verilerin bir kısmını veya tamamını sil
    .tooltiptext = Gezinti verilerimin bir kısmını veya tamamını sil

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } bu sayfanın kendiliğinden yenilenmesini önledi.
refresh-blocked-redirect-label = { -brand-short-name } bu sayfanın başka sayfaya yönlenmesini önledi.
refresh-blocked-allow =
    .label = İzin ver
    .accesskey = z

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Güvenli, kullanımı kolay maskelerimiz kimliğinizi korur ve e-posta adresinizi gizleyerek istenmeyen e-postaları önler.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = E-posta maskelerinize gönderilen tüm e-postalar <strong>{ $useremail }</strong> adresine yönlendirilecektir (siz engellemeye karar vermediğiniz sürece).
firefox-relay-offer-legal-notice = “E-posta maskesi kullan”a tıkladığınızda <label data-l10n-name="tos-url">Hizmet Koşulları</label>’nı ve <label data-l10n-name="privacy-url">Gizlilik Bildirimi</label>’ni kabul etmiş sayılırsınız.
firefox-relay-offer-legal-notice-1 = Kaydolup e-posta maskesi oluşturduğunuzda <label data-l10n-name="tos-url">Hizmet Koşulları</label>’nı ve <label data-l10n-name="privacy-url">Gizlilik Bildirimi</label>’ni kabul etmiş sayılırsınız.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Doğrulanmamış)
popup-notification-xpinstall-prompt-learn-more = Eklentileri güvenle yükleme hakkında daha fazla bilgi alın
popup-notification-xpinstall-prompt-block-url = Ayrıntıları göster
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Uzantının gizli pencerelerde çalışmasına izin ver
    .accesskey = U
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Teknik verileri ve etkileşim verilerini uzantı geliştiricisiyle paylaş
    .accesskey = T

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } bu sitenin açılır pencere açmasını engelledi.
       *[other] { -brand-short-name } bu sitenin { $popupCount } açılır pencere açmasını engelledi.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } bu sitenin sizi yönlendirmesini engelledi.
        [1] { -brand-short-name } bu sitenin açılır pencere açmasını ve sizi yönlendirmesini engelledi.
        [one] { -brand-short-name } bu sitenin { $popupCount } açılır pencere açmasını ve sizi yönlendirmesini engelledi.
       *[other] { -brand-short-name } bu sitenin { $popupCount } açılır pencere açmasını ve sizi yönlendirmesini engelledi.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message =
    { $popupCount ->
        [one] { -brand-short-name } bu sitenin { $popupCount } adetten fazla açılır pencere açmasını engelledi.
       *[other] { -brand-short-name } bu sitenin { $popupCount } adetten fazla açılır pencere açmasını engelledi.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } bu sitenin en az { $popupCount } açılır pencere açmasını ve sizi yönlendirmesini engelledi.
       *[other] { -brand-short-name } bu sitenin en az { $popupCount } açılır pencere açmasını ve sizi yönlendirmesini engelledi.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Seçenekler
           *[other] Tercihler
        }
    .accesskey =
        { PLATFORM() ->
            [windows] S
           *[other] T
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = “{ $popupURI }” penceresini göster
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = “{ $redirectURI }” sayfasını göster

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Windows dosya iletişim kutusu açılamadı. Hiçbir dosya veya klasör seçilemedi.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Windows dosya iletişim kutusu açılamadı. Dosya { $path } konumuna kaydedilecek.
file-picker-failed-save-nowhere = Windows dosya iletişim kutusu açılamadı. Varsayılan klasör bulunamadı. Dosya kaydedilmeyecektir.
file-picker-crashed-open = Windows dosya iletişim kutusu çöktü. Hiçbir dosya veya klasör seçilemedi.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows dosya iletişim kutusu çöktü. Dosya { $path } konumuna kaydedilecek.
file-picker-crashed-save-nowhere = Windows dosya iletişim kutusu çöktü. Varsayılan klasör bulunamadı. Dosya kaydedilmeyecektir.
file-picker-crashed-show-in-folder =
    .label = Klasörde göster
    .accessKey = l

## Unsigned add-ons notification

unsigned-addons-disabled-message = Yüklü eklentilerden biri veya birkaçı doğrulanamadığı için devre dışı bırakıldı.
unsigned-addons-disabled-learn-more =
    .label = Daha fazla bilgi alın
    .accesskey = D

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Bu sayfa { -brand-short-name } tarayıcınızı yavaşlatıyor. Tarayıcınızı hızlandırmak için bu sayfayı durdurabilirsiniz.
process-hang-nonspecific-tab-message = Bir web sayfası { -brand-short-name } tarayıcınızı yavaşlatıyor. Tarayıcınızı hızlandırmak için o sayfayı durdurabilirsiniz.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” { -brand-short-name } tarayıcınızı yavaşlatıyor. Tarayıcınızı hızlandırmak için o sayfayı durdurabilirsiniz.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” { -brand-short-name } tarayıcınızı yavaşlatıyor. Tarayıcınızı hızlandırmak için bu uzantıyı durdurabilirsiniz.
process-hang-addon-learn-more =
    .value = Daha fazla bilgi al
process-hang-stop-button =
    .label = Durdur
    .accesskey = D

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Kurulumu tamamla
onboarding-aw-finish-setup-button =
    .label = Kurulumu tamamla
    .tooltiptext = { -brand-short-name } kurulumunu tamamlayın

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Gelişmiş izlenme koruması açık
trustpanel-etp-label-disabled = Gelişmiş izlenme koruması kapalı
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Gelişmiş izlenme koruması: { $host } için açık
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Gelişmiş izlenme koruması: { $host } için kapalı
trustpanel-etp-description-enabled = Site bozuk görünüyorsa korumaları kapatmayı deneyin.
trustpanel-etp-description-disabled = { -brand-product-name } şirketlerin sizi daha az takip etmesi gerektiğini düşünüyor. Korumaları açtığınızda mümkün olduğunca çok sayıda takip kodunu engelliyoruz.
trustpanel-connection-label-secure = Bağlantı güvenli
trustpanel-connection-label-insecure = Bağlantı güvenli değil
trustpanel-header-enabled = { -brand-product-name } sizi koruyor
trustpanel-description-enabled2 = Koruma altındasınız. Bir şey tespit edersek size haber vereceğiz.
trustpanel-header-enabled-insecure = Bu sitede dikkatli olun
trustpanel-description-enabled-insecure = { -brand-product-name } şüpheli bir şey fark etti.
trustpanel-header-disabled = Korumaları kapattınız
trustpanel-description-disabled = { -brand-product-name } kapalı. Korumaları yeniden açmanızı öneririz.
trustpanel-clear-cookies-button = Çerezleri ve site verilerini temizle
trustpanel-privacy-link = Gizlilik ayarları
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = { $host } çerezlerini ve site verilerini temizle
trustpanel-clear-cookies-description = Çerezleri ve site verilerini temizlerseniz sitelerdeki oturumlarınız kapanabilir ve alışveriş sepetleriniz boşalabilir.
trustpanel-clear-cookies-subview-button-clear = Temizle
trustpanel-clear-cookies-subview-button-cancel = Vazgeç
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = { $host } bağlantı korumaları
trustpanel-siteinformation-morelink = Daha fazla site bilgisi
trustpanel-blocker-see-all = Tümünü göster
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = { $host } izlenme korumaları
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Güvenli değil
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } takip kodu engellendi
       *[other] { $count } takip kodu engellendi
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } şirketlerin sizi daha az takip etmesi gerektiğini düşünüyor. O yüzden mümkün olduğunca çok takip kodunu engelliyoruz.
trustpanel-blocked-header = { -brand-product-name } sizin için aşağıdakileri engelledi:
trustpanel-tracking-header = Sitelerin bozulmasını önlemek için { -brand-product-name } aşağıdakilere izin verdi:
trustpanel-tracking-description = Takip kodları olmadan bazı düğmeler, formlar ve giriş alanları çalışmayabilir.
trustpanel-insecure-section-header = Bağlantınız güvenli değil
trustpanel-insecure-description = Bu siteye gönderdiğiniz veriler şifrelenmemiştir. Bu veriler görüntülenebilir, çalınabilir veya üzerinde değişiklik yapılabilir.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } siteler arası takip çerezi
       *[other] { $count } siteler arası takip çerezi
    }
trustpanel-list-label-tracking-content = Takip amaçlı içerikler
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } parmak izi toplayıcı
       *[other] { $count } parmak izi toplayıcı
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } sosyal medya takip kodu
       *[other] { $count } sosyal medya takip kodu
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } kripto madencisi
       *[other] { $count } kripto madencisi
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } sosyal medya takip kodunu engelledi
       *[other] { -brand-product-name } { $count } sosyal medya takip kodunu engelledi
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } sosyal medya takip koduna izin verdi
       *[other] { -brand-product-name } { $count } sosyal medya takip koduna izin verdi
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } siteler arası takip çerezini engelledi
       *[other] { -brand-product-name } { $count } siteler arası takip çerezini engelledi
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } siteler arası takip çerezine izin verdi
       *[other] { -brand-product-name } { $count } siteler arası takip çerezine izin verdi
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } takip kodunu engelledi
       *[other] { -brand-product-name } { $count } takip kodunu engelledi
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } takip koduna izin verdi
       *[other] { -brand-product-name } { $count } takip koduna izin verdi
    }
trustpanel-tracking-content-tab-list-header = Bu siteler sizi izlemeye çalışıyor:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } parmak izi toplayıcıyı engelledi
       *[other] { -brand-product-name } { $count } parmak izi toplayıcıyı engelledi
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } parmak izi toplayıcıya izin verdi
       *[other] { -brand-product-name } { $count } parmak izi toplayıcıya izin verdi
    }
trustpanel-fingerprinter-list-header = Bu siteler parmak izinizi almaya çalışıyor:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } kripto madenciyi engelledi
       *[other] { -brand-product-name } { $count } kripto madenciyi engelledi
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } { $count } kripto madenciye izin verdi
       *[other] { -brand-product-name } { $count } kripto madenciye izin verdi
    }
trustpanel-cryptominer-tab-list-header = Bu siteler kripto madenciliği yapmaya çalışıyor:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Bu sitede hesabınız var mı?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } bu sitenin son 12 ay içinde veri ihlali yaşadığını tespit etti. Etkilenip etkilenmediğinizi öğrenin.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Kapat
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Ücretsiz taramayı başlat
trustpanel-blocker-section-header2 =
    { $count ->
        [one] Bu sitede <span data-l10n-name="count">{ $count }</span> takip kodu engellendi
       *[other] Bu sitede <span data-l10n-name="count">{ $count }</span> takip kodu engellendi
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Site bozuk mu görünüyor?</strong> İzlenme korumanızı geçici olarak azaltmak için sayfayı tazeleyin.
reduced-protection-infobar-reload-button = Tazele
    .accesskey = z
reduced-protection-infobar-never-show-button = Bir daha gösterme
    .accesskey = B


identity-allow-site-data = vOrbit-lite: Bu site için çerezleri/verileri her zaman sakla
