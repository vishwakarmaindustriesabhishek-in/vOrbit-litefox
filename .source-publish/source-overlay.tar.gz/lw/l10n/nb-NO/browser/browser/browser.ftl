# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } Privat nettlesing
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Rask og privat nettsurfing
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Privat nettlesing
       *[other] { -brand-full-name } Privat nettlesing
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Privat nettlesing
popups-infobar-dont-show-message2 =
    .label = Ikke vis denne meldingen når sprettoppvinduer eller tredjepartvideresendinger er blokkert
    .accesskey = k
edit-popup-settings2 =
    .label = Behandle innstillinger for sprettoppvinduer og tredjepartvideresendinger …
    .accesskey = B
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Vis informasjon om nettstedet
            [1] Vis informasjon om nettstedet (1 sporer blokkert)
           *[other] Vis informasjon om nettstedet ({ $count } sporere blokkert)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } lenke
           *[other] { $count } lenker
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Meldinger og mer …
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Meldinger, Mail og mer…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Del…
    .accesskey = D
urlbar-identity-button =
    .aria-label = Vis nettstedsinformasjon

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Åpne meldingspanel for installasjon
urlbar-web-notification-anchor =
    .tooltiptext = Velg om du kan motta varsler fra nettstedet
urlbar-midi-notification-anchor =
    .tooltiptext = Åpne MIDI-panelet
urlbar-serial-notification-anchor =
    .tooltiptext = Åpne serieportpanelet
urlbar-eme-notification-anchor =
    .tooltiptext = Behandle bruk av DRM-programmer
urlbar-web-authn-anchor =
    .tooltiptext = Åpne webautentiseringspanelet
urlbar-canvas-notification-anchor =
    .tooltiptext = Håndter rettigheter for uttrekking av canvas-data
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Behandle deling av mikrofon med dette nettstedet
urlbar-default-notification-anchor =
    .tooltiptext = Åpne meldingspanel
urlbar-geolocation-notification-anchor =
    .tooltiptext = Åpne panel for stedsforespørsel
urlbar-localhost-notification-anchor =
    .tooltiptext = Behandle lokal enhetstilgang for dette nettstedet
urlbar-local-network-notification-anchor =
    .tooltiptext = Behandle deling av lokal nettverkstilgang med dette nettstedet
urlbar-xr-notification-anchor =
    .tooltiptext = Åpne autoriseringspanelet for virtuell virkelighet
urlbar-storage-access-anchor =
    .tooltiptext = Åpne autoriseringspanelet for nettleseraktivitet
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Behandle deling av vinduer eller skjerm med nettstedet
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Åpne meldingspanel for frakoblet data
urlbar-password-notification-anchor =
    .tooltiptext = Åpne meldingspanel for lagring av passord
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Behandle deling av kamera og/eller mikrofon på dette nettstedet
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Behandle deling av andre høyttalere med nettstedet
urlbar-autoplay-notification-anchor =
    .tooltiptext = Åpne automatisk avspilling-panelet
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Lagre data i vedvarende lagring
urlbar-addons-notification-anchor =
    .tooltiptext = Åpne meldingspanel for utvidelsesinstallasjon
urlbar-search-tips-confirm = Ok, jeg forstår
urlbar-search-tips-confirm-short = Jeg forstår
urlbar-result-menu-button =
    .title = Åpne meny
urlbar-result-menu-button-feedback = Tilbakemelding
    .title = Åpne meny
urlbar-result-menu-learn-more2 = Les mer
    .accesskey = L
urlbar-result-menu-remove-from-history2 = Fjern fra historikk
    .accesskey = F
urlbar-result-menu-tip-get-help2 = Få hjelp
    .accesskey = F
urlbar-result-menu-dismiss-suggestion2 = Avvis dette forslaget
    .accesskey = A
urlbar-result-menu-remove-top-site = Fjern dette mest besøkte nettstedet
    .accesskey = F
urlbar-result-menu-manage-firefox-suggest2 = Behandle { -firefox-suggest-brand-name }
    .accesskey = B
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Rapporter unøyaktig plassering
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = Vis sjeldnere
    .accesskey = V
urlbar-result-menu-dont-show-weather-suggestions3 = Ikke vis værforslag
    .accesskey = k
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Rapporter unøyaktig plassering
urlbar-result-menu-show-less-frequently2 = Vis sjeldnere
urlbar-result-menu-dont-show-weather-suggestions2 = Ikke vis værforslag
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Avvis dette forslaget
    .accesskey = v
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Fjern fra historikk
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = Les mer
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = Fjern fra historikk
    .accesskey = F
urlbar-result-menu-tip-get-help =
    .label = Få hjelp
    .accesskey = F
urlbar-result-menu-dismiss-suggestion =
    .label = Avvis dette forslaget
    .accesskey = A
urlbar-result-menu-manage-firefox-suggest =
    .label = Behandle { -firefox-suggest-brand-name }
    .accesskey = B
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Rapporter unøyaktig plassering
urlbar-result-menu-show-less-frequently =
    .label = Vis sjeldnere
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Ikke vis værforslag
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Åpne meny
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Takk for tilbakemeldingen
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Takk for tilbakemeldingen din. Du vil ikke lenger se værforslag.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Skriv mindre, finn mer: Søk med { $engineName } direkte fra adresselinjen din.
urlbar-search-tips-redirect-2 = Start ditt søk i adressefeltet for å se forslag fra { $engineName } og din nettleserhistorikk.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Velg denne snarveien for å finne det du trenger raskere.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Bokmerker
urlbar-search-mode-tabs = Faner
urlbar-search-mode-history = Historikk
urlbar-search-mode-actions = Handlinger

##

urlbar-geolocation-blocked =
    .tooltiptext = Du har blokkert plasseringsinformasjon for dette nettstedet.
urlbar-localhost-blocked =
    .tooltiptext = Du har blokkert lokale enhetstilkoblinger for dette nettstedet.
urlbar-local-network-blocked =
    .tooltiptext = Du har blokkert lokale nettverkstilkoblinger for dette nettstedet.
urlbar-xr-blocked =
    .tooltiptext = Du har blokkert tilgang for virtuell virkelighetsenhet for dette nettstedet.
urlbar-web-notifications-blocked =
    .tooltiptext = Du har blokkert varsler for dette nettstedet.
urlbar-camera-blocked =
    .tooltiptext = Du har blokkert kameraet for dette nettstedet.
urlbar-microphone-blocked =
    .tooltiptext = Du har blokkert mikrofonen for dette nettstedet.
urlbar-screen-blocked =
    .tooltiptext = Du har blokkert dette nettstedet fra å dele din skjerm.
urlbar-persistent-storage-blocked =
    .tooltiptext = Du har blokkert vedvarende lagring for denne nettsiden.
urlbar-popup-blocked2 =
    .tooltiptext = Du har blokkert sprettoppvinduer og tredjepartvideresendinger for dette nettstedet.
urlbar-autoplay-media-blocked =
    .tooltiptext = Du har blokkert automatisk avspilling av medier med lyd på dette nettstedet.
urlbar-canvas-blocked =
    .tooltiptext = Du har blokkert uttrekking av canvas-data for dette nettstedet.
urlbar-midi-blocked =
    .tooltiptext = Du har blokkert MIDI-tilgang for dette nettstedet.
urlbar-serial-blocked =
    .tooltiptext = Du har blokkert serieport-tilgang for dette nettstedet.
urlbar-install-blocked =
    .tooltiptext = Du har blokkert installasjon av utvidelser for dette nettstedet.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Rediger dette bokmerket ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Bokmerk denne siden ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Delt visning
    .tooltiptext = Delt visning

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Lim inn og åpne
    .accesskey = L
urlbar-menuitem-paste-and-search =
    .label = Lim inn og søk
    .accesskey = s

## Searchbar context menu

clear-search-history =
    .label = Tøm søkehistorikk
    .accesskey = T

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Behandle utvidelse…
    .accesskey = e
page-action-remove-extension2 =
    .label = Fjern utvidelse
    .accesskey = u

## Auto-hide Context Menu

full-screen-autohide =
    .label = Skjul verktøylinjer
    .accesskey = S
full-screen-exit =
    .label = Avslutt fullskjermmodus
    .accesskey = v

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Søk denne gangen med:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Endre søkeinnstillinger
search-one-offs-context-open-new-tab =
    .label = Søk i ny fane
    .accesskey = f
search-one-offs-context-set-as-default =
    .label = Bruk som standard søkemotor
    .accesskey = B
search-one-offs-context-set-as-default-private =
    .label = Angi som standard søkemotor for private vindu
    .accesskey = p
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Legg til søkemotor «{ $engineName }»
    .label = Legg til «{ $engineName }»
    .tooltiptext = Legg til søkemotor «{ $engineName }»
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Legg til søkemotor
    .accesskey = L
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Legg til søkemotor

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Bokmerker ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Faner ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historikk ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Handlinger ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Vis tillegg
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = utvidelser, temaer, tillegg
# Opens preferences page at AI controls
quickactions-manageai = Behandle AI-kontroller
quickactions-cmd-manageai = deaktivere ai, slå av ai, behandle ai, administrer ai, deaktivere ki, slå av ki, behandle ki, administrer ki
# Opens the bookmarks library window
quickactions-bookmarks2 = Behandle bokmerker
quickactions-cmd-bookmarks = bokmerker
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Tøm nylig historikk
quickactions-cmd-clearrecenthistory2 = infokapsler, slett infokapsler, informasjonskapsler, slett informasjonskapsler, hurtigbuffer, tøm hurtigbuffer, nettlesingsdata, slett nettlesingsdata, historikk, slett nylig historikk
# Opens about:downloads page
quickactions-downloads2 = Vis nedlastinger
quickactions-cmd-downloads = nedlastinger
# Opens about:addons page in the extensions section
quickactions-extensions = Behandle utvidelser
quickactions-cmd-extensions2 = utvidelser, tillegg
# Opens Firefox View
quickactions-firefoxview = Åpne { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = åpne { -firefoxview-brand-name }, { -firefoxview-brand-name }, åpne oversikt, oversikt
# Opens SUMO home page
quickactions-help = { -brand-product-name }-hjelp
quickactions-cmd-help = hjelp, støtte, support
# Opens the devtools web inspector
quickactions-inspector2 = Åpne utviklerverktøy
quickactions-cmd-inspector2 = inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Velg en farge
quickactions-cmd-colorpicker = fargevelger, pipette, velg farge
# Opens Firefox Library
quickactions-cmd-library = bibliotek
quickactions-library = Åpne bibliotek
# Opens about:logins
quickactions-logins2 = Behandle passord
quickactions-cmd-logins = innlogginger, passord
# Mutes all tabs playing audio
quickactions-mute = Demp faner som spiller av lyd
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = demp, stille, tyss, hysj, sssssh
# Opens the print dialog
quickactions-print2 = Skriv ut side
quickactions-cmd-print = utskrift, skriv ut
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Lagre side som PDF
quickactions-cmd-savepdf2 = pdf, lagre side
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Åpne PDF-redigerer
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Åpne privat vindu
quickactions-cmd-private = privat nettlesing
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Tilbakestill { -brand-short-name }
quickactions-cmd-refresh = oppdater
# Restarts the browser
quickactions-restart = Start { -brand-short-name } på nytt
quickactions-cmd-restart = omstart, start på nytt
# Opens the screenshot tool
quickactions-screenshot3 = Ta et skjermbilde
quickactions-cmd-screenshot2 = skjermbilde, ta et skjermbilde
# Opens about:translations
quickactions-translate = Oversett
quickactions-cmd-translate = oversett
# Opens about:preferences
quickactions-settings2 = Behandle innstillinger
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = innstillinger, preferanser, alternativer, behandle
# Opens about:addons page in the themes section
quickactions-themes = Behandle temaer
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temaer, tillegg
# Opens a SUMO article explaining how to update the browser
quickactions-update = Oppdater { -brand-short-name }
quickactions-cmd-update = oppdater
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Vis kildekode
quickactions-cmd-viewsource2 = vis kilde, kilde, sidekilde
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Åpne { -firefoxlabs-brand-name }
quickactions-cmd-labs = lab, labs, eksperiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Les mer om hurtige handlinger
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Trykk på tabulator-tasten for å velge:

## Bookmark Panel

bookmarks-add-bookmark = Legg til bokmerke
bookmarks-edit-bookmark = Rediger bokmerke
bookmark-panel-cancel =
    .label = Avbryt
    .accesskey = A
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [1] Fjern bokmerke
           *[other] Fjern { $count } bokmerker
        }
    .accesskey = F
bookmark-panel-show-editor-checkbox =
    .label = Vis redigerer ved lagring
    .accesskey = s
bookmark-panel-save-button2 =
    .label = Lagre
    .accesskey = L
bookmark-panel-save-button =
    .label = Lagre
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Nettstedsinformasjon for { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Tilkoblingssikkerhet for { $host }
identity-connection-not-secure = Tilkoblingen er ikke sikker
identity-connection-secure = Tilkoblingen er sikker
identity-connection-failure = Tilkoblingsfeil
identity-connection-internal = Dette er en sikker { -brand-short-name }-side.
identity-connection-file = Denne siden lagres på datamaskinen din.
identity-connection-associated = Denne siden er lastet inn fra en annen side.
identity-extension-page = Denne siden er lastet fra en utvidelse.
identity-active-blocked = { -brand-short-name } blokkerte deler av denne siden som ikke er sikre.
identity-custom-root = Tilkobling verifisert av en sertifikatutsteder som ikke kjennes igjen av Mozilla.
identity-passive-loaded = Deler av denne siden er ikke sikker (f.eks. bilder).
identity-active-loaded = Du har slått av beskyttelse på denne siden.
identity-weak-encryption = Denne siden bruker svak kryptering.
identity-https-only-connection-upgraded = (oppgradert til HTTPS)
identity-https-only-label2 = Oppgrader denne siden automatisk til en sikker tilkobling
identity-https-only-dropdown-on =
    .label = På
identity-https-only-dropdown-off =
    .label = Av
identity-https-only-dropdown-off-temporarily =
    .label = Midlertidig av
identity-https-only-info-turn-on3 = Slå på HTTPS-oppgraderinger for dette nettstedet hvis du vil at { -brand-short-name } skal oppgradere tilkoblingen når det er mulig.
identity-https-only-info-turn-off3 = Hvis siden virker ødelagt, kan det være lurt å slå av HTTPS-oppgraderinger for at dette nettstedet skal lastes inn på nytt ved hjelp av usikker HTTP.
identity-https-only-info-no-upgrade = Kan ikke å oppgradere tilkoblingen fra HTTP.
identity-permissions-storage-access-header = Infokapsler på tvers av nettsteder
identity-permissions-storage-access-hint = Disse partene kan bruke infokapsler på tvers av nettsteder og nettsteddata mens du er på dette nettstedet.
identity-permissions-storage-access-learn-more = Les mer
identity-permissions-reload-hint = Du må kanskje laste siden på nytt for at endringene skal gjelde.
identity-clear-site-data =
    .label = Slett infokapsler og nettstedsdata…
identity-connection-not-secure-security-view = Du er ikke sikkert koblet til dette nettstedet.
identity-connection-verified = Du er sikkert koblet til dette nettstedet.
identity-ev-owner-label2 = Sertifikat utstedt til
identity-verifier-label2 = Bekreftet av
identity-ev-owner-label = Sertifikat utstedt til:
identity-verifier-label = Verifisert av:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Kvalifisert som spesifisert i forordning (EU) 2024/1183.
identity-description-custom-root2 = Mozilla kjenner ikke igjen denne sertifikatutstederen. Den kan ha blitt lagt til av ditt operativsystem eller av en administrator.
identity-cert-exception-overridden = Du har laget et sikkerhetsunntak for dette nettstedet.
identity-remove-cert-exception =
    .label = Fjern unntak
    .accesskey = F
identity-description-insecure = Tilkoblingen til dette nettstedet er ikke privat. Informasjon du sender kan leses av andre (som f.eks. passord, meldinger, betalingskort, osv.).
identity-description-weak-cipher-intro = Tilkoblingen til dette nettstedet bruker svak kryptering, og er ikke privat.
identity-description-weak-cipher-risk = Andre personer kan se informasjonen eller endre nettstedets oppførsel.
identity-description-active-blocked2 = { -brand-short-name } har blokkert deler av denne siden som ikke er sikker.
identity-description-passive-loaded = Tilkoblingen er ikke privat, og informasjon du sender til nettstedet kan vises av andre.
identity-description-passive-loaded-insecure2 = Dette nettstedet inneholder informasjon som ikke er overført sikkert (f.eks. bilder).
identity-description-passive-loaded-mixed2 = Selv om { -brand-short-name } har blokkert noe innhold, er det fortsatt innhold på denne siden som ikke er sikker (f.eks. bilder).
identity-description-active-loaded = Dette nettstedet inneholder innhold som ikke er overført sikkert (som f.eks. skript), og tilkoblingen til nettstedet er derfor ikke privat.
identity-description-active-loaded-insecure = Informasjon du sender til dette nettstedet kan vises av andre (som passord, meldinger, betalingskort, osv.).
identity-description-tls-key-logging-heading = Tilkoblingen er kanskje ikke privat
identity-description-tls-key-logging-message = En app eller tjeneste kan se den krypterte trafikken din fra dette nettstedet.
identity-more-info-link-text =
    .label = Mer informasjon

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimer
browser-window-maximize-button =
    .tooltiptext = Maksimer
browser-window-restore-down-button =
    .tooltiptext = Gjenopprett ned
browser-window-close-button =
    .tooltiptext = Lukk
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Tilbake

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importer bokmerker…
    .tooltiptext = Importer bokmerker fra en annen nettleser til { -brand-short-name }.
bookmarks-toolbar-empty-message = Plasser bokmerkene dine her på bokmerkeverktøylinjen for rask tilgang. <a data-l10n-name="manage-bookmarks">Behandle bokmerker…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Høyttalere
popup-select-window-or-screen =
    .label = Vindu eller skjerm:
    .accesskey = V
popup-all-windows-shared = Alle synlige vinduer på skjermen vil deles.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Du deler { -brand-short-name }. Andre personer kan se når du bytter til en ny fane.
sharing-warning-screen = Du deler hele skjermen. Andre personer kan se når du bytter til en ny fane.
sharing-warning-proceed-to-tab =
    .label = Fortsett til fanen
sharing-warning-disable-for-session =
    .label = Slå av delingsbeskyttelse for denne økten

## WebSerial "select a port" popup

webserial-select-port-label = Velg en serieport:
webserial-no-ports-available = Ingen serieporter tilgjengelig

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Lukk
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Søk eller skriv inn adresse
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Skriv inn adresse
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Søk med { $name }
    .placeholder = Søk på nettet
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Søk { $name }
    .placeholder = Skriv inn søketekst
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Søk i bokmerker
    .placeholder = Skriv inn søketekst
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Søk i historikk
    .placeholder = Skriv inn søketekst
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Søk i faner
    .placeholder = Skriv inn søketekst
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Søkehandlinger
    .placeholder = Skriv inn søketekst
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Søk med { $name } eller skriv inn adresse
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Nettleseren er under fjernkontroll (årsak: { $component })
urlbar-permissions-granted =
    .tooltiptext = Du har gitt dette nettstedet noen spesialtillatelser.
urlbar-switch-to-tab =
    .value = Bytt til fane:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Utvidelse:
urlbar-go-button2 =
    .title = Gå til adressen i adresselinjen
urlbar-page-action-button =
    .tooltiptext = Sidehandlinger
urlbar-revert-button =
    .tooltiptext = Vis adressen i adresselinjen

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Søk med { $engine } i et privat vindu
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Søk i et privat vindu
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Søk med { $engine }
urlbar-result-action-sponsored = Sponset
urlbar-result-action-switch-tab = Bytt til fane
urlbar-result-action-move-tab-to-split-view = Flytt fane til delt visning
urlbar-result-action-visit = Besøk
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Bytt til fane · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Navnløs gruppe
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Besøk fra utklippstavlen
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Trykk på tab for å søke med { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Trykk på tab for å søke { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Søk med { $engine } direkte fra adresselinjen
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Søk i { $engine } direkte fra adresselinjen
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopier
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = udefinert
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name }-utvidelse
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Anbefalt
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature } °{ $unit }</strong> i { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature } °{ $unit }</strong> i { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> i { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Sponset
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Spør
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Sist besøkt { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Sist besøkt for { $daysAgo } dag siden
       *[other] Sist besøkt for { $daysAgo } dager siden
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Sist besøkt for { $weeksAgo } uke siden
       *[other] Sist besøkt for { $weeksAgo } uker siden
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Sist besøkt for { $monthsAgo } måned siden
       *[other] Sist besøkt for { $monthsAgo } måneder siden
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Sist besøkt den { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Bokmerket { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Sist besøkt { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Sist besøkt { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Sist besøkt { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Få aksjemarkedsdata rett i søkefeltet
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Vis markedsoppdateringer og mer fra våre partnere når du deler søkedatainformasjon med { -vendor-short-name }. <a data-l10n-name="learn-more-link">Les mer</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Vis forslag
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Ikke nå
urlbar-result-realtime-opt-in-dismiss = Ignorer
urlbar-result-realtime-opt-in-dismiss-all2 = Ikke vis disse forslagene
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Ikke vis markedsforslag
    .accesskey = k
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Ikke vis markedsforslag
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Ikke vis disse forslagene
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Ikke vis markedsforslag
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Takk for tilbakemeldingen din. Du vil ikke lenger se markedsforslag.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Aksjemarkedsforslag
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Takk for tilbakemeldingen din. Du vil ikke se disse forslagene lenger.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · Om { $daysUntilStart } dag
       *[other] { $name } · Om { $daysUntilStart } dager
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Starter om { $daysUntilStart } dag
       *[other] { $name } · Starter om { $daysUntilStart } dager
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Slutter om { $daysUntilEnd } dag
       *[other] { $name } · Slutter om { $daysUntilEnd } dager
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · I dag
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Slutter i dag

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Søk med { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Søk i { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Søk med { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, velg en søkemotor
urlbar-searchmode-button-no-engine2 =
    .title = Ingen snarvei valgt, velg en snarvei
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Nøkkelordssøk er deaktivert
urlbar-searchmode-dropmarker2 =
    .title = Velg en søkemotor
urlbar-searchmode-bookmarks4 = Bokmerker
urlbar-searchmode-tabs4 = Faner
urlbar-searchmode-history4 = Historikk
urlbar-searchmode-actions4 = Handlinger
urlbar-searchmode-bookmarks3 = Bokmerker
    .accesskey = B
urlbar-searchmode-tabs3 = Faner
    .accesskey = F
urlbar-searchmode-history3 = Historikk
    .accesskey = H
urlbar-searchmode-actions3 = Handlinger
    .accesskey = a
urlbar-searchmode-exit-button2 =
    .title = Lukk
urlbar-searchmode-default2 =
    .title = Standard søkemotor
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Legg til «{ $engineName }»
    .title = Legg til søkemotor «{ $engineName }»
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Søk denne gang med:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Søk med:
urlbar-searchmode-popup-search-settings2 = Søkeinnstillinger
urlbar-searchmode-popup-settings2 = Innstillinger
urlbar-searchmode-popup-search-settings = Søkeinnstillinger
    .accesskey = S
urlbar-searchmode-popup-settings = Innstillinger
    .accesskey = s

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Søk i bokmerker
urlbar-result-action-search-history = Søk i historikk
urlbar-result-action-search-tabs = Søk i faner
urlbar-result-action-search-actions = Søkehandlinger
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Bytt til { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Åpne { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Åpne i ny fane
    .accesskey = n
urlbar-view-context-menu-open-in-container-tab =
    .label = Åpne i ny beholderfane
    .accesskey = p
urlbar-view-context-menu-open-in-window =
    .label = Åpne i nytt vindu
    .accesskey = n
urlbar-view-context-menu-open-in-private-window =
    .label = Åpne i nytt privat vindu
    .accesskey = p
urlbar-view-context-menu-open-in-tab2 = Åpne i ny fane
    .accesskey = n
urlbar-view-context-menu-open-in-container-tab2 = Åpne i ny beholderfane
    .accesskey = p
urlbar-view-context-menu-open-in-window2 = Åpne i nytt vindu
    .accesskey = n
urlbar-view-context-menu-open-in-private-window2 = Åpne i nytt privat vindu
    .accesskey = p
urlbar-view-context-menu-search-in-tab = Søk i ny fane
    .accesskey = S
urlbar-view-context-menu-search-in-container-tab = Søk i ny beholderfane
    .accesskey = i
urlbar-view-context-menu-search-in-window = Søk i nytt vindu
    .accesskey = n
urlbar-view-context-menu-search-in-private-window = Søk i nytt privat vindu
    .accesskey = p
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Hopp over denne menyen når du bruker tabulatortasten
    .accesskey = H

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine }-forslag
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Hurtige handlinger
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Nylige søk
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Populær på { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Ikke vis populære søk
    .accesskey = k
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Ikke vis populære søk
    .accesskey = k
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Ikke vis populære søk
    .accesskey = k
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Takk for din tilbakemelding. Du vil ikke lenger se populære søk.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Gå til lesevisning
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Lukk lesevisning

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Åpne bilde-i-bilde ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Lukk bilde-i-bilde ({ $shortcut })
picture-in-picture-panel-header = Bilde-i-bilde
picture-in-picture-panel-headline = Dette nettstedet anbefaler ikke bilde-i-bilde
picture-in-picture-panel-body = Det kan hende at videoer ikke vises slik utvikleren hadde tenkt mens bilde-i-bilde er aktivert.
picture-in-picture-enable-toggle =
    .label = Slå på uansett

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> er nå i fullskjerm
fullscreen-warning-no-domain = Dette dokumentet er nå i fullskjerm
fullscreen-exit-button = Avslutt fullskjerm (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Avslutt fullskjerm (esc)
fullscreen-keyboardlock-exit-button = Avslutt fullskjerm (trykk og hold Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Avslutt fullskjerm (trykk og hold esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> har kontroll over musepekeren din. Trykk Esc for å ta tilbake kontrollen.
pointerlock-warning-no-domain = Dette dokumentet har kontroll over musepekeren din. Trykk på Esc for å ta tilbake kontrollen.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Behandle bokmerker
bookmarks-recent-bookmarks-panel-subheader = Nylige bokmerker
bookmarks-toolbar-chevron =
    .tooltiptext = Vis flere bokmerker
bookmarks-sidebar-content =
    .aria-label = Bokmerker
bookmarks-menu-button =
    .label = Bokmerkemeny
bookmarks-other-bookmarks-menu =
    .label = Andre bokmerker
bookmarks-mobile-bookmarks-menu =
    .label = Mobile bokmerker

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Skjul bokmerkesidestolpen
           *[other] Vis bokmerkesidestolpen
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Skjul bokmerkeverktøylinje
           *[other] Vis bokmerkeverktøylinje
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Vis bokmerkeverktøylinjen
           *[other] Skjul bokmerkeverktøylinjen
        }

##

bookmarks-search =
    .label = Søk i bokmerker
bookmarks-tools =
    .label = Verktøy for bokmerker
bookmarks-subview-edit-bookmark =
    .label = Rediger dette bokmerket …
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Bokmerker
    .toolbarname = Bokmerker
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Bokmerker
bookmarks-toolbar-placeholder =
    .title = Elementer i bokmerkelinje
bookmarks-toolbar-placeholder-button =
    .label = Elementer i bokmerkelinje
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Bokmerk gjeldende fane …

## Library Panel items

library-bookmarks-menu =
    .label = Bokmerker

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Reparer tekstkoding
    .tooltiptext = Gjett riktig tekstkoding fra sideinnhold

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Innstillinger
    .tooltiptext =
        { PLATFORM() ->
            [macos] Åpne innstillinger ({ $shortcut })
           *[other] Åpne innstillinger
        }
toolbar-overflow-customize-button =
    .label = Tilpass verktøylinje…
    .accesskey = T
toolbar-button-email-link =
    .label = Send lenke med e-post
    .tooltiptext = Send en lenke til siden med e-post
toolbar-button-logins =
    .label = Passord
    .tooltiptext = Se og behandle dine lagrede passord
qrcode-panel-error =
    .message = Klarte ikke å generere QR-kode. Prøv igjen.
qrcode-copy-button =
    .label = Kopier
qrcode-copy-success =
    .message = QR-kode kopiert til utklippstavlen.
qrcode-copy-error =
    .message = Kunne ikke kopiere QR-koden.
qrcode-save-button =
    .label = Lagre
qrcode-window-title = QR-kode
qrcode-dialog-title = QR-kode
qrcode-image =
    .aria-label = QR-kode
qrcode-close-button =
    .aria-label = Lukk
toolbar-button-save-page =
    .label = Lagre side
    .tooltiptext = Lagre denne siden ({ $shortcut })
toolbar-button-open-file =
    .label = Åpne fil
    .tooltiptext = Åpne fil ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Synkroniserte faner
    .tooltiptext = Vis faner fra andre enheter
toolbar-button-send-tab =
    .label = Send fane
    .tooltiptext = Send gjeldende fane til en annen enhet
toolbar-button-new-private-window =
    .label = Nytt privat vindu
    .tooltiptext = Åpne et nytt privat nettleservindu ({ $shortcut })
toolbar-button-share-tab =
    .label = Del
    .tooltiptext = Del denne siden
toolbar-button-tab-groups =
    .label = Fanegrupper
    .tooltiptext = Vis fanegruppene dine
toolbar-button-history =
    .label = Historikk
    .tooltiptext = Vis historikk ({ $shortcut })
toolbar-button-find =
    .label = Finn
    .tooltiptext = Finn i denne siden ({ $shortcut })
toolbar-button-developer =
    .label = Utviklere
    .tooltiptext = Åpne webutviklerverktøy ({ $shortcut })
toolbar-button-forget =
    .label = Glem
    .tooltiptext = Glem deler av nettleserhistorikken
toolbar-zoom-controls =
    .label = Zoom-kontroller
    .title = Zoom-kontroller
toolbar-button-zoom-out =
    .label = Zoom ut
    .tooltiptext = Zoom ut ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Tilbakestill zoom ({ $shortcut })
toolbar-button-zoom-in =
    .label = Zoom inn
    .tooltiptext = Zoom inn ({ $shortcut })
toolbar-edit-controls =
    .label = Rediger kontroller
    .title = Rediger kontroller
toolbar-button-cut =
    .label = Klipp ut
    .tooltiptext = Klipp ut ({ $shortcut })
toolbar-button-copy =
    .label = Kopier
    .tooltiptext = Kopier ({ $shortcut })
toolbar-button-paste =
    .label = Lim inn
    .tooltiptext = Lim inn ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qr-kode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qr-kode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Noe lyd eller video på denne siden bruker DRM-programvare, som kan begrense hva { -brand-short-name } lar deg gjøre med den.
eme-notifications-drm-content-playing-manage = Behandle innstillinger
eme-notifications-drm-content-playing-manage-accesskey = B
eme-notifications-drm-content-playing-dismiss = Ignorer
eme-notifications-drm-content-playing-dismiss-accesskey = I

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Du må aktivere DRM for å spille lyd eller video på denne siden.
eme-notifications-drm-content-disabled-button =
    .label = Slå på DRM
    .accesskey = S
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } installerer komponentene som trengs for å spille av lyden eller videoen på denne siden. Prøv igjen senere.
decoder-doctor-no-codecs-linux-message = For å spille av videoer må du installere de påkrevde video-kodekene.
decoder-doctor-no-hw-acceleration-message = For å forbedre videokvalitet må du kanskje installere Microsofts Media Feature Pack.
decoder-doctor-no-pulse-audio-message = For å spille av lyd, må du kanskje installere den påkrevde PulseAudio-programvaren.
decoder-doctor-unsupported-libavcodec-message = libavcode kan være sårbart eller ikke støttet, og burde oppdateres for å spille video.
decoder-doctor-decode-error-message = Det oppstod en feil under dekoding av en medieressurs.
decoder-doctor-decode-warning-message = En gjenopprettelig feil oppstod ved dekoding av en medieressurs.
decoder-doctor-learn-how-link = Finn ut hvordan
decoder-doctor-report-issue-button =
    .label = Rapporter problem med nettsted
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Programtillegget { $pluginName } krasjet.
plugin-crashed-notification-reload-button =
    .label = Oppdater siden
    .accesskey = O
plugin-crashed-notification-submit-button =
    .label = Send inn en krasjrapport
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Villedende nettsted!
safebrowsing-reported-attack-site-message = Rapportert angrepsnettsted!
safebrowsing-reported-unwanted-site-message = Rapportert uønsket programvare-nettsted!
safebrowsing-reported-harmful-site-message = Rapportert skadelig nettsted!
safebrowsing-get-me-out-of-here-button =
    .label = Få meg bort herfra!
    .accesskey = F
safebrowsing-not-a-deceptive-site-button =
    .label = Dette er ikke et villedende nettsted …
    .accesskey = d
safebrowsing-not-an-attack-site-button =
    .label = Dette er ikke en angrepsnettside …
    .accesskey = e

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Du må logge inn på nettverket før du får tilgang til Internett.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Åpne innloggingsside for nettverk

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Mente du å gå til { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Ja, gå til { $hostName }
    .accesskey = J

## Password save/update panel

panel-save-update-username-2 =
    .label = Brukernavn
panel-save-update-password-2 =
    .label = Passord

##

# "More" item in macOS share menu
menu-share-more =
    .label = Mer…
menu-share-windows =
    .label = Flere innstillinger
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Kopier lenke
           *[other] Kopier { $count } lenker
        }
    .accesskey = o
ui-tour-info-panel-close =
    .tooltiptext = Lukk

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Tillat sprettoppvinduer og tredjepartvideresendinger for { $uriHost }
    .accesskey = s

##

picture-in-picture-hide-toggle =
    .label = Skjul bilde-i-bilde-veksleknapp
    .accesskey = S

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Flytt bilde-i-bilde-veksler til høyre side
    .accesskey = h
picture-in-picture-move-toggle-left =
    .label = Flytt bilde-i-bilde-veksler til venstre side
    .accesskey = v

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigasjon
navbar-downloads =
    .label = Nedlastinger
navbar-overflow-2 =
    .tooltiptext = Flere verktøy
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Skriv ut
    .tooltiptext = Skriv ut denne siden … ({ $shortcut })
navbar-home =
    .label = Startside
    .tooltiptext = { -brand-short-name }-startside
navbar-library =
    .label = Arkiv
    .tooltiptext = Se historikk, lagrede bokmerker og mer
navbar-search =
    .title = Søk
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Nettleserfaner
tabs-toolbar-new-tab =
    .label = Ny fane
tabs-toolbar-list-all-tabs-2 =
    .label = Søk etter og behandle faner
    .tooltiptext = Søk etter og behandle faner
tabs-toolbar-list-all-tabs =
    .label = List opp alle faner
    .tooltiptext = List opp alle faner

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Slipp fanen her for å feste den

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Åpne tidligere faner?</strong> Du kan gjenopprette den forrige økten fra { -brand-short-name }-programmenyen <img data-l10n-name="icon"/>, under Historikk.
restore-session-startup-suggestion-button = Vis meg hvordan

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Organisasjonen din har blokkert tilgang til lokale filer på denne datamaskinen

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } søker nå etter faner
urlbar-addons-shortcut-moved-description = Bruk { $addonsShortcut } for å åpne utvidelser og temaer.
urlbar-addons-shortcut-moved-change-shortcuts = Behandle hurtigtaster
urlbar-addons-shortcut-moved-dismiss = Jeg forstår

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } sender automatisk noen data til { -vendor-short-name } slik at vi kan forbedre opplevelsen din.
data-reporting-notification-button =
    .label = Velg hva som skal deles
    .accesskey = V
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Privat nettlesing
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Privat nettlesing
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Privat nettlesingsinformasjon
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Du er i et privat vindu
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Dette bidrar til å holde surfingen din skjult for andre som bruker denne enheten, men gjør deg ikke usynlig på nettet. <a data-l10n-name="learn-more">Hvem kan kanskje fortsatt se hva du gjør på nettet?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Forebygging av datatap (DLP) av { $agentName }. Klikk for mer info.
content-analysis-panel-title2 = Forebygging av datatap
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Organisasjonen din bruker <b>{ $agentName }</b> til å kontrollere hvordan sensitive data kan deles. <a data-l10n-name="info">Les mer</a>
content-analysis-panel-title = Databeskyttelse
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Organisasjonen din bruker <b>{ $agentName }</b> for å beskytte mot tap av data. <a data-l10n-name="info">Les mer</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Utvidelser
    .tooltiptext = Utvidelser

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Utvidelser
    .tooltiptext =
        Utvidelser
        Trenger tillatelser

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Utvidelser
    .tooltiptext =
        Utvidelser
        Noen utvidelser er ikke tillatt

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Utvidelser
    .tooltiptext =
        Utvidelser
        Noen utvidelser er deaktivert

## Private browsing reset button

reset-pbm-panel-heading2 = Slette data og starte en ny privat økt?
reset-pbm-panel-description3 = Dette sletter historikken og infokapslene dine og logger deg ut av nettsteder. De private vinduene dine lukkes, og et nytt åpnes.
reset-pbm-panel-description2 = Dette sletter historikk, infokapsler og alle andre nettstedsdata uten å lukke det private vinduet.
reset-pbm-panel-always-ask-checkbox =
    .label = Spør meg alltid
    .accesskey = S
reset-pbm-panel-cancel-button =
    .label = Avbryt
    .accesskey = A
reset-pbm-panel-confirm-button2 =
    .label = Tøm privat økt
    .accesskey = T
reset-pbm-panel-complete = Private øktdata slettet
reset-pbm-toolbar-button2 =
    .label = Tøm privat økt
    .tooltiptext = Tøm privat økt

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Slette alle nettleserdata?
fire-button-panel-description = Dette sletter historikk, infokapsler og nettstedsdata. Du blir logget ut av nettsteder. Dette vinduet lukkes, og { -brand-short-name } åpner et nytt.
fire-button-panel-choose-description = Hvis du ikke vil slette alt, kan du velge bestemte data i stedet.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Velg…
fire-button-panel-cancel-button =
    .label = Avbryt
    .accesskey = A
fire-button-panel-confirm-button =
    .label = Slett alle
    .accesskey = S
fire-button-panel-complete = Nettleserdata slettet
fire-button-toolbar-button2 =
    .label = Slett noen eller alle data
    .tooltiptext = Slett noen eller alle nettleserdataene dine

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } forhindret denne nettsiden fra å automatisk laste inn på nytt.
refresh-blocked-redirect-label = { -brand-short-name } forhindret denne nettsiden fra å automatisk omdirigere til en annen nettside.
refresh-blocked-allow =
    .label = Tillat
    .accesskey = T

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Våre sikre, brukervennlige aliaser beskytter identiteten din og forhindrer spam ved å skjule e-postadressen din.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Alle e-poster som sendes til e-postaliasene dine vil bli videresendt til <strong>{ $useremail }</strong> (med mindre du bestemmer deg for å blokkere dem).
firefox-relay-offer-legal-notice = Ved å klikke «Bruk e-postalias» godtar du <label data-l10n-name="tos-url">bruksvilkår</label> og <label data-l10n-name="privacy-url">personvernerklæringen</label>.
firefox-relay-offer-legal-notice-1 = Ved å registrere deg og opprette et e-postalias, godtar du <label data-l10n-name="tos-url">bruksvilkårene</label> og <label data-l10n-name="privacy-url">personvernerklæringen</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Ubekreftet)
popup-notification-xpinstall-prompt-learn-more = Les mer om sikker installering av utvidelser
popup-notification-xpinstall-prompt-block-url = Se detaljer
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Tillat at utvidelsen kjører i private vinduer
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Del tekniske data og interaksjonsdata med utvikler av utvidelsen
    .accesskey = D

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } forhindret dette nettstedet fra å åpne et sprettoppvindu.
       *[other] { -brand-short-name } forhindret dette nettstedet fra å åpne { $popupCount } sprettoppvinduer.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } forhindret dette nettstedet fra å videresende.
        [1] { -brand-short-name } forhindret dette nettstedet fra å åpne et sprettoppvindu og videresende.
       *[other] { -brand-short-name } forhindret dette nettstedet fra å åpne { $popupCount } sprettoppvinduer og videresende.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } forhindret dette nettstedet fra å åpne mer enn { $popupCount } sprettopp-vinduer.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
       *[other] { -brand-short-name } forhindret dette nettstedet fra å åpne mer enn { $popupCount } sprettoppvinduer og videresende.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Innstillinger
           *[other] Innstillinger
        }
    .accesskey =
        { PLATFORM() ->
            [windows] I
           *[other] I
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Åpne «{ $popupURI }»
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Vis «{ $redirectURI }»

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Klarte ikke å åpne Windows-fildialogvinduet. Ingen fil eller mappe kunne velges.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Klarte ikke å åpne Windows-fildialogvinduet. Filen vil bli lagret i { $path }.
file-picker-failed-save-nowhere = Klarte ikke å åpne Windows-fildialogvinduet. Fant ingen standardmappe, og filen vil ikke bli lagret.
file-picker-crashed-open = Windows-fildialogvinduet har krasjet. Ingen fil eller mappe kunne velges.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows-fildialogvinduet har krasjet. Filen vil bli lagret i { $path }.
file-picker-crashed-save-nowhere = Windows-fildialogvinduet har krasjet. Fant ingen standardmappe, og filen vil ikke bli lagret.
file-picker-crashed-show-in-folder =
    .label = Vis i mappe
    .accessKey = m

## Unsigned add-ons notification

unsigned-addons-disabled-message = En eller flere installerte utvidelser kan ikke bekreftes, og har blitt slått av.
unsigned-addons-disabled-learn-more =
    .label = Les mer
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Denne nettsiden gjør at { -brand-short-name } går tregere. Stopp denne siden for å øke hastigheten på nettleseren din.
process-hang-nonspecific-tab-message = En nettside gjør at { -brand-short-name } går tregere. Stopp den siden for å øke hastigheten på nettleseren din.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = «{ $title }» gjør at { -brand-short-name } går tregere. Stopp den siden for å øke hastigheten på nettleseren din.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = «{ $addonName }» gjør at { -brand-short-name } går tregere. Stopp den utvidelsen for å øke hastigheten på nettleseren din.
process-hang-addon-learn-more =
    .value = Les mer
process-hang-stop-button =
    .label = Stopp
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Fullfør oppsettet
onboarding-aw-finish-setup-button =
    .label = Fullfør oppsettet
    .tooltiptext = Fullfør oppsettet av { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Utvidet sporingsbeskyttelse er på
trustpanel-etp-label-disabled = Utvidet sporingsbeskyttelse er av
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Utvidet sporingsbeskyttelse: På for { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Utvidet sporingsbeskyttelse: Av for { $host }
trustpanel-etp-description-enabled = Hvis noe ser ødelagt ut på dette nettstedet, prøv å slå av beskyttelsen.
trustpanel-etp-description-disabled = { -brand-product-name } mener at selskaper burde følge deg mindre. Vi blokkerer så mange sporere som mulig når du slår på beskyttelse.
trustpanel-connection-label-secure = Tilkoblingen er sikker
trustpanel-connection-label-insecure = Tilkoblingen er ikke sikker
trustpanel-header-enabled = { -brand-product-name } er på vakt
trustpanel-description-enabled2 = Du er beskyttet. Om vi oppdager noe sier vi ifra.
trustpanel-header-enabled-insecure = Vær forsiktig på dette nettstedet
trustpanel-description-enabled-insecure = { -brand-product-name } oppdaget noe mistenkelig.
trustpanel-header-disabled = Du har slått av beskyttelse
trustpanel-description-disabled = { -brand-product-name } er deaktivert. Vi foreslår at du skrur på beskyttelsen igjen.
trustpanel-clear-cookies-button = Fjern infokapsler og nettstedsdata
trustpanel-privacy-link = Personverninnstillinger
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Fjern infokapsler og nettstedsdata for { $host }
trustpanel-clear-cookies-description = Fjerning av infokapsler og nettstedsdata kan logge deg ut av nettsteder og tømme handlekurver.
trustpanel-clear-cookies-subview-button-clear = Tøm
trustpanel-clear-cookies-subview-button-cancel = Avbryt
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Tilkoblingsbeskyttelse for { $host }
trustpanel-siteinformation-morelink = Mer informasjon om nettstedet
trustpanel-blocker-see-all = Vis alle
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Sporingsbeskyttelse for { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Ikke sikker
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } sporer blokkert
       *[other] { $count } sporere blokkert
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } mener at selskaper burde følge deg mindre. Så vi blokkerer så mange som mulig.
trustpanel-blocked-header = { -brand-product-name } blokkerte disse tingene for deg:
trustpanel-tracking-header = { -brand-product-name } tillot dette slik at nettsteder ikke skulle slutte å fungere:
trustpanel-tracking-description = Uten sporere kan det hende at enkelte knapper, skjemaer og innloggingsfelt ikke fungerer.
trustpanel-insecure-section-header = Tilkoblingen er ikke sikker
trustpanel-insecure-description = Dataene du sender til dette nettstedet er ikke kryptert. De kan bli sett, stjålet eller endret.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } sporingsinfokapsel på tvers av nettsteder
       *[other] { $count } sporingsinfokapsler på tvers av nettsteder
    }
trustpanel-list-label-tracking-content = Sporings-innhold
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } fingeravtrykkssporer
       *[other] { $count } fingeravtrykkssporere
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } sporer via sosiale medier
       *[other] { $count } sporere via sosiale medier
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } kryptoutvinner
       *[other] { $count } kryptoutvinnere
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } blokkerte { $count } sporer via sosiale medier
       *[other] { -brand-product-name } blokkerte { $count } sporere via sosiale medier
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } tillot { $count } sporer via sosiale medier
       *[other] { -brand-product-name } tillot { $count } sporere via sosiale medier
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } blokkerte { $count } sporingsinfokapsel på tvers av nettsteder
       *[other] { -brand-product-name } blokkerte { $count } sporingsinfokapsler på tvers av nettsteder
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } tillot { $count } sporingsinfokapsel på tvers av nettsteder
       *[other] { -brand-product-name } tillot { $count } sporingsinfokapsler på tvers av nettsteder
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } blokkerte { $count } sporer
       *[other] { -brand-product-name } blokkerte { $count } sporere
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } tillot { $count } sporer
       *[other] { -brand-product-name } tillot { $count } sporere
    }
trustpanel-tracking-content-tab-list-header = Disse nettstedene prøver å spore deg:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } blokkerte { $count } fingeravtrykkssporer
       *[other] { -brand-product-name } blokkerte { $count } fingeravtrykkssporere
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } tillot { $count } fingeravtrykkssporer
       *[other] { -brand-product-name } tillot { $count } fingeravtrykkssporere
    }
trustpanel-fingerprinter-list-header = Disse nettstedene prøver å fingeravtrykkspore deg:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } blokkerte { $count } kryptoutvinner
       *[other] { -brand-product-name } blokkerte { $count } kryptoutvinnere
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } tillot { $count } kryptoutvinner
       *[other] { -brand-product-name } tillot { $count } kryptoutvinnere
    }
trustpanel-cryptominer-tab-list-header = Disse nettstedene prøver å drive kryptomining:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Har du en konto på dette nettstedet?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } har oppdaget at dette nettstedet hadde en datalekkasje de siste 12 månedene. Finn ut om du ble berørt.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Ignorer
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Start gratis skanning
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> sporer blokkert på dette nettstedet
       *[other] <span data-l10n-name="count">{ $count }</span> sporere blokkert på dette nettstedet
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Ser nettstedet ødelagt ut?</strong> Last siden på nytt for midlertidig å redusere sporingsbeskyttelsen.
reduced-protection-infobar-reload-button = Last på nytt
    .accesskey = L
reduced-protection-infobar-never-show-button = Ikke vis igjen
    .accesskey = v


