# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Fortell nettsteder om ikke å selge eller dele mine data
    .accesskey = o
non-technical-privacy-group =
    .label = Nettstedets personverninnstillinger
do-not-track-removal3 =
    .message = Vi støtter ikke lenger «Ikke spor»-funksjonen
non-technical-privacy-heading =
    .label = Ytterligere beskyttelse
preferences-privacy-relay-available =
    .description = Skjuler den virkelige e-postadressen din for å beskytte innboksen mot uønsket e-post (spam).
    .label = Foreslå e-postalias fra { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Innstillinger
category-nav-heading =
    .heading = Innstillinger
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Søk i innstillinger
    .style = width: 15.4em
managed-notice = Nettleseren din administreres av organisasjonen din.
managed-notice-info-icon =
    .alt = Informasjon
managed-notice-nav =
    .label = Nettleseren din administreres av organisasjonen din.
tls-key-logging-notice-nav =
    .label = En app eller tjeneste kan se den krypterte trafikken din.
category-list =
    .aria-label = Kategorier
pane-general-title = Generelt
pane-home-title = Hjem
pane-home-startup-title2 = Startside og oppstart
    .title = Startside og oppstart
pane-search-title2 = Søk
    .title = Søk
pane-privacy-title3 = Personvern og sikkerhet
    .title = Personvern og sikkerhet
pane-privacy-section =
    .heading = Personvern og sikkerhet
pane-sync-title3 = Synkronisering
pane-ai-controls-title2 = AI-kontroller
    .title = AI-kontroller
pane-about-firefox-title = Om { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Utseende
    .title = { pane-appearance-title }
pane-downloads-title2 = Nedlastinger
    .title = Nedlastinger
pane-downloads3 =
    .heading = Nedlastinger
pane-accessibility-title = Tilgjengelighet
    .title = { pane-accessibility-title }
pane-languages-title2 = Språk
    .title = Språk
preferences-languages-header3 =
    .heading = Språk
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Prøv våre eksperimentelle funksjoner! De er under utvikling og i endring, noe som kan påvirke hvordan { -brand-short-name } fungerer. Vi mottar bare data om bruken din av disse funksjonene hvis du har <a data-l10n-name="data-collection">tekniske data og interaksjonsdata</a> slått på.
pane-experimental-reset =
    .label = Gjenopprett standard
    .accesskey = G
help-button-label2 = { -brand-short-name } brukerstøtte
    .title = { -brand-short-name } brukerstøtte
addons-button-label2 = Utvidelser og tema
    .title = Utvidelser og tema
focus-search =
    .key = f
close-button =
    .aria-label = Lukk
do-not-track-removal2 =
    .label = Vi støtter ikke lenger «Ikke spor»-signalet
applications-setting-new-file-types =
    .label = Hva skal { -brand-short-name } gjøre med andre filer?

## Browser Restart Dialog

feature-enable-requires-restart = { -brand-short-name } må startes på nytt for å aktivere denne funksjonen.
feature-disable-requires-restart = { -brand-short-name } må startes på nytt for å slå av denne funksjonen.
should-restart-title = Start { -brand-short-name } på nytt
should-restart-ok = Start { -brand-short-name } på nytt nå
cancel-no-restart-button = Avbryt
restart-later = Start på nytt senere

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrollerer denne innstillingen.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrollerer denne innstillingen.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> krever beholderfaner.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontrollerer denne innstillingen.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> kontrollerer hvordan { -brand-short-name } kobler til internett.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = For å aktivere utvidelsen, gå til <img data-l10n-name="addons-icon"/> Utvidelser i menyen <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = For å aktivere denne utvidelsen på nytt, gå til <a data-l10n-name="addons-link">utvidelser og temaer</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } styrer noen av dine startsideinnstillinger.

## Preferences UI Search Results

search-results-header = Søkeresultat
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Beklager! Det er ingen resultat i innstillinger for «<span data-l10n-name="query"></span>».
search-results-help-link = Trenger du hjelp? Gå til <a data-l10n-name="url">{ -brand-short-name } brukerstøtte</a>

## General Section

always-check-default =
    .label = Kontroller alltid om { -brand-short-name } er standardnettleser
    .accesskey = a
startup-restore-windows-and-tabs =
    .label = Åpne tidligere vinduer og faner
    .accesskey = p
startup-windows-launch-on-login-profile-disabled =
    .message = Aktiver denne innstillingen ved å merke av for «{ profile-manager-use-selected.label }» i «Velg brukerprofil»-vinduet.
windows-launch-on-login =
    .label = Åpne { -brand-short-name } automatisk når datamaskinen din starter opp
    .accesskey = p
windows-launch-on-login-disabled = Denne innstillingen er deaktivert i Windows. For å endre, gå til <a data-l10n-name="startup-link">Oppstartsapper</a> i Systeminnstillinger.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Åpne også en ny fane
    .accesskey = n
disable-extension =
    .label = Slå av utvidelse
preferences-data-migration-group =
    .description = Ta med bokmerker, passord, historikk, utvidelser og autoutfyllingsdata fra en annen nettleser.
    .label = Importer nettleserdata
preferences-data-migration-button =
    .label = Importer data
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profiler
preferences-profiles-subpane-description =
    .description = Hver profil har separate nettlesingsdata og innstillinger, inkludert historikk, passord med mer.
preferences-profiles-section-header =
    .description = Hver profil har separate nettlesingsdata og innstillinger, inkludert historikk, passord med mer.
    .label = Profiler
preferences-manage-profiles-button =
    .label = Behandle profiler
preferences-profiles-settings-button =
    .label = Innstillinger
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Den nye profilen vil kopiere innstillingene dine, utvidelser, historikk og lagrede data som bokmerker og passord — men ikke kontoen din eller synkroniseringsinformasjonen.
    .label = Kopier en eksisterende profil
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Profil som skal kopieres
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Velg profil
preferences-copy-profile-button = Kopier
tabs-browsing-section =
    .heading = Faner og nettlesing
pane-tabs-browsing-title2 = Faner og nettlesing
    .title = Faner og nettlesing
tabs-group-header2 =
    .label = Faner
tabs-opening-heading =
    .label = Åpning
tabs-interaction-heading =
    .label = Interaksjon
tabs-containers-heading =
    .label = Beholdere
tabs-closing-heading =
    .label = Lukking
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab veksler mellom faner i nylig brukt-rekkefølge
    .accesskey = T
open-new-link-as-tabs =
    .label = Åpne lenker i faner istedenfor nye vindu
    .accesskey = f
open-external-link-next-to-active-tab =
    .label = Åpne lenker fra apper ved siden av den aktive fanen din
ask-on-close-multiple-tabs =
    .label = Spør før lukking av flere faner
    .accesskey = p
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Spør før du avslutter med { $quitKey }
    .accesskey = a
warn-on-open-many-tabs =
    .label = Advar når åpning av mange faner samtidig kan gjøre { -brand-short-name } treg
    .accesskey = d
switch-to-new-tabs-2 =
    .label = Når du åpner lenker eller media i en ny fane, bytt til den umiddelbart
    .accesskey = d
show-tabs-in-taskbar =
    .label = Vis forhåndsvisning av faner i Windows-oppgavelinjen
    .accesskey = s
browser-containers-enabled-2 =
    .label = Bruk beholderfaner
    .accesskey = r
browser-containers-learn-more = Les mer
browser-containers-settings-2 =
    .label = Behandle innstillinger
    .accesskey = i
containers-disable-alert-title = Lukk alle beholderfaner?
startup-group =
    .label = Startside

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Hvis du deaktiverer beholderfaner nå, vil { $tabCount } beholderfane bli stengt. Er du sikker på at du vil deaktivere beholderfaner?
       *[other] Hvis du deaktiverer beholderfaner nå, vil { $tabCount } beholderfaner bli stengt. Er du sikker på at du vil deaktivere beholderfaner?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Lukk { $tabCount } beholderfane
       *[other] Lukk { $tabCount } beholderfaner
    }

##

containers-disable-alert-cancel-button = Behold aktivert
containers-remove-alert-title = Fjern denne beholderen?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Hvis du fjerner denne beholderen nå, vil { $count } beholderfane bli stengt. Er du sikker på at du vil fjerne denne beholderen?
       *[other] Hvis du fjerner denne beholderen nå, vil { $count } beholderfaner bli stengt. Er du sikker på at du vil fjerne denne beholderen?
    }
containers-remove-ok-button = Fjern denne beholderen?
containers-remove-cancel-button = Ikke fjern denne beholderen
settings-tabs-show-image-in-preview =
    .label = Vis en forhåndsvisning når du holder musepekeren over en fane
    .accessKey = f
settings-tabs-drag-to-create-tab-groups =
    .label = Dra faner sammen for å opprette fanegrupper
browser-layout-header2 =
    .label = Nettleserutforming
browser-layout-horizontal-tabs2 =
    .description = Faner øverst
    .label = Horisontale faner
    .title = Faner øverst
browser-layout-vertical-tabs2 =
    .description = Faner på siden, i sidestolpen
    .label = Vertikale faner
    .title = Faner på siden, i sidestolpen
browser-layout-show-sidebar2 =
    .description = Få rask tilgang til bokmerker, faner fra telefonen, AI-chatroboter og mer uten å forlate hovedvisningen.
    .label = Vis sidestolpe
page-navigation-group =
    .label = Sidenavigasjon

## General Section - Language & Appearance

language-and-appearance-header = Språk og utseende
appearance-group2 =
    .description = Noen nettsteder endrer fargene sine for å samsvare med innstillingene dine. Velg fargeskjema.
    .label = Nettstedsutseende
preferences-web-appearance-choice-auto3 =
    .label = System
    .title = Endre automatisk bakgrunner og innhold på nettsteder basert på systeminnstillingene dine og temaet i { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Lyst
    .title = Bruk et lyst utseende for nettsidebakgrunn og innhold.
preferences-web-appearance-choice-dark2 =
    .label = Mørkt
    .title = Bruk et mørkt utseende for nettsidebakgrunn og innhold.
web-appearance-group =
    .aria-label = Utseende på nettstedet
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Kontrastinnstillingene dine overstyrer nettstedets utseende.
preferences-web-appearance-link =
    .label = Behandle { -brand-short-name }-temaer i Tillegg og temaer
preferences-contrast-control-group =
    .description = Nettsteder bruker ulike forgrunns- og bakgrunnsfarger. For jevn kontrast kan du bruke de samme fargene på tvers av nettsteder.
    .label = Nettstedskontrast
preferences-contrast-control-radio-group =
    .label = Overstyr farger
preferences-contrast-control-use-platform-settings =
    .label = Automatisk (bruk systeminnstillinger)
    .accesskey = A
preferences-contrast-control-off =
    .label = Av
    .accesskey = A
preferences-contrast-control-custom =
    .label = Tilpasset
    .accesskey = T
preferences-colors-manage-button2 =
    .label = Behandle farger
    .accesskey = B
preferences-colors-manage-button =
    .label = Behandle farger…
    .accesskey = B
preferences-fonts-header2 =
    .label = Skrifttyper
preferences-default-zoom-label =
    .label = Standardskalering
    .accesskey = s
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage } %
preferences-zoom-text-only =
    .label = Forstørr bare tekst
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Hvis «Forstørr bare tekst» er slått på og standardzoom ikke er 100 %, kan det hende at enkelte nettsteder ikke viser innhold riktig.
language-header = Språk
choose-language-description = Velg foretrukket språk på nettsider
website-language-heading =
    .description = Noen nettsider vises på flere språk. Velg språk i ønsket rekkefølge.
    .label = Nettstedsspråk
website-preferred-language =
    .label = Foretrukket språk
website-language-list =
    .aria-label = Foretrukne språk
website-add-language =
    .label = Legg til språk
website-add-language-button =
    .aria-label = Legg til valgt språk
    .title = Legg til valgt språk
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Fjern { $locale }
    .title = Fjern { $locale }
choose-button =
    .label = Velg …
    .accesskey = V
choose-browser-language-description = Velg språkene som brukes til å vise menyer, meldinger og varsler fra { -brand-short-name }.
manage-browser-languages-button =
    .label = Velg alternativer…
    .accesskey = l
confirm-browser-language-change-description = Start om { -brand-short-name } for å bruke disse endringene
confirm-browser-language-change-button = Bruk og start om
browser-language-heading =
    .description = Velg språket som brukes til å vise menyer, meldinger og varsler fra { -brand-short-name }.
    .label = Nettleserspråk
browser-language-preferred-label =
    .label = Foretrukket språk
browser-language-fallback-label =
    .description = Brukes når oversettelsen til foretrukket språk er ufullstendig.
    .label = Reservespråk
browser-language-install-error =
    .message = { -brand-short-name } kan ikke oppdatere språkene dine akkurat nå. Kontroller at du er koblet til Internett, eller prøv på nytt.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Unntak …
    .accesskey = n
settings-translations-header =
    .aria-label = Oversettelser
    .description = Oversett sider eller valgt tekst. For å beskytte personvernet ditt forblir oversettelsene på enheten din.
    .label = Oversettelser
settings-translations-offer-to-translate-label =
    .label = Tilby oversettelse av hele siden
settings-translations-more-settings-button =
    .description = Angi innstillinger for språk, nettsteder og frakoblet oversettelse.
    .label = Flere oversettelsesinnstillinger
settings-translations-subpage-header =
    .heading = Flere oversettelsesinnstillinger
settings-translations-subpage-speed-up-translation-header =
    .description = Last ned komplette språk for raskere oversettelser og for å oversette uten nettforbindelse.
    .label = Raskere oversettelse
settings-translations-subpage-automatic-translation-header =
    .label = Automatisk oversettelse
settings-translations-subpage-always-translate-header =
    .label = Oversett alltid disse språkene
settings-translations-subpage-never-translate-header =
    .label = Oversett aldri disse språkene
settings-translations-subpage-never-translate-sites-header =
    .label = Oversett aldri disse nettstedene
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = For å legge til et nettsted åpner du <img data-l10n-name="translations-icon"/>oversettelsespanelet, velger <img data-l10n-name="settings-icon"/> oversettelsesinnstillinger og deretter «Oversett aldri dette nettstedet»
settings-translations-subpage-language-select-option =
    .label = Legg til språk
settings-translations-subpage-language-add-button =
    .aria-label = Legg til språk
    .title = Legg til språk
settings-translations-subpage-download-languages-header =
    .label = Last ned språk
settings-translations-subpage-download-languages-select-option =
    .label = Velg språk
settings-translations-subpage-download-languages-button =
    .aria-label = Last ned språk
    .title = Last ned språk
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Ingen språk lastet ned
settings-translations-subpage-no-languages-added =
    .label = Ingen språk lagt til
settings-translations-subpage-download-progress = Nedlasting pågår…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Kunne ikke laste ned { $language } ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Prøv igjen
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Slett { $language } ({ $size } MB)?
settings-translations-subpage-download-delete-button =
    .label = Slett
settings-translations-subpage-download-cancel-button =
    .label = Avbryt
settings-translations-subpage-no-sites-added =
    .label = Ingen nettsteder lagt til
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Bruk operativsysteminnstillingene for «{ $localeName }» for å formatere datoer, klokkeslett, tall og målinger.
settings-spellcheck-header =
    .label = Stavekontroll
check-user-spelling =
    .label = Kontroller staving mens du skriver
    .accesskey = t
spellcheck-download-dictionaries =
    .label = Last ned ordbøker
spellcheck-promo =
    .heading = Slik bruker du stavekontroll
    .message = Høyreklikk i et tekstfelt for å slå stavekontroll på eller av, eller for å endre språk. Ikke alle felt støtter stavekontroll.

## Downloads - Files and applications

files-and-applications-title = Filer og programmer
download-save-files-header =
    .label = Lagre filer i
download-save-where-3 =
    .aria-label = Lagre filer i
download-always-ask-where2 =
    .label = Spør hvor filer skal lagres før nedlasting
    .accesskey = S
download-private-browsing-delete2 =
    .label = Slett nedlastinger fra private vinduer ved lukking
    .accesskey = S
applications-header = Program
applications-description = Velg hvordan { -brand-short-name } håndterer filer du henter fra nettet eller programmene du bruker når du surfer.
applications-setting2 =
    .description = Velg hvordan { -brand-short-name } håndterer nedlastede filer og innhold.
    .label = Filer og programmer
applications-filter =
    .placeholder = Søk filtyper eller program
applications-type-column =
    .label = Innholdstype
    .accesskey = I
applications-type-heading = Innholdstype
applications-action-column =
    .label = Handling
    .accesskey = H
applications-action-heading = Handling
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension }-fil
applications-action-save =
    .label = Lagre filen
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Bruk { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Bruk { $app-name } (standard)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Bruk macOS-standardprogrammet
            [windows] Bruk Windows-standardprogrammet
           *[other] Bruk systemets standardprogram
        }
applications-use-other =
    .label = Annet …
applications-select-helper = Velg program
applications-manage-app =
    .label = Programinformasjon …
applications-always-ask =
    .label = Spør alltid
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Åpne i { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Hva skal { -brand-short-name } gjøre med andre filer?
applications-save-for-new-types =
    .label = Lagre filer
    .accesskey = L
applications-save-for-new-types2 =
    .label = Lagre filer automatisk
    .accesskey = L
applications-ask-before-handling =
    .label = Spør om du vil åpne eller lagre filer
    .accesskey = S
applications-ask-before-handling2 =
    .label = Spør om å åpne eller lagre filer
    .accesskey = S
drm-group =
    .label = Digital Rights Management (DRM) innhold
play-drm-content =
    .label = Spill DRM-kontrollert innhold
    .accesskey = S
play-drm-content-learn-more = Les mer
# Variables:
# $version (string) - Firefox version
update-application-version = Versjon { $version } <a data-l10n-name="learn-more">Hva er nytt</a>
update-history-2 =
    .label = Vis oppdateringshistorikk
    .accesskey = p
update-application-installation =
    .label = Installasjon
update-application-radio-group =
    .aria-label = Installasjon
update-application-auto-2 =
    .label = Installer oppdateringer automatisk (anbefalt)
    .accesskey = a
update-application-check-choose-2 =
    .label = Se etter oppdateringer, men velg når du vil installere dem
    .accesskey = S
update-application-background-enabled =
    .label = Når { -brand-short-name } ikke kjører
    .accesskey = N
update-application-warning-cross-user-setting-2 =
    .message = Denne innstillingen gjelder for alle Windows-kontoer og { -brand-short-name }-profiler som bruker denne installasjonen av { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Vis færre oppdateringspåminnelser
    .accesskey = n
update-setting-write-failure-title2 = Kunne ikke lagre oppdateringsinnstillinger
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } oppdaget en feil og lagret ikke denne endringen. Merk, for å kunne lagre endringen av denne oppdateringsinnstillingen, kreves det tillatelse til å skrive til filen nedenfor. Du eller en systemadministrator kan muligens løse feilen ved å gi gruppen Brukere full tilgang til denne filen.
    
    Kunne ikke skrive til filen: { $path }
update-in-progress-title = Oppdatering pågår
update-in-progress-message = Vil du at { -brand-short-name } skal fortsette med denne oppdateringen?
update-in-progress-ok-button = &Avvis
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Fortsett

## About Firefox

about-firefox-header =
    .heading = Om { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Oppdateringer forbedrer hastighet, stabilitet og sikkerhet i { -brand-short-name }.
    .label = { -brand-short-name }-oppdateringer
update-application-suppress-prompts-heading =
    .label = Varsler
update-application-updates-managed-by-os =
    .message = Oppdateringer administreres av operativsystemet ditt

## Firefox support

support-application-heading =
    .description = Feilsøk problemer eller del ideer med fellesskapet.
    .label = { -brand-short-name } brukerstøtte
support-get-help =
    .label = Få hjelp
support-share-ideas =
    .label = Del ideer og tilbakemeldinger

## General Section - Performance

performance-settings-learn-more = Les mer
performance-allow-hw-accel =
    .label = Bruk maskinvareakselerasjon når tilgjengelig
    .accesskey = m
performance-limit-content-process-option = Grense for innholdsprosesser
    .accesskey = G
performance-limit-content-process-enabled-desc = Ytterligere innholdsprosesser kan forbedre ytelsen når du bruker flere faner, men vil også bruke mer minne.
performance-limit-content-process-blocked-desc = Endring av antall innholdsprosesser kan bare gjøres med multiprosess { -brand-short-name }. <a data-l10n-name="learn-more">Lær hvordan du kontrollerer om multiprosess er slått på</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (standard)
performance-group =
    .label = Ytelse
performance-use-recommended-settings-checkbox-2 =
    .description = Disse innstillingene er tilpasset maskinvaren og operativsystemet ditt.
    .label = Bruk anbefalte ytelsesinnstillinger
    .accesskey = B

## Accessibility page

browsing-use-autoscroll =
    .label = Bruk automatisk rulling
    .accesskey = B
keyboard-and-scrolling-group =
    .label = Tastaturnavigasjon og rulling
motion-and-link-group =
    .label = Bevegelses- og lenkestil
browsing-use-smooth-scrolling =
    .label = Bruk jevn rulling
    .accesskey = u
browsing-gtk-use-non-overlay-scrollbars =
    .label = Vis alltid rullefelt
    .accesskey = V
browsing-always-underline-links =
    .label = Understrek alltid lenker
    .accesskey = U
browsing-use-onscreen-keyboard =
    .label = Vis et touch-tastatur når nødvendig
    .accesskey = t
browsing-use-cursor-navigation =
    .label = Bruk alltid piltastene til å navigere på nettsider
    .accesskey = B
browsing-use-full-keyboard-navigation =
    .label = Bruk tabulator-tasten for å flytte fokus mellom skjemakontroller og lenker
    .accesskey = B
browsing-search-on-start-typing =
    .label = Søk etter tekst når jeg begynner å skrive
    .accesskey = k
settings-keyboard-shortcuts-group =
    .description = Styr hvordan du beveger deg rundt og samhandler med { -brand-short-name }.
    .label = Hurtigtaster
settings-keyboard-shortcuts-customkeys-link =
    .label = Tilpass hurtigtaster
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Tilpass innstillingene for adressefeltet under «Søk»
settings-media-group =
    .label = Media
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Bruk bilde-i-bilde
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Fortsett å spille av videoer i bilde-i-bilde når du bytter fane
    .accesskey = s
browsing-media-control =
    .label = Kontroller media via tastatur, hodesett eller virtuelt grensesnitt
    .accesskey = o
recommendations-group =
    .label = Anbefalinger
browsing-cfr-recommendations =
    .label = Anbefal utvidelser mens du surfer
    .accesskey = r
browsing-cfr-features =
    .label = Anbefal funksjoner mens du surfer
    .accesskey = f
browsing-group =
    .label = Nettlesing
preferences-accessibility-header =
    .heading = Tilgjengelighet
preferences-default-zoom-select =
    .aria-label = Standardskalering
preferences-fonts-family =
    .label = Skrifttype
    .accesskey = k
preferences-fonts-size =
    .label = Skriftstørrelse
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = Avanserte innstillinger
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .description = Konfigurer hvordan { -brand-short-name } kobler seg til internett.
    .label = Proxyinnstillinger
network-proxy-connection-settings2 =
    .description = Endring av disse innstillingene kan føre til tilkoblingsproblemer
    .label = Konfigurer proxy
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Nye vinduer og faner
home-new-windows-tabs-description2 = Velg hva du vil se når du åpner startsiden, nye vinduer og nye faner.
home-section =
    .heading = Startside og oppstart

## Home Section - Default Browser

home-default-browser-title =
    .label = Standard nettleser
is-default-browser-2 =
    .message = { -brand-short-name } er standardnettleseren din. Godt valg.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } er ikke din standardnettleser.
set-as-my-default-browser-2 =
    .label = Bruk som standard
    .accesskey = s

## Custom Homepage subpage

home-homepage-mode-label = Startside og nye vinduer
home-newtabs-mode-label = Nye faner
home-restore-defaults =
    .label = Bruk standard
    .accesskey = r
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (standard)
home-mode-choice-custom =
    .label = Tilpassede nettadresser…
home-mode-choice-blank =
    .label = Blank side
home-homepage-custom-url =
    .placeholder = Lim inn en URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Behandle utvidelse
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Bruk åpen nettside
           *[other] Bruk åpne nettsider
        }
    .accesskey = B
choose-bookmark =
    .label = Bruk bokmerke …
    .accesskey = u
home-homepage-title =
    .label = Startside
home-homepage-new-windows =
    .label = Nye vinduer
home-homepage-new-tabs =
    .label = Nye faner
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Velg et bestemt nettsted
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Nettadresse(r)
home-custom-homepage-list =
    .aria-label = Nettstedsadresser
home-custom-homepage-address =
    .placeholder = Skriv inn adresse
home-custom-homepage-address-button =
    .label = Legg til adresse
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Ingen nettsteder lagt til ennå.
home-custom-homepage-delete-address-button =
    .aria-label = Slett adresse
    .title = Slett adresse
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Erstatt med
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Gjeldende åpnede sider
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Bokmerker…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Utvidelse ({ $extension })
home-custom-homepage-header = Tilpasset startside
home-custom-homepage-subpage =
    .heading = Tilpasset startside

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name } Innhold
home-prefs-content-description2 = Velg hvilket innhold som du vil ha på din { -firefox-home-brand-name }-skjerm.
home-prefs-search-header =
    .label = Nettsøk
home-prefs-shortcuts-header =
    .label = Snarveier
home-prefs-shortcuts-description = Nettsteder du lagrer eller besøker
home-prefs-shortcuts-by-option-sponsored =
    .label = Sponsede snarveier
home-prefs-recommended-by-header-generic =
    .label = Anbefalte artikler
home-prefs-recommended-by-description-generic = Enestående innhold kuratert av { -brand-product-name }-familien
home-prefs-stories-header =
    .label = Artikler
home-prefs-stories-description = Personlige artikler basert på aktiviteten din

##

home-prefs-recommended-by-learn-more = Hvordan det virker
home-prefs-recommended-by-option-sponsored-stories =
    .label = Sponsede historier
home-prefs-highlights-option-visited-pages =
    .label = Besøkte nettsider
home-prefs-highlights-options-bookmarks =
    .label = Bokmerker
home-prefs-highlights-option-most-recent-download =
    .label = Siste nedlasting
home-prefs-recent-activity-header =
    .label = Nylig aktivitet
home-prefs-recent-activity-description = Et utvalg av nylige nettsteder og innhold
home-prefs-weather-header =
    .label = Vær
home-prefs-weather-description = Dagens værmelding i korte trekk
home-prefs-weather-learn-more-link = Les mer
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Støtt { -brand-product-name }
home-prefs-mission-message = Våre sponsorer støtter vårt oppdrag om å bygge et bedre internett
home-prefs-mission-message-learn-more-link = Finn ut hvordan
home-prefs-manage-topics-link = Behandle emner
home-prefs-choose-wallpaper-link = Velg et bakgrunnsbilde
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } rekke
           *[other] { $num } rekker
        }

## Search Section

search-show-suggestions-option =
    .label = Vis søkeforslag
    .accesskey = s
search-show-suggestions-url-bar-option =
    .label = Vis søkeforslag i adresselinjens resultater
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Vis søkeforslag før nettleserhistorikk i adressefeltsresultatene
search-show-suggestions-private-windows-2 =
    .label = Søkeforslag i private vinduer
search-suggestions-cant-show-2 =
    .message = Søkeforslag vil ikke vises i adresselinjeresultatene fordi du har konfigurert { -brand-short-name } til å aldri huske historikk.
addressbar-header-1 =
    .description = Velg hvilke forslag som skal vises i adresselinjen
    .label = Adresselinje
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Forslag fra { -brand-short-name } og våre partnere i adresselinjen din.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Vis søkeord i adressefeltet på resultatsidene
search-separate-default-engine-2 =
    .label = Bruk en annen standard søkemotor i private vinduer
    .accesskey = B
search-separate-default-engine-dropdown =
    .aria-label = Standard søkemotor i private vinduer
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Navigering i adresselinjen
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Hopp over resultatmenyen når du bruker tabulatortasten til å flytte fokus
search-suggestions-header-2 =
    .label = Søkemotorforslag
search-one-click-header2 = Søkesnarveier
search-one-click-desc = Velg alternative søkemotorer som vises under adresselinjen og søkelinjen når du begynner å skrive inn et søkeord.
search-one-click-header-3 =
    .description = Velg hvilke søkemotorer og snarveier som vises i adressefeltet.
    .label = Flere søkemotorer
search-engine-list =
    .aria-label = Søkemotorer og snarveier
update-search-engine-success =
    .message = Søkemotoren er oppdatert
search-edit-engine-2 =
    .title = Rediger søkemotor
search-delete-engine =
    .title = Slett søkemotor
search-enable-engine =
    .title = Aktiver søkemotor
search-outlink-to-extensions-page =
    .title = Behandle i utvidelser og temaer
search-choose-engine-column =
    .label = Søkemotor
search-choose-keyword-column =
    .label = Nøkkelord
search-restore-default =
    .label = Gjenopprett standard søkemotorer
    .accesskey = G
search-remove-engine =
    .label = Fjern
    .accesskey = F
search-add-engine =
    .label = Legg til
    .accesskey = L
search-add-engine-2 =
    .label = Legg til søkemotor
    .accesskey = L
search-edit-engine =
    .label = Rediger
    .accesskey = R
search-find-more-link = Finn flere søkemotorer
search-filtering-for-add-engine = Legg til søkemotor
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Duplikat nøkkelord
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Du har valgt et nøkkelord som allerede brukes av «{ $name }». Velg et annet nøkkelord.
search-keyword-warning-bookmark = Du har valgt et nøkkelord som brukes av et annet bokmerke. Velg et annet nøkkelord.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Det finnes allerede en søkemotor med navnet «{ $name }». Velg et annet navn.
remove-engine-confirmation = Er du sikker på at du vil fjerne denne søkemotoren?
remove-engine-remove = Fjern
remove-addon-engine-alert = For å fjerne denne søkemotoren, fjern det tilknyttede tillegget.
search-engine-group =
    .label = Standard søkemotor
search-default-engine =
    .aria-label = Standard søkemotor
# Header for the search section ("search" is a noun).
search-section =
    .heading = Søk

## Containers Section

containers-section-header2 =
    .heading = Beholderinstillinger
containers-card-header2 =
    .description = Skill infokapsler mellom beholdere, slik at du kan bruke forskjellige kontoer på samme nettsted og begrense sporing på tvers av nettsteder.
    .label = Beholdere
containers-add-button2 =
    .label = Legg til ny beholder
    .accesskey = L
containers-list =
    .aria-label = Beholdere
containers-new-tab-check3 =
    .label = Velg en beholder for hver nye fane
    .accesskey = V
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Ikke bruk beholdere for lenker åpnet fra eksterne apper
    .accesskey = I
containers-new-tab-check2 =
    .description = Dette åpner beholdermenyen hver gang du trykker på knappen for å åpne en ny fane.
    .label = Velg en beholder for hver nye fane
    .accesskey = V
containers-settings-button2 =
    .title = Innstillinger
containers-remove-button3 =
    .title = Slett
containers-sites-card-header =
    .description = Velg en beholder for et nettsted, og { -brand-short-name } vil bruke den hver gang nettstedet åpnes.
    .label = Stedsspesifikke beholdere
containers-sites-add-button =
    .label = Legg til nettsted
    .accesskey = L
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Beholder for { $site }
containers-site-remove-button =
    .title = Slett
containers-remove-button2 =
    .title = Fjern

## Account and sync

sync-group-label =
    .label = Synkronisering
account-group-label2 =
    .label = Konto
account-disabled-group =
    .description = Kontoinnstillinger er ikke tilgjengelige.
    .label = Konto
account-placeholder2 =
    .description = Logg inn og hold dataene dine private, krypterte og umiddelbart tilgjengelige overalt der du bruker { -brand-short-name }.
    .label = Du er ikke logget inn
account-sync-section =
    .heading = Konto og synkronisering
pane-account-sync-title2 = Konto og synkronisering
    .title = Konto og synkronisering

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Ta med deg webben
sync-signedout-description2 = Synkroniser bokmerker, historikk, faner, passord, utvidelser og innstillinger på tvers av alle enhetene dine.
sync-signedout-account-signin3 =
    .label = Logg inn for å synkronisere…
    .accesskey = L
sync-signedout-account-signin-4 =
    .label = Logg på kontoen din for å starte synkroniseringen
    .accesskey = o
sync-signedout-account-short =
    .label = Logg inn
    .accesskey = i
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Last ned Firefox for <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> eller <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> for å synkronisere med dine mobile enheter.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Endre profilbilde
    .tooltiptext = Endre profilbilde
sync-profile-picture-account-problem =
    .alt = Kontoprofilbilde
fxa-login-rejected-warning =
    .alt = Advarsel
sync-sign-out =
    .label = Logg ut…
    .accesskey = g
sync-sign-out2 =
    .label = Logg ut
    .accesskey = g
sync-manage-account = Behandle konto
    .accesskey = o
sync-manage-account2 =
    .label = Behandle konto
    .accesskey = o

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } er ikke bekreftet.
sync-signedin-unverified2 =
    .description = Sjekk innboksen din for å bekrefte kontoen og gjøre den offisiell.
    .label = { $email } er ikke bekreftet ennå
sync-signedin-login-failure = Logg inn for å koble til på nytt { $email }
sync-signedin-login-failure2 =
    .description = Logg inn igjen for å koble til på nytt og begynne å synkronisere dine data.
    .label = Du er logget ut av { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Bekreft konto
    .accesskey = B
sync-remove-account =
    .label = Fjern konto
    .accesskey = k
sync-sign-in =
    .label = Logg inn
    .accesskey = g

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synkronisering: PÅ
prefs-syncing-on-2 =
    .label = Synkronisering er PÅ
prefs-syncing-off = Synkronisering: AV
prefs-syncing-off-2 =
    .description = Slå på synkronisering for å få bokmerkene, passordene, historikken og mer tilgjengelig på alle enhetene dine.
    .label = Synkronisering er AV
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Slå på synkronisering for å få bokmerkene, passordene, historikken og mer på denne enheten.
    .label = Synkronisering er AV
prefs-sync-turn-on-syncing =
    .label = Slå på synkronisering…
    .accesskey = S
prefs-sync-turn-on-syncing-2 =
    .label = Slå på synkronisering
    .accesskey = S
prefs-sync-offer-setup-label2 = Synkroniser bokmerker, historikk, faner, passord, utvidelser og innstillinger på tvers av alle enhetene dine.
prefs-sync-now-button =
    .label = Synkroniser nå
    .accesskey = n
prefs-sync-now-button-2 =
    .label = Synkroniser nå
    .accesskey = n
prefs-syncing-button =
    .label = Synkroniserer…
prefs-syncing-button-2 =
    .label = Synkroniserer…
    .title = Synkroniser nå
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Valgene dine for synkronisering gjelder nå bare for denne enheten.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Du synkroniserer disse elementene mellom alle de tilkoblede enhetene dine:
sync-syncing-across-devices-heading-2 = Data synkronisert på tvers av enheter
sync-syncing-across-devices-heading-3 = Datasynkronisering på denne enheten
sync-syncing-across-devices-empty-state2 =
    .description = Du synkroniserer ingenting … ennå. Start synkronisering for å få alle dataene dine på alle enhetene dine.
    .label = Behandle synkroniserte data
sync-syncing-across-devices-empty-state3 =
    .description = Du synkroniserer ingenting … ennå. Velg hva du vil synkronisere på denne enheten.
    .label = Behandle synkroniserte data
sync-currently-syncing-bookmarks = Bokmerker
sync-currently-syncing-history = Historikk
sync-currently-syncing-tabs = Åpne faner
sync-currently-syncing-passwords = Passord
sync-currently-syncing-addresses = Adresser
sync-currently-syncing-payment-methods = Betalingsmåter
sync-currently-syncing-addons = Utvidelser
sync-currently-syncing-settings = Innstillinger
sync-manage-options =
    .label = Behandle synkronisering …
    .accesskey = B
sync-manage-options-2 =
    .label = Behandle synkroniserte data
    .accesskey = B
settings-sync-disconnect-button =
    .label = Koble fra

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Bokmerker
    .accesskey = B
sync-engine-history =
    .label = Historikk
    .accesskey = s
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Åpne faner
    .tooltiptext = Åpne faner fra de andre enhetene dine
    .accesskey = p
sync-engine-tabs =
    .label = Åpne faner
    .tooltiptext = En liste over hva som er åpent på alle synkroniserte enheter
    .accesskey = f
sync-engine-passwords =
    .label = Passord
    .tooltiptext = Passord du har lagret
    .accesskey = P
sync-engine-addresses2 =
    .label = Adresser
    .tooltiptext = Adresser du har lagret i { -brand-short-name }
    .accesskey = e
sync-engine-payment-methods3 =
    .label = Betalingsmåter
    .tooltiptext = Betalingsmåter du har lagret
    .accesskey = n
sync-engine-addons2 =
    .label = Tillegg
    .tooltiptext = Utvidelser og temaer du har lagt til i { -brand-short-name } for datamaskin
    .accesskey = T
sync-engine-settings2 =
    .label = Innstillinger
    .tooltiptext = { -brand-short-name }-innstillinger der det er aktuelt
    .accesskey = s
sync-engine-addresses =
    .label = Adresser
    .tooltiptext = Postadresser du har lagret (bare datamaskin)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = Betalingsmåter
    .tooltiptext = Navn, kortnummer og utløpsdatoer
    .accesskey = n
sync-engine-addons =
    .label = Utvidelser
    .tooltiptext = Utvidelser og temaer for Firefox for datamaskin
    .accesskey = U
sync-engine-settings =
    .label = Innstillinger
    .tooltiptext = Generelle, personvern- og sikkerhetsinnstillinger du har endret
    .accesskey = n
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Lagre
    .buttonlabelextra2 = Koble fra …
    .buttonaccesskeyaccept = L
    .buttonaccesskeyextra2 = K
    .style = min-width: 36em;
    .title = Behandle hva som synkroniseres på alle de tilkoblede enhetene dine
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Lagre
    .buttonlabelextra2 = Koble fra …
    .buttonaccesskeyaccept = L
    .buttonaccesskeyextra2 = K
    .style = min-width: 36em;
    .title = Behandle hva som synkroniseres på denne enheten

## The device name controls.

sync-device-name-header = Enhetsnavn
sync-device-name-header-2 =
    .label = Enhetsnavn
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Enhetsnavn
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Endre enhetsnavn
    .accesskey = E
sync-device-name-change =
    .label = Endre enhetsnavn…
    .accesskey = E
sync-device-name-cancel =
    .label = Avbryt
    .accesskey = A
sync-device-name-save =
    .label = Lagre
    .accesskey = L
sync-connect-another-device = Koble til en annen enhet
sync-connect-another-device-2 =
    .label = Koble til en annen enhet

## Privacy Section

privacy-header = Nettleserpersonvern

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Passord
    .searchkeywords = innlogginger
forms-passwords-header =
    .aria-label = Passord
    .label = Passord
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Spør om å lagre passord
    .accesskey = S
forms-manage-password-exceptions =
    .label = Behandle passordunntak
    .accesskey = B
forms-exceptions =
    .label = Unntak …
    .accesskey = n
forms-suggest-passwords =
    .label = Foreslå sterkt passord …
    .accesskey = F
forms-breach-alerts =
    .label = Vis varsler om passord for datalekkasjer på nettsteder
    .accesskey = p
forms-breach-alerts-learn-more-link = Les mer
preferences-relay-integration-checkbox2 =
    .label = Foreslå { -relay-brand-name } e-postalias for å beskytte e-postadressen din
    .accesskey = F
relay-integration-learn-more-link = Les mer
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Fyll ut brukernavn og passord automatisk
    .accesskey = F
forms-fill-usernames-and-passwords-2 =
    .label = Lagre og fyll ut brukernavn og passord automatisk
    .accesskey = f
forms-saved-passwords =
    .label = Lagrede passord
    .accesskey = L
forms-saved-passwords-2 =
    .label = Behandle lagrede passord
    .accesskey = d
forms-saved-passwords-searchkeywords = Innlogginger fra følgende nettsted er lagret på datamaskinen
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Ytterligere beskyttelse
forms-primary-pw-use =
    .label = Bruk et hovedpassord
    .accesskey = B
forms-primary-pw-use-2 =
    .description = Legger til et ekstra lag med sikkerhet for å beskytte dine lagrede passord.
    .label = Bruk et hovedpassord
    .accesskey = B
forms-primary-pw-set =
    .label = Angi hovedpassord
forms-primary-pw-on-2 = Hovedpassord er <strong>PÅ</strong>
forms-primary-pw-on =
    .label = Hovedpassord er PÅ
forms-primary-pw-change-2 =
    .label = Endre hovedpassord
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Slå det av
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Krev enhetsinnlogging for å fylle ut og behandle passord
forms-os-reauth-2 =
    .label = Krev enhetsinnlogging for å behandle passord
forms-primary-pw-learn-more-link = Les mer
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Endre hovedpassord …
    .accesskey = d
forms-primary-pw-change =
    .label = Endre hovedpassord…
    .accesskey = p
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Du er for tiden i FIPS-modus. FIPS krever at du bruker et hovedpassord.
forms-master-pw-fips-desc = Passordendring mislyktes
forms-windows-sso =
    .label = Tillat Windows enkel pålogging for Microsoft, arbeids- og skolekontoer
forms-windows-sso-learn-more-link = Les mer
forms-windows-sso-desc = Behandle kontoer i dine enhetensinnstillinger
windows-passkey-settings-label = Behandle passnøkkel i systeminnstillingene
privacy-panel-settings-header =
    .description = Få hjelp til å beskytte informasjonen din på nettet i { -brand-short-name }.
    .label = Innstillinger for personvernpanelet
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Vis meldinger om datalekkasjer
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Skriv inn innloggingsinformasjonen for Windows for å opprette et hovedpassord. Dette vil gjøre kontoene dine tryggere.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = opprett et hovedpassord
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] endre innstillingene for betalingsmåter
       *[other] { -brand-short-name } prøver å endre innstillingene for betalingsmåter. Bruk din enhetsinnlogging for å tillate dette.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Betalingsmåter
autofill-payment-methods-checkbox-message-2 =
    .label = Lagre og fyll ut betalingsinformasjon automatisk
    .accesskey = a
autofill-payment-methods-manage-payments-title =
    .heading = Behandle betalingsmåter
autofill-payment-methods-manage-payments-button =
    .label = Behandle betalingsmåter
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Krev enhetspålogging for å autofylle
    .accesskey = K
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Krev enhetspålogging for å automatisk fylle ut og behandle betalingsmåter
    .accesskey = r
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Lagre sikkerhetskoder
    .accesskey = g
autofill-payment-methods-add-button = Legg til ny betalingsmåte
payments-list-header =
    .label = Betalingsmåter
payments-delete-payment-prompt-title = Slette denne betalingsmåten?
payments-delete-payment-prompt-confirm-button = Slett
payments-delete-payment-prompt-cancel-button = Avbryt
payments-delete-payment-button-label =
    .aria-label = Slett
payments-edit-payment-button-label =
    .aria-label = Rediger
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Ingen betalingsmåter lagt til
autofill-addresses-checkbox-message =
    .label = Lagre og autoutfyll adresser
    .accesskey = L
autofill-addresses-manage-addresses-button =
    .label = Behandle adresser og mer
    .accesskey = B
addresses-list-header =
    .label = Adresser
addreses-delete-address-button-label =
    .aria-label = Slett
addreses-edit-address-button-label =
    .aria-label = Rediger
addresses-delete-address-prompt-title = Slette denne adressen?
addresses-delete-address-prompt-confirm-button = Slett
addresses-delete-address-prompt-cancel-button = Avbryt
autofill-addresses-add-button = Legg til ny adresse
autofill-addresses-manage-addresses-title =
    .heading = Behandle adresser og mer
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Ingen adresser lagt til
personal-info-group =
    .label = Personopplysninger
autofill-personal-info-checkbox-message =
    .label = Lagre og fyll ut personlig informasjon automatisk
autofill-personal-info-manage-button =
    .label = Behandle personlig informasjon
passports-list-header =
    .label = Pass
passports-delete-passport-button-label =
    .aria-label = Slett
passports-edit-passport-button-label =
    .aria-label = Rediger
passports-delete-passport-prompt-title = Slette dette passet?
passports-delete-passport-prompt-confirm-button = Slett
passports-delete-passport-prompt-cancel-button = Avbryt
autofill-passports-add-button = Legg til nytt pass
autofill-personal-info-manage-title =
    .heading = Behandle personlig informasjon
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Ingen pass lagt til
pane-passwords-autofill-title2 = Passord og autofyll
    .title = Passord og autofyll
preferences-passwords-autofill-header =
    .heading = Passord og autofyll
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adresser og mer
payments-group =
    .label = Betalingsmåter

## Privacy Section - History

history-remember-option-never2 =
    .description = Hvert vindu fungerer som et privat vindu. Når dette er på, må utvidelser tillates.
    .label = Lagre aldri noe historikk
history-remember-option-custom2 =
    .label = Tilpass historikk
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } vil lagre informasjon om besøkte nettsider, skjema- og søkehistorikk.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } vil bruke de samme innstillingene som privat nettlesing, og vil ikke huske noen historikk mens du bruker nettet.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } vil bruke tilpassede innstillinger for nettleser-, nedlastings-, skjema- og søkehistorikk.
history-private-browsing-permanent =
    .label = Alltid bruk privat nettlesing-modus
    .accesskey = A
history-remember-browser-option =
    .label = Husk nettleser- og nedlastingshistorikk
    .accesskey = n
history-remember-search-option =
    .label = Husk søke- og skjemahistorikk
    .accesskey = ø
history-clear-on-close-option =
    .label = Slett historikk når { -brand-short-name } avsluttes
    .accesskey = S
history-clear-on-close-settings =
    .label = Innstillinger …
    .accesskey = I
history-shutdown-exceptions =
    .label = Behandle unntak
    .accesskey = B
history-clear-button =
    .label = Tøm historikk…
    .accesskey = s
history-header2 =
    .heading = Historikk
history-section-header =
    .description = Velg hva du vil at { -brand-short-name } skal huske når du lukker nettleseren.
    .label = Historikk
history-custom-section-header =
    .description = Tilpass hva du vil at { -brand-short-name } skal huske når du lukker nettleseren.
    .label = Avanserte innstillinger
history-custom-button =
    .label = Velg hva du vil at { -brand-short-name } skal huske
history-group =
    .label = Historikk
history-mode-radio-group =
    .aria-label = Historikk
history-remember-option-all2 =
    .label = Huske historikk

## Privacy Section - Site Data

sitedata-total-size-calculating = Regner ut størrelse på nettstedsdata og hurtiglager…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Nettsteder bruker for øyeblikket <strong>{ $value } { $unit }</strong> med diskplass.
sitedata-learn-more = Les mer
sitedata-delete-on-close2 =
    .label = Fjern infokapsler og nettstedsdata hver gang du lukker { -brand-short-name }
    .accesskey = n
sitedata-delete-on-close-private-browsing3 =
    .message = Basert på historikkinnstillingene dine, sletter { -brand-short-name } infokapsler og nettstedsdata fra økten din når du lukker nettleseren.
sitedata-delete-on-close-private-browsing4 =
    .heading = Historikk lagres ikke.
    .message = { -brand-short-name } fjerner infokapsler og nettstedsdata fra økten din når du lukker nettleseren.
sitedata-option-block-cross-site-trackers =
    .label = Sporing på tvers av nettsteder
sitedata-option-block-cross-site-tracking-cookies =
    .label = Sporingsinfokapsler på tvers av nettsteder
sitedata-option-block-cross-site-cookies2 =
    .label = Isoler infokapsler på tvers av nettsteder
sitedata-option-block-unvisited =
    .label = Infokapsler fra ubesøkte nettsteder
sitedata-option-block-all-cross-site-cookies =
    .label = Alle infokapsler på tvers av nettsteder (kan føre til at nettsteder ikke fungerer)
sitedata-option-block-all =
    .label = Alle infokapsler (vil føre til feil på nettsteder)
sitedata-clear2 =
    .label = Fjern nettleserdata
    .accesskey = j
sitedata-settings2 =
    .label = Behandle nettleserdata
    .accesskey = B
sitedata-cookies-exceptions =
    .label = Behandle unntak…
    .accesskey = B
sitedata-cookies-exceptions2 =
    .description = Du kan angi hvilke nettsteder som alltid eller aldri har lov til å bruke infokapsler og nettstedsdata.
    .label = Behandle unntak
    .accesskey = e
sitedata-heading =
    .description = Behandle infokapsler, historikk, hurtigbuffer, nettstedsdata og mer.
    .label = Nettlesingsdata
sitedata-settings3 =
    .label = Fjern data for bestemte nettsteder
    .accesskey = e
sitedata-cookies-exceptions3 =
    .description = Velg hvordan bestemte nettsteder skal håndtere infokapsler og nettstedsdata.
    .label = Behandle unntak
    .accesskey = u
cookies-site-data-group =
    .label = Infokapsler og nettstedsdata

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Blokkering av infokapselbanner
cookie-banner-blocker-description = Når et nettsted spør om de kan bruke infokapsler i privat nettlesingsmodus, så avviser { -brand-short-name } forespørselen automatisk for deg. Bare på støttede nettsteder.
cookie-banner-learn-more = Les mer
cookie-banner-blocker-checkbox-label =
    .label = Avslå automatisk infokapselbannere

## Search Section

addressbar-locbar-history-option =
    .label = Nettleserhistorikk
    .accesskey = h
addressbar-locbar-bookmarks-option =
    .label = Bokmerker
    .accesskey = k
addressbar-locbar-clipboard-option =
    .label = Utklippstavle
    .accesskey = U
addressbar-locbar-openpage-option =
    .label = Åpne faner
    .accesskey = f
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Snarveier
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = Mest besøkte nettsteder
    .accesskey = M
addressbar-locbar-engines-option-1 =
    .label = Foreslå søkemotorer å bruke
    .accesskey = s
addressbar-locbar-quickactions-option =
    .label = Hurtige handlinger
    .accesskey = H
addressbar-locbar-showrecentsearches-option-2 =
    .label = Nylige søk
    .accesskey = y
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Populære søkeforslag
    .accesskey = o
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Få forslag fra nettet relatert til søket ditt
    .label = Forslag fra { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Støtt { -brand-short-name } med sporadiske sponsede forslag.
    .label = Forslag fra sponsorer
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Hent forslag fra Mozilla mens du skriver
addressbar-dismissed-suggestions-label-2 =
    .description = Gjenopprett avviste forslag fra sponsorer og { -brand-short-name }.
    .label = Forkastede forslag
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Gjenopprett forslag

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Utvidet sporingsbeskyttelse
content-blocking-section-top-level-description = Sporere følger deg rundt på nettet for å samle informasjon om surfevanene og interessene dine. { -brand-short-name } blokkerer mange av disse sporere og andre ondsinnede skript.
content-blocking-learn-more = Les mer
content-blocking-fpi-incompatibility-warning = Du bruker First Party Isolation (FPI), som tilsidesetter noen av infokapsel-innstillingene til { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Du bruker Resist Fingerprinting (RFP), som erstatter noen av { -brand-short-name } sine beskyttelsesinnstillinger for fingeravtrykk. Dette kan føre til at enkelte nettsteder ikke vil fungere.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standard
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Streng
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Tilpasset
    .accesskey = T

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Balansert for beskyttelse og ytelse. Sider lastes normalt.
content-blocking-etp-strict-desc = Sterkere beskyttelse, men kan føre til at noen nettsteder eller innhold ikke vil fungere.
content-blocking-etp-custom-desc = Velg hvilke sporere og skript som skal blokkeres.
content-blocking-etp-blocking-desc = { -brand-short-name } blokkerer følgende:
content-blocking-private-windows = Sporingsinnhold i private vinduer
content-blocking-cross-site-cookies-in-all-windows2 = Infokapsler på tvers av nettsteder i alle vinduer
content-blocking-cross-site-tracking-cookies = Sporingsinfokapsler på tvers av nettsteder
content-blocking-all-cross-site-cookies-private-windows = Infokapsler på tvers av nettsteder i private vindu
content-blocking-isolate-cross-site-cookies = Isoler infokapsler på tvers av nettsteder
content-blocking-social-media-trackers = Sporing via sosiale medier
content-blocking-all-cookies = Alle infokapsler
content-blocking-unvisited-cookies = Infokapsler fra ubesøkte nettsteder
content-blocking-all-windows-tracking-content = Sporingsinnhold i alle vinduer
content-blocking-all-cross-site-cookies = Alle infokapsler på tvers av nettsteder
content-blocking-cryptominers = Kryptoutvinnere
content-blocking-fingerprinters = Nettleseravtrykk
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Kjente og mistenkte nettleseravtrykksporere
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Total beskyttelse mot infokapsler isolerer infokapsler til nettstedet du er på, så sporere ikke kan bruke dem til å følge deg mellom nettsteder.
content-blocking-etp-standard-tcp-rollout-learn-more = Les mer
content-blocking-etp-standard-tcp-title = Inkluderer total beskyttelse mot infokapsler, vår kraftigste personvernfunksjon noensinne
content-blocking-warning-title-2 = Noen nettsteder kan slutte å fungere med streng sporingsbeskyttelse
content-blocking-warning-title-custom = Noen nettsteder kan slutte å fungere med tilpasset sporingsbeskyttelse
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } anbefaler å bruke innstillingene «Fiks nettstedsproblemer» for å redusere ødelagte funksjoner og innhold på nettsteder. Hvis et nettsted virker ødelagt, kan du prøve å slå av sporingsbeskyttelse for det nettstedet for å laste alt innhold.
content-blocking-warning-learn-how = Les hvordan
content-blocking-baseline-exceptions-3 =
    .description = Hjelper med å laste inn nettsteder og funksjoner ved å oppheve blokkering av bare nødvendige elementer som kan inneholde sporere. Dekker de fleste vanlige problemer.
    .label = Fiks større nettstedsproblemer (anbefalt)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Gjenoppretter ting som videoer i en artikkel eller kommentarfelt ved å oppheve blokkering av elementer som kan inneholde sporere. Dette kan redusere problemer på nettsteder, men gir mindre beskyttelse. Må brukes sammen med fikser for større problemer.
    .label = Fiks mindre nettstedsproblemer
content-blocking-baseline-uncheck-warning-dialog-title = Er du sikker på at du vil slå av fiksene?
content-blocking-baseline-uncheck-warning-dialog-body = Denne innstillingen bidrar til å fikse de vanligste nettstedsproblemene. Hvis du slår den av, kan det hende at noen nettsteder ikke fungerer, og { -brand-short-name } vil ikke kunne hjelpe med å feilsøke disse problemene.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Slå av fiksene
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Behold fiksene på
content-blocking-reload-description = Du må oppdatere fanene dine for å kunne bruke disse endringene.
content-blocking-reload-tabs-button =
    .label = Last inn alle faner på nytt
    .accesskey = L
content-blocking-tracking-content-label =
    .label = Sporingsinnhold
    .accesskey = S
content-blocking-tracking-protection-option-all-windows =
    .label = I alle vindu
    .accesskey = a
content-blocking-option-private =
    .label = Bare i private vindu
    .accesskey = p
content-blocking-cookies-label =
    .label = Infokapsler
    .accesskey = k
content-blocking-expand-section =
    .tooltiptext = Mer informasjon
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Kryptoutvinnere
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Kjente nettleseravtrykksporere
    .accesskey = K
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Mistenkt nettleseravtrykksporere
    .accesskey = M

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Behandle unntak…
    .accesskey = u

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Sett varsler på pause til { -brand-short-name } starter på nytt
    .accesskey = n
permissions-autoplay2 =
    .label = Automatisk avspilling
permissions-block-popups2 =
    .label = Blokker sprettoppvinduer og tredjepartvideresendinger
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Legg til nettsteder som kan åpne sprettoppvinduer og bruke tredjepartsomdirigeringer.
    .label = Behandle unntak
    .searchkeywords = sprettoppvinduer
    .accesskey = u
permissions-addon-install-warning3 =
    .label = Vis advarsel når nettsteder prøver å installere utvidelser
    .accesskey = a
permissions-addon-exceptions2 =
    .label = Velg hvilke nettsteder som kan installere utvidelser
    .accesskey = e
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Tillat nettsteder å be om å åpne applenker.
    .accesskey = T
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Behandle blokkerte nettsteder
    .accesskey = B
permissions-location2 =
    .label = Plassering
permissions-localhost2 =
    .label = Enhetsapper og -tjenester
permissions-local-network2 =
    .label = Lokale nettverksenheter
permissions-xr2 =
    .label = Virtuell virkelighet
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Høyttaler
permissions-notification2 =
    .label = Varsler
permissions-header3 =
    .description = Behandle hva nettsteder kan få tilgang til, styre eller utløse.
    .label = Tillatelser
permissions-data-section =
    .heading = Tillatelser og data
pane-permissions-data-title2 = Tillatelser og data
    .title = Tillatelser og data
notifications-section-header =
    .heading = Varsler
notifications-entry-card-header =
    .description = Velg hvilke nettsteder som kan sende varsler, og hvordan disse varslene vises.
    .label = Varsler
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } nettsted
           *[other] { $count } nettsteder
        }
    .label = Behandle varslingsinnstillinger
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Behandle innstillinger for nettstedsvarsler
notifications-website-card-header =
    .description = Velg hvordan nettsteder kan sende varsler.
    .label = Nettstedvarsler
notifications-filter =
    .placeholder = Søk nettsteder
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Nettsted
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Tillat varsler
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Nettsteder
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Alltid
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Tillat
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Aldri
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Ingen nettstedsvarsler er lagt til.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Ingen nettstedsvarsler samsvarer med søket ditt.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = For å sørge for at denne endringen er inkludert i sikkerhetskopiene dine, åpne hver profil og velg «Sikkerhetskopier nå» i Innstillinger.
nimbus-rollouts =
    .description = Endringer rulles ut eksternt.
    .label = Tillat at { -brand-short-name } forbedrer funksjoner, ytelse og stabilitet mellom oppdateringer
addon-recommendations3 =
    .description = Få anbefalinger for utvidelser for å forbedre nettleseropplevelsen din.
    .label = Tillat tilpassede anbefalinger for utvidelser
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Datarapportering er deaktivert for denne byggekonfigurasjonen.
collection-backlogged-crash-reports2 =
    .label = Send inn krasjrapporter automatisk
    .accesskey = k
collection-backlogged-crash-reports-description = Dette hjelper { -vendor-short-name } med å diagnostisere og fikse problemer med nettleseren. Rapporter kan inneholde personlige eller sensitive data.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Samme innstillinger, nytt utseende!
    .message = Vi har omorganisert denne siden slik at den er enklere å få oversikt over og utforske. De personlige innstillingene dine er ikke endret, og alt er fortsatt her. Tips: bruk søk for å gå rett til det du trenger.
settings-redesign-promo-dismiss-button =
    .label = Jeg forstår
privacy-segmentation-section-header = Nye funksjoner som forbedrer surfingen din
privacy-segmentation-section-description = Når vi tilbyr funksjoner som bruker dine data for å gi deg en mer personlig opplevelse:
privacy-segmentation-radio-off =
    .label = Bruk { -brand-product-name }-anbefalinger
privacy-segmentation-radio-on =
    .label = Vis detaljert informasjon
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Vi streber etter å gi deg valg og samler bare inn minimalt med data som er nødvendig for å forbedre { -brand-product-name } for alle.
    .label = Datainnsamling og bruk for { -brand-short-name }
    .searchkeywords = telemetri
data-collection-link = Vis personvernerklæring
data-collection-preferences-across-profiles =
    .message = Disse innstillingene gjelder for alle { -brand-product-name }-profiler på denne enheten.
data-collection-profiles-link = Vis alle profiler
data-collection-health-report-telemetry-disabled =
    .message = Du tillater ikke lenger { -vendor-short-name } å samle inn teknisk data og data om bruk. Alle tidligere data vil bli slettet innen 30 dager.
data-collection-health-report =
    .description = Dette hjelper oss med å forbedre funksjoner, ytelse og stabilitet i { -brand-product-name }.
    .label = Send tekniske data og data om bruk til { -vendor-short-name }
    .accesskey = e
data-collection-health-report-disabled =
    .description = Datarapportering er deaktivert for denne byggkonfigurasjonen.
    .label = Send tekniske data og data om bruk til { -vendor-short-name }
    .accesskey = t
data-collection-run-studies =
    .description = { -brand-short-name } velger tilfeldig brukere for å teste funksjoner, noe som bidrar til å forbedre kvaliteten for alle.
    .label = Tillat at { -brand-short-name } kjører funksjonsstudier
data-collection-studies-link =
    .label = Vis { -brand-short-name }-studier
data-collection-backlogged-crash-reports =
    .description = Dette hjelper { -vendor-short-name } med å diagnostisere og løse problemer med nettleseren. Rapportene kan inneholde personlige eller sensitive data.
    .label = Send krasjrapporter automatisk
    .accesskey = S
data-collection-usage-ping =
    .description = Dette hjelper { -vendor-short-name } med å beregne aktive brukere.
    .label = Send ping for daglig bruk til { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Sikkerhet
browsing-protection-group2 =
    .description = Farlige nettsteder og nedlastinger kan sette dine data og enhet i fare. { -brand-short-name } blokkerer dem automatisk og advarer deg om risikabel eller uønsket programvare.
    .label = Beskyttelse mot villedende innhold og farlig programvare
security-enable-safe-browsing =
    .label = Blokker farlig og villendende innhold
    .accesskey = B
security-enable-safe-browsing-link = Les mer
security-safe-browsing-warning =
    .message = Hvis du slår av dette, reduseres beskyttelsen mot svindel, ondsinnede nettsteder og farlige nedlastinger.
security-block-downloads =
    .label = Blokker farlige nedlastinger
    .accesskey = f
security-block-uncommon-software =
    .label = Advar deg om uønskede eller uvanlige programmer
    .accesskey = d

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Tillat at { -brand-short-name } automatisk stoler på tredjeparts rotsertifikater du installerer
    .accesskey = T
certs-devices-enable-fips = Bruk FIPS
space-alert-over-5gb-settings-button =
    .label = Åpne Innstillinger
    .accesskey = p
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } er i ferd med å gå tom for plass på disken.</strong> Det kan hende at innholdet på nettstedet ikke vises ordentlig. Du kan tømme lagret data i Innstillinger > Personern og sikkerhet > Infokapsler og nettstedsdata.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } er i ferd med å gå tom for plass på disken.</strong> Det kan hende at innholdet på nettsiden ikke vises ordentlig. Gå til «Les mer» for å optimalisere diskbruken din for en bedre nettleseropplevelse.
certs-description3 =
    .description = Konfigurer sertifikatene som { -brand-short-name } bruker til å verifisere sikre tilkoblinger.
    .label = Sertifikater
certs-view2 =
    .label = Behandle sertifikater
    .accesskey = s
certs-devices2 =
    .label = Behandle sikkerhetsenheter
    .accesskey = h

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Hvordan kun-HTTPS-modus fungerer
httpsonly-radio-enabled =
    .label = Aktiver kun-HTTPS i alle vinduer
httpsonly-radio-enabled-pbm =
    .label = Aktiver kun-HTTPS kun i private vinduer
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } kan fortsatt oppgradere noen tilkoblinger
    .label = Ikke aktiver kun-HTTPS-modus
httpsonly-group =
    .description = Tillater kun sikre tilkoblinger til nettsteder. { -brand-short-name } vil spørre, før en usikker tilkobling opprettes.
    .label = Kun-HTTPS-modus
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS-over-HTTPS
dns-over-https-group2 =
    .description = Domain Name System over HTTPS (DoH) krypterer nettstedsoppslag slik at det blir vanskeligere for internettleverandøren din eller andre å se hvilke nettsteder du er i ferd med å besøke.
    .label = DNS-over-HTTPS
preferences-doh-description2 = Domain Name System (DNS) over HTTPS sender forespørselen din om et domenenavn gjennom en kryptert tilkobling, og gir en sikker DNS og gjør det vanskeligere for andre å se hvilket nettsted du er i ferd med å besøke.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Status: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Leverandør: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Ugyldig nettadresse
preferences-doh-steering-status = Bruker lokal leverandør
preferences-doh-status-active = Aktiv
preferences-doh-status-disabled = Av
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Ikke aktiv ({ $reason })
preferences-doh-group-message2 = Aktiver DNS-over-HTTPS med:
preferences-doh-radio-group =
    .aria-label = Aktiver DNS-over-HTTPS med:
preferences-doh-expand-section =
    .tooltiptext = Mer informasjon
preferences-doh-setting-default =
    .label = Standardbeskyttelse
    .accesskey = d
preferences-doh-default-desc = { -brand-short-name } bestemmer når sikker DNS skal brukes for å beskytte personvernet ditt.
preferences-doh-default-detailed-desc-1 = Bruk sikker DNS i regioner der den er tilgjengelig
preferences-doh-default-detailed-desc-2 = Bruk din standard DNS-resolver hvis det er et problem med den sikre DNS-leverandøren
preferences-doh-default-detailed-desc-3 = Bruk en lokal leverandør, hvis mulig
preferences-doh-default-detailed-desc-4 = Slå av når VPN, foreldrekontroll eller bedriftspolicyer er aktive
preferences-doh-default-detailed-desc-5 = Slå av når et nettverk forteller { -brand-short-name } at det sikker DNS ikke skal brukes
preferences-doh-setting-enabled =
    .label = Økt beskyttelse
    .accesskey = k
preferences-doh-enabled-desc = Du kontrollerer når du skal bruke sikker DNS og velger leverandør.
preferences-doh-enabled-detailed-desc-1 = Bruk leverandøren du velger
preferences-doh-enabled-detailed-desc-2 = Bruk bare standard DNS-resolver hvis det er et problem med sikker DNS
preferences-doh-setting-strict =
    .label = Maks beskyttelse
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } vil alltid bruke sikker DNS. Du vil se en advarsel om sikkerhetsrisiko før vi bruker systemets DNS.
preferences-doh-strict-detailed-desc-1 = Bruk kun leverandøren du velger
preferences-doh-strict-detailed-desc-2 = Advar alltid hvis sikker DNS ikke er tilgjengelig
preferences-doh-strict-detailed-desc-3 = Hvis sikker DNS ikke er tilgjengelig, vil ikke nettsteder lastes eller fungere som de skal
preferences-doh-setting-off =
    .label = Av
    .accesskey = A
preferences-doh-off-desc = Bruk din standard DNS-resolver
preferences-doh-select-resolver = Velg leverandør:
preferences-doh-manage-exceptions =
    .label = Behandle unntak…
    .accesskey = e
preferences-doh-overview-default =
    .description = Bruk sikker DNS i områder der det er tilgjengelig.
    .label = Standardbeskyttelse
preferences-doh-overview-custom =
    .description = Bruk alltid sikker DNS med kontroll over leverandør og reserveatferd.
    .label = Tilpasset
preferences-doh-overview-off =
    .description = Bruk standard DNS-oppslagstjeneste.
    .label = Av
preferences-doh-advanced-button =
    .label = Avanserte innstillinger
preferences-doh-advanced-section =
    .description = Domain Name System over HTTPS (DoH) krypterer nettstedsoppslag slik at det blir vanskeligere for internettleverandøren din eller andre å se hvilke nettsteder du er i ferd med å besøke.
    .label = Avanserte innstillinger
preferences-doh-manage-exceptions2 =
    .label = Behandle unntak
    .accesskey = h
preferences-doh-radio-default =
    .description = Bruk sikker DNS i områder der det er tilgjengelig
    .label = Standard
preferences-doh-radio-custom =
    .description = Bruk alltid sikker DNS med kontroll over leverandør og reserveatferd
    .label = Tilpasset
preferences-doh-radio-off =
    .description = Bruk standard DNS-oppslagstjeneste
    .label = Av
preferences-doh-fallback-label =
    .label = Varsle meg alltid hvis sikker DNS ikke er tilgjengelig
preferences-doh-status-item-off =
    .message = DNS-over-HTTPS er av
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS-over-HTTPS fungerer ikke fordi det oppstod en feil ({ $reason }) da vi forsøkte å bruke leverandøren { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS-over-HTTPS fungerer ikke fordi vi mottok en ugyldig URL ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS-over-HTTPS bruker leverandøren { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS-over-HTTPS fungerer ikke fordi det oppstod en feil ({ $reason }) da vi forsøkte å bruke den lokale leverandøren { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS-over-HTTPS bruker den lokale leverandøren { $name }
preferences-doh-select-resolver-label =
    .label = Velg leverandør:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Bruk denne leverandøren for DNS-over-HTTPS-oppslag
preferences-doh-custom-provider-label =
    .aria-label = Skriv inn en tilpasset leverandør-URL
preferences-doh-header2 =
    .heading = DNS-over-HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Tilkoblings- og programvaresikkerhet
preferences-connection-link-section =
    .description = Se hvordan tilkoblinger holdes sikre, skadelig programvare blokkeres og nettsteder verifiseres.
    .label = Tilkobling og programvaresikkerhet
preferences-connection-link-button =
    .label = Avanserte innstillinger

## The following strings are used in the Download section of settings

desktop-folder-name = Skrivebord
downloads-folder-name = Nedlastinger

## Appearance page

preferences-appearance-header =
    .heading = Utseende
browser-theme-group =
    .description = Gi { -brand-short-name } ditt eget preg. Temafarger brukes på verktøylinjer, menyer og meldinger.
    .label = Nettlesertema
browser-theme-manage-link =
    .label = Behandle { -brand-short-name }-tema
appearance-window-density-group =
    .description = Juster avstanden rundt vinduselementer som verktøylinje, faner og sidestolpe.
    .label = Vindustetthet
appearance-window-density-radio-group =
    .aria-label = Vindustetthet
appearance-window-density-automatic =
    .description = Standard, kompakt eller berøringsoptimalisert avstand brukes automatisk
    .label = Automatisk (standard)
appearance-window-density-automatic-no-touch =
    .description = Standard eller kompakt avstand brukes automatisk
    .label = Automatisk (standard)
appearance-window-density-standard =
    .description = Balansert avstand for de fleste skjermer
    .label = Standard
appearance-window-density-auto-touch-mode =
    .label = Bruk berøringsoptimalisert avstand i nettbrettmodus
appearance-window-density-compact =
    .description = Redusert avstand for mindre skjermer
    .label = Kompakt
appearance-window-density-touch =
    .description = Større vinduselementer og klikkmål, optimalisert for berøringsskjermer
    .label = Berøringsoptimalisert
related-settings-group =
    .label = Relaterte innstillinger
related-settings-accessibility-link =
    .label = Tilpass zoom- og skriftinnstillinger under Tilgjengelighet
related-settings-home-link =
    .label = Tilpass { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = Tilpass nettleseroppsettet

## AI controls page

preferences-ai-controls-description = Du har alltid et valg i { -brand-short-name }, også om du vil bruke funksjoner som er forbedret med AI. Flere kontroller kommer snart.
preferences-ai-controls-block-ai-label = Blokker AI-forbedringer
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Blokkering betyr at du ikke vil se nye eller eksisterende AI-forbedringer i { -brand-short-name }, eller varsler om dem. <a data-l10n-name="link">Få flere detaljer</a> om hva som er inkludert og hvordan du kan styre tradisjonelle maskinlæringsfunksjoner, som søkeforslag og anbefalinger.
preferences-ai-controls-blocked-message =
    .message = Nye og eksisterende AI-forbedringer er blokkert som standard. For å oppheve blokkeringen av en bestemt funksjon, bruk kontrollene nedenfor.
preferences-ai-controls-on-device-group =
    .description = Disse bruker små AI-modeller som lastes ned til enheten din hvis du bruker funksjonen. Denne tilnærmingen bidrar til å beskytte personvernet ditt.
    .label = AI på enheten
preferences-ai-controls-translations-control =
    .description = Surf sømløst på nettet på språket du foretrekker.
    .label = Oversettelser
preferences-ai-controls-translations-more-link = Flere oversettelsesinnstillinger
preferences-ai-controls-pdfjs-control =
    .description = Når du legger til bilder i PDF-filer, legges det til beskrivelser for å gjøre dem tilgjengelige.
    .label = Bildetekst (alt-tekst) i PDF-visningsprogrammet i { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Få forslag til å navngi og organisere dine faner.
    .label = Forslag til fanegrupper
preferences-ai-controls-key-points-control =
    .description = Se et raskt sammendrag før du åpner en lenke.
    .label = Hovedpunkter i forhåndsvisning av lenker
preferences-ai-controls-speech-recognition-control =
    .description = Transkriber tale lokalt.
    .label = Talegjenkjenning
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Ha en chatbot i sikte mens du surfer. Velg mellom flere leverandører og bytt når som helst.
    .label = AI-chatbotleverandører i sidestolpen
preferences-ai-controls-sidebar-chatbot-group =
    .description = Ha en chatbot synlig mens du surfer. Velg mellom Anthropic Claude, ChatGPT, Copilot, Google Gemini og Le Chat Mistral.
    .label = AI-chatbotleverandører i sidestolpen
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot i sidestolpen
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Tilgjengelig
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Påslått
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Blokkert
preferences-ai-controls-state-description-before = Hva alternativene betyr:
preferences-ai-controls-state-description-available = <strong>Tilgjengelig:</strong> Du vil se funksjonen og kan bruke den.
preferences-ai-controls-state-description-enabled = <strong>Påslått:</strong> Du har valgt å bruke funksjonen.
preferences-ai-controls-state-description-blocked = <strong>Blokkert:</strong> Du vil ikke se og kan ikke bruke funksjonen. For AI på enheten fjernes eventuelle modeller som allerede er lastet ned.
preferences-ai-controls-block-confirmation-heading = Blokkere AI-forbedringer?
preferences-ai-controls-block-confirmation-description = Du vil ikke se nye eller eksisterende AI-forbedringer i { -brand-short-name }, eller varsler om dem. Etterpå kan du oppheve blokkeringen av det du ønsker å fortsette å bruke.
preferences-ai-controls-block-confirmation-features-start = Hva som vil bli blokkert:
preferences-ai-controls-block-confirmation-translations = Oversettelser
preferences-ai-controls-block-confirmation-pdfjs = Bildetekst (alt-tekst) i PDF-visningsprogrammet i { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Forslag til fanegrupper
preferences-ai-controls-block-confirmation-key-points = Hovedpunkter i forhåndsvisning av lenker
preferences-ai-controls-block-confirmation-sidebar-chatbot = Chatbotleverandører i sidestolpen
preferences-ai-controls-block-confirmation-speech-recognition = Talegjenkjenning
preferences-ai-controls-block-confirmation-features-after = Blokkering påvirker også utvidelser som bruker AI levert av { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Avbryt
preferences-ai-controls-block-confirmation-confirm =
    .label = Blokker
preferences-ai-controls-header3 =
    .heading = AI-kontroller

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } er på vakt
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } anbefaler noen sikkerhetsforbedringer
security-privacy-status-ok-label = Utvidet sporingsbeskyttelse er på
security-privacy-status-problem-label = Vi fant innstillinger som påvirker beskyttelsen din
security-privacy-status-problem-helper-label = Vis problemer
security-privacy-status-pending-trackers-label = Ser på hvor mange sporere som { -brand-short-name } har blokkert den siste måneden
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } sporer blokkert den siste måneden
       *[other] { $trackerCount } sporere blokkert den siste måneden
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Du har <a data-l10n-name="strict-tracking-protection">streng beskyttelse</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Du har <a data-l10n-name="custom-tracking-protection">tilpasset beskyttelse</a>
security-privacy-status-up-to-date-label = Du har den nyeste og sikreste versjonen av { -brand-short-name }
security-privacy-status-update-needed-label = En ny versjon av { -brand-short-name } er tilgjengelig.
security-privacy-status-update-error-label = { -brand-short-name } har problemer med å oppdatere seg selv
security-privacy-status-update-checking-label = { -brand-short-name } ser etter oppdateringer
security-privacy-status-update-needed-description = Oppdater for de nyeste forbedringene i hastighet, stabilitet og sikkerhet.
security-privacy-status-update-button-label =
    .label = Oppdater { -brand-short-name }
security-privacy-image-warning =
    .alt = Et skjold med et utropstegn som uttrykker bekymring over sikkerhetsvarslene dine
security-privacy-image-ok =
    .alt = Et skjold med en hake som viser at du ikke har noen utestående sikkerhetsproblemer
security-privacy-issue-card =
    .heading = Sikkerhetsadvarsler
issue-card-reset-button =
    .label = Tilbakestill
issue-card-dismiss-button =
    .aria-label = Ignorer
    .tooltiptext = Ignorer

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Nettsteder bruker sporere for å følge deg på nettet og vise påtrengende annonser. { -brand-short-name } beskytter deg mens du surfer ved å blokkere sporere automatisk, slik at du har kontroll over de digitale sporene dine.
    .label = Utvidet sporingsbeskyttelse
preferences-etp-level-radio-group =
    .aria-label = Utvidet sporingsbeskyttelse
preferences-etp-level-standard =
    .description = Sterk og pålitelig beskyttelse som fungerer problemfritt med de fleste nettsteder.
    .label = Standard (standard)
preferences-etp-level-strict =
    .description = Sterkere beskyttelse som blokkerer flere sporere, men kan føre til at noen nettsteder ikke fungerer som de skal.
    .label = Streng
preferences-etp-level-custom =
    .description = Velg hvilke beskyttelser som skal slås av eller på.
    .label = Tilpasset
preferences-etp-status-advanced-button =
    .label = Avanserte innstillinger
preferences-etp-tracker-count-enabled =
    .label = Vis blokkerte sporere i adressefeltet
preferences-etp-status-protections-dashboard-link =
    .description = Se hvor mange snikende sporere { -brand-short-name } har blokkert for deg, inkludert sporere fra sosiale medier, nettleseravtrykksporere og kryptoutvinnere.
    .label = Se ditt personlige beskyttelsesoversikt
preferences-etp-header =
    .heading = Utvidet sporingsbeskyttelse
preferences-etp-advanced-settings-group =
    .description = Nettsteder bruker sporere for å følge deg på nettet og vise påtrengende annonser. { -brand-short-name } beskytter deg mens du surfer ved å blokkere sporere automatisk, slik at du har kontroll over de digitale sporene dine.
    .label = Utvidet sporingsbeskyttelse
preferences-etp-customize-button =
    .label = Tilpass sporingsbeskyttelse
preferences-etp-reload-tabs-hint =
    .message = Last inn fanene dine på nytt for å bruke disse endringene.
preferences-etp-reload-tabs-hint-button =
    .label = Last inn alle fanene på nytt
preferences-etp-rfp-warning-message =
    .message = Du bruker Resist Fingerprinting (RFP), som erstatter noen av { -brand-short-name } sine beskyttelsesinnstillinger for nettleseravtrykk. Dette kan føre til at enkelte nettsteder ikke vil fungere.
preferences-etp-level-warning-message =
    .heading = Obs! Noen nettsteder fungerer kanskje ikke som forventet.
    .message = Noen nettsteder bygger sporere inn i funksjonene eller innholdet sitt. Når { -brand-short-name } blokkerer dem, kan nettstedet se ødelagt ut. Prøv å bruke «Fiks nettstedsproblem» eller slå av sporingsbeskyttelse for det nettstedet.
preferences-etp-manage-exceptions-button =
    .description = Behandle nettsteder der utvidet sporingsbeskyttelse er deaktivert.
    .label = Behandle unntak
preferences-etp-customize-header =
    .heading = Tilpass sporingsbeskyttelse
preferences-etp-reset =
    .description = Gjenopprett innstillinger til et forhåndsdefinert beskyttelsesnivå.
    .label = Tilbakestill tilpasninger
preferences-etp-reset-standard-button =
    .label = Tilbakestill til standard
preferences-etp-reset-strict-button =
    .label = Tilbakestill til streng
preferences-etp-custom-control-group =
    .description = Velg hvilke beskyttelser som skal slås på eller av.
    .label = Sporingsbeskyttelse
preferences-etp-custom-cookies-enabled =
    .label = Infokapsler
preferences-etp-custom-cookie-behavior =
    .aria-label = Infokapsler
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Tillat alle infokapsler
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Blokker sporingsinfokapsler på tvers av nettsteder
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Blokker infokapsler på tvers av nettsteder
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Isoler infokapsler på tvers av nettsteder
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Blokker infokapsler fra ubesøkte nettsteder
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Blokker alle infokapsler på tvers av nettsteder (kan føre til at nettsteder ikke fungerer)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Blokker alle infokapsler (vil føre til at enkelte nettsteder ikke virker)
preferences-etp-custom-tracking-protection-enabled =
    .label = Sporings-innhold
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Sporings-innhold
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Kryptoutvinnere
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Kjente nettleseravtrykksporere
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Mistenkt nettleseravtrykksporere
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Mistenkt nettleseravtrykksporere

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Dette kan gjøre det mulig for noen sporere å følge deg uten infokapsler.
    .label = Kjente nettleseravtrykksporere blokkeres ikke
security-privacy-issue-warning-third-party-cookies =
    .description = Tredjeparts-infokapsler brukes til å spore deg på tvers av nettsteder.
    .label = Tredjeparts-infokapsler er aktivert
security-privacy-issue-warning-password-manager =
    .description = Passordbehandlere hjelper deg med å lagre sterke passord for dine kontoer.
    .label = Passordbehandling er deaktivert
security-privacy-issue-warning-popup-blocker =
    .description = Sprettoppvinduer er forstyrrende og kan være skadelige.
    .label = Sprettoppvindu-blokkering er deaktivert
security-privacy-issue-warning-extension-install =
    .description = Nettsteder kan installere utvidelser i { -brand-short-name } uten å spørre.
    .label = Nettsteder kan installere utvidelser
security-privacy-issue-warning-safe-browsing =
    .description = Risikoen for svindel og skadevare fra nettsteder øker.
    .label = Farlig og villedende innhold blokkeres ikke
security-privacy-issue-warning-doh2 =
    .description = DNS-over-HTTPS bidrar til å skjule hvilke nettsteder du er i ferd med å besøke, fra nettverksleverandøren din.
    .label = DNS-over-HTTPS er deaktivert
security-privacy-issue-warning-ech2 =
    .description = Kryptert klient Hello bidrar til å skjule hvilke nettsteder du er i ferd med å besøke, fra nettverksleverandøren din.
    .label = Kryptert klient Hello er slått av
security-privacy-issue-warning-doh =
    .description = DNS-over-HTTPS skjuler hvilke nettsteder du besøker for nettverksleverandøren din.
    .label = DNS-over-HTTPS er deaktivert
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello skjuler hvilke nettsteder du besøker for nettverksleverandøren din.
    .label = Encrypted Client Hello er deaktivert
security-privacy-issue-warning-proxy-autodetection =
    .description = Automatisk proxykonfigurasjon kan gjøre det mulig for upålitelige nettverk å overvåke aktiviteten din.
    .label = Automatisk proxykonfigurasjon er aktivert

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Inviter noen til å velge nettleseren som setter personvern først.
    .label = Del { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Del { -brand-product-name }


