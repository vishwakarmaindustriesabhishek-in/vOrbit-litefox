# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = Unntak
permissions-close-key =
    .key = w
permissions-address = Adressen til nettstedet
    .accesskey = d
permissions-block =
    .label = Blokker
    .accesskey = B
permissions-disable-etp =
    .label = Legg til unntak
    .accesskey = e
permissions-session =
    .label = Tillat for programøkten
    .accesskey = T
permissions-allow =
    .label = Tillat
    .accesskey = T
permissions-add =
    .label = Legg til
    .accesskey = L
permissions-button-off =
    .label = Slå av
    .accesskey = S
permissions-button-off-temporarily =
    .label = Slå av midlertidig
    .accesskey = a
permissions-site-name =
    .label = Nettsted
permissions-status =
    .label = Status
permissions-remove =
    .label = Fjern nettsted
    .accesskey = F
permissions-remove-all =
    .label = Fjern alle nettsteder
    .accesskey = e
permissions-save-changes-2 =
    .buttonlabelaccept = Lagre endringer
    .buttonaccesskeyaccept = L
permission-dialog =
    .buttonlabelaccept = Lagre endringer
    .buttonaccesskeyaccept = L
permissions-autoplay-menu = Standard for alle nettsteder:
permissions-searchbox =
    .placeholder = Søk på nettside
permissions-capabilities-autoplay-allow =
    .label = Tillat lyd og video
permissions-capabilities-autoplay-block =
    .label = Blokker lyd
permissions-capabilities-autoplay-blockall =
    .label = Blokker lyd og video
permissions-capabilities-allow =
    .label = Tillat
permissions-capabilities-block =
    .label = Blokker
permissions-capabilities-prompt =
    .label = Spør alltid
permissions-capabilities-listitem-allow =
    .value = Tillat
permissions-capabilities-listitem-block =
    .value = Blokker
permissions-capabilities-listitem-allow-session =
    .value = Tillat for programøkten
permissions-capabilities-listitem-off =
    .value = Av
permissions-capabilities-listitem-off-temporarily =
    .value = Midlertidig av

## Invalid Hostname Dialog

permissions-invalid-uri-title = Ugyldig servernavn skrevet inn
permissions-invalid-uri-label = Skriv inn et gyldig servernavn

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Unntak for utvidet sporingsbeskyttelse
permissions-exceptions-manage-etp-desc = Du kan oppgi hvilke nettsteder som har utvidet sporingsbeskyttelse slått av. Skriv inn den eksakte adressen til nettstedet du vil administrere, og klikk deretter på Legg til unntak.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Unntak - Infokapsler og nettstedsdata
permissions-exceptions-cookie-desc = Du kan spesifisere hvilke nettsteder som alltid eller aldri får bruke infokapsler og nettsteddata.  Skriv inn den eksakte adressen til nettstedet du vil administrere, og klikk deretter Blokker, Tillat for økt, eller Tillat.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Unntak – Tøm historikk ved avslutning
permissions-exceptions-shutdown-clearing-desc = Du kan angi hvilke nettsteder som skal beholde dataene sine når { -brand-short-name } tømmer historikken ved avslutning. Skriv inn den nøyaktige adressen til nettstedet du vil behandle, og klikk deretter på Tillat.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Unntak - kun-HTTPS-modus
permissions-exceptions-https-only-desc2 = Du kan slå av kun-HTTPS-modus for bestemte nettsteder. { -brand-short-name } prøver ikke å oppgradere tilkoblingen til sikker HTTPS for disse nettstedene.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Tillatte nettsteder – sprettoppvinduer og tredjepartvideresendinger
permissions-exceptions-popup-desc2 = Du kan angi hvilke nettsteder som har lov til å åpne sprettoppvinduer og bli videresendt av tredjepartsrammer.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Unntak - lagrede passord
permissions-exceptions-saved-passwords-desc = { -brand-short-name } lagrer ikke passord for nettsteder som er oppført her.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Tillatte nettsteder - Installering av utvidelser
permissions-exceptions-addons-desc = Du kan oppgi hvilke nettsted som har tillatelse til å installere programtillegg. Skriv inn den eksakte adressen til nettstedet du vil tillate, og trykk «Tillat».

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Automatisk avspilling
permissions-site-autoplay-desc = Du kan håndtere de nettsteder som ikke følger dine standardinnstillinger for automatisk avspilling her.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Varslingstillatelser
permissions-site-notification-desc = Følgende nettsider har bedt om å få sende deg varsler. Du kan spesifisere hvilke nettsider som har tillatelse til å sende deg varsler. Du kan også blokkere nye forespørsler som ber om tillatelse til å sende varsel.
permissions-site-notification-disable-label =
    .label = Blokkere nye forespørsler som ber om tillatelse til å sende varsel
permissions-site-notification-disable-desc = Dette forhindrer nettsteder som ikke er oppført ovenfor, fra å be om tillatelse til å sende varsler. Blokkering av varsler kan ødelegge noen nettstedsfunksjoner.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Tillat nettstedsvarsler når { -brand-short-name } er lukket
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Varslingsinnstillingene for operativsystemet gjelder også.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Plasseringstillatelser
permissions-site-location-desc = Følgende nettsteder har bedt om tilgang til plasseringen din. Du kan spesifisere hvilke nettsteder som får tilgang til plasseringen din. Du kan også blokkere nye forespørsler som ber om tilgang til plasseringen din.
permissions-site-location-disable-label =
    .label = Blokker nye forespørsler som ber om tilgang til plasseringen din
permissions-site-location-disable-desc = Dette forhindrer nettsteder som ikke er oppført ovenfor, og ber om tillatelse til å få tilgang til posisjonen din. Hvis du blokkerer tilgang til posisjonen din, kan det hende at noen nettstedsfunksjoner ikke vil fungere.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Tillatelser for virtuell virkelighet
permissions-site-xr-desc = Følgende nettsteder har bedt om tilgang til din virtuell virkelighetsenhet. Du kan spesifisere hvilke nettsteder som får tilgang til din virtuell virkelighetsenhet. Du kan også blokkere nye forespørsler som ber om tilgang til din virtuell virkelighetsenhet.
permissions-site-xr-disable-label =
    .label = Blokker nye forespørsler som ber om tilgang til din virtuell virkelighetsenhet.
permissions-site-xr-disable-desc = Dette forhindrer nettsteder som ikke er oppført ovenfor, og ber om tillatelse til å få tilgang til din virtuell virkelighetsenhet. Hvis du blokkerer tilgang til din virtuell virkelighetsenhet, kan det hende at noen nettstedsfunksjoner ikke vil fungere.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Innstillinger – Blokkerte nettsteder for applenker
permissions-site-app-links-desc = Disse nettstedene er blokkert fra å be om å åpne applenker, for eksempel e-postlenker (mailto:). Fjern et nettsted for å tillate at det spør igjen.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Kameratillatelser
permissions-site-camera-desc = Følgende nettsteder har bedt om tilgang til kameraet ditt. Du kan spesifisere hvilke nettsteder som får tilgang til kameraet ditt. Du kan også blokkere nye forespørsler som ber om tilgang til kameraet ditt.
permissions-site-camera-disable-label =
    .label = Blokker nye forespørsler som ber om tilgang til kameraet ditt
permissions-site-camera-disable-desc = Dette forhindrer nettsteder som ikke er oppført ovenfor, og ber om tillatelse til å få tilgang til kameraet ditt. Hvis du blokkerer tilgang til kameraet ditt, kan det hende at noen nettstedsfunksjoner ikke vil fungere.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Innstillinger – Enhetsapper og -tjenester
permissions-site-localhost-desc = Disse nettstedene har bedt om tilgang til apper og tjenester på denne enheten. Du kan velge å tillate eller blokkere nettsteder fra å gjøre dette.
permissions-site-localhost-disable-label =
    .label = Blokker nye forespørsler om tilgang til apper og tjenester på denne enheten
permissions-site-localhost-disable-desc = Dette vil hindre nettsteder som ikke er oppført ovenfor i å be om tilgang til apper og tjenester på denne enheten. Dette kan føre til at enkelte nettstedsfunksjoner ikke fungerer.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Innstillinger – Lokale nettverksenheter
permissions-site-local-network-desc = Disse nettstedene har bedt om tilgang til apper og tjenester på enheter som er koblet til Wi-Fi-nettverket eller det lokale nettverket ditt. Du kan velge å tillate eller blokkere nettsteder fra å gjøre dette.
permissions-site-local-network-disable-label =
    .label = Blokker nye forespørsler om tilgang til apper og tjenester på enheter som er koblet til Wi-Fi-nettverket eller det lokale nettverket ditt.
permissions-site-local-network-disable-desc = Dette vil hindre nettsteder som ikke er oppført ovenfor i å be om tilgang til apper og tjenester på enheter som er koblet til Wi-Fi eller lokale nettverksenheter. Dette kan føre til at enkelte nettstedsfunksjoner ikke fungerer.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Innstillinger - Mikrofontillatelser
permissions-site-microphone-desc = Følgende nettsteder har bedt om tilgang til mikrofonen din. Du kan spesifisere hvilke nettsteder som får tilgang til mikrofonen din. Du kan også blokkere nye forespørsler som ber om tilgang til mikrofonen din.
permissions-site-microphone-disable-label =
    .label = Blokker nye forespørsler som ber om tilgang til mikrofonen din
permissions-site-microphone-disable-desc = Dette forhindrer nettsteder som ikke er oppført ovenfor, og ber om tillatelse til å få tilgang til mikrofonen din. Hvis du blokkerer tilgang til mikrofonen din, kan det hende at noen nettstedsfunksjoner ikke vil fungere.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Innstillinger - Høyttalertillatelser
permissions-site-speaker-desc = Følgende nettsteder har bedt om å velge en lydutgangsenhet. Du kan spesifisere hvilke nettsteder som har lov til å velge en lydutgangsenhet.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Nettstedunntak for DNS-over-HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } vil ikke bruke sikker DNS på disse nettstedene og deres underdomener.
permissions-doh-entry-field = Skriv inn nettstedets domenenavn
    .accesskey = k
permissions-doh-add-exception =
    .label = Legg til
    .accesskey = L
permissions-doh-col =
    .label = Domene
permissions-doh-remove =
    .label = Fjern
    .accesskey = F
permissions-doh-remove-all =
    .label = Fjern alle
    .accesskey = e


