# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } Pribadong Pagba-browse
urlbar-identity-button =
    .aria-label = Tingnan ang impormasyon ng site

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Buksan ang install message panel
urlbar-web-notification-anchor =
    .tooltiptext = Baguhin kung pwede ka na makakuha ng abiso galing sa site
urlbar-midi-notification-anchor =
    .tooltiptext = Buksan ang MIDI panel
urlbar-eme-notification-anchor =
    .tooltiptext = Pamahalaan ang paggamit ng DRM software
urlbar-web-authn-anchor =
    .tooltiptext = Buksan ang Web Authentication panel
urlbar-canvas-notification-anchor =
    .tooltiptext = Pamahalaan ang pahintulot sa pagkuha ng cavas
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Pangasiwaan ang pag-bahagi ng iyong mikropono sa site
urlbar-default-notification-anchor =
    .tooltiptext = Buksan ang panel ng mensahe
urlbar-geolocation-notification-anchor =
    .tooltiptext = Buksan ang panel ng kahilingan ng lokasyon
urlbar-xr-notification-anchor =
    .tooltiptext = Buksan ang panel ng mga pahintulot para sa virtual reality
urlbar-storage-access-anchor =
    .tooltiptext = Buksan ang panel ng mga pahintulot para sa browsing activity
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Pangasiwaan ang pag-bahagi ng iyong windows o screen sa site
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Buksan ang offline storage message panel
urlbar-password-notification-anchor =
    .tooltiptext = Buksan ang save password message panel
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = I-manage ang pag-share ng iyong kamera at/o mikropono sa site
urlbar-autoplay-notification-anchor =
    .tooltiptext = Buksan ang panel ng autoplay
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Ilagay ang datos sa Persistent Storage
urlbar-addons-notification-anchor =
    .tooltiptext = Buksan ang add-on intallation message panel
urlbar-search-tips-confirm = OK, nakuha ko
urlbar-search-tips-confirm-short = Nakuha ko

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Shortcut: Hanapin ang { $engineName } direkta mula sa iyong address bar.
urlbar-search-tips-redirect-2 = Simulan ang iyong paghahanap sa address bar para makakita ng mga mungkahi mula sa { $engineName } at sa iyong browsing history.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Piliin ang shortcut na ito upang makita kung ano ang iyong kinakailangan nang mas mabilis.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Mga Bookmark
urlbar-search-mode-tabs = Mga Tab
urlbar-search-mode-history = Kasaysayan

##

urlbar-geolocation-blocked =
    .tooltiptext = Na-block mo ang impormasyon ng lokasyon para sa website na ito.
urlbar-xr-blocked =
    .tooltiptext = Hinarangan mo ang virtual reality device na mag-access para sa website na ito.
urlbar-web-notifications-blocked =
    .tooltiptext = Na-block mo ang mga notification para sa website na ito.
urlbar-camera-blocked =
    .tooltiptext = Hinarangan mo ang iyong camera para sa website na ito.
urlbar-microphone-blocked =
    .tooltiptext = Na-block mo ang iyong mikropono para sa website na ito.
urlbar-screen-blocked =
    .tooltiptext = Na-block mo ang website na ito mula sa pagbabahagi ng iyong screen.
urlbar-persistent-storage-blocked =
    .tooltiptext = Na-block mo ang paulit-ulit na imbakan para sa website na ito.
urlbar-autoplay-media-blocked =
    .tooltiptext = Hinarangan mo ang pag autoplay ng media na may tunog sa website na ito.
urlbar-canvas-blocked =
    .tooltiptext = Na-block mo ang data extraction ng canvas para sa website na ito.
urlbar-midi-blocked =
    .tooltiptext = Na-block mo ang access sa MIDI para sa website na ito.
urlbar-install-blocked =
    .tooltiptext = Hinarang mo ang pagkabit ng mga add-on sa website na ito.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Baguhin itong bookmark ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = i-Bookmark ang pahinang ito ({ $shortcut })

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = i-Paste at Puntahan
    .accesskey = G

## Searchbar context menu

clear-search-history =
    .label = Burahin ang Search History
    .accesskey = H

## Auto-hide Context Menu

full-screen-autohide =
    .label = Itago ang mga Toolbar
    .accesskey = H
full-screen-exit =
    .label = Lumabas sa Full Screen Mode
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Ngayon naman, maghanap gamit ang:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Baguhin ang mga search setting
search-one-offs-context-open-new-tab =
    .label = Hanapin sa Bagong Tab
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = I-set sa Default Search Engine
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = Itakda bilang Default Search Engine sa mga Private Window
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = I-dagdag ang search engine na “{ $engineName }”
    .label = I-dagdag ang “{ $engineName }”
    .tooltiptext = I-dagdag ang search engine na “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Magdagdag ng search engine
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Magdagdag ng search engine

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Mga Bookmark ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Mga Tab ({ $restrict })
search-one-offs-history =
    .tooltiptext = Kasaysayan ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Mga Aksyon ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Tingnan ang mga add-on
# Opens the bookmarks library window
quickactions-bookmarks2 = Pamahalaan ang mga bookmark
quickactions-cmd-bookmarks = mga bookmark
# Opens about:downloads page
quickactions-downloads2 = Tingnan ang mga download
quickactions-cmd-downloads = mga download
# Opens about:addons page in the extensions section
quickactions-extensions = Pamahalaan ang mga extension
# Opens the devtools web inspector
quickactions-inspector2 = Buksan ang Developer Tools
# Opens about:logins
quickactions-logins2 = Pamahalaan ang mga password
quickactions-cmd-logins = mga login, password
# Opens the print dialog
quickactions-print2 = I-print ang pahina
quickactions-cmd-print = i-print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = I-save ang pahina bilang PDF
# Opens a new private browsing window
quickactions-private2 = Magbukas ng pribadong window
quickactions-cmd-private = pribadong pagba-browse
# Opens a SUMO article explaining how to refresh
quickactions-refresh = I-refresh ang { -brand-short-name }
quickactions-cmd-refresh = i-refresh
# Restarts the browser
quickactions-restart = I-restart ang { -brand-short-name }
quickactions-cmd-restart = i-restart
# Opens the screenshot tool
quickactions-screenshot3 = Kumuha ng screenshot
# Opens about:preferences
quickactions-settings2 = Pamahalaan ang mga setting

## Bookmark Panel

bookmarks-add-bookmark = Magdagdag ng bookmark
bookmarks-edit-bookmark = I-edit ang bookmark
bookmark-panel-cancel =
    .label = Kanselahin
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Tanggalin ang Bookmark
           *[other] Magtanggal ng { $count } mga Bookmark
        }
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = Ipakita ang editor kapag nagse-save
    .accesskey = S
bookmark-panel-save-button =
    .label = i-Save
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Impormasyon ng Site para sa { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Connection Security for { $host }
identity-connection-not-secure = Hindi ligtas ang koneksyon
identity-connection-secure = Ligtas na koneksyon
identity-connection-failure = Kabiguan sa koneksyon
identity-connection-internal = Ito ay secure na { -brand-short-name } na pahina.
identity-connection-file = Ang pahinang ito ay naka-imbak sa iyong computer.
identity-extension-page = Ang pahinang ito ay nai-load mula sa isang extension.
identity-active-blocked = { -brand-short-name } Na-block ang mga bahagi ng pahinang ito na hindi ligtas.
identity-custom-root = Ang connection ay na-verify ng isang certificate issuer na hindi kinikilala ng Mozilla.
identity-passive-loaded = Ang mga bahagi ng pahinang ito ay hindi ligtas (tulad ng mga larawan).
identity-active-loaded = Hindi mo pinagana ang proteksyon sa pahinang ito.
identity-weak-encryption = Ang pahinang ito ay gumagamit ng mahina na pag-encrypt.
identity-https-only-connection-upgraded = (inupgrade na sa HTTPS)
identity-https-only-dropdown-on =
    .label = Nakabukas
identity-https-only-dropdown-off =
    .label = Nakasara
identity-https-only-dropdown-off-temporarily =
    .label = Pansamantalang nakasara
identity-https-only-info-no-upgrade = Hindi kayang mag-upgrade ng koneksyon mula sa HTTP.
identity-permissions-storage-access-header = Mga cross-site cookie
identity-permissions-storage-access-hint = Ang mga partidong ito ay maaaring gumamit ng mga cross-site cookie at site data habang ikaw ay nasa site na ito.
identity-permissions-storage-access-learn-more = Alamin
identity-permissions-reload-hint = Maaaring kailangan mong i-reload ang pahina para mag-aplay ang mga pagbabago.
identity-clear-site-data =
    .label = Burahin ang mga Cookie at Site Data…
identity-connection-not-secure-security-view = Ikaw ay hindi ligtas na nakakonekta sa site na ito.
identity-connection-verified = Ikaw ay ligtas na nakakonekta sa site na ito.
identity-ev-owner-label = Inisyu ang certificate kay:
identity-description-custom-root2 = Hindi kilala ng Mozilla ang certificate issuer na ito. Maaari itong nadagdag sa iyong operating system o ng isang administrator.
identity-remove-cert-exception =
    .label = Tanggalin ang Exception
    .accesskey = R
identity-description-insecure = Ang iyong koneksyon sa site na ito ay hindi pribado. Ang impormasyon na iyong isinumite ay maaaring matingnan ng iba (tulad ng mga password, mensahe, credit card, atbp.).
identity-description-weak-cipher-intro = Ang iyong koneksyon sa website na ito ay gumagamit ng mahina na pag-encrypt at hindi pribado.
identity-description-weak-cipher-risk = Maaaring tingnan ng iba pang mga tao ang iyong impormasyon o baguhin ang pag-uugali ng website.
identity-description-active-blocked2 = { -brand-short-name } Na-block ang mga bahagi ng pahinang ito na hindi ligtas.
identity-description-passive-loaded = Ang iyong koneksyon ay hindi pribado at ang impormasyon na iyong ibinabahagi sa site ay maaaring makita ng iba.
identity-description-passive-loaded-insecure2 = Ang website na ito ay naglalaman ng nilalaman na hindi ligtas (tulad ng mga larawan).
identity-description-passive-loaded-mixed2 = Kahit na { -brand-short-name } Na-block ng ilang nilalaman, may nilalaman pa rin sa pahina na hindi ligtas (tulad ng mga larawan).
identity-description-active-loaded = Ang website na ito ay naglalaman ng nilalaman na hindi ligtas (tulad ng mga script) at ang iyong koneksyon dito ay hindi pribado.
identity-description-active-loaded-insecure = Ang impormasyon na ibinabahagi mo sa site na ito ay maaaring makita ng iba (tulad ng mga password, mensahe, credit card, atbp.).
identity-more-info-link-text =
    .label = Karagdagang Impormasyon

## Window controls

browser-window-minimize-button =
    .tooltiptext = i-Minimize
browser-window-maximize-button =
    .tooltiptext = Palakihin
browser-window-restore-down-button =
    .tooltiptext = Restore Down
browser-window-close-button =
    .tooltiptext = Isara

## Bookmarks toolbar items

browser-import-button2 =
    .label = Mag-import ng mga bookmark…
    .tooltiptext = Mag-import ng mga bookmark mula sa ibang browser papuntang { -brand-short-name }.
bookmarks-toolbar-empty-message = Para sa mabilis na pag-access, ilagay ang iyong mga bookmark dito sa bookmarks toolbar. <a data-l10n-name="manage-bookmarks">I-manage ang mga bookmark…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Camera:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = Camera
popup-select-microphone-device =
    .value = Mikropono:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikropono
popup-select-speaker-icon =
    .tooltiptext = Mga Speaker
popup-select-window-or-screen =
    .label = Window o screen:
    .accesskey = W
popup-all-windows-shared = Lahat ng nakikitang window sa iyong screen ay ibabahagi.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Ibinabahagi mo ang { -brand-short-name }. Makikita ng ibang mga tao kapag lumipat ka sa bagong tab.
sharing-warning-screen = Ibinabahagi mo ang iyong buong screen. Makikita ng ibang mga tao kapag lumipat ka sa bagong tab.
sharing-warning-proceed-to-tab =
    .label = Magpatuloy sa Tab
sharing-warning-disable-for-session =
    .label = I-disable ang sharing protection para sa session na ito

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Isarado
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Hanapin o ilagay ang address
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Maghanap gamit ang { $name }
    .placeholder = Hanapin sa Web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Hanapin { $name }
    .placeholder = Ipasok ang mga search term
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Hanapin sa mga bookmark
    .placeholder = Ipasok ang mga search term
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Hanapin sa kasaysayan
    .placeholder = Ipasok ang mga search term
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Hanapin sa mga tab
    .placeholder = Ipasok ang mga search term
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Maghanap gamit ang { $name } o ipasok ang address
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Naka-remote control ang browser (dahilan: { $component })
urlbar-permissions-granted =
    .tooltiptext = Ipinagkaloob mo sa website na ito ang mga karagdagang pahintulot.
urlbar-switch-to-tab =
    .value = Lumipat sa tab:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Extension:
urlbar-go-button2 =
    .title = Pumunta sa lokasyon na nasa Location Bar
urlbar-page-action-button =
    .tooltiptext = Page actions

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Maghanap gamit ang { $engine } sa Private Window
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Maghanap sa Private Window
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Maghanap gamit ang { $engine }
urlbar-result-action-sponsored = Sponsored
urlbar-result-action-switch-tab = Lumipat sa Tab
urlbar-result-action-visit = Puntahan
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Lumipat sa Tab · <span>{ $container }</span>
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Bisitahin mula sa clipboard
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Pindutin ang Tab upang maghanap gamit ang { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Pindutin ang Tab upang maghanap sa { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Maghanap gamit ang { $engine } direkta mula sa address bar
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Maghanap sa { $engine } direkta mula sa address bar
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopyahin

## Strings used for buttons in the urlbar

urlbar-searchmode-bookmarks4 = Mga Bookmark
urlbar-searchmode-tabs4 = Mga Tab
urlbar-searchmode-history4 = Kasaysayan
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = I-dagdag ang “{ $engineName }”
    .title = I-dagdag ang search engine na “{ $engineName }”

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Hanapin sa mga Bookmark
urlbar-result-action-search-history = Hanapin sa Kasaysayan
urlbar-result-action-search-tabs = Hanapin sa mga Tab

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Mga Hinahanap Kamakailan

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Ipasok ang Reader View
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Isara ang Reader View

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Buksan ang Picture-in-Picture ({ $shortcut })
picture-in-picture-panel-header = Picture-in-Picture
picture-in-picture-panel-headline = Hindi inirerekomenda ng website na ito ang Picture-in-Picture
picture-in-picture-enable-toggle =
    .label = Paganahin pa rin

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = Ang <span data-l10n-name="domain">{ $domain }</span> ay naka-full screen na ngayon
fullscreen-warning-no-domain = Ang dokument na ito ay naka full screen
fullscreen-exit-button = Umalis sa Full Screen (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Umalis sa Full Screen (Esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> ay may kontrol sa iyong pointer. Pindutin ang ESC para mabawi ang kontrol.
pointerlock-warning-no-domain = Ang dokumentong ito ay may kontrol sa iyong pointer. Pindutin ang Esc para manumbalik ang kontrol.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = I-manage ang mga bookmark
bookmarks-recent-bookmarks-panel-subheader = Mga bookmark kamakailan
bookmarks-toolbar-chevron =
    .tooltiptext = Magpakita ng karagdagang mga bookmark
bookmarks-sidebar-content =
    .aria-label = Mga bookmark
bookmarks-menu-button =
    .label = Menu ng mga Bookmark
bookmarks-other-bookmarks-menu =
    .label = Iba pang mga Bookmark
bookmarks-mobile-bookmarks-menu =
    .label = Mga Mobile Bookmark

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Itago ang Bookmark Sidebar
           *[other] Ipakita ang Bookmark Sidebar
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Itago ang Bookmark Toolbar
           *[other] Ipakita ang Bookmark Sidebar
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Itago ang bookmarks toolbar
           *[other] Ipakita ang bookmarks toolbar
        }

##

bookmarks-search =
    .label = Hanapin sa mga Bookmark
bookmarks-tools =
    .label = Mga Gamit sa Pag-bookmark
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Mga bookmark
    .toolbarname = Bookmark Toolbar
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Bookmark Toolbar
bookmarks-toolbar-placeholder =
    .title = Mga nakalagay sa Bookmark Toolbar
bookmarks-toolbar-placeholder-button =
    .label = Mga nakalagay sa Bookmark Toolbar
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = I-bookmark ang kasalukuyang tab…

## Library Panel items

library-bookmarks-menu =
    .label = Mga bookmark

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Ayusin ang text encoding
    .tooltiptext = Hulahan ang tamang text encoding mula sa nilalaman ng pahina

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Mga Setting
    .tooltiptext =
        { PLATFORM() ->
            [macos] Buksan ang mga setting ({ $shortcut })
           *[other] Buksan ang mga setting
        }
toolbar-overflow-customize-button =
    .label = I-customize ang Toolbar...
    .accesskey = C
toolbar-button-email-link =
    .label = Email Link
    .tooltiptext = Mag-email ng link sa page na ito
toolbar-button-logins =
    .label = Mga password
    .tooltiptext = Tingnan at pamahalaan ang iyong mga naka-save na password
toolbar-button-save-page =
    .label = i-Save ang Pahina
    .tooltiptext = i-Save ang pahina na ito ({ $shortcut })
toolbar-button-open-file =
    .label = Magbukas ng file
    .tooltiptext = Magbukas ng file ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Mga Naka-sync na Tab
    .tooltiptext = Ipakita ang mga tabs mula sa ibang devices
toolbar-button-new-private-window =
    .label = Bagong Private Window
    .tooltiptext = Magbukas ng panibagong Private Browsing window ({ $shortcut })
toolbar-button-history =
    .label = Kasaysayan
    .tooltiptext = Ipakita ang iyong kasaysayan ({ $shortcut })
toolbar-button-find =
    .label = Hanapin
    .tooltiptext = Hanapin sa pahinang ito ({ $shortcut })
toolbar-button-developer =
    .label = Developer
    .tooltiptext = Buksan ang Web developer na mga tools ({ $shortcut })
toolbar-button-forget =
    .label = Kalimutan
    .tooltiptext = Kalimutan ang ibang kasaysayan ng pag-browse
toolbar-zoom-controls =
    .label = Mga control pang-zoom
    .title = Mga control pang-zoom
toolbar-button-zoom-out =
    .label = Paliitin
    .tooltiptext = Paliitin ({ $shortcut })
toolbar-button-zoom-reset-tooltip = I-reset ang etiketa ng pag-zoom ({ $shortcut })
toolbar-button-zoom-in =
    .label = Palakihin
    .tooltiptext = Palakihin ({ $shortcut })
toolbar-edit-controls =
    .label = Mga Edit Control
    .title = Mga edit control
toolbar-button-cut =
    .label = i-Cut
    .tooltiptext = i-Cut ({ $shortcut })
toolbar-button-copy =
    .label = Kopyahin
    .tooltiptext = Kopyahin ({ $shortcut })
toolbar-button-paste =
    .label = i-Paste
    .tooltiptext = i-Paste ({ $shortcut })

## EME notification panel

eme-notifications-drm-content-playing = Ang ilang mga audio o video sa site na ito ay gumagamit ng software na DRM, na maaaring limitahan ang { -brand-short-name } sa kung ano ang maaaring mong gawin dito.
eme-notifications-drm-content-playing-manage = I-manage ang mga setting
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = Alisin
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-button =
    .label = Paganahin ang DRM
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = Ang { -brand-short-name } ay nag-i-install ng mga kinakailangang component para mapaandar ang audio o video sa pahinang ito. Subukan uli mamaya.
decoder-doctor-no-codecs-linux-message = Upang may-play ng video, maaaring kailanganin mong i-install ang kinakailangang mga video codec.
decoder-doctor-no-hw-acceleration-message = Upang mapabuti ang kalidad ng video, maaaring kailanganin mong i-install ang Media Feature Pack ng Microsoft.
decoder-doctor-no-pulse-audio-message = Upang mag-play ng audio, maaaring kailangan mong i-install ang kinakailangang software na PulseAudio.
decoder-doctor-unsupported-libavcodec-message = maaaring mahina ang libavcodec o hindi suportado, at dapat ma-update upang i-play ang video.
decoder-doctor-decode-error-message = May naganap na error habang nagde-decode sa pinagkukuhanan ng media.
decoder-doctor-decode-warning-message = Isang recoverable na error ang naganap habang nagde-decode sa pinagkukuhanan ng media.
decoder-doctor-learn-how-link = Alamin kung paano
decoder-doctor-report-issue-button =
    .label = Mag-report ng Issue sa Site
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Nag-crash ang plugin na { $pluginName }.
plugin-crashed-notification-reload-button =
    .label = i-Reload ang pahina
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = Magpasa ng crash report
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Mapanlinlang na Site!
safebrowsing-reported-attack-site-message = Iniulat na Attack Site!
safebrowsing-reported-unwanted-site-message = Iniulat na Unwanted Software Site!
safebrowsing-reported-harmful-site-message = Iniulat ang Mapanganib na Site!
safebrowsing-get-me-out-of-here-button =
    .label = Itakas mo ako rito!
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = Hindi ito isang mapanlinlang na site…
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = Hindi ito isang attack site...
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Dapat kang mag-log in sa network na ito bago mo ma-access ang Internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Buksan ang Pahina ng Network Login

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Ang ibig mo bang sabihin ay pumunta sa { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Oo, dalhin mo ako sa { $hostName }
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = Username
panel-save-update-password-2 =
    .label = Password

##

# "More" item in macOS share menu
menu-share-more =
    .label = Higit pa...
ui-tour-info-panel-close =
    .tooltiptext = Isarado

##

picture-in-picture-hide-toggle =
    .label = Itago ang Toggle para sa Picture-in-Picture
    .accesskey = H

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigation
navbar-downloads =
    .label = Mga Download
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = I-print
    .tooltiptext = I-print ang pahinang ito ... ({ $shortcut })
navbar-home =
    .label = Home
    .tooltiptext = { -brand-short-name } Home Page
navbar-library =
    .label = Library
    .tooltiptext = Tingnan ang kasaysayan, naka-save na mga bookmark, at iba pa
navbar-search =
    .title = Hanapin
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Mga tab ng browser
tabs-toolbar-new-tab =
    .label = Bagong Tab
tabs-toolbar-list-all-tabs =
    .label = Ilista ang lahat ng mga tabs
    .tooltiptext = Ilista ang lahat ng mga tabs

## Infobar shown at startup to suggest session-restore

restore-session-startup-suggestion-button = Ipakita sa akin kung paano

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = Ang { -brand-short-name } ay kusang nagpapadala ng ilang data sa { -vendor-short-name } upang mapahusay namin ang iyong karanasan.
data-reporting-notification-button =
    .label = Piliin ang Ibabahagi
    .accesskey = D
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Pribadong pag-browse

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Mga extension
    .tooltiptext = Mga extension

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Mga extension
    .tooltiptext =
        Mga extension
        Kailangan ng pahintulot

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Mga extension
    .tooltiptext =
        Mga extension
        May ilang mga extension na hindi pinapayagan

## Autorefresh blocker

refresh-blocked-refresh-label = Pinigilan ng { -brand-short-name } ang agarang pagbukas ng pahinang ito.
refresh-blocked-redirect-label = Pingilan ng { -brand-short-name } ang kusang pagdirekta ng pahinang ito tungo sa ibang pahina.
refresh-blocked-allow =
    .label = Payagan
    .accesskey = A

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Unverified)
popup-notification-xpinstall-prompt-learn-more = Alamin ang tungkol sa ligtas na pagkabit ng mga add-on

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] Pinigil ng { -brand-short-name } na magbukas ng pop-up window sa site na ito.
       *[other] Pinigil ng { -brand-short-name } na magbukas ng { $popupCount } pop-up window sa site na ito.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = Pinigilan ng { -brand-short-name } ang site na ito na magbukas ng higit sa { $popupCount } pop-up window.
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Mga Pagpipilian
           *[other] Mga Kagustuhan
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Ipakita ang '{ $popupURI }'

## Unsigned add-ons notification

unsigned-addons-disabled-message = Isa o higit pang mga add-on ay hindi maaaring maberipika at ito ay nai-disable.
unsigned-addons-disabled-learn-more =
    .label = Alamin
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-addon-learn-more =
    .value = Matuto ng mahigit pa


identity-allow-site-data = vOrbit-lite: Palaging iimbak ang mga cookie/data para sa site na ito
