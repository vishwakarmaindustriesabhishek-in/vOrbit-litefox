# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = Ιδιωτική περιήγηση { -brand-shortcut-name }
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Γρήγορη και ιδιωτική περιήγηση
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Ιδιωτική περιήγηση
       *[other] Ιδιωτική περιήγηση { -brand-full-name }
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Ιδιωτική περιήγηση
popups-infobar-dont-show-message2 =
    .label = Να μην εμφανίζεται αυτό το μήνυμα όταν αποκλείονται αναδυόμενα παράθυρα ή ανακατευθύνσεις τρίτων
    .accesskey = φ
edit-popup-settings2 =
    .label = Διαχείριση ρυθμίσεων αναδυόμενων παραθύρων και ανακατευθύνσεων τρίτων…
    .accesskey = Δ
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Προβολή πληροφοριών ιστοτόπου
            [1] Προβολή πληροφοριών ιστοτόπου (1 αποκλεισμένος ιχνηλάτης)
           *[other] Προβολή πληροφοριών ιστοτόπου ({ $count } αποκλεισμένοι ιχνηλάτες)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } σύνδεσμος
           *[other] { $count } σύνδεσμοι
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Μηνύματα και άλλα…
    .accesskey = Μ
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Μηνύματα, Mail και άλλα…
    .accesskey = Μ
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Κοινή χρήση…
    .accesskey = η
urlbar-identity-button =
    .aria-label = Προβολή πληροφοριών ιστοτόπου

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου μηνυμάτων εγκατάστασης
urlbar-web-notification-anchor =
    .tooltiptext = Επιλέξτε εάν θέλετε να λαμβάνετε ειδοποιήσεις από τον ιστότοπο
urlbar-midi-notification-anchor =
    .tooltiptext = Άνοιγμα πίνακα MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Άνοιγμα πίνακα σειριακών συσκευών
urlbar-eme-notification-anchor =
    .tooltiptext = Διαχείριση χρήσης λογισμικού DRM
urlbar-web-authn-anchor =
    .tooltiptext = Άνοιγμα πίνακα διαδικτυακής ταυτοποίησης
urlbar-canvas-notification-anchor =
    .tooltiptext = Διαχείριση δικαιώματος εξαγωγής καμβά
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Διαχείριση του διαμοιρασμού του μικροφώνου σας για τον ιστοτόπο
urlbar-default-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου μηνυμάτων
urlbar-geolocation-notification-anchor =
    .tooltiptext = Άνοιγμα πίνακα αιτήματος τοποθεσίας
urlbar-localhost-notification-anchor =
    .tooltiptext = Διαχειριστείτε την πρόσβαση στις τοπικές συσκευές για αυτόν τον ιστότοπο
urlbar-local-network-notification-anchor =
    .tooltiptext = Διαχειριστείτε τον διαμοιρασμό της πρόσβασης στο τοπικό δίκτυό σας με αυτόν τον ιστότοπο
urlbar-xr-notification-anchor =
    .tooltiptext = Άνοιγμα πίνακα δικαιωμάτων εικονικής πραγματικότητας
urlbar-storage-access-anchor =
    .tooltiptext = Άνοιγμα πίνακα δικαιωμάτων δραστηριότητας περιήγησης
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Διαχείριση του διαμοιρασμού των παραθύρων ή της οθόνης σας με τον ιστοτόπο
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου μηνυμάτων αποθηκευμένων εκτός σύνδεσης
urlbar-password-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου μηνύματος αποθήκευσης κωδικού πρόσβασης
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Διαχείριση του διαμοιρασμού της κάμερας και/ή του μικροφώνου σας για τον ιστοτόπο
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Διαχείριση κοινής χρήσης άλλων ηχείων με τον ιστότοπο
urlbar-autoplay-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου αυτόματης αναπαραγωγής
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Αποθήκευση δεδομένων στην επίμονη αποθήκευση
urlbar-addons-notification-anchor =
    .tooltiptext = Άνοιγμα πλαισίου μηνυμάτων εγκατάστασης προσθέτων
urlbar-search-tips-confirm = Εντάξει, το κατάλαβα
urlbar-search-tips-confirm-short = Το κατάλαβα
urlbar-result-menu-button =
    .title = Άνοιγμα μενού
urlbar-result-menu-button-feedback = Σχόλια
    .title = Άνοιγμα μενού
urlbar-result-menu-learn-more2 = Μάθετε περισσότερα
    .accesskey = Μ
urlbar-result-menu-remove-from-history2 = Αφαίρεση από το ιστορικό
    .accesskey = Α
urlbar-result-menu-tip-get-help2 = Λήψη βοήθειας
    .accesskey = β
urlbar-result-menu-dismiss-suggestion2 = Απόρριψη πρότασης
    .accesskey = Α
urlbar-result-menu-remove-top-site = Αφαίρεση κορυφαίου ιστοτόπου
    .accesskey = τ
urlbar-result-menu-manage-firefox-suggest2 = Διαχείριση { -firefox-suggest-brand-name(case: "gen") }
    .accesskey = Δ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Αναφορά ανακριβούς τοποθεσίας
    .accesskey = Α
urlbar-result-menu-show-less-frequently3 = Εμφάνιση σπανιότερα
    .accesskey = Ε
urlbar-result-menu-dont-show-weather-suggestions3 = Να μην εμφανίζονται προτάσεις καιρού
    .accesskey = Ν
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Αναφορά ανακριβούς τοποθεσίας
urlbar-result-menu-show-less-frequently2 = Εμφάνιση σπανιότερα
urlbar-result-menu-dont-show-weather-suggestions2 = Να μην εμφανίζονται προτάσεις καιρού
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Απόρριψη πρότασης
    .accesskey = ι
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Αφαίρεση από το ιστορικό
    .accesskey = ε
urlbar-result-menu-learn-more =
    .label = Μάθετε περισσότερα
    .accesskey = Μ
urlbar-result-menu-remove-from-history =
    .label = Αφαίρεση από το ιστορικό
    .accesskey = Α
urlbar-result-menu-tip-get-help =
    .label = Λήψη βοήθειας
    .accesskey = β
urlbar-result-menu-dismiss-suggestion =
    .label = Απόρριψη πρότασης
    .accesskey = Α
urlbar-result-menu-manage-firefox-suggest =
    .label = Διαχείριση { -firefox-suggest-brand-name(case: "gen") }
    .accesskey = Δ
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Αναφορά ανακριβούς τοποθεσίας
urlbar-result-menu-show-less-frequently =
    .label = Εμφάνιση σπανιότερα
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Να μην εμφανίζονται προτάσεις καιρού
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Άνοιγμα μενού
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Ευχαριστούμε για τα σχόλιά σας
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Ευχαριστούμε για τα σχόλιά σας. Δεν θα βλέπετε πλέον προτάσεις καιρού.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Πληκτρολογήστε λιγότερα, βρείτε περισσότερα: Αναζητήστε μέσω { $engineName } κατευθείαν από τη γραμμή διευθύνσεων.
urlbar-search-tips-redirect-2 = Ξεκινήστε την αναζήτησή σας στη γραμμή διευθύνσεων για να δείτε προτάσεις από το { $engineName } και το ιστορικό περιήγησής σας.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Επιλέξτε αυτήν τη συντόμευση για να βρείτε αυτό που χρειάζεστε, πιο γρήγορα.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Σελιδοδείκτες
urlbar-search-mode-tabs = Καρτέλες
urlbar-search-mode-history = Ιστορικό
urlbar-search-mode-actions = Ενέργειες

##

urlbar-geolocation-blocked =
    .tooltiptext = Έχετε αποκλείσει τις πληροφορίες τοποθεσίας σε αυτόν τον ιστότοπο.
urlbar-localhost-blocked =
    .tooltiptext = Έχετε αποκλείσει τις συνδέσεις με τις τοπικές συσκευές για αυτόν τον ιστότοπο.
urlbar-local-network-blocked =
    .tooltiptext = Έχετε αποκλείσει τις συνδέσεις με το τοπικό δίκτυο για αυτόν τον ιστότοπο.
urlbar-xr-blocked =
    .tooltiptext = Έχετε αποκλείσει την πρόσβαση συσκευών εικονικής πραγματικότητας σε αυτόν τον ιστότοπο.
urlbar-web-notifications-blocked =
    .tooltiptext = Έχετε αποκλείσει τις ειδοποιήσεις σε αυτόν τον ιστότοπο.
urlbar-camera-blocked =
    .tooltiptext = Έχετε αποκλείσει την κάμερά σας σε αυτόν τον ιστότοπο.
urlbar-microphone-blocked =
    .tooltiptext = Έχετε αποκλείσει το μικρόφωνό σας σε αυτόν τον ιστότοπο.
urlbar-screen-blocked =
    .tooltiptext = Έχετε αποκλείσει την κοινή χρήση οθόνης σε αυτόν τον ιστότοπο.
urlbar-persistent-storage-blocked =
    .tooltiptext = Έχετε αποκλείσει τη μόνιμη αποθήκευση σε αυτόν τον ιστότοπο.
urlbar-popup-blocked2 =
    .tooltiptext = Έχετε αποκλείσει αναδυόμενα παράθυρα και ανακατευθύνσεις τρίτων σε αυτόν τον ιστότοπο.
urlbar-autoplay-media-blocked =
    .tooltiptext = Έχετε αποκλείσει την αυτόματη αναπαραγωγή πολυμέσων με ήχο σε αυτόν τον ιστότοπο.
urlbar-canvas-blocked =
    .tooltiptext = Έχετε αποκλείσει την εξαγωγή δεδομένων καμβά σε αυτόν τον ιστότοπο.
urlbar-midi-blocked =
    .tooltiptext = Έχετε αποκλείσει την πρόσβαση MIDI σε αυτόν τον ιστότοπο.
urlbar-serial-blocked =
    .tooltiptext = Έχετε αποκλείσει την πρόσβαση σειριακών θυρών για αυτόν τον ιστότοπο.
urlbar-install-blocked =
    .tooltiptext = Έχετε αποκλείσει την εγκατάσταση προσθέτων σε αυτόν τον ιστότοπο.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Επεξεργασία σελιδοδείκτη ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Δημιουργία σελιδοδείκτη για αυτήν τη σελίδα ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Διαχωρισμός προβολής
    .tooltiptext = Διαχωρισμός προβολής

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Επικόλληση και μετάβαση
    .accesskey = Ε
urlbar-menuitem-paste-and-search =
    .label = Επικόλληση και αναζήτηση
    .accesskey = α

## Searchbar context menu

clear-search-history =
    .label = Απαλοιφή ιστορικού αναζήτησης
    .accesskey = κ

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Διαχείριση επέκτασης…
    .accesskey = ε
page-action-remove-extension2 =
    .label = Αφαίρεση επέκτασης
    .accesskey = φ

## Auto-hide Context Menu

full-screen-autohide =
    .label = Απόκρυψη γραμμών εργαλείων
    .accesskey = ψ
full-screen-exit =
    .label = Έξοδος από πλήρη οθόνη
    .accesskey = π

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Τρέχουσα αναζήτηση με:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Αλλαγή ρυθμίσεων αναζήτησης
search-one-offs-context-open-new-tab =
    .label = Αναζήτηση σε νέα καρτέλα
    .accesskey = Α
search-one-offs-context-set-as-default =
    .label = Ορισμός ως προεπιλεγμένη μηχανή αναζήτησης
    .accesskey = Ο
search-one-offs-context-set-as-default-private =
    .label = Ορισμός ως προεπιλεγμένη μηχανή αναζήτησης ιδιωτικών παραθύρων
    .accesskey = ι
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Προσθήκη μηχανής αναζήτησης «{ $engineName }»
    .label = Προσθήκη «{ $engineName }»
    .tooltiptext = Προσθήκη μηχανής αναζήτησης «{ $engineName }»
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Προσθήκη μηχανής αναζήτησης
    .accesskey = Π
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Προσθήκη μηχανής αναζήτησης

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Σελιδοδείκτες ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Καρτέλες ({ $restrict })
search-one-offs-history =
    .tooltiptext = Ιστορικό ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Ενέργειες ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Προβολή προσθέτων
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = επεκτάσεις, θέματα, πρόσθετα, addons, add-ons
# Opens preferences page at AI controls
quickactions-manageai = Διαχείριση επιλογών ελέγχου ΤΝ
quickactions-cmd-manageai = απενεργοποίηση ΤΝ, διαχείριση ΤΝ, απενεργοποίηση AI, διαχείριση AI, disable ai, off ai, manage ai
# Opens the bookmarks library window
quickactions-bookmarks2 = Διαχείριση σελιδοδεικτών
quickactions-cmd-bookmarks = σελιδοδείκτες, αγαπημένα
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Απαλοιφή πρόσφατου ιστορικού
quickactions-cmd-clearrecenthistory2 = cookie, cookies, διαγραφή cookie, εκκαθάριση cookie, κρυφή μνήμη, προσωρινή μνήμη, εκκαθάριση κρυφής μνήμης, διαγραφή κρυφής μνήμης, δεδομένα περιήγησης, εκκαθάριση δεδομένων περιήγησης, διαγραφή δεδομένων περιήγησης, ιστορικό, εκκαθάριση πρόσφατου ιστορικού, διαγραφή πρόσφατου ιστορικού
# Opens about:downloads page
quickactions-downloads2 = Προβολή λήψεων
quickactions-cmd-downloads = λήψεις, αρχεία λήψης
# Opens about:addons page in the extensions section
quickactions-extensions = Διαχείριση επεκτάσεων
quickactions-cmd-extensions2 = επεκτάσεις, πρόσθετα
# Opens Firefox View
quickactions-firefoxview = Άνοιγμα { -firefoxview-brand-name(case: "gen") }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = άνοιγμα { -firefoxview-brand-name(case: "gen") }, { -firefoxview-brand-name(case: "nom") }, άνοιγμα προβολής, προβολή
# Opens SUMO home page
quickactions-help = Βοήθεια { -brand-product-name }
quickactions-cmd-help = βοήθεια, υποστήριξη
# Opens the devtools web inspector
quickactions-inspector2 = Άνοιγμα εργαλείων ανάπτυξης
quickactions-cmd-inspector2 = επιθεώρηση, επιθεώρηση σελίδας, εργαλεία ανάπτυξης, ανάπτυξη, devtools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Επιλογή χρώματος
quickactions-cmd-colorpicker = εργαλείο επιλογής χρώματος, σταγονόμετρο, επιλογή χρώματος, color picker, eyedropper, pick color
# Opens Firefox Library
quickactions-cmd-library = βιβλιοθήκη
quickactions-library = Άνοιγμα βιβλιοθήκης
# Opens about:logins
quickactions-logins2 = Διαχείριση κωδικών πρόσβασης
quickactions-cmd-logins = συνδέσεις, στοιχεία σύνδεσης, διαπιστευτήρια, κωδικοί πρόσβασης, κωδικοί
# Mutes all tabs playing audio
quickactions-mute = Σίγαση καρτελών που αναπαράγουν ήχο
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = σίγαση, σιωπή, σουτ, σσσσς
# Opens the print dialog
quickactions-print2 = Εκτύπωση σελίδας
quickactions-cmd-print = εκτύπωση
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Αποθήκευση σελίδας ως PDF
quickactions-cmd-savepdf2 = pdf, αποθήκευση σελίδας
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Άνοιγμα επεξεργασίας PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Άνοιγμα ιδιωτικού παραθύρου
quickactions-cmd-private = ιδιωτική περιήγηση, ανώνυμη περιήγηση
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Ανανέωση του { -brand-short-name }
quickactions-cmd-refresh = ανανέωση, επαναφόρτωση
# Restarts the browser
quickactions-restart = Επανεκκίνηση του { -brand-short-name }
quickactions-cmd-restart = επανεκκίνηση
# Opens the screenshot tool
quickactions-screenshot3 = Λήψη στιγμιότυπου
quickactions-cmd-screenshot2 = στιγμιότυπο, στιγμιότυπο οθόνης, λήψη στιγμιότυπου, screenshot
# Opens about:translations
quickactions-translate = Μετάφραση
quickactions-cmd-translate = μετάφραση
# Opens about:preferences
quickactions-settings2 = Διαχείριση ρυθμίσεων
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = ρυθμίσεις, προτιμήσεις, επιλογές, διαχείριση
# Opens about:addons page in the themes section
quickactions-themes = Διαχείριση θεμάτων
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = θέματα, πρόσθετα
# Opens a SUMO article explaining how to update the browser
quickactions-update = Ενημέρωση του { -brand-short-name }
quickactions-cmd-update = ενημέρωση, αναβάθμιση
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Προβολή πηγαίου κώδικα σελίδας
quickactions-cmd-viewsource2 = προβολή πηγής, πηγή, πηγή σελίδας
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Άνοιγμα του { -firefoxlabs-brand-name }
quickactions-cmd-labs = πείραμα, πειράματα, εργαστήριο, εργαστήρια, lab, labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Μάθετε περισσότερα για τις γρήγορες ενέργειες
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Πατήστε Tab για επιλογή:

## Bookmark Panel

bookmarks-add-bookmark = Προσθήκη σελιδοδείκτη
bookmarks-edit-bookmark = Επεξεργασία σελιδοδείκτη
bookmark-panel-cancel =
    .label = Ακύρωση
    .accesskey = Α
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Αφαίρεση σελιδοδείκτη
           *[other] Αφαίρεση { $count } σελιδοδεικτών
        }
    .accesskey = Α
bookmark-panel-show-editor-checkbox =
    .label = Εμφάνιση επεξεργαστή κατά την αποθήκευση
    .accesskey = Ε
bookmark-panel-save-button2 =
    .label = Αποθήκευση
    .accesskey = Α
bookmark-panel-save-button =
    .label = Αποθήκευση
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Πληροφορίες ιστοτόπου για το { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Ασφάλεια σύνδεσης για το { $host }
identity-connection-not-secure = Μη ασφαλής σύνδεση
identity-connection-secure = Ασφαλής σύνδεση
identity-connection-failure = Αποτυχία σύνδεσης
identity-connection-internal = Αυτή είναι μια ασφαλής σελίδα του { -brand-short-name }.
identity-connection-file = Αυτή η σελίδα είναι αποθηκευμένη στον υπολογιστή σας.
identity-connection-associated = Αυτή η σελίδα φορτώνεται από άλλη σελίδα.
identity-extension-page = Αυτή η σελίδα έχει φορτωθεί από μια επέκταση.
identity-active-blocked = Το { -brand-short-name } έχει αποκλείσει επισφαλή τμήματα αυτής της σελίδας.
identity-custom-root = Η σύνδεση επαληθεύτηκε από έναν εκδότη πιστοποιητικών που δεν αναγνωρίζεται από τη Mozilla.
identity-passive-loaded = Κάποια τμήματα αυτής της σελίδας δεν είναι ασφαλή (όπως οι εικόνες).
identity-active-loaded = Έχετε απενεργοποιήσει την προστασία σε αυτήν τη σελίδα.
identity-weak-encryption = Αυτή η σελίδα δεν χρησιμοποιεί ισχυρή κρυπτογράφηση.
identity-https-only-connection-upgraded = (αναβαθμίστηκε σε HTTPS)
identity-https-only-label2 = Αυτόματη αναβάθμιση ιστοτόπου σε ασφαλή σύνδεση
identity-https-only-dropdown-on =
    .label = Ενεργή
identity-https-only-dropdown-off =
    .label = Ανενεργή
identity-https-only-dropdown-off-temporarily =
    .label = Προσωρινά ανενεργή
identity-https-only-info-turn-on3 = Ενεργοποιήστε τις αναβαθμίσεις HTTPS σε αυτόν τον ιστότοπο αν θέλετε το { -brand-short-name } να αναβαθμίζει τη σύνδεση όταν είναι εφικτό.
identity-https-only-info-turn-off3 = Αν η σελίδα δεν λειτουργεί σωστά, μπορείτε να απενεργοποιήσετε τις αναβαθμίσεις HTTPS για να γίνει ανανέωση του ιστοτόπου μέσω του επισφαλούς HTTP.
identity-https-only-info-no-upgrade = Δεν είναι δυνατή η αναβάθμιση της σύνδεσης από HTTP.
identity-permissions-storage-access-header = Cookie μεταξύ ιστοτόπων
identity-permissions-storage-access-hint = Αυτά τα μέρη μπορούν να χρησιμοποιήσουν cookie μεταξύ ιστοτόπων και δεδομένα ιστοτόπων όσο βρίσκεστε σε αυτόν τον ιστότοπο.
identity-permissions-storage-access-learn-more = Μάθετε περισσότερα
identity-permissions-reload-hint = Ίσως χρειαστεί να επαναφορτώσετε τη σελίδα για εφαρμογή των αλλαγών.
identity-clear-site-data =
    .label = Απαλοιφή cookie και δεδομένων ιστοτόπου…
identity-connection-not-secure-security-view = Η σύνδεσή σας με αυτόν τον ιστότοπο δεν είναι ασφαλής.
identity-connection-verified = Η σύνδεσή σας με αυτόν τον ιστότοπο είναι ασφαλής.
identity-ev-owner-label2 = Το πιστοποιητικό εκδόθηκε για
identity-verifier-label2 = Επαληθεύτηκε από
identity-ev-owner-label = Το πιστοποιητικό εκδόθηκε για:
identity-verifier-label = Επαληθεύτηκε από:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Πιστοποιημένο όπως ορίζει ο Κανονισμός (ΕΕ) 2024/1183.
identity-description-custom-root2 = Η Mozilla δεν αναγνωρίζει αυτόν τον εκδότη πιστοποιητικών. Ενδέχεται να έχει προστεθεί από το λειτουργικό σας σύστημα ή κάποιο διαχειριστή.
identity-cert-exception-overridden = Έχετε προσθέσει μια εξαίρεση ασφαλείας για αυτόν τον ιστότοπο.
identity-remove-cert-exception =
    .label = Αφαίρεση εξαίρεσης
    .accesskey = ρ
identity-description-insecure = Η σύνδεσή σας με αυτόν τον ιστότοπο δεν είναι ιδιωτική. Οι υποβεβλημένες πληροφορίες μπορεί να προβληθούν από τρίτους (όπως κωδικοί πρόσβασης, μηνύματα, πιστωτικές κάρτες κ.λπ.).
identity-description-weak-cipher-intro = Η σύνδεση σας με αυτόν τον ιστότοπο δεν χρησιμοποιεί ισχυρή κρυπτογράφηση και δεν είναι ιδιωτική.
identity-description-weak-cipher-risk = Τρίτα άτομα μπορούν να δουν τις πληροφορίες σας ή να τροποποιήσουν τη συμπεριφορά αυτού του ιστοτόπου.
identity-description-active-blocked2 = Το { -brand-short-name } έχει αποκλείσει επισφαλή τμήματα αυτής της σελίδας.
identity-description-passive-loaded = Η σύνδεσή σας δεν είναι ιδιωτική και οι πληροφορίες που μοιράζεστε με αυτόν τον ιστότοπο μπορεί να προβληθούν από τρίτους.
identity-description-passive-loaded-insecure2 = Αυτός ο ιστότοπος διαθέτει επισφαλές περιεχόμενο (όπως εικόνες).
identity-description-passive-loaded-mixed2 = Παρόλο που το { -brand-short-name } έχει αποκλείσει ορισμένο περιεχόμενο, υπάρχει ακόμη επισφαλές περιεχόμενο (π.χ. εικόνες).
identity-description-active-loaded = Αυτός ο ιστότοπος διαθέτει επισφαλές περιεχόμενο (όπως σενάρια) και η σύνδεσή σας δεν είναι ιδιωτική.
identity-description-active-loaded-insecure = Οι πληροφορίες που μοιράζεστε με αυτόν τον ιστότοπο μπορεί να προβληθούν από τρίτους (όπως κωδικοί πρόσβασης, μηνύματα, πιστωτικές κάρτες κ.λπ.).
identity-description-tls-key-logging-heading = Η σύνδεσή σας ενδέχεται να μην είναι ιδιωτική
identity-description-tls-key-logging-message = Μια εφαρμογή ή υπηρεσία ενδέχεται να βλέπει την κρυπτογραφημένη κίνηση από αυτόν τον ιστότοπο.
identity-more-info-link-text =
    .label = Περισσότερες πληροφορίες

## Window controls

browser-window-minimize-button =
    .tooltiptext = Ελαχιστοποίηση
browser-window-maximize-button =
    .tooltiptext = Μεγιστοποίηση
browser-window-restore-down-button =
    .tooltiptext = Αναίρεση μεγιστοποίησης
browser-window-close-button =
    .tooltiptext = Κλείσιμο
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Επιστροφή

## Bookmarks toolbar items

browser-import-button2 =
    .label = Εισαγωγή σελιδοδεικτών…
    .tooltiptext = Εισαγωγή σελιδοδεικτών από άλλο πρόγραμμα περιήγησης στο { -brand-short-name }.
bookmarks-toolbar-empty-message = Για γρήγορη πρόσβαση, τοποθετήστε τους σελιδοδείκτες σας εδώ, στη γραμμή σελιδοδεικτών. <a data-l10n-name="manage-bookmarks">Διαχείριση σελιδοδεικτών…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Κάμερα:
    .accesskey = Κ
popup-select-camera-icon =
    .tooltiptext = Κάμερα
popup-select-microphone-device =
    .value = Μικρόφωνο:
    .accesskey = Μ
popup-select-microphone-icon =
    .tooltiptext = Μικρόφωνο
popup-select-speaker-icon =
    .tooltiptext = Ηχεία
popup-select-window-or-screen =
    .label = Παράθυρο ή οθόνη:
    .accesskey = Π
popup-all-windows-shared = Όλα τα ορατά παράθυρα της οθόνης σας θα γίνουν κοινόχρηστα.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Μοιράζεστε το { -brand-short-name }. Άλλα άτομα μπορούν να δουν όταν μεταβείτε σε μια νέα καρτέλα.
sharing-warning-screen = Μοιράζεστε ολόκληρη την οθόνη σας. Οι άλλοι χρήστες μπορούν να δουν ότι κάνετε εναλλαγή σε νέα καρτέλα.
sharing-warning-proceed-to-tab =
    .label = Συνέχεια στην καρτέλα
sharing-warning-disable-for-session =
    .label = Απενεργοποίηση προστασίας κοινής χρήσης για αυτήν τη συνεδρία

## WebSerial "select a port" popup

webserial-select-port-label = Επιλογή σειριακής θύρας:
webserial-no-ports-available = Καμία διαθέσιμη σειριακή θύρα

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Κλείσιμο
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Αναζήτηση ή εισαγωγή διεύθυνσης
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Εισαγάγετε διεύθυνση
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Αναζήτηση με { $name }
    .placeholder = Αναζήτηση στο διαδίκτυο
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Αναζήτηση { $name }
    .placeholder = Εισαγάγετε όρους αναζήτησης
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Αναζήτηση σελιδοδεικτών
    .placeholder = Εισαγάγετε όρους αναζήτησης
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Αναζήτηση ιστορικού
    .placeholder = Εισαγάγετε όρους αναζήτησης
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Αναζήτηση καρτελών
    .placeholder = Εισαγάγετε όρους αναζήτησης
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Αναζήτηση ενεργειών
    .placeholder = Εισαγάγετε όρους αναζήτησης
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Αναζήτηση με { $name } ή εισαγωγή διεύθυνσης
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Το πρόγραμμα περιήγησης ελέγχεται απομακρυσμένα (αιτία: { $component })
urlbar-permissions-granted =
    .tooltiptext = Έχετε χορηγήσει πρόσθετα δικαιώματα σε αυτόν τον ιστότοπο.
urlbar-switch-to-tab =
    .value = Εναλλαγή σε καρτέλα:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Επέκταση:
urlbar-go-button2 =
    .title = Μετάβαση στη διεύθυνση της γραμμής διευθύνσεων
urlbar-page-action-button =
    .tooltiptext = Ενέργειες σελίδας
urlbar-revert-button =
    .tooltiptext = Εμφάνιση διεύθυνσης στη γραμμή τοποθεσίας

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Αναζήτηση με { $engine } σε ιδιωτικό παράθυρο
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Αναζήτηση σε ιδιωτικό παράθυρο
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Αναζήτηση με { $engine }
urlbar-result-action-sponsored = Χορηγία
urlbar-result-action-switch-tab = Εναλλαγή σε καρτέλα
urlbar-result-action-move-tab-to-split-view = Μετακίνηση καρτέλας στον διαχωρισμό προβολής
urlbar-result-action-visit = Επίσκεψη
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Εναλλαγή σε καρτέλα · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Ανώνυμη ομάδα
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Επίσκεψη από το πρόχειρο
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Πατήστε Tab για αναζήτηση με { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Πατήστε το Tab για αναζήτηση με { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Αναζήτηση με { $engine } απευθείας από τη γραμμή διευθύνσεων
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Αναζήτηση { $engine } απευθείας από τη γραμμή διευθύνσεων
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Αντιγραφή
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = δεν ορίζεται
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Επέκταση { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Προτείνεται
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> — { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> — { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> — { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Χορηγία
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Ερώτηση
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Τελευταία επίσκεψη: { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Τελευταία επίσκεψη: πριν από { $daysAgo } ημέρα
       *[other] Τελευταία επίσκεψη: πριν από { $daysAgo } ημέρες
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Τελευταία επίσκεψη: πριν από { $weeksAgo } εβδομάδα
       *[other] Τελευταία επίσκεψη: πριν από { $weeksAgo } εβδομάδες
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Τελευταία επίσκεψη: πριν από { $monthsAgo } μήνα
       *[other] Τελευταία επίσκεψη: πριν από { $monthsAgo } μήνες
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Τελευταία επίσκεψη: { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Προσθήκη σελιδοδείκτη: { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Τελευταία επίσκεψη: { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Τελευταία επίσκεψη: { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Τελευταία επίσκεψη: { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Λάβετε δεδομένα χρηματιστηρίου στη γραμμή αναζήτησης
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Να εμφανίζονται ενημερώσεις μετοχών και άλλες από τους συνεργάτες μας όταν κοινοποιούνται δεδομένα ερωτημάτων αναζήτησης στη { -vendor-short-name }. <a data-l10n-name="learn-more-link">Μάθετε περισσότερα</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Εμφάνιση προτάσεων
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Όχι τώρα
urlbar-result-realtime-opt-in-dismiss = Απόρριψη
urlbar-result-realtime-opt-in-dismiss-all2 = Να μην εμφανίζονται αυτές οι προτάσεις
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Να μην εμφανίζονται προτάσεις μετοχών
    .accesskey = Ν
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Να μην εμφανίζονται προτάσεις μετοχών
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Να μην εμφανίζονται αυτές οι προτάσεις
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Να μην εμφανίζονται προτάσεις μετοχών
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Ευχαριστούμε για τα σχόλιά σας. Δεν θα βλέπετε πλέον προτάσεις μετοχών.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Προτάσεις χρηματιστηρίου
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Ευχαριστούμε για τα σχόλιά σας. Δεν θα βλέπετε πλέον αυτές τις προτάσεις.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · Σε { $daysUntilStart } ημέρα
       *[other] { $name } · Σε { $daysUntilStart } ημέρες
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Ξεκινά σε { $daysUntilStart } ημέρα
       *[other] { $name } · Ξεκινά σε { $daysUntilStart } ημέρες
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Τελειώνει σε { $daysUntilEnd } ημέρα
       *[other] { $name } · Τελειώνει σε { $daysUntilEnd } ημέρες
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Σήμερα
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Τελειώνει σήμερα

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Αναζήτηση με { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Αναζήτηση σε { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Αναζήτηση με { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, επιλογή μηχανής αναζήτησης
urlbar-searchmode-button-no-engine2 =
    .title = Δεν έχει επιλεγεί συντόμευση, επιλέξτε συντόμευση
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Η αναζήτηση λέξεων-κλειδιών είναι ανενεργή
urlbar-searchmode-dropmarker2 =
    .title = Επιλογή μηχανής αναζήτησης
urlbar-searchmode-bookmarks4 = Σελιδοδείκτες
urlbar-searchmode-tabs4 = Καρτέλες
urlbar-searchmode-history4 = Ιστορικό
urlbar-searchmode-actions4 = Ενέργειες
urlbar-searchmode-bookmarks3 = Σελιδοδείκτες
    .accesskey = Σ
urlbar-searchmode-tabs3 = Καρτέλες
    .accesskey = Κ
urlbar-searchmode-history3 = Ιστορικό
    .accesskey = Ι
urlbar-searchmode-actions3 = Ενέργειες
    .accesskey = Ε
urlbar-searchmode-exit-button2 =
    .title = Κλείσιμο
urlbar-searchmode-default2 =
    .title = Προεπιλεγμένη μηχανή αναζήτησης
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Προσθήκη «{ $engineName }»
    .title = Προσθήκη μηχανής αναζήτησης «{ $engineName }»
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Τρέχουσα αναζήτηση με:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Αναζήτηση με:
urlbar-searchmode-popup-search-settings2 = Ρυθμίσεις αναζήτησης
urlbar-searchmode-popup-settings2 = Ρυθμίσεις
urlbar-searchmode-popup-search-settings = Ρυθμίσεις αναζήτησης
    .accesskey = ζ
urlbar-searchmode-popup-settings = Ρυθμίσεις
    .accesskey = Ρ

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Αναζήτηση σελιδοδεικτών
urlbar-result-action-search-history = Αναζήτηση ιστορικού
urlbar-result-action-search-tabs = Αναζήτηση καρτελών
urlbar-result-action-search-actions = Αναζήτηση ενεργειών
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Εναλλαγή σε «{ $group }»
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Άνοιγμα «{ $group }»

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Άνοιγμα σε νέα καρτέλα
    .accesskey = γ
urlbar-view-context-menu-open-in-container-tab =
    .label = Άνοιγμα σε νέα θεματική καρτέλα
    .accesskey = θ
urlbar-view-context-menu-open-in-window =
    .label = Άνοιγμα σε νέο παράθυρο
    .accesskey = ν
urlbar-view-context-menu-open-in-private-window =
    .label = Άνοιγμα σε νέο ιδιωτικό παράθυρο
    .accesskey = ι
urlbar-view-context-menu-open-in-tab2 = Άνοιγμα σε νέα καρτέλα
    .accesskey = γ
urlbar-view-context-menu-open-in-container-tab2 = Άνοιγμα σε νέα θεματική καρτέλα
    .accesskey = θ
urlbar-view-context-menu-open-in-window2 = Άνοιγμα σε νέο παράθυρο
    .accesskey = ν
urlbar-view-context-menu-open-in-private-window2 = Άνοιγμα σε νέο ιδιωτικό παράθυρο
    .accesskey = ι
urlbar-view-context-menu-search-in-tab = Αναζήτηση σε νέα καρτέλα
    .accesskey = ζ
urlbar-view-context-menu-search-in-container-tab = Αναζήτηση σε νέα θεματική καρτέλα
    .accesskey = τ
urlbar-view-context-menu-search-in-window = Αναζήτηση σε νέο παράθυρο
    .accesskey = ν
urlbar-view-context-menu-search-in-private-window = Αναζήτηση σε νέο ιδιωτικό παράθυρο
    .accesskey = δ
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Παράλειψη αυτού του μενού κατά τη χρήση του πλήκτρου Tab
    .accesskey = Π

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name(case: "nom") }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Προτάσεις { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Γρήγορες ενέργειες
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Πρόσφατες αναζητήσεις
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Τάσεις στο { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Απόκρυψη δημοφιλών αναζητήσεων
    .accesskey = Α
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Απόκρυψη δημοφιλών αναζητήσεων
    .accesskey = Α
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Απόκρυψη δημοφιλών αναζητήσεων
    .accesskey = Α
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Ευχαριστούμε για τα σχόλιά σας. Δεν θα βλέπετε πλέον δημοφιλείς αναζητήσεις.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Άνοιγμα προβολής ανάγνωσης
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Κλείσιμο προβολής ανάγνωσης

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Άνοιγμα λειτουργίας «Εικόνα εντός εικόνας» ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Κλείσιμο λειτουργίας «Εικόνα εντός εικόνας» ({ $shortcut })
picture-in-picture-panel-header = Εικόνα εντός εικόνας
picture-in-picture-panel-headline = Αυτός ο ιστότοπος δεν συνιστά τη λειτουργία «Εικόνα εντός εικόνας»
picture-in-picture-panel-body = Τα βίντεο ενδέχεται να μην προβάλλονται όπως θα ήθελε ο προγραμματιστής όταν είναι ενεργοποιημένη η λειτουργία «Εικόνα εντός εικόνας».
picture-in-picture-enable-toggle =
    .label = Ενεργοποίηση ούτως ή άλλως

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = Το <span data-l10n-name="domain">{ $domain }</span> εκτελείται σε πλήρη οθόνη
fullscreen-warning-no-domain = Αυτό το έγγραφο εμφανίζεται σε πλήρη οθόνη
fullscreen-exit-button = Έξοδος από πλήρη οθόνη (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Έξοδος από πλήρη οθόνη (esc)
fullscreen-keyboardlock-exit-button = Έξοδος από την πλήρη οθόνη (Πατήστε παρατεταμένα το Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Έξοδος από την πλήρη οθόνη (Πατήστε παρατεταμένα το esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = Το <span data-l10n-name="domain">{ $domain }</span> ελέγχει τον κέρσορα. Πατήστε το Esc για ανάκτηση ελέγχου.
pointerlock-warning-no-domain = Αυτό το έγγραφο ελέγχει τον κέρσορά σας. Πατήστε το Esc για ανάκτηση ελέγχου.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Διαχείριση σελιδοδεικτών
bookmarks-recent-bookmarks-panel-subheader = Πρόσφατοι σελιδοδείκτες
bookmarks-toolbar-chevron =
    .tooltiptext = Εμφάνιση περισσότερων σελιδοδεικτών
bookmarks-sidebar-content =
    .aria-label = Σελιδοδείκτες
bookmarks-menu-button =
    .label = Μενού σελιδοδεικτών
bookmarks-other-bookmarks-menu =
    .label = Άλλοι σελιδοδείκτες
bookmarks-mobile-bookmarks-menu =
    .label = Σελιδοδείκτες κινητού

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Απόκρυψη πλαϊνής γραμμής σελιδοδεικτών
           *[other] Προβολή πλαϊνής γραμμής σελιδοδεικτών
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Απόκρυψη γραμμής σελιδοδεικτών
           *[other] Προβολή γραμμής σελιδοδεικτών
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Απόκρυψη γραμμής σελιδοδεικτών
           *[other] Εμφάνιση γραμμής σελιδοδεικτών
        }

##

bookmarks-search =
    .label = Αναζήτηση σελιδοδεικτών
bookmarks-tools =
    .label = Εργαλεία σελιδοδεικτών
bookmarks-subview-edit-bookmark =
    .label = Επεξεργασία σελιδοδείκτη…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Σελιδοδείκτες
    .toolbarname = Γραμμή σελιδοδεικτών
    .accesskey = Γ
bookmarks-toolbar-menu =
    .label = Γραμμή σελιδοδεικτών
bookmarks-toolbar-placeholder =
    .title = Στοιχεία γραμμής σελιδοδεικτών
bookmarks-toolbar-placeholder-button =
    .label = Στοιχεία γραμμής σελιδοδεικτών
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Προσθήκη σελιδοδείκτη…

## Library Panel items

library-bookmarks-menu =
    .label = Σελιδοδείκτες

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Επιδιόρθωση κωδικοποίησης κειμένου
    .tooltiptext = Υπόθεση σωστής κωδικοποίησης κειμένου από το περιεχόμενο της σελίδας

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Ρυθμίσεις
    .tooltiptext =
        { PLATFORM() ->
            [macos] Άνοιγμα ρυθμίσεων ({ $shortcut })
           *[other] Άνοιγμα ρυθμίσεων
        }
toolbar-overflow-customize-button =
    .label = Προσαρμογή γραμμής εργαλείων…
    .accesskey = ο
toolbar-button-email-link =
    .label = Αποστολή συνδέσμου
    .tooltiptext = Αποστολή συνδέσμου σελίδας
toolbar-button-logins =
    .label = Κωδικοί πρόσβασης
    .tooltiptext = Προβολή και διαχείριση των αποθηκευμένων κωδικών πρόσβασης
qrcode-panel-error =
    .message = Αποτυχία δημιουργίας κωδικού QR. Δοκιμάστε ξανά.
qrcode-copy-button =
    .label = Αντιγραφή
qrcode-copy-success =
    .message = Ο κωδικός QR αντιγράφτηκε στο πρόχειρο.
qrcode-copy-error =
    .message = Αποτυχία αντιγραφής κωδικού QR.
qrcode-save-button =
    .label = Αποθήκευση
qrcode-window-title = Κωδικός QR
qrcode-dialog-title = Κωδικός QR
qrcode-image =
    .aria-label = Κωδικός QR
qrcode-close-button =
    .aria-label = Κλείσιμο
toolbar-button-save-page =
    .label = Αποθήκευση σελίδας
    .tooltiptext = Αποθήκευση σελίδας ({ $shortcut })
toolbar-button-open-file =
    .label = Άνοιγμα αρχείου
    .tooltiptext = Άνοιγμα αρχείου ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Συγχρονισμένες καρτέλες
    .tooltiptext = Εμφάνιση καρτελών από άλλες συσκευές
toolbar-button-send-tab =
    .label = Αποστολή καρτέλας
    .tooltiptext = Αποστολή τρέχουσας καρτέλας σε άλλη συσκευή
toolbar-button-new-private-window =
    .label = Νέο ιδιωτικό παράθυρο
    .tooltiptext = Άνοιγμα σε νέο παράθυρο ιδιωτικής περιήγησης ({ $shortcut })
toolbar-button-share-tab =
    .label = Κοινοποίηση
    .tooltiptext = Κοινοποίηση σελίδας
toolbar-button-tab-groups =
    .label = Ομάδες καρτελών
    .tooltiptext = Εμφάνιση των ομάδων καρτελών σας
toolbar-button-history =
    .label = Ιστορικό
    .tooltiptext = Εμφάνιση ιστορικού ({ $shortcut })
toolbar-button-find =
    .label = Εύρεση
    .tooltiptext = Εύρεση στη σελίδα ({ $shortcut })
toolbar-button-developer =
    .label = Ανάπτυξη
    .tooltiptext = Άνοιγμα εργαλείων ανάπτυξης web ({ $shortcut })
toolbar-button-forget =
    .label = Διαγραφή
    .tooltiptext = Διαγραφή μέρους του ιστορικού περιήγησης
toolbar-zoom-controls =
    .label = Στοιχεία ελέγχου ζουμ
    .title = Στοιχεία ελέγχου ζουμ
toolbar-button-zoom-out =
    .label = Σμίκρυνση
    .tooltiptext = Σμίκρυνση ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Επαναφορά επιπέδου ζουμ ({ $shortcut })
toolbar-button-zoom-in =
    .label = Μεγέθυνση
    .tooltiptext = Μεγέθυνση ({ $shortcut })
toolbar-edit-controls =
    .label = Κουμπιά επεξεργασίας
    .title = Κουμπιά επεξεργασίας
toolbar-button-cut =
    .label = Αποκοπή
    .tooltiptext = Αποκοπή ({ $shortcut })
toolbar-button-copy =
    .label = Αντιγραφή
    .tooltiptext = Αντιγραφή ({ $shortcut })
toolbar-button-paste =
    .label = Επικόλληση
    .tooltiptext = Επικόλληση ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Κάποιοι ήχοι ή βίντεο του ιστοτόπου χρησιμοποιούν λογισμικό DRM, που ενδέχεται να περιορίσει αυτά που μπορείτε να κάνετε με το { -brand-short-name }.
eme-notifications-drm-content-playing-manage = Διαχείριση ρυθμίσεων
eme-notifications-drm-content-playing-manage-accesskey = Δ
eme-notifications-drm-content-playing-dismiss = Απόρριψη
eme-notifications-drm-content-playing-dismiss-accesskey = Α

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Θα πρέπει να ενεργοποιήσετε το DRM για αναπαραγωγή ήχου ή βίντεο στη σελίδα.
eme-notifications-drm-content-disabled-button =
    .label = Ενεργοποίηση DRM
    .accesskey = Ε
eme-notifications-drm-content-cdm-installing-message = Το { -brand-short-name } εγκαθιστά κάποια απαραίτητα στοιχεία προκειμένου να γίνει αναπαραγωγή ήχου ή βίντεο στη σελίδα. Δοκιμάστε ξανά αργότερα.
decoder-doctor-no-codecs-linux-message = Για την αναπαραγωγή βίντεο, ενδέχεται να χρειάζεται η εγκατάσταση των απαραίτητων αποκωδικοποιητών βίντεο.
decoder-doctor-no-hw-acceleration-message = Για τη βελτίωση της ποιότητας των βίντεο, ενδέχεται να χρειάζεται η εγκατάσταση του Πακέτου δυνατοτήτων media της Microsoft.
decoder-doctor-no-pulse-audio-message = Για την αναπαραγωγή ήχου, ίσως χρειαστεί να εγκαταστήσετε το λογισμικό PulseAudio.
decoder-doctor-unsupported-libavcodec-message = Το libavcodec παρουσιάζει ευπάθειες ασφάλειας ή δεν υποστηρίζεται και πρέπει να ενημερωθεί για την αναπαραγωγή βίντεο.
decoder-doctor-decode-error-message = Προέκυψε σφάλμα κατά την αποκωδικοποίηση ενός πόρου πολυμέσων.
decoder-doctor-decode-warning-message = Προέκυψε ανακτήσιμο σφάλμα κατά την αποκωδικοποίηση ενός πόρου πολυμέσων.
decoder-doctor-learn-how-link = Μάθετε πώς
decoder-doctor-report-issue-button =
    .label = Αναφορά ζητήματος ιστοτόπου
    .accesskey = Α
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Το άρθρωμα { $pluginName } κατέρρευσε.
plugin-crashed-notification-reload-button =
    .label = Ανανέωση σελίδας
    .accesskey = ν
plugin-crashed-notification-submit-button =
    .label = Υποβολή αναφοράς κατάρρευσης
    .accesskey = β

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Παραπλανητικός ιστότοπος!
safebrowsing-reported-attack-site-message = Έχει αναφερθεί ως ιστότοπος επιθέσεων!
safebrowsing-reported-unwanted-site-message = Έχει αναφερθεί ως ιστότοπος ανεπιθύμητου λογισμικού!
safebrowsing-reported-harmful-site-message = Αναφέρθηκε επιβλαβής ιστότοπος!
safebrowsing-get-me-out-of-here-button =
    .label = Θέλω να φύγω από εδώ!
    .accesskey = γ
safebrowsing-not-a-deceptive-site-button =
    .label = Αυτός δεν είναι παραπλανητικός ιστότοπος…
    .accesskey = Δ
safebrowsing-not-an-attack-site-button =
    .label = Αυτός δεν είναι ιστότοπος επιθέσεων…
    .accesskey = θ

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Πρέπει να συνδεθείτε σε αυτό το δίκτυο πριν μπορέσετε να αποκτήσετε πρόσβαση στο διαδίκτυο.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Άνοιγμα σελίδας σύνδεσης σε δίκτυο

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Μήπως θέλατε να μεταβείτε στο { $hostName };
keyword-uri-fixup-go-to-button =
    .label = Ναι, μετάβαση στο { $hostName }
    .accesskey = Ν

## Password save/update panel

panel-save-update-username-2 =
    .label = Όνομα χρήστη
panel-save-update-password-2 =
    .label = Κωδικός πρόσβασης

##

# "More" item in macOS share menu
menu-share-more =
    .label = Περισσότερα…
menu-share-windows =
    .label = Περισσότερες επιλογές
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Αντιγραφή συνδέσμου
           *[other] Αντιγραφή { $count } συνδέσμων
        }
    .accesskey = σ
ui-tour-info-panel-close =
    .tooltiptext = Κλείσιμο

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Αποδοχή αναδυόμενων παραθύρων και ανακατευθύνσεων τρίτων για το { $uriHost }
    .accesskey = χ

##

picture-in-picture-hide-toggle =
    .label = Απόκρυψη διακόπτη «Εικόνα εντός εικόνας»
    .accesskey = Α

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Μετακίνηση διακόπτη «Εικόνα εντός εικόνας» στα δεξιά
    .accesskey = ε
picture-in-picture-move-toggle-left =
    .label = Μετακίνηση διακόπτη «Εικόνα εντός εικόνας» στα αριστερά
    .accesskey = α

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Πλοήγηση
navbar-downloads =
    .label = Λήψεις
navbar-overflow-2 =
    .tooltiptext = Περισσότερα εργαλεία
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Εκτύπωση
    .tooltiptext = Εκτύπωση σελίδας… ({ $shortcut })
navbar-home =
    .label = Αρχική σελίδα
    .tooltiptext = Αρχική σελίδα του { -brand-short-name }
navbar-library =
    .label = Βιβλιοθήκη
    .tooltiptext = Προβολή ιστορικού, σελιδοδεικτών και πολλών άλλων
navbar-search =
    .title = Αναζήτηση
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Καρτέλες προγράμματος περιήγησης
tabs-toolbar-new-tab =
    .label = Νέα καρτέλα
tabs-toolbar-list-all-tabs-2 =
    .label = Αναζήτηση και διαχείριση καρτελών
    .tooltiptext = Αναζήτηση και διαχείριση καρτελών
tabs-toolbar-list-all-tabs =
    .label = Παράθεση όλων των καρτελών
    .tooltiptext = Παράθεση όλων των καρτελών

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Αποθέστε εδώ την καρτέλα για καρφίτσωμα

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Άνοιγμα προηγούμενων καρτελών;</strong> Μπορείτε να ανακτήσετε την προηγούμενη συνεδρία σας από την ενότητα «Ιστορικό» του μενού εφαρμογής <img data-l10n-name="icon"/> του { -brand-short-name }.
restore-session-startup-suggestion-button = Εμφάνιση οδηγιών

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Ο οργανισμός σας έχει αποκλείσει την πρόσβαση στα τοπικά αρχεία αυτού του υπολογιστή

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = Η συντόμευση { $searchTabsShortcut } κάνει πλέον αναζήτηση στις καρτέλες
urlbar-addons-shortcut-moved-description = Για να ανοίξετε τις επεκτάσεις και τα θέματα, πατήστε { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Διαχείριση συντομεύσεων
urlbar-addons-shortcut-moved-dismiss = Το κατάλαβα

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = Το { -brand-short-name } στέλνει αυτόματα μερικά δεδομένα στη { -vendor-short-name }, έτσι ώστε να μπορέσουμε να βελτιώσουμε την εμπειρία σας.
data-reporting-notification-button =
    .label = Επιλέξτε τι θα μοιράζεστε
    .accesskey = ξ
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Ιδιωτική περιήγηση
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Ιδιωτική περιήγηση
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Πληροφορίες ιδιωτικής περιήγησης
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Βρίσκεστε σε ένα ιδιωτικό παράθυρο
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Αυτό διατηρεί την περιήγησή σας κρυφή από άλλους χρήστες αυτής της συσκευής, αλλά δεν σας καθιστά αόρατους στο διαδίκτυο. <a data-l10n-name="learn-more">Ποιος μπορεί δυνητικά να δει τη δραστηριότητά μου;</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Πρόληψη απώλειας δεδομένων (DLP) του { $agentName }. Κάντε κλικ για περισσότερες πληροφορίες.
content-analysis-panel-title2 = Αποτροπή απώλειας δεδομένων
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Ο οργανισμός σας χρησιμοποιεί το <b>{ $agentName }</b> για να ελέγχει τον τρόπο με τον οποίο μπορούν να κοινοποιούνται ευαίσθητα δεδομένα. <a data-l10n-name="info">Μάθετε περισσότερα</a>
content-analysis-panel-title = Προστασία δεδομένων
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Ο οργανισμός σας χρησιμοποιεί το <b>{ $agentName }</b> για προστασία από απώλεια δεδομένων. <a data-l10n-name="info">Μάθετε περισσότερα</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Επεκτάσεις
    .tooltiptext = Επεκτάσεις

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Επεκτάσεις
    .tooltiptext =
        Επεκτάσεις
        Απαιτούνται άδειες

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Επεκτάσεις
    .tooltiptext =
        Επεκτάσεις
        Ορισμένες επεκτάσεις δεν επιτρέπονται

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Επεκτάσεις
    .tooltiptext =
        Επεκτάσεις
        Ορισμένες επεκτάσεις είναι απενεργοποιημένες

## Private browsing reset button

reset-pbm-panel-heading2 = Απαλοιφή δεδομένων και έναρξη νέας ιδιωτικής συνεδρίας;
reset-pbm-panel-description3 = Διαγράφει το ιστορικό και τα cookie σας και σας αποσυνδέει από τους ιστοτόπους. Τα ιδιωτικά παράθυρά σας θα κλείσουν και θα ανοίξει ένα νέο.
reset-pbm-panel-description2 = Αυτό διαγράφει το ιστορικό, τα cookie και όλα τα άλλα δεδομένα ιστοτόπων χωρίς να κλείσει το ιδιωτικό σας παράθυρο.
reset-pbm-panel-always-ask-checkbox =
    .label = Ερώτηση πάντα
    .accesskey = Ε
reset-pbm-panel-cancel-button =
    .label = Ακύρωση
    .accesskey = Α
reset-pbm-panel-confirm-button2 =
    .label = Απαλοιφή ιδιωτικής συνεδρίας
    .accesskey = λ
reset-pbm-panel-complete = Τα δεδομένα της ιδιωτικής συνεδρίας διαγράφηκαν
reset-pbm-toolbar-button2 =
    .label = Απαλοιφή ιδιωτικής συνεδρίας
    .tooltiptext = Απαλοιφή ιδιωτικής συνεδρίας

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Διαγραφή όλων των δεδομένων περιήγησης;
fire-button-panel-description = Αυτή η ενέργεια διαγράφει το ιστορικό, τα cookie και τα δεδομένα ιστοτόπων. Θα αποσυνδεθείτε από τους ιστοτόπους. Αυτό το παράθυρο θα κλείσει και το { -brand-short-name } θα ανοίξει ένα νέο.
fire-button-panel-choose-description = Εάν δεν θέλετε να διαγράψετε τα πάντα, επιλέξτε συγκεκριμένα δεδομένα.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Επιλογή…
fire-button-panel-cancel-button =
    .label = Ακύρωση
    .accesskey = Α
fire-button-panel-confirm-button =
    .label = Διαγραφή όλων
    .accesskey = Δ
fire-button-panel-complete = Τα δεδομένα περιήγησης διαγράφηκαν
fire-button-toolbar-button2 =
    .label = Διαγράψτε μερικά ή όλα τα δεδομένα
    .tooltiptext = Διαγράψτε μερικά ή όλα τα δεδομένα περιήγησής σας

## Autorefresh blocker

refresh-blocked-refresh-label = Το { -brand-short-name } εμπόδισε την αυτόματη ανανέωση της σελίδας.
refresh-blocked-redirect-label = Το { -brand-short-name } εμπόδισε την αυτόματη ανακατεύθυνση της σελίδας σε μια άλλη σελίδα.
refresh-blocked-allow =
    .label = Αποδοχή
    .accesskey = Α

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Οι ασφαλείς και εύχρηστες μάσκες μας, προστατεύουν την ταυτότητά σας και αποτρέπουν τα ανεπιθύμητα μηνύματα κρύβοντας τη διεύθυνση email σας.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Όλα τα email που αποστέλλονται στις μάσκες email σας θα προωθούνται στο <strong>{ $useremail }</strong> (εκτός εάν αποφασίσετε να τα αποκλείσετε).
firefox-relay-offer-legal-notice = Κάνοντας κλικ στο «Χρήση μάσκας email», αποδέχεστε τους <label data-l10n-name="tos-url">Όρους παροχής υπηρεσιών</label> και τη <label data-l10n-name="privacy-url">Δήλωση απορρήτου </label>.
firefox-relay-offer-legal-notice-1 = Κάνοντας εγγραφή και δημιουργία μιας μάσκας email, αποδέχεστε τους <label data-l10n-name="tos-url">Όρους παροχής υπηρεσιών</label> και τη <label data-l10n-name="privacy-url">Δήλωση απορρήτου</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Μη επαληθευμένο)
popup-notification-xpinstall-prompt-learn-more = Μάθετε περισσότερα σχετικά με την ασφαλή εγκατάσταση πρόσθετων
popup-notification-xpinstall-prompt-block-url = Προβολή λεπτομερειών
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Να επιτρέπεται η εκτέλεση της επέκτασης σε ιδιωτικά παράθυρα
    .accesskey = π
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Κοινοποίηση τεχνικών δεδομένων και δεδομένων αλληλεπίδρασης με τον προγραμματιστή της επέκτασης
    .accesskey = Κ

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] Το { -brand-short-name } εμπόδισε το άνοιγμα ενός αναδυόμενου παραθύρου στον ιστότοπο.
       *[other] Το { -brand-short-name } εμπόδισε το άνοιγμα { $popupCount } αναδυόμενων παραθύρων στον ιστότοπο.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] Το { -brand-short-name } εμπόδισε την ανακατεύθυνση από αυτόν τον ιστότοπο.
        [1] Το { -brand-short-name } εμπόδισε το άνοιγμα ενός αναδυόμενου παραθύρου και την ανακατεύθυνση από αυτόν τον ιστότοπο.
       *[other] Το { -brand-short-name } εμπόδισε το άνοιγμα { $popupCount } αναδυόμενων παραθύρων και την ανακατεύθυνση από αυτόν τον ιστότοπο.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = Το { -brand-short-name } εμπόδισε το άνοιγμα περισσότερων από { $popupCount } αναδυόμενων παραθύρων στον ιστότοπο.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
       *[other] Το { -brand-short-name } εμπόδισε το άνοιγμα περισσότερων από { $popupCount } αναδυόμενων παραθύρων και την ανακατεύθυνση από αυτόν τον ιστότοπο.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Επιλογές
           *[other] Προτιμήσεις
        }
    .accesskey =
        { PLATFORM() ->
            [windows] Ε
           *[other] Π
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Εμφάνιση του «{ $popupURI }»
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Εμφάνιση του «{ $redirectURI }»

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Δεν ήταν δυνατό το άνοιγμα του παραθύρου διαλόγου αρχείων των Windows. Δεν ήταν δυνατή η επιλογή αρχείου ή φακέλου.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Δεν ήταν δυνατό το άνοιγμα του παραθύρου διαλόγου αρχείων των Windows. Το αρχείο θα αποθηκευτεί στο { $path }.
file-picker-failed-save-nowhere = Δεν ήταν δυνατό το άνοιγμα του παραθύρου διαλόγου αρχείων των Windows. Δεν ήταν δυνατή η εύρεση προεπιλεγμένου φακέλου· το αρχείο δεν θα αποθηκευτεί.
file-picker-crashed-open = Το παράθυρο διαλόγου αρχείων των Windows κατέρρευσε. Δεν ήταν δυνατή η επιλογή αρχείου ή φακέλου.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Το παράθυρο διαλόγου αρχείων των Windows κατέρρευσε. Το αρχείο θα αποθηκευτεί στο { $path }.
file-picker-crashed-save-nowhere = Το παράθυρο διαλόγου αρχείων των Windows κατέρρευσε. Δεν ήταν δυνατή η εύρεση προεπιλεγμένου φακέλου· το αρχείο δεν θα αποθηκευτεί.
file-picker-crashed-show-in-folder =
    .label = Εμφάνιση στον φάκελο
    .accessKey = φ

## Unsigned add-ons notification

unsigned-addons-disabled-message = Ένα ή περισσότερα εγκατεστημένα πρόσθετα δεν μπορούν να επαληθευτούν και έχουν απενεργοποιηθεί.
unsigned-addons-disabled-learn-more =
    .label = Μάθετε περισσότερα
    .accesskey = Μ

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Αυτή η σελίδα επιβραδύνει το { -brand-short-name }. Για να επιταχύνετε το πρόγραμμα περιήγησής σας, τερματίστε τη.
process-hang-nonspecific-tab-message = Μια ιστοσελίδα επιβραδύνει το { -brand-short-name }. Για να επιταχύνετε το πρόγραμμα περιήγησής σας, τερματίστε τη.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = Το «{ $title }» επιβραδύνει το { -brand-short-name }. Για να επιταχύνετε το πρόγραμμα περιήγησής σας, τερματίστε αυτήν τη σελίδα.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = Το «{ $addonName }» επιβραδύνει το { -brand-short-name }. Για να επιταχύνετε το πρόγραμμα περιήγησής σας, τερματίστε αυτήν την επέκταση.
process-hang-addon-learn-more =
    .value = Μάθετε περισσότερα
process-hang-stop-button =
    .label = Διακοπή
    .accesskey = Δ

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Ολοκλήρωση ρύθμισης
onboarding-aw-finish-setup-button =
    .label = Ολοκλήρωση ρύθμισης
    .tooltiptext = Ολοκλήρωση της ρύθμισης του { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Η Ενισχυμένη προστασία από καταγραφή είναι ενεργή
trustpanel-etp-label-disabled = Η Ενισχυμένη προστασία από καταγραφή είναι ανενεργή
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Ενισχυμένη προστασία από καταγραφή: ενεργή στο { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Ενισχυμένη προστασία από καταγραφή: ανενεργή στο { $host }
trustpanel-etp-description-enabled = Εάν κάτι δεν λειτουργεί σωστά σε αυτόν τον ιστότοπο, δοκιμάστε να απενεργοποιήσετε την προστασία.
trustpanel-etp-description-disabled = Το { -brand-product-name } θεωρεί ότι οι εταιρείες θα πρέπει να σας ακολουθούν λιγότερο. Αποκλείουμε όσο περισσότερους ιχνηλάτες μπορούμε όταν ενεργοποιείτε την προστασία.
trustpanel-trackercount-label = Εμφάνιση αποκλεισμένων ιχνηλατών στη γραμμή διευθύνσεων
trustpanel-trackercount-toggle =
    .aria-label = Εμφάνιση αποκλεισμένων ιχνηλατών στη γραμμή διευθύνσεων
trustpanel-connection-label-secure = Ασφαλής σύνδεση
trustpanel-connection-label-insecure = Μη ασφαλής σύνδεση
trustpanel-header-enabled = Το { -brand-product-name } είναι σε επιφυλακή
trustpanel-description-enabled2 = Προστατεύεστε. Αν εντοπίσουμε κάτι, θα σας ενημερώσουμε.
trustpanel-header-enabled-insecure = Να προσέχετε σε αυτόν τον ιστότοπο
trustpanel-description-enabled-insecure = Το { -brand-product-name } παρατήρησε κάτι ύποπτο.
trustpanel-header-disabled = Απενεργοποιήσατε την προστασία
trustpanel-description-disabled = Το { -brand-product-name } είναι εκτός υπηρεσίας. Προτείνουμε να ενεργοποιήσετε ξανά την προστασία.
trustpanel-clear-cookies-button = Απαλοιφή cookie και δεδομένων ιστοτόπου
trustpanel-privacy-link = Ρυθμίσεις απορρήτου
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Απαλοιφή cookie και δεδομένων ιστοτόπου για το { $host }
trustpanel-clear-cookies-description = Η διαγραφή των cookie και των δεδομένων ιστοτόπων ενδέχεται να σας αποσυνδέσει από ιστοτόπους και να αδειάσει τα καλάθια αγορών.
trustpanel-clear-cookies-subview-button-clear = Απαλοιφή
trustpanel-clear-cookies-subview-button-cancel = Ακύρωση
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Προστασία σύνδεσης για το { $host }
trustpanel-siteinformation-morelink = Περισσότερες πληροφορίες ιστοτόπου
trustpanel-blocker-see-all = Προβολή όλων
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Προστασία από καταγραφή για το { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Μη ασφαλής
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } αποκλεισμένος ιχνηλάτης
       *[other] { $count } αποκλεισμένοι ιχνηλάτες
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = Το { -brand-product-name } θεωρεί ότι οι εταιρείες πρέπει να σας ακολουθούν λιγότερο. Αποκλείουμε λοιπόν όσους περισσότερους μπορούμε.
trustpanel-blocked-header = Το { -brand-product-name } απέκλεισε τα παρακάτω στοιχεία για εσάς:
trustpanel-tracking-header = Το { -brand-product-name } επέτρεψε τα παρακάτω στοιχεία για την εύρυθμη λειτουργία των ιστοτόπων:
trustpanel-tracking-description = Χωρίς τους ιχνηλάτες, ορισμένα κουμπιά, φόρμες και πεδία σύνδεσης ενδέχεται να μην λειτουργούν.
trustpanel-insecure-section-header = Η σύνδεσή σας δεν είναι ασφαλής
trustpanel-insecure-description = Τα δεδομένα που στέλνετε σε αυτόν τον ιστότοπο δεν είναι κρυπτογραφημένα. Μπορούν να προβληθούν, να υποκλαπούν ή να αλλοιωθούν.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } cookie καταγραφής μεταξύ ιστοτόπων
       *[other] { $count } cookie καταγραφής μεταξύ ιστοτόπων
    }
trustpanel-list-label-tracking-content = Περιεχόμενο καταγραφής
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } fingerprinter
       *[other] { $count } fingerprinter
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } ιχνηλάτης κοινωνικών δικτύων
       *[other] { $count } ιχνηλάτες κοινωνικών δικτύων
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } cryptominer
       *[other] { $count } cryptominer
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } απέκλεισε { $count } ιχνηλάτη κοινωνικών δικτύων
       *[other] Το { -brand-product-name } απέκλεισε { $count } ιχνηλάτες κοινωνικών δικτύων
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } επέτρεψε { $count } ιχνηλάτη κοινωνικών δικτύων
       *[other] Το { -brand-product-name } επέτρεψε { $count } ιχνηλάτες κοινωνικών δικτύων
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } απέκλεισε { $count } cookie καταγραφής μεταξύ ιστοτόπων
       *[other] Το { -brand-product-name } απέκλεισε { $count } cookie καταγραφής μεταξύ ιστοτόπων
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } επέτρεψε { $count } cookie καταγραφής μεταξύ ιστοτόπων
       *[other] Το { -brand-product-name } επέτρεψε { $count } cookie καταγραφής μεταξύ ιστοτόπων
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } απέκλεισε { $count } ιχνηλάτη
       *[other] Το { -brand-product-name } απέκλεισε { $count } ιχνηλάτες
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } επέτρεψε { $count } ιχνηλάτη
       *[other] Το { -brand-product-name } επέτρεψε { $count } ιχνηλάτες
    }
trustpanel-tracking-content-tab-list-header = Αυτοί οι ιστότοποι προσπαθούν να σας καταγράψουν:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } απέκλεισε { $count } fingerprinter
       *[other] Το { -brand-product-name } απέκλεισε { $count } fingerprinter
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } επέτρεψε { $count } fingerprinter
       *[other] Το { -brand-product-name } επέτρεψε { $count } fingerprinter
    }
trustpanel-fingerprinter-list-header = Αυτοί οι ιστότοποι προσπαθούν να σας αναλύσουν το ψηφιακό σας αποτύπωμα:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } απέκλεισε { $count } cryptominer
       *[other] Το { -brand-product-name } απέκλεισε { $count } cryptominer
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] Το { -brand-product-name } επέτρεψε { $count } cryptominer
       *[other] Το { -brand-product-name } επέτρεψε { $count } cryptominer
    }
trustpanel-cryptominer-tab-list-header = Αυτοί οι ιστότοποι προσπαθούν να εξορύξουν κρυπτονομίσματα:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Έχετε λογαριασμό σε αυτόν τον ιστότοπο;
trustpanel-breachalerts-anonymous-breached-description = Το { -brand-product-name } διαπίστωσε ότι τα δεδομένα αυτού του ιστοτόπου παραβιάστηκαν εντός των τελευταίων 12 μηνών. Μάθετε αν επηρεαστήκατε.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Απόρριψη
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Έναρξη δωρεάν σάρωσης
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> αποκλεισμένος ιχνηλάτης σε αυτόν τον ιστότοπο
       *[other] <span data-l10n-name="count">{ $count }</span> αποκλεισμένοι ιχνηλάτες σε αυτόν τον ιστότοπο
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Φαίνεται προβληματικός ο ιστότοπος;</strong> Ανανεώστε τη σελίδα για να μειώσετε προσωρινά την προστασία από καταγραφή.
reduced-protection-infobar-reload-button = Ανανέωση
    .accesskey = Α
reduced-protection-infobar-never-show-button = Να μην εμφανιστεί ξανά
    .accesskey = Ν


identity-allow-site-data = vOrbit-lite: Αποηθήκευση cookies/δεδομένων πάντα για αυτή την ιστοσελίδα
