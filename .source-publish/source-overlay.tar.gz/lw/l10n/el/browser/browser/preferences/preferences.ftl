# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Αποστολή αιτήματος μη πώλησης ή κοινοποίησης δεδομένων στους ιστοτόπους
    .accesskey = σ
non-technical-privacy-group =
    .label = Προτιμήσεις απορρήτου ιστοτόπων
do-not-track-removal3 =
    .message = Δεν υποστηρίζουμε πλέον τη λειτουργία «Αποτροπή καταγραφής».
non-technical-privacy-heading =
    .label = Πρόσθετα μέτρα προστασίας
preferences-privacy-relay-available =
    .description = Αποκρύπτει την πραγματική σας διεύθυνση email για την προστασία των εισερχομένων σας από ανεπιθύμητα μηνύματα.
    .label = Πρόταση μασκών email του { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Ρυθμίσεις
category-nav-heading =
    .heading = Ρυθμίσεις
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Εύρεση στις ρυθμίσεις
    .style = width: 15.4em
managed-notice = Το πρόγραμμα περιήγησής σας ρυθμίζεται από τον οργανισμό σας.
managed-notice-info-icon =
    .alt = Πληροφορίες
managed-notice-nav =
    .label = Το πρόγραμμα περιήγησής σας ρυθμίζεται από τον οργανισμό σας.
tls-key-logging-notice-nav =
    .label = Μια εφαρμογή ή υπηρεσία ενδέχεται να βλέπει την κρυπτογραφημένη κίνηση.
category-list =
    .aria-label = Κατηγορίες
pane-general-title = Γενικά
pane-home-title = Αρχική
pane-home-startup-title2 = Αρχική σελίδα και εκκίνηση
    .title = Αρχική σελίδα και εκκίνηση
pane-search-title2 = Αναζήτηση
    .title = Αναζήτηση
pane-privacy-title3 = Απόρρητο και ασφάλεια
    .title = Απόρρητο και ασφάλεια
pane-privacy-section =
    .heading = Απόρρητο και ασφάλεια
pane-sync-title3 = Συγχρονισμός
pane-ai-controls-title2 = Επιλογές ελέγχου ΤΝ
    .title = Επιλογές ελέγχου ΤΝ
pane-about-firefox-title = Σχετικά με το { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Εμφάνιση
    .title = { pane-appearance-title }
pane-downloads-title2 = Λήψεις
    .title = Λήψεις
pane-downloads3 =
    .heading = Λήψεις
pane-accessibility-title = Προσβασιμότητα
    .title = { pane-accessibility-title }
pane-languages-title2 = Γλώσσες
    .title = Γλώσσες
preferences-languages-header3 =
    .heading = Γλώσσες
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Δοκιμάστε τις πειραματικές μας λειτουργίες! Βρίσκονται υπό ανάπτυξη και εξέλιξη, γεγονός που μπορεί να επηρεάσει τον τρόπο λειτουργίας του { -brand-short-name }. Λαμβάνουμε δεδομένα σχετικά με τη χρήση αυτών των λειτουργιών μόνο εφόσον έχετε ενεργοποιήσει τα <a data-l10n-name="data-collection">τεχνικά δεδομένα και τα δεδομένα αλληλεπίδρασης</a>.
pane-experimental-reset =
    .label = Επαναφορά προεπιλογών
    .accesskey = Ε
help-button-label2 = Υποστήριξη { -brand-short-name }
    .title = Υποστήριξη { -brand-short-name }
addons-button-label2 = Επεκτάσεις και θέματα
    .title = Επεκτάσεις και θέματα
focus-search =
    .key = f
close-button =
    .aria-label = Κλείσιμο
do-not-track-removal2 =
    .label = Δεν υποστηρίζουμε πλέον το σήμα «Αποτροπή καταγραφής»
applications-setting-new-file-types =
    .label = Τι να κάνει το { -brand-short-name } με άλλα αρχεία;

## Browser Restart Dialog

feature-enable-requires-restart = Θα πρέπει να γίνει επανεκκίνηση του { -brand-short-name } για ενεργοποίηση αυτής της λειτουργίας.
feature-disable-requires-restart = Θα πρέπει να γίνει επανεκκίνηση του { -brand-short-name } για απενεργοποίηση αυτής της λειτουργίας..
should-restart-title = Επανεκκίνηση του { -brand-short-name }
should-restart-ok = Επανεκκίνηση του { -brand-short-name } τώρα
cancel-no-restart-button = Ακύρωση
restart-later = Επανεκκίνηση αργότερα

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = Αυτή η ρύθμιση ελέγχεται από το πρόσθετο <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = Αυτή η ρύθμιση ελέγχεται από το πρόσθετο <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = Το <img data-l10n-name="icon"/> <strong>{ $name }</strong> απαιτεί θεματικές καρτέλες.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = Αυτή η ρύθμιση ελέγχεται από το πρόσθετο <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = Το <img data-l10n-name="icon"/> <strong>{ $name }</strong> ελέγχει τον τρόπο σύνδεσης του { -brand-short-name } με το διαδίκτυο.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Για να ενεργοποιήσετε την επέκταση, μεταβείτε στα <img data-l10n-name="addons-icon"/> «Πρόσθετα» στο μενού <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Για να ενεργοποιήσετε ξανά αυτήν την επέκταση, επισκεφθείτε τη σελίδα <a data-l10n-name="addons-link">Επεκτάσεις και θέματα</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = Το { $name } ελέγχει ορισμένες από τις ρυθμίσεις της αρχικής σελίδας σας.

## Preferences UI Search Results

search-results-header = Αποτελέσματα αναζήτησης
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Δυστυχώς, δεν υπάρχουν αποτελέσματα για το «<span data-l10n-name="query"></span>» στις ρυθμίσεις.
search-results-help-link = Χρειάζεστε βοήθεια; Επισκεφθείτε την <a data-l10n-name="url">Υποστήριξη { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Να ελέγχεται πάντα εάν το { -brand-short-name } είναι το προεπιλεγμένο πρόγραμμα περιήγησης
    .accesskey = γ
startup-restore-windows-and-tabs =
    .label = Άνοιγμα προηγούμενων παραθύρων και καρτελών
    .accesskey = π
startup-windows-launch-on-login-profile-disabled =
    .message = Ενεργοποιήστε αυτήν την προτίμηση επιλέγοντας «{ profile-manager-use-selected.label }» στο παράθυρο «Επιλογή προφίλ χρήστη».
windows-launch-on-login =
    .label = Άνοιγμα του { -brand-short-name } αυτόματα κατά την εκκίνηση του υπολογιστή
    .accesskey = ν
windows-launch-on-login-disabled = Αυτή η προτίμηση έχει απενεργοποιηθεί στα Windows. Για να την αλλάξετε, επισκεφτείτε τις <a data-l10n-name="startup-link">Εφαρμογές εκκίνησης</a> στις ρυθμίσεις συστήματος.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Επίσης, άνοιγμα νέας καρτέλας
    .accesskey = ν
disable-extension =
    .label = Απενεργοποίηση επέκτασης
preferences-data-migration-group =
    .description = Εισαγάγετε σελιδοδείκτες, κωδικούς πρόσβασης, ιστορικό, πρόσθετα και δεδομένα αυτόματης συμπλήρωσης από άλλο πρόγραμμα περιήγησης.
    .label = Εισαγωγή δεδομένων προγράμματος περιήγησης
preferences-data-migration-button =
    .label = Εισαγωγή δεδομένων
    .accesskey = ι
preferences-profiles-group-header =
    .heading = Προφίλ
preferences-profiles-subpane-description =
    .description = Κάθε προφίλ περιέχει ξεχωριστά δεδομένα και ρυθμίσεις περιήγησης, όπως ιστορικό, κωδικοί πρόσβασης και πολλά άλλα.
preferences-profiles-section-header =
    .description = Κάθε προφίλ περιέχει ξεχωριστά δεδομένα και ρυθμίσεις περιήγησης, όπως ιστορικό, κωδικοί πρόσβασης και πολλά άλλα.
    .label = Προφίλ
preferences-manage-profiles-button =
    .label = Διαχείριση προφίλ
preferences-profiles-settings-button =
    .label = Ρυθμίσεις
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Το νέο προφίλ θα αντιγράψει τις ρυθμίσεις, τα πρόσθετα, το ιστορικό και τα αποθηκευμένα δεδομένα, όπως σελιδοδείκτες και κωδικούς πρόσβασης, όχι όμως τον λογαριασμό ή τις πληροφορίες συγχρονισμού σας.
    .label = Αντιγραφή υπάρχοντος προφίλ
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Προφίλ προς αντιγραφή
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Επιλογή προφίλ
preferences-copy-profile-button = Αντιγραφή
tabs-browsing-section =
    .heading = Καρτέλες και περιήγηση
pane-tabs-browsing-title2 = Καρτέλες και περιήγηση
    .title = Καρτέλες και περιήγηση
tabs-group-header2 =
    .label = Καρτέλες
tabs-opening-heading =
    .label = Άνοιγμα
tabs-interaction-heading =
    .label = Αλληλεπίδραση
tabs-containers-heading =
    .label = Θεματικές ενότητες
tabs-closing-heading =
    .label = Κλείσιμο
ctrl-tab-recently-used-order =
    .label = Εναλλαγή καρτελών με τα Ctrl+Tab σε σειρά πρόσφατης χρήσης
    .accesskey = T
open-new-link-as-tabs =
    .label = Άνοιγμα συνδέσμων σε καρτέλες αντί για νέα παράθυρα
    .accesskey = π
open-external-link-next-to-active-tab =
    .label = Άνοιγμα συνδέσμων από εφαρμογές δίπλα στην ενεργή καρτέλα
ask-on-close-multiple-tabs =
    .label = Ερώτηση πριν από το κλείσιμο πολλαπλών καρτελών
    .accesskey = π
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Ερώτηση πριν από τον τερματισμό με { $quitKey }
    .accesskey = τ
warn-on-open-many-tabs =
    .label = Προειδοποίηση όταν το άνοιγμα πολλαπλών καρτελών ενδέχεται να επιβραδύνει το { -brand-short-name }
    .accesskey = β
switch-to-new-tabs-2 =
    .label = Άμεση εναλλαγή στη νέα καρτέλα όταν ανοίγουν σύνδεσμοι ή πολυμέσα
    .accesskey = η
show-tabs-in-taskbar =
    .label = Προβολή προεπισκόπησης καρτελών στη γραμμή εργασιών των Windows
    .accesskey = ε
browser-containers-enabled-2 =
    .label = Χρήση θεματικών καρτελών
    .accesskey = ν
browser-containers-learn-more = Μάθετε περισσότερα
browser-containers-settings-2 =
    .label = Διαχείριση ρυθμίσεων
    .accesskey = ι
containers-disable-alert-title = Κλείσιμο όλων των θεματικών καρτελών;
startup-group =
    .label = Εκκίνηση

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Αν απενεργοποιήσετε τις θεματικές καρτέλες τώρα, θα κλείσει { $tabCount } θεματική καρτέλα. Θέλετε σίγουρα να απενεργοποιήσετε τις θεματικές καρτέλες;
       *[other] Αν απενεργοποιήσετε τις θεματικές καρτέλες τώρα, θα κλείσουν { $tabCount } θεματικές καρτέλες. Θέλετε σίγουρα να απενεργοποιήσετε τις θεματικές καρτέλες;
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Κλείσιμο { $tabCount } θεματικής καρτέλας
       *[other] Κλείσιμο { $tabCount } θεματικών καρτελών
    }

##

containers-disable-alert-cancel-button = Να παραμείνουν ενεργές
containers-remove-alert-title = Αφαίρεση θεματικής καρτέλας;
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Αν αφαιρέσετε αυτήν τη θεματική ενότητα τώρα, θα κλείσει { $count } θεματική καρτέλα. Θέλετε σίγουρα να αφαιρέσετε αυτήν τη θεματική ενότητα;
       *[other] Αν αφαιρέσετε αυτήν τη θεματική ενότητα τώρα, θα κλείσουν { $count } θεματικές καρτέλες. Θέλετε σίγουρα να αφαιρέσετε αυτήν τη θεματική ενότητα;
    }
containers-remove-ok-button = Αφαίρεση θεματικής ενότητας
containers-remove-cancel-button = Διατήρηση θεματικής ενότητας
settings-tabs-show-image-in-preview =
    .label = Εμφάνιση εικόνας προεπισκόπησης όταν τοποθετείτε τον δείκτη του ποντικιού σε μια καρτέλα
    .accessKey = μ
settings-tabs-drag-to-create-tab-groups =
    .label = Σύρετε τις καρτέλες μαζί για να δημιουργήσετε ομάδες
browser-layout-header2 =
    .label = Διάταξη προγράμματος περιήγησης
browser-layout-horizontal-tabs2 =
    .description = Καρτέλες στο πάνω μέρος
    .label = Οριζόντιες καρτέλες
    .title = Καρτέλες στο πάνω μέρος
browser-layout-vertical-tabs2 =
    .description = Καρτέλες στο πλάι, στην πλαϊνή γραμμή
    .label = Κάθετες καρτέλες
    .title = Καρτέλες στο πλάι, στην πλαϊνή γραμμή
browser-layout-show-sidebar2 =
    .description = Αποκτήστε γρήγορη πρόσβαση σε σελιδοδείκτες, καρτέλες από το τηλέφωνό σας, chatbot ΤΝ και πολλά άλλα χωρίς να αποχωρήσετε από την κύρια προβολή.
    .label = Εμφάνιση πλαϊνής γραμμής
page-navigation-group =
    .label = Πλοήγηση στις σελίδες

## General Section - Language & Appearance

language-and-appearance-header = Γλώσσα και εμφάνιση
appearance-group2 =
    .description = Ορισμένοι ιστότοποι αλλάζουν τα χρώματά τους ανάλογα με τις προτιμήσεις σας. Επιλέξτε το σύνολο χρωμάτων σας.
    .label = Εμφάνιση ιστοτόπων
preferences-web-appearance-choice-auto3 =
    .label = Σύστημα
    .title = Αυτόματη αλλαγή του φόντου και του περιεχομένου των ιστοτόπων με βάση τις ρυθμίσεις του συστήματός σας και το θέμα του { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Ανοιχτόχρωμο
    .title = Χρήση ανοιχτόχρωμης εμφάνισης για φόντο και περιεχόμενο ιστοτόπων.
preferences-web-appearance-choice-dark2 =
    .label = Σκουρόχρωμο
    .title = Χρήση σκουρόχρωμης εμφάνισης για φόντο και περιεχόμενο ιστοτόπων.
web-appearance-group =
    .aria-label = Εμφάνιση ιστοτόπων
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Οι ρυθμίσεις σας για τον έλεγχο αντίθεσης υπερισχύουν της εμφάνισης του ιστοτόπου.
preferences-web-appearance-link =
    .label = Διαχείριση των θεμάτων του { -brand-short-name } στην ενότητα «Επεκτάσεις και θέματα»
preferences-contrast-control-group =
    .description = Οι ιστότοποι χρησιμοποιούν μια ποικιλία χρωμάτων προσκηνίου και παρασκηνίου. Για τη συνέπεια των ρυθμίσεων αντίθεσης, μπορείτε να χρησιμοποιήσετε τα ίδια χρώματα σε όλους τους ιστοτόπους.
    .label = Αντίθεση ιστοτόπων
preferences-contrast-control-radio-group =
    .label = Παράκαμψη χρωμάτων
preferences-contrast-control-use-platform-settings =
    .label = Αυτόματα (χρήση ρυθμίσεων συστήματος)
    .accesskey = Α
preferences-contrast-control-off =
    .label = Ανενεργή
    .accesskey = ν
preferences-contrast-control-custom =
    .label = Προσαρμοσμένη
    .accesskey = Π
preferences-colors-manage-button2 =
    .label = Διαχείριση χρωμάτων
    .accesskey = ω
preferences-colors-manage-button =
    .label = Διαχείριση χρωμάτων…
    .accesskey = ω
preferences-fonts-header2 =
    .label = Γραμματοσειρές
preferences-default-zoom-label =
    .label = Προεπιλεγμένο ζουμ
    .accesskey = ζ
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Ζουμ μόνο στο κείμενο
    .accesskey = κ
preferences-text-zoom-override-warning2 =
    .message = Εάν είναι ενεργή η επιλογή «Ζουμ μόνο στο κείμενο» και το προεπιλεγμένο ζουμ δεν είναι 100%, ορισμένοι ιστότοποι ενδέχεται να μην εμφανίζουν σωστά το περιεχόμενό τους.
language-header = Γλώσσα
choose-language-description = Επιλέξτε την προτιμώμενη γλώσσα για την εμφάνιση σελίδων
website-language-heading =
    .description = Ορισμένες ιστοσελίδες προβάλλονται σε πολλαπλές γλώσσες. Επιλέξτε γλώσσες με τη σειρά προτίμησής σας.
    .label = Γλώσσα ιστοτόπων
website-preferred-language =
    .label = Προτιμώμενες γλώσσες
website-language-list =
    .aria-label = Προτιμώμενες γλώσσες
website-add-language =
    .label = Προσθήκη γλώσσας
website-add-language-button =
    .aria-label = Προσθήκη επιλεγμένης γλώσσας
    .title = Προσθήκη επιλεγμένης γλώσσας
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Αφαίρεση της γλώσσας «{ $locale }»
    .title = Αφαίρεση της γλώσσας «{ $locale }»
choose-button =
    .label = Επιλογή…
    .accesskey = λ
choose-browser-language-description = Επιλέξτε τις γλώσσες εμφάνισης μενού, μηνυμάτων και ειδοποιήσεων από το { -brand-short-name }.
manage-browser-languages-button =
    .label = Ορισμός εναλλακτικών…
    .accesskey = ν
confirm-browser-language-change-description = Επανεκκίνηση του { -brand-short-name } για εφαρμογή αλλαγών
confirm-browser-language-change-button = Εφαρμογή και επανεκκίνηση
browser-language-heading =
    .description = Επιλέξτε τη γλώσσα που χρησιμοποιείται για την εμφάνιση των μενού, μηνυμάτων και ειδοποιήσεων από το { -brand-short-name }.
    .label = Γλώσσα προγράμματος περιήγησης
browser-language-preferred-label =
    .label = Προτιμώμενη γλώσσα
browser-language-fallback-label =
    .description = Χρησιμοποιείται όταν η μετάφραση στην προτιμώμενη γλώσσα δεν είναι ολοκληρωμένη.
    .label = Εφεδρική γλώσσα
browser-language-install-error =
    .message = Το { -brand-short-name } δεν μπορεί να ενημερώσει τις γλώσσες σας αυτήν τη στιγμή. Ελέγξτε αν έχετε συνδεθεί στο διαδίκτυο ή δοκιμάστε ξανά.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Εξαιρέσεις…
    .accesskey = ξ
settings-translations-header =
    .aria-label = Μεταφράσεις
    .description = Μετάφραση σελίδων ή επιλεγμένου κειμένου. Για την προστασία του απορρήτου σας, οι μεταφράσεις παραμένουν στη συσκευή σας.
    .label = Μεταφράσεις
settings-translations-offer-to-translate-label =
    .label = Προσφορά ολοσέλιδης μετάφρασης
settings-translations-more-settings-button =
    .description = Καθορίστε προτιμήσεις για γλώσσες, ιστοτόπους και μετάφραση εκτός σύνδεσης.
    .label = Περισσότερες ρυθμίσεις μετάφρασης
settings-translations-subpage-header =
    .heading = Περισσότερες ρυθμίσεις μετάφρασης
settings-translations-subpage-speed-up-translation-header =
    .description = Κάντε λήψη ολόκληρων γλωσσών για ταχύτερες μεταφράσεις και μετάφραση εκτός σύνδεσης.
    .label = Επιτάχυνση μετάφρασης
settings-translations-subpage-automatic-translation-header =
    .label = Αυτόματη μετάφραση
settings-translations-subpage-always-translate-header =
    .label = Να μεταφράζονται πάντα αυτές οι γλώσσες
settings-translations-subpage-never-translate-header =
    .label = Να μην μεταφράζονται ποτέ αυτές οι γλώσσες
settings-translations-subpage-never-translate-sites-header =
    .label = Να μην μεταφράζονται ποτέ αυτοί οι ιστότοποι
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Για να προσθέσετε έναν ιστότοπο, ανοίξτε τον <img data-l10n-name="translations-icon"/> πίνακα μεταφράσεων, επιλέξτε τις <img data-l10n-name="settings-icon"/> ρυθμίσεις μετάφρασης και επιλέξτε «Να μην μεταφράζεται ποτέ αυτός ο ιστότοπος»
settings-translations-subpage-language-select-option =
    .label = Προσθήκη γλώσσας
settings-translations-subpage-language-add-button =
    .aria-label = Προσθήκη γλώσσας
    .title = Προσθήκη γλώσσας
settings-translations-subpage-download-languages-header =
    .label = Λήψη γλωσσών
settings-translations-subpage-download-languages-select-option =
    .label = Επιλογή γλώσσας
settings-translations-subpage-download-languages-button =
    .aria-label = Λήψη γλώσσας
    .title = Λήψη γλώσσας
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Δεν έχει γίνει λήψη γλωσσών
settings-translations-subpage-no-languages-added =
    .label = Δεν έχουν προστεθεί γλώσσες
settings-translations-subpage-download-progress = Λήψη σε εξέλιξη…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Δεν ήταν δυνατή η λήψη της γλώσσας «{ $language }» ({ $size }MB)
settings-translations-subpage-download-retry-button =
    .label = Δοκιμή ξανά
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Διαγραφή της γλώσσας «{ $language }» ({ $size }MB);
settings-translations-subpage-download-delete-button =
    .label = Διαγραφή
settings-translations-subpage-download-cancel-button =
    .label = Ακύρωση
settings-translations-subpage-no-sites-added =
    .label = Δεν έχουν προστεθεί ιστότοποι
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Χρήση ρυθμίσεων λειτουργικού συστήματος για τα «{ $localeName }» για μορφοποίηση ημερομηνίας, ώρας, αριθμών και μετρήσεων.
settings-spellcheck-header =
    .label = Ορθογραφικός έλεγχος
check-user-spelling =
    .label = Έλεγχος ορθογραφίας κατά την πληκτρολόγηση
    .accesskey = π
spellcheck-download-dictionaries =
    .label = Λήψη λεξικών
spellcheck-promo =
    .heading = Οδηγίες χρήσης του ορθογραφικού ελέγχου
    .message = Κάντε δεξί κλικ σε ένα πεδίο κειμένου για να (απ)ενεργοποιήσετε τον ορθογραφικό έλεγχο ή να αλλάξετε τη γλώσσα. Ο ορθογραφικός έλεγχος δεν υποστηρίζεται σε όλα τα πεδία.

## Downloads - Files and applications

files-and-applications-title = Αρχεία και εφαρμογές
download-save-files-header =
    .label = Αποθήκευση αρχείων σε
download-save-where-3 =
    .aria-label = Αποθήκευση αρχείων σε
download-always-ask-where2 =
    .label = Ερώτηση για την τοποθεσία αποθήκευσης αρχείων πριν από τη λήψη
    .accesskey = α
download-private-browsing-delete2 =
    .label = Διαγραφή των λήψεων από ιδιωτικά παράθυρα κατά το κλείσιμο
    .accesskey = Δ
applications-header = Εφαρμογές
applications-description = Επιλέξτε πώς θα χειρίζεται το { -brand-short-name } τα αρχεία λήψης από το διαδίκτυο ή τις εφαρμογές που χρησιμοποιείτε κατά την περιήγηση.
applications-setting2 =
    .description = Επιλέξτε πώς θα χειρίζεται το { -brand-short-name } τα αρχεία και το περιεχόμενο λήψης.
    .label = Αρχεία και εφαρμογές
applications-filter =
    .placeholder = Αναζήτηση τύπων αρχείων ή εφαρμογών
applications-type-column =
    .label = Τύπος περιεχομένου
    .accesskey = Τ
applications-type-heading = Τύπος περιεχομένου
applications-action-column =
    .label = Ενέργεια
    .accesskey = Ε
applications-action-heading = Ενέργεια
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = Αρχείο { $extension }
applications-action-save =
    .label = Αποθήκευση αρχείου
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Χρήση { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Χρήση «{ $app-name }» (προεπιλογή)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Χρήση προεπιλεγμένης εφαρμογής macOS
            [windows] Χρήση προεπιλεγμένης εφαρμογής Windows
           *[other] Χρήση προεπιλεγμένης εφαρμογής συστήματος
        }
applications-use-other =
    .label = Χρήση άλλου…
applications-select-helper = Επιλογή βοηθητικής εφαρμογής
applications-manage-app =
    .label = Λεπτομέρειες εφαρμογής…
applications-always-ask =
    .label = Ερώτηση πάντα
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Άνοιγμα στο { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Τι να κάνει το { -brand-short-name } με άλλα αρχεία;
applications-save-for-new-types =
    .label = Αποθήκευση αρχείων
    .accesskey = Α
applications-save-for-new-types2 =
    .label = Αυτόματη αποθήκευση αρχείων
    .accesskey = σ
applications-ask-before-handling =
    .label = Ερώτηση για το εάν θα γίνεται άνοιγμα ή αποθήκευση των αρχείων
    .accesskey = Ε
applications-ask-before-handling2 =
    .label = Ερώτηση για άνοιγμα ή αποθήκευση των αρχείων
    .accesskey = α
drm-group =
    .label = Περιεχόμενο διαχείρισης ψηφιακών δικαιωμάτων (DRM)
play-drm-content =
    .label = Αναπαραγωγή περιεχομένου με έλεγχο DRM
    .accesskey = Α
play-drm-content-learn-more = Μάθετε περισσότερα
# Variables:
# $version (string) - Firefox version
update-application-version = Έκδοση { $version } <a data-l10n-name="learn-more">Τι νέο υπάρχει</a>
update-history-2 =
    .label = Εμφάνιση ιστορικού ενημερώσεων
    .accesskey = ν
update-application-installation =
    .label = Εγκατάσταση
update-application-radio-group =
    .aria-label = Εγκατάσταση
update-application-auto-2 =
    .label = Αυτόματη εγκατάσταση ενημερώσεων (προτείνεται)
    .accesskey = Α
update-application-check-choose-2 =
    .label = Έλεγχος για ενημερώσεις, αλλά επιλογή για το πότε θα γίνει εγκατάσταση
    .accesskey = γ
update-application-background-enabled =
    .label = Όταν δεν εκτελείται το { -brand-short-name }
    .accesskey = Ό
update-application-warning-cross-user-setting-2 =
    .message = Αυτή η ρύθμιση θα εφαρμοστεί σε όλους τους λογαριασμούς των Windows και τα προφίλ του { -brand-short-name } που χρησιμοποιούν αυτήν την εγκατάσταση του { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Εμφάνιση λιγότερων υπενθυμίσεων για ενημερώσεις
    .accesskey = ν
update-setting-write-failure-title2 = Σφάλμα αποθήκευσης ρυθμίσεων ενημερώσεων
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    Το { -brand-short-name } αντιμετώπισε σφάλμα και δεν αποθήκευσε αυτήν την αλλαγή. Σημειώστε ότι η αλλαγή αυτής της επιλογής ενημερώσεων απαιτεί δικαίωμα εγγραφής στο παρακάτω αρχείο. Εσείς ή κάποιος διαχειριστής συστήματος ενδέχεται να μπορέσει να επιλύσει το σφάλμα, χορηγώντας στην ομάδα «Χρήστες» τον πλήρη έλεγχο για αυτό το αρχείο.
    
    Δεν ήταν δυνατή η εγγραφή στο αρχείο: { $path }
update-in-progress-title = Ενημέρωση σε εξέλιξη
update-in-progress-message = Θέλετε το { -brand-short-name } να συνεχίσει με αυτήν την ενημέρωση;
update-in-progress-ok-button = &Απόρριψη
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Συνέχεια

## About Firefox

about-firefox-header =
    .heading = Σχετικά με το { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Οι ενημερώσεις βελτιώνουν την ταχύτητα, τη σταθερότητα και την ασφάλεια του { -brand-short-name }.
    .label = Ενημερώσεις του { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Ειδοποιήσεις
update-application-updates-managed-by-os =
    .message = Η διαχείριση των ενημερώσεων γίνεται από το λειτουργικό σας σύστημα

## Firefox support

support-application-heading =
    .description = Επιλύστε ζητήματα ή μοιραστείτε ιδέες με την κοινότητα.
    .label = Υποστήριξη { -brand-short-name }
support-get-help =
    .label = Λήψη βοήθειας
support-share-ideas =
    .label = Κοινοποίηση ιδεών και σχολίων

## Firefox newsletter

newsletter-settings-heading =
    .description = Λάβετε οδηγίες χρήσης, συμβουλές και ειδήσεις για να έχετε την καλύτερη δυνατή εμπειρία με το { -brand-product-name }.
    .label = Ενημερωτικό δελτίο του { -brand-product-name }
newsletter-sign-up-link =
    .label = Εγγραφή

## General Section - Performance

performance-settings-learn-more = Μάθετε περισσότερα
performance-allow-hw-accel =
    .label = Χρήση επιτάχυνσης υλικού όταν είναι διαθέσιμη
    .accesskey = λ
performance-limit-content-process-option = Όριο διεργασιών περιεχομένου
    .accesskey = Ο
performance-limit-content-process-enabled-desc = Οι επιπρόσθετες διεργασίες περιεχομένου μπορούν να βελτιώσουν τις επιδόσεις κατά τη χρήση πολλαπλών καρτελών, αλλά θα χρησιμοποιούν περισσότερη μνήμη.
performance-limit-content-process-blocked-desc = Η τροποποίηση του αριθμού των διεργασιών περιεχομένου είναι δυνατή μόνο στο { -brand-short-name } με τη δυνατότητα πολλαπλών διεργασιών. <a data-l10n-name="learn-more">Μάθετε πώς μπορείτε να ελέγξετε εάν είναι ενεργοποιημένη η λειτουργία πολλαπλών διεργασιών</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (προεπιλογή)
performance-group =
    .label = Επιδόσεις
performance-use-recommended-settings-checkbox-2 =
    .description = Αυτές οι ρυθμίσεις έχουν προσαρμοστεί στο υλικό και το λειτουργικό σύστημά σας.
    .label = Χρήση προτεινόμενων ρυθμίσεων επιδόσεων
    .accesskey = υ

## Accessibility page

browsing-use-autoscroll =
    .label = Χρήση αυτόματης κύλισης
    .accesskey = α
keyboard-and-scrolling-group =
    .label = Πλοήγηση και κύλιση με πληκτρολόγιο
motion-and-link-group =
    .label = Κίνηση και μορφοποίηση συνδέσμων
browsing-use-smooth-scrolling =
    .label = Χρήση ομαλής κύλισης
    .accesskey = μ
browsing-gtk-use-non-overlay-scrollbars =
    .label = Πάντα εμφάνιση γραμμών κύλισης
    .accesskey = μ
browsing-always-underline-links =
    .label = Να γίνεται πάντα υπογράμμιση των συνδέσμων
    .accesskey = γ
browsing-use-onscreen-keyboard =
    .label = Εμφάνιση πληκτρολογίου αφής όταν χρειάζεται
    .accesskey = π
browsing-use-cursor-navigation =
    .label = Πάντα χρήση των πλήκτρων κέρσορα για πλοήγηση στις σελίδες
    .accesskey = π
browsing-use-full-keyboard-navigation =
    .label = Χρήση του πλήκτρου Tab για μετακίνηση της εστίασης μεταξύ κουμπιών φόρμας και συνδέσμων
    .accesskey = T
browsing-search-on-start-typing =
    .label = Αναζήτηση κειμένου κατά την έναρξη της πληκτρολόγησης
    .accesskey = μ
settings-keyboard-shortcuts-group =
    .description = Ελέγξτε τον τρόπο με τον οποίο πλοηγείστε και αλληλεπιδράτε με το { -brand-short-name }.
    .label = Συντομεύσεις πληκτρολογίου
settings-keyboard-shortcuts-customkeys-link =
    .label = Προσαρμογή συντομεύσεων πληκτρολογίου
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Προσαρμογή ρυθμίσεων γραμμής διευθύνσεων στην ενότητα «Αναζήτηση»
settings-media-group =
    .label = Πολυμέσα
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Χρήση εικόνας εντός εικόνας
    .accesskey = ε
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Συνέχεια αναπαραγωγής βίντεο σε λειτουργία «Εικόνα εντός εικόνας» κατά την εναλλαγή καρτελών
    .accesskey = Σ
browsing-media-control =
    .label = Έλεγχος πολυμέσων με πληκτρολόγιο, ακουστικά ή εικονική διεπαφή
    .accesskey = λ
recommendations-group =
    .label = Προτάσεις
browsing-cfr-recommendations =
    .label = Πρόταση επεκτάσεων κατά την περιήγηση
    .accesskey = Π
browsing-cfr-features =
    .label = Πρόταση λειτουργιών κατά την περιήγηση
    .accesskey = λ
browsing-group =
    .label = Περιήγηση
preferences-accessibility-header =
    .heading = Προσβασιμότητα
preferences-default-zoom-select =
    .aria-label = Προεπιλεγμένο ζουμ
preferences-fonts-family =
    .label = Οικογένεια γραμματοσειράς
    .accesskey = γ
preferences-fonts-size =
    .label = Μέγεθος γραμματοσειράς
    .accesskey = μ
preferences-fonts-advanced-settings =
    .label = Σύνθετες ρυθμίσεις
    .accesskey = Σ

## General Section - Proxy

network-proxy-group2 =
    .description = Ρυθμίστε τον τρόπο σύνδεσης του { -brand-short-name } με το διαδίκτυο.
    .label = Ρυθμίσεις διακομιστή μεσολάβησης
network-proxy-connection-settings2 =
    .description = Η αλλαγή αυτών των ρυθμίσεων ενδέχεται να προκαλέσει ζητήματα σύνδεσης
    .label = Ρύθμιση διακομιστή μεσολάβησης
    .accesskey = δ

## Home Section

home-new-windows-tabs-header = Νέα παράθυρα και καρτέλες
home-new-windows-tabs-description2 = Επιλέξτε τι θα βλέπετε όταν ανοίγετε την αρχική σας σελίδα, νέα παράθυρα και νέες καρτέλες.
home-section =
    .heading = Αρχική σελίδα και εκκίνηση

## Home Section - Default Browser

home-default-browser-title =
    .label = Προεπιλεγμένο πρόγραμμα περιήγησης
is-default-browser-2 =
    .message = Το { -brand-short-name } είναι το προεπιλεγμένο σας πρόγραμμα περιήγησης. Καλή επιλογή!
is-not-default-browser-2 =
    .message = Ψιτ, το { -brand-short-name } δεν έχει οριστεί ως προεπιλογή.
set-as-my-default-browser-2 =
    .label = Ορισμός ως προεπιλογή
    .accesskey = ρ

## Custom Homepage subpage

home-homepage-mode-label = Αρχική σελίδα και νέα παράθυρα
home-newtabs-mode-label = Νέες καρτέλες
home-restore-defaults =
    .label = Επαναφορά προεπιλογών
    .accesskey = Ε
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Προεπιλογή)
home-mode-choice-custom =
    .label = Προσαρμοσμένα URL…
home-mode-choice-blank =
    .label = Κενή σελίδα
home-homepage-custom-url =
    .placeholder = Επικόλληση URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Διαχείριση επέκτασης
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Χρήση τρέχουσας σελίδας
           *[other] Χρήση τρεχουσών σελίδων
        }
    .accesskey = τ
choose-bookmark =
    .label = Χρήση σελιδοδείκτη…
    .accesskey = σ
home-homepage-title =
    .label = Αρχική σελίδα
home-homepage-new-windows =
    .label = Νέα παράθυρα
home-homepage-new-tabs =
    .label = Νέες καρτέλες
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Επιλογή συγκεκριμένου ιστοτόπου
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Διευθύνσεις ιστοτόπων
home-custom-homepage-list =
    .aria-label = Διευθύνσεις ιστοτόπων
home-custom-homepage-address =
    .placeholder = Εισαγάγετε διεύθυνση
home-custom-homepage-address-button =
    .label = Προσθήκη διεύθυνσης
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Δεν έχουν προστεθεί ακόμα ιστότοποι.
home-custom-homepage-delete-address-button =
    .aria-label = Διαγραφή διεύθυνσης
    .title = Διαγραφή διεύθυνσης
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Αντικατάσταση με
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Τρέχουσες ανοικτές σελίδες
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Σελιδοδείκτες…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Επέκταση ({ $extension })
home-custom-homepage-header = Προσαρμοσμένη αρχική σελίδα
home-custom-homepage-subpage =
    .heading = Προσαρμοσμένη αρχική σελίδα

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Περιεχόμενο { -firefox-home-brand-name(capitalization: "upper", case: "gen") }
home-prefs-content-description2 = Επιλέξτε το περιεχόμενο που θέλετε στην οθόνη «{ -firefox-home-brand-name }».
home-prefs-search-header =
    .label = Διαδικτυακή αναζήτηση
home-prefs-shortcuts-header =
    .label = Συντομεύσεις
home-prefs-shortcuts-description = Ιστότοποι από σελιδοδείκτες ή ιστορικό
home-prefs-shortcuts-by-option-sponsored =
    .label = Χορηγούμενες συντομεύσεις
home-prefs-recommended-by-header-generic =
    .label = Προτεινόμενα άρθρα
home-prefs-recommended-by-description-generic = Εξαιρετικό περιεχόμενο από την οικογένεια του { -brand-product-name }
home-prefs-stories-header =
    .label = Άρθρα
home-prefs-stories-description = Εξατομικευμένα άρθρα με βάση τη δραστηριότητά σας

##

home-prefs-recommended-by-learn-more = Πώς λειτουργεί
home-prefs-recommended-by-option-sponsored-stories =
    .label = Χορηγούμενα άρθρα
home-prefs-highlights-option-visited-pages =
    .label = Σελίδες που έχετε επισκεφθεί
home-prefs-highlights-options-bookmarks =
    .label = Σελιδοδείκτες
home-prefs-highlights-option-most-recent-download =
    .label = Πιο πρόσφατες λήψεις
home-prefs-recent-activity-header =
    .label = Πρόσφατη δραστηριότητα
home-prefs-recent-activity-description = Μια συλλογή πρόσφατων ιστοτόπων και περιεχομένου
home-prefs-weather-header =
    .label = Καιρός
home-prefs-weather-description = Σημερινή πρόγνωση με μια ματιά
home-prefs-weather-learn-more-link = Μάθετε περισσότερα
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Υποστηρίξτε το { -brand-product-name }
home-prefs-mission-message = Οι χορηγοί μας υποστηρίζουν την αποστολή μας για ένα καλύτερο διαδίκτυο
home-prefs-mission-message-learn-more-link = Μάθετε πώς
home-prefs-manage-topics-link = Διαχείριση θεμάτων
home-prefs-choose-wallpaper-link = Επιλογή ταπετσαρίας
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } σειρά
           *[other] { $num } σειρές
        }

## Search Section

search-show-suggestions-option =
    .label = Εμφάνιση προτάσεων αναζήτησης
    .accesskey = Ε
search-show-suggestions-url-bar-option =
    .label = Εμφάνιση προτάσεων αναζήτησης στα αποτελέσματα της γραμμής διευθύνσεων
    .accesskey = τ
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Εμφάνιση προτάσεων αναζήτησης πριν από το ιστορικό περιήγησης στα αποτελέσματα της γραμμής διευθύνσεων
search-show-suggestions-private-windows-2 =
    .label = Προτάσεις αναζήτησης σε ιδιωτικά παράθυρα
search-suggestions-cant-show-2 =
    .message = Οι προτάσεις αναζήτησης δεν θα εμφανίζονται στη γραμμή διευθύνσεων, καθώς έχετε ρυθμίσει το { -brand-short-name } έτσι ώστε να μην διατηρεί ποτέ το ιστορικό.
addressbar-header-1 =
    .description = Επιλέξτε ποιες προτάσεις θα εμφανίζονται στη γραμμή διευθύνσεων
    .label = Γραμμή διευθύνσεων
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Προτάσεις από το { -brand-short-name } και τους συνεργάτες μας στη γραμμή διευθύνσεών σας.
    .label = { -firefox-suggest-brand-name(case: "nom") }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Εμφάνιση όρων αναζήτησης στη γραμμή διευθύνσεων για σελίδες αποτελεσμάτων
search-separate-default-engine-2 =
    .label = Χρήση διαφορετικής μηχανής αναζήτησης στα ιδιωτικά παράθυρα
    .accesskey = Χ
search-separate-default-engine-dropdown =
    .aria-label = Προεπιλεγμένη μηχανή αναζήτησης σε ιδιωτικά παράθυρα
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Πλοήγηση εντός της γραμμής διευθύνσεων
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Παράλειψη του μενού αποτελεσμάτων κατά τη χρήση του πλήκτρου Tab για μετακίνηση της εστίασης
search-suggestions-header-2 =
    .label = Προτάσεις μηχανής αναζήτησης
search-one-click-header2 = Συντομεύσεις αναζήτησης
search-one-click-desc = Επιλέξτε τις εναλλακτικές μηχανές αναζήτησης που εμφανίζονται κάτω από τη γραμμή διευθύνσεων και τη γραμμή αναζήτησης όταν αρχίσετε να πληκτρολογείτε μια λέξη-κλειδί.
search-one-click-header-3 =
    .description = Επιλέξτε ποιες μηχανές αναζήτησης και συντομεύσεις θα εμφανίζονται στη γραμμή διευθύνσεων.
    .label = Πρόσθετες μηχανές αναζήτησης
search-engine-list =
    .aria-label = Μηχανές αναζήτησης και συντομεύσεις
update-search-engine-success =
    .message = Επιτυχής ενημέρωση μηχανής αναζήτησης
search-edit-engine-2 =
    .title = Επεξεργασία μηχανής αναζήτησης
search-delete-engine =
    .title = Διαγραφή μηχανής αναζήτησης
search-enable-engine =
    .title = Ενεργοποίηση μηχανής αναζήτησης
search-outlink-to-extensions-page =
    .title = Διαχείριση στη σελίδα «Επεκτάσεις και θέματα»
search-choose-engine-column =
    .label = Μηχανή αναζήτησης
search-choose-keyword-column =
    .label = Λέξη-κλειδί
search-restore-default =
    .label = Επαναφορά προεπιλογών
    .accesskey = φ
search-remove-engine =
    .label = Αφαίρεση
    .accesskey = Α
search-add-engine =
    .label = Προσθήκη
    .accesskey = Π
search-add-engine-2 =
    .label = Προσθήκη μηχανής αναζήτησης
    .accesskey = Π
search-edit-engine =
    .label = Επεξεργασία
    .accesskey = Ε
search-find-more-link = Εύρεση περισσότερων μηχανών αναζήτησης
search-filtering-for-add-engine = Προσθήκη μηχανής
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Διπλή λέξη-κλειδί
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Έχετε επιλέξει μια λέξη-κλειδί που χρησιμοποιείται ήδη από το «{ $name }». Επιλέξτε κάποια άλλη.
search-keyword-warning-bookmark = Έχετε επιλέξει μια λέξη-κλειδί που χρησιμοποιείται ήδη από έναν σελιδοδείκτη. Επιλέξτε κάποια άλλη.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Υπάρχει ήδη μια μηχανή αναζήτησης με το όνομα «{ $name }». Επιλέξτε ένα άλλο όνομα.
remove-engine-confirmation = Θέλετε σίγουρα να αφαιρέσετε αυτήν τη μηχανή αναζήτησης;
remove-engine-remove = Αφαίρεση
remove-addon-engine-alert = Για να αφαιρέσετε αυτήν τη μηχανή αναζήτησης, καταργήστε το σχετικό πρόσθετο.
search-engine-group =
    .label = Προεπιλεγμένη μηχανή αναζήτησης
search-default-engine =
    .aria-label = Προεπιλεγμένη μηχανή αναζήτησης
# Header for the search section ("search" is a noun).
search-section =
    .heading = Αναζήτηση

## Containers Section

containers-section-header2 =
    .heading = Ρυθμίσεις θεματικών ενοτήτων
containers-card-header2 =
    .description = Διαχωρίζοντας τα cookie ανά θεματική ενότητα, μπορείτε να χρησιμοποιείτε διαφορετικούς λογαριασμούς στον ίδιο ιστότοπο και να περιορίζετε την καταγραφή μεταξύ των ιστοτόπων.
    .label = Θεματικές ενότητες
containers-add-button2 =
    .label = Προσθήκη νέας θεματικής ενότητας
    .accesskey = α
containers-list =
    .aria-label = Θεματικές ενότητες
containers-new-tab-check3 =
    .label = Επιλογή θεματικής ενότητας για κάθε νέα καρτέλα
    .accesskey = Ε
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Να μην χρησιμοποιούνται θεματικές ενότητες για συνδέσμους που ανοίγουν από εξωτερικές εφαρμογές
    .accesskey = Ν
containers-new-tab-check2 =
    .description = Το μενού θεματικών ενοτήτων θα ανοίγει κάθε φορά που επιλέγετε το κουμπί ανοίγματος νέας καρτέλας.
    .label = Επιλογή θεματικής ενότητας για κάθε νέα καρτέλα
    .accesskey = Ε
containers-settings-button2 =
    .title = Ρυθμίσεις
containers-remove-button3 =
    .title = Διαγραφή
containers-sites-card-header =
    .description = Επιλέξτε μια θεματική ενότητα για έναν ιστότοπο και το { -brand-short-name } θα τη χρησιμοποιεί κάθε φορά που ανοίγει ο ιστότοπος.
    .label = Θεματικές ενότητες για συγκεκριμένους ιστοτόπους
containers-sites-add-button =
    .label = Προσθήκη ιστοτόπου
    .accesskey = ι
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Θεματική ενότητα για το { $site }
containers-site-remove-button =
    .title = Διαγραφή
containers-remove-button2 =
    .title = Αφαίρεση

## Account and sync

sync-group-label =
    .label = Συγχρονισμός
account-group-label2 =
    .label = Λογαριασμός
account-disabled-group =
    .description = Δεν είναι διαθέσιμες οι ρυθμίσεις λογαριασμού.
    .label = Λογαριασμός
account-placeholder2 =
    .description = Συνδεθείτε και διατηρήστε τα δεδομένα σας ιδιωτικά, κρυπτογραφημένα και άμεσα προσβάσιμα, οπουδήποτε χρησιμοποιείτε το { -brand-short-name }.
    .label = Δεν έχετε συνδεθεί
account-sync-section =
    .heading = Λογαριασμός και συγχρονισμός
pane-account-sync-title2 = Λογαριασμός και συγχρονισμός
    .title = Λογαριασμός και συγχρονισμός

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Πάρτε μαζί σας το διαδίκτυο
sync-signedout-description2 = Συγχρονίστε τους σελιδοδείκτες, το ιστορικό, τις καρτέλες, τους κωδικούς πρόσβασης, τα πρόσθετα και τις ρυθμίσεις σας σε όλες τις συσκευές σας.
sync-signedout-account-signin3 =
    .label = Σύνδεση για συγχρονισμό…
    .accesskey = ν
sync-signedout-account-signin-4 =
    .label = Συνδεθείτε στον λογαριασμό σας για να ξεκινήσει ο συγχρονισμός
    .accesskey = ν
sync-signedout-account-short =
    .label = Σύνδεση
    .accesskey = ν
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Κάντε λήψη του Firefox για <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> ή <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> για συγχρονισμό με την κινητή σας συσκευή.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Αλλαγή εικόνας προφίλ
    .tooltiptext = Αλλαγή εικόνας προφίλ
sync-profile-picture-account-problem =
    .alt = Εικόνα προφίλ λογαριασμού
fxa-login-rejected-warning =
    .alt = Προειδοποίηση
sync-sign-out =
    .label = Αποσύνδεση…
    .accesskey = ν
sync-sign-out2 =
    .label = Αποσύνδεση
    .accesskey = ν
sync-manage-account = Διαχείριση λογαριασμού
    .accesskey = η
sync-manage-account2 =
    .label = Διαχείριση λογαριασμού
    .accesskey = η

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } Μη επαληθευμένος.
sync-signedin-unverified2 =
    .description = Ελέγξτε τα εισερχόμενά σας για να επιβεβαιώσετε τον λογαριασμό σας.
    .label = Το { $email } δεν έχει επιβεβαιωθεί ακόμα
sync-signedin-login-failure = Συνδεθείτε ξανά για επανασύνδεση του { $email }
sync-signedin-login-failure2 =
    .description = Συνδεθείτε ξανά για να ξεκινήσετε τον συγχρονισμό των δεδομένων σας.
    .label = Έχετε αποσυνδεθεί από το { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Επαλήθευση λογαριασμού
    .accesskey = Ε
sync-remove-account =
    .label = Αφαίρεση λογαριασμού
    .accesskey = Α
sync-sign-in =
    .label = Σύνδεση
    .accesskey = σ

## Sync section - enabling or disabling sync.

prefs-syncing-on = Συγχρονισμός: ΕΝΕΡΓΟΣ
prefs-syncing-on-2 =
    .label = Ο συγχρονισμός είναι ΕΝΕΡΓΟΣ
prefs-syncing-off = Συγχρονισμός: ΑΝΕΝΕΡΓΟΣ
prefs-syncing-off-2 =
    .description = Ενεργοποιήστε τον συγχρονισμό για να λάβετε τους σελιδοδείκτες, τους κωδικούς πρόσβασης, το ιστορικό και πολλά άλλα σε οποιαδήποτε συσκευή.
    .label = Ο συγχρονισμός είναι ΑΝΕΝΕΡΓΟΣ
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Ενεργοποιήστε τον συγχρονισμό για να λάβετε σελιδοδείκτες, κωδικούς πρόσβασης, ιστορικό και άλλα δεδομένα σε αυτήν τη συσκευή.
    .label = Ο συγχρονισμός είναι ΑΝΕΝΕΡΓΟΣ
prefs-sync-turn-on-syncing =
    .label = Ενεργοποίηση συγχρονισμού…
    .accesskey = ρ
prefs-sync-turn-on-syncing-2 =
    .label = Ενεργοποίηση συγχρονισμού
    .accesskey = ρ
prefs-sync-offer-setup-label2 = Συγχρονίστε τους σελιδοδείκτες, το ιστορικό, τις καρτέλες, τους κωδικούς πρόσβασης, τα πρόσθετα και τις ρυθμίσεις σας σε όλες τις συσκευές σας.
prefs-sync-now-button =
    .label = Συγχρονισμός τώρα
    .accesskey = τ
prefs-sync-now-button-2 =
    .label = Συγχρονισμός τώρα
    .accesskey = τ
prefs-syncing-button =
    .label = Συγχρονισμός…
prefs-syncing-button-2 =
    .label = Συγχρονισμός…
    .title = Συγχρονισμός τώρα
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Οι επιλογές συγχρονισμού σας ισχύουν πλέον μόνο για αυτήν τη συσκευή.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Μπορείτε να συγχρονίσετε αυτά τα στοιχεία σε όλες τις συνδεδεμένες συσκευές σας:
sync-syncing-across-devices-heading-2 = Συγχρονισμένα δεδομένα μεταξύ των συσκευών
sync-syncing-across-devices-heading-3 = Συγχρονισμός δεδομένων σε αυτήν τη συσκευή
sync-syncing-across-devices-empty-state2 =
    .description = Δεν συγχρονίζετε τίποτα… ακόμα. Ξεκινήστε τον συγχρονισμό για να λάβετε όλα τα δεδομένα σας σε όλες τις συσκευές σας.
    .label = Διαχείριση συγχρονισμένων δεδομένων
sync-syncing-across-devices-empty-state3 =
    .description = Δεν συγχρονίζεται τίποτα… ακόμα. Επιλέξτε τα δεδομένα που θα συγχρονίζονται σε αυτήν τη συσκευή.
    .label = Διαχείριση συγχρονισμένων δεδομένων
sync-currently-syncing-bookmarks = Σελιδοδείκτες
sync-currently-syncing-history = Ιστορικό
sync-currently-syncing-tabs = Ανοικτές καρτέλες
sync-currently-syncing-passwords = Κωδικοί πρόσβασης
sync-currently-syncing-addresses = Διευθύνσεις
sync-currently-syncing-payment-methods = Μέθοδοι πληρωμής
sync-currently-syncing-addons = Πρόσθετα
sync-currently-syncing-settings = Ρυθμίσεις
sync-manage-options =
    .label = Διαχείριση συγχρονισμού…
    .accesskey = Δ
sync-manage-options-2 =
    .label = Διαχείριση συγχρονισμένων δεδομένων
    .accesskey = Δ
settings-sync-disconnect-button =
    .label = Αποσύνδεση

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Σελιδοδείκτες
    .accesskey = δ
sync-engine-history =
    .label = Ιστορικό
    .accesskey = ρ
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Ανοικτές καρτέλες
    .tooltiptext = Ανοικτές καρτέλες από τις άλλες συσκευές σας
    .accesskey = τ
sync-engine-tabs =
    .label = Ανοικτές καρτέλες
    .tooltiptext = Μια λίστα με όλα όσα είναι ανοικτά στις συγχρονισμένες συσκευές
    .accesskey = κ
sync-engine-passwords =
    .label = Κωδικοί πρόσβασης
    .tooltiptext = Κωδικοί πρόσβασης που έχετε αποθηκεύσει
    .accesskey = Κ
sync-engine-addresses2 =
    .label = Διευθύνσεις
    .tooltiptext = Διευθύνσεις που έχετε αποθηκεύσει στο { -brand-short-name }
    .accesskey = ε
sync-engine-payment-methods3 =
    .label = Μέθοδοι πληρωμής
    .tooltiptext = Τρόποι πληρωμής που έχετε αποθηκεύσει
    .accesskey = μ
sync-engine-addons2 =
    .label = Πρόσθετα
    .tooltiptext = Επεκτάσεις και θέματα που έχετε προσθέσει στο { -brand-short-name } για υπολογιστές
    .accesskey = Π
sync-engine-settings2 =
    .label = Ρυθμίσεις
    .tooltiptext = Ρυθμίσεις του { -brand-short-name }, όπου είναι εφικτό
    .accesskey = σ
sync-engine-addresses =
    .label = Διευθύνσεις
    .tooltiptext = Διευθύνσεις αποστολής που έχετε αποθηκεύσει (μόνο για υπολογιστές)
    .accesskey = ν
sync-engine-payment-methods2 =
    .label = Μέθοδοι πληρωμής
    .tooltiptext = Ονόματα, αριθμοί καρτών και ημερομηνίες λήξης
    .accesskey = δ
sync-engine-addons =
    .label = Πρόσθετα
    .tooltiptext = Επεκτάσεις και θέματα για το Firefox για υπολογιστές
    .accesskey = Π
sync-engine-settings =
    .label = Ρυθμίσεις
    .tooltiptext = Ρυθμίσεις που έχετε αλλάξει στις ενότητες «Γενικά» και «Απόρρητο και ασφάλεια»
    .accesskey = θ
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Αποθήκευση
    .buttonlabelextra2 = Αποσύνδεση…
    .buttonaccesskeyaccept = Α
    .buttonaccesskeyextra2 = π
    .style = min-width: 39em;
    .title = Διαχείριση δεδομένων προς συγχρονισμό με όλες τις συνδεδεμένες συσκευές
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Αποθήκευση
    .buttonlabelextra2 = Αποσύνδεση…
    .buttonaccesskeyaccept = θ
    .buttonaccesskeyextra2 = σ
    .style = min-width: 36em;
    .title = Διαχειριστείτε ποια δεδομένα θα συγχρονίζονται σε αυτήν τη συσκευή

## The device name controls.

sync-device-name-header = Όνομα συσκευής
sync-device-name-header-2 =
    .label = Όνομα συσκευής
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Όνομα συσκευής
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Αλλαγή ονόματος συσκευής
    .accesskey = λ
sync-device-name-change =
    .label = Αλλαγή ονόματος συσκευής…
    .accesskey = λ
sync-device-name-cancel =
    .label = Ακύρωση
    .accesskey = κ
sync-device-name-save =
    .label = Αποθήκευση
    .accesskey = θ
sync-connect-another-device = Σύνδεση άλλης συσκευής
sync-connect-another-device-2 =
    .label = Σύνδεση άλλης συσκευής

## Privacy Section

privacy-header = Απόρρητο προγράμματος περιήγησης

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Κωδικοί πρόσβασης
    .searchkeywords = συνδέσεις
forms-passwords-header =
    .aria-label = Κωδικοί πρόσβασης
    .label = Κωδικοί πρόσβασης
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Ερώτηση για αποθήκευση κωδικών πρόσβασης
    .accesskey = Ε
forms-manage-password-exceptions =
    .label = Διαχείριση εξαιρέσεων κωδικών πρόσβασης
    .accesskey = Δ
forms-exceptions =
    .label = Εξαιρέσεις…
    .accesskey = ξ
forms-suggest-passwords =
    .label = Πρόταση ισχυρών κωδικών πρόσβασης
    .accesskey = Π
forms-breach-alerts =
    .label = Εμφάνιση ειδοποιήσεων για κωδικούς πρόσβασης από παραβιασμένους ιστοτόπους
    .accesskey = μ
forms-breach-alerts-learn-more-link = Μάθετε περισσότερα
preferences-relay-integration-checkbox2 =
    .label = Πρόταση μασκών email του { -relay-brand-name } για την προστασία της διεύθυνσης email σας
    .accesskey = ρ
relay-integration-learn-more-link = Μάθετε περισσότερα
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Αυτόματη συμπλήρωση ονομάτων χρήστη και κωδικών πρόσβασης
    .accesskey = υ
forms-fill-usernames-and-passwords-2 =
    .label = Αποθήκευση και αυτόματη συμπλήρωση ονομάτων χρήστη και κωδικών πρόσβασης
    .accesskey = θ
forms-saved-passwords =
    .label = Αποθηκευμένοι κωδικοί πρόσβασης
    .accesskey = θ
forms-saved-passwords-2 =
    .label = Διαχείριση αποθηκευμένων κωδικών πρόσβασης
    .accesskey = χ
forms-saved-passwords-searchkeywords = Οι συνδέσεις για τους ακόλουθους ιστοτόπους αποθηκεύονται στον υπολογιστή σας
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Πρόσθετα μέτρα προστασίας
forms-primary-pw-use =
    .label = Χρήση κύριου κωδικού πρόσβασης
    .accesskey = Χ
forms-primary-pw-use-2 =
    .description = Προσθέτει ένα επιπλέον επίπεδο ασφαλείας για την προστασία των αποθηκευμένων κωδικών πρόσβασής σας.
    .label = Χρήση κύριου κωδικού πρόσβασης
    .accesskey = Χ
forms-primary-pw-set =
    .label = Ορισμός κύριου κωδικού πρόσβασης
forms-primary-pw-on-2 = Ο κύριος κωδικός πρόσβασης είναι <strong>ΕΝΕΡΓΟΣ</strong>
forms-primary-pw-on =
    .label = Ο κύριος κωδικός πρόσβασης είναι ΕΝΕΡΓΟΣ
forms-primary-pw-change-2 =
    .label = Αλλαγή κύριου κωδικού πρόσβασης
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Απενεργοποίηση
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Απαίτηση σύνδεσης μέσω συσκευής για συμπλήρωση και διαχείριση κωδικών πρόσβασης
forms-os-reauth-2 =
    .label = Απαίτηση σύνδεσης μέσω συσκευής για τη διαχείριση των κωδικών πρόσβασης
forms-primary-pw-learn-more-link = Μάθετε περισσότερα
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Αλλαγή κύριου κωδικού…
    .accesskey = γ
forms-primary-pw-change =
    .label = Αλλαγή κύριου κωδικού πρόσβασης…
    .accesskey = κ
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Είστε σε λειτουργία FIPS. Το FIPS απαιτεί μη κενό κύριο κωδικό πρόσβασης.
forms-master-pw-fips-desc = Αποτυχία αλλαγής κωδικού
forms-windows-sso =
    .label = Να επιτρέπεται η καθολική σύνδεση των Windows για λογαριασμούς Microsoft, εργασίας και σχολείου.
forms-windows-sso-learn-more-link = Μάθετε περισσότερα
forms-windows-sso-desc = Διαχειριστείτε τους λογαριασμούς σας στις ρυθμίσεις συσκευής
windows-passkey-settings-label = Διαχείριση κλειδιών πρόσβασης στις ρυθμίσεις συστήματος
privacy-panel-settings-header =
    .description = Λάβετε βοήθεια με την προστασία των πληροφοριών σας στο { -brand-short-name }.
    .label = Ρυθμίσεις πίνακα απορρήτου
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Εμφάνιση μηνυμάτων παραβίασης
    .accesskey = υ

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Για να δημιουργήσετε έναν κύριο κωδικό πρόσβασης, εισαγάγετε τα διαπιστευτήρια σύνδεσης των Windows. Αυτό συμβάλλει στην προστασία των λογαριασμών σας.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = δημιουργήσει κύριο κωδικό πρόσβασης
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] αλλάξει τις ρυθμίσεις των μεθόδων πληρωμής
       *[other] Το { -brand-short-name } προσπαθεί να αλλάξει τις ρυθμίσεις των μεθόδων πληρωμής. Χρησιμοποιήστε τη σύνδεση μέσω της συσκευής σας για να το επιτρέψετε.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Μέθοδοι πληρωμής
autofill-payment-methods-checkbox-message-2 =
    .label = Αποθήκευση και αυτόματη συμπλήρωση στοιχείων πληρωμής
    .accesskey = π
autofill-payment-methods-manage-payments-title =
    .heading = Διαχείριση μεθόδων πληρωμής
autofill-payment-methods-manage-payments-button =
    .label = Διαχείριση μεθόδων πληρωμής
    .accesskey = μ
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Απαιτείται σύνδεση συσκευής για αυτόματη συμπλήρωση
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Απαίτηση σύνδεσης μέσω συσκευής για αυτόματη συμπλήρωση και διαχείριση μεθόδων πληρωμής
    .accesskey = π
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Αποθήκευση κωδικών ασφαλείας
    .accesskey = κ
autofill-payment-methods-add-button = Προσθήκη νέας μεθόδου πληρωμής
payments-list-header =
    .label = Μέθοδοι πληρωμής
payments-delete-payment-prompt-title = Αφαίρεση μεθόδου πληρωμής;
payments-delete-payment-prompt-confirm-button = Διαγραφή
payments-delete-payment-prompt-cancel-button = Ακύρωση
payments-delete-payment-button-label =
    .aria-label = Διαγραφή
payments-edit-payment-button-label =
    .aria-label = Επεξεργασία
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Δεν έχουν προστεθεί μέθοδοι πληρωμής
autofill-addresses-checkbox-message =
    .label = Αποθήκευση και αυτόματη συμπλήρωση διευθύνσεων
    .accesskey = Α
autofill-addresses-manage-addresses-button =
    .label = Διαχείριση διευθύνσεων και άλλων
    .accesskey = Δ
addresses-list-header =
    .label = Διευθύνσεις
addreses-delete-address-button-label =
    .aria-label = Διαγραφή
addreses-edit-address-button-label =
    .aria-label = Επεξεργασία
addresses-delete-address-prompt-title = Διαγραφή διεύθυνσης;
addresses-delete-address-prompt-confirm-button = Διαγραφή
addresses-delete-address-prompt-cancel-button = Ακύρωση
autofill-addresses-add-button = Προσθήκη νέας διεύθυνσης
autofill-addresses-manage-addresses-title =
    .heading = Διαχείριση διευθύνσεων και άλλων
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Δεν έχουν προστεθεί διευθύνσεις
personal-info-group =
    .label = Προσωπικές πληροφορίες
autofill-personal-info-checkbox-message =
    .label = Αποθήκευση και αυτόματη συμπλήρωση προσωπικών πληροφοριών
autofill-personal-info-manage-button =
    .label = Διαχείριση προσωπικών πληροφοριών
passports-list-header =
    .label = Διαβατήρια
passports-delete-passport-button-label =
    .aria-label = Διαγραφή
passports-edit-passport-button-label =
    .aria-label = Επεξεργασία
passports-delete-passport-prompt-title = Διαγραφή διαβατηρίου;
passports-delete-passport-prompt-confirm-button = Διαγραφή
passports-delete-passport-prompt-cancel-button = Ακύρωση
autofill-passports-add-button = Προσθήκη νέου διαβατηρίου
autofill-personal-info-manage-title =
    .heading = Διαχείριση προσωπικών πληροφοριών
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Δεν έχουν προστεθεί διαβατήρια
pane-passwords-autofill-title2 = Κωδικοί πρόσβασης και αυτόματη συμπλήρωση
    .title = Κωδικοί πρόσβασης και αυτόματη συμπλήρωση
preferences-passwords-autofill-header =
    .heading = Κωδικοί πρόσβασης και αυτόματη συμπλήρωση
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Διευθύνσεις και άλλα
payments-group =
    .label = Μέθοδοι πληρωμής

## Privacy Section - History

history-remember-option-never2 =
    .description = Κάθε παράθυρο λειτουργεί ως ιδιωτικό. Όταν είναι ενεργή αυτή η ρύθμιση, θα πρέπει να επιτρέπετε την εκτέλεση των επεκτάσεων.
    .label = Διαγραφή ιστορικού
history-remember-option-custom2 =
    .label = Προσαρμογή ιστορικού
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = Το { -brand-short-name } θα αποθηκεύει το ιστορικό περιήγησης, λήψεων, φορμών και αναζητήσεων.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = Το { -brand-short-name } θα χρησιμοποιεί τις ίδιες ρυθμίσεις με την ιδιωτική περιήγηση και δεν θα διατηρεί το ιστορικό περιήγησης σας.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = Το { -brand-short-name } θα χρησιμοποιεί προσαρμοσμένες ρυθμίσεις για το ιστορικό περιήγησης, λήψεων, φορμών και αναζητήσεων.
history-private-browsing-permanent =
    .label = Μόνιμη λειτουργία ιδιωτικής περιήγησης
    .accesskey = ι
history-remember-browser-option =
    .label = Διατήρηση ιστορικού περιήγησης και λήψεων
    .accesskey = τ
history-remember-search-option =
    .label = Διατήρηση ιστορικού αναζήτησης και φορμών
    .accesskey = φ
history-clear-on-close-option =
    .label = Απαλοιφή ιστορικού όταν κλείνει το { -brand-short-name }
    .accesskey = κ
history-clear-on-close-settings =
    .label = Ρυθμίσεις…
    .accesskey = θ
history-shutdown-exceptions =
    .label = Διαχείριση εξαιρέσεων
    .accesskey = χ
history-clear-button =
    .label = Απαλοιφή ιστορικού…
    .accesskey = σ
history-header2 =
    .heading = Ιστορικό
history-section-header =
    .description = Επιλέξτε τι θέλετε να απομνημονεύει το { -brand-short-name } όταν κλείνετε το πρόγραμμα περιήγησης.
    .label = Ιστορικό
history-custom-section-header =
    .description = Προσαρμόστε τα στοιχεία που θέλετε να απομνημονεύει το { -brand-short-name } όταν το κλείνετε.
    .label = Σύνθετες ρυθμίσεις
history-custom-button =
    .label = Επιλέξτε τι θέλετε να απομνημονεύει το { -brand-short-name }
history-group =
    .label = Ιστορικό
history-mode-radio-group =
    .aria-label = Ιστορικό
history-remember-option-all2 =
    .label = Διατήρηση ιστορικού

## Privacy Section - Site Data

sitedata-total-size-calculating = Υπολογισμός μεγέθους δεδομένων ιστοτόπου και προσωρινής μνήμης…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Οι ιστότοποι χρησιμοποιούν επί του παρόντος <strong>{ $value } { $unit }</strong> χώρου δίσκου.
sitedata-learn-more = Μάθετε περισσότερα
sitedata-delete-on-close2 =
    .label = Διαγραφή cookie και δεδομένων ιστοτόπων σε κάθε κλείσιμο του { -brand-short-name }
    .accesskey = φ
sitedata-delete-on-close-private-browsing3 =
    .message = Βάσει των ρυθμίσεων ιστορικού σας, το { -brand-short-name } διαγράφει τα cookie και τα δεδομένα ιστοτόπων από τη συνεδρία σας όταν κλείνετε το πρόγραμμα περιήγησης.
sitedata-delete-on-close-private-browsing4 =
    .heading = Το ιστορικό δεν θα αποθηκεύεται.
    .message = Το { -brand-short-name } διαγράφει τα cookie και τα δεδομένα ιστοτόπων από τη συνεδρία σας όταν κλείνετε το πρόγραμμα περιήγησης.
sitedata-option-block-cross-site-trackers =
    .label = Ιχνηλάτες μεταξύ ιστοτόπων
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cookie καταγραφής μεταξύ ιστοτόπων
sitedata-option-block-cross-site-cookies2 =
    .label = Απομόνωση cookie μεταξύ ιστοτόπων
sitedata-option-block-unvisited =
    .label = Cookie από ιστοτόπους που δεν έχετε επισκεφτεί
sitedata-option-block-all-cross-site-cookies =
    .label = Όλα τα cookie μεταξύ ιστοτόπων (πιθανή δυσλειτουργία ιστοτόπων)
sitedata-option-block-all =
    .label = Όλα τα cookie (προκαλεί δυσλειτουργία ιστοτόπων)
sitedata-clear2 =
    .label = Απαλοιφή δεδομένων περιήγησης
    .accesskey = φ
sitedata-settings2 =
    .label = Διαχείριση δεδομένων περιήγησης
    .accesskey = Δ
sitedata-cookies-exceptions =
    .label = Διαχείριση εξαιρέσεων…
    .accesskey = σ
sitedata-cookies-exceptions2 =
    .description = Μπορείτε να καθορίσετε σε ποιους ιστοτόπους επιτρέπεται ή απαγορεύεται πάντα η χρήση cookie και δεδομένων ιστοτόπου.
    .label = Διαχείριση εξαιρέσεων
    .accesskey = χ
sitedata-heading =
    .description = Διαχειριστείτε τα cookie, το ιστορικό, την προσωρινή μνήμη, τα δεδομένα ιστοτόπων και πολλά άλλα.
    .label = Δεδομένα περιήγησης
sitedata-settings3 =
    .label = Απαλοιφή δεδομένων για συγκεκριμένους ιστοτόπους
    .accesskey = σ
sitedata-cookies-exceptions3 =
    .description = Επιλέξτε πώς χειρίζονται συγκεκριμένοι ιστότοποι τα cookie και τα δεδομένα ιστοτόπων.
    .label = Διαχείριση εξαιρέσεων
    .accesskey = χ
cookies-site-data-group =
    .label = Cookie και δεδομένα ιστοτόπων

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Αποκλεισμός μηνυμάτων για cookie
cookie-banner-blocker-description = Όταν ένας ιστότοπος ρωτά εάν μπορεί να χρησιμοποιήσει cookie στη λειτουργία ιδιωτικής περιήγησης, το { -brand-short-name } αρνείται αυτόματα για εσάς. Μόνο σε υποστηριζόμενους ιστοτόπους.
cookie-banner-learn-more = Μάθετε περισσότερα
cookie-banner-blocker-checkbox-label =
    .label = Αυτόματη απόρριψη μηνυμάτων για cookie

## Search Section

addressbar-locbar-history-option =
    .label = Ιστορικό περιήγησης
    .accesskey = Ι
addressbar-locbar-bookmarks-option =
    .label = Σελιδοδείκτες
    .accesskey = κ
addressbar-locbar-clipboard-option =
    .label = Πρόχειρο
    .accesskey = Π
addressbar-locbar-openpage-option =
    .label = Ανοικτές καρτέλες
    .accesskey = ν
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Συντομεύσεις
    .accesskey = Σ
addressbar-locbar-topsites-option =
    .label = Κορυφαίους ιστοτόπους
    .accesskey = Κ
addressbar-locbar-engines-option-1 =
    .label = Πρόταση μηχανών αναζήτησης προς χρήση
    .accesskey = ρ
addressbar-locbar-quickactions-option =
    .label = Γρήγορες ενέργειες
    .accesskey = Γ
addressbar-locbar-showrecentsearches-option-2 =
    .label = Πρόσφατες αναζητήσεις
    .accesskey = φ
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Δημοφιλείς προτάσεις αναζήτησης
    .accesskey = μ
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Λάβετε προτάσεις από το διαδίκτυο που σχετίζονται με την αναζήτησή σας.
    .label = Προτάσεις από το { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Υποστηρίξτε το { -brand-short-name } με περιστασιακές προτάσεις από χορηγούς.
    .label = Προτάσεις από χορηγούς
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Λήψη προτάσεων από τη Mozilla κατά την πληκτρολόγηση
addressbar-dismissed-suggestions-label-2 =
    .description = Επαναφέρετε τις απορριφθείσες προτάσεις από χορηγούς και το { -brand-short-name }.
    .label = Απορριφθείσες προτάσεις
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Επαναφορά προτάσεων

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Ενισχυμένη προστασία από καταγραφή
content-blocking-section-top-level-description = Οι ιχνηλάτες σάς ακολουθούν στο διαδίκτυο ώστε να συλλέξουν δεδομένα για τις συνήθειες και τα ενδιαφέροντά σας. Το { -brand-short-name } αποκλείει πολλούς από αυτούς, καθώς και άλλα κακόβουλα σενάρια.
content-blocking-learn-more = Μάθετε περισσότερα
content-blocking-fpi-incompatibility-warning = Χρησιμοποιείτε τη λειτουργία First Party Isolation (FPI), που παρακάμπτει ορισμένες ρυθμίσεις cookie του { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Χρησιμοποιείτε το Resist Fingerprinting (RFP), το οποίο αντικαθιστά ορισμένες από τις ρυθμίσεις προστασίας του { -brand-short-name } ενάντια στο fingerprinting. Αυτό μπορεί να προκαλέσει δυσλειτουργίες σε ορισμένους ιστοτόπους.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Τυπική
    .accesskey = Τ
enhanced-tracking-protection-setting-strict =
    .label = Αυστηρή
    .accesskey = Α
enhanced-tracking-protection-setting-custom =
    .label = Προσαρμοσμένη
    .accesskey = Π

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Ισορροπία μεταξύ προστασίας και επιδόσεων. Οι σελίδες θα φορτώνονται κανονικά.
content-blocking-etp-strict-desc = Ισχυρότερη προστασία, αλλά πιθανή δυσλειτουργία μερικών ιστοτόπων ή περιεχομένου.
content-blocking-etp-custom-desc = Επιλέξτε ιχνηλάτες και σενάρια για αποκλεισμό.
content-blocking-etp-blocking-desc = Το { -brand-short-name } αποκλείει τα εξής:
content-blocking-private-windows = Περιεχόμενο καταγραφής σε ιδιωτικά παράθυρα
content-blocking-cross-site-cookies-in-all-windows2 = Cookie μεταξύ ιστοτόπων σε όλα τα παράθυρα
content-blocking-cross-site-tracking-cookies = Cookie καταγραφής μεταξύ ιστοτόπων
content-blocking-all-cross-site-cookies-private-windows = Cookie μεταξύ ιστοτόπων σε ιδιωτικά παράθυρα
content-blocking-isolate-cross-site-cookies = Απομόνωση cookie μεταξύ ιστοτόπων
content-blocking-social-media-trackers = Ιχνηλάτες κοινωνικών δικτύων
content-blocking-all-cookies = Όλα τα cookie
content-blocking-unvisited-cookies = Cookie από ιστοτόπους που δεν έχετε επισκεφτεί
content-blocking-all-windows-tracking-content = Περιεχόμενο καταγραφής σε όλα τα παράθυρα
content-blocking-all-cross-site-cookies = Όλα τα cookie μεταξύ ιστοτόπων
content-blocking-cryptominers = Cryptominer
content-blocking-fingerprinters = Fingerprinter
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Γνωστά και πιθανά fingerprinter
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Η Ολική προστασία cookie περιορίζει τα cookie στον ιστότοπο που βρίσκεστε, ώστε να μην μπορούν να χρησιμοποιηθούν από ιχνηλάτες για την καταγραφή της δραστηριότητάς σας.
content-blocking-etp-standard-tcp-rollout-learn-more = Μάθετε περισσότερα
content-blocking-etp-standard-tcp-title = Περιλαμβάνει την Ολική προστασία cookie, την πιο ισχυρή μας λειτουργία απορρήτου
content-blocking-warning-title-2 = Ορισμένοι ιστότοποι ενδέχεται να μην λειτουργούν με την αυστηρή προστασία από καταγραφή
content-blocking-warning-title-custom = Ορισμένοι ιστότοποι ενδέχεται να μην λειτουργούν με την προσαρμοσμένη προστασία από καταγραφή
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = Το { -brand-short-name } συνιστά τη χρήση των ρυθμίσεων «Διόρθωση ζητημάτων ιστοτόπου» για τη μείωση των προβλημάτων με τις λειτουργίες και το περιεχόμενο των ιστοτόπων. Αν κάποιος ιστότοπος δεν λειτουργεί σωστά, δοκιμάστε να απενεργοποιήσετε την προστασία από καταγραφή για να φορτωθεί όλο το περιεχόμενό του.
content-blocking-warning-learn-how = Μάθετε πώς
content-blocking-baseline-exceptions-3 =
    .description = Βοηθά στη φόρτωση ιστοτόπων και λειτουργιών άροντας τον αποκλεισμό μόνο των βασικών στοιχείων που ενδέχεται να περιέχουν ιχνηλάτες. Διορθώνει τα πιο κοινά προβλήματα.
    .label = Διόρθωση σημαντικών ζητημάτων ιστοτόπου (προτείνεται)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Επαναφέρει στοιχεία, όπως βίντεο σε άρθρα ή ενότητες σχολίων, άροντας τον αποκλεισμό των στοιχείων που ενδέχεται να περιέχουν ιχνηλάτες. Αυτό μπορεί να μειώσει τα ζητήματα σε ιστοτόπους, αλλά προσφέρει λιγότερη προστασία. Πρέπει να χρησιμοποιείται με τις διορθώσεις σημαντικών ζητημάτων.
    .label = Διόρθωση μικρών ζητημάτων ιστοτόπου
content-blocking-baseline-uncheck-warning-dialog-title = Θέλετε σίγουρα να απενεργοποιήσετε τις διορθώσεις;
content-blocking-baseline-uncheck-warning-dialog-body = Αυτή η ρύθμιση συμβάλλει στη διόρθωση των πιο κοινών προβλημάτων των ιστοτόπων. Αν την απενεργοποιήσετε, ορισμένοι ιστότοποι ενδέχεται να μην λειτουργούν και το { -brand-short-name } δεν θα μπορεί να βοηθήσει στην επίλυση αυτών των ζητημάτων.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Απενεργοποίηση διορθώσεων
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Διατήρηση διορθώσεων
content-blocking-reload-description = Θα πρέπει να φορτώσετε ξανά τις καρτέλες σας για εφαρμογή των αλλαγών αυτών.
content-blocking-reload-tabs-button =
    .label = Ανανέωση όλων των καρτελών
    .accesskey = Α
content-blocking-tracking-content-label =
    .label = Περιεχόμενο καταγραφής
    .accesskey = Π
content-blocking-tracking-protection-option-all-windows =
    .label = Σε όλα τα παράθυρα
    .accesskey = ό
content-blocking-option-private =
    .label = Μόνο σε ιδιωτικά παράθυρα
    .accesskey = ι
content-blocking-cookies-label =
    .label = Cookie
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Περισσότερες πληροφορίες
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Cryptominer
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Γνωστά fingerprinter
    .accesskey = Γ
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Πιθανά fingerprinter
    .accesskey = Π

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Διαχείριση εξαιρέσεων…
    .accesskey = χ

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Παύση ειδοποιήσεων μέχρι να επανεκκινηθεί το { -brand-short-name }
    .accesskey = ε
permissions-autoplay2 =
    .label = Αυτόματη αναπαραγωγή
permissions-block-popups2 =
    .label = Φραγή αναδυόμενων παραθύρων και ανακατευθύνσεις τρίτων
    .accesskey = Φ
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Προσθέστε ιστοτόπους που μπορούν να ανοίγουν αναδυόμενα παράθυρα και να χρησιμοποιούν ανακατευθύνσεις τρίτων.
    .label = Διαχείριση εξαιρέσεων
    .searchkeywords = αναδυόμενα, αναδυόμενα παράθυρα, popups, popup, pop-up, pop-ups
    .accesskey = ε
permissions-addon-install-warning3 =
    .label = Εμφάνιση προειδοποίησης όταν οι ιστότοποι προσπαθούν να εγκαταστήσουν επεκτάσεις
    .accesskey = φ
permissions-addon-exceptions2 =
    .label = Επιλέξτε ποιοι ιστότοποι μπορούν να εγκαθιστούν επεκτάσεις
    .accesskey = Ε
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Να επιτρέπεται στους ιστοτόπους η ερώτηση για άνοιγμα συνδέσμων εφαρμογών.
    .accesskey = α
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Διαχείριση αποκλεισμένων ιστοτόπων
    .accesskey = Δ
permissions-location2 =
    .label = Τοποθεσία
permissions-localhost2 =
    .label = Εφαρμογές και υπηρεσίες συσκευής
permissions-local-network2 =
    .label = Συσκευές τοπικού δικτύου
permissions-xr2 =
    .label = Εικονική πραγματικότητα
permissions-camera2 =
    .label = Κάμερα
permissions-microphone2 =
    .label = Μικρόφωνο
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Ηχείο
permissions-notification2 =
    .label = Ειδοποιήσεις
permissions-header3 =
    .description = Διαχειριστείτε τι θα μπορούν να προσπελάσουν, να ελέγξουν ή να ενεργοποιήσουν οι ιστότοποι.
    .label = Δικαιώματα
permissions-data-section =
    .heading = Δικαιώματα και δεδομένα
pane-permissions-data-title2 = Δικαιώματα και δεδομένα
    .title = Δικαιώματα και δεδομένα
notifications-section-header =
    .heading = Ειδοποιήσεις
notifications-entry-card-header =
    .description = Επιλέξτε ποιοι ιστότοποι μπορούν να στέλνουν ειδοποιήσεις και πώς θα εμφανίζονται αυτές.
    .label = Ειδοποιήσεις
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } ιστότοπος
           *[other] { $count } ιστότοποι
        }
    .label = Διαχείριση ρυθμίσεων ειδοποιήσεων
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Διαχείριση ρυθμίσεων ειδοποιήσεων ιστοτόπων
notifications-website-card-header =
    .description = Επιλέξτε πώς οι ιστότοποι μπορούν να στέλνουν ειδοποιήσεις.
    .label = Ειδοποιήσεις ιστοτόπων
notifications-filter =
    .placeholder = Αναζήτηση ιστοτόπων
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Ιστότοπος
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Αποδοχή ειδοποιήσεων
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Ιστότοποι
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Πάντα
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Αποδοχή
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Ποτέ
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Δεν έχουν προστεθεί ειδοποιήσεις ιστοτόπων.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Δεν βρέθηκαν ειδοποιήσεις ιστοτόπων που να αντιστοιχούν στην αναζήτησή σας.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Για να βεβαιωθείτε ότι αυτή η αλλαγή θα συμπεριληφθεί στα αντίγραφα ασφαλείας σας, ανοίξτε καθένα από τα προφίλ και επιλέξτε «Δημιουργία τώρα» στις Ρυθμίσεις.
nimbus-rollouts =
    .description = Οι αλλαγές θα διατίθενται απομακρυσμένα.
    .label = Να επιτρέπεται στο { -brand-short-name } η βελτίωση των δυνατοτήτων, των επιδόσεων και της σταθερότητας μεταξύ των ενημερώσεων
addon-recommendations3 =
    .description = Λάβετε προτάσεις επεκτάσεων για να βελτιώσετε την εμπειρία περιήγησής σας.
    .label = Να επιτρέπονται εξατομικευμένες προτάσεις επεκτάσεων
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Η αναφορά δεδομένων είναι ανενεργή για αυτήν τη διαμόρφωση έκδοσης δομής.
collection-backlogged-crash-reports2 =
    .label = Αυτόματη αποστολή αναφορών κατάρρευσης
    .accesskey = τ
collection-backlogged-crash-reports-description = Αυτό βοηθά τη { -vendor-short-name } να διαγνώσει και να επιλύσει προβλήματα του προγράμματος περιήγησης. Οι αναφορές ενδέχεται να περιέχουν προσωπικά ή ευαίσθητα δεδομένα.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Ίδιες ρυθμίσεις, νέα εμφάνιση!
    .message = Αναδιοργανώσαμε αυτήν τη σελίδα ώστε να είναι ευκολότερη η ανάγνωση και η εξερεύνησή της. Οι προσωπικές σας ρυθμίσεις δεν έχουν αλλάξει και όλα βρίσκονται ακόμα εδώ. Συμβουλή: χρησιμοποιήστε την αναζήτηση για να μεταβείτε απευθείας σε αυτό που χρειάζεστε.
settings-redesign-promo-dismiss-button =
    .label = Το κατάλαβα
privacy-segmentation-section-header = Νέες λειτουργίες που βελτιώνουν την περιήγησή σας
privacy-segmentation-section-description = Όταν προσφέρουμε λειτουργίες που χρησιμοποιούν τα δεδομένα σας για μια πιο εξατομικευμένη εμπειρία:
privacy-segmentation-radio-off =
    .label = Χρήση προτάσεων του { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Εμφάνιση λεπτομερών πληροφοριών
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Προσπαθούμε να σας παρέχουμε επιλογές και να συλλέγουμε μόνο τα ελάχιστα δεδομένα που απαιτούνται για τη βελτίωση του { -brand-product-name } για όλους.
    .label = Συλλογή και χρήση δεδομένων του { -brand-short-name }
    .searchkeywords = τηλεμετρία
data-collection-link = Προβολή δήλωσης απορρήτου
data-collection-preferences-across-profiles =
    .message = Αυτές οι ρυθμίσεις ισχύουν για κάθε προφίλ του { -brand-product-name } σε αυτήν τη συσκευή.
data-collection-profiles-link = Προβολή όλων των προφίλ
data-collection-health-report-telemetry-disabled =
    .message = Δεν επιτρέπεται πλέον στη { -vendor-short-name } η συλλογή τεχνικών δεδομένων και δεδομένων αλληλεπίδρασης. Όλα τα προηγούμενα δεδομένα θα διαγραφούν μέσα σε 30 ημέρες.
data-collection-health-report =
    .description = Αυτό μάς βοηθά να βελτιώσουμε τις λειτουργίες, τις επιδόσεις και τη σταθερότητα του { -brand-product-name }.
    .label = Αποστολή τεχνικών δεδομένων και δεδομένων αλληλεπίδρασης στη { -vendor-short-name }
    .accesskey = λ
data-collection-health-report-disabled =
    .description = Η αναφορά δεδομένων είναι απενεργοποιημένη για αυτήν τη διαμόρφωση δομής.
    .label = Αποστολή τεχνικών δεδομένων και δεδομένων αλληλεπίδρασης στη { -vendor-short-name }
    .accesskey = δ
data-collection-run-studies =
    .description = Το { -brand-short-name } επιλέγει τυχαία χρήστες για δοκιμή λειτουργιών, βελτιώνοντας την ποιότητα για όλους.
    .label = Να επιτρέπεται στο { -brand-short-name } να εκτελεί μελέτες λειτουργιών
data-collection-studies-link =
    .label = Προβολή μελετών του { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = Αυτό βοηθά τη { -vendor-short-name } να διαγνώσει και να επιλύσει προβλήματα του προγράμματος περιήγησης. Οι αναφορές ενδέχεται να περιέχουν προσωπικά ή ευαίσθητα δεδομένα.
    .label = Αυτόματη αποστολή αναφορών κατάρρευσης
    .accesskey = μ
data-collection-usage-ping =
    .description = Αυτό βοηθά τη { -vendor-short-name } να εκτιμήσει τους ενεργούς χρήστες.
    .label = Αποστολή ping ημερήσιας χρήσης στη { -vendor-short-name }
    .accesskey = σ

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Ασφάλεια
browsing-protection-group2 =
    .description = Οι επικίνδυνοι ιστότοποι και λήψεις μπορούν να θέσουν σε κίνδυνο τα δεδομένα και τη συσκευή σας. Το { -brand-short-name } τα αποκλείει αυτόματα και σας προειδοποιεί για επικίνδυνο ή ανεπιθύμητο λογισμικό.
    .label = Προστασία από παραπλανητικό περιεχόμενο και επικίνδυνο λογισμικό
security-enable-safe-browsing =
    .label = Φραγή επικίνδυνου και παραπλανητικού περιεχομένου
    .accesskey = Φ
security-enable-safe-browsing-link = Μάθετε περισσότερα
security-safe-browsing-warning =
    .message = Η απενεργοποίηση αυτής της λειτουργίας μειώνει την προστασία από απάτες, κακόβουλους ιστοτόπους και επικίνδυνες λήψεις.
security-block-downloads =
    .label = Φραγή επικίνδυνων λήψεων
    .accesskey = λ
security-block-uncommon-software =
    .label = Προειδοποίηση για ανεπιθύμητο και ασυνήθιστο λογισμικό
    .accesskey = σ

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Να επιτρέπεται στο { -brand-short-name } να εμπιστεύεται αυτόματα τα τρίτα πιστοποιητικά ρίζας που εγκαθιστάτε
    .accesskey = π
certs-devices-enable-fips = Ενεργοποίηση FIPS
space-alert-over-5gb-settings-button =
    .label = Άνοιγμα ρυθμίσεων
    .accesskey = Ά
space-alert-over-5gb-message2 = <strong>Το { -brand-short-name } δεν διαθέτει επαρκή χώρο στον δίσκο.</strong> Το περιεχόμενο των ιστοτόπων ενδέχεται να μην εμφανίζεται κανονικά. Μπορείτε να διαγράψετε τα αποθηκευμένα δεδομένα στις Ρυθμίσεις > Απόρρητο και ασφάλεια > Cookie και δεδομένα ιστοτόπων.
space-alert-under-5gb-message2 = <strong>Το { -brand-short-name } δεν διαθέτει επαρκή χώρο στον δίσκο.</strong> Το περιεχόμενο των ιστοτόπων ενδέχεται να μην εμφανίζεται κανονικά. Επισκεφθείτε το «Μάθετε περισσότερα» για να βελτιστοποιήσετε τη χρήση δίσκου σας για μια καλύτερη εμπειρία περιήγησης.
certs-description3 =
    .description = Ρυθμίστε τα πιστοποιητικά που χρησιμοποιεί το { -brand-short-name } για επαλήθευση των ασφαλών συνδέσεων.
    .label = Πιστοποιητικά
certs-view2 =
    .label = Διαχείριση πιστοποιητικών
    .accesskey = π
certs-devices2 =
    .label = Διαχείριση συσκευών ασφαλείας
    .accesskey = σ

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Πώς λειτουργεί η δυνατότητα «Μόνο HTTPS»
httpsonly-radio-enabled =
    .label = Ενεργοποίηση λειτουργίας «Μόνο HTTPS» σε όλα τα παράθυρα
httpsonly-radio-enabled-pbm =
    .label = Ενεργοποίηση λειτουργίας «Μόνο HTTPS» μόνο σε ιδιωτικά παράθυρα
httpsonly-radio-disabled3 =
    .description = Το { -brand-short-name } ενδέχεται και πάλι να αναβαθμίσει ορισμένες συνδέσεις
    .label = Να μην ενεργοποιηθεί η λειτουργία «Μόνο HTTPS»
httpsonly-group =
    .description = Επιτρέπει μόνο τις ασφαλείς συνδέσεις με ιστοτόπους. Το { -brand-short-name } θα σας ρωτήσει πριν πραγματοποιήσει μη ασφαλή σύνδεση.
    .label = Λειτουργία «Μόνο HTTPS»
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS μέσω HTTPS
dns-over-https-group2 =
    .description = Η λειτουργία «Σύστημα ονομάτων τομέων μέσω HTTPS» (DoH) κρυπτογραφεί τις αναζητήσεις ιστοτόπων, ώστε να είναι πιο δύσκολο για τον πάροχο διαδικτύου σας ή άλλα μέρη να βλέπουν ποιους ιστοτόπους πρόκειται να επισκεφθείτε.
    .label = DNS μέσω HTTPS
preferences-doh-description2 = Το DNS (Domain Name System) μέσω HTTPS στέλνει το αίτημά σας για όνομα τομέα μέσω κρυπτογραφημένης σύνδεσης, παρέχοντας ένα ασφαλές DNS και δυσκολεύοντας τους άλλους να δουν σε ποιον ιστότοπο πρόκειται να αποκτήσετε πρόσβαση.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Κατάσταση: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Πάροχος: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Μη έγκυρο URL
preferences-doh-steering-status = Χρήση τοπικού παρόχου
preferences-doh-status-active = Ενεργό
preferences-doh-status-disabled = Ανενεργό
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Μη ενεργό ({ $reason })
preferences-doh-group-message2 = Ενεργοποίηση DNS μέσω HTTPS χρησιμοποιώντας:
preferences-doh-radio-group =
    .aria-label = Ενεργοποίηση DNS μέσω HTTPS χρησιμοποιώντας:
preferences-doh-expand-section =
    .tooltiptext = Περισσότερες πληροφορίες
preferences-doh-setting-default =
    .label = Προεπιλεγμένη προστασία
    .accesskey = Π
preferences-doh-default-desc = Το { -brand-short-name } αποφασίζει πότε θα χρησιμοποιεί ασφαλές DNS για την προστασία του απορρήτου σας.
preferences-doh-default-detailed-desc-1 = Χρήση ασφαλούς DNS σε περιοχές όπου είναι διαθέσιμο
preferences-doh-default-detailed-desc-2 = Χρήση προεπιλεγμένης ανάλυσης DNS εάν υπάρχει πρόβλημα με τον πάροχο ασφαλούς DNS
preferences-doh-default-detailed-desc-3 = Χρήση τοπικού παρόχου εάν είναι δυνατόν
preferences-doh-default-detailed-desc-4 = Απενεργοποίηση όταν είναι ενεργό το VPN, ο γονικός έλεγχος ή οι εταιρικές πολιτικές
preferences-doh-default-detailed-desc-5 = Απενεργοποίηση όταν ένα δίκτυο ενημερώνει το { -brand-short-name } ότι δεν πρέπει να χρησιμοποιεί ασφαλές DNS
preferences-doh-setting-enabled =
    .label = Αυξημένη προστασία
    .accesskey = Α
preferences-doh-enabled-desc = Εσείς ελέγχετε πότε θα χρησιμοποιείται ασφαλές DNS και επιλέγετε τον πάροχό σας.
preferences-doh-enabled-detailed-desc-1 = Χρήση του παρόχου της επιλογής σας
preferences-doh-enabled-detailed-desc-2 = Χρήση προεπιλεγμένης ανάλυσης DNS μόνο εάν υπάρχει πρόβλημα με το ασφαλές DNS
preferences-doh-setting-strict =
    .label = Μέγιστη προστασία
    .accesskey = Μ
preferences-doh-strict-desc = Το { -brand-short-name } θα χρησιμοποιεί πάντα ασφαλές DNS. Θα βλέπετε μια προειδοποίηση πριν χρησιμοποιήσουμε το DNS του συστήματός σας.
preferences-doh-strict-detailed-desc-1 = Χρήση μόνο του παρόχου της επιλογής σας
preferences-doh-strict-detailed-desc-2 = Πάντα προειδοποίηση εάν το ασφαλές DNS δεν είναι διαθέσιμο
preferences-doh-strict-detailed-desc-3 = Εάν δεν διατίθεται ασφαλές DNS, οι ιστότοποι δεν θα φορτώνονται ή δεν θα λειτουργούν σωστά
preferences-doh-setting-off =
    .label = Ανενεργή προστασία
    .accesskey = Α
preferences-doh-off-desc = Χρήση προεπιλεγμένης ανάλυσης DNS
preferences-doh-select-resolver = Επιλογή παρόχου:
preferences-doh-manage-exceptions =
    .label = Διαχείριση εξαιρέσεων…
    .accesskey = χ
preferences-doh-overview-default =
    .description = Χρήση ασφαλούς DNS στις περιοχές όπου είναι διαθέσιμο.
    .label = Προεπιλεγμένη προστασία
preferences-doh-overview-custom =
    .description = Πάντα χρήση ασφαλούς DNS με δυνατότητα ελέγχου του παρόχου και της εφεδρικής συμπεριφοράς.
    .label = Προσαρμογή
preferences-doh-overview-off =
    .description = Χρήση της προεπιλεγμένης υπηρεσίας ανάλυσης DNS.
    .label = Ανενεργό
preferences-doh-advanced-button =
    .label = Σύνθετες ρυθμίσεις
preferences-doh-advanced-section =
    .description = Η λειτουργία «Σύστημα ονομάτων τομέων μέσω HTTPS» (DoH) κρυπτογραφεί τις αναζητήσεις ιστοτόπων, ώστε να είναι πιο δύσκολο για τον πάροχο διαδικτύου σας ή άλλα μέρη να βλέπουν ποιους ιστοτόπους πρόκειται να επισκεφθείτε.
    .label = Σύνθετες ρυθμίσεις
preferences-doh-manage-exceptions2 =
    .label = Διαχείριση εξαιρέσεων
    .accesskey = χ
preferences-doh-radio-default =
    .description = Χρήση ασφαλούς DNS στις περιοχές όπου είναι διαθέσιμο
    .label = Προεπιλογή
preferences-doh-radio-custom =
    .description = Πάντα χρήση ασφαλούς DNS με δυνατότητα ελέγχου του παρόχου και της εφεδρικής συμπεριφοράς
    .label = Προσαρμογή
preferences-doh-radio-off =
    .description = Χρήση της προεπιλεγμένης υπηρεσίας ανάλυσης DNS
    .label = Ανενεργό
preferences-doh-fallback-label =
    .label = Πάντα προειδοποίηση αν το ασφαλές DNS δεν είναι διαθέσιμο
preferences-doh-status-item-off =
    .message = Το DNS μέσω HTTPS είναι ανενεργό
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = Το DNS μέσω HTTPS δεν λειτουργεί επειδή αντιμετωπίσαμε σφάλμα ({ $reason }) κατά την προσπάθεια χρήσης του παρόχου { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = Το DNS μέσω HTTPS δεν λειτουργεί επειδή λάβαμε ένα μη έγκυρο URL ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = Το DNS μέσω HTTPS χρησιμοποιεί τον πάροχο { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = Το DNS μέσω HTTPS δεν λειτουργεί επειδή αντιμετωπίσαμε σφάλμα ({ $reason }) κατά την προσπάθεια χρήσης του τοπικού παρόχου { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = Το DNS μέσω HTTPS χρησιμοποιεί τον τοπικό πάροχο { $name }
preferences-doh-select-resolver-label =
    .label = Επιλογή παρόχου:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Χρήση αυτού του παρόχου για την ανάλυση DNS μέσω HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Εισαγάγετε ένα προσαρμοσμένο URL παρόχου
preferences-doh-header2 =
    .heading = DNS μέσω HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Ασφάλεια συνδέσεων και λογισμικού
preferences-connection-link-section =
    .description = Δείτε πώς παραμένουν ασφαλείς οι συνδέσεις, πώς αποκλείεται το επιβλαβές λογισμικό και πώς επαληθεύονται οι ιστότοποι.
    .label = Ασφάλεια συνδέσεων και λογισμικού
preferences-connection-link-button =
    .label = Σύνθετες ρυθμίσεις

## The following strings are used in the Download section of settings

desktop-folder-name = Επιφάνεια εργασίας
downloads-folder-name = Λήψεις

## Appearance page

preferences-appearance-header =
    .heading = Εμφάνιση
browser-theme-group =
    .description = Προσαρμόστε το στυλ του { -brand-short-name } ανάλογα με το προσωπικό σας γούστο. Τα χρώματα του θέματος εφαρμόζονται στις γραμμές εργαλείων, τα μενού και τα μηνύματα.
    .label = Θέμα προγράμματος περιήγησης
browser-theme-manage-link =
    .label = Διαχείριση των θεμάτων του { -brand-short-name }
appearance-window-density-group =
    .description = Προσαρμόστε την απόσταση γύρω από τα στοιχεία του παραθύρου, όπως η γραμμή εργαλείων, οι καρτέλες και η πλαϊνή γραμμή.
    .label = Πυκνότητα παραθύρου
appearance-window-density-radio-group =
    .aria-label = Πυκνότητα παραθύρου
appearance-window-density-automatic =
    .description = Επιλέγεται αυτόματα τυπική, πυκνή ή αραιή (για οθόνες αφής) προβολή
    .label = Αυτόματα (προεπιλογή)
appearance-window-density-automatic-no-touch =
    .description = Επιλέγεται αυτόματα τυπική ή πυκνή προβολή
    .label = Αυτόματα (προεπιλογή)
appearance-window-density-standard =
    .description = Ισορροπημένες αποστάσεις για τις περισσότερες οθόνες
    .label = Τυπική
appearance-window-density-auto-touch-mode =
    .label = Χρήση αραιής προβολής για τη λειτουργία tablet
appearance-window-density-compact =
    .description = Μειωμένες αποστάσεις για μικρότερες οθόνες
    .label = Πυκνή
appearance-window-density-touch =
    .description = Μεγαλύτερα στοιχεία παραθύρου και ενεργές περιοχές, βελτιστοποιημένα για οθόνες αφής
    .label = Αραιή
related-settings-group =
    .label = Σχετικές ρυθμίσεις
related-settings-accessibility-link =
    .label = Προσαρμογή ρυθμίσεων ζουμ και γραμματοσειράς στην ενότητα «Προσβασιμότητα»
related-settings-home-link =
    .label = Προσαρμογή { -firefox-home-brand-name(capitalization: "upper", case: "gen") }
related-settings-tabs-browsing-link =
    .label = Προσαρμογή διάταξης προγράμματος περιήγησης

## AI controls page

preferences-ai-controls-description = Το { -brand-short-name } δίνει πάντα την επιλογή σε εσάς, ακόμα κι όταν αφορά τη χρήση λειτουργιών που έχουν ενισχυθεί με τεχνητή νοημοσύνη. Σύντομα θα έχετε ακόμα περισσότερες επιλογές ελέγχου.
preferences-ai-controls-block-ai-label = Αποκλεισμός βελτιώσεων ΤΝ
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Ο αποκλεισμός σημαίνει ότι δεν θα βλέπετε νέες ή τρέχουσες βελτιώσεις τεχνητής νοημοσύνης στο { -brand-short-name }, ούτε αναδυόμενα παράθυρα σχετικά με αυτές. <a data-l10n-name="link">Μάθετε περισσότερες λεπτομέρειες</a> σχετικά με το τι περιλαμβάνει και τον τρόπο ελέγχου των παραδοσιακών λειτουργιών μηχανικής εκμάθησης, όπως είναι οι προτάσεις αναζήτησης και οι συστάσεις.
preferences-ai-controls-blocked-message =
    .message = Οι νέες και οι τρέχουσες βελτιώσεις τεχνητής νοημοσύνης αποκλείονται από προεπιλογή. Για να άρετε τον αποκλεισμό μιας συγκεκριμένης λειτουργίας, χρησιμοποιήστε τα παρακάτω κουμπιά ελέγχου.
preferences-ai-controls-on-device-group =
    .description = Αυτά χρησιμοποιούν μικρά μοντέλα τεχνητής νοημοσύνης που αποθηκεύονται στη συσκευή σας εφόσον χρησιμοποιείτε τη λειτουργία. Αυτή η προσέγγιση συμβάλλει στην προστασία του απορρήτου σας.
    .label = Τοπική ΤΝ
preferences-ai-controls-translations-control =
    .description = Περιηγηθείτε απρόσκοπτα στο διαδίκτυο, στην προτιμώμενη γλώσσα σας.
    .label = Μεταφράσεις
preferences-ai-controls-translations-more-link = Περισσότερες ρυθμίσεις μεταφράσεων
preferences-ai-controls-pdfjs-control =
    .description = Όταν προσθέτετε εικόνες σε αρχεία PDF, αυτή η επιλογή προσθέτει περιγραφές για λόγους προσβασιμότητας.
    .label = Εναλλακτικό κείμενο εικόνας στο εργαλείο προβολής PDF του { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Λάβετε προτάσεις για την ονομασία και την οργάνωση των καρτελών σας.
    .label = Προτάσεις ομάδων καρτελών
preferences-ai-controls-key-points-control =
    .description = Δείτε μια γρήγορη σύνοψη πριν από το άνοιγμα ενός συνδέσμου.
    .label = Kύρια σημεία στις προεπισκοπήσεις συνδέσμων
preferences-ai-controls-speech-recognition-control =
    .description = Τοπική μεταγραφή ομιλίας.
    .label = Αναγνώριση ομιλίας
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Διατηρήστε κοντά σας ένα chatbot κατά την περιήγηση. Επιλέξτε ανάμεσα σε πολλαπλούς παρόχους και κάντε εναλλαγή ανά πάσα στιγμή.
    .label = Πάροχοι chatbot ΤΝ στην πλαϊνή γραμμή
preferences-ai-controls-sidebar-chatbot-group =
    .description = Διατηρήστε ένα chatbot κοντά σας κατά την περιήγηση. Επιλέξτε ανάμεσα στα Anthropic Claude, ChatGPT, Copilot, Google Gemini και Le Chat Mistral.
    .label = Πάροχοι chatbot ΤΝ στην πλαϊνή γραμμή
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot στην πλαϊνή γραμμή
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Διαθέσιμο
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Ενεργό
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Αποκλεισμένο
preferences-ai-controls-state-description-before = Τι σημαίνουν οι επιλογές:
preferences-ai-controls-state-description-available = <strong>Διαθέσιμο:</strong> Θα βλέπετε τη λειτουργία και θα μπορείτε να τη χρησιμοποιήσετε.
preferences-ai-controls-state-description-enabled = <strong>Ενεργό:</strong> Έχετε επιλέξει να χρησιμοποιήσετε τη λειτουργία.
preferences-ai-controls-state-description-blocked = <strong>Αποκλεισμένο:</strong> Δεν μπορείτε να δείτε, ούτε να χρησιμοποιήσετε τη λειτουργία. Όσον αφορά την τοπική τεχνητή νοημοσύνη, αφαιρούνται τυχόν μοντέλα που έχουν ήδη ληφθεί.
preferences-ai-controls-block-confirmation-heading = Αποκλεισμός βελτιώσεων ΤΝ;
preferences-ai-controls-block-confirmation-description = Δεν θα βλέπετε τις νέες ή τρέχουσες βελτιώσεις τεχνητής νοημοσύνης στο { -brand-short-name }, ούτε αναδυόμενα παράθυρα σχετικά με αυτές. Μπορείτε μετέπειτα να άρετε τον αποκλεισμό όποιας λειτουργίας θέλετε να συνεχίσετε να χρησιμοποιείτε.
preferences-ai-controls-block-confirmation-features-start = Τι θα αποκλειστεί:
preferences-ai-controls-block-confirmation-translations = Μεταφράσεις
preferences-ai-controls-block-confirmation-pdfjs = Εναλλακτικό κείμενο εικόνας στο εργαλείο προβολής PDF του { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Προτάσεις ομάδων καρτελών
preferences-ai-controls-block-confirmation-key-points = Kύρια σημεία στις προεπισκοπήσεις συνδέσμων
preferences-ai-controls-block-confirmation-sidebar-chatbot = Πάροχοι chatbot στην πλαϊνή γραμμή
preferences-ai-controls-block-confirmation-speech-recognition = Αναγνώριση ομιλίας
preferences-ai-controls-block-confirmation-features-after = Ο αποκλεισμός επηρεάζει επίσης τις επεκτάσεις που χρησιμοποιούν τεχνητή νοημοσύνη που παρέχεται από το { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Ακύρωση
preferences-ai-controls-block-confirmation-confirm =
    .label = Αποκλεισμός
preferences-ai-controls-header3 =
    .heading = Επιλογές ελέγχου ΤΝ

## Privacy and security status card

security-privacy-status-ok-header = Το { -brand-short-name } είναι σε επιφυλακή
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = Το { -brand-short-name } προτείνει ορισμένες βελτιώσεις ασφαλείας
security-privacy-status-ok-label = Η Ενισχυμένη προστασία από καταγραφή είναι ενεργή
security-privacy-status-problem-label = Εντοπίσαμε ρυθμίσεις που επηρεάζουν την προστασία σας
security-privacy-status-problem-helper-label = Προβολή ζητημάτων
security-privacy-status-pending-trackers-label = Αναζήτηση του αριθμού των ιχνηλατών που απέκλεισε το { -brand-short-name } τον τελευταίο μήνα
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } αποκλεισμένος ιχνηλάτης τον τελευταίο μήνα
       *[other] { $trackerCount } αποκλεισμένοι ιχνηλάτες τον τελευταίο μήνα
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Διαθέτετε <a data-l10n-name="strict-tracking-protection">αυστηρή προστασία</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Διαθέτετε <a data-l10n-name="custom-tracking-protection">προσαρμοσμένη προστασία</a>
security-privacy-status-up-to-date-label = Διαθέτετε την πιο πρόσφατη και ασφαλή έκδοση του { -brand-short-name }
security-privacy-status-update-needed-label = Διατίθεται μια νέα έκδοση του { -brand-short-name }.
security-privacy-status-update-error-label = Το { -brand-short-name } αντιμετωπίζει πρόβλημα με την ενημέρωσή του
security-privacy-status-update-checking-label = Το { -brand-short-name } ελέγχει για ενημερώσεις
security-privacy-status-update-needed-description = Κάντε ενημέρωση για τις πιο πρόσφατες βελτιώσεις ταχύτητας, σταθερότητας και ασφάλειας.
security-privacy-status-update-button-label =
    .label = Ενημέρωση του { -brand-short-name }
security-privacy-image-warning =
    .alt = Μια ασπίδα με θαυμαστικό, που εκφράζει ανησυχία για τις προειδοποιήσεις ασφαλείας σας
security-privacy-image-ok =
    .alt = Μια ασπίδα με σημάδι ελέγχου, που δείχνει ότι δεν έχετε εκκρεμή ζητήματα ασφαλείας
security-privacy-issue-card =
    .heading = Προειδοποιήσεις ασφαλείας
issue-card-reset-button =
    .label = Επαναφορά
issue-card-dismiss-button =
    .aria-label = Απόρριψη
    .tooltiptext = Απόρριψη

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Οι ιστότοποι χρησιμοποιούν ιχνηλάτες για να σας ακολουθούν στο διαδίκτυο και να εμφανίζουν διαφημίσεις. Το { -brand-short-name } σάς προστατεύει κατά την περιήγησή σας, αποκλείοντας τους περισσότερους ιχνηλάτες αυτόματα, ώστε να έχετε τον έλεγχο των ψηφιακών σας ιχνών.
    .label = Ενισχυμένη προστασία από καταγραφή
preferences-etp-level-radio-group =
    .aria-label = Ενισχυμένη προστασία από καταγραφή
preferences-etp-level-standard =
    .description = Ισχυρή, αξιόπιστη προστασία που λειτουργεί ομαλά με τους περισσότερους ιστοτόπους.
    .label = Τυπική (προεπιλογή)
preferences-etp-level-strict =
    .description = Ισχυρότερη προστασία που αποκλείει περισσότερους ιχνηλάτες, αλλά ενδέχεται να προκαλέσει τη δυσλειτουργία ορισμένων ιστοτόπων.
    .label = Αυστηρή
preferences-etp-level-custom =
    .description = Επιλέξτε ποια μέτρα προστασίας θα (απ)ενεργοποιήσετε.
    .label = Προσαρμοσμένη
preferences-etp-status-advanced-button =
    .label = Σύνθετες ρυθμίσεις
preferences-etp-tracker-count-enabled =
    .label = Εμφάνιση αποκλεισμένων ιχνηλατών στη γραμμή διευθύνσεων
preferences-etp-status-protections-dashboard-link =
    .description = Δείτε πόσους ύπουλους ιχνηλάτες έχει αποκλείσει το { -brand-short-name } για εσάς, όπως ιχνηλάτες μέσων κοινωνικής δικτύωσης, fingerprinter και cryptominer.
    .label = Προβολή εξατομικευμένου πίνακα προστασίας
preferences-etp-header =
    .heading = Ενισχυμένη προστασία από καταγραφή
preferences-etp-advanced-settings-group =
    .description = Οι ιστότοποι χρησιμοποιούν ιχνηλάτες για να σας ακολουθούν στο διαδίκτυο και να εμφανίζουν διαφημίσεις. Το { -brand-short-name } σάς προστατεύει κατά την περιήγησή σας, αποκλείοντας τους περισσότερους ιχνηλάτες αυτόματα, ώστε να έχετε τον έλεγχο των ψηφιακών σας ιχνών.
    .label = Σύνθετες ρυθμίσεις
preferences-etp-customize-button =
    .label = Προσαρμογή προστασίας από καταγραφή
preferences-etp-reload-tabs-hint =
    .message = Φορτώστε εκ νέου τις καρτέλες σας για να εφαρμόσετε αυτές τις αλλαγές.
preferences-etp-reload-tabs-hint-button =
    .label = Επαναφόρτωση όλων των καρτελών
preferences-etp-rfp-warning-message =
    .message = Χρησιμοποιείτε το Resist Fingerprinting (RFP), το οποίο αντικαθιστά ορισμένες από τις ρυθμίσεις προστασίας του { -brand-short-name } ενάντια στο fingerprinting. Αυτό μπορεί να προκαλέσει δυσλειτουργίες σε ορισμένους ιστοτόπους.
preferences-etp-level-warning-message =
    .heading = Προσοχή! Ορισμένοι ιστότοποι ενδέχεται να μην λειτουργούν όπως πρέπει.
    .message = Ορισμένοι ιστότοποι ενσωματώνουν ιχνηλάτες στις λειτουργίες ή το περιεχόμενό τους. Όταν αυτοί αποκλείονται από το { -brand-short-name }, ο ιστότοπος δεν θα εμφανίζεται σωστά. Δοκιμάστε να χρησιμοποιήσετε την επιλογή «Διόρθωση ζητήματος ιστοτόπου» ή να απενεργοποιήσετε την προστασία από καταγραφή στον συγκεκριμένο ιστότοπο.
preferences-etp-manage-exceptions-button =
    .description = Διαχειριστείτε τους ιστοτόπους όπου η Ενισχυμένη προστασία από καταγραφή είναι ανενεργή.
    .label = Διαχείριση εξαιρέσεων
preferences-etp-customize-header =
    .heading = Προσαρμογή προστασίας από καταγραφή
preferences-etp-reset =
    .description = Επαναφορά των ρυθμίσεων στο προκαθορισμένο επίπεδο προστασίας.
    .label = Επαναφορά προσαρμογών
preferences-etp-reset-standard-button =
    .label = Επαναφορά στην τυπική
preferences-etp-reset-strict-button =
    .label = Επαναφορά στην αυστηρή
preferences-etp-custom-control-group =
    .description = Επιλέξτε ποια μέτρα προστασίας θέλετε να (απ)ενεργοποιήσετε.
    .label = Προστασία από καταγραφή
preferences-etp-custom-cookies-enabled =
    .label = Cookie
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookie
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Αποδοχή όλων των cookie
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Φραγή cookie καταγραφής μεταξύ ιστοτόπων
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Φραγή cookie μεταξύ ιστοτόπων
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Απομόνωση cookie μεταξύ ιστοτόπων
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Φραγή cookie από ιστοτόπους που δεν έχετε επισκεφθεί
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Φραγή όλων των cookie μεταξύ ιστοτόπων (πιθανή δυσλειτουργία ιστοτόπων)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Φραγή όλων των cookie (προκαλεί δυσλειτουργία ιστοτόπων)
preferences-etp-custom-tracking-protection-enabled =
    .label = Περιεχόμενο καταγραφής
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Περιεχόμενο καταγραφής
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Cryptominer
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Γνωστά fingerprinter
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Πιθανά fingerprinter
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Πιθανά fingerprinter

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Αυτό ενδέχεται να επιτρέπει σε ορισμένους ιχνηλάτες να σας ακολουθούν χωρίς cookie.
    .label = Τα γνωστά fingerprinter δεν αποκλείονται
security-privacy-issue-warning-third-party-cookies =
    .description = Τα cookie τρίτων χρησιμοποιούνται για την καταγραφή σας μεταξύ των ιστοτόπων.
    .label = Τα cookie τρίτων είναι ενεργά
security-privacy-issue-warning-password-manager =
    .description = Οι εφαρμογές διαχείρισης κωδικών πρόσβασης σάς βοηθούν να αποθηκεύετε ισχυρούς κωδικούς πρόσβασης για τους λογαριασμούς σας.
    .label = Η διαχείριση κωδικών πρόσβασης είναι ανενεργή
security-privacy-issue-warning-popup-blocker =
    .description = Τα αναδυόμενα παράθυρα διακόπτουν την περιήγησή σας και είναι δυνητικά επιβλαβή.
    .label = Η φραγή αναδυόμενων παραθύρων είναι ανενεργή
security-privacy-issue-warning-extension-install =
    .description = Οι ιστότοποι μπορούν να εγκαθιστούν επεκτάσεις στο { -brand-short-name } χωρίς να ζητούν την άδειά σας.
    .label = Οι ιστότοποι μπορούν να εγκαθιστούν επεκτάσεις
security-privacy-issue-warning-safe-browsing =
    .description = Η έκθεσή σας σε απάτες και κακόβουλο λογισμικό από ιστοτόπους είναι αυξημένη.
    .label = Το επικίνδυνο και παραπλανητικό περιεχόμενο δεν αποκλείεται
security-privacy-issue-warning-doh2 =
    .description = Το DNS μέσω HTTPS βοηθά στην απόκρυψη των ιστοτόπων που πρόκειται να επισκεφθείτε από τον πάροχο δικτύου σας.
    .label = Το DNS μέσω HTTPS είναι ανενεργό
security-privacy-issue-warning-ech2 =
    .description = Το Encrypted Client Hello βοηθά στην απόκρυψη των ιστοτόπων που πρόκειται να επισκεφθείτε από τον πάροχο δικτύου σας.
    .label = Το Encrypted Client Hello είναι ανενεργό
security-privacy-issue-warning-doh =
    .description = Το DNS μέσω HTTPS αποκρύπτει ποιους ιστοτόπους επισκέπτεστε από τον πάροχο δικτύου σας.
    .label = Το DNS μέσω HTTPS είναι ανενεργό
security-privacy-issue-warning-ech =
    .description = Το Encrypted Client Hello αποκρύπτει ποιους ιστοτόπους επισκέπτεστε από τον πάροχο δικτύου σας.
    .label = Το Encrypted Client Hello είναι απενεργοποιημένο
security-privacy-issue-warning-proxy-autodetection =
    .description = Η αυτόματη ρύθμιση διακομιστή μεσολάβησης θα μπορούσε να επιτρέψει σε αναξιόπιστα δίκτυα να παρακολουθήσουν τη δραστηριότητά σας.
    .label = Η αυτόματη ρύθμιση διακομιστή μεσολάβησης είναι ενεργή

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Προσκαλέστε κάποιον να επιλέξει το πρόγραμμα περιήγησης που δίνει προτεραιότητα στο απόρρητο.
    .label = Σύσταση του { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Σύσταση του { -brand-product-name }


pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = αλλαγές σε "about:config", λογικά ομαδοποιημένες και εύκολα προσβάσιμες
vorbit-header = Επιλογές του vOrbit-lite
vorbit-warning-title = Προσοχή!
vorbit-warning-description = Επιλέγουμε προσεκτικά τις προεπιλεγμένες ρυθμίσεις με επίκεντρο την ιδιωτιότητα και την ασφάλεια. Όταν αλλάζετε αυτές τις ρυθμίσεις, διαβάστε τις περιγραφές για να κατανοήσετε τις επιπτώσεις αυτών των αλλαγών.
vorbit-general-heading = Συμπεριφορά περιηγητή
vorbit-extension-update-checkbox =
    .label = Αυτόματη ενημέρωση επεκτάσεων
vorbit-autocopy-checkbox =
    .label = Ενεργοποίηση επικόλλησης με μεσαίο κλικ
vorbit-styling-checkbox =
    .label = Επιτρέψτε την προσαρμογή του userChrome.css
vorbit-network-heading = Δίκτυο
vorbit-privacy-heading = Ιδιωτικότητα
vorbit-webgl-checkbox =
    .label = Ενεργοποίηση WebGL
vorbit-rfp-checkbox =
    .label = Ενεργοποίηση ResistFingerprinting
vorbit-letterboxing-checkbox =
    .label = Ενεργοποίηση letterboxing
vorbit-security-heading = Ασφάλεια
vorbit-goog-safe-download-checkbox =
    .label = Σάρωση λήψεων
vorbit-extension-update-warning1 = Εαν δεν ελέγχετε τον κώδικα των επεκτάσεων σας πριν από κάθε ενημέρωση, θα πρέπει να ενεργοποιήσετε αυτή την επιλογή.
vorbit-ipv6-description = Επιτρέψτε στο { -brand-short-name } να συνδεθεί χρησιμοποιώντας IPv6.
vorbit-ocsp-description = Αποτρέψτε τη σύνδεση σε έναν ιστότοπο εάν ο έλεγχος OCSP δεν μπορεί να πραγματοποιηθεί.
vorbit-ocsp-warning1 = Αυτό αυξάνει την ασφάλεια, αλλά θα προκαλέσει βλάβη όταν ένας διακομιστής OCSP είναι εκτός λειτουργίας.
vorbit-sync-warning1 = Το Firefox Sync κρυπτογραφεί τα δεδομένα τοπικά πριν από τη μετάδοσή τους στον διακομιστή.
vorbit-styling-description = Ενεργοποιήστε το εάν θέλετε να προσαρμόσετε το UI με ένα θέμα που έχει φορτωθεί χειροκίνητα.
vorbit-extension-update-description = Διατηρήστε τις επεκτάσεις ενημερωμένες χωρίς χειροκίνητη παρέμβαση. Μία καλή επιλογή για την ασφάλειά σας.
vorbit-sync-checkbox =
    .label = Ενεργοποίηση Firefox Sync
vorbit-ipv6-checkbox =
    .label = Ενεργοποίηση IPv6
vorbit-ipv6-warning1 = Αντί να μπλοκάρετε το IPv6 στον περιηγητή, σας προτείνουμε να ενεργοποιήσετε την επέκταση απορρήτου IPv6 στο λειτουργικό σας σύστημα.
vorbit-sync-description = Συγχρονίστε τα δεδεομένα σας με άλλους περιηγητές. Απαιτεί επανεκκίνηση.
vorbit-autocopy-description = Επιλέξτε κάποιο κείμενο για να το αντιγράψετε και, στη συνέχεια, επικολλήστε το με ένα μεσαίο κλικ του ποντικιού.
vorbit-goog-safe-checkbox =
    .label = Ενεργοποίηση ασφαλούς πλοήγησης Google
content-blocking-section-top-level-description = Το vOrbit-lite υποστηρίζει - και ενεργοποιεί από προεπιλογή - την Ενισχυμένη Προστασία Παρακολούθησης (Enhanced Tracking Protection) στην Αυστηρή λειτουργία (Strict mode). Αυτή είναι μία από τις πιο σημαντικές ρυθμίσεις του περιηγητή, καθώς παρέχει καταμερισμό κατάστασης, αυστηρές λίστες αποκλεισμού και άλλες τακτοποιημένες λειτουργίες απορρήτου. Δεν συνιστούμε την αλλαγή σε άλλες λειτουργίες.
vorbit-styling-warning1 = Βεβεαιωθείτε ότι εμπιστεύεστε τον πάροχο του θέματος.
vorbit-xorigin-ref-warning1 = Αυτό μπορεί να προκαλέσει βλάβες. Επιπλέον, ακόμη και όταν αποστέλλονται παραπομπές θα εξακολουθούν να κόβονται.
vorbit-webgl-description = Το WebGL είναι ένας ισχυρός φορέας ψηφιακών αποτυπωμάτων.
vorbit-webgl-warning1 = Εάν χρειάζεται να το ενεργοποιήσετε, σκεφτείτε να χρησιμοποιήσετε μια επέκταση όπως το Canvas Blocker.
vorbit-rfp-description = Το ResistFingerprinting είναι το καλύτερο στην κατηγορία του εργαλείο κατά των ψηφιακών αποτυπωμάτων.
vorbit-rfp-warning1 = Εάν χρειάζεται να το απενεργοποιήσετε, σκεφτείτε να χρησιμοποιήσετε μια επέκταση όπως το Canvas Blocker.
vorbit-letterboxing-description = Το Letterboxing εφαρμόζει περιθώρια γύρω από τα παράθυρά σας, προκειμένου να επιστρέψει ένα περιορισμένο σύνολο στρογγυλεμένων αναλύσεων.
vorbit-xorigin-ref-checkbox =
    .label = Περιορισμός των παραπομπών πολλαπλής προέλευσης
vorbit-broken-heading = Fingerprinting (Ψηφιακά αποτυπώματα)
vorbit-ocsp-checkbox =
    .label = Επιβολή αυστηρής αποτυχίας OCSP
vorbit-xorigin-ref-description = Αποστολή παραπομπής μόνο στην ίδια προέλευση.
vorbit-goog-safe-download-description = Επιτρέψτε στην Ασφαλή περιήγηση (Safe Browsing) να σαρώσει τις λήψεις σας για να εντοπίσει ύποπτα αρχεία.
vorbit-goog-safe-download-warning1 = Όλοι οι έλεγχοι πραγματοποιούνται τοπικά.
vorbit-footer = Χρήσιμοι δύνδεσμοι
vorbit-config-link = Όλες οι προχωρημένες ρυθμίσεις (about:config)
vorbit-open-profile = Άνοιγμα φακέλου προφίλ χρήστη
vorbit-goog-safe-description = Εάν ανησυχείτε για το κακόβουλο λογισμικό και το phishing, σκεφτείτε να το ενεργοποιήσετε.
vorbit-goog-safe-warning1 = Απενεργοποιημένο λόγω ανησυχιών για λογοκρισία, αλλά συνιστάται για λιγότερο προχωρημένους χρήστες. Όλοι οι έλεγχοι γίνονται τοπικά.
