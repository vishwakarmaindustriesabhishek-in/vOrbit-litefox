# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Pyydä verkkosivustoja olemaan myymättä tai jakamatta tietojani
    .accesskey = s
non-technical-privacy-group =
    .label = Sivuston tietosuojakäytännöt
do-not-track-removal3 =
    .message = "Älä seuraa"-ominaisuus ei ole enää tuettu.
non-technical-privacy-heading =
    .label = Lisäsuojaukset
preferences-privacy-relay-available =
    .description = Piilottaa oikean sähköpostiosoitteesi ja pyrkii siten suojaamaan sähköpostiasi roskapostilta.
    .label = Ehdota { -relay-brand-name }-sähköpostimaskeja
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Asetukset
category-nav-heading =
    .heading = Asetukset
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Hae asetuksista
    .style = width: 15.4em
managed-notice = Organisaatiosi hallitsee selaimesi asetuksia.
managed-notice-info-icon =
    .alt = Tietoa
managed-notice-nav =
    .label = Organisaatiosi hallitsee selaimesi asetuksia.
tls-key-logging-notice-nav =
    .label = Sovellus tai palvelu saattaa nähdä salatun liikenteesi.
category-list =
    .aria-label = Luokat
pane-general-title = Yleiset
pane-home-title = Aloitussivu
pane-home-startup-title2 = Koti ja käynnistys
    .title = Koti ja käynnistys
pane-search-title2 = Haku
    .title = Haku
pane-privacy-title3 = Tietosuoja ja turvallisuus
    .title = Tietosuoja ja turvallisuus
pane-privacy-section =
    .heading = Tietosuoja ja turvallisuus
pane-sync-title3 = Synkronointi
pane-ai-controls-title2 = Tekoälyn säätimet
    .title = Tekoälyn säätimet
pane-about-firefox-title = Tietoja { -brand-short-name }ista
    .title = { pane-about-firefox-title }
pane-appearance-title = Ulkoasu
    .title = { pane-appearance-title }
pane-downloads-title2 = Lataukset
    .title = Lataukset
pane-downloads3 =
    .heading = Lataukset
pane-accessibility-title = Esteettömyys
    .title = { pane-accessibility-title }
pane-languages-title2 = Kielet
    .title = Kielet
preferences-languages-header3 =
    .heading = Kielet
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Kokeile kokeellisia ominaisuuksia! Ne ovat kehitysvaiheessa ja kehittyvät, mikä voi vaikuttaa { -brand-short-name }in toimintaan. Saamme tietoja näiden ominaisuuksien käytöstäsi vain, jos <a data-l10n-name="data-collection">tekniset ja vuorovaikutustiedot</a> ovat käytössä.
pane-experimental-reset =
    .label = Palauta oletukset
    .accesskey = P
help-button-label2 = { -brand-short-name }-tuki
    .title = { -brand-short-name }-tuki
addons-button-label2 = Laajennukset ja teemat
    .title = Laajennukset ja teemat
focus-search =
    .key = f
close-button =
    .aria-label = Sulje
do-not-track-removal2 =
    .label = "Älä seuraa"-signaali ei ole enää tuettu
applications-setting-new-file-types =
    .label = Mitä { -brand-short-name }in pitäisi tehdä muille tiedostoille?

## Browser Restart Dialog

feature-enable-requires-restart = { -brand-short-name } täytyy käynnistää uudestaan, jotta ominaisuus voidaan ottaa käyttöön.
feature-disable-requires-restart = { -brand-short-name } täytyy käynnistää uudestaan, jotta ominaisuus voidaan poistaa käytöstä.
should-restart-title = Käynnistä { -brand-short-name } uudestaan
should-restart-ok = Käynnistä { -brand-short-name } uudestaan nyt
cancel-no-restart-button = Peruuta
restart-later = Käynnistä uudestaan myöhemmin

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> hallitsee tätä asetusta.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> hallitsee tätä asetusta.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> vaatii eristettyjä välilehtiä.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> hallitsee tätä asetusta.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> hallitsee miten { -brand-short-name } yhdistää internetiin.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Ota laajennus käyttöön siirtymällä <img data-l10n-name="addons-icon"/> Lisäosat -sivulle <img data-l10n-name="menu-icon"/>-valikosta.
extension-controlled-enable-2 = Voit ottaa tämän laajennuksen uudelleen käyttöön <a data-l10n-name="addons-link">Laajennukset ja teemat</a> -sivulla.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } hallitsee joitakin etusivusi asetuksia.

## Preferences UI Search Results

search-results-header = Hakutulokset
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Ei hakutuloksia asetuksista haulle ”<span data-l10n-name="query"></span>”.
search-results-help-link = Tarvitsetko apua? Avaa <a data-l10n-name="url">{ -brand-short-name }-tuki</a>

## General Section

always-check-default =
    .label = Tarkista aina, onko { -brand-short-name } oletusselain
    .accesskey = i
startup-restore-windows-and-tabs =
    .label = Avaa aiemmat ikkunat ja välilehdet
    .accesskey = A
startup-windows-launch-on-login-profile-disabled =
    .message = Ota tämä asetus käyttöön valitsemalla "{ profile-manager-use-selected.label }" "Valitse käyttäjäprofiili"-ikkunassa.
windows-launch-on-login =
    .label = Avaa { -brand-short-name } automaattisesti, kun tietokoneesi käynnistyy
    .accesskey = O
windows-launch-on-login-disabled = Tämä asetus on poistettu käytöstä Windowsissa. Jos haluat muuttaa sitä, siirry kohtaan <a data-l10n-name="startup-link">Käynnistyssovellukset</a> asetuksissa.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Avaa myös uusi välilehti
    .accesskey = m
disable-extension =
    .label = Poista laajennus käytöstä
preferences-data-migration-group =
    .description = Tuo kirjanmerkit, salasanat, historia, laajennukset ja automaattisen täydennyksen tiedot toisesta selaimesta.
    .label = Tuo selaintiedot
preferences-data-migration-button =
    .label = Tuo tietoja
    .accesskey = T
preferences-profiles-group-header =
    .heading = Profiilit
preferences-profiles-subpane-description =
    .description = Jokaisella profiililla on erilliset selaustiedot ja -asetukset, mukaan lukien historia, salasanat ja paljon muuta.
preferences-profiles-section-header =
    .description = Jokaisella profiililla on erilliset selaustiedot ja -asetukset, mukaan lukien historia, salasanat ja paljon muuta.
    .label = Profiilit
preferences-manage-profiles-button =
    .label = Hallitse profiileja
preferences-profiles-settings-button =
    .label = Asetukset
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Uusi profiili kopioi asetukset, lisäosat, historian ja tallennetut tiedot kuten kirjanmerkit ja salasanat — mutta ei tiliäsi tai synkronointitietoja.
    .label = Kopioi olemassa oleva profiili
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Kopioitava profiili
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Valitse profiili
preferences-copy-profile-button = Kopioi
tabs-browsing-section =
    .heading = Välilehdet ja selaaminen
pane-tabs-browsing-title2 = Välilehdet ja selaaminen
    .title = Välilehdet ja selaaminen
tabs-group-header2 =
    .label = Välilehdet
tabs-opening-heading =
    .label = Avaaminen
tabs-interaction-heading =
    .label = Vuorovaikutus
tabs-containers-heading =
    .label = Eristetyt välilehdet
tabs-closing-heading =
    .label = Sulkeminen
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab selaa välilehtiä käyttöjärjestyksessä alkaen viimeisimmästä
    .accesskey = s
open-new-link-as-tabs =
    .label = Avaa linkit välilehtiin uusien ikkunoiden sijasta
    .accesskey = A
open-external-link-next-to-active-tab =
    .label = Avaa linkit sovelluksista aktiivisen välilehden viereen
ask-on-close-multiple-tabs =
    .label = Kysy ennen useiden välilehtien sulkemista
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Kysy ennen pikanäppäimellä { $quitKey } lopettamista
    .accesskey = ä
warn-on-open-many-tabs =
    .label = Varoita, kun useiden välilehtien avaaminen voi hidastaa { -brand-short-name }ia
    .accesskey = r
switch-to-new-tabs-2 =
    .label = Kun avaan linkkejä tai mediaa uudelle välilehdelle, siirry siihen välittömästi
    .accesskey = h
show-tabs-in-taskbar =
    .label = Näytä esikatselut välilehdistä Windowsin tehtäväpalkissa
    .accesskey = y
browser-containers-enabled-2 =
    .label = Käytä eristettyjä välilehtiä
    .accesskey = v
browser-containers-learn-more = Lue lisää
browser-containers-settings-2 =
    .label = Hallitse asetuksia
    .accesskey = i
containers-disable-alert-title = Suljetaanko kaikki eristetyt välilehdet?
startup-group =
    .label = Käynnistys

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Jos poistat eristetyt välilehdet käytöstä nyt, { $tabCount } eristetty välilehti suljetaan. Haluatko varmasti poistaa eristetyt välilehdet käytöstä?
       *[other] Jos poistat eristetyt välilehdet käytöstä nyt, { $tabCount } eristettyä välilehteä suljetaan. Haluatko varmasti poistaa eristetyt välilehdet käytöstä?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Sulje { $tabCount } eristetty välilehti
       *[other] Sulje { $tabCount } eristettyä välilehteä
    }

##

containers-disable-alert-cancel-button = Pidä käytössä
containers-remove-alert-title = Poistetaanko tämä eristystila?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Jos poistat tämän eristystilan nyt, { $count } eristetty välilehti suljetaan. Haluatko varmasti poistaa eristystilan?
       *[other] Jos poistat tämän eristystilan nyt, { $count } eristettyä välilehteä suljetaan. Haluatko varmasti poistaa eristystilan?
    }
containers-remove-ok-button = Poista eristystila
containers-remove-cancel-button = Älä poista eristystilaa
settings-tabs-show-image-in-preview =
    .label = Näytä kuvan esikatselu, kun siirrät hiiren välilehden päälle
    .accessKey = h
settings-tabs-drag-to-create-tab-groups =
    .label = Vedä välilehtiä yhteen luodaksesi välilehtiryhmiä
browser-layout-header2 =
    .label = Selaimen asettelu
browser-layout-horizontal-tabs2 =
    .description = Välilehdet ylhäällä
    .label = Vaakasuuntaiset välilehdet
    .title = Välilehdet ylhäällä
browser-layout-vertical-tabs2 =
    .description = Välilehdet sivupalkissa
    .label = Pystysuuntaiset välilehdet
    .title = Välilehdet sivupalkissa
browser-layout-show-sidebar2 =
    .description = Käytä nopeasti kirjanmerkkejä, välilehtiä, AI-chatbotteja ja paljon muuta poistumatta päänäkymästä.
    .label = Näytä sivupalkki
page-navigation-group =
    .label = Sivun navigointi

## General Section - Language & Appearance

language-and-appearance-header = Kieli ja ulkoasu
appearance-group2 =
    .description = Jotkin sivustot vaihtavat värejään vastatakseen mieltymystäsi. Valitse väriteema.
    .label = Verkkosivuston ulkoasu
preferences-web-appearance-choice-auto3 =
    .label = Järjestelmä
    .title = Vaihda automaattisesti sivustojen taustat ja sisältö pohjautuen järjestelmäsi asetuksiin ja { -brand-short-name }in teemaan.
preferences-web-appearance-choice-light2 =
    .label = Vaalea
    .title = Käytä vaaleaa ulkoasua verkkosivuston taustalle ja sisällölle.
preferences-web-appearance-choice-dark2 =
    .label = Tumma
    .title = Käytä tummaa ulkoasua verkkosivuston taustalle ja sisällölle.
web-appearance-group =
    .aria-label = Verkkosivuston ulkoasu
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Kontrastiasetukset ohittavat verkkosivuston ulkoasun.
preferences-web-appearance-link =
    .label = Hallinnoi { -brand-short-name }in teemoja Laajennukset ja teemat -osiossa
preferences-contrast-control-group =
    .description = Verkkosivustot käyttävät vaihtelevia edusta- ja taustavärejä. Yhtenäisen kontrastin vuoksi voit käyttää samoja värejä eri verkkosivustoilla.
    .label = Verkkosivuston kontrasti
preferences-contrast-control-radio-group =
    .label = Ohita värit
preferences-contrast-control-use-platform-settings =
    .label = Automaattinen (käytä järjestelmän asetuksia)
    .accesskey = A
preferences-contrast-control-off =
    .label = Pois päältä
    .accesskey = o
preferences-contrast-control-custom =
    .label = Mukautettu
    .accesskey = M
preferences-colors-manage-button2 =
    .label = Hallitse värejä
    .accesskey = ä
preferences-colors-manage-button =
    .label = Hallitse värejä…
    .accesskey = ä
preferences-fonts-header2 =
    .label = Kirjasimet
preferences-default-zoom-label =
    .label = Oletuskoko
    .accesskey = O
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage } %
preferences-zoom-text-only =
    .label = Muuta vain tekstin kokoa
    .accesskey = M
preferences-text-zoom-override-warning2 =
    .message = Jos ”Muuta vain tekstin kokoa” on käytössä ja oletusarvoinen koko ei ole 100 %, jotkin sivustot eivät välttämättä näytä sisältöä oikein.
language-header = Kieli
choose-language-description = Valitse kielet, joilla sivut näytetään
website-language-heading =
    .description = Jotkin sivustot esitetään useilla kielillä. Valitse kielet ensisijaisuusjärjestyksessä.
    .label = Verkkosivuston kieli
website-preferred-language =
    .label = Ensisijaiset kielet
website-language-list =
    .aria-label = Ensisijaiset kielet
website-add-language =
    .label = Lisää kieli
website-add-language-button =
    .aria-label = Lisää valittu kieli
    .title = Lisää valittu kieli
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Poista { $locale }
    .title = Poista { $locale }
choose-button =
    .label = Valitse…
    .accesskey = V
choose-browser-language-description = Valitse kielet, joilla { -brand-short-name }in valikot, viestit ja ilmoitukset näytetään.
manage-browser-languages-button =
    .label = Valitse lisäkielet…
    .accesskey = k
confirm-browser-language-change-description = Käytä näitä muutoksia käynnistämällä { -brand-short-name } uudestaan
confirm-browser-language-change-button = Käytä ja käynnistä uudestaan
browser-language-heading =
    .description = Valitse kieli, jolla { -brand-short-name }in valikot, viestit ja ilmoitukset näytetään.
    .label = Selaimen kieli
browser-language-preferred-label =
    .label = Ensisijainen kieli
browser-language-fallback-label =
    .description = Käytetään kun ensisijaisen kielen kotoistus on puutteellinen.
    .label = Varakieli
browser-language-install-error =
    .message = { -brand-short-name } ei voi päivittää kieliä juuri nyt. Varmista, että yhteys internetiin toimii tai yritä uudestaan.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Poikkeukset…
    .accesskey = i
settings-translations-header =
    .aria-label = Käännökset
    .description = Käännä sivuja tai valittu teksti. Yksityisyytesi suojaamiseksi käännökset pysyvät laitteellasi.
    .label = Käännökset
settings-translations-offer-to-translate-label =
    .label = Tarjoa koko sivun käännöstä
settings-translations-more-settings-button =
    .description = Määritä kieleen, verkkosivustoihin ja yhteydettömän tilan käännöksiin liittyvät asetukset.
    .label = Lisää käännösasetuksia
settings-translations-subpage-header =
    .heading = Lisää käännösasetuksia
settings-translations-subpage-speed-up-translation-header =
    .description = Lataa kokonaisia kieliä nopeampaa käännöstä ja yhteydettömässä tilassa tapahtuvaa käännöstä varten.
    .label = Nopeuta käännöstä
settings-translations-subpage-automatic-translation-header =
    .label = Automaattinen käännös
settings-translations-subpage-always-translate-header =
    .label = Käännä nämä kielet aina
settings-translations-subpage-never-translate-header =
    .label = Älä käännä koskaan näitä kieliä
settings-translations-subpage-never-translate-sites-header =
    .label = Älä käännä koskaan näitä sivustoja
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Lisää sivusto avaamalla <img data-l10n-name="translations-icon"/> käännöspaneeli, valitsemalla <img data-l10n-name="settings-icon"/> käännösasetukset ja valitsemalla ”Älä käännä tätä sivustoa koskaan”.
settings-translations-subpage-language-select-option =
    .label = Lisää kieli
settings-translations-subpage-language-add-button =
    .aria-label = Lisää kieli
    .title = Lisää kieli
settings-translations-subpage-download-languages-header =
    .label = Lataa kieliä
settings-translations-subpage-download-languages-select-option =
    .label = Valitse kieli
settings-translations-subpage-download-languages-button =
    .aria-label = Lataa kieli
    .title = Lataa kieli
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } Mt)
    .label = { $language } ({ $size } Mt)
settings-translations-subpage-no-languages-downloaded =
    .label = Kieliä ei ole ladattu
settings-translations-subpage-no-languages-added =
    .label = Kieliä ei ole lisätty
settings-translations-subpage-download-progress = Lataus käynnissä…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Ei voitu ladata kieltä { $language } ({ $size } Mt)
settings-translations-subpage-download-retry-button =
    .label = Yritä uudelleen
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Poistetaanko { $language } ({ $size } Mt)?
settings-translations-subpage-download-delete-button =
    .label = Poista
settings-translations-subpage-download-cancel-button =
    .label = Peruuta
settings-translations-subpage-no-sites-added =
    .label = Sivustoja ei ole lisätty
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Käytä käyttöjärjestelmän asetuksia alueelle ”{ $localeName }” muotoilemaan päivämäärät, kellonajat, luvut ja mittayksiköt.
settings-spellcheck-header =
    .label = Oikeinkirjoituksen tarkistus
check-user-spelling =
    .label = Oikolue käyttäjän kirjoitukset
    .accesskey = l
spellcheck-download-dictionaries =
    .label = Lataa oikolukusanastot
spellcheck-promo =
    .heading = Oikeinkirjoituksen tarkistuksen käyttö
    .message = Napsauta hiiren oikealla painikkeella tekstikenttää tarkistaaksesi oikeinkirjoituksen tai poistaaksesi sen käytöstä, tai vaihtaaksesi kieltä. Kaikki kentät eivät tue oikeinkirjoituksen tarkistusta.

## Downloads - Files and applications

files-and-applications-title = Tiedostot ja ohjelmat
download-save-files-header =
    .label = Tallenna kansioon
download-save-where-3 =
    .aria-label = Tallenna kansioon
download-always-ask-where2 =
    .label = Kysy ennen lataamista minne tiedostot tallennetaan
    .accesskey = K
download-private-browsing-delete2 =
    .label = Poista yksityisen ikkunan lataukset sulkemisen yhteydessä
    .accesskey = P
applications-header = Ohjelmat
applications-description = Valitse, miten { -brand-short-name } käsittelee verkosta lataamasi tiedostot tai verkkoa selatessa käyttämäsi ohjelmat.
applications-setting2 =
    .description = Valitse miten { -brand-short-name } käsittelee ladattuja tiedostoja ja sisältöä.
    .label = Tiedostot ja ohjelmat
applications-filter =
    .placeholder = Etsi tiedostotyyppejä tai ohjelmia
applications-type-column =
    .label = Sisältötyyppi
    .accesskey = S
applications-type-heading = Sisältötyyppi
applications-action-column =
    .label = Toiminto
    .accesskey = o
applications-action-heading = Toiminto
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension }-tiedosto
applications-action-save =
    .label = Tallenna tiedosto
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Käytä ohjelmaa { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Käytä ohjelmaa { $app-name } (oletus)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Käytä macOS:n oletussovellusta
            [windows] Käytä Windowsin oletussovellusta
           *[other] Käytä järjestelmän oletussovellusta
        }
applications-use-other =
    .label = Valitse uusi apuohjelma…
applications-select-helper = Valitse uusi apuohjelma
applications-manage-app =
    .label = Sovellusten tiedot…
applications-always-ask =
    .label = Kysy aina
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Avaa { -brand-short-name(case: "inessive") }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Mitä { -brand-short-name }in pitäisi tehdä muille tiedostoille?
applications-save-for-new-types =
    .label = Tallenna tiedostot
    .accesskey = s
applications-save-for-new-types2 =
    .label = Tallenna tiedostot automaattisesti
    .accesskey = a
applications-ask-before-handling =
    .label = Kysy avataanko vai tallennetaanko tiedostot
    .accesskey = A
applications-ask-before-handling2 =
    .label = Kysy tiedostojen avaamista tai tallentamista
    .accesskey = K
drm-group =
    .label = Käyttöoikeuksien hallintaa (DRM) käyttävä sisältö
play-drm-content =
    .label = Toista DRM-suojattua sisältöä
    .accesskey = D
play-drm-content-learn-more = Lue lisää
# Variables:
# $version (string) - Firefox version
update-application-version = Versio { $version } <a data-l10n-name="learn-more">Mitä uutta</a>
update-history-2 =
    .label = Näytä päivityshistoria
    .accesskey = N
update-application-installation =
    .label = Asennus
update-application-radio-group =
    .aria-label = Asennus
update-application-auto-2 =
    .label = Asenna päivitykset automaattisesti (suositus)
    .accesskey = A
update-application-check-choose-2 =
    .label = Tarkista päivitykset, mutta valitse asennusaika
    .accesskey = T
update-application-background-enabled =
    .label = Kun { -brand-short-name } ei ole käynnissä
    .accesskey = K
update-application-warning-cross-user-setting-2 =
    .message = Tämä asetus koskee kaikkia Windows-tilejä ja { -brand-short-name }-profiileja, jotka käyttävät tätä { -brand-short-name }-asennusta.
update-application-suppress-prompts-2 =
    .label = Näytä vähemmän päivitysmuistutuksia
    .accesskey = v
update-setting-write-failure-title2 = Päivitysasetusten tallennusvirhe
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } havaitsi virheen eikä tallentanut tätä muutosta. Huomaa, että tämän päivitysasetuksen muuttaminen vaatii oikeuden kirjoittaa alla olevaan tiedostoon. Sinä tai järjestelmän ylläpitäjä voi pystyä ratkaisemaan virheen antamalla täydet oikeudet tähän tiedostoon Käyttäjät-ryhmälle.
    
    Ei onnistuttu kirjoittamaan tiedostoon: { $path }
update-in-progress-title = Päivitys meneillään
update-in-progress-message = Haluatko, että { -brand-short-name } jatkaa tämän päivityksen asentamista?
update-in-progress-ok-button = &Hylkää
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Jatka

## About Firefox

about-firefox-header =
    .heading = Tietoja { -brand-short-name }ista

## Firefox updates

update-application-heading =
    .description = Päivitykset parantavat { -brand-short-name }in nopeutta, vakautta ja turvallisuutta.
    .label = { -brand-short-name }-päivitykset
update-application-suppress-prompts-heading =
    .label = Ilmoitukset
update-application-updates-managed-by-os =
    .message = Päivityksiä hallinnoi käyttöjärjestelmä

## Firefox support

support-application-heading =
    .description = Selvitä ongelmia tai jaa ideoita yhteisön kanssa.
    .label = { -brand-short-name }-tuki
support-get-help =
    .label = Tuki
support-share-ideas =
    .label = Jaa ideoita ja palautetta

## General Section - Performance

performance-settings-learn-more = Lue lisää
performance-allow-hw-accel =
    .label = Käytä laitteistokiihdytystä jos mahdollista
    .accesskey = K
performance-limit-content-process-option = Sisältöprosessien yläraja
    .accesskey = i
performance-limit-content-process-enabled-desc = Useammat sisältöprosessit parantavat suorituskykyä käytettäessä useita välilehtiä, mutta kuluttavat myös enemmän muistia.
performance-limit-content-process-blocked-desc = Sisältöprosessien määrän muokkaaminen on mahdollista vain useaa prosessia hyödyntävällä { -brand-short-name }illa. <a data-l10n-name="learn-more">Lue, miten usean prosessin hyödyntämisen tilanteen voi tarkistaa</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (oletus)
performance-group =
    .label = Suorituskyky
performance-use-recommended-settings-checkbox-2 =
    .description = Nämä asetukset on sovitettu laitteistollesi ja käyttöjärjestelmällesi.
    .label = Käytä suositeltuja suorituskykyasetuksia
    .accesskey = u

## Accessibility page

browsing-use-autoscroll =
    .label = Vieritä sivua automaattisesti
    .accesskey = V
keyboard-and-scrolling-group =
    .label = Näppäimistöllä liikkuminen ja vieritys
motion-and-link-group =
    .label = Liikkeen ja linkkien muotoilu
browsing-use-smooth-scrolling =
    .label = Vieritä sivua tasaisesti
    .accesskey = e
browsing-gtk-use-non-overlay-scrollbars =
    .label = Näytä aina vierityspalkit
    .accesskey = v
browsing-always-underline-links =
    .label = Alleviivaa linkit aina
    .accesskey = l
browsing-use-onscreen-keyboard =
    .label = Näytä kosketusnäppäimistö tarvittaessa
    .accesskey = N
browsing-use-cursor-navigation =
    .label = Liiku sivuilla nuolinäppäimillä
    .accesskey = s
browsing-use-full-keyboard-navigation =
    .label = Käytä sarkainnäppäintä siirtääksesi kohdistusta lomakkeen ohjauskontrollien ja linkkien välillä
    .accesskey = t
browsing-search-on-start-typing =
    .label = Ala etsiä tekstistä heti kirjoitettaessa
    .accesskey = A
settings-keyboard-shortcuts-group =
    .description = Määritä, miten liikut ja olet vuorovaikutuksessa { -brand-short-name }issa.
    .label = Pikanäppäimet
settings-keyboard-shortcuts-customkeys-link =
    .label = Mukauta pikanäppäimiä
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Mukauta osoiterivin asetuksia haussa
settings-media-group =
    .label = Media
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Käytä kuva kuvassa -toimintoa
    .accesskey = ä
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Jatka videoiden toistamista kuva kuvassa -tilassa välilehtiä vaihdettaessa
    .accesskey = s
browsing-media-control =
    .label = Ohjaa mediaa näppäimistön, kuulokemikrofonin tai virtuaalisen käyttöliittymän kautta
    .accesskey = O
recommendations-group =
    .label = Suositukset
browsing-cfr-recommendations =
    .label = Suosittele laajennuksia selaamisen yhteydessä
    .accesskey = S
browsing-cfr-features =
    .label = Suosittele ominaisuuksia selaamisen yhteydessä
    .accesskey = u
browsing-group =
    .label = Selaus
preferences-accessibility-header =
    .heading = Esteettömyys
preferences-default-zoom-select =
    .aria-label = Oletuskoko
preferences-fonts-family =
    .label = Kirjasinlaji
    .accesskey = K
preferences-fonts-size =
    .label = Kirjasinkoko
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = Lisäasetukset
    .accesskey = L

## General Section - Proxy

network-proxy-group2 =
    .description = Määritä miten { -brand-short-name } yhdistää Internetiin.
    .label = Välityspalvelimen asetukset
network-proxy-connection-settings2 =
    .description = Näiden asetusten muuttaminen saattaa aiheuttaa ongelmia yhteydessä
    .label = Määritä välityspalvelin
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Uudet ikkunat ja välilehdet
home-new-windows-tabs-description2 = Valitse, mitä näet kun avaat aloitussivun, uuden ikkunan tai uuden välilehden.
home-section =
    .heading = Koti ja käynnistys

## Home Section - Default Browser

home-default-browser-title =
    .label = Oletusselain
is-default-browser-2 =
    .message = { -brand-short-name } on oletusselaimesi. Hyvä valinta.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } ei ole oletusselaimesi.
set-as-my-default-browser-2 =
    .label = Aseta oletukseksi
    .accesskey = e

## Custom Homepage subpage

home-homepage-mode-label = Aloitussivu ja uudet ikkunat
home-newtabs-mode-label = Uudet välilehdet
home-restore-defaults =
    .label = Palauta oletukset
    .accesskey = P
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Oletus)
home-mode-choice-custom =
    .label = Omat osoitteet…
home-mode-choice-blank =
    .label = Tyhjä sivu
home-homepage-custom-url =
    .placeholder =
        { PLATFORM() ->
            [macos] Kirjoita tai sijoita osoite…
           *[other] Kirjoita tai liitä osoite…
        }
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Hallitse laajennusta
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Käytä avointa sivua
           *[other] Käytä avoimia sivuja
        }
    .accesskey = K
choose-bookmark =
    .label = Käytä kirjanmerkkiä…
    .accesskey = m
home-homepage-title =
    .label = Etusivu
home-homepage-new-windows =
    .label = Uudet ikkunat
home-homepage-new-tabs =
    .label = Uudet välilehdet
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Valitse tietty sivusto
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Verkkosivuston tai -sivustojen osoitteet
home-custom-homepage-list =
    .aria-label = Verkkosivustojen osoitteet
home-custom-homepage-address =
    .placeholder = Kirjoita osoite
home-custom-homepage-address-button =
    .label = Lisää osoite
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Ei vielä lisättyjä verkkosivustoja.
home-custom-homepage-delete-address-button =
    .aria-label = Poista osoite
    .title = Poista osoite
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Korvaa käyttäen
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = nyt avoinna olevia sivuja
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Kirjanmerkit…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Laajennus ({ $extension })
home-custom-homepage-header = Mukautettu etusivu
home-custom-homepage-subpage =
    .heading = Mukautettu etusivu

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name }n sisältö
home-prefs-content-description2 = Valitse mitä sisältöä haluat { -firefox-home-brand-name }lle.
home-prefs-search-header =
    .label = Verkkohaku
home-prefs-shortcuts-header =
    .label = Oikotiet
home-prefs-shortcuts-description = Tallentamasi tai vierailemasi sivustot
home-prefs-shortcuts-by-option-sponsored =
    .label = Sponsoroidut oikotiet
home-prefs-recommended-by-header-generic =
    .label = Suositellut tarinat
home-prefs-recommended-by-description-generic = Poikkeuksellista { -brand-product-name }-perheen kuratoimaa sisältöä
home-prefs-stories-header =
    .label = Tarinat
home-prefs-stories-description = Personoituja tarinoita aktiivisuuteesi pohjautuen

##

home-prefs-recommended-by-learn-more = Kuinka se toimii
home-prefs-recommended-by-option-sponsored-stories =
    .label = Sponsoroidut tarinat
home-prefs-highlights-option-visited-pages =
    .label = Vieraillut sivustot
home-prefs-highlights-options-bookmarks =
    .label = Kirjanmerkit
home-prefs-highlights-option-most-recent-download =
    .label = Viimeisimmät lataukset
home-prefs-recent-activity-header =
    .label = Viimeisin toiminta
home-prefs-recent-activity-description = Valikoima viimeisimpiä sivustoja ja sisältöä
home-prefs-weather-header =
    .label = Sää
home-prefs-weather-description = Tämän päivän ennuste yhdellä vilkaisulla
home-prefs-weather-learn-more-link = Lue lisää
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Tue { -brand-product-name }ia
home-prefs-mission-message = Sponsorimme tukevat tehtäväämme rakentaa parempaa Internetiä
home-prefs-mission-message-learn-more-link = Lue lisää
home-prefs-manage-topics-link = Hallinnoi aiheita
home-prefs-choose-wallpaper-link = Valitse taustakuva
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } rivi
           *[other] { $num } riviä
        }

## Search Section

search-show-suggestions-option =
    .label = Näytä hakuehdotukset
    .accesskey = S
search-show-suggestions-url-bar-option =
    .label = Näytä hakuehdotukset osoitepalkkihauissa
    .accesskey = o
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Näytä hakuehdotukset ennen selaushistoriaa osoitepalkin tuloksissa
search-show-suggestions-private-windows-2 =
    .label = Hakuehdotukset yksityisissä ikkunoissa
search-suggestions-cant-show-2 =
    .message = Hakuehdotuksia ei näytetä osoitepalkista tehtävistä hauista, koska olet valinnut, että { -brand-short-name } ei muista historiaa.
addressbar-header-1 =
    .description = Valitse osoiterivillä näkyvät ehdotukset
    .label = Osoitepalkki
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Ehdotuksia { -brand-short-name }ilta ja yhteistyökumppaneiltamme osoitepalkissasi.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Näytä hakuehdot tulossivujen osoitepalkissa
search-separate-default-engine-2 =
    .label = Käytä eri oletushakukonetta yksityisissä ikkunoissa
    .accesskey = u
search-separate-default-engine-dropdown =
    .aria-label = Oletushakukone yksityisissä ikkunoissa
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Osoiterivillä liikkuminen
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Ohita tulosvalikko, kun siirrät kohdistusta sarkainnäppäimellä
search-suggestions-header-2 =
    .label = Hakukoneen ehdotukset
search-one-click-header2 = Hakuoikotiet
search-one-click-desc = Valitse vaihtoehtoiset hakukoneet, jotka ilmestyvät osoite- ja hakupalkin alalaitaan, kun alat kirjoittaa hakusanoja.
search-one-click-header-3 =
    .description = Valitse mitkä hakukoneet ja oikotiet näkyvät osoitepalkissa.
    .label = Lisähakukoneet
search-engine-list =
    .aria-label = Hakukoneet ja pikavalinnat
update-search-engine-success =
    .message = Hakukone päivitetty onnistuneesti
search-edit-engine-2 =
    .title = Muokkaa hakukonetta
search-delete-engine =
    .title = Poista hakukone
search-enable-engine =
    .title = Ota hakukone käyttöön
search-outlink-to-extensions-page =
    .title = Hallitse laajennuksissa ja teemoissa
search-choose-engine-column =
    .label = Hakukone
search-choose-keyword-column =
    .label = Pikakomento
search-restore-default =
    .label = Palauta oletushakukoneet
    .accesskey = a
search-remove-engine =
    .label = Poista
    .accesskey = P
search-add-engine =
    .label = Lisää
    .accesskey = L
search-add-engine-2 =
    .label = Lisää hakukone
    .accesskey = a
search-edit-engine =
    .label = Muokkaa
    .accesskey = M
search-find-more-link = Etsi lisää hakukoneita
search-filtering-for-add-engine = Lisää hakukone
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Pikakomento jo käytössä
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Annettu pikakomento on jo kirjanmerkillä ”{ $name }”. Kirjoita uusi pikakomento.
search-keyword-warning-bookmark = Annettu pikakomento on jo toisella kirjanmerkillä. Kirjoita uusi pikakomento.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Hakukone nimeltä ”{ $name }” on jo olemassa. Valitse toinen nimi.
remove-engine-confirmation = Haluatko varmasti poistaa tämän hakukoneen?
remove-engine-remove = Poista
remove-addon-engine-alert = Poistaaksesi tämän hakukoneen, poista siihen liittyvä lisäosa.
search-engine-group =
    .label = Oletushakukone
search-default-engine =
    .aria-label = Oletushakukone
# Header for the search section ("search" is a noun).
search-section =
    .heading = Haku

## Containers Section

containers-section-header2 =
    .heading = Eristystilan asetukset
containers-card-header2 =
    .description = Eriytä evästeet eri eristystilojen avulla, niin voit käytttää eri käyttäjätilejä samalla sivustolla ja rajoittaa sivustorajat ylittävää seurantaa.
    .label = Eristystilat
containers-add-button2 =
    .label = Lisää uusi eristystila
    .accesskey = a
containers-list =
    .aria-label = Eristystilat
containers-new-tab-check3 =
    .label = Valitse eristystila jokaiselle uudelle välilehdelle
    .accesskey = s
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Älä käytä eristystiloja ulkoisista sovelluksista avatuille linkeille
    .accesskey = Ä
containers-new-tab-check2 =
    .description = Tämä avaa eristystilavalikon, kun napsautat uuden välilehden painiketta.
    .label = Valitse eristystila jokaiselle uudelle välilehdelle
    .accesskey = s
containers-settings-button2 =
    .title = Asetukset
containers-remove-button3 =
    .title = Poista
containers-sites-card-header =
    .description = Valitse sivustolle eristystila, niin { -brand-short-name } käyttää sitä aina, kun sivusto avautuu.
    .label = Sivustokohtaiset eristystilat
containers-sites-add-button =
    .label = Lisää verkkosivusto
    .accesskey = L
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Eristystila sivustolle { $site }
containers-site-remove-button =
    .title = Poista
containers-remove-button2 =
    .title = Poista

## Account and sync

sync-group-label =
    .label = Synkronointi
account-group-label2 =
    .label = Tili
account-disabled-group =
    .description = Tilin asetukset eivät ole käytettävissä.
    .label = Tili
account-placeholder2 =
    .description = Kirjaudu sisään ja pidä tietosi yksityisenä, salattuna ja välittömästi käyttövalmiina missä hyvänsä käytät { -brand-short-name }ia.
    .label = Et ole kirjautunut sisään
account-sync-section =
    .heading = Tili ja synkronointi
pane-account-sync-title2 = Tili ja synkronointi
    .title = Tili ja synkronointi

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Pidä oma selain aina mukanasi
sync-signedout-description2 = Synkronoi kirjanmerkit, sivuhistoria, välilehdet, salasanat, lisäosat ja asetukset kaikilla laitteillasi.
sync-signedout-account-signin3 =
    .label = Kirjaudu synkronoidaksesi…
    .accesskey = K
sync-signedout-account-signin-4 =
    .label = Kirjaudu tilillesi aloittaaksesi synkronoinnin
    .accesskey = i
sync-signedout-account-short =
    .label = Kirjaudu sisään
    .accesskey = i
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Lataa Firefox <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Androidille</a> tai <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS:lle</a> ja synkronoi tietosi kannettavalle laitteellesi.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Vaihda kuva
    .tooltiptext = Vaihda kuva
sync-profile-picture-account-problem =
    .alt = Tilin profiilikuva
fxa-login-rejected-warning =
    .alt = Varoitus
sync-sign-out =
    .label = Kirjaudu ulos…
    .accesskey = K
sync-sign-out2 =
    .label = Kirjaudu ulos
    .accesskey = K
sync-manage-account = Hallinnoi tiliä
    .accesskey = H
sync-manage-account2 =
    .label = Hallinnoi tiliä
    .accesskey = H

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = Sähköpostiosoitetta { $email } ei ole vahvistettu.
sync-signedin-unverified2 =
    .description = Tarkista postilaatikkosi vahvistaaksesi tilisi ja tehdäksesi siitä virallisen.
    .label = Sähköpostiosoitetta { $email } ei ole vielä vahvistettu
sync-signedin-login-failure = Kirjaudu sisään palauttaaksesi osoitteen { $email } yhteyden
sync-signedin-login-failure2 =
    .description = Kirjaudu uudelleen sisään käynnistääksesi tietojesi synkronoinnin.
    .label = Olet kirjautunut ulos tililtä { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Vahvista tili
    .accesskey = V
sync-remove-account =
    .label = Poista tili
    .accesskey = P
sync-sign-in =
    .label = Kirjaudu sisään
    .accesskey = r

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synkronointi: PÄÄLLÄ
prefs-syncing-on-2 =
    .label = Synkronointi on PÄÄLLÄ
prefs-syncing-off = Synkronointi: POIS PÄÄLTÄ
prefs-syncing-off-2 =
    .description = Ota synkronointi käyttöön saadaksesi kirjanmerkit, salasanat, historian ja paljon muuta mille tahansa laitteelle.
    .label = Synkronointi on POIS PÄÄLTÄ
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Ota synkronointi käyttöön, niin saat kirjanmerkit, salasanat, selaushistorian ja paljon muuta tälle laitteelle.
    .label = Synkronointi on POIS PÄÄLTÄ
prefs-sync-turn-on-syncing =
    .label = Ota synkronointi käyttöön…
    .accesskey = O
prefs-sync-turn-on-syncing-2 =
    .label = Ota synkronointi käyttöön
    .accesskey = O
prefs-sync-offer-setup-label2 = Synkronoi kirjanmerkit, sivuhistoria, välilehdet, salasanat, lisäosat ja asetukset kaikilla laitteillasi.
prefs-sync-now-button =
    .label = Synkronoi nyt
    .accesskey = N
prefs-sync-now-button-2 =
    .label = Synkronoi nyt
    .accesskey = N
prefs-syncing-button =
    .label = Synkronoidaan…
prefs-syncing-button-2 =
    .label = Synkronoidaan…
    .title = Synkronoi nyt
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Synkronointiasetuksesi koskevat nyt vain tätä laitetta.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Synkronoit näitä tietoja kaikkien yhdistettyjen laitteiden välillä:
sync-syncing-across-devices-heading-2 = Laitteiden välillä synkronoidut tiedot
sync-syncing-across-devices-heading-3 = Tietojen synkronointi tällä laitteella
sync-syncing-across-devices-empty-state2 =
    .description = Et synkronoi mitään… vielä. Aloita synkronointi saadaksesi kaikki tietosi kaikille laitteillesi.
    .label = Synkronoitujen tietojen hallinta
sync-syncing-across-devices-empty-state3 =
    .description = Et synkronoi vielä mitään… Valitse, mitä tällä laitteella synkronoidaan.
    .label = Hallinnoi synkronoituja tietoja
sync-currently-syncing-bookmarks = Kirjanmerkit
sync-currently-syncing-history = Historia
sync-currently-syncing-tabs = Avoimet välilehdet
sync-currently-syncing-passwords = Salasanat
sync-currently-syncing-addresses = Osoitteet
sync-currently-syncing-payment-methods = Maksutavat
sync-currently-syncing-addons = Lisäosat
sync-currently-syncing-settings = Asetukset
sync-manage-options =
    .label = Hallinnoi synkronointia…
    .accesskey = s
sync-manage-options-2 =
    .label = Synkronoitujen tietojen hallinta
    .accesskey = S
settings-sync-disconnect-button =
    .label = Katkaise yhteys

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Kirjanmerkit
    .accesskey = K
sync-engine-history =
    .label = Sivuhistoria
    .accesskey = S
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Avoimet välilehdet
    .tooltiptext = Avoimet välilehdet muilla laitteillasi
    .accesskey = A
sync-engine-tabs =
    .label = Avoimet välilehdet
    .tooltiptext = Lista kaikilla synkronoiduilla laitteilla auki olevista välilehdistä
    .accesskey = V
sync-engine-passwords =
    .label = Salasanat
    .tooltiptext = Tallentamasi salasanat
    .accesskey = T
sync-engine-addresses2 =
    .label = Osoitteet
    .tooltiptext = Osoitteet, jotka olet tallentanut { -brand-short-name }iin
    .accesskey = O
sync-engine-payment-methods3 =
    .label = Maksutavat
    .tooltiptext = Tallennetamasi maksutavat
    .accesskey = M
sync-engine-addons2 =
    .label = Lisäosat
    .tooltiptext = Laajennukset ja teemat, jotka olet lisännyt { -brand-short-name }in työpöytäsovellukseen
    .accesskey = L
sync-engine-settings2 =
    .label = Asetukset
    .tooltiptext = { -brand-short-name }in asetukset soveltuvin osin
    .accesskey = A
sync-engine-addresses =
    .label = Osoitteet
    .tooltiptext = Tallentamasi postiosoitteet (vain Firefoxin työpöytäversiossa)
    .accesskey = O
sync-engine-payment-methods2 =
    .label = Maksutavat
    .tooltiptext = Nimet, korttinumerot ja vanhenemispäivät
    .accesskey = M
sync-engine-addons =
    .label = Lisäosat
    .tooltiptext = Firefoxin työpöytäversion laajennukset ja teemat
    .accesskey = i
sync-engine-settings =
    .label = Asetukset
    .tooltiptext = Muuttamasi yleiset asetukset sekä tietosuoja- ja turvallisuusasetukset
    .accesskey = A
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Tallenna
    .buttonlabelextra2 = Katkaise yhteys…
    .buttonaccesskeyaccept = T
    .buttonaccesskeyextra2 = K
    .style = min-width: 36em;
    .title = Hallitse mitä kaikille yhdistetyille laitteillesi synkronoidaan
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Tallenna
    .buttonlabelextra2 = Katkaise yhteys…
    .buttonaccesskeyaccept = T
    .buttonaccesskeyextra2 = K
    .style = min-width: 36em;
    .title = Hallinnoi laitteelle synkronoitavia asioita

## The device name controls.

sync-device-name-header = Laitteen nimi
sync-device-name-header-2 =
    .label = Laitteen nimi
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Laitteen nimi
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Muuta laitteen nimeä
    .accesskey = M
sync-device-name-change =
    .label = Muuta laitteen nimeä…
    .accesskey = M
sync-device-name-cancel =
    .label = Peruuta
    .accesskey = P
sync-device-name-save =
    .label = Tallenna
    .accesskey = T
sync-connect-another-device = Yhdistä toinen laite
sync-connect-another-device-2 =
    .label = Yhdistä toinen laite

## Privacy Section

privacy-header = Selaimen tietosuoja

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Salasanat
    .searchkeywords = kirjautumistiedot
forms-passwords-header =
    .aria-label = Salasanat
    .label = Salasanat
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Kysy salasanojen tallentamisesta
    .accesskey = a
forms-manage-password-exceptions =
    .label = Hallinnoi salasanapoikkeuksia
    .accesskey = k
forms-exceptions =
    .label = Poikkeukset…
    .accesskey = e
forms-suggest-passwords =
    .label = Ehdota vahvoja salasanoja
    .accesskey = s
forms-breach-alerts =
    .label = Näytä hälytykset salasanoista sivustoille, jotka ovat kokeneet tietomurron
    .accesskey = h
forms-breach-alerts-learn-more-link = Lue lisää
preferences-relay-integration-checkbox2 =
    .label = Ehdota { -relay-brand-name } -sähköpostimaskeja sähköpostiosoitteen suojaamiseksi
    .accesskey = h
relay-integration-learn-more-link = Lue lisää
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Täytä käyttäjätunnukset ja salasanat automaattisesti
    .accesskey = ä
forms-fill-usernames-and-passwords-2 =
    .label = Tallenna ja täytä käyttäjätunnukset sekä salasanat automaattisesti
    .accesskey = T
forms-saved-passwords =
    .label = Tallennetut salasanat
    .accesskey = s
forms-saved-passwords-2 =
    .label = Hallinnoi tallennettuja salasanoja
    .accesskey = s
forms-saved-passwords-searchkeywords = Seuraavien sivustojen kirjautumistiedot ovat tallennettuna tietokoneellesi
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Lisäsuojaukset
forms-primary-pw-use =
    .label = Käytä pääsalasanaa
    .accesskey = K
forms-primary-pw-use-2 =
    .description = Lisää kerroksen turvallisuutta tallennettujen salasanojesi suojaamiseksi.
    .label = Käytä pääsalasanaa
    .accesskey = K
forms-primary-pw-set =
    .label = Aseta pääsalasana
forms-primary-pw-on-2 = Pääsalasana on <strong>KÄYTÖSSÄ</strong>
forms-primary-pw-on =
    .label = Pääsalasana on KÄYTÖSSÄ
forms-primary-pw-change-2 =
    .label = Vaihda pääsalasana
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Poista se käytöstä
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Vaadi laitteen sisäänkirjautuminen salasanojen täyttämistä ja hallintaa varten
forms-os-reauth-2 =
    .label = Vaadi laitteen sisäänkirjautuminen salasanojen hallintaa varten
forms-primary-pw-learn-more-link = Lue lisää
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Muuta pääsalasanaa…
    .accesskey = M
forms-primary-pw-change =
    .label = Vaihda pääsalasana…
    .accesskey = V
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Olet parhaillaan FIPS-tilassa. FIPS edellyttää, että pääsalasana ei ole tyhjä.
forms-master-pw-fips-desc = Salasanan vaihto epäonnistui
forms-windows-sso =
    .label = Salli Windowsin kertakirjautuminen Microsoft-, työ- ja koulutileille.
forms-windows-sso-learn-more-link = Lisätietoja
forms-windows-sso-desc = Hallinnoi tilejä laitteen asetuksissa
windows-passkey-settings-label = Hallitse todentamisavaimia järjestelmän asetuksissa
privacy-panel-settings-header =
    .description = Apua tietojesi suojaamiseksi verkossa { -brand-short-name }issa.
    .label = Tietosuojapaneelin asetukset
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Näytä tietomurtoilmoitukset
    .accesskey = ä

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Luo pääsalasana kirjoittamalla Windows-kirjautumistietosi. Tämä auttaa suojaamaan tilejäsi.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = asettaa pääsalasanan
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] muuttaa maksutapojen asetuksia
       *[other] { -brand-short-name } yrittää muuttaa maksutapojen asetuksia. Käytä laitteen sisäänkirjautumista salliaksesi tämän.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Maksutavat
autofill-payment-methods-checkbox-message-2 =
    .label = Tallenna ja täytä maksutiedot automaattisesti
    .accesskey = ä
autofill-payment-methods-manage-payments-title =
    .heading = Hallinnoi maksutapoja
autofill-payment-methods-manage-payments-button =
    .label = Hallitse maksutapoja
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Vaadi laitteen kirjautuminen automaattiseen täyttöön
    .accesskey = V
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Vaadi laitekirjautuminen maksutapojen automaattiseen täyttöön ja hallintaan
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Tallenna turvakoodit
    .accesskey = T
autofill-payment-methods-add-button = Lisää uusi maksutapa
payments-list-header =
    .label = Maksutavat
payments-delete-payment-prompt-title = Poistetaanko tämä maksutapa?
payments-delete-payment-prompt-confirm-button = Poista
payments-delete-payment-prompt-cancel-button = Peruuta
payments-delete-payment-button-label =
    .aria-label = Poista
payments-edit-payment-button-label =
    .aria-label = Muokkaa
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Maksutapoja ei ole lisätty
autofill-addresses-checkbox-message =
    .label = Tallenna ja täytä osoitteet automaattisesti
    .accesskey = s
autofill-addresses-manage-addresses-button =
    .label = Hallitse osoitteita ja muuta
    .accesskey = m
addresses-list-header =
    .label = Osoitteet
addreses-delete-address-button-label =
    .aria-label = Poista
addreses-edit-address-button-label =
    .aria-label = Muokkaa
addresses-delete-address-prompt-title = Poistetaanko tämä osoite?
addresses-delete-address-prompt-confirm-button = Poista
addresses-delete-address-prompt-cancel-button = Peruuta
autofill-addresses-add-button = Lisää uusi osoite
autofill-addresses-manage-addresses-title =
    .heading = Hallitse osoitteita ja muuta
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Osoitteita ei ole lisätty
personal-info-group =
    .label = Henkilökohtaiset tiedot
autofill-personal-info-checkbox-message =
    .label = Tallenna ja täytä henkilökohtaiset tiedot automaattisesti
autofill-personal-info-manage-button =
    .label = Hallinnoi henkilötietoja
passports-list-header =
    .label = Passit
passports-delete-passport-button-label =
    .aria-label = Poista
passports-edit-passport-button-label =
    .aria-label = Muokkaa
passports-delete-passport-prompt-title = Poistetaanko tämä passi?
passports-delete-passport-prompt-confirm-button = Poista
passports-delete-passport-prompt-cancel-button = Peruuta
autofill-passports-add-button = Lisää uusi passi
autofill-personal-info-manage-title =
    .heading = Hallinnoi henkilötietoja
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Passeja ei ole lisätty
pane-passwords-autofill-title2 = Salasanat ja automaattinen täyttö
    .title = Salasanat ja automaattinen täyttö
preferences-passwords-autofill-header =
    .heading = Salasanat ja automaattinen täyttö
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Osoitteita ja muuta
payments-group =
    .label = Maksutavat

## Privacy Section - History

history-remember-option-never2 =
    .description = Jokainen ikkuna käyttäytyy kuin yksityinen ikkuna. Kun käytössä, laajennukset tulee olla sallittu.
    .label = Älä koskaan muista sivuhistoriaa
history-remember-option-custom2 =
    .label = Mukauta sivuhistoriaa
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } kerää ja säilyttää selaus-, lataus-, lomake- ja hakuhistorian.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } toimii aina kuten yksityisessä selaustilassa, eikä säilytä mitään historiatietoja.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } käyttää mukautettuja asetuksia selaus-, lataus-, lomake- ja hakuhistoriaa varten.
history-private-browsing-permanent =
    .label = Selaa aina yksityinen selaus -tilassa
    .accesskey = y
history-remember-browser-option =
    .label = Säilytä selaushistoria ja tieto latauksista
    .accesskey = ä
history-remember-search-option =
    .label = Säilytä lomakkeiden ja hakupalkin tiedot
    .accesskey = d
history-clear-on-close-option =
    .label = Poista historiatiedot kun { -brand-short-name } suljetaan
    .accesskey = o
history-clear-on-close-settings =
    .label = Asetukset…
    .accesskey = u
history-shutdown-exceptions =
    .label = Hallitse poikkeuksia
    .accesskey = p
history-clear-button =
    .label = Tyhjennä historia…
    .accesskey = T
history-header2 =
    .heading = Sivuhistoria
history-section-header =
    .description = Valitse mitä haluat { -brand-short-name }in muistavan, kun suljet selaimen.
    .label = Sivuhistoria
history-custom-section-header =
    .description = Mukauta mitä haluat { -brand-short-name }in muistavan, kun suljet selaimen.
    .label = Lisäasetukset
history-custom-button =
    .label = Valitse mitä haluat { -brand-short-name }in muistavan
history-group =
    .label = Historiatiedot
history-mode-radio-group =
    .aria-label = Historiatiedot
history-remember-option-all2 =
    .label = Muista historia

## Privacy Section - Site Data

sitedata-total-size-calculating = Lasketaan sivustotietojen ja välimuistin kokoa…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Verkkosivustot käyttävät tällä hetkellä <strong>{ $value } { $unit }</strong> levytilaa.
sitedata-learn-more = Lue lisää
sitedata-delete-on-close2 =
    .label = Tyhjennä evästeet ja sivustotiedot aina, kun suljet { -brand-short-name }in
    .accesskey = ä
sitedata-delete-on-close-private-browsing3 =
    .message = Historia-asetustesi perusteella { -brand-short-name } poistaa evästeet ja sivustotiedot istunnostasi, kun suljet selaimen.
sitedata-delete-on-close-private-browsing4 =
    .heading = Historiaa ei tallenneta.
    .message = { -brand-short-name } tyhjentää istunnon aikana kertyneet evästeet ja sivustotiedot, kun suljet selaimen.
sitedata-option-block-cross-site-trackers =
    .label = Sivustorajat ylittävät seuraimet
sitedata-option-block-cross-site-tracking-cookies =
    .label = Sivustorajat ylittävät seurainevästeet
sitedata-option-block-cross-site-cookies2 =
    .label = Eristä sivustorajat ylittävät evästeet
sitedata-option-block-unvisited =
    .label = Evästeet vierailemattomilta sivustoilta
sitedata-option-block-all-cross-site-cookies =
    .label = Kaikki sivustorajat ylittävät evästeet (voi aiheuttaa sivustojen toimimattomuutta)
sitedata-option-block-all =
    .label = Kaikki evästeet (aiheuttaa sivustovirheitä)
sitedata-clear2 =
    .label = Tyhjennä selaustiedot
    .accesskey = y
sitedata-settings2 =
    .label = Hallitse selaustietoja
    .accesskey = j
sitedata-cookies-exceptions =
    .label = Hallitse poikkeuksia…
    .accesskey = p
sitedata-cookies-exceptions2 =
    .description = Voit määrittää, mitkä verkkosivustot voivat aina tai ei koskaan käyttää evästeitä ja sivustotietoa.
    .label = Hallitse poikkeuksia
    .accesskey = k
sitedata-heading =
    .description = Hallitse evästeitä, sivuhistoriaa, välimuistia, verkkosivustojen tietoja ja paljon muuta.
    .label = Selaustiedot
sitedata-settings3 =
    .label = Tyhjennä tiettyjen sivustojen tiedot
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Valitse miten tietyt sivustot käsittelevät evästeitä ja sivustotietoa.
    .label = Hallitse poikkeuksia
    .accesskey = p
cookies-site-data-group =
    .label = Evästeet ja sivustotiedot

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Evästeilmoitusten esto
cookie-banner-blocker-description = Kun sivusto kysyy, voiko se käyttää evästeitä yksityisessä selaustilassa, { -brand-short-name } kieltäytyy automaattisesti puolestasi. Vain tuetuilla sivustoilla.
cookie-banner-learn-more = Lue lisää
cookie-banner-blocker-checkbox-label =
    .label = Kieltäydy automaattisesti evästeilmoituksista

## Search Section

addressbar-locbar-history-option =
    .label = selaushistoriasta
    .accesskey = h
addressbar-locbar-bookmarks-option =
    .label = kirjanmerkeistä
    .accesskey = k
addressbar-locbar-clipboard-option =
    .label = Leikepöytä
    .accesskey = L
addressbar-locbar-openpage-option =
    .label = avoimista välilehdistä
    .accesskey = a
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = oikoteistä
    .accesskey = o
addressbar-locbar-topsites-option =
    .label = ykkössivustoista
    .accesskey = y
addressbar-locbar-engines-option-1 =
    .label = Ehdota hakukoneita käytettäväksi
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = Pikatoiminnot
    .accesskey = Q
addressbar-locbar-showrecentsearches-option-2 =
    .label = Viimeisimmät haut
    .accesskey = V
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Nousussa olevat hakuehdotukset
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Hanki hakuusi liittyviä ehdotuksia verkosta.
    .label = Ehdotuksia palvelusta { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Tue { -brand-short-name }ia satunnaisilla sponsoroiduilla ehdotuksilla.
    .label = Ehdotuksia sponsoreilta
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Vastaanota ehdotuksia Mozillasta kirjoittaessasi
addressbar-dismissed-suggestions-label-2 =
    .description = Palauta sponsorien ja { -brand-short-name }in hylätyt ehdotukset.
    .label = Hylätyt ehdotukset
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Palauta ehdotukset

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Tehostettu seurannan suojaus
content-blocking-section-top-level-description = Seuraimet seuraavat sinua verkossa ja keräävät tietoja selaustapoihisi ja kiinnostuksen kohteisiisi liittyen. { -brand-short-name } estää monet näistä seuraimista ja muita haitallisia komentosarjoja.
content-blocking-learn-more = Lue lisää
content-blocking-fpi-incompatibility-warning = Käytät ensimmäisen osapuolen eristämistä (FPI), joka korvaa joitain { -brand-short-name }in evästeasetuksista.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Käytät Resist Fingerprinting (RFP) -toimintoa, joka korvaa osan { -brand-short-name }in yksilöinnin suojausasetuksista. Tämä saattaa aiheuttaa joidenkin sivustojen rikkoutumisen.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Tavallinen
    .accesskey = T
enhanced-tracking-protection-setting-strict =
    .label = Tiukka
    .accesskey = u
enhanced-tracking-protection-setting-custom =
    .label = Mukautettu
    .accesskey = M

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Tasapainotettu suojauksen ja suorituskyvyn välillä. Sivut latautuvat normaalisti.
content-blocking-etp-strict-desc = Vahvempi suojaus, mutta saattaa aiheuttaa sivustojen tai sisällön toimimattomuutta.
content-blocking-etp-custom-desc = Valitse, mitkä seuraimet ja komentosarjat estetään.
content-blocking-etp-blocking-desc = { -brand-short-name } estää seuraavat:
content-blocking-private-windows = Seurantaan tarkoitettu sisältö yksityisissä ikkunoissa
content-blocking-cross-site-cookies-in-all-windows2 = Sivustorajat ylittävät evästeet kaikissa ikkunoissa
content-blocking-cross-site-tracking-cookies = Sivustorajat ylittävät seurainevästeet
content-blocking-all-cross-site-cookies-private-windows = Sivustorajat ylittävät evästeet yksityisissä ikkunoissa
content-blocking-isolate-cross-site-cookies = Eristä sivustorajat ylittävät evästeet
content-blocking-social-media-trackers = Sosiaalisen median seuraimet
content-blocking-all-cookies = Kaikki evästeet
content-blocking-unvisited-cookies = Evästeet sivustoilta, joilla ei ole käyty
content-blocking-all-windows-tracking-content = Seurantaan tarkoitettu sisältö kaikissa ikkunoissa
content-blocking-all-cross-site-cookies = Kaikki sivustorajat ylittävät evästeet
content-blocking-cryptominers = Kryptolouhijat
content-blocking-fingerprinters = Yksilöijät
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Tunnetut ja epäillyt yksilöijät
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Totaalinen evästesuoja eristää evästeet sivustolle, jolla olet, joten seuraimet eivät voi käyttää niitä seurantaan sivustojen välillä.
content-blocking-etp-standard-tcp-rollout-learn-more = Lue lisää
content-blocking-etp-standard-tcp-title = Sisältää totaalisen evästesuojan, kaikkien aikojen tehokkaimman tietosuojaominaisuuden
content-blocking-warning-title-2 = Jotkin sivustot saattavat rikkoutua tiukalla seurannan suojauksella
content-blocking-warning-title-custom = Jotkin sivustot saattavat rikkoutua mukautetulla seurannan suojauksella
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } suosittelee käyttämään ”Korjaa sivuston ongelmat”-asetuksia sivuston rikkinäisten ominaisuuksien ja sisällön vähentämiseksi. Jos sivusto vaikuttaa rikkinäiseltä, kokeile poistaa seurantasuojaus käytöstä kyseiseltä sivustolta, jotta kaikki sisältö latautuu.
content-blocking-warning-learn-how = Lue lisää
content-blocking-baseline-exceptions-3 =
    .description = Auttaa lataamaan sivustoja ja ominaisuuksia poistamalla estoja vain tärkeiltä elementeiltä, jotka saattavat sisältää seuraimia. Kattaa yleisimmät ongelmat.
    .label = Korjaa merkittävät sivuston ongelmat (suositus)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Palauttaa esimerkiksi videot artikkelissa tai kommenttiosiot poistamalla mahdollisesti seuraimia sisältävien elementtien eston. Tämä voi vähentää sivuston ongelmia, mutta tarjoaa vähemmän suojaa. On käytettävä korjausten kanssa merkittävissä ongelmissa.
    .label = Korjaa pienet sivuston ongelmat
content-blocking-baseline-uncheck-warning-dialog-title = Haluatko varmasti poistaa korjaukset käytöstä?
content-blocking-baseline-uncheck-warning-dialog-body = Tämä asetus auttaa korjaamaan yleisimpiä sivusto-ongelmia. Jos poistat sen käytöstä, jotkin sivustot eivät välttämättä toimi, eikä { -brand-short-name } pysty auttamaan näiden ongelmien vianmäärityksessä.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Poista korjaukset käytöstä
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Pidä korjaukset käytössä
content-blocking-reload-description = Kaikki välilehdet tarvitsee päivittää, jotta muutokset tulevat voimaan.
content-blocking-reload-tabs-button =
    .label = Päivitä kaikki välilehdet
    .accesskey = P
content-blocking-tracking-content-label =
    .label = Seurantaan tarkoitettu sisältö
    .accesskey = S
content-blocking-tracking-protection-option-all-windows =
    .label = Kaikissa ikkunoissa
    .accesskey = K
content-blocking-option-private =
    .label = Vain yksityisissä ikkunoissa
    .accesskey = V
content-blocking-cookies-label =
    .label = Evästeet
    .accesskey = E
content-blocking-expand-section =
    .tooltiptext = Lisätietoja
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Kryptolouhijat
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Tunnetut yksilöijät
    .accesskey = K
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Epäillyt yksilöijät
    .accesskey = S

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Hallitse poikkeuksia…
    .accesskey = p

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Älä näytä ilmoituksia ennen kuin { -brand-short-name } uudelleenkäynnistetään
    .accesskey = k
permissions-autoplay2 =
    .label = Automaattinen toisto
permissions-block-popups2 =
    .label = Estä ponnahdusikkunat ja kolmannen osapuolen uudelleenohjaukset
    .accesskey = ä
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Lisää verkkosivustoja, jotka voivat avata ponnahdusikkunoita ja käyttää kolmannen osapuolen uudelleenohjauksia.
    .label = Hallitse poikkeuksia
    .searchkeywords = ponnahdukset
    .accesskey = e
permissions-addon-install-warning3 =
    .label = Näytä varoitus, kun verkkosivustot yrittävät asentaa laajennuksia
    .accesskey = v
permissions-addon-exceptions2 =
    .label = Valitse, mitkä verkkosivustot voivat asentaa laajennuksia
    .accesskey = a
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Salli sivustojen pyytää avaamaan sovelluslinkkejä.
    .accesskey = S
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Hallitse estettyjä sivustoja
    .accesskey = H
permissions-location2 =
    .label = Sijainti
permissions-localhost2 =
    .label = Laitesovellukset ja -palvelut
permissions-local-network2 =
    .label = Paikallisverkon laitteet
permissions-xr2 =
    .label = Virtuaalitodellisuus
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofoni
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Kaiutin
permissions-notification2 =
    .label = Ilmoitukset
permissions-header3 =
    .description = Hallitse mitä verkkosivustot voivat käyttää, ohjata ja käynnistää.
    .label = Käyttöoikeudet
permissions-data-section =
    .heading = Käyttöoikeudet ja data
pane-permissions-data-title2 = Käyttöoikeudet ja data
    .title = Käyttöoikeudet ja data
notifications-section-header =
    .heading = Ilmoitukset
notifications-entry-card-header =
    .description = Valitse, mitkä verkkosivustot voivat lähettää ilmoituksia ja miten ne näkyvät.
    .label = Ilmoitukset
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } verkkosivusto
           *[other] { $count } verkkosivustoa
        }
    .label = Hallitse ilmoitusten asetuksia
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Hallitse sivustojen ilmoitusasetuksia
notifications-website-card-header =
    .description = Valitse, miten verkkosivustot voivat lähettää ilmoituksia.
    .label = Verkkosivustojen ilmoitukset
notifications-filter =
    .placeholder = Etsi sivustoja
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Verkkosivusto
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Salli ilmoitukset
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Verkkosivustot
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Aina
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Salli
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Ei koskaan
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Verkkosivustojen ilmoituksia ei ole lisätty.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Hakuasi vastaavia verkkosivustojen ilmoituksia ei löytynyt.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Varmistaaksesi, että tämä muutos sisältyy varmuuskopioihisi, avaa jokainen profiili ja valitse asetuksissa ”Varmuuskopioi nyt”.
nimbus-rollouts =
    .description = Muutokset toteutetaan etäohjattuna.
    .label = Salli { -brand-short-name }in parantaa ominaisuuksia, suorituskykyä ja vakautta päivitysten välillä
addon-recommendations3 =
    .description = Hanki laajennussuosituksia parantaaksesi selauskokemustasi.
    .label = Salli henkilökohtaiset laajennussuositukset
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Tietojen kerääminen ei ole käytössä tässä koostamiskokoonpanossa.
collection-backlogged-crash-reports2 =
    .label = Lähetä kaatumisilmoitukset automaattisesti
    .accesskey = ä
collection-backlogged-crash-reports-description = Tämä auttaa { -vendor-short-name }a diagnosoimaan ja korjaamaan selaimen ongelmia. Raportit voivat sisältää henkilökohtaisia tai arkaluonteisia tietoja.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Samat asetukset, uusi ulkoasu!
    .message = Järjestimme tämän sivun uudelleen, jotta se on helpompi selata. Henkilökohtaisia asetuksiasi ei ole muutettu, ja asiat ovat paikallaan. Vihje: käytä hakua siirtyäksesi haluamaasi kohtaan.
settings-redesign-promo-dismiss-button =
    .label = Selvä
privacy-segmentation-section-header = Uudet selaamista parantavat ominaisuudet
privacy-segmentation-section-description = Kun tarjoamme ominaisuuksia, jotka käyttävät tietojasi aiempaa henkilökohtaisemman käyttökokemuksen tarjoamiseksi:
privacy-segmentation-radio-off =
    .label = Käytä { -brand-product-name }-suosituksia
privacy-segmentation-radio-on =
    .label = Näytä yksityiskohtaiset tiedot
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Pyrimme tarjoamaan sinulle vaihtoehtoja ja keräämään vain vähimmäistiedot, jotka ovat tarpeen { -brand-product-name }in parantamiseksi.
    .label = { -brand-short-name }in tietojen keräys ja käyttö
    .searchkeywords = telemetria
data-collection-link = Näytä tietosuojakäytäntö
data-collection-preferences-across-profiles =
    .message = Nämä asetukset koskevat kaikkia tämän laitteen { -brand-product-name }-profiileja.
data-collection-profiles-link = Näytä kaikki profiilit
data-collection-health-report-telemetry-disabled =
    .message = Et enää salli { -vendor-short-name }n vastaanottaa teknisiä ja käyttötilastoja. Kaikki aikaisemmat tiedot poistetaan 30 päivän kuluessa.
data-collection-health-report =
    .description = Tämä auttaa meitä parantamaan { -brand-product-name }in ominaisuuksia, suorituskykyä ja vakautta.
    .label = Lähetä teknistä ja vuorovaikutustietoa { -vendor-short-name }lle
    .accesskey = r
data-collection-health-report-disabled =
    .description = Dataraportointi on poistettu käytöstä tästä koontimäärityksestä.
    .label = Lähetä teknistä ja vuorovaikutustietoa { -vendor-short-name }lle
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name } valitsee satunnaisesti käyttäjiä testaamaan ominaisuuksia, mikä auttaa parantamaan laatua kaikille.
    .label = Salli, että { -brand-short-name } suorittaa ominaisuustutkimuksia
data-collection-studies-link =
    .label = Näytä { -brand-short-name }-tutkimukset
data-collection-backlogged-crash-reports =
    .description = Tämä auttaa { -vendor-short-name }a diagnosoimaan ja korjaamaan selaimen ongelmia. Ilmoitukset voivat sisältää henkilökohtaista tai arkaluonteista tietoa.
    .label = Lähetä kaatumisilmoitukset automaattisesti
    .accesskey = ä
data-collection-usage-ping =
    .description = Tämä auttaa { -vendor-short-name }a arvioimaan aktiivisten käyttäjien määrää.
    .label = Lähetä päivittäinen käyttöilmoitus { -vendor-short-name }lle
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Turvallisuus
browsing-protection-group2 =
    .description = Vaaralliset sivustot ja lataukset voivat saattaa tietosi ja laitteesi alttiiksi riskeille. { -brand-short-name } estää ne automaattisesti, ja varoittaa sinua riskalttiista tai ei-halutuista ohjelmistoista.
    .label = Petolliselta sisällöltä ja vaarallisilta ohjelmilta suojaus
security-enable-safe-browsing =
    .label = Estä vaarallinen ja petollinen sisältö
    .accesskey = s
security-enable-safe-browsing-link = Lue lisää
security-safe-browsing-warning =
    .message = Tämän poistaminen käytöstä heikentää suojaa huijauksia, haitallisia sivustoja ja vaarallisia latauksia vastaan.
security-block-downloads =
    .label = Estä vaaralliset lataukset
    .accesskey = a
security-block-uncommon-software =
    .label = Varoita ei-halutuista ja epätavallisista ohjelmista
    .accesskey = r

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Salli { -brand-short-name }in luottaa automaattisesti asentamiisi kolmannen osapuolen juurivarmenteisiin
    .accesskey = t
certs-devices-enable-fips = Ota FIPS käyttöön
space-alert-over-5gb-settings-button =
    .label = Avaa asetukset
    .accesskey = A
space-alert-over-5gb-message2 = <strong>{ -brand-short-name(case: "ablative") } loppuu kohta levytila.</strong> Sivustojen sisällöt eivät ehkä näy oikein. Voit tyhjentää sivustotiedot avaamalla Asetukset > Tietosuoja ja turvallisuus > Evästeet ja sivustotiedot.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name(case: "ablative") } loppuu kohta levytila.</strong> Sivustojen sisällöt eivät ehkä näy oikein. Voit lukea levyn käytön optimoimisesta selaamisen sujuvoittamiseksi painamalla ”Lue lisää”.
certs-description3 =
    .description = Määritä { -brand-short-name }in suojattujen yhteyksien vahvistamiseen käyttämät varmenteet.
    .label = Varmenteet
certs-view2 =
    .label = Hallitse varmenteita
    .accesskey = r
certs-devices2 =
    .label = Hallitse turvalaitteita
    .accesskey = t

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Miten ”Vain HTTPS”-tila toimii
httpsonly-radio-enabled =
    .label = Käytä ”Vain HTTPS”-tilaa kaikissa ikkunoissa
httpsonly-radio-enabled-pbm =
    .label = Käytä ”Vain HTTPS”-tilaa vain yksityisissä ikkunoissa
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } saattaa silti päivittää jotkin yhteydet salatuksi
    .label = Älä käytä ”Vain HTTPS”-tilaa
httpsonly-group =
    .description = Sallii vain suojatut yhteydet verkkosivustoille. { -brand-short-name } kysyy, ennen kuin muodostaa suojaamattoman yhteyden.
    .label = Vain HTTPS -tila
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS HTTPS:n kautta
dns-over-https-group2 =
    .description = Domain Name System (nimipalvelujärjestlemä) HTTPS:n kautta (DoH) salaa sivustojen etsinnän, joten Internet-yhteytesi palveluntarjoajan ja muiden on vaikeampi nähdä, millä verkkosivustoilla vierailet.
    .label = DNS HTTPS:n kautta
preferences-doh-description2 = DNS (Domain Name System eli nimipalvelujärjestelmä) HTTPS:n kautta lähettää verkkotunnuksen nimeä koskevan pyyntösi salatun yhteyden kautta, tarjoten suojatun DNS:n ja vaikeuttaen muiden nähdä, mihin verkkosivustoon olet siirtymässä.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Tila: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Palveluntarjoaja: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Virheellinen osoite
preferences-doh-steering-status = Käytetään paikallista palveluntarjoajaa
preferences-doh-status-active = Käytössä
preferences-doh-status-disabled = Ei käytössä
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Ei aktiivinen ({ $reason })
preferences-doh-group-message2 = Käytä DNS:ää HTTPS:n välityksellä hyödyntäen:
preferences-doh-radio-group =
    .aria-label = Käytä DNS:ää HTTPS:n välityksellä hyödyntäen:
preferences-doh-expand-section =
    .tooltiptext = Lisätietoja
preferences-doh-setting-default =
    .label = Oletussuojaus
    .accesskey = O
preferences-doh-default-desc = { -brand-short-name } päättää, milloin suojattua DNS:ää käytetään yksityisyytesi suojaamiseksi.
preferences-doh-default-detailed-desc-1 = Käytä suojattua DNS:ää alueilla, joilla se on saatavilla
preferences-doh-default-detailed-desc-2 = Käytä oletusarvoista DNS-selvittäjää, jos suojatussa DNS:ssä on ongelma
preferences-doh-default-detailed-desc-3 = Käytä paikallista palveluntarjoajaa, jos mahdollista
preferences-doh-default-detailed-desc-4 = Sammuta, kun VPN, vanhempien käytönvalvonta tai yrityskäytännöt ovat aktiivisia
preferences-doh-default-detailed-desc-5 = Sammuta, kun verkko kertoo { -brand-short-name }ille, ettei sen pitäisi käyttää suojattua DNS:ää
preferences-doh-setting-enabled =
    .label = Lisätty suojaus
    .accesskey = i
preferences-doh-enabled-desc = Sinä hallitset, milloin suojattua DNS:ää käytetään ja valitset palveluntarjoajan.
preferences-doh-enabled-detailed-desc-1 = Käytä valitsemaani palveluntarjoajaa
preferences-doh-enabled-detailed-desc-2 = Käytä oletusarvoista DNS-selvittäjää vain, jos suojatussa DNS:ssä on ongelma
preferences-doh-setting-strict =
    .label = Täysi suojaus
    .accesskey = ä
preferences-doh-strict-desc = { -brand-short-name } käyttää aina suojattua DNS:ää. Näet turvallisuusriskivaroituksen, ennen kuin käytämme järjestelmäsi DNS:ää.
preferences-doh-strict-detailed-desc-1 = Käytä vain valitsemaani palveluntarjoajaa
preferences-doh-strict-detailed-desc-2 = Varoita aina, jos suojattu DNS ei ole käytettävissä
preferences-doh-strict-detailed-desc-3 = Jos suojattu DNS ei ole käytettävissä, sivustot eivät lataudu tai toimi oikein
preferences-doh-setting-off =
    .label = Pois
    .accesskey = o
preferences-doh-off-desc = Käytä oletusarvoista DNS-selvittäjää
preferences-doh-select-resolver = Valitse palveluntarjoaja:
preferences-doh-manage-exceptions =
    .label = Hallitse poikkeuksia…
    .accesskey = H
preferences-doh-overview-default =
    .description = Käytä suojattua DNS:ää alueilla, joilla se on saatavilla.
    .label = Oletussuojaus
preferences-doh-overview-custom =
    .description = Käytä aina suojattua DNS:ää halliten palveluntarjoajaa ja varatoiminnallisuutta.
    .label = Mukautettu
preferences-doh-overview-off =
    .description = Käytä yhteytesi oletusarvoista DNS-selvittäjää.
    .label = Pois päältä
preferences-doh-advanced-button =
    .label = Lisäasetukset
preferences-doh-advanced-section =
    .description = Domain Name System (nimipalvelujärjestlemä) HTTPS:n kautta (DoH) salaa sivustojen etsinnän, joten Internet-yhteytesi palveluntarjoajan ja muiden on vaikeampi nähdä, millä verkkosivustoilla vierailet.
    .label = Lisäasetukset
preferences-doh-manage-exceptions2 =
    .label = Hallitse poikkeuksia
    .accesskey = p
preferences-doh-radio-default =
    .description = Käytä suojattua DNS:ää alueilla, joilla se on saatavilla
    .label = Oletus
preferences-doh-radio-custom =
    .description = Käytä aina suojattua DNS:ää siten, että hallitset palveluntarjoajaa ja varatoiminnallisuutta
    .label = Mukautettu
preferences-doh-radio-off =
    .description = Käytä yhteytesi oletusarvoista DNS-selvittäjää
    .label = Pois päältä
preferences-doh-fallback-label =
    .label = Varoita aina, jos suojattua DNS:ää ei ole saatavilla
preferences-doh-status-item-off =
    .message = DNS HTTPS:n kautta on pois päältä
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = HTTPS-yhteyskäytännön kautta toimiva DNS ei toimi, koska palveluntarjoajaa { $name } käytettäessä tapahtui virhe ({ $reason }).
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS HTTPS:n kautta ei toimi, koska vastaanotettiin virheellinen URL-osoite ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = HTTPS-yhteyden kautta toimiva DNS käyttää palveluntarjoajaa { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = HTTPS-yhteyskäytännön kautta toimiva DNS ei toimi, koska havaitsimme virheen ({ $reason }) yrittäessämme käyttää paikallista palveluntarjoajaa { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = HTTPS-yhteyden kautta toimiva DNS käyttää paikallista palveluntarjoajaa { $name }
preferences-doh-select-resolver-label =
    .label = Valitse palveluntarjoaja:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Käytä tätä palveluntarjoajaa DNS-selvityksien tekemiseen HTTPS-yhteydellä
preferences-doh-custom-provider-label =
    .aria-label = Anna mukautetun tarjoajan URL-osoite
preferences-doh-header2 =
    .heading = DNS HTTPS:n kautta

## Connection and software security section

preferences-connection-header =
    .heading = Yhteys- ja ohjelmistoturvallisuus
preferences-connection-link-section =
    .description = Näe kuinka yhteydet pysyvät suojattuna, haitalliset ohjelmistot estetään ja verkkosivustot vahvistetaan.
    .label = Yhteys- ja ohjelmistoturvallisuus
preferences-connection-link-button =
    .label = Lisäasetukset

## The following strings are used in the Download section of settings

desktop-folder-name = Työpöytä
downloads-folder-name = Lataukset

## Appearance page

preferences-appearance-header =
    .heading = Ulkoasu
browser-theme-group =
    .description = Aseta { -brand-short-name }ille haluamasi tyyli. Teeman värejä käytetään työkalupalkeissa, valikoissa ja viesteissä.
    .label = Selaimen teema
browser-theme-manage-link =
    .label = Hallitse { -brand-short-name }in teemoja
appearance-window-density-group =
    .description = Säädä välistystä ikkunaelementtien, kuten työkalupalkin, välilehtien ja sivupalkin välillä.
    .label = Ikkunan tiheys
appearance-window-density-radio-group =
    .aria-label = Ikkunan tiheys
appearance-window-density-automatic =
    .description = Tavallinen, tiivis tai kosketuspohjainen välistys toteutetaan automaattisesti
    .label = Automaattinen (oletus)
appearance-window-density-automatic-no-touch =
    .description = Tavallinen tai kompakti välistys toteutetaan automaattisesti
    .label = Automaattinen (oletus)
appearance-window-density-standard =
    .description = Tasapainotettu välistys useimmille näytöille
    .label = Tavallinen
appearance-window-density-auto-touch-mode =
    .label = Käytä kosketusvälistystä tablettitilassa
appearance-window-density-compact =
    .description = Pienempi välistys pienemmille näytöille
    .label = Tiivis
appearance-window-density-touch =
    .description = Suuremmat ikkunaelementit ja napsautusalueet, optimoitu kosketusnäytöille
    .label = Kosketus
related-settings-group =
    .label = Aiheeseen liittyvät asetukset
related-settings-accessibility-link =
    .label = Mukauta suurennuksen ja kirjasimen asetuksia esteettömyysasetuksissa
related-settings-home-link =
    .label = Mukauta { -firefox-home-brand-name }ia
related-settings-tabs-browsing-link =
    .label = Mukauta selaimen asettelua

## AI controls page

preferences-ai-controls-description = Sinulla on aina vaihtoehtoja { -brand-short-name }issa,, mukaan lukien tekoälyn parannettujen ominaisuuksien käyttö. Lisää säätimiä on tulossa pian.
preferences-ai-controls-block-ai-label = Estä tekoälytehostukset
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Estäminen tarkoittaa, että et näe uusia tai nykyisiä tekoälytehostuksia { -brand-short-name }issa, etkä niistä kertovia ponnahdusikkunoita. <a data-l10n-name="link">Lue lisätietoja</a> siitä, mitä ominaisuuksia on ja miten voit hallita perinteisiä koneoppimisominaisuuksia, kuten hakuehdotuksia ja suosituksia.
preferences-ai-controls-blocked-message =
    .message = Uudet ja nykyiset tekoälytehostukset on oletusarvoisesti estetty. Voit poistaa tietyn ominaisuuden eston alla olevilla säätimillä.
preferences-ai-controls-on-device-group =
    .description = Nämä ovat pieniä tekoälymalleja, jotka ladataan laitteellesi, jos käytät tätä ominaisuutta. Tämä lähestymistapa auttaa suojaamaan yksityisyyttäsi.
    .label = Paikallisen laitteen tekoäly
preferences-ai-controls-translations-control =
    .description = Selaa verkkoa haluamallasi kielellä.
    .label = Käännökset
preferences-ai-controls-translations-more-link = Lisää käännösasetuksia
preferences-ai-controls-pdfjs-control =
    .description = Kun lisäät kuvia PDF-tiedostoihin, tämä lisää kuvaavia tekstejä saavutettavuuden takaamiseksi.
    .label = Kuvan alt-teksti { -brand-short-name }in PDF-katseluohjelmassa
preferences-ai-controls-tab-group-suggestions-control =
    .description = Vastaanota ehdotuksia välilehtiesi nimeämiseen ja järjestämiseen.
    .label = Välilehtiryhmien ehdotukset
preferences-ai-controls-key-points-control =
    .description = Näe nopea yhteenveto ennen linkin avaamista.
    .label = Pääkohdat linkkien esikatselussa
preferences-ai-controls-speech-recognition-control =
    .description = Litteroi puhe paikallisesti.
    .label = Puheentunnistus
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Pidä chatbot näkyvillä selatessasi. Valitse useista palveluntarjoajista ja vaihda milloin tahansa.
    .label = Chatbot-palveluntarjoajat sivupaneelissa
preferences-ai-controls-sidebar-chatbot-group =
    .description = Pidä chatbot näkyvissä kun selaat. Vaihtoehdot ovat Anthropic Claude, ChatGPT, Copilot, Google Gemini ja Le Chat Mistral.
    .label = Chatbot-palveluntarjoajat sivupalkissa
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot sivupaneelissa
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Saatavilla
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Käytössä
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Estetty
preferences-ai-controls-state-description-before = Mitä vaihtoehdot tarkoittavat:
preferences-ai-controls-state-description-available = <strong>Saatavilla:</strong> Näet ominaisuuden ja voit käyttää sitä.
preferences-ai-controls-state-description-enabled = <strong>Käytössä:</strong> Olet ottanut ominaisuuden käyttöön.
preferences-ai-controls-state-description-blocked = <strong>Estetty:</strong> Et näe etkä voi käyttää ominaisuutta. Paikallisen laitteen tekoälyn osalta kaikki jo ladatut mallit poistetaan.
preferences-ai-controls-block-confirmation-heading = Estetäänkö tekoälytehostukset?
preferences-ai-controls-block-confirmation-description = Et näe uusia tai nykyisiä tekoälytehostuksia { -brand-short-name }issa, etkä niihin liittyviä ponnahdusikkunoita. Voit milloin tahansa myöhemmin poistaa yksittäisen tekoälytehostuksen eston.
preferences-ai-controls-block-confirmation-features-start = Mitä estetään:
preferences-ai-controls-block-confirmation-translations = Käännökset
preferences-ai-controls-block-confirmation-pdfjs = Kuvan alt-teksti { -brand-short-name }in PDF-katseluohjelmassa
preferences-ai-controls-block-confirmation-tab-group-suggestions = Välilehtiryhmien ehdotukset
preferences-ai-controls-block-confirmation-key-points = Pääkohdat linkkien esikatselussa
preferences-ai-controls-block-confirmation-sidebar-chatbot = Chatbot sivupaneelissa
preferences-ai-controls-block-confirmation-speech-recognition = Puheentunnistus
preferences-ai-controls-block-confirmation-features-after = Esto vaikuttaa myös laajennuksiin, jotka käyttävät { -brand-short-name }in tarjoamaa tekoälyä.
preferences-ai-controls-block-confirmation-cancel =
    .label = Peruuta
preferences-ai-controls-block-confirmation-confirm =
    .label = Estä
preferences-ai-controls-header3 =
    .heading = Tekoälyn säätimet

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } on valppaana
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } suosittelee joitakin tietoturvaparannuksia
security-privacy-status-ok-label = Tehostettu seurannan suojaus on päällä
security-privacy-status-problem-label = Löysimme turvallisuuteesi vaikuttavia asetuksia
security-privacy-status-problem-helper-label = Näytä ongelmat
security-privacy-status-pending-trackers-label = Tarkastellaan, kuinka monta seurainta { -brand-short-name } esti viimeisen kuukauden aikana
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } seurain estetty viimeisen kuukauden aikana
       *[other] { $trackerCount } seurainta estetty viimeisen kuukauden aikana
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Sinulla on <a data-l10n-name="strict-tracking-protection">tiukka suojaus</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Sinulla on <a data-l10n-name="custom-tracking-protection">mukautettu suojaus</a>
security-privacy-status-up-to-date-label = Sinulla on { -brand-short-name }in uusin ja turvallisin versio
security-privacy-status-update-needed-label = Uusi versio { -brand-short-name }ista on saatavilla.
security-privacy-status-update-error-label = { -brand-short-name } kohtasi ongelmia päivittäessä itseään
security-privacy-status-update-checking-label = { -brand-short-name } tarkistaa päivityksiä
security-privacy-status-update-needed-description = Päivitä uusimmat nopeus-, vakaus- ja tietoturvapäivitykset.
security-privacy-status-update-button-label =
    .label = Päivitä { -brand-short-name }
security-privacy-image-warning =
    .alt = Huutomerkillä varustettu kilpi, joka ilmaisee huolta turvallisuuteesi liittyvistä varoituksista
security-privacy-image-ok =
    .alt = Oikein-merkillä varustettu kilpi, joka osoittaa, että sinulla ei ole ratkaisemattomia tietoturvaongelmia
security-privacy-issue-card =
    .heading = Turvallisuusvaroitukset
issue-card-reset-button =
    .label = Palauta
issue-card-dismiss-button =
    .aria-label = Hylkää
    .tooltiptext = Hylkää

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Sivustot käyttävät seuraimia käyttäjien seurantaan ja mainosten esittämiseen. { -brand-short-name } suojaa sinut, kun selaat, estäen seuraimet automaattisesti, asettaen digitaalisen jalanjälkesi hallintaasi.
    .label = Tehostettu seurannan suojaus
preferences-etp-level-radio-group =
    .aria-label = Tehostettu seurannan suojaus
preferences-etp-level-standard =
    .description = Vahva, luotettava suojaus, joka toimii useimpien verkkosivustojen kanssa.
    .label = Tavallinen (oletus)
preferences-etp-level-strict =
    .description = Vahvemmat suojaukset useimpien seurainten estämiseksi, mutta saattaa aiheuttaa joidenkin verkkosivustojen rikkoutumisen.
    .label = Tiukka
preferences-etp-level-custom =
    .description = Valitse mitkä suojaukset ovat käytössä tai pois käytöstä.
    .label = Mukautettu
preferences-etp-status-advanced-button =
    .label = Lisäasetukset
preferences-etp-tracker-count-enabled =
    .label = Näytä estetyt seuraimet osoiterivillä
preferences-etp-status-protections-dashboard-link =
    .description = Näe, kuinka monta seurainta { -brand-short-name } on estänyt puolestasi, mukaan lukien sosiaalisen median seuraimet, yksilöijät ja kryptolouhijat.
    .label = Tarkastele mukautettua suojaushallintapaneeliasi
preferences-etp-header =
    .heading = Tehostettu seurannan suojaus
preferences-etp-advanced-settings-group =
    .description = Sivustot käyttävät seuraimia käyttäjien seurantaan ja mainosten esittämiseen. { -brand-short-name } suojaa sinut, kun selaat, estäen seuraimet automaattisesti, asettaen digitaalisen jalanjälkesi hallintaasi.
    .label = Lisäasetukset
preferences-etp-customize-button =
    .label = Mukauta seurannan suojausta
preferences-etp-reload-tabs-hint =
    .message = Lataa välilehdet uudelleen, jotta nämä muutokset otetaan käyttöön.
preferences-etp-reload-tabs-hint-button =
    .label = Lataa kaikki välilehdet uudelleen
preferences-etp-rfp-warning-message =
    .message = Käytät Resist Fingerprinting (RFP) -toimintoa, joka korvaa osan { -brand-short-name }in yksilöinnin suojausasetuksista. Tämä saattaa aiheuttaa joidenkin sivustojen rikkoutumisen.
preferences-etp-level-warning-message =
    .heading = Huomio! Jotkin sivustot eivät välttämättä toimi odotetulla tavalla.
    .message = Jotkin sivustot rakentavat seuraimia itse sivuston ominaisuuksiin tai sisältöön. Kun { -brand-short-name } estää ne, sivusto vaikuttaa rikkinäiseltä. Kokeile “Korjaa sivuston ongelmat” tai poista seurannan suojaus pois käytöstä kyseisellä sivustolla.
preferences-etp-manage-exceptions-button =
    .description = Hallitse verkkosivustoja, joiden kohdalla ei käytetä tehostettua seurannan suojausta.
    .label = Hallitse poikkeuksia
preferences-etp-customize-header =
    .heading = Mukauta seurannan suojausta
preferences-etp-reset =
    .description = Palauta asetukset esiasetettuun suojaustasoon.
    .label = Nollaa mukautukset
preferences-etp-reset-standard-button =
    .label = Palauta vakioasetuksiin
preferences-etp-reset-strict-button =
    .label = Palauta tiukaksi
preferences-etp-custom-control-group =
    .description = Valitse mitkä suojaukset ovat käytössä tai pois käytöstä.
    .label = Seurannan suojaus
preferences-etp-custom-cookies-enabled =
    .label = Evästeet
preferences-etp-custom-cookie-behavior =
    .aria-label = Evästeet
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Salli kaikki evästeet
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Estä sivustorajat ylittävät seurainevästeet
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Estä sivustorajat ylittävät evästeet
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Eristä sivustorajat ylittävät evästeet
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Estä evästeet vierailemattomilta verkkosivustoilta
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Estä kaikki sivustorajat ylittävät evästeet (voi aiheuttaa sivustojen toimimattomuutta)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Estä kaikki evästeet (rikkoo verkkosivustoja)
preferences-etp-custom-tracking-protection-enabled =
    .label = Seurantaan tarkoitettu sisältö
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Seurantaan tarkoitettu sisältö
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Kryptolouhijat
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Tunnetut yksilöijät
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Epäillyt yksilöijät
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Epäillyt yksilöijät

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Tämä saattaa mahdollistaa joidenkin seurainten seurata sinua ilman evästeitä.
    .label = Tunnettuja yksilöijiä ei estetä
security-privacy-issue-warning-third-party-cookies =
    .description = Kolmannen osapuolen evästeitä käytetään seuraamiseesi verkkosivustojen välillä.
    .label = Kolmannen osapuolen evästeet ovat käytössä
security-privacy-issue-warning-password-manager =
    .description = Salasananhallinnan palvelut ja sovellukset voivat auttaa tallentamaan vahvoja salasanoja tilejäsi varten.
    .label = Salasananhallinta on poistettu käytöstä
security-privacy-issue-warning-popup-blocker =
    .description = Ponnahdusikkunat ovat häiritseviä ja mahdollisesti haitallisia.
    .label = Ponnahdusikkunoiden esto on poistettu käytöstä
security-privacy-issue-warning-extension-install =
    .description = Verkkosivustot voivat asentaa laajennuksia { -brand-short-name }iin kysymättä minulta.
    .label = Verkkosivustot voivat asentaa laajennuksia
security-privacy-issue-warning-safe-browsing =
    .description = Altistumisesi verkkosivustojen huijauksille ja haittaohjelmille on kasvanut.
    .label = Vaarallista ja harhaanjohtavaa sisältöä ei estetä
security-privacy-issue-warning-doh2 =
    .description = HTTPS-yhteyden kautta toimiva DNS auttaa piilottamaan verkko-operaattoriltasi, millä sivustoilla olet käymässä.
    .label = DNS HTTPS:n kautta on poistettu käytöstä
security-privacy-issue-warning-ech2 =
    .description = Salatun Client Hellon avulla voit piilottaa verkkopalveluntarjoajaltasi, millä sivustoilla olet käymässä.
    .label = Salattu Client Hello on poistettu käytöstä
security-privacy-issue-warning-doh =
    .description = DNS HTTPS:n kautta piilottaa verkkoyhteytesi tarjoajalta vierailemasi sivustot.
    .label = DNS HTTPS:n kautta on poistettu käytöstä
security-privacy-issue-warning-ech =
    .description = Salattu Client Hello piilottaa verkkoyhteytesi tarjoajalta vierailemasi sivustot.
    .label = Salattu Client Hello on poistettu käytöstä
security-privacy-issue-warning-proxy-autodetection =
    .description = Välityspalvelimen automaattinen määritys saattaa mahdollistaa ei-luotettujen verkkojen tarkkailla toimiasi.
    .label = Välityspalvelimen automaattinen määritys on käytössä

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Pyydä jotakuta valitsemaan yksityisyyden etusijalle asettava selain.
    .label = Jaa { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Jaa { -brand-product-name }


vorbit-header = vOrbit-lite-asetukset
vorbit-letterboxing-checkbox =
    .label = Ota käyttöön selaimen laatikointi
vorbit-webgl-description = WebGL on tehokas tapa suorittaa yksilöintiä.
vorbit-general-heading = Selaimen toiminta
vorbit-network-heading = Verkko
vorbit-ocsp-checkbox =
    .label = Pakota OCSP:n luja epäonnistuminen
category-vorbit =
    .tooltiptext = about:config, loogisesti ryhmitetty ja helposti saatavilla
vorbit-extension-update-checkbox =
    .label = Päivitä lisäosat automaattisesti
vorbit-broken-heading = Yksilöinti
vorbit-security-heading = Tietoturva
vorbit-goog-safe-checkbox =
    .label = Ota käyttöön Google Safe Browsing -suojaus
vorbit-extension-update-warning1 = Jos et tutki laajennustesi koodia ennen niiden päivittämistä, silloin sinun kannattaa ottaa tämä valinta käyttöön.
vorbit-ipv6-description = Salli { -brand-short-name }in muodostaa yhteyden käyttäen IPv6:tta.
vorbit-ocsp-description = Estä verkkosivustoon yhdistäminen, jos OCSP:n tarkistusta ei voida suorittaa.
vorbit-sync-description = Synkronoi datasi toisten selainten kanssa. Vaatii uudelleenkäynnistyksen.
vorbit-sync-warning1 = Firefox Sync salaa datan paikallisesti ennen palvelimelle lähettämistä.
vorbit-styling-warning1 = Varmista, että luotat teeman tarjoajaan.
vorbit-xorigin-ref-description = Lähetä viittaja vain samasta alkuperästä.
vorbit-rfp-description = ResistFingerprinting on luokkansa paras yksilöinnin estotyökalu.
vorbit-rfp-warning1 = Jos sinun tarvitsee poistaa se käytöstä, harkitse laajennuksen, kuten Canvas Blockerin, käyttöä.
vorbit-goog-safe-download-description = Salli Safe Browing -suojauksen tarkistaa lataukset epäillyttävien tiedostojen tunnistamiseksi.
vorbit-footer = Hyödylliset linkit
vorbit-open-profile = Avaa käyttäjäprofiilin hakemisto
pane-vorbit-title = vOrbit-lite
vorbit-warning-title = Huomio!
vorbit-ipv6-checkbox =
    .label = Ota käyttöön IPv6
vorbit-webgl-checkbox =
    .label = Ota käyttöön WebGL
vorbit-warning-description = Valitsemme oletusasetukset huolellisesti keskittyäksemme yksityisyyteen ja turvallisuuteen. Kun teet muutoksia näihin asetuksiin, lue kuvaukset, jotta ymmärrät muutoksiesi merkityksen.
vorbit-sync-checkbox =
    .label = Ota käyttöön Firefox Sync
vorbit-autocopy-checkbox =
    .label = Ota käyttöön hiiren keskipainikkeella liittäminen
vorbit-styling-checkbox =
    .label = Salli userChrome.css:n mukauttaminen
vorbit-privacy-heading = Yksityisyys
vorbit-xorigin-ref-checkbox =
    .label = Rajoita cross-origin-viittaajia
vorbit-rfp-checkbox =
    .label = Ota käyttöön yksilöinnin vastustaminen
vorbit-goog-safe-download-checkbox =
    .label = Tarkista lataukset
vorbit-styling-description = Ota tämä käyttöön, mikäli haluat mukauttaa käyttöliittymää manuaalisesti ladatulla teemalla.
vorbit-extension-update-description = Päivitä lisäosat ilman manuaalista vuorovaikutusta. Hyvä valinta turvallisuutesi kannalta.
vorbit-webgl-warning1 = Jos sinun tarvitsee ottaa se käyttöön, harkitse laajennuksen, kuten Canvas Blockerin, käyttöä.
vorbit-ipv6-warning1 = Sen sijaan, että IPv6 estettäisiin selaimessa, me suosittelemme, että otat IPv6:n yksityisyyslaajennuksen käyttöön käyttöjärjestelmässäsi.
vorbit-ocsp-warning1 = Tämä parantaa turvallisuutta, mutta aiheuttaa ongelmia, kun OCSP-palvelin on alhaalla.
vorbit-autocopy-description = Valitse teksti kopioidaksesi se, ja liitä se hiiren keskipainalluksella.
vorbit-xorigin-ref-warning1 = Tämä voi aiheuttaa ongelmia. Lisäksi, vaikka viittajat lähetetään, ne silti rajataan.
vorbit-goog-safe-warning1 = Pois käytöstä sensuurihuolien takia, mutta suositeltu vähemmän edistyneille käyttäjille. Kaikki tarkistukset tapahtuvat paikalliseti.
vorbit-letterboxing-description = Letterboxing lisää marginaalit ikkunoidesi ympärille, jotta se voi palauttaa rajoitetun joukon pyöristettyjä resoluutioita.
vorbit-goog-safe-description = Jos olet huolissasi haittaohjelmista ja tietojenkalastelusta, harkitse tämän käyttämistä.
vorbit-goog-safe-download-warning1 = Kaikki tarkistukset tapahtuvat paikallisesti.
vorbit-config-link = Kaikki lisäasetukset (about:config)
content-blocking-section-top-level-description = vOrbit-lite tukee - ja se mahdollistaa oletuksena - parannetun seurantasuojauksen tiukassa tilassa. Tämä on yksi selaimen tärkeimmistä asetuksista, koska se tarjoaa tilaosioinnin, tiukat estoluettelot ja muita siistejä tietosuojaominaisuuksia. Emme suosittele vaihtamista muihin tiloihin.
vorbit-webgl-prompt-checkbox =
    .label = Ota käyttöön WebGL-käyttöoikeuden kysely
vorbit-webgl-prompt-description = Tämä näyttää kysymysikkunan, kun WebGL on otettu käyttöön, sen sijaan että annetaan suoraan käyttöoikeus.
