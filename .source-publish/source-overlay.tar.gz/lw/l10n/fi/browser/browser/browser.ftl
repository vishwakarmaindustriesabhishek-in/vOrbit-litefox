# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } - Yksityinen selaus
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Nopeaa ja yksityistä verkkoselailua
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Yksityinen selaus
       *[other] { -brand-full-name } — Yksityinen selaus
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Yksityinen selaus
popups-infobar-dont-show-message2 =
    .label = Älä näytä tätä viestiä, kun ponnahdusikkunat tai kolmannen osapuolen uudelleenohjaukset on estetty
    .accesskey = d
edit-popup-settings2 =
    .label = Hallitse ponnahdusikkunoiden ja kolmannen osapuolen uudelleenohjausten asetuksia…
    .accesskey = m
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Näytä sivuston tiedot
            [1] Näytä sivuston tiedot (1 seurain estetty)
            [one] Näytä sivuston tiedot ({ $count } seurain estetty)
           *[other] Näytä sivuston tiedot ({ $count } seurainta estetty)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } linkki
           *[other] { $count } linkkiä
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Viestit ja paljon muuta…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Viestit, sähköposti ja paljon muuta…
    .accesskey = V
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Jaa…
    .accesskey = J
urlbar-identity-button =
    .aria-label = Näytä sivuston tiedot

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Avaa asentamisen viestipaneeli
urlbar-web-notification-anchor =
    .tooltiptext = Muuta sitä, voitko saada ilmoituksia tältä sivustolta
urlbar-midi-notification-anchor =
    .tooltiptext = Avaa MIDI-paneeli
urlbar-serial-notification-anchor =
    .tooltiptext = Avaa sarjaporttipaneeli
urlbar-eme-notification-anchor =
    .tooltiptext = Hallinnoi DRM-ohjelmiston käyttöä
urlbar-web-authn-anchor =
    .tooltiptext = Avaa verkkotodennuksen paneeli
urlbar-canvas-notification-anchor =
    .tooltiptext = Hallinnoi kanvaksen sisällön lukemisen oikeutta
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Hallinnoi mikrofonin jakamista sivustolle
urlbar-default-notification-anchor =
    .tooltiptext = Avaa viestipaneeli
urlbar-geolocation-notification-anchor =
    .tooltiptext = Avaa paikannustietojen pyyntöpaneeli
urlbar-localhost-notification-anchor =
    .tooltiptext = Hallinnoi paikallisten laitteiden pääsyä tälle sivustolle
urlbar-local-network-notification-anchor =
    .tooltiptext = Hallinnoi lähiverkon pääsyn jakamista tämän sivuston kanssa
urlbar-xr-notification-anchor =
    .tooltiptext = Avaa virtuaalitodellisuuden käyttöoikeuspaneeli
urlbar-storage-access-anchor =
    .tooltiptext = Avaa selaamisen seuraamisoikeuden paneeli
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Hallinnoi ikkunoiden tai näytön jakamista sivustolle
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Avaa verkkoyhteydettömän tilan tietovaraston viestipaneeli
urlbar-password-notification-anchor =
    .tooltiptext = Avaa salasanan tallentamisen viestipaneeli
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Hallinnoi kameran tai mikrofonin jakamista sivustolle
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Hallinnoi muiden kaiuttimien jakamista sivuston kanssa
urlbar-autoplay-notification-anchor =
    .tooltiptext = Avaa automaattisen toiston paneeli
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Tallenna tietoja pysyvään tallennustilaan
urlbar-addons-notification-anchor =
    .tooltiptext = Avaa lisäosan asentamisen viestipaneeli
urlbar-search-tips-confirm = Selvä
urlbar-search-tips-confirm-short = Selvä
urlbar-result-menu-button =
    .title = Avaa valikko
urlbar-result-menu-button-feedback = Palaute
    .title = Avaa valikko
urlbar-result-menu-learn-more2 = Lue lisää
    .accesskey = L
urlbar-result-menu-remove-from-history2 = Poista historiasta
    .accesskey = R
urlbar-result-menu-tip-get-help2 = Tuki
    .accesskey = T
urlbar-result-menu-dismiss-suggestion2 = Hylkää tämä ehdotus
    .accesskey = ä
urlbar-result-menu-manage-firefox-suggest2 = Hallitse { -firefox-suggest-brand-name }ia
    .accesskey = H
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Ilmoita epätarkasta sijainnista
    .accesskey = m
urlbar-result-menu-show-less-frequently3 = Näytä harvemmin
    .accesskey = N
urlbar-result-menu-dont-show-weather-suggestions3 = Älä näytä sääehdotuksia
    .accesskey = Ä
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Ilmoita epätarkasta sijainnista
urlbar-result-menu-show-less-frequently2 = Näytä harvemmin
urlbar-result-menu-dont-show-weather-suggestions2 = Älä näytä sääehdotuksia
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Hylkää tämä ehdotus
    .accesskey = H
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Poista historiasta
    .accesskey = P
urlbar-result-menu-learn-more =
    .label = Lue lisää
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = Poista historiasta
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = Tuki
    .accesskey = T
urlbar-result-menu-dismiss-suggestion =
    .label = Hylkää tämä ehdotus
    .accesskey = ä
urlbar-result-menu-manage-firefox-suggest =
    .label = Hallitse { -firefox-suggest-brand-name }ia
    .accesskey = H
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Ilmoita epätarkasta sijainnista
urlbar-result-menu-show-less-frequently =
    .label = Näytä harvemmin
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Älä näytä sääehdotuksia
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Avaa valikko
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Kiitos palautteestasi
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Kiitos palautteestasi. Et näe enää sääehdotuksia.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Kirjoita vähemmän, löydä enemmän: Hae hakukoneella { $engineName } suoraan osoitepalkista.
urlbar-search-tips-redirect-2 = Aloita hakeminen osoitepalkista, niin näet ehdotukset palvelusta { $engineName } ja selaushistoriastasi.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Valitse tämä, niin löydät etsimäsi nopeammin.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Kirjanmerkit
urlbar-search-mode-tabs = Välilehdet
urlbar-search-mode-history = Historia
urlbar-search-mode-actions = Toiminnot

##

urlbar-geolocation-blocked =
    .tooltiptext = Olet estänyt sijaintitiedot tältä sivustolta.
urlbar-localhost-blocked =
    .tooltiptext = Olet estänyt paikallisten laitteiden yhteydet tälle verkkosivustolle.
urlbar-local-network-blocked =
    .tooltiptext = Olet estänyt paikallisverkon yhteydet tälle verkkosivustolle.
urlbar-xr-blocked =
    .tooltiptext = Olet estänyt virtuaalitodellisuuslaitteen käytön tältä sivustolta.
urlbar-web-notifications-blocked =
    .tooltiptext = Olet estänyt ilmoitukset tältä sivustolta.
urlbar-camera-blocked =
    .tooltiptext = Olet estänyt kameran tältä sivustolta.
urlbar-microphone-blocked =
    .tooltiptext = Olet estänyt mikrofonin tältä sivustolta.
urlbar-screen-blocked =
    .tooltiptext = Olet estänyt tämän sivuston jakamasta näyttöäsi.
urlbar-persistent-storage-blocked =
    .tooltiptext = Olet estänyt pysyvän tallennustilan käytön tältä sivustolta.
urlbar-popup-blocked2 =
    .tooltiptext = Olet estänyt ponnahdusikkunat ja kolmannen osapuolen uudelleenohjaukset tällä verkkosivustolla.
urlbar-autoplay-media-blocked =
    .tooltiptext = Olet estänyt äänellisen median automaattisen toistamisen tältä sivustolta.
urlbar-canvas-blocked =
    .tooltiptext = Olet estänyt kanvaksen sisällön lukemisen tältä sivustolta.
urlbar-midi-blocked =
    .tooltiptext = Olet estänyt MIDI-käytön tältä sivustolta.
urlbar-serial-blocked =
    .tooltiptext = Olet estänyt sarjaportin käytön tältä sivustolta.
urlbar-install-blocked =
    .tooltiptext = Olet estänyt lisäosien asennuksen tältä sivustolta.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Muokkaa kirjanmerkkiä ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Lisää kirjanmerkki ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Jaettu näkymä
    .tooltiptext = Jaettu näkymä

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Liitä ja avaa
    .accesskey = L
urlbar-menuitem-paste-and-search =
    .label = Liitä ja hae
    .accesskey = L

## Searchbar context menu

clear-search-history =
    .label = Tyhjennä hakuhistoria
    .accesskey = T

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Hallitse laajennusta…
    .accesskey = e
page-action-remove-extension2 =
    .label = Poista laajennus
    .accesskey = i

## Auto-hide Context Menu

full-screen-autohide =
    .label = Piilota työkalupalkit
    .accesskey = P
full-screen-exit =
    .label = Poistu koko näytön tilasta
    .accesskey = o

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Tällä kertaa käytä hakuun:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Muuta hakuasetuksia
search-one-offs-context-open-new-tab =
    .label = Etsi uudessa välilehdessä
    .accesskey = E
search-one-offs-context-set-as-default =
    .label = Aseta oletushakukoneeksi
    .accesskey = A
search-one-offs-context-set-as-default-private =
    .label = Aseta oletushakukoneeksi yksityisissä ikkunoissa
    .accesskey = A
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Lisää hakukone ”{ $engineName }”
    .label = Lisää ”{ $engineName }”
    .tooltiptext = Lisää hakukone ”{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Lisää hakukone
    .accesskey = L
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Lisää hakukone

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Kirjanmerkit ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Välilehdet ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historia ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Toiminnot ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Näytä lisäosat
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = laajennukset, teemat, lisäosat
# Opens preferences page at AI controls
quickactions-manageai = Hallitse tekoälysäätimiä
quickactions-cmd-manageai = poista tekoäly käytöstä, tekoäly pois, hallitse tekoälyä
# Opens the bookmarks library window
quickactions-bookmarks2 = Hallitse kirjanmerkkejä
quickactions-cmd-bookmarks = kirjanmerkit
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Tyhjennä viimeaikainen historia
quickactions-cmd-clearrecenthistory2 = cookies, clear cookies, cache, clear cache, browsing data, clear browsing data, history, clear recent history, evästeet, tyhjennä evästeet, välimuisti, tyhjennä välimuisti, selaustiedot, tyhjennä selaustiedot, historia, tyhjennä viimeaikainen historia
# Opens about:downloads page
quickactions-downloads2 = Näytä lataukset
quickactions-cmd-downloads = lataukset
# Opens about:addons page in the extensions section
quickactions-extensions = Hallitse laajennuksia
quickactions-cmd-extensions2 = laajennukset, lisäosat
# Opens Firefox View
quickactions-firefoxview = Avaa { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = avaa { -firefoxview-brand-name }, { -firefoxview-brand-name }, avaa näkymä, näkymä
# Opens SUMO home page
quickactions-help = { -brand-product-name }-tuki
quickactions-cmd-help = ohje, tuki
# Opens the devtools web inspector
quickactions-inspector2 = Avaa kehittäjätyökalut
quickactions-cmd-inspector2 = inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Valitse väri
quickactions-cmd-colorpicker = color picker, eyedropper, pick color, värinvalitsin, pipetti, värin valinta
# Opens Firefox Library
quickactions-cmd-library = kirjasto
quickactions-library = Avaa kirjasto
# Opens about:logins
quickactions-logins2 = Hallitse salasanoja
quickactions-cmd-logins = käyttäjätunnukset, salasanat
# Mutes all tabs playing audio
quickactions-mute = Mykistä ääntä toistavat välilehdet
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = mykkä, hiljaa, sssssh
# Opens the print dialog
quickactions-print2 = Tulosta sivu
quickactions-cmd-print = tulosta
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Tallenna sivu PDF-muodossa
quickactions-cmd-savepdf2 = pdf, tallenna sivu
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Avaa PDF-muokkain
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Avaa yksityinen ikkuna
quickactions-cmd-private = yksityinen selaus
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Palauta { -brand-short-name } uudenveroiseksi
quickactions-cmd-refresh = päivitä
# Restarts the browser
quickactions-restart = Käynnistä { -brand-short-name } uudelleen
quickactions-cmd-restart = käynnistä uudelleen
# Opens the screenshot tool
quickactions-screenshot3 = Ota kuvakaappaus
quickactions-cmd-screenshot2 = kuvakaappaus, ota kuvakaappaus
# Opens about:translations
quickactions-translate = Käännä
quickactions-cmd-translate = käännä
# Opens about:preferences
quickactions-settings2 = Hallitse asetuksia
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = asetukset, valinnat, hallitse
# Opens about:addons page in the themes section
quickactions-themes = Hallitse teemoja
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = teemat, lisäosat
# Opens a SUMO article explaining how to update the browser
quickactions-update = Päivitä { -brand-short-name }
quickactions-cmd-update = päivitä
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Näytä sivun lähdekoodi
quickactions-cmd-viewsource2 = näytä lähdekoodi, lähde, sivun lähdekoodi
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Avaa { -firefoxlabs-brand-name }
quickactions-cmd-labs = laboratoriot, koe, labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Lue lisää pikatoiminnoista
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Paina sarkainta valitaksesi:

## Bookmark Panel

bookmarks-add-bookmark = Kirjanmerkin lisääminen
bookmarks-edit-bookmark = Kirjanmerkin muokkaus
bookmark-panel-cancel =
    .label = Peruuta
    .accesskey = P
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Poista kirjanmerkki
           *[other] Poista { $count } kirjanmerkkiä
        }
    .accesskey = P
bookmark-panel-show-editor-checkbox =
    .label = Näytä muokkaus tallennettaessa
    .accesskey = m
bookmark-panel-save-button2 =
    .label = Tallenna
    .accesskey = T
bookmark-panel-save-button =
    .label = Tallenna
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Tiedot sivustosta { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Yhteyden suojaus sivustoon { $host }
identity-connection-not-secure = Yhteys ei ole suojattu
identity-connection-secure = Yhteys on suojattu
identity-connection-failure = Yhteysvirhe
identity-connection-internal = Tämä on suojattu { -brand-short-name }-sivu.
identity-connection-file = Sivu on tallennettu tietokoneellesi.
identity-connection-associated = Tämä sivu on ladattu toiselta sivulta.
identity-extension-page = Tämän sivun latasi laajennus.
identity-active-blocked = { -brand-short-name } on estänyt suojaamattoman sisällön näyttämisen.
identity-custom-root = Yhteys on suojattu varmenteella, jonka myöntäjää Mozilla ei tunnista.
identity-passive-loaded = Tällä sivulla on suojaamatonta sisältöä (kuten kuvia).
identity-active-loaded = Suojaamattoman sisällön estäminen on otettu pois päältä sivustolla.
identity-weak-encryption = Sivusto käyttää heikkoa salausta.
identity-https-only-connection-upgraded = (päivitetty HTTPS:ksi)
identity-https-only-label2 = Päivitä tämä sivusto automaattisesti suojattuun yhteyteen
identity-https-only-dropdown-on =
    .label = Käytössä
identity-https-only-dropdown-off =
    .label = Ei käytössä
identity-https-only-dropdown-off-temporarily =
    .label = Ei käytössä väliaikaisesti
identity-https-only-info-turn-on3 = Ota HTTPS-päivitykset käyttöön tälle sivustolle, jos haluat, että { -brand-short-name } päivittää yhteyden suojatuksi sen ollessa mahdollista.
identity-https-only-info-turn-off3 = Jos sivu näyttää rikkinäiseltä, saatat haluta poistaa HTTPS-päivitykset käytöstä tältä sivustolta ladataksesi yhteyden uudelleen käyttämään suojaamatonta HTTP-yhteyttä.
identity-https-only-info-no-upgrade = Yhteyden päivittäminen HTTP:stä epäonnistui.
identity-permissions-storage-access-header = Sivustorajat ylittävät evästeet
identity-permissions-storage-access-hint = Nämä osapuolet voivat käyttää sivustorajat ylittäviä evästeitä ja sivustotietoja, kun olet tällä sivustolla.
identity-permissions-storage-access-learn-more = Lue lisää
identity-permissions-reload-hint = Sivu tarvitsee ehkä päivittää, jotta muutokset tulevat voimaan.
identity-clear-site-data =
    .label = Poista evästeet ja sivustotiedot…
identity-connection-not-secure-security-view = Yhteytesi tähän sivustoon ei ole suojattu.
identity-connection-verified = Yhteytesi tähän sivustoon on suojattu.
identity-ev-owner-label2 = Varmenne myönnetty taholle
identity-verifier-label2 = Varmentanut
identity-ev-owner-label = Varmenne myönnetty taholle:
identity-verifier-label = Varmentaja:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Asetuksen (EU) 2024/1183 mukaisesti kelvollinen.
identity-description-custom-root2 = Mozilla ei tunnista tämän varmenteen myöntäjää. Se on voitu lisätä käyttöjärjestelmästä tai järjestelmänvalvojan toimesta.
identity-cert-exception-overridden = Olet lisännyt tätä sivustoa koskevan turvallisuuspoikkeuksen.
identity-remove-cert-exception =
    .label = Poista poikkeus
    .accesskey = s
identity-description-insecure = Yhteytesi verkkosivustoon ei ole yksityinen. Sivullisten on mahdollista tarkastella antamiasi tietoja (esim. salasanoja, viestejä, luottokorttitietoja).
identity-description-weak-cipher-intro = Yhteytesi verkkosivustoon käyttää heikkoa salausta eikä sen takia ole yksityinen.
identity-description-weak-cipher-risk = Sivullisten on mahdollista tarkastella antamiasi tietoja tai vaikuttaa sivuston toimintaan.
identity-description-active-blocked2 = { -brand-short-name } on estänyt suojaamattoman sisällön näyttämisen.
identity-description-passive-loaded = Yhteytesi verkkosivustoon ei ole yksityinen ja sivullisten on mahdollista tarkastella tietoja, joita lähetät sivustolle.
identity-description-passive-loaded-insecure2 = Tällä sivulla on suojaamatonta sisältöä (kuten kuvia).
identity-description-passive-loaded-mixed2 = Vaikka { -brand-short-name } on osittain estänyt suojaamattoman sisällön, osa näkyvästä sisällöstä on edelleen suojaamatonta (kuten kuvat).
identity-description-active-loaded = Tällä sivulla on suojaamatonta sisältöä (kuten komentosarjoja) eikä yhteytesi sivustoon ei ole yksityinen.
identity-description-active-loaded-insecure = Sivullisten on mahdollista tarkastella antamiasi tietoja (esim. salasanoja, viestejä, luottokorttitietoja).
identity-description-tls-key-logging-heading = Yhteytesi ei välttämättä ole suojattu
identity-description-tls-key-logging-message = Sovellus tai palvelu saattaa nähdä salatun liikenteesi tältä sivustolta.
identity-more-info-link-text =
    .label = Lisätietoja

## Window controls

browser-window-minimize-button =
    .tooltiptext = Pienennä ikkuna
browser-window-maximize-button =
    .tooltiptext = Suurenna
browser-window-restore-down-button =
    .tooltiptext = Palauta pienemmäksi ikkunaksi
browser-window-close-button =
    .tooltiptext = Sulje
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Palaa

## Bookmarks toolbar items

browser-import-button2 =
    .label = Tuo kirjanmerkit…
    .tooltiptext = Tuo kirjanmerkit toisesta selaimsta { -brand-short-name }iin.
bookmarks-toolbar-empty-message = Laita kirjanmerkkisi tänne kirjanmerkkipalkkiin, niin pääset niihin nopeasti. <a data-l10n-name="manage-bookmarks">Järjestele kirjanmerkkejä…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofoni:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofoni
popup-select-speaker-icon =
    .tooltiptext = Kaiuttimet
popup-select-window-or-screen =
    .label = Ikkuna tai näyttö:
    .accesskey = I
popup-all-windows-shared = Kaikki näkyvissä olevat ikkunat jaetaan.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Jaat parhailleen { -brand-short-name }-ikkunaa. Muut näkevät, kun vaihdat uuteen välilehteen.
sharing-warning-screen = Jaat parhaillaan koko näyttöäsi. Muut näkevät, kun vaihdat uuteen välilehteen.
sharing-warning-proceed-to-tab =
    .label = Jatka välilehteen
sharing-warning-disable-for-session =
    .label = Poista jakamisen suojaus tästä istunnosta

## WebSerial "select a port" popup

webserial-select-port-label = Valitse sarjaportti:
webserial-no-ports-available = Sarjaportteja ei ole käytettävissä

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Sulje
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Kirjoita osoite tai hakusana
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Kirjoita osoite
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Hae hakukoneella { $name }
    .placeholder = Hae verkosta
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Hae sivustosta { $name }
    .placeholder = Kirjoita hakuehdot
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Hae kirjanmerkeistä
    .placeholder = Kirjoita hakuehdot
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Hae historiasta
    .placeholder = Kirjoita hakuehdot
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Hae välilehdistä
    .placeholder = Kirjoita hakuehdot
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Etsi toimintoja
    .placeholder = Kirjoita hakuehdot
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Hae hakukoneella { $name } tai kirjoita osoite
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Selain on etäohjauksessa (syy: { $component })
urlbar-permissions-granted =
    .tooltiptext = Olet myöntänyt tälle sivustolle lisäoikeuksia.
urlbar-switch-to-tab =
    .value = Siirry välilehteen:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Laajennus:
urlbar-go-button2 =
    .title = Siirry osoitepalkissa olevaan osoitteeseen
urlbar-page-action-button =
    .tooltiptext = Sivun toiminnot
urlbar-revert-button =
    .tooltiptext = Näytä osoite sijaintipalkissa

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Hae hakukoneella { $engine } yksityisessä ikkunassa
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Hae yksityisessä ikkunassa
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine }-haku
urlbar-result-action-sponsored = Sponsoroitu
urlbar-result-action-switch-tab = Siirry välilehteen
urlbar-result-action-move-tab-to-split-view = Siirrä välilehti jaettuun näkymään
urlbar-result-action-visit = Avaa
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Vaihda välilehteen · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Nimetön ryhmä
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Siirry leikepöydällä olevaan osoitteeseen
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Hae hakukoneella { $engine } painamalla sarkainta
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Hae sivustosta { $engine } painamalla sarkainta
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Hae hakukoneella { $engine } suoraan osoitepalkista
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Hae hakukoneella { $engine } suoraan osoitepalkista
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopioi
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = määrittämätön
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name }-laajennus
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Suositeltu
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong>, { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong>, { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong>, { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Sponsoroitu
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Kysy
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Kävit viimeksi { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Kävit viimeksi { $daysAgo } päivä sitten
       *[other] Kävit viimeksi { $daysAgo } päivää sitten
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Kävit viimeksi { $weeksAgo } viikko sitten
       *[other] Kävit viimeksi { $weeksAgo } viikkoa sitten
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Kävit viimeksi { $monthsAgo } kuukausi sitten
       *[other] Kävit viimeksi { $monthsAgo } kuukautta sitten
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Kävit viimeksi { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Lisätty kirjanmerkkeihin { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Käyty viimeksi { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Käyty viimeksi { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Käyty viimeksi { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Hanki osakemarkkinatietoja suoraan hakupalkkiin
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Näytä markkinapäivityksiä ja muuta kumppaneiltamme, kun jaat hakukyselytietoja toimijan { -vendor-short-name } kanssa. <a data-l10n-name="learn-more-link">Lisätietoja</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Näytä ehdotukset
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Ei nyt
urlbar-result-realtime-opt-in-dismiss = Hylkää
urlbar-result-realtime-opt-in-dismiss-all2 = Älä näytä näitä ehdotuksia
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Älä näytä osakemarkkinaehdotuksia
    .accesskey = Ä
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Älä näytä osakemarkkinaehdotuksia
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Älä näytä näitä ehdotuksia
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Älä näytä osakemarkkinaehdotuksia
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Kiitos palautteestasi. Et enää näe osakemarkkinaehdotuksia.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Osakemarkkinoiden ehdotukset
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Kiitos palautteestasi. Et enää näe näitä ehdotuksia.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · { $daysUntilStart } päivän päästä
       *[other] { $name } · { $daysUntilStart } päivän päästä
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Alkaa { $daysUntilStart } päivän päästä
       *[other] { $name } · Alkaa { $daysUntilStart } päivän päästä
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Päättyy { $daysUntilEnd } päivän päästä
       *[other] { $name } · Päättyy { $daysUntilEnd } päivän päästä
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Tänään
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Päättyy tänään

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine }-haku
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Hae kohteesta { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Hae käyttämällä { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, valitse hakukone
urlbar-searchmode-button-no-engine2 =
    .title = Oikotietä ei ole valittu, valitse oikotie
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Avainsanahaku on poistettu käytöstä
urlbar-searchmode-dropmarker2 =
    .title = Valitse hakukone
urlbar-searchmode-bookmarks4 = Kirjanmerkit
urlbar-searchmode-tabs4 = Välilehdet
urlbar-searchmode-history4 = Sivuhistoria
urlbar-searchmode-actions4 = Toiminnot
urlbar-searchmode-bookmarks3 = Kirjanmerkit
    .accesskey = K
urlbar-searchmode-tabs3 = Välilehdet
    .accesskey = V
urlbar-searchmode-history3 = Sivuhistoria
    .accesskey = S
urlbar-searchmode-actions3 = Toiminnot
    .accesskey = T
urlbar-searchmode-exit-button2 =
    .title = Sulje
urlbar-searchmode-default2 =
    .title = Oletushakukone
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Lisää ”{ $engineName }”
    .title = Lisää hakukone ”{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Tällä kertaa käytä hakuun:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Hae palvelulla:
urlbar-searchmode-popup-search-settings2 = Hakuasetukset
urlbar-searchmode-popup-settings2 = Asetukset
urlbar-searchmode-popup-search-settings = Hakuasetukset
    .accesskey = H
urlbar-searchmode-popup-settings = Asetukset
    .accesskey = A

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Etsi kirjanmerkeistä
urlbar-result-action-search-history = Etsi historiasta
urlbar-result-action-search-tabs = Etsi välilehdistä
urlbar-result-action-search-actions = Etsi toimintoja
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Vaihda ryhmään { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Avaa { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Avaa uuteen välilehteen
    .accesskey = v
urlbar-view-context-menu-open-in-container-tab =
    .label = Avaa uuteen eristettyyn välilehteen
    .accesskey = e
urlbar-view-context-menu-open-in-window =
    .label = Avaa uuteen ikkunaan
    .accesskey = u
urlbar-view-context-menu-open-in-private-window =
    .label = Avaa uuteen yksityiseen ikkunaan
    .accesskey = y
urlbar-view-context-menu-open-in-tab2 = Avaa uuteen välilehteen
    .accesskey = v
urlbar-view-context-menu-open-in-container-tab2 = Avaa uuteen eristettyyn välilehteen
    .accesskey = e
urlbar-view-context-menu-open-in-window2 = Avaa uuteen ikkunaan
    .accesskey = u
urlbar-view-context-menu-open-in-private-window2 = Avaa uuteen yksityiseen ikkunaan
    .accesskey = y
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Ohita tämä valikko, kun käytät sarkainnäppäintä
    .accesskey = O

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine }-ehdotukset
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Pikatoiminnot
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Viimeisimmät haut
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Suosittuja hakukoneessa { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Älä näytä suositujja hakuja
    .accesskey = Ä
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Älä näytä suositujja hakuja
    .accesskey = Ä
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Älä näytä suositujja hakuja
    .accesskey = Ä
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Kiitos palautteestasi. Et näe enää suosittuja hakuja.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Avaa lukunäkymä
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Sulje lukunäkymä

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Avaa kuva kuvassa ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Sulje kuva kuvassa ({ $shortcut })
picture-in-picture-panel-header = Kuva kuvassa
picture-in-picture-panel-headline = Tämä sivusto ei suosittele kuva kuvassa -toimintoa
picture-in-picture-panel-body = Videot eivät välttämättä näy kehittäjän tarkoittamalla tavalla, kun kuva kuvassa -toiminto on käytössä.
picture-in-picture-enable-toggle =
    .label = Ota silti käyttöön

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> on nyt koko näytön tilassa
fullscreen-warning-no-domain = Dokumentti on nyt koko näytön tilassa
fullscreen-exit-button = Poistu koko näytön tilasta (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Poistu koko näytön tilasta (esc)
fullscreen-keyboardlock-exit-button = Poistu koko näytön tilasta (paina ja pidä Esc painettuna)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Poistu koko näytön tilasta (paina ja pidä Esc painettuna)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = Sivusto <span data-l10n-name="domain">{ $domain }</span> hallitsee hiiren osoitinta. Voit ottaa osoittimen hallintaasi painamalla Esc.
pointerlock-warning-no-domain = Tämä sivu hallitsee hiiren osoitinta. Voit ottaa osoittimen hallintaasi painamalla Esc.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Järjestele kirjanmerkkejä
bookmarks-recent-bookmarks-panel-subheader = Uusimmat kirjanmerkit
bookmarks-toolbar-chevron =
    .tooltiptext = Näytä lisää kirjanmerkkejä
bookmarks-sidebar-content =
    .aria-label = Kirjanmerkit
bookmarks-menu-button =
    .label = Kirjanmerkit-valikko
bookmarks-other-bookmarks-menu =
    .label = Muut kirjanmerkit
bookmarks-mobile-bookmarks-menu =
    .label = Kannettavan laitteen kirjanmerkit

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Piilota kirjanmerkkien sivupaneeli
           *[other] Näytä kirjanmerkkien sivupaneeli
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Piilota kirjanmerkkipalkki
           *[other] Näytä kirjanmerkkipalkki
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Piilota kirjanmerkkipalkki
           *[other] Näytä kirjanmerkkipalkki
        }

##

bookmarks-search =
    .label = Etsi kirjanmerkeistä
bookmarks-tools =
    .label = Kirjanmerkkityökalut
bookmarks-subview-edit-bookmark =
    .label = Muokkaa kirjanmerkkiä…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Kirjanmerkit
    .toolbarname = Kirjanmerkkipalkki
    .accesskey = K
bookmarks-toolbar-menu =
    .label = Kirjanmerkkipalkki
bookmarks-toolbar-placeholder =
    .title = Kirjanmerkkipalkin linkit
bookmarks-toolbar-placeholder-button =
    .label = Kirjanmerkkipalkin linkit
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Lisää nykyinen välilehti kirjanmerkkeihin…

## Library Panel items

library-bookmarks-menu =
    .label = Kirjanmerkit

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Korjaa merkistökoodaus
    .tooltiptext = Arvaa oikea merkistökoodaus sivun sisällöstä

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Asetukset
    .tooltiptext =
        { PLATFORM() ->
            [macos] Avaa asetukset ({ $shortcut })
           *[other] Avaa asetuket
        }
toolbar-overflow-customize-button =
    .label = Muokkaa työkalupalkkia…
    .accesskey = M
toolbar-button-email-link =
    .label = Lähetä linkki
    .tooltiptext = Lähetä linkki sähköpostilla
toolbar-button-logins =
    .label = Salasanat
    .tooltiptext = Näytä ja hallitse tallennettuja salasanoja
qrcode-panel-error =
    .message = QR-koodin luominen epäonnistui. Yritä uudelleen.
qrcode-copy-button =
    .label = Kopioi
qrcode-copy-success =
    .message = QR-koodi kopioitu leikepöydälle.
qrcode-copy-error =
    .message = QR-koodin kopiointi epäonnistui.
qrcode-save-button =
    .label = Tallenna
qrcode-window-title = QR-koodi
qrcode-dialog-title = QR-koodi
qrcode-image =
    .aria-label = QR-koodi
qrcode-close-button =
    .aria-label = Sulje
toolbar-button-save-page =
    .label = Tallenna sivu
    .tooltiptext = Tallenna avoin sivu ({ $shortcut })
toolbar-button-open-file =
    .label = Avaa tiedosto
    .tooltiptext = Avaa tiedosto ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Synkronoidut välilehdet
    .tooltiptext = Näytä muiden laitteiden välilehdet
toolbar-button-send-tab =
    .label = Lähetä välilehti
    .tooltiptext = Lähetä nykyinen välilehti toiselle laitteelle
toolbar-button-new-private-window =
    .label = Uusi yksityinen ikkuna
    .tooltiptext = Avaa yksityinen selaaminen -ikkuna ({ $shortcut })
toolbar-button-share-tab =
    .label = Jaa
    .tooltiptext = Jaa tämä sivu
toolbar-button-tab-groups =
    .label = Välilehtiryhmät
    .tooltiptext = Näytä välilehtiryhmät
toolbar-button-history =
    .label = Sivuhistoria
    .tooltiptext = Näytä sivuhistoria ({ $shortcut })
toolbar-button-find =
    .label = Etsi
    .tooltiptext = Etsi sivulta ({ $shortcut })
toolbar-button-developer =
    .label = Web-työkalut
    .tooltiptext = Avaa web-työkalut (englanninkielisiä) ({ $shortcut })
toolbar-button-forget =
    .label = Unohda
    .tooltiptext = Unohda jonkin verran selaushistoriaa
toolbar-zoom-controls =
    .label = Lähennyksen valitsimet
    .title = Lähennyksen valitsimet
toolbar-button-zoom-out =
    .label = Loitonna
    .tooltiptext = Loitonna ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Palauta oletuslähennystaso ({ $shortcut })
toolbar-button-zoom-in =
    .label = Lähennä
    .tooltiptext = Lähennä ({ $shortcut })
toolbar-edit-controls =
    .label = Muokkauksen valitsimet
    .title = Muokkauksen valitsimet
toolbar-button-cut =
    .label = Leikkaa
    .tooltiptext = Leikkaa ({ $shortcut })
toolbar-button-copy =
    .label = Kopioi
    .tooltiptext = Kopioi ({ $shortcut })
toolbar-button-paste =
    .label = Liitä
    .tooltiptext = Liitä ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrkoodi
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrkoodi-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Osa sivuston äänitteistä tai videoista käyttää DRM-ohjelmistoa, joka voi rajoittaa mitä { -brand-short-name } voi antaa tehdä niillä.
eme-notifications-drm-content-playing-manage = Muokkaa asetuksia
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = Hylkää
eme-notifications-drm-content-playing-dismiss-accesskey = H

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = DRM täytyy ottaa käyttöön, jotta joitain tällä sivulla olevia ääniä tai videoita voi toistaa.
eme-notifications-drm-content-disabled-button =
    .label = Ota DRM-tuki käyttöön
    .accesskey = O
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } asentaa komponentteja, joita tarvitaan toistamaan sivun äänitteitä tai videoita. Yritä myöhemmin uudestaan.
decoder-doctor-no-codecs-linux-message = Vaaditut videokoodekit tarvitsee ehkä asentaa, jotta voit toistaa videon.
decoder-doctor-no-hw-acceleration-message = Microsoftin Mediaominaisuuspaketti tarvitsee ehkä asentaa videon laadun parantamiseksi.
decoder-doctor-no-pulse-audio-message = PulseAudio-ohjelmisto tarvitsee ehkä asentaa, jotta voit toistaa ääntä.
decoder-doctor-unsupported-libavcodec-message = libavcodec voi olla haavoittuvainen tai ehkä sitä ei tueta, ja se pitäisi päivittää, jotta voit katsoa videoita.
decoder-doctor-decode-error-message = Tapahtui virhe purettaessa mediaresurssia.
decoder-doctor-decode-warning-message = Tapahtui toivuttavissa oleva virhe purettaessa mediaresurssia.
decoder-doctor-learn-how-link = Lue miten
decoder-doctor-report-issue-button =
    .label = Ilmoita sivuston ongelmasta
    .accesskey = I
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Liitännäinen { $pluginName } kaatui.
plugin-crashed-notification-reload-button =
    .label = Lataa sivu uudestaan
    .accesskey = L
plugin-crashed-notification-submit-button =
    .label = Lähetä kaatumisilmoitus
    .accesskey = k

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Petollinen sivusto!
safebrowsing-reported-attack-site-message = Ilmoitettu hyökkäyssivusto!
safebrowsing-reported-unwanted-site-message = Ilmoitettu ei-haluttuja sovelluksia jakava sivusto!
safebrowsing-reported-harmful-site-message = Ilmoitettu haitallinen sivusto!
safebrowsing-get-me-out-of-here-button =
    .label = Siirry pois sivustolta!
    .accesskey = S
safebrowsing-not-a-deceptive-site-button =
    .label = Tämä ei ole petollinen sivusto…
    .accesskey = e
safebrowsing-not-an-attack-site-button =
    .label = Tämä ei ole hyökkäyssivusto…
    .accesskey = e

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Tähän verkkoon täytyy kirjautua ennen internetin käyttämistä.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Avaa verkon kirjautumissivu

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Halusitko avata sivuston { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Kyllä, avaa { $hostName }
    .accesskey = K

## Password save/update panel

panel-save-update-username-2 =
    .label = Käyttäjätunnus
panel-save-update-password-2 =
    .label = Salasana

##

# "More" item in macOS share menu
menu-share-more =
    .label = Lisää…
menu-share-windows =
    .label = Lisää valintoja
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Kopioi linkki
           *[other] Kopioi { $count } linkkiä
        }
    .accesskey = l
ui-tour-info-panel-close =
    .tooltiptext = Sulje

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Salli ponnahdusikkunat ja kolmannen osapuolen uudelleenohjaukset sivustolle { $uriHost }
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = Piilota kuva kuvassa -kytkin
    .accesskey = P

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Siirrä kuva kuvassa -kytkin oikealle puolelle
    .accesskey = o
picture-in-picture-move-toggle-left =
    .label = Siirrä kuva kuvassa -kytkin vasemmalle puolelle
    .accesskey = v

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigointi
navbar-downloads =
    .label = Lataukset
navbar-overflow-2 =
    .tooltiptext = Lisää työkaluja
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Tulosta
    .tooltiptext = Tulosta sivu… ({ $shortcut })
navbar-home =
    .label = Aloitussivu
    .tooltiptext = { -brand-short-name }-aloitussivu
navbar-library =
    .label = Kirjasto
    .tooltiptext = Katsele historiaa, tallennettuja kirjanmerkkejä ynnä muuta
navbar-search =
    .title = Etsi
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Selaimen välilehdet
tabs-toolbar-new-tab =
    .label = Uusi välilehti
tabs-toolbar-list-all-tabs =
    .label = Listaa kaikki välilehdet
    .tooltiptext = Listaa kaikki välilehdet

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Pudota välilehti tähän kiinnittääksesi sen

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Haluatko avata aiemmat välilehdet?</strong> Voit palauttaa aiemman istunnon { -brand-short-name }in sovellusvalikosta <img data-l10n-name="icon"/> kohdasta Sivuhistoria.
restore-session-startup-suggestion-button = Näytä ohje

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Organisaatiosi on estänyt pääsyn paikallisiin tiedostoihin tällä tietokoneella

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-dismiss = Selvä

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } lähettää automaattisesti joitain tietoja { -vendor-short-name }lle käyttökokemuksen parantamiseksi.
data-reporting-notification-button =
    .label = Valitse lähetettävät tiedot
    .accesskey = V
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Yksityinen selaus
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Yksityinen selaus
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Yksityisen selauksen tiedot
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Olet yksityisessä ikkunassa
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Tämä auttaa pitämään selaamisesi piilossa muilta tällä laitteella, mutta ei tee sinusta näkymätöntä verkossa. <a data-l10n-name="learn-more">Kuka saattaa nähdä toimintani?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Tietojen menetyksen estäminen (DLP), tekijä { $agentName }. Napsauta saadaksesi lisätietoja.
content-analysis-panel-title2 = Tietojen menetyksen estäminen
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Organisaatiosi hallitsee arkaluonteisten tietojen jakamista ohjelmistolla <b>{ $agentName }</b>. <a data-l10n-name="info">Lue lisää</a>
content-analysis-panel-title = Tietojen suojaus
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Organisaatiosi käyttää <b>{ $agentName }</b> tietojen menetyksen estämiseksi. <a data-l10n-name="info">Lisätietoja</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Laajennukset
    .tooltiptext = Laajennukset

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Laajennukset
    .tooltiptext =
        Laajennukset
        Lupia vaaditaan

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Laajennukset
    .tooltiptext =
        Laajennukset
        Joitain laajennuksia ei sallita

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Laajennukset
    .tooltiptext =
        Laajennukset
        Jotkin laajennukset on poistettu käytöstä

## Private browsing reset button

reset-pbm-panel-heading2 = Tyhjennetäänkö tiedot ja aloitetaanko uusi yksityinen istunto?
reset-pbm-panel-description2 = Tämä poistaa historian, evästeet ja kaikki muut sivuston tiedot sulkematta yksityistä ikkunaa.
reset-pbm-panel-always-ask-checkbox =
    .label = Kysy aina
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = Peruuta
    .accesskey = P
reset-pbm-panel-confirm-button2 =
    .label = Tyhjennä yksityinen istunto
    .accesskey = i
reset-pbm-panel-complete = Yksityisen istunnon tiedot poistettu
reset-pbm-toolbar-button2 =
    .label = Tyhjennä yksityinen istunto
    .tooltiptext = Tyhjennä yksityinen istunto

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Poistetaanko kaikki selaustiedot?
fire-button-panel-description = Tämä poistaa historian, evästeet ja sivustotiedot. Sinut kirjataan ulos sivustoilta. Tämä ikkuna sulkeutuu ja { -brand-short-name } avaa uuden ikkunan.
fire-button-panel-choose-description = Jos et halua poistaa kaikkea, valitse sen sijaan poistettavat tiedot yksittäin.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Valitse…
fire-button-panel-cancel-button =
    .label = Peruuta
    .accesskey = P
fire-button-panel-confirm-button =
    .label = Poista kaikki
    .accesskey = P
fire-button-panel-complete = Selaustiedot poistettu

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } esti sivua päivittymästä.
refresh-blocked-redirect-label = { -brand-short-name } esti sivua ohjautumasta automaattisesti toiselle sivulle.
refresh-blocked-allow =
    .label = Salli
    .accesskey = S

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Turvalliset ja helppokäyttöiset maskit suojaavat henkilöllisyyttäsi sekä estävät roskapostia piilottamalla sähköpostiosoitteesi.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Kaikki sähköpostimaskeihisi lähetetyt sähköpostit välitetään edelleen osoitteeseen <strong>{ $useremail }</strong> (ellet päätä estää saapuvia viestejä).
firefox-relay-offer-legal-notice = Napsauttamalla “Käytä sähköpostimaskia” hyväksyt <label data-l10n-name="tos-url">käyttöehdot</label> ja <label data-l10n-name="privacy-url">tietosuojakäytännön</label>.
firefox-relay-offer-legal-notice-1 = Rekisteröitymällä ja luomalla sähköpostimaskin hyväksyt <label data-l10n-name="tos-url">käyttöehdot</label> ja <label data-l10n-name="privacy-url">tietosuojakäytännön</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Varmentamaton)
popup-notification-xpinstall-prompt-learn-more = Lue lisää lisäosien asentamisesta turvallisesti
popup-notification-xpinstall-prompt-block-url = Näytä yksityiskohdat
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Salli laajennuksen suorittaminen yksityisissä ikkunoissa
    .accesskey = ä
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Jaa teknisiä ja vuorovaikutustietoja laajennuskehittäjän kanssa
    .accesskey = s

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } esti tätä sivustoa avaamasta ponnahdusikkunaa.
       *[other] { -brand-short-name } esti tätä sivustoa avaamasta { $popupCount } ponnahdusikkunaa.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } esti tätä sivustoa uudelleenohjaamasta.
        [1] { -brand-short-name } esti tätä sivustoa avaamasta ponnahdusikkunaa ja uudelleenohjaamasta.
        [one] { -brand-short-name } esti tätä sivustoa avaamasta { $popupCount } ponnahdusikkunaa ja uudelleenohjaamasta.
       *[other] { -brand-short-name } esti tätä sivustoa avaamasta { $popupCount } ponnahdusikkunaa ja uudelleenohjaamasta.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } esti tätä sivustoa avaamasta enemmän kuin { $popupCount } ponnahdusikkunaa.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } esti tätä sivustoa avaamasta yli { $popupCount } ponnahdusikkunaa ja uudelleenohjaamasta.
       *[other] { -brand-short-name } esti tätä sivustoa avaamasta yli { $popupCount } ponnahdusikkunaa ja uudelleenohjaamasta.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Asetukset
           *[other] Asetukset
        }
    .accesskey =
        { PLATFORM() ->
            [windows] A
           *[other] A
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Näytä ”{ $popupURI }”
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Näytä “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Windowsin tiedostovalintaikkunaa ei voitu avata. Tiedostoa tai kansiota ei voitu valita.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Windowsin tiedostovalintaikkunaa ei voitu avata. Tiedosto tallennetaan sijaintiin { $path }.
file-picker-failed-save-nowhere = Windowsin tiedostovalintaikkunaa ei voitu avata. Oletuskansiota ei löytynyt; tiedostoa ei tallenneta.
file-picker-crashed-open = Windowsin tiedostovalintaikkuna on kaatunut. Tiedostoa tai kansiota ei voitu valita.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windowsin tiedostovalintaikkuna on kaatunut. Tiedosto tallennetaan sijaintiin { $path }.
file-picker-crashed-save-nowhere = Windowsin tiedostovalintaikkuna on kaatunut. Oletuskansiota ei löytynyt; tiedostoa ei tallenneta.
file-picker-crashed-show-in-folder =
    .label = Näytä kansiossa
    .accessKey = K

## Unsigned add-ons notification

unsigned-addons-disabled-message = Yhtä tai useampaa lisäosaa ei ole varmennettu, ja ne on poistettu käytöstä.
unsigned-addons-disabled-learn-more =
    .label = Lue lisää
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Tämä sivu hidastaa { -brand-short-name }ia. Voit nopeuttaa selainta pysäyttämällä sivun.
process-hang-nonspecific-tab-message = Verkkosivu hidastaa { -brand-short-name }ia. Voit nopeuttaa selainta pysäyttämällä sivun.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = Sivu ”{ $title }” hidastaa { -brand-short-name }ia. Voit nopeuttaa selainta pysäyttämällä sivun.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = Laajennus ”{ $addonName }” hidastaa { -brand-short-name }ia. Voit nopeuttaa selainta pysäyttämällä laajennuksen.
process-hang-addon-learn-more =
    .value = Lue lisää
process-hang-stop-button =
    .label = Pysäytä
    .accesskey = P

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Viimeistele määritys
onboarding-aw-finish-setup-button =
    .label = Viimeistele määritys
    .tooltiptext = Viimeistele { -brand-short-name }in määritys

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Tehostettu seurannan suojaus on päällä
trustpanel-etp-label-disabled = Tehostettu seurannan suojaus ei ole päällä
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Tehostettu seurannan suojaus: Käytössä sivustolla { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Tehostettu seurannan suojaus: Ei käytössä sivustolla { $host }
trustpanel-etp-description-enabled = Jos jokin näyttää olevan rikki tällä sivustolla, yritä poistaa suojaukset käytöstä.
trustpanel-etp-description-disabled = { -brand-product-name } on sitä mieltä, että yritysten tulisi seurata sinua vähemmän. Estämme niin monta seurainta kuin mahdollista, kun otat suojaukset käyttöön.
trustpanel-connection-label-secure = Yhteys on suojattu
trustpanel-connection-label-insecure = Yhteys ei ole suojattu
trustpanel-header-enabled = { -brand-product-name } on valppaana
trustpanel-description-enabled2 = Olet suojattu. Jos havaitsemme jotain, ilmoitamme sinulle.
trustpanel-header-enabled-insecure = Ole varovainen tällä sivustolla
trustpanel-description-enabled-insecure = { -brand-product-name } huomasi jotain epäilyttävää.
trustpanel-header-disabled = Poistit suojaukset käytöstä
trustpanel-description-disabled = { -brand-product-name } ei ole työvuorossa. Suosittelemme suojausten kytkemistä takaisin päälle.
trustpanel-clear-cookies-button = Tyhjennä evästeet ja sivustotiedot
trustpanel-privacy-link = Tietosuoja-asetukset
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Tyhjennä evästeet ja sivustotiedot sivuston { $host } osalta
trustpanel-clear-cookies-description = Evästeiden ja sivustotietojen poistaminen saattaa kirjata sinut ulos verkkosivustoilta ja tyhjentää ostoskorit.
trustpanel-clear-cookies-subview-button-clear = Tyhjennä
trustpanel-clear-cookies-subview-button-cancel = Peruuta
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Yhteyden suojaukset sivustolle { $host }
trustpanel-siteinformation-morelink = Lisätietoja sivustosta
trustpanel-blocker-see-all = Näytä kaikki
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Seurantasuojaukset sivustolle { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Ei suojattu
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } seurain estetty
       *[other] { $count } seurainta estetty
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } on sitä mieltä, että yritysten pitäisi seurata sinua vähemmän. Siksi estämme niin monta seurainta kuin pystymme.
trustpanel-blocked-header = { -brand-product-name } esti nämä puolestasi:
trustpanel-tracking-header = { -brand-product-name } salli nämä asiat, jotta sivustot eivät rikkoutuisi:
trustpanel-tracking-description = Ilman seuraimia jotkin painikkeet, lomakkeet ja kirjautumiskentät eivät välttämättä toimi.
trustpanel-insecure-section-header = Yhteys ei ole suojattu
trustpanel-insecure-description = Tälle sivustolle lähettämiäsi tietoja ei salata. Niitä voidaan tarkastella, varastaa tai muuttaa.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } sivustorajat ylittävä seuraineväste
       *[other] { $count } sivustorajat ylittävää seurainevästettä
    }
trustpanel-list-label-tracking-content = Seurantaan tarkoitettu sisältö
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } yksilöijä
       *[other] { $count } yksilöijää
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } sosiaalisen median seurain
       *[other] { $count } sosiaalisen median seurainta
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } kryptolouhija
       *[other] { $count } kryptolouhijaa
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } esti { $count } sosiaalisen median seuraimen
       *[other] { -brand-product-name } esti { $count } sosiaalisen median seurainta
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } salli { $count } sosiaalisen median seuraimen
       *[other] { -brand-product-name } salli { $count } sosiaalisen median seurainta
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } esti { $count } sivustorajat ylittävän seurainevästeen
       *[other] { -brand-product-name } esti { $count } sivustorajat ylittävää seurainevästettä
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } salli { $count } sivustorajat ylittävän seurainevästeen
       *[other] { -brand-product-name } salli { $count } sivustorajat ylittävää seurainevästettä
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } esti { $count } seuraimen
       *[other] { -brand-product-name } esti { $count } seurainta
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } salli { $count } seuraimen
       *[other] { -brand-product-name } salli { $count } seurainta
    }
trustpanel-tracking-content-tab-list-header = Nämä sivustot yrittävät seurata sinua:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } esti { $count } yksilöijän
       *[other] { -brand-product-name } esti { $count } yksilöijää
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } salli { $count } yksilöijän
       *[other] { -brand-product-name } salli { $count } yksilöijää
    }
trustpanel-fingerprinter-list-header = Nämä sivustot yrittävät yksilöidä sinut:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } esti { $count } kryptolouhijan
       *[other] { -brand-product-name } esti { $count } kryptolouhijaa
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } salli { $count } kryptolouhijan
       *[other] { -brand-product-name } salli { $count } kryptolouhijaa
    }
trustpanel-cryptominer-tab-list-header = Nämä sivustot yrittävät louhia kryptovaluuttoja:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Onko sinulla tili tälle sivustolle?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } havaitsi, että tällä sivustolla on ollut tietomurto viimeisen 12 kuukauden aikana. Ota selvää, koskiko se sinua.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Hylkää
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Aloita ilmainen tarkistus
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> seurain estetty tällä sivustolla
       *[other] <span data-l10n-name="count">{ $count }</span> seurainta estetty tällä sivustolla
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Näyttääkö sivusto rikkinäiseltä?</strong> Lataa sivu uudelleen, niin seurannan suojausta heikennetään väliaikaisesti.
reduced-protection-infobar-reload-button = Lataa uudelleen
    .accesskey = L
reduced-protection-infobar-never-show-button = Älä näytä uudelleen
    .accesskey = Ä


identity-allow-site-data = vOrbit-lite: Tallenna aina evästeet/tiedot tälle sivustolle
urlbar-webgl-notification-anchor =
    .tooltiptext = Hallitse WebGL-kontekstin luomisen käyttöoikeutta
urlbar-webgl-blocked =
    .tooltiptext = Olet estänyt WebGL-kontekstin luomisen tällä verkkosivustolla.
