# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.



translations-panel-disable-translations =
    .label = Eemalda tõlkimine tervikuna kasutusest
translations-manage-enable =
    .label = Võimalda täislehtede tõlkeid
translations-manage-autopopup =
    .label = Paku võimalust tõlkida lehti, mis pole brauseri seadistatud keelte hulgas
