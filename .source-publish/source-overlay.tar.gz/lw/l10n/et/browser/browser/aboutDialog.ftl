# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

aboutDialog-title =
    .title = { -brand-full-name }i teave
releaseNotes-link = Uuendused
update-checkForUpdatesButton =
    .label = Kontrolli uuendusi
    .accesskey = K
update-updateButton =
    .label = Uuendamiseks taaskäivita { -brand-shorter-name }
    .accesskey = U
update-checkingForUpdates = Uuenduste olemasolu kontrollimine…
settings-update-checking-for-updates =
    .label = Uuenduste olemasolu kontrollimine…

## Variables:
##   $transfer (string) - Transfer progress.

aboutdialog-update-downloading = Uuenduse allalaadimine — <label data-l10n-name="download-status">{ $transfer }</label>
settings-update-downloading-2 =
    .label = Uuenduse allalaadimine — { $transfer }

##

update-applying = Uuenduse rakendamine…
settings-update-applying =
    .label = Uuenduse rakendamine…
update-failed = Uuendamine ebaõnnestus. <label data-l10n-name="failed-link">Laadi alla uusim versioon</label>
update-failed-main = Uuendamine ebaõnnestus. <a data-l10n-name="failed-link-main">Laadi alla uusim versioon</a>
update-policy-disabled = Värskendused on sinu organisatsiooni poolt keelatud
settings-update-policy-disabled =
    .label = Värskendused on sinu organisatsiooni poolt keelatud
update-noUpdatesFound = Kasutusel on { -brand-short-name }i uusim versioon
settings-update-no-updates-found =
    .label = Kasutusel on { -brand-short-name }i uusim versioon
aboutdialog-update-checking-failed = Uuenduste kontrollimine ebaõnnestus.
settings-update-checking-failed =
    .label = Uuenduste kontrollimine ebaõnnestus.
update-otherInstanceHandlingUpdates = { -brand-short-name }i uuendatakse teise protsessi poolt
settings-update-other-instance-handling-updates =
    .label = { -brand-short-name }i uuendatakse teise protsessi poolt

## Variables:
##   $displayUrl (String): URL to page with download instructions. Example: www.mozilla.org/firefox/nightly/

aboutdialog-update-manual-with-link = Uuendused on saadaval aadressil <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-manual-with-link = Uuendused on saadaval aadressil <a data-l10n-name="manual-link">{ $displayUrl }</a>
update-unsupported = Edasised uuendused selle süsteemi peal pole võimalikud. <label data-l10n-name="unsupported-link">Rohkem teavet</label>
settings-update-unsupported = Edasised uuendused selle süsteemi peal pole võimalikud. <a data-l10n-name="unsupported-link">Rohkem teavet</a>
update-restarting = Taaskäivitamine…
settings-update-restarting =
    .label = Taaskäivitamine…
update-internal-error2 = Sisemise vea tõttu pole võimalik uuendusi kontrollida. Uuendused on saadaval aadressil <label data-l10n-name="manual-link">{ $displayUrl }</label>
settings-update-internal-error = Sisemise vea tõttu pole võimalik uuendusi kontrollida. Uuendused on saadaval aadressil <a data-l10n-name="manual-link">{ $displayUrl }</a>

##

# Variables:
#   $channel (String): description of the update channel (e.g. "release", "beta", "nightly" etc.)
aboutdialog-channel-description = Kasutusel on uuendustekanal <label data-l10n-name="current-channel">{ $channel }</label>.
warningDesc-version = { -brand-short-name } on katsetamiseks ja võib olla ebastabiilne.
aboutdialog-help-user = { -brand-product-name }i abi
aboutdialog-submit-feedback = Saada tagasisidet
community-exp = <label data-l10n-name="community-exp-mozillaLink">{ -vendor-short-name }</label> on <label data-l10n-name="community-exp-creditsLink">üleilmne kogukond</label>, kes töötab koos, et hoida internet avatuna, avalikuna ja ligipääsetavana kõigile.
community-2 = { -brand-short-name } on loodud <label data-l10n-name="community-mozillaLink">{ -vendor-short-name }</label> <label data-l10n-name="community-creditsLink">üleilmse kogukonna </label> poolt. Me usume, et internet peaks olema avatud, avalik ja ilma igasuguste piiranguteta ligipääsetav kõigile.
helpus = Soovid aidata? <label data-l10n-name="helpus-donateLink">Tee annetus</label> või <label data-l10n-name="helpus-getInvolvedLink">löö kaasa!</label>
bottomLinks-license = Litsentsist
bottom-links-terms = Kasutustingimused
bottom-links-privacy = Privaatsusteatis
# Example of resulting string: 66.0.1 (64-bit)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version = { $version } ({ $bits }-bitine)
# Example of resulting string: 66.0a1 (2019-01-16) (64-bit)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $bits (Number): bits of the architecture (32 or 64)
aboutDialog-version-nightly = { $version } ({ $isodate }) ({ $bits }-bitine)
# Example of resulting string: 131.0a1 (aarch64)
# Variables:
#   $version (String): version of Firefox, e.g. 66.0.1
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch = { $version } ({ $arch })
# Example of resulting string: 131.0a1 (2024-08-27) (aarch64)
# Variables:
#   $version (String): version of Firefox for Nightly builds, e.g. 66.0a1
#   $isodate (String): date in ISO format, e.g. 2019-01-16
#   $arch (String): name of the architecture (arm, aarch64, etc.)
aboutdialog-version-arch-nightly = { $version } ({ $isodate }) ({ $arch })


about-vorbit = vOrbit-lite on kohandatud versioon Firefoxist, mis on keskendunud privaatsusele, turvalisusele ja kasutajate vabadusele.
