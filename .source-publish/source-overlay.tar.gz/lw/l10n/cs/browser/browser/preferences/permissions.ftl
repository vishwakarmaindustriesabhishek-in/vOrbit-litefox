# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 36em
    .title = Výjimky
permissions-close-key =
    .key = w
permissions-address = Adresa webového serveru
    .accesskey = d
permissions-block =
    .label = Blokovat
    .accesskey = B
permissions-disable-etp =
    .label = Přidat výjimku
    .accesskey = P
permissions-session =
    .label = Povolit pro relaci
    .accesskey = o
permissions-allow =
    .label = Povolit
    .accesskey = P
permissions-add =
    .label = Přidat
    .accesskey = P
permissions-button-off =
    .label = Vypnout
    .accesskey = o
permissions-button-off-temporarily =
    .label = Dočasně vypnout
    .accesskey = t
permissions-site-name =
    .label = Server
permissions-status =
    .label = Stav
permissions-remove =
    .label = Odebrat server
    .accesskey = r
permissions-remove-all =
    .label = Odebrat všechny servery
    .accesskey = e
permissions-save-changes-2 =
    .buttonlabelaccept = Uložit změny
    .buttonaccesskeyaccept = U
permission-dialog =
    .buttonlabelaccept = Uložit změny
    .buttonaccesskeyaccept = U
permissions-autoplay-menu = Výchozí nastavení:
permissions-searchbox =
    .placeholder = Hledat
permissions-capabilities-autoplay-allow =
    .label = povolit zvuk i video
permissions-capabilities-autoplay-block =
    .label = blokovat zvuk
permissions-capabilities-autoplay-blockall =
    .label = blokovat zvuk i video
permissions-capabilities-allow =
    .label = Povolit
permissions-capabilities-block =
    .label = Blokovat
permissions-capabilities-prompt =
    .label = Vždy se zeptat
permissions-capabilities-listitem-allow =
    .value = Povolit
permissions-capabilities-listitem-block =
    .value = Blokovat
permissions-capabilities-listitem-allow-session =
    .value = Povolit pro relaci
permissions-capabilities-listitem-off =
    .value = Vypnuto
permissions-capabilities-listitem-off-temporarily =
    .value = Dočasně vypnuto

## Invalid Hostname Dialog

permissions-invalid-uri-title = Neplatný název serveru
permissions-invalid-uri-label = Vložte prosím platný název serveru

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Výjimky pro používání rozšířené ochrany proti sledování
permissions-exceptions-manage-etp-desc = Zde můžete určit, které servery mají vypnutu rozšířenou ochranu proti sledování. Vložte přesnou adresu serveru, který chcete spravovat, a poté klepněte na tlačítko Přidat výjimku.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Výjimky pro používání cookies a dat stránek
permissions-exceptions-cookie-desc = Zde můžete určit, které servery mohou nebo nesmí používat cookies a data stránek. Zadejte přesnou adresu serveru a klepněte na tlačítko Blokovat, Povolit pro relaci nebo Povolit.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Výjimky – Vymazání historie při vypnutí
permissions-exceptions-shutdown-clearing-desc = Můžete určit, které webové stránky si ponechají svá data, když { -brand-short-name } při zavření vymaže historii. Zadejte přesnou adresu stránky, kterou chcete spravovat, a poté klepněte na Povolit.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Servery, které mohou používat nezabezpečený protokol HTTP
permissions-exceptions-https-only-desc2 = Zde můžete určit, které servery mohou používat nezabezpečený protokol HTTP. Na těchto serverech se { -brand-short-name } nebude pokoušet o navázání zabezpečeného spojení skrze protokol HTTPS.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Povolené weby - vyskakovací okna a přesměrování třetích stran
permissions-exceptions-popup-desc2 = Zde můžete určit, které servery mohou otevírat vyskakovací okna a být přesměrovány pomocí rámů třetích stran.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Výjimky pro ukládání hesel
permissions-exceptions-saved-passwords-desc = { -brand-short-name } neuloží hesla pro weby uvedené v tomto seznamu.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Důvěryhodné servery pro instalaci doplňků
permissions-exceptions-addons-desc = Zde můžete určit, které servery mohou instalovat doplňky. Zadejte přesnou adresu serveru a klepněte na tlačítko Povolit.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění automatického přehrávání
permissions-site-autoplay-desc = Níže můžete nastavit výjimky a vlastní nastavení pro vámi vybrané servery.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění zasílat oznámení
permissions-site-notification-desc = Následující servery požádaly o povolení vám zasílat oznámení. Zde můžete určit, které servery mají nebo nemají povoleno vám oznámení zasílat. Můžete zde také zablokovat nové žádosti o povolení.
permissions-site-notification-disable-label =
    .label = Blokovat nové žádosti o povolení zasílat oznámení
permissions-site-notification-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o povolení vám zasílat oznámení. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Povolit stránkám zobrazovat oznámení, i když je { -brand-short-name } zavřený
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Platí také nastavení oznámení ve vašem operačním systému.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění zjišťovat polohu
permissions-site-location-desc = Následující servery požádaly o přístup k údajům o vaší poloze. Zde můžete určit, které servery mají nebo nemají povoleno vaši polohu zjistit. Můžete zde také zablokovat nové žádosti o přístup.
permissions-site-location-disable-label =
    .label = Blokovat nové žádosti o přístup k údajům o vaší poloze
permissions-site-location-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k údajům o vaší poloze. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění pro virtuální realitu
permissions-site-xr-desc = Následující servery požádaly o přístup k vašim zařízením pro virtuální realitu. Zde můžete určit, které servery mají nebo nemají povoleno tato zařízení používat. Můžete zde také zablokovat nové žádosti o přístup.
permissions-site-xr-disable-label =
    .label = Blokovat nové žádosti o přístup k vašim zařízením pro virtuální realitu
permissions-site-xr-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k vašim zařízením pro virtuální realitu. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Nastavení - Blokované stránky pro otevírání odkazů v aplikacích
permissions-site-app-links-desc = Tyto stránky se nemohou dotazovat na otevírání odkazů v aplikacích, například e-mailových odkazů (mailto:). Odebráním stránce opět umožníte se dotázat.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění přístupu ke kameře
permissions-site-camera-desc = Následující servery požádaly o přístup k vaší kameře. Zde můžete určit, které servery mají nebo nemají povoleno vaši kameru používat. Můžete zde také zablokovat nové žádosti o přístup.
permissions-site-camera-disable-label =
    .label = Blokovat nové žádosti o přístup k vaší kameře
permissions-site-camera-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k vaší kameře. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Nastavení - Aplikace a služby v zařízení
permissions-site-localhost-desc = Tyto servery požádaly o přístup k aplikacím a službám na tomto zařízení. Můžete jim ho povolit nebo zakázat.
permissions-site-localhost-disable-label =
    .label = Blokovat nové žádosti o přístup k aplikacím a službám na tomto zařízení
permissions-site-localhost-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k aplikacím a službám v tomto zařízení. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Nastavení - Zařízení v místní síti
permissions-site-local-network-desc = Tyto servery požádaly o přístup k aplikacím a službám na zařízeních připojených k vaší Wi-Fi nebo místní síti. Můžete jim ho povolit nebo zakázat.
permissions-site-local-network-disable-label =
    .label = Blokovat nové žádosti o přístup k aplikacím a službám na zařízeních připojených k vaší Wi-Fi nebo místní síti.
permissions-site-local-network-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k aplikacím a službám na zařízeních připojených k vaší Wi-Fi nebo místní síti. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Oprávnění přístupu k mikrofonu
permissions-site-microphone-desc = Následující servery požádaly o přístup k vašemu mikrofonu. Zde můžete určit, které servery mají nebo nemají povoleno váš mikrofon používat. Můžete zde také zablokovat nové žádosti o přístup.
permissions-site-microphone-disable-label =
    .label = Blokovat nové žádosti o přístup k vašemu mikrofonu
permissions-site-microphone-disable-desc = Tímto zakážete všem serverům, které nejsou v seznamu výše, požádat o přístup k vašemu mikrofonu. Při blokování žádostí nemusí některé funkce webových stránek správně fungovat.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Oprávnění přístupu k reproduktoru
permissions-site-speaker-desc = Následující servery požádaly o výběr výstupního zvukového zařízení. Zde můžete určit, které servery mají povoleno vybrat výstupní zvukové zařízení.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Výjimky pro DNS over HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } nebude zabezpečené DNS na těchto serverech a jejich subdoménách používat.
permissions-doh-entry-field = Zadejte doménové jméno
    .accesskey = d
permissions-doh-add-exception =
    .label = Přidat
    .accesskey = a
permissions-doh-col =
    .label = Doména
permissions-doh-remove =
    .label = Odebrat
    .accesskey = r
permissions-doh-remove-all =
    .label = Odebrat vše
    .accesskey = e


permissions-site-webgl-window2 =
    .title = Nastavení - Oprávnění WebGL
    .style = { permissions-window2.style }
permissions-site-webgl-desc = Následující webové stránky požádaly o vytvoření kontextu WebGL. Můžete určit, které webové stránky smí vytvořit kontext WebGL. Můžete také zablokovat nové žádosti požadující vytvoření kontextu WebGL.
