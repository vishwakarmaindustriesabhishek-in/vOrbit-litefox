# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Říkat webům, aby neprodávaly ani nesdílely vaše údaje
    .accesskey = s
non-technical-privacy-group =
    .label = Předvolby ochrany soukromí na webových stránkách
do-not-track-removal3 =
    .message = Funkci „Do Not Track“ již nepodporujeme.
non-technical-privacy-heading =
    .label = Dodatečná ochrana
preferences-privacy-relay-available =
    .description = Skryje vaši skutečnou e-mailovou adresu a ochrání vaši doručenou poštu před nevyžádanou poštou.
    .label = Navrhovat e-mailové masky služby { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Nastavení
category-nav-heading =
    .heading = Nastavení
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Najít nastavení
    .style = width: 15.4em
managed-notice = Tento prohlížeč je spravován vaší organizací.
managed-notice-info-icon =
    .alt = Informace
managed-notice-nav =
    .label = Tento prohlížeč je spravován vaší organizací.
tls-key-logging-notice-nav =
    .label = Aplikace nebo služba může vidět vaši šifrovanou komunikaci.
category-list =
    .aria-label = Kategorie
pane-general-title = Obecné
pane-home-title = Domovská stránka
pane-home-startup-title2 = Domovská stránka a spuštění
    .title = Domovská stránka a spuštění
pane-search-title2 = Vyhledávání
    .title = Vyhledávání
pane-privacy-title3 = Soukromí a zabezpečení
    .title = Soukromí a zabezpečení
pane-privacy-section =
    .heading = Soukromí a zabezpečení
pane-sync-title3 = Synchronizace
pane-ai-controls-title2 = Ovládání AI
    .title = Ovládání AI
pane-about-firefox-title = O aplikaci { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Vzhled
    .title = { pane-appearance-title }
pane-downloads-title2 = Stahování
    .title = Stahování
pane-downloads3 =
    .heading = Stahování
pane-accessibility-title = Přístupnost
    .title = { pane-accessibility-title }
pane-languages-title2 = Jazyky
    .title = Jazyky
preferences-languages-header3 =
    .heading = Jazyky
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 =
    { -brand-short-name.case-status ->
        [with-cases] Vyzkoušejte naše experimentální funkce! Jsou ve vývoji a průběžně se vylepšují, což může ovlivnit fungování { -brand-short-name(case: "gen") }. Údaje o vašem používání těchto funkcí dostáváme pouze tehdy, když máte zapnuté odesílání <a data-l10n-name="data-collection">technických údajů a údajů o interakcích</a>.
       *[no-cases] Vyzkoušejte naše experimentální funkce! Jsou ve vývoji a průběžně se vylepšují, což může ovlivnit fungování aplikace { -brand-short-name }. Údaje o vašem používání těchto funkcí dostáváme pouze tehdy, když máte zapnuté odesílání <a data-l10n-name="data-collection">technických údajů a údajů o interakcích</a>.
    }
pane-experimental-reset =
    .label = Obnovit výchozí nastavení
    .accesskey = O
help-button-label2 =
    { -brand-short-name.case-status ->
        [with-cases] Nápověda { -brand-short-name(case: "gen") }
       *[no-cases] Nápověda
    }
    .title =
        { -brand-short-name.case-status ->
            [with-cases] Nápověda { -brand-short-name(case: "gen") }
           *[no-cases] Nápověda
        }
addons-button-label2 = Rozšíření a vzhledy
    .title = Rozšíření a vzhledy
focus-search =
    .key = f
close-button =
    .aria-label = Zavřít
do-not-track-removal2 =
    .label = Funkce “Do Not Track” již není podporována
applications-setting-new-file-types =
    .label = Co má { -brand-short-name } dělat s ostatními soubory?

## Browser Restart Dialog

feature-enable-requires-restart =
    { -brand-short-name.case-status ->
        [with-cases] Pro povolení této funkce je potřeba { -brand-short-name(case: "acc") } restartovat.
       *[no-cases] Pro povolení této funkce je potřeba aplikaci { -brand-short-name } restartovat.
    }
feature-disable-requires-restart =
    { -brand-short-name.case-status ->
        [with-cases] Pro zakázání této funkce je potřeba { -brand-short-name(case: "acc") } restartovat.
       *[no-cases] Pro zakázání této funkce je potřeba aplikaci { -brand-short-name } restartovat.
    }
should-restart-title =
    { -brand-short-name.case-status ->
        [with-cases] Restartovat { -brand-short-name(case: "acc") }
       *[no-cases] Restartovat aplikaci { -brand-short-name }
    }
should-restart-ok =
    { -brand-short-name.case-status ->
        [with-cases] Restartovat { -brand-short-name(case: "acc") }
       *[no-cases] Restartovat aplikaci { -brand-short-name }
    }
cancel-no-restart-button = Zrušit
restart-later = Restartovat později

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = Toto nastavení je spravované rozšířením <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = Toto nastavení je spravované rozšířením <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = Rozšíření <img data-l10n-name="icon"/> <strong>{ $name }</strong> vyžaduje kontejnerové panely.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = Toto nastavení je spravované rozšířením <img data-l10n-name="icon"/> <strong>{ $name }</strong>.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config =
    { -brand-short-name.case-status ->
        [with-cases] Připojení { -brand-short-name(case: "gen") } k internetu je spravované rozšířením <img data-l10n-name ="icon"/> <strong>{ $name }</strong>.
       *[no-cases] Připojení aplikace { -brand-short-name } k internetu je spravované rozšířením <img data-l10n-name ="icon"/> <strong>{ $name }</strong>.
    }
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Pro povolení rozšíření otevřete <img data-l10n-name="addons-icon"/> Doplňky v nabídce <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Chcete-li znovu povolit toto rozšíření, navštivte <a data-l10n-name="addons-link">Rozšíření a vzhledy</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = Rozšíření { $name } řídí některá nastavení vaší domovské stránky.

## Preferences UI Search Results

search-results-header = Výsledky hledání
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Je nám líto, pro „<span data-l10n-name="query"></span>“ jsme v nastavení nic nenašli.
search-results-help-link =
    { -brand-short-name.case-status ->
        [with-cases] Potřebujete pomoc? Navštivte <a data-l10n-name="url">Podporu { -brand-short-name(case: "gen") }</a>
       *[no-cases] Potřebujete pomoc? Navštivte <a data-l10n-name="url">Podporu aplikace { -brand-short-name }</a>
    }

## General Section

always-check-default =
    .label = Kontrolovat, jestli je { -brand-short-name } výchozím webovým prohlížečem
    .accesskey = w
startup-restore-windows-and-tabs =
    .label = Otevřít okna a panely z minula
    .accesskey = p
startup-windows-launch-on-login-profile-disabled =
    .message = Povolte tuto předvolbu zaškrtnutím "{ profile-manager-use-selected.label }" v okně "Výběr profilu uživatele".
windows-launch-on-login =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Otevřít { -brand-short-name(case: "acc") } při každém spuštění počítače
           *[no-cases] Otevřít aplikaci { -brand-short-name } při každém spuštění počítače
        }
    .accesskey = O
windows-launch-on-login-disabled = Tato předvolba byla v systému Windows zakázána. Chcete-li ji změnit, navštivte <a data-l10n-name="startup-link">Spouštěné aplikace</a> v nastavení systému.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Také otevřít nový panel
    .accesskey = T
disable-extension =
    .label = Zakázat rozšíření
preferences-data-migration-group =
    .description = Importujte své záložky, hesla, historii, rozšíření a data automatického vyplňování z jiného prohlížeče.
    .label = Import dat z prohlížeče
preferences-data-migration-button =
    .label = Importovat data
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profily
preferences-profiles-subpane-description =
    .description = Každý profil obsahuje různá data prohlížení a nastavení, včetně historie, hesel a dalších věcí.
preferences-profiles-section-header =
    .description = Každý profil obsahuje různá data prohlížení a nastavení, včetně historie, hesel a dalších věcí.
    .label = Profily
preferences-manage-profiles-button =
    .label = Správa profilů
preferences-profiles-settings-button =
    .label = Nastavení
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Nový profil si nakopíruje vaše nastavení, doplňky, historii a uložená data jako záložky a hesla – ne však údaje o vašem účtu ani vaší synchronizaci.
    .label = Zkopírování profilu
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Profil určený ke zkopírování
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Vyberte profil
preferences-copy-profile-button = Kopírovat
tabs-browsing-section =
    .heading = Panely a prohlížení
pane-tabs-browsing-title2 = Panely a prohlížení
    .title = Panely a prohlížení
tabs-group-header2 =
    .label = Panely
tabs-opening-heading =
    .label = Otevření
tabs-interaction-heading =
    .label = Interakce
tabs-containers-heading =
    .label = Kontejnery
tabs-closing-heading =
    .label = Ukončení
ctrl-tab-recently-used-order =
    .label = Přepínat panely pomocí Ctrl+Tab v pořadí podle jejich posledního použití
    .accesskey = T
open-new-link-as-tabs =
    .label = Otevírat odkazy v panelech místo v nových oknech
    .accesskey = O
open-external-link-next-to-active-tab =
    .label = Otevírat odkazy z aplikací vedle vašeho aktivního panelu
ask-on-close-multiple-tabs =
    .label = Zeptat se před zavřením vícera panelů
    .accesskey = p
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Zeptat se před ukončením aplikace pomocí zkratky { $quitKey }
    .accesskey = k
warn-on-open-many-tabs =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Varovat, pokud by mohlo otevření více panelů { -brand-short-name(case: "acc") } zpomalit
           *[no-cases] Varovat, pokud by mohlo otevření více panelů aplikaci { -brand-short-name } zpomalit
        }
    .accesskey = d
switch-to-new-tabs-2 =
    .label = Při otevírání odkazu nebo média v novém panelu na něj okamžitě přepnout
    .accesskey = P
show-tabs-in-taskbar =
    .label = V hlavním panelu systému Windows zobrazit náhledy panelů
    .accesskey = h
browser-containers-enabled-2 =
    .label = Použít kontejnerové panely
    .accesskey = P
browser-containers-learn-more = Zjistit více
browser-containers-settings-2 =
    .label = Spravovat nastavení
    .accesskey = S
containers-disable-alert-title = Zavřít všechny kontejnerové panely?
startup-group =
    .label = Spuštění

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Zakážete-li kontejnerové panely, bude zavřen { $tabCount } kontejnerový panel. Opravdu chcete zakázat kontejnerové panely?
        [few] Zakážete-li kontejnerové panely, budou zavřeny { $tabCount } kontejnerové panely. Opravdu chcete zakázat kontejnerové panely?
       *[other] Zakážete-li kontejnerové panely, bude zavřeno { $tabCount } kontejnerových panelů. Opravdu chcete zakázat kontejnerové panely?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Zavřít { $tabCount } kontejnerový panel
        [few] Zavřít { $tabCount } kontejnerové panely
       *[other] Zavřít { $tabCount } kontejnerových panelů
    }

##

containers-disable-alert-cancel-button = Nechat povolené
containers-remove-alert-title = Odstranit tento kontejner?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Pokud odstraníte tento kontejner, bude zavřen { $count } kontejnerový panel. Opravdu chcete kontejner odstranit?
        [few] Pokud odstraníte tento kontejner, budou zavřeny { $count } kontejnerové panely. Opravdu chcete kontejner odstranit?
       *[other] Pokud odstraníte tento kontejner, bude zavřeno { $count } kontejnerových panelů. Opravdu chcete kontejner odstranit?
    }
containers-remove-ok-button = Odstranit tento kontejner
containers-remove-cancel-button = Neodstraňovat tento kontejner
settings-tabs-show-image-in-preview =
    .label = Zobrazit obrázek s náhledem při přejetí nad panelem
    .accessKey = o
settings-tabs-drag-to-create-tab-groups =
    .label = Přetažením panelů k sobě vytvořit skupiny panelů
browser-layout-header2 =
    .label = Rozložení prohlížeče
browser-layout-horizontal-tabs2 =
    .description = Panely nahoře
    .label = Vodorovné panely
    .title = Panely nahoře
browser-layout-vertical-tabs2 =
    .description = Panely na straně, v postranní liště
    .label = Svislé panely
    .title = Panely na straně, v postranní liště
browser-layout-show-sidebar2 =
    .description = Získejte rychlý přístup k záložkám, panelům z telefonu, AI chatbotu a dalším věcem bez toho, abyste opustili hlavní okno.
    .label = Zobrazit postranní lištu
page-navigation-group =
    .label = Navigace po stránce

## General Section - Language & Appearance

language-and-appearance-header = Zobrazení a jazyk stránek
appearance-group2 =
    .description = Některé webové stránky přizpůsobují své barevné schéma vašim preferencím. Vyberte si své barevné schéma.
    .label = Vzhled webové stránky
preferences-web-appearance-choice-auto3 =
    .label = Systémový
    .title = Automaticky mění pozadí a obsah webových stránek podle nastavení systému a motivu aplikace { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Světlý
    .title = Použije pro pozadí a obsah webových stránek vzhled se světlým barevným motivem.
preferences-web-appearance-choice-dark2 =
    .label = Tmavý
    .title = Použije pro pozadí a obsah webových stránek vzhled s tmavým barevným motivem.
web-appearance-group =
    .aria-label = Vzhled webových stránek
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Vaše nastavení kontrastu má přednost před vzhledem webu.
preferences-web-appearance-link =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Vzhled { -brand-short-name(case: "gen") } nastavíte ve správci doplňků
           *[no-cases] Vzhled aplikace { -brand-short-name } nastavíte ve správci doplňků
        }
preferences-contrast-control-group =
    .description = Webové stránky používají různé barvy popředí a pozadí. Pro dosažení konzistentního kontrastu můžete na všech webových stránkách používat stejné barvy.
    .label = Kontrast webových stránek
preferences-contrast-control-radio-group =
    .label = Přepsání barev
preferences-contrast-control-use-platform-settings =
    .label = Automaticky (použít systémové nastavení)
    .accesskey = A
preferences-contrast-control-off =
    .label = Vypnuto
    .accesskey = V
preferences-contrast-control-custom =
    .label = Vlastní
    .accesskey = V
preferences-colors-manage-button2 =
    .label = Nastavení barev
    .accesskey = b
preferences-colors-manage-button =
    .label = Nastavení barev…
    .accesskey = b
preferences-fonts-header2 =
    .label = Písma
preferences-default-zoom-label =
    .label = Výchozí velikost
    .accesskey = z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage } %
preferences-zoom-text-only =
    .label = Pouze velikost textu
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Pokud máte zapnutou funkci “Pouze velikost textu” a výchozí velikost stránky není 100 %, některé stránky nemusí zobrazovat obsah správně.
language-header = Jazyk
choose-language-description = Vyberte jazyky pro zobrazování webových stránek
website-language-heading =
    .description = Některé webové stránky je možné zobrazit ve více jazycích. Vyberte jazyky v pořadí podle vašich preferencí.
    .label = Jazyk webových stránek
website-preferred-language =
    .label = Preferované jazyky
website-language-list =
    .aria-label = Preferované jazyky
website-add-language =
    .label = Přidat jazyk
website-add-language-button =
    .aria-label = Přidat vybraný jazyk
    .title = Přidat vybraný jazyk
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Odebrat jazyk { $locale }
    .title = Odebrat jazyk { $locale }
choose-button =
    .label = Vybrat jazyky…
    .accesskey = j
choose-browser-language-description =
    { -brand-short-name.case-status ->
        [with-cases] Vyberte požadovaný jazyk uživatelského rozhraní { -brand-short-name(case: "gen") }.
       *[no-cases] Vyberte požadovaný jazyk uživatelského rozhraní aplikace { -brand-short-name }.
    }
manage-browser-languages-button =
    .label = Vybrat alternativy…
    .accesskey = l
confirm-browser-language-change-description =
    { -brand-short-name.case-status ->
        [with-cases] Aby se změny projevily, restartujte { -brand-short-name(case: "acc") }
       *[no-cases] Aby se změny projevily, restartujte aplikaci { -brand-short-name }
    }
confirm-browser-language-change-button = Potvrdit a restartovat
browser-language-heading =
    .description = Vyberte jazyk, ve kterém se budou zobrazovat nabídky, zprávy a oznámení od aplikace { -brand-short-name }.
    .label = Jazyk prohlížeče
browser-language-preferred-label =
    .label = Preferovaný jazyk
browser-language-fallback-label =
    .description = Používá se v případě, že lokalizace do preferovaného jazyka není kompletní.
    .label = Záložní jazyk
browser-language-install-error =
    .message = { -brand-short-name } nyní nemůže aktualizovat seznam jazyků. Zkontrolujte internetové připojení a zkuste to znovu.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Výjimky…
    .accesskey = V
settings-translations-header =
    .aria-label = Překlady
    .description = Přeloží stránky nebo vybraný text. Z důvodu ochrany vašeho soukromí zůstávají překlady ve vašem zařízení.
    .label = Překlady
settings-translations-offer-to-translate-label =
    .label = Nabízet překlad celé stránky
settings-translations-more-settings-button =
    .description = Nastavení předvoleb pro jazyky, webové stránky a offline překlad.
    .label = Další nastavení pro překlady
settings-translations-subpage-header =
    .heading = Další nastavení překladu
settings-translations-subpage-speed-up-translation-header =
    .description = Stáhněte si kompletní jazyky pro rychlejší překlady a překládání offline.
    .label = Zrychlení překladu
settings-translations-subpage-automatic-translation-header =
    .label = Automatický překlad
settings-translations-subpage-always-translate-header =
    .label = Vždy překládat z těchto jazyků
settings-translations-subpage-never-translate-header =
    .label = Z těchto jazyků nikdy nepřekládat
settings-translations-subpage-never-translate-sites-header =
    .label = Nikdy nepřekládat tyto stránky
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Chcete-li přidat web, otevřete <img data-l10n-name="translations-icon"/>panel překladů, vyberte možnost <img data-l10n-name="settings-icon"/> nastavení překladů, a potom vyberte “Nikdy nepřekládat tento web”.
settings-translations-subpage-language-select-option =
    .label = Přidat jazyk
settings-translations-subpage-language-add-button =
    .aria-label = Přidat jazyk
    .title = Přidat jazyk
settings-translations-subpage-download-languages-header =
    .label = Stáhnout jazyky
settings-translations-subpage-download-languages-select-option =
    .label = Vyberte jazyk
settings-translations-subpage-download-languages-button =
    .aria-label = Stáhnout jazyk
    .title = Stáhnout jazyk
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Nebyly staženy žádné jazyky
settings-translations-subpage-no-languages-added =
    .label = Nebyly přidány žádné jazyky
settings-translations-subpage-download-progress = Probíhá stahování…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Nepodařilo se stáhnout jazyk { $language } ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Zkusit znovu
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Smazat jazyk { $language } ({ $size } MB)?
settings-translations-subpage-download-delete-button =
    .label = Smazat
settings-translations-subpage-download-cancel-button =
    .label = Zrušit
settings-translations-subpage-no-sites-added =
    .label = Nebyly přidány žádné stránky
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Formátovat datumy, časy, čísla a jednotky podle nastavení pro jazyk „{ $localeName }“ v operačním systému
settings-spellcheck-header =
    .label = Kontrola pravopisu
check-user-spelling =
    .label = Při psaní kontrolovat pravopis
    .accesskey = t
spellcheck-download-dictionaries =
    .label = Stáhnout slovníky
spellcheck-promo =
    .heading = Jak používat kontrolu pravopisu
    .message = Klepnutím pravým tlačítkem na textové pole zapnete nebo vypnete kontrolu pravopisu nebo změníte její jazyk. Ne všechna pole podporují kontrolu pravopisu.

## Downloads - Files and applications

files-and-applications-title = Soubory a aplikace
download-save-files-header =
    .label = Ukládat všechny soubory do složky
download-save-where-3 =
    .aria-label = Ukládat všechny soubory do složky
download-always-ask-where2 =
    .label = Před stažením se ptát, kam se mají soubory uložit
    .accesskey = P
download-private-browsing-delete2 =
    .label = Při zavření smazat soubory stažené v anonymním okně
    .accesskey = P
applications-header = Aplikace
applications-description = Co má { -brand-short-name } dělat se staženými soubory, nebo s aplikacemi, které používáte při prohlížení?
applications-setting2 =
    .description = Zvolte, jak má aplikace { -brand-short-name } zacházet se staženými soubory a obsahem.
    .label = Soubory a aplikace
applications-filter =
    .placeholder = Hledat typ souboru nebo aplikaci
applications-type-column =
    .label = Typ obsahu
    .accesskey = T
applications-type-heading = Typ obsahu
applications-action-column =
    .label = Akce
    .accesskey = A
applications-action-heading = Akce
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = Soubor { $extension }
applications-action-save =
    .label = Uložit soubor
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Použít { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Použít { $app-name } (výchozí)
applications-use-os-default =
    .label = Použít výchozí systémovou aplikaci
applications-use-other =
    .label = Použít jinou…
applications-select-helper = Zvolit pomocnou aplikaci
applications-manage-app =
    .label = Podrobnosti o aplikaci…
applications-always-ask =
    .label = Vždy se zeptat
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Otevřít ve { -brand-short-name(case: "loc") }
           *[no-cases] Otevřít v aplikaci { -brand-short-name }
        }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Co má { -brand-short-name } dělat s ostatními soubory?
applications-save-for-new-types =
    .label = Ukládat soubory
    .accesskey = s
applications-save-for-new-types2 =
    .label = Soubory automaticky ukládat
    .accesskey = S
applications-ask-before-handling =
    .label = Zeptat se, jestli soubor otevřít, nebo uložit
    .accesskey = a
applications-ask-before-handling2 =
    .label = Ptát se pro otevření nebo uložení souboru
    .accesskey = t
drm-group =
    .label = Obsah chráněný pomocí Digital Rights Management (DRM)
play-drm-content =
    .label = Přehrávat obsah chráněný pomocí DRM
    .accesskey = P
play-drm-content-learn-more = Zjistit více
# Variables:
# $version (string) - Firefox version
update-application-version = Verze { $version } <a data-l10n-name="learn-more">Co je nového</a>
update-history-2 =
    .label = Zobrazit historii aktualizací
    .accesskey = h
update-application-installation =
    .label = Instalace
update-application-radio-group =
    .aria-label = Instalace
update-application-auto-2 =
    .label = Instalovat aktualizace automaticky (doporučeno)
    .accesskey = I
update-application-check-choose-2 =
    .label = Vyhledávat aktualizace, ale rozhodnout, kdy se má nainstalovat
    .accesskey = V
update-application-background-enabled =
    .label =
        { -brand-short-name.gender ->
            [masculine] Když je { -brand-short-name } vypnutý
            [feminine] Když je { -brand-short-name } vypnutá
            [neuter] Když je { -brand-short-name } vypnuté
           *[other] Když je aplikace vypnutá
        }
    .accesskey = v
update-application-warning-cross-user-setting-2 =
    .message =
        { -brand-short-name.case-status ->
            [with-cases] Toto nastavení ovlivní všechny uživatele systému Windows a jejich profily { -brand-short-name(case: "gen") }, pokud používají stejnou instalaci.
           *[no-cases] Toto nastavení ovlivní všechny uživatele systému Windows a jejich profily aplikace { -brand-short-name }, pokud používají stejnou instalaci.
        }
update-application-suppress-prompts-2 =
    .label = Zobrazovat méně upozornění na aktualizace
    .accesskey = Z
update-setting-write-failure-title2 = Chyba při ukládání nastavení aktualizací
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name.gender ->
        [masculine]
            { -brand-short-name } zaznamenal problém při ukládání změny nastavení. Změna těchto nastavení vyžaduje oprávnění k zápisu do níže uvedeného souboru. Vy nebo správce vašeho systému můžete tento problém vyřešit přidělením úplných oprávnění k tomuto souboru pro skupinu Users.
            
                Není možný zápis do souboru: { $path }
        [feminine]
            { -brand-short-name } zaznamenala problém při ukládání změny nastavení. Změna těchto nastavení vyžaduje oprávnění k zápisu do níže uvedeného souboru. Vy nebo správce vašeho systému můžete tento problém vyřešit přidělením úplných oprávnění k tomuto souboru pro skupinu Users.
            
                Není možný zápis do souboru: { $path }
        [neuter]
            { -brand-short-name } zaznamenalo problém při ukládání změny nastavení. Změna těchto nastavení vyžaduje oprávnění k zápisu do níže uvedeného souboru. Vy nebo správce vašeho systému můžete tento problém vyřešit přidělením úplných oprávnění k tomuto souboru pro skupinu Users.
            
                Není možný zápis do souboru: { $path }
       *[other]
            Aplikace { -brand-short-name } zaznamenala problém při ukládání změny nastavení. Změna těchto nastavení vyžaduje oprávnění k zápisu do níže uvedeného souboru. Vy nebo správce vašeho systému můžete tento problém vyřešit přidělením úplných oprávnění k tomuto souboru pro skupinu Users.
            
                Není možný zápis do souboru: { $path }
    }
update-in-progress-title = Probíhá aktualizace
update-in-progress-message =
    { -brand-short-name.gender ->
        [masculine] Chcete, aby { -brand-short-name } pokračoval v aktualizaci?
        [feminine] Chcete, aby { -brand-short-name } pokračovala v aktualizaci?
        [neuter] Chcete, aby { -brand-short-name } pokračovalo v aktualizaci?
       *[other] Chcete, aby aplikace { -brand-short-name } pokračovala v aktualizaci?
    }
update-in-progress-ok-button = &Nepokračovat
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Pokračovat

## About Firefox

about-firefox-header =
    .heading =
        { -brand-short-name.case-status ->
            [with-cases] O { -brand-short-name(case: "gen") }
           *[no-cases] O aplikaci { -brand-short-name }
        }

## Firefox updates

update-application-heading =
    .description = Aktualizace zvyšují rychlost, stabilitu a bezpečnost aplikace { -brand-short-name }.
    .label = Aktualizace aplikace { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Upozornění
update-application-updates-managed-by-os =
    .message = Aktualizace jsou spravovány vaším operačním systémem

## Firefox support

support-application-heading =
    .description = Řešení problémů nebo sdílení nápadů s komunitou.
    .label = Podpora { -brand-short-name(case: "gen") }
support-get-help =
    .label = Získat pomoc
support-share-ideas =
    .label = Sdílet nápady nebo zpětnou vazbu

## General Section - Performance

performance-settings-learn-more = Zjistit více
performance-allow-hw-accel =
    .label = Použít hardwarovou akceleraci, je-li dostupná
    .accesskey = h
performance-limit-content-process-option = Omezit počet procesů pro obsah na
    .accesskey = b
performance-limit-content-process-enabled-desc = Další procesy pro obsah mohou zlepšit výkon s více otevřenými panely, ale potřebují více paměti.
performance-limit-content-process-blocked-desc =
    { -brand-short-name.case-status ->
        [with-cases] Počet procesů pro obsah lze upravit pouze při použití multiprocesového režimu { -brand-short-name(case: "gen") }. <a data-l10n-name="learn-more">Podívejte se, jak stav multiprocesového režimu zkontrolovat</a>
       *[no-cases] Počet procesů pro obsah lze upravit pouze při použití multiprocesového režimu aplikace { -brand-short-name }. <a data-l10n-name="learn-more">Podívejte se, jak stav multiprocesového režimu zkontrolovat</a>
    }
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (výchozí)
performance-group =
    .label = Výkon
performance-use-recommended-settings-checkbox-2 =
    .description = Tato nastavení jsou přizpůsobena vašemu hardwaru a operačnímu systému.
    .label = Použít doporučené nastavení výkonu
    .accesskey = v

## Accessibility page

browsing-use-autoscroll =
    .label = Použít automatické posouvání
    .accesskey = a
keyboard-and-scrolling-group =
    .label = Navigace a rolování pomocí klávesnice
motion-and-link-group =
    .label = Pohyb a stylování odkazů
browsing-use-smooth-scrolling =
    .label = Použít plynulé posouvání
    .accesskey = l
browsing-gtk-use-non-overlay-scrollbars =
    .label = Vždy zobrazovat posuvníky
    .accesskey = o
browsing-always-underline-links =
    .label = Vždy podtrhávat odkazy
    .accesskey = r
browsing-use-onscreen-keyboard =
    .label = V případě potřeby zobrazit dotykovou klávesnici
    .accesskey = d
browsing-use-cursor-navigation =
    .label = Používat kurzorové šipky pro pohyb po stránce
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = Použít klávesu Tab pro přesun fokusu mezi prvky formuláře a odkazy
    .accesskey = T
browsing-search-on-start-typing =
    .label = Psaním vyhledávat text na stránce
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = Ovládejte, jak se pohybujete a jak interagujete s aplikací { -brand-short-name }.
    .label = Klávesové zkratky
settings-keyboard-shortcuts-customkeys-link =
    .label = Přizpůsobení klávesových zkratek
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Upravit nastavení adresního řádku v sekci Vyhledávání
settings-media-group =
    .label = Média
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Používat Obraz v obraze
    .accesskey = o
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Pokračovat v přehrávání videí v režimu Obraz v obraze při přepínání panelů
    .accesskey = P
browsing-media-control =
    .label = Ovládat média pomocí klávesnice, sluchátek nebo virtuálního rozhraní
    .accesskey = v
recommendations-group =
    .label = Doporučení
browsing-cfr-recommendations =
    .label = Doporučovat vhodná rozšíření pro navštívené stránky
    .accesskey = r
browsing-cfr-features =
    .label = Doporučovat funkce během prohlížení
    .accesskey = f
browsing-group =
    .label = Prohlížení
preferences-accessibility-header =
    .heading = Přístupnost
preferences-default-zoom-select =
    .aria-label = Výchozí velikost
preferences-fonts-family =
    .label = Typ písma
    .accesskey = T
preferences-fonts-size =
    .label = Velikost písma
    .accesskey = V
preferences-fonts-advanced-settings =
    .label = Pokročilé nastavení
    .accesskey = P

## General Section - Proxy

network-proxy-group2 =
    .description = Určete, jak se má { -brand-short-name } připojovat k internetu.
    .label = Nastavení proxy
network-proxy-connection-settings2 =
    .description = Změna těchto nastavení může způsobit problémy s připojením
    .label = Konfigurace proxy serveru
    .accesskey = K

## Home Section

home-new-windows-tabs-header = Nová okna a panely
home-new-windows-tabs-description2 = Vyberte si domovskou stránku a stránku zobrazovanou při otevření nového okna a nového panelu.
home-section =
    .heading = Domovská stránka a spuštění

## Home Section - Default Browser

home-default-browser-title =
    .label = Výchozí prohlížeč
is-default-browser-2 =
    .message = { -brand-short-name } je vaším výchozím prohlížečem. Dobrá volba.
is-not-default-browser-2 =
    .message = { -brand-short-name } není vaším výchozím prohlížečem.
set-as-my-default-browser-2 =
    .label = Nastavit jako výchozí
    .accesskey = i

## Custom Homepage subpage

home-homepage-mode-label = Na domovské stránce a v novém okně
home-newtabs-mode-label = V novém panelu
home-restore-defaults =
    .label = Obnovit výchozí
    .accesskey = O
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (výchozí)
home-mode-choice-custom =
    .label = Vlastní adresy…
home-mode-choice-blank =
    .label = Prázdná stránka
home-homepage-custom-url =
    .placeholder = Zadejte adresu URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Nastavení tohoto rozšíření
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Použít aktuální stránku
           *[other] Použít aktuální stránky
        }
    .accesskey = k
choose-bookmark =
    .label = Použít záložku…
    .accesskey = z
home-homepage-title =
    .label = Domovská stránka
home-homepage-new-windows =
    .label = Nová okna
home-homepage-new-tabs =
    .label = V novém panelu
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Zvolte konkrétní stránku
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Adresy webových stránek
home-custom-homepage-list =
    .aria-label = Webové adresy
home-custom-homepage-address =
    .placeholder = Zadejte webovou adresu
home-custom-homepage-address-button =
    .label = Přidat adresu
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Dosud nebyly přidány žádné stránky.
home-custom-homepage-delete-address-button =
    .aria-label = Smazat adresu
    .title = Smazat adresu
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Nahradit s
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Právě otevřené stránky
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Záložky…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Rozšíření ({ $extension })
home-custom-homepage-header = Vlastní domovskou stránku
home-custom-homepage-subpage =
    .heading = Vlastní domovskou stránku

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Obsah { -firefox-home-brand-name(capitalization: "lower", case: "gen") }
home-prefs-content-description2 = Vyberte obsah, který chcete mít na { -firefox-home-brand-name(capitalization: "lower", case: "loc") }.
home-prefs-search-header =
    .label = Vyhledávání na webu
home-prefs-shortcuts-header =
    .label = Zkratky
home-prefs-shortcuts-description = Uložené nebo navštěvované stránky
home-prefs-shortcuts-by-option-sponsored =
    .label = Sponzorované zkratky
home-prefs-recommended-by-header-generic =
    .label = Doporučené příběhy
home-prefs-recommended-by-description-generic = Výjimečný obsah od rodiny { -brand-product-name(case: "gen") }
home-prefs-stories-header =
    .label = Příběhy
home-prefs-stories-description = Personalizované příběhy na základě vaší aktivity

##

home-prefs-recommended-by-learn-more = Jak to funguje
home-prefs-recommended-by-option-sponsored-stories =
    .label = Sponzorované příběhy
home-prefs-highlights-option-visited-pages =
    .label = Navštívené stránky
home-prefs-highlights-options-bookmarks =
    .label = Záložky
home-prefs-highlights-option-most-recent-download =
    .label = Nedávná stahování
home-prefs-recent-activity-header =
    .label = Nedávná aktivita
home-prefs-recent-activity-description = Výběr z nedávných stránek a obsahu
home-prefs-weather-header =
    .label = Počasí
home-prefs-weather-description = Přehled dnešní předpovědi
home-prefs-weather-learn-more-link = Zjistit více
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label =
        { -brand-product-name.case-status ->
            [with-cases] Podpora { -brand-product-name(case: "gen") }
           *[no-cases] Podpora aplikace { -brand-product-name }
        }
home-prefs-mission-message = Naši sponzoři podporují naši misi budovat lepší web.
home-prefs-mission-message-learn-more-link = Zjistěte jak
home-prefs-manage-topics-link = Správa témat
home-prefs-choose-wallpaper-link = Vybrat tapetu
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } řádek
            [few] { $num } řádky
           *[other] { $num } řádků
        }

## Search Section

search-show-suggestions-option =
    .label = Zobrazovat návrhy vyhledávání
    .accesskey = v
search-show-suggestions-url-bar-option =
    .label = Našeptávat dotazy pro vyhledávač také v adresním řádku
    .accesskey = e
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = V našeptávači uvádět návrhy vyhledávání před historií prohlížení
search-show-suggestions-private-windows-2 =
    .label = Návrhy vyhledávání v anonymních oknech
search-suggestions-cant-show-2 =
    .message =
        { -brand-short-name.case-status ->
            [with-cases] Návrhy vyhledávání se nebudou adresním řádku zobrazovat, protože jste { -brand-short-name(case: "acc") } nastavili, aby si nikdy nepamatoval historii.
           *[no-cases] Návrhy vyhledávání se nebudou adresním řádku zobrazovat, protože jste aplikaci { -brand-short-name } nastavili, aby si nikdy nepamatovala historii.
        }
addressbar-header-1 =
    .description = Zvolte, co se bude našeptávat v adresním řádku
    .label = Adresní řádek
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description =
        { -brand-short-name.case-status ->
            [with-cases] Návrhy od { -brand-short-name(case: "gen") } a našich partnerů přímo v adresním řádku.
           *[no-cases] Návrhy od aplikace { -brand-short-name } a našich partnerů přímo v adresním řádku.
        }
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Na stránkách s výsledky zobrazovat v adresním řádku hledané výrazy
search-separate-default-engine-2 =
    .label = Použít jiný výchozí vyhledávač v anonymních oknech
    .accesskey = v
search-separate-default-engine-dropdown =
    .aria-label = Výchozí vyhledávač v anonymních oknech
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Pohyb v adresním řádku
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Při přesouvání fokusu klávesou Tab přeskakovat nabídku výsledků
search-suggestions-header-2 =
    .label = Návrhy od vyhledávačů
search-one-click-header2 = Vyhledávače
search-one-click-desc = Vyberte další vyhledávače, které se zobrazí v nabídce adresního řádku a pole vyhledávání.
search-one-click-header-3 =
    .description = Vyberte si vyhledávače a zkratky, které se zobrazí ve vašem adresním řádku.
    .label = Další vyhledávače
search-engine-list =
    .aria-label = Vyhledávače a zkratky
update-search-engine-success =
    .message = Vyhledávač byl úspěšně aktualizován
search-edit-engine-2 =
    .title = Upravit vyhledávač
search-delete-engine =
    .title = Smazat vyhledávač
search-enable-engine =
    .title = Povolit vyhledávač
search-outlink-to-extensions-page =
    .title = Správa rozšíření a vzhledů
search-choose-engine-column =
    .label = Vyhledávač
search-choose-keyword-column =
    .label = Klíčové slovo
search-restore-default =
    .label = Obnovit výchozí vyhledávače
    .accesskey = d
search-remove-engine =
    .label = Odebrat
    .accesskey = r
search-add-engine =
    .label = Přidat
    .accesskey = P
search-add-engine-2 =
    .label = Přidat vyhledávač
    .accesskey = v
search-edit-engine =
    .label = Upravit
    .accesskey = U
search-find-more-link = Přidat další vyhledávače
search-filtering-for-add-engine = Přidat vyhledávač
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Použité klíčové slovo
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Zvolili jste klíčové slovo, které už je použito pro „{ $name }“. Zvolte prosím jiné.
search-keyword-warning-bookmark = Zvolili jste klíčové slovo, které už je použito pro záložku. Zvolte prosím jiné.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Vyhledávač s názvem „{ $name }“ už existuje. Zvolte prosím jiný název.
remove-engine-confirmation = Opravdu chcete odstranit tento vyhledávač?
remove-engine-remove = Odebrat
remove-addon-engine-alert = Chcete-li tento vyhledávač odstranit, odstraňte související doplněk.
search-engine-group =
    .label = Výchozí vyhledávač
search-default-engine =
    .aria-label = Výchozí vyhledávač
# Header for the search section ("search" is a noun).
search-section =
    .heading = Hledat

## Containers Section

containers-section-header2 =
    .heading = Nastavení kontejneru
containers-card-header2 =
    .description = Ukládejte cookies do samostatných kontejnerů, abyste mohli na stejném webu používat různé účty a omezit sledování napříč weby.
    .label = Kontejnery
containers-add-button2 =
    .label = Přidat nový kontejner
    .accesskey = P
containers-list =
    .aria-label = Kontejnery
containers-new-tab-check3 =
    .label = Zobrazit výběr kontejneru pro každý nový panel
    .accesskey = Z
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Nepoužívat kontejnery pro odkazy otevřené z externích aplikací
    .accesskey = k
containers-new-tab-check2 =
    .description = Tím se při každém stisknutí tlačítka „Otevřít nový panel“ otevře nabídka kontejnerů.
    .label = Zobrazit výběr kontejneru při otevření nového panelu
    .accesskey = k
containers-settings-button2 =
    .title = Nastavení
containers-remove-button3 =
    .title = Smazat
containers-sites-card-header =
    .description = Vyberte kontejner pro daný web a aplikace { -brand-short-name } jej bude používat při každém otevření webu.
    .label = Kontejnery specifické pro danou stránku
containers-sites-add-button =
    .label = Přidat webovou stránku
    .accesskey = P
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Kontejner pro { $site }
containers-site-remove-button =
    .title = Smazat
containers-remove-button2 =
    .title = Odebrat

## Account and sync

sync-group-label =
    .label = Synchronizace
account-group-label2 =
    .label = Účet
account-disabled-group =
    .description = Nastavení účtu není k dispozici.
    .label = Účet
account-placeholder2 =
    .description = Přihlaste se a udržujte své údaje soukromé, šifrované a okamžitě dostupné všude, kde používáte { -brand-short-name }.
    .label = Nejste přihlášen(a)
account-sync-section =
    .heading = Účet a synchronizace
pane-account-sync-title2 = Účet a synchronizace
    .title = Účet a synchronizace

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Vezměte si web s sebou
sync-signedout-description2 = Synchronizujte své záložky, historii, panely, hesla, doplňky a nastavení napříč všemi svými zařízeními.
sync-signedout-account-signin3 =
    .label = Přihlásit se k synchronizaci…
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = Přihlaste se do svého účtu a spusťte synchronizaci
    .accesskey = P
sync-signedout-account-short =
    .label = Přihlásit se
    .accesskey = P
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Stáhněte si Firefox pro <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> nebo <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> a synchronizujte svá data se svým mobilním zařízením.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Změnit profilový obrázek
    .tooltiptext = Změnit profilový obrázek
sync-profile-picture-account-problem =
    .alt = Profilový obrázek účtu
fxa-login-rejected-warning =
    .alt = Varování
sync-sign-out =
    .label = Odhlásit se…
    .accesskey = O
sync-sign-out2 =
    .label = Odhlásit se
    .accesskey = O
sync-manage-account = Spravovat účet
    .accesskey = S
sync-manage-account2 =
    .label = Spravovat účet
    .accesskey = S

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = Účet { $email } není ověřen.
sync-signedin-unverified2 =
    .description = Zkontrolujte si doručenou poštu, abyste potvrdili svůj účet a oficiálně ho zaregistrovali.
    .label = Adresa { $email } zatím není potvrzená
sync-signedin-login-failure = Pro opětovné připojení účtem { $email } se přihlaste
sync-signedin-login-failure2 =
    .description = Znovu se přihlaste, abyste se znovu připojili a začali synchronizovat svá data.
    .label = Jste odhlášeni z { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Ověřit účet
    .accesskey = v
sync-remove-account =
    .label = Odebrat účet
    .accesskey = d
sync-sign-in =
    .label = Přihlásit se
    .accesskey = i

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synchronizace zapnuta
prefs-syncing-on-2 =
    .label = Synchronizace je zapnuta
prefs-syncing-off = Synchronizace vypnuta
prefs-syncing-off-2 =
    .description = Zapnutím synchronizace získáte své záložky, hesla, historii a další informace z libovolného zařízení.
    .label = Synchronizace je vypnutá
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Zapněte synchronizaci, abyste mohli mít své záložky, hesla, historii a další data na svém zařízení.
    .label = Synchronizace je vypnutá
prefs-sync-turn-on-syncing =
    .label = Zapnout synchronizaci…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Zapnout synchronizaci
    .accesskey = s
prefs-sync-offer-setup-label2 = Synchronizujte své záložky, historii, panely, hesla, doplňky a nastavení napříč všemi svými zařízeními.
prefs-sync-now-button =
    .label = Synchronizovat
    .accesskey = S
prefs-sync-now-button-2 =
    .label = Synchronizovat
    .accesskey = S
prefs-syncing-button =
    .label = Probíhá synchronizace…
prefs-syncing-button-2 =
    .label = Probíhá synchronizace…
    .title = Synchronizovat
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Vaše volby synchronizace nyní platí pouze pro toto zařízení.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Tyto položky synchronizujete ve všech připojených zařízeních:
sync-syncing-across-devices-heading-2 = Data synchronizovaná mezi zařízeními
sync-syncing-across-devices-heading-3 = Data synchronizovaná na tomto zařízení
sync-syncing-across-devices-empty-state2 =
    .description = Zatím nic nesynchronizujete… Začněte synchronizovat, abyste měli všechna data na všech svých zařízeních.
    .label = Spravovat synchronizované údaje
sync-syncing-across-devices-empty-state3 =
    .description = Zatím nic nesynchronizujete. Vyberte, co se má na tomto zařízení synchronizovat.
    .label = Spravovat synchronizovaná data
sync-currently-syncing-bookmarks = Záložky
sync-currently-syncing-history = Historii
sync-currently-syncing-tabs = Otevřené panely
sync-currently-syncing-passwords = Hesla
sync-currently-syncing-addresses = Adresy
sync-currently-syncing-payment-methods = Platební metody
sync-currently-syncing-addons = Doplňky
sync-currently-syncing-settings = Nastavení
sync-manage-options =
    .label = Spravovat synchronizaci…
    .accesskey = S
sync-manage-options-2 =
    .label = Spravovat synchronizovaná data
    .accesskey = S
settings-sync-disconnect-button =
    .label = Odpojit

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Záložky
    .accesskey = Z
sync-engine-history =
    .label = Historie
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Otevřené panely
    .tooltiptext = Otevírejte panely z ostatních zařízení
    .accesskey = O
sync-engine-tabs =
    .label = Otevřené panely
    .tooltiptext = Seznam panelů otevřených v ostatních zařízeních
    .accesskey = t
sync-engine-passwords =
    .label = Hesla
    .tooltiptext = Uložená hesla
    .accesskey = H
sync-engine-addresses2 =
    .label = Adresy
    .tooltiptext = Adresy, které jste uložili do aplikace { -brand-short-name }
    .accesskey = A
sync-engine-payment-methods3 =
    .label = Platební metody
    .tooltiptext = Uložené způsoby platby
    .accesskey = P
sync-engine-addons2 =
    .label = Doplňky
    .tooltiptext = Rozšíření a vzhledy, které jste přidali do aplikace { -brand-short-name } pro počítač
    .accesskey = D
sync-engine-settings2 =
    .label = Nastavení
    .tooltiptext = Nastavení { -brand-short-name(case: "gen") } (pokud je relevantní)
    .accesskey = N
sync-engine-addresses =
    .label = Adresy
    .tooltiptext = Uložené poštovní adresy (pouze na počítači)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = Platební metody
    .tooltiptext = Jména, čísla karet a data platnosti
    .accesskey = P
sync-engine-addons =
    .label = Doplňky
    .tooltiptext = Rozšíření a motivy vzhledu ve Firefoxu pro počítač
    .accesskey = D
sync-engine-settings =
    .label = Nastavení
    .tooltiptext = Nastavení v sekcích Obecné a Soukromí a zabezpečení
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Uložit
    .buttonlabelextra2 = Odpojit…
    .buttonaccesskeyaccept = U
    .buttonaccesskeyextra2 = O
    .style = min-width: 36em;
    .title = Správa synchronizace všech připojených zařízení
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Uložit
    .buttonlabelextra2 = Odpojit…
    .buttonaccesskeyaccept = U
    .buttonaccesskeyextra2 = O
    .style = min-width: 36em;
    .title = Spravovat synchronizovaný obsah na zařízení

## The device name controls.

sync-device-name-header = Název zařízení
sync-device-name-header-2 =
    .label = Název zařízení
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Název zařízení
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Přejmenovat toto zařízení
    .accesskey = j
sync-device-name-change =
    .label = Přejmenovat toto zařízení…
    .accesskey = j
sync-device-name-cancel =
    .label = Zrušit
    .accesskey = u
sync-device-name-save =
    .label = Uložit
    .accesskey = l
sync-connect-another-device = Připojit další zařízení
sync-connect-another-device-2 =
    .label = Připojit další zařízení

## Privacy Section

privacy-header = Nastavení soukromí

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Hesla
    .searchkeywords = hesla
forms-passwords-header =
    .aria-label = Hesla
    .label = Hesla
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Ptát se na ukládání hesel
    .accesskey = P
forms-manage-password-exceptions =
    .label = Spravovat výjimky pro hesla
    .accesskey = m
forms-exceptions =
    .label = Výjimky…
    .accesskey = k
forms-suggest-passwords =
    .label = Navrhovat silná hesla
    .accesskey = N
forms-breach-alerts =
    .label = Upozorňovat na hesla uložená pro servery, u nichž došlo k úniku dat
    .accesskey = ú
forms-breach-alerts-learn-more-link = Zjistit více
preferences-relay-integration-checkbox2 =
    .label = Navrhovat e-mailové masky služby { -relay-brand-name } k ochraně vaší e-mailové adresy
    .accesskey = r
relay-integration-learn-more-link = Zjistit více
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Vyplňovat automaticky uživatelská jména a hesla
    .accesskey = V
forms-fill-usernames-and-passwords-2 =
    .label = Ukládat a automaticky vyplňovat uživatelská jména a hesla
    .accesskey = U
forms-saved-passwords =
    .label = Uložená hesla
    .accesskey = U
forms-saved-passwords-2 =
    .label = Správa uložených hesel
    .accesskey = h
forms-saved-passwords-searchkeywords = Ve vašem počítači jsou uložené přihlašovací údaje pro následující servery
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Dodatečná ochrana
forms-primary-pw-use =
    .label = Použít hlavní heslo
    .accesskey = P
forms-primary-pw-use-2 =
    .description = Přidává další vrstvu zabezpečení pro ochranu vašich uložených hesel.
    .label = Použít hlavní heslo
    .accesskey = h
forms-primary-pw-set =
    .label = Nastavit hlavní heslo
forms-primary-pw-on-2 = Hlavní heslo je <strong>ZAPNUTÉ</strong>
forms-primary-pw-on =
    .label = Hlavní heslo je ZAPNUTÉ
forms-primary-pw-change-2 =
    .label = Změnit hlavní heslo
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Vypnout
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = K vyplňování a správě hesel vyžadovat přihlášení se do zařízení
forms-os-reauth-2 =
    .label = Ke správě hesel vyžadovat přihlášení se do zařízení
forms-primary-pw-learn-more-link = Zjistit více
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Změnit hlavní heslo…
    .accesskey = m
forms-primary-pw-change =
    .label = Změnit hlavní heslo…
    .accesskey = m
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Momentálně jste v režimu FIPS, který vyžaduje neprázdné hlavní heslo.
forms-master-pw-fips-desc = Neúspěšná změna hesla
forms-windows-sso =
    .label = Povolit jednotné přihlašování Windows pro pracovní a školní účty a účty Microsoft
forms-windows-sso-learn-more-link = Zjistit více
forms-windows-sso-desc = Účty můžete spravovat v nastavení svého zařízení
windows-passkey-settings-label = Správa přístupových klíčů v nastavení systému
privacy-panel-settings-header =
    .description = Získejte pomoc s ochranou svých údajů na internetu v aplikaci { -brand-short-name }.
    .label = Nastavení panelu ochrany osobních údajů
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Zobrazit zprávy o únicích
    .accesskey = a

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Pro nastavení hlavního hesla prosím zadejte své přihlašovací údaje k systému Windows. Toto opatření pomáhá v zabezpečení vašich účtů.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = vytvořit hlavní heslo
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] změnit nastavení pro platební metody
       *[other] { -brand-short-name } se snaží změnit nastavení platebních metod. Pokud to chcete povolit, použijte heslo k účtu na svém zařízení.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Platební metody
autofill-payment-methods-checkbox-message-2 =
    .label = Ukládat a automaticky vyplňovat platební metody
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = Spravovat platební metody
autofill-payment-methods-manage-payments-button =
    .label = Spravovat platební metody
    .accesskey = S
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Pro automatické vyplňování vyžadovat přihlášení ze zařízení
    .accesskey = v
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = K automatickému vyplnění a správě platebních metod vyžadovat přihlášení se na zařízení
    .accesskey = v
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Ukládat bezpečností kódy
    .accesskey = k
autofill-payment-methods-add-button = Přidat novou platební metodu
payments-list-header =
    .label = Platební metody
payments-delete-payment-prompt-title = Smazat tuto platební metodu?
payments-delete-payment-prompt-confirm-button = Smazat
payments-delete-payment-prompt-cancel-button = Zrušit
payments-delete-payment-button-label =
    .aria-label = Smazat
payments-edit-payment-button-label =
    .aria-label = Upravit
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Nebyla přidána žádná platební metoda
autofill-addresses-checkbox-message =
    .label = Ukládat a automaticky vyplňovat adresy
    .accesskey = U
autofill-addresses-manage-addresses-button =
    .label = Spravovat adresy a další údaje
    .accesskey = S
addresses-list-header =
    .label = Adresy
addreses-delete-address-button-label =
    .aria-label = Smazat
addreses-edit-address-button-label =
    .aria-label = Upravit
addresses-delete-address-prompt-title = Smazat tuto adresu?
addresses-delete-address-prompt-confirm-button = Smazat
addresses-delete-address-prompt-cancel-button = Zrušit
autofill-addresses-add-button = Přidat novou adresu
autofill-addresses-manage-addresses-title =
    .heading = Spravovat adresy a další údaje
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Nebyla přidána žádná adresa
personal-info-group =
    .label = Osobní údaje
autofill-personal-info-checkbox-message =
    .label = Ukládat a automaticky vyplňovat osobní údaje
autofill-personal-info-manage-button =
    .label = Spravovat osobní údaje
passports-list-header =
    .label = Pasy
passports-delete-passport-button-label =
    .aria-label = Smazat
passports-edit-passport-button-label =
    .aria-label = Upravit
passports-delete-passport-prompt-title = Smazat tento pas?
passports-delete-passport-prompt-confirm-button = Smazat
passports-delete-passport-prompt-cancel-button = Zrušit
autofill-passports-add-button = Přidat nový pas
autofill-personal-info-manage-title =
    .heading = Spravovat osobní údaje
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Nejsou uloženy žádné pasy
pane-passwords-autofill-title2 = Hesla a automatické vyplňování
    .title = Hesla a automatické vyplňování
preferences-passwords-autofill-header =
    .heading = Hesla a automatické vyplňování
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adresy a další údaje
payments-group =
    .label = Platební metody

## Privacy Section - History

history-remember-option-never2 =
    .description = Každé okno funguje jako anonymní okno. Když je zapnuto, rozšíření se musí povolit.
    .label = Nikdy neukládat historii prohlížení
history-remember-option-custom2 =
    .label = Přizpůsobení historie
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } si bude pamatovat historii vašeho prohlížení, stahování, formulářů a vyhledávání.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } použije stejné nastavení jako v režimu anonymního prohlížení a nebude si pamatovat žádnou historii.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } použije individuální nastavení pro historii vašeho prohlížení, stahování, formulářů a vyhledávání.
history-private-browsing-permanent =
    .label = Vždy použít režim anonymního prohlížení
    .accesskey = p
history-remember-browser-option =
    .label = Pamatovat si historii prohlížení a stahování
    .accesskey = s
history-remember-search-option =
    .label = Pamatovat si historii vyhledávání a formulářů
    .accesskey = f
history-clear-on-close-option =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Vymazat historii při ukončení { -brand-short-name(case: "gen") }
           *[no-cases] Vymazat historii při ukončení aplikace { -brand-short-name }
        }
    .accesskey = r
history-clear-on-close-settings =
    .label = Nastavení…
    .accesskey = t
history-shutdown-exceptions =
    .label = Spravovat výjimky
    .accesskey = v
history-clear-button =
    .label = Vymazat historii…
    .accesskey = V
history-header2 =
    .heading = Historie
history-section-header =
    .description = Vyberte, co si má { -brand-short-name } pamatovat, když zavřete prohlížeč.
    .label = Historie
history-custom-section-header =
    .description = Upravte, co si má { -brand-short-name } pamatovat, když zavřete prohlížeč.
    .label = Rozšířené nastavení
history-custom-button =
    .label = Vyberte, co si má { -brand-short-name } pamatovat
history-group =
    .label = Historie
history-mode-radio-group =
    .aria-label = Historie
history-remember-option-all2 =
    .label = Pamatovat si historii

## Privacy Section - Site Data

sitedata-total-size-calculating = Probíhá výpočet velikosti mezipaměti a dat stránek…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Webové stránky aktuálně používají <strong>{ $value } { $unit }</strong> místa na disku.
sitedata-learn-more = Zjistit více
sitedata-delete-on-close2 =
    .label = Vymazat cookies a data stránek při každém ukončení { -brand-short-name(case: "gen") }
    .accesskey = V
sitedata-delete-on-close-private-browsing3 =
    .message = Na základě vašeho nastavení pro historii smaže { -brand-short-name } při svém ukončení z vaší relace cookies a data stránek.
sitedata-delete-on-close-private-browsing4 =
    .heading = Historie se nebude ukládat.
    .message = Když zavřete prohlížeč, { -brand-short-name } vymaže cookies a data webu z vaší relace.
sitedata-option-block-cross-site-trackers =
    .label = Sledovací prvky
sitedata-option-block-cross-site-tracking-cookies =
    .label = Sledovací cross-site cookies
sitedata-option-block-cross-site-cookies2 =
    .label = Izolovat cross-site cookies
sitedata-option-block-unvisited =
    .label = Cookies z dosud nenavštívených stránek
sitedata-option-block-all-cross-site-cookies =
    .label = Všechny cross-site cookies (může omezit fungování některých stránek)
sitedata-option-block-all =
    .label = Všechny cookies (omezí fungování některých stránek)
sitedata-clear2 =
    .label = Vymazat data prohlížení
    .accesskey = V
sitedata-settings2 =
    .label = Spravovat data prohlížení
    .accesskey = p
sitedata-cookies-exceptions =
    .label = Výjimky…
    .accesskey = k
sitedata-cookies-exceptions2 =
    .description = Můžete určit, které weby mají vždy nebo nemají nikdy povoleno používat cookies a data stránek.
    .label = Spravovat výjimky
    .accesskey = v
sitedata-heading =
    .description = Spravujte své cookies, historii, mezipaměť, data webových stránek a další.
    .label = Údaje o prohlížení
sitedata-settings3 =
    .label = Vymazat data pro konkrétní stránky
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Vyberte, jak konkrétní stránky zpracovávají cookies a data webu.
    .label = Spravovat výjimky
    .accesskey = v
cookies-site-data-group =
    .label = Cookies a data stránek

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Blokování lišt cookie
cookie-banner-blocker-description = Když se stránka zeptá, zda může používat cookies v režimu anonymního prohlížení, { -brand-short-name } to automaticky odmítne. K dispozici pouze na podporovaných stránkách.
cookie-banner-learn-more = Zjistit více
cookie-banner-blocker-checkbox-label =
    .label = Automaticky odmítnout lišty cookie

## Search Section

addressbar-locbar-history-option =
    .label = Historie prohlížení
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = Záložky
    .accesskey = Z
addressbar-locbar-clipboard-option =
    .label = Schránka
    .accesskey = S
addressbar-locbar-openpage-option =
    .label = Otevřené panely
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Zkratky
    .accesskey = Z
addressbar-locbar-topsites-option =
    .label = Top stránky
    .accesskey = T
addressbar-locbar-engines-option-1 =
    .label = Vyhledávače, které je možné použít
    .accesskey = N
addressbar-locbar-quickactions-option =
    .label = Rychlé akce
    .accesskey = R
addressbar-locbar-showrecentsearches-option-2 =
    .label = Nedávná vyhledávání
    .accesskey = N
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Návrhy populárních vyhledávání
    .accesskey = N
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Získat návrhy z webu souvisejícím s vaším vyhledáváním.
    .label =
        { -brand-full-name.case-status ->
            [with-cases] Návrhy od { -brand-short-name(case: "gen") }
           *[no-cases] Návrhy od aplikace { -brand-short-name }
        }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Podpořte { -brand-short-name(case: "acc") } občasným zobrazením sponzorovaných návrhů.
    .label = Návrhy od sponzorů
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Při psaní získávat návrhy od Mozilly
addressbar-dismissed-suggestions-label-2 =
    .description =
        { -brand-short-name.case-status ->
            [with-cases] Vraťte zpět vyřazené návrhy od sponzorů a { -brand-short-name(case: "gen") }.
           *[no-cases] Vraťte zpět vyřazené návrhy od sponzorů a aplikace { -brand-short-name }.
        }
    .label = Vyřazené návrhy
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Vrátit návrhy zpět

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Rozšířená ochrana proti sledování
content-blocking-section-top-level-description = Sledovací prvky sbírají informace, co a kde na internetu děláte, jaké máte návyky a co vás zajímá. { -brand-short-name } blokuje mnoho takových prvků i dalších škodlivých skriptů.
content-blocking-learn-more = Zjistit více
content-blocking-fpi-incompatibility-warning = Používáte izolaci prvních stran (FPI), která potlačí některá nastavení cookies ve { -brand-short-name(case: "loc") }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning =
    { -brand-short-name.case-status ->
        [with-cases] Používáte funkci Resist Fingerprinting (RFP), která nahrazuje některá nastavení ochrany ve { -brand-short-name(case: "loc") } před vytvářením otisku prohlížeče . To může způsobit problémy s některými stránkami.
       *[no-cases] Používáte funkci Resist Fingerprinting (RFP), která nahrazuje některá nastavení ochrany v aplikaci { -brand-short-name } před vytvářením otisku prohlížeče . To může způsobit problémy s některými stránkami.
    }

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standardní
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Přísná
    .accesskey = P
enhanced-tracking-protection-setting-custom =
    .label = Vlastní
    .accesskey = V

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Vyvážená ochrana a výkon. Stránky se budou načítat normálně.
content-blocking-etp-strict-desc = Silnější ochrana. Může omezit fungování některých stránek.
content-blocking-etp-custom-desc = Vyberte, které sledovací prvky a skripty se mají blokovat.
content-blocking-etp-blocking-desc = { -brand-short-name } blokuje:
content-blocking-private-windows = Sledující obsah v anonymních oknech
content-blocking-cross-site-cookies-in-all-windows2 = Cookies třetích stran ve všech oknech
content-blocking-cross-site-tracking-cookies = Sledovací cookies
content-blocking-all-cross-site-cookies-private-windows = Cookies třetích stran v anonymních oknech
content-blocking-isolate-cross-site-cookies = Izolovat cross-site cookies
content-blocking-social-media-trackers = Sledující prvky sociálních sítí
content-blocking-all-cookies = Všechny cookies
content-blocking-unvisited-cookies = Cookies z dosud nenavštívených stránek
content-blocking-all-windows-tracking-content = Sledující obsah blokován ve všech oknech
content-blocking-all-cross-site-cookies = Všechny cross-site cookies
content-blocking-cryptominers = Těžbu kryptoměn
content-blocking-fingerprinters = Vytváření otisku prohlížeče
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Známé a předpokládané vytváření otisku prohlížeče
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Úplná ochrana před cookies omezuje cookies na web, na němž se nacházíte, aby vás sledující subjekty nemohly sledovat napříč stránkami.
content-blocking-etp-standard-tcp-rollout-learn-more = Zjistit více
content-blocking-etp-standard-tcp-title = Zahrnuje úplnou ochranu před cookies, naši nejsilnější funkci zaměřenou na soukromí
content-blocking-warning-title-2 = Některé stránky nemusí s přísnou ochranou před sledováním fungovat správně
content-blocking-warning-title-custom = Některé stránky nemusí s vlastní ochranou proti sledování fungovat správně
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } doporučuje použít nastavení „Oprava problémů se stránkami“, aby se snížil počet porušených funkcí a porušeného obsahu stránek. Pokud se zdá, že stránka nefunguje správně, zkuste pro daný web vypnout ochranu proti sledování, aby se na stránce načetl veškerý obsah.
content-blocking-warning-learn-how = Jak na to
content-blocking-baseline-exceptions-3 =
    .description = Pomáhá načítat stránky a funkce tím, že odblokovává pouze jejich nezbytné součásti, jež mohou obsahovat sledovací prvky. Pokrývá nejčastější problémy.
    .label = Oprava závažných problémů se stránkami (doporučeno)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Obnovuje například videa v článcích nebo sekce komentářů tím, že odblokovává součásti, jež mohou obsahovat sledovací prvky. To může zredukovat problémy se stránkami, ovšem poskytuje menší ochranu. Musí být použito společně s opravami závažných problémů.
    .label = Oprava drobných problémů se stránkami
content-blocking-baseline-uncheck-warning-dialog-title = Opravdu chcete vypnout opravy?
content-blocking-baseline-uncheck-warning-dialog-body = Toto nastavení pomáhá řešit nejčastější problémy se stránkami. Pokud ho vypnete, některé stránky nemusí fungovat a { -brand-short-name } nebude moci s odstraněním těchto problémů pomoci.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Vypnout opravy
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Ponechat opravy zapnuté
content-blocking-reload-description = Aby se změny projevily, načtěte znovu své panely.
content-blocking-reload-tabs-button =
    .label = Znovu načíst všechny panely
    .accesskey = n
content-blocking-tracking-content-label =
    .label = Sledující obsah
    .accesskey = o
content-blocking-tracking-protection-option-all-windows =
    .label = ve všech oknech
    .accesskey = v
content-blocking-option-private =
    .label = jen v anonymních oknech
    .accesskey = a
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Více informací
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Těžba kryptoměn
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Známé vytváření otisku prohlížeče
    .accesskey = Z
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Předpokládané vytváření otisku prohlížeče
    .accesskey = P

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Výjimky…
    .accesskey = k

## Privacy Section - Permissions

permissions-notification-pause =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Zakázat oznámení do restartu { -brand-short-name(case: "gen") }
           *[no-cases] Zakázat oznámení do restartu aplikace { -brand-short-name }
        }
    .accesskey = n
permissions-autoplay2 =
    .label = Automatické přehrávání
permissions-block-popups2 =
    .label = Blokovat vyskakovací okna a přesměrování třetích stran
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Přidejte webové stránky, které mohou otevírat vyskakovací okna a využívat přesměrování třetích stran.
    .label = Spravovat výjimky
    .searchkeywords = vyskakovací okna
    .accesskey = v
permissions-addon-install-warning3 =
    .label = Zobrazit varování, když se webové stránky pokouší o instalaci rozšíření
    .accesskey = r
permissions-addon-exceptions2 =
    .label = Zvolte, které weby mohou instalovat rozšíření
    .accesskey = e
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Povolit stránkám žádat o otevření odkazů v aplikacích.
    .accesskey = P
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Spravovat blokované stránky
    .accesskey = S
permissions-location2 =
    .label = Poloha
permissions-localhost2 =
    .label = Aplikace a služby v zařízení
permissions-local-network2 =
    .label = Zařízení v místní síti
permissions-xr2 =
    .label = Virtuální realita
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Reproduktor
permissions-notification2 =
    .label = Oznámení
permissions-header3 =
    .description = Spravujte, k čemu mohou webové stránky přistupovat, co mohou ovládat nebo co mohou spouštět.
    .label = Oprávnění
permissions-data-section =
    .heading = Oprávnění a data
pane-permissions-data-title2 = Oprávnění a data
    .title = Oprávnění a data
notifications-section-header =
    .heading = Upozornění
notifications-entry-card-header =
    .description = Vyberte, které strány mohou posílat oznámení a jak se mají zobrazovat.
    .label = Upozornění
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } stránka
            [few] { $count } stránky
           *[other] { $count } stránek
        }
    .label = Spravovat nastavení oznámení
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Spravovat nastavení oznámení webových stránek
notifications-website-card-header =
    .description = Zvolte, jak mohou webové stránky posílat oznámení.
    .label = Oznámení webových stránek
notifications-filter =
    .placeholder = Hledat ve stránkách
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Webová stránka
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Povolit oznámení
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Webové stránky
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Vždy
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Povolit
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Nikdy
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Nejsou přidána žádná oznámení z webových stránek.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Vašemu hledání neodpovídají žádná oznámení z webových stránek.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Abyste se ujistili, že tato změna bude zahrnuta do vašich záloh, otevřete každý profil a v nastavení vyberte „Zálohovat nyní“.
nimbus-rollouts =
    .description = Změny budou prováděny na dálku.
    .label = Povolit aplikaci { -brand-short-name } vylepšovat funkce, výkon a stabilitu mezi aktualizacemi
addon-recommendations3 =
    .description = Nechte si doporučovat rozšíření pro zlepšení vašeho prohlížení.
    .label = Povolit personalizovaná doporučení rozšíření
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Pro tuto konfiguraci sestavení je hlášení dat vypnuto.
collection-backlogged-crash-reports2 =
    .label = Automaticky odesílat hlášení o pádech
    .accesskey = m
collection-backlogged-crash-reports-description =
    { -vendor-short-name.case-status ->
        [with-cases] To pomáhá { -vendor-short-name(case: "dat") } diagnostikovat a opravovat problémy s prohlížečem. Hlášení mohou obsahovat osobní nebo citlivé údaje.
       *[no-cases] To pomáhá organizaci { -vendor-short-name } diagnostikovat a opravovat problémy s prohlížečem. Hlášení mohou obsahovat osobní nebo citlivé údaje.
    }
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Stejné nastavení, nový vzhled!
    .message = Tuto stránku jsme přepracovali, aby se na ní lépe orientovalo a procházelo. Vaše osobní nastavení se nezměnila a vše je stále na svém místě. Tip: Pomocí vyhledávání se můžete dostat přímo k tomu, co potřebujete.
settings-redesign-promo-dismiss-button =
    .label = Rozumím
privacy-segmentation-section-header = Nové funkce, které zlepšují vaše prohlížení
privacy-segmentation-section-description = Když nabízíme funkce, které využívají vaše data, abychom vám poskytli osobnější prožitek:
privacy-segmentation-radio-off =
    .label =
        { -brand-product-name.case-status ->
            [with-cases] Použít doporučení { -brand-product-name(case: "gen") }
           *[no-cases] Použít doporučení aplikace { -brand-product-name }
        }
privacy-segmentation-radio-on =
    .label = Zobrazit podrobnosti
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description =
        { -brand-product-name.case-status ->
            [with-cases] Snažíme se vám poskytnout možnost volby a sbírat jen minimum údajů potřebných k vylepšování { -brand-product-name(case: "gen") }.
           *[no-cases] Snažíme se vám poskytnout možnost volby a sbírat jen minimum údajů potřebných k vylepšování aplikace { -brand-product-name }.
        }
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Sběr a použití údajů o { -brand-short-name(case: "loc") }
           *[no-cases] Sběr a použití údajů o aplikaci { -brand-short-name }
        }
    .searchkeywords = telemetrie
data-collection-link = Zobrazit zásady ochrany osobních údajů
data-collection-preferences-across-profiles =
    .message =
        { -brand-product-name.case-status ->
            [with-cases] Tato nastavení platí pro každý profil { -brand-product-name(case: "gen") } na tomto zařízení.
           *[no-cases] Tato nastavení platí pro každý profil aplikace { -brand-product-name } na tomto zařízení.
        }
data-collection-profiles-link = Zobrazit všechny profily
data-collection-health-report-telemetry-disabled =
    .message =
        { -vendor-short-name.case-status ->
            [with-cases] Odesílání technických údajů a údajů o interakcích { -vendor-short-name(case: "dat") } není nadále povoleno. Všechny historické údaje budou smazány do 30 dnů.
           *[no-cases] Odesílání technických údajů a údajů o interakcích organizaci { -vendor-short-name } není nadále povoleno. Všechny historické údaje budou smazány do 30 dnů.
        }
data-collection-health-report =
    .description =
        { -brand-product-name.case-status ->
            [with-cases] To nám pomáhá vylepšovat funkce, výkon a stabilitu { -brand-product-name(case: "gen") }.
           *[no-cases] To nám pomáhá vylepšovat funkce, výkon a stabilitu aplikace { -brand-product-name }.
        }
    .label = Odesílat { -vendor-short-name(case: "dat") } technické údaje a údaje o interakcích
    .accesskey = t
data-collection-health-report-disabled =
    .description = Pro tuto konfiguraci sestavení je hlášení dat deaktivováno.
    .label = Odesílat technická data a data o interakcích organizaci { -vendor-short-name }
    .accesskey = O
data-collection-run-studies =
    .description = { -brand-short-name } náhodně vybírá uživatele k testování funkcí, což pomáhá zlepšovat kvalitu pro všechny.
    .label = Povolit aplikaci { -brand-short-name } spouštět studie funkcí
data-collection-studies-link =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Zobrazit studie { -brand-short-name(case: "gen") }
           *[no-cases] Zobrazit studie aplikace { -brand-short-name }
        }
data-collection-backlogged-crash-reports =
    .description = To pomáhá společnosti { -vendor-short-name } diagnostikovat a řešit problémy s prohlížečem. Zprávy mohou obsahovat osobní nebo citlivé údaje.
    .label = Automaticky odesílat hlášení o pádu
    .accesskey = A
data-collection-usage-ping =
    .description =
        { -vendor-short-name.case-status ->
            [with-cases] To { -vendor-short-name(case: "dat") } pomáhá odhadnout počet aktivních uživatelů.
           *[no-cases] To organizaci { -vendor-short-name } pomáhá odhadnout počet aktivních uživatelů.
        }
    .label =
        { -vendor-short-name.case-status ->
            [with-cases] Odesílat { -vendor-short-name(case: "dat") } denní ping o používání
           *[no-cases] Odesílat organizaci { -vendor-short-name } denní ping o používání
        }
    .accesskey = p

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Zabezpečení
browsing-protection-group2 =
    .description = Nebezpečné stránky a stahování mohou ohrozit vaše data a zařízení. { -brand-short-name } je automaticky zablokuje a upozorní vás na rizikový nebo nežádoucí software.
    .label = Ochrana před klamavým obsahem a nebezpečným softwarem
security-enable-safe-browsing =
    .label = Blokovat nebezpečný a podvodný obsah
    .accesskey = B
security-enable-safe-browsing-link = Zjistit více
security-safe-browsing-warning =
    .message = Vypnutím této možnosti klesá ochrana proti podvodům, škodlivým webům a nebezpečnému stahování.
security-block-downloads =
    .label = Blokovat nebezpečná stahování
    .accesskey = s
security-block-uncommon-software =
    .label = Upozorňovat na nežádoucí nebo neobvyklý software
    .accesskey = w

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Povolit { -brand-short-name(case: "gen") } automaticky důvěřovat kořenovým certifikátům třetích stran, které nainstalujete
           *[no-cases] Povolit aplikaci { -brand-short-name } automaticky důvěřovat kořenovým certifikátům třetích stran, které nainstalujete
        }
    .accesskey = P
certs-devices-enable-fips = Povolit FIPS
space-alert-over-5gb-settings-button =
    .label = Otevřít nastavení
    .accesskey = O
space-alert-over-5gb-message2 =
    { -brand-short-name.case-status ->
        [with-cases] <strong>{ -brand-short-name(case: "dat") } dochází místo na disku.</strong> Obsah webové stránky se nemusí zobrazit správně. Uložená data stránky můžete vymazat v Nastavení  > Soukromí a zabezpečení > Cookies a data stránek.
       *[no-cases] <strong>Aplikaci { -brand-short-name } dochází místo na disku.</strong> Obsah webové stránky se nemusí zobrazit správně. Uložená data stránky můžete vymazat v Nastavení  > Soukromí a zabezpečení > Cookies a data stránek.
    }
space-alert-under-5gb-message2 =
    { -brand-short-name.case-status ->
        [with-cases] <strong>{ -brand-short-name(case: "dat") } dochází místo na disku.</strong> Obsah webové stránky se nemusí zobrazit správně. Klepněte na „Dozvědět se více“ o optimalizaci využití disku k lepšímu prohlížení webu.
       *[no-cases] <strong>Aplikaci { -brand-short-name } dochází místo na disku.</strong> Obsah webové stránky se nemusí zobrazit správně. Klepněte na „Dozvědět se více“ o optimalizaci využití disku k lepšímu prohlížení webu.
    }
certs-description3 =
    .description = Konfigurace certifikátů, které { -brand-short-name } používá k ověření zabezpečených připojení.
    .label = Certifikáty
certs-view2 =
    .label = Spravovat certifikáty
    .accesskey = c
certs-devices2 =
    .label = Spravovat bezpečností zařízení
    .accesskey = b

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Jak funguje režim „pouze HTTPS“.
httpsonly-radio-enabled =
    .label = Zapnout režim „pouze HTTPS“ ve všech oknech
httpsonly-radio-enabled-pbm =
    .label = Zapnout režim „pouze HTTPS“ v anonymních oknech
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } i tak může některá spojení povýšit na zabezpečená
    .label = Nezapínat režim „pouze HTTPS“.
httpsonly-group =
    .description = Umožňuje pouze zabezpečená spojení s weby. { -brand-short-name } se před použitím nezabezpečeného spojení zeptá.
    .label = Režim „pouze HTTPS“
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS over HTTPS
dns-over-https-group2 =
    .description = Domain Name System over HTTPS (DoH) šifruje vyhledávání stránek, takže pro vašeho poskytovatele internetu nebo pro ostatní je obtížnější vidět, jaké webové stránky se chystáte navštívit.
    .label = DNS over HTTPS
preferences-doh-description2 = DNS over HTTPS odesílá váš požadavek na doménové jméno skrze šifrované spojení, čímž DNS zabezpečuje a znesnadňuje ostatním zjistit, na jaký web se chystáte přejít.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Stav: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Poskytovatel: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Neplatná adresa URL
preferences-doh-steering-status = Pomocí místního poskytovatele
preferences-doh-status-active = Aktivní
preferences-doh-status-disabled = Vypnuto
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Neaktivní ({ $reason })
preferences-doh-group-message2 = Zapnout DNS over HTTPS, použije se:
preferences-doh-radio-group =
    .aria-label = Zapnout DNS over HTTPS, použije se:
preferences-doh-expand-section =
    .tooltiptext = Více informací
preferences-doh-setting-default =
    .label = Výchozí ochrana
    .accesskey = V
preferences-doh-default-desc = { -brand-short-name } rozhodne, kdy použít zabezpečené DNS za účelem ochrany vašeho soukromí.
preferences-doh-default-detailed-desc-1 = V oblastech, v nichž je dostupné, se použije zabezpečené DNS
preferences-doh-default-detailed-desc-2 = Pokud se zabezpečeným DNS nastane problém, použije se výchozí překladač DNS
preferences-doh-default-detailed-desc-3 = Je-li to možné, použije se místní poskytovatel
preferences-doh-default-detailed-desc-4 = Vypne se, když jsou aktivní síť VPN, rodičovská kontrola nebo podnikové zásady
preferences-doh-default-detailed-desc-5 =
    { -brand-short-name.case-status ->
        [with-cases] Vypne se, když síť oznámí { -brand-short-name(case: "dat") }, že nemá používat zabezpečené DNS
       *[no-cases] Vypne se, když síť oznámí aplikaci { -brand-short-name }, že nemá používat zabezpečené DNS
    }
preferences-doh-setting-enabled =
    .label = Zvýšená ochrana
    .accesskey = Z
preferences-doh-enabled-desc = Sami si nastavíte, kdy se zabezpečené DNS použije, a od jakého poskytovatele.
preferences-doh-enabled-detailed-desc-1 = Použije se poskytovatel, kterého jste si vybrali
preferences-doh-enabled-detailed-desc-2 = Výchozí překladač DNS se použijte jen v případě problému se zabezpečeným DNS
preferences-doh-setting-strict =
    .label = Maximální ochrana
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } vždy použije zabezpečené DNS. Před použitím systémového překladače DNS vždy uvidíte bezpečnostní varování.
preferences-doh-strict-detailed-desc-1 = Použije se pouze ten poskytovatel, kterého jste si vybrali
preferences-doh-strict-detailed-desc-2 = Vždy budete upozorněni, jestliže není zabezpečené DNS dostupné
preferences-doh-strict-detailed-desc-3 = Pokud není zabezpečené DNS dostupné, webové stránky se nenačtou nebo nebudou správně fungovat
preferences-doh-setting-off =
    .label = Vypnuto
    .accesskey = V
preferences-doh-off-desc = Použije se výchozí překladač DNS
preferences-doh-select-resolver = Vyberte poskytovatele:
preferences-doh-manage-exceptions =
    .label = Výjimky…
    .accesskey = k
preferences-doh-overview-default =
    .description = Použije se zabezpečený DNS v oblastech, kde je dostupný.
    .label = Výchozí ochrana
preferences-doh-overview-custom =
    .description = Vždy používejte zabezpečený DNS, u kterého máte kontrolu nad poskytovatelem a chováním při selhání.
    .label = Vlastní
preferences-doh-overview-off =
    .description = Bude použit váš výchozí překladač DNS.
    .label = Zakázáno
preferences-doh-advanced-button =
    .label = Pokročilé nastavení
preferences-doh-advanced-section =
    .description = Systém doménových jmen přes HTTPS (DoH) šifruje vyhledávání webových stránek, takže je pro vašeho poskytovatele internetového připojení i pro ostatní obtížnější zjistit, které webové stránky se chystáte navštívit.
    .label = Pokročilé nastavení
preferences-doh-manage-exceptions2 =
    .label = Spravovat výjimky
    .accesskey = v
preferences-doh-radio-default =
    .description = Použije se zabezpečený DNS v oblastech, kde je dostupný
    .label = Výchozí
preferences-doh-radio-custom =
    .description = Vždy používejte zabezpečený DNS, u kterého máte kontrolu nad poskytovatelem a chováním při selhání
    .label = Vlastní
preferences-doh-radio-off =
    .description = Použije se váš výchozí překladač DNS
    .label = Vypnuto
preferences-doh-fallback-label =
    .label = Vždy mě upozornit, pokud není zabezpečené DNS dostupné
preferences-doh-status-item-off =
    .message = DNS over HTTPS je vypnuté
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS over HTTPS nefunguje, protože při pokusu o použití poskytovatele { $name } došlo k chybě ({ $reason }).
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS over HTTPS nefunguje, protože jsme obdrželi neplatné URL ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS over HTTPS používá poskytovatele { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS over HTTPS nefunguje, protože při pokusu o použití místního poskytovatele { $name } došlo k chybě ({ $reason }).
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS over HTTPS používá místního poskytovatele { $name }
preferences-doh-select-resolver-label =
    .label = Vyberte poskytovatele:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Použijte tohoto poskytovatele pro DNS over HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Zadejte URL vlastního poskytovatele
preferences-doh-header2 =
    .heading = DNS over HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Bezpečnost připojení a aplikace
preferences-connection-link-section =
    .description = Podívejte se, jak jsou připojení zabezpečena, jak je blokován škodlivý software a jak jsou ověřovány webové stránky.
    .label = Bezpečnost připojení a softwaru
preferences-connection-link-button =
    .label = Pokročilé nastavení

## The following strings are used in the Download section of settings

desktop-folder-name = Plocha
downloads-folder-name = Stažené soubory

## Appearance page

preferences-appearance-header =
    .heading = Vzhled
browser-theme-group =
    .description = Přizpůsobte si styl aplikace { -brand-short-name } podle svých představ. Barvy motivu se promítnou do panelů nástrojů, nabídek a hlášení.
    .label = Vzhled prohlížeče
browser-theme-manage-link =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Spravovat vzhledy { -brand-short-name(case: "gen") }
           *[no-cases] Spravovat vzhledy aplikace { -brand-short-name }
        }
appearance-window-density-group =
    .description = Upravte mezery kolem prvků okna, jako jsou panel nástrojů, záložky a postranní panel.
    .label = Hustota oken
appearance-window-density-radio-group =
    .aria-label = Hustota oken
appearance-window-density-automatic =
    .description = Automaticky se použijí standardní, kompaktní nebo dotykové rozestupy
    .label = Automatická (výchozí)
appearance-window-density-automatic-no-touch =
    .description = Standardní nebo kompaktní rozestup se použije automaticky
    .label = Automatická (výchozí)
appearance-window-density-standard =
    .description = Vyvážené rozestupy pro většinu obrazovek
    .label = Standardní
appearance-window-density-auto-touch-mode =
    .label = Použít pro režim tabletu rozestupy dotyků
appearance-window-density-compact =
    .description = Zmenšené mezery pro menší obrazovky
    .label = Kompaktní
appearance-window-density-touch =
    .description = Větší prvky oken a klikací cíle, optimalizované pro dotykové obrazovky
    .label = Dotykové
related-settings-group =
    .label = Související nastavení
related-settings-accessibility-link =
    .label = Přizpůsobení nastavení velikosti stránky a písma najdete v části Přístupnost
related-settings-home-link =
    .label = Přizpůsobit { -firefox-home-brand-name(case: "acc") }
related-settings-tabs-browsing-link =
    .label = Přizpůsobení rozložení prohlížeče

## AI controls page

preferences-ai-controls-description =
    { -brand-short-name.case-status ->
        [with-cases] Ve { -brand-short-name(case: "loc") } máte vždy možnost volby, a to i ohledně používání funkcí vylepšených pomocí umělé inteligence. Brzy přibudou další možnosti ovládání.
       *[no-cases] V aplikaci { -brand-short-name } máte vždy možnost volby, a to i ohledně používání funkcí vylepšených pomocí umělé inteligence. Brzy přibudou další možnosti ovládání.
    }
preferences-ai-controls-block-ai-label = Blokovat vylepšení pomocí AI
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description =
    { -brand-short-name.case-status ->
        [with-cases] Blokování znamená, že ve { -brand-short-name(case: "loc") } neuvidíte nová ani stávající vylepšení pomocí umělé inteligence, ani vyskakovací okna zpravující o nich. <a data-l10n-name="link">Zjistěte více</a> o tom, co všechno to zahrnuje a jak ovládat tradiční funkce strojového učení, jako jsou návrhy vyhledávání a doporučení.
       *[no-cases] Blokování znamená, že v aplikaci { -brand-short-name } neuvidíte nová ani stávající vylepšení pomocí umělé inteligence, ani vyskakovací okna zpravující o nich. <a data-l10n-name="link">Zjistěte více</a> o tom, co všechno to zahrnuje a jak ovládat tradiční funkce strojového učení, jako jsou návrhy vyhledávání a doporučení.
    }
preferences-ai-controls-blocked-message =
    .message = Nová a stávající vylepšení pomocí umělé inteligence jsou nyní standardně blokována. Chcete-li určitou funkci odblokovat, použijte níže její ovládání.
preferences-ai-controls-on-device-group =
    .description = Tyto funkce využívají menší modely umělé inteligence, které se při použití funkce stáhnou do vašeho zařízení. Tento přístup pomáhá chránit vaše soukromí.
    .label = Místně uložená AI
preferences-ai-controls-translations-control =
    .description = Procházejte internet plynule ve svém preferovaném jazyce.
    .label = Překlady
preferences-ai-controls-translations-more-link = Další nastavení překladu
preferences-ai-controls-pdfjs-control =
    .description = Když do souborů PDF přidáte obrázky, tato funkce přidá popis, aby byly přístupnější.
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Alternativní text obrázku v PDF prohlížeči { -brand-short-name(case: "gen") }
           *[no-cases] Alternativní text obrázku v PDF prohlížeči aplikace { -brand-short-name }
        }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Dostávejte návrhy na pojmenování a uspořádání panelů.
    .label = Návrhy pro skupiny panelů
preferences-ai-controls-key-points-control =
    .description = Před otevřením odkazu si nechte zobrazit krátké shrnutí.
    .label = Výčet hlavních myšlenek v náhledech odkazů
preferences-ai-controls-speech-recognition-control =
    .description = Provádění lokálního přepisu řeči.
    .label = Rozpoznávání řeči
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Mějte chatbota neustále na očích, jak prohlížíte. Vyberte si z více poskytovatelů a kdykoliv zvolte jiného.
    .label = Poskytovatelé AI chatbotů v postranní liště
preferences-ai-controls-sidebar-chatbot-group =
    .description = Při procházení webu mějte chatbota stále na očích. Na výběr máte chatboty Anthropic Claude, ChatGPT, Copilot, Google Gemini a Le Chat Mistral.
    .label = Poskytovatelé AI chatbotů v postranní liště
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot v postranní liště
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Dostupné
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Povoleno
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Blokováno
preferences-ai-controls-state-description-before = Co znamenají tyto možnosti:
preferences-ai-controls-state-description-available = <strong>Dostupné:</strong> Funkci uvidíte a můžete ji používat.
preferences-ai-controls-state-description-enabled = <strong>Povoleno:</strong> Funkci jste se sami rozhodli používat.
preferences-ai-controls-state-description-blocked = <strong>Blokováno:</strong> Funkci neuvidíte a nebudete moci používat. V případě místně uložené umělé inteligence dochází k odstranění již stažených modelů.
preferences-ai-controls-block-confirmation-heading = Blokovat vylepšování umělou inteligencí?
preferences-ai-controls-block-confirmation-description =
    { -brand-short-name.case-status ->
        [with-cases] Ve { -brand-short-name(case: "loc") } neuvidíte nová ani stávající vylepšení pomocí umělé inteligence, ani vyskakovací okna zpravující o nich. Následně můžete odblokovat vše, co si přejete dál používat.
       *[no-cases] V aplikaci { -brand-short-name } neuvidíte nová ani stávající vylepšení pomocí umělé inteligence, ani vyskakovací okna zpravující o nich. Následně můžete odblokovat vše, co si přejete dál používat.
    }
preferences-ai-controls-block-confirmation-features-start = Co bude blokováno:
preferences-ai-controls-block-confirmation-translations = Překlady
preferences-ai-controls-block-confirmation-pdfjs =
    { -brand-short-name.case-status ->
        [with-cases] Alternativní text obrázku v PDF prohlížeči { -brand-short-name(case: "gen") }
       *[no-cases] Alternativní text obrázku v PDF prohlížeči aplikace { -brand-short-name }
    }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Návrhy pro skupiny panelů
preferences-ai-controls-block-confirmation-key-points = Výčet hlavních myšlenek v náhledech odkazů
preferences-ai-controls-block-confirmation-sidebar-chatbot = Poskytovatelé chatbotů v postranní liště
preferences-ai-controls-block-confirmation-speech-recognition = Rozpoznávání řeči
preferences-ai-controls-block-confirmation-features-after =
    { -brand-short-name.case-status ->
        [with-cases] Blokování ovlivní také rozšíření, která využívají umělou inteligenci poskytovanou { -brand-short-name(case: "ins") }.
       *[no-cases] Blokování ovlivní také rozšíření, která využívají umělou inteligenci poskytovanou aplikací { -brand-short-name }.
    }
preferences-ai-controls-block-confirmation-cancel =
    .label = Zrušit
preferences-ai-controls-block-confirmation-confirm =
    .label = Blokovat
preferences-ai-controls-header3 =
    .heading = Ovládání AI

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } je ve střehu
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } doporučuje některá vylepšení zabezpečení
security-privacy-status-ok-label = Rozšířená ochrana proti sledování je zapnuta
security-privacy-status-problem-label = Našli jsme nastavení, které má vliv na vaši ochranu
security-privacy-status-problem-helper-label = Zobrazit problémy
security-privacy-status-pending-trackers-label = Vyhledává se, kolik sledovacích prvků { -brand-short-name } zablokoval během posledního měsíce
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] Za poslední měsíc byl zablokován { $trackerCount } sledovací prvek
        [few] Za poslední měsíc byly zablokovány { $trackerCount } sledovací prvky
        [many] Za poslední měsíc bylo zablokováno { $trackerCount } sledovacích prvků
       *[other] Za poslední měsíc bylo zablokováno { $trackerCount } sledovacích prvků
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Máte <a data-l10n-name="strict-tracking-protection">přísnou ochranu</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Máte <a data-l10n-name="custom-tracking-protection">vlastní ochranu</a>
security-privacy-status-up-to-date-label =
    { -brand-short-name.case-status ->
        [with-cases] Máte nejnovější a nejbezpečnější verzi { -brand-short-name(case: "gen") }
       *[no-cases] Máte nejnovější a nejbezpečnější verzi aplikace { -brand-short-name }
    }
security-privacy-status-update-needed-label =
    { -brand-short-name.case-status ->
        [with-cases] Je k dispozici nová verze { -brand-short-name(case: "gen") }.
       *[no-cases] Je k dispozici nová verze aplikace { -brand-short-name }.
    }
security-privacy-status-update-error-label =
    { -brand-short-name.case-status ->
        [with-cases] { -brand-short-name } má problémy s aktualizací
       *[no-cases] Aplikace { -brand-short-name } má problémy s aktualizací
    }
security-privacy-status-update-checking-label = { -brand-short-name } hledá aktualizace
security-privacy-status-update-needed-description = Aktualizace pro nejnovější vylepšení rychlosti, stability a bezpečnosti.
security-privacy-status-update-button-label =
    .label =
        { -brand-short-name.case-status ->
            [with-cases] Aktualizovat { -brand-short-name(case: "acc") }
           *[no-cases] Aktualizovat aplikaci { -brand-short-name }
        }
security-privacy-image-warning =
    .alt = Štít s vykřičníkem, který vyjadřuje znepokojení nad vašimi bezpečnostními varováními
security-privacy-image-ok =
    .alt = Štít se značkou zaškrtnutí, který indikuje, že nemáte žádný nevyřešený bezpečnostní problém
security-privacy-issue-card =
    .heading = Bezpečnostní varování
issue-card-reset-button =
    .label = Obnovit
issue-card-dismiss-button =
    .aria-label = Zavřít
    .tooltiptext = Zavřít

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Webové stránky používají sledovače, aby vás sledovaly online a zobrazovaly strašidelné reklamy. { -brand-short-name } vás chrání při procházení a automaticky blokuje sledovače, abyste měli svou digitální stopu pod kontrolou.
    .label = Rozšířená ochrana proti sledování
preferences-etp-level-radio-group =
    .aria-label = Rozšířená ochrana proti sledování
preferences-etp-level-standard =
    .description = Silná a spolehlivá ochrana, která hladce funguje s většinou webových stránek.
    .label = Standardní (výchozí)
preferences-etp-level-strict =
    .description = Silnější ochrany, které blokují více sledovačů, ale mohou způsobit poškození některých webových stránek.
    .label = Přísná
preferences-etp-level-custom =
    .description = Vyberte, které ochrany chcete zapnout nebo vypnout.
    .label = Vlastní
preferences-etp-status-advanced-button =
    .label = Pokročilé nastavení
preferences-etp-tracker-count-enabled =
    .label = Zobrazovat počet zablokovaných sledovacích prvků v adresním řádku
preferences-etp-status-protections-dashboard-link =
    .description = Podívejte se, kolik skrytých sledovacích prvků vám { -brand-short-name } zablokoval, včetně sledovacích prvků sociálních sítí, nástrojů pro identifikaci zařízení a skriptů pro těžbu kryptoměn.
    .label = Zobrazit přehled vašeho osobního zabezpečení
preferences-etp-header =
    .heading = Rozšířená ochrana proti sledování
preferences-etp-advanced-settings-group =
    .description = Webové stránky používají sledovače, aby vás sledovaly online a zobrazovaly strašidelné reklamy. { -brand-short-name } vás chrání při procházení a automaticky blokuje většinu sledovačů, abyste měli svou digitální stopu pod kontrolou.
    .label = Pokročilé nastavení
preferences-etp-customize-button =
    .label = Přizpůsobení ochrany proti sledování
preferences-etp-reload-tabs-hint =
    .message = Pro použití těchto změn znovu načtěte panely.
preferences-etp-reload-tabs-hint-button =
    .label = Znovu načíst všechny panely
preferences-etp-rfp-warning-message =
    .message = Používáte funkci Resist Fingerprinting (RFP), která nahrazuje některá nastavení ochrany v aplikaci { -brand-short-name } před vytvářením otisku prohlížeče . To může způsobit problémy s některými stránkami.
preferences-etp-level-warning-message =
    .heading = Pozor! Některé stránky nemusí fungovat podle očekávání.
    .message = Některé webové stránky zabudovávají sledovače do svých funkcí nebo obsahu. Když je { -brand-short-name } zablokuje, web vypadá nefunkčně. Zkuste použít „Opravit problém s webem“ nebo na daném webu vypnout ochranu proti sledování.
preferences-etp-manage-exceptions-button =
    .description = Správa webových stránek, kde je vypnutá rozšířená ochrana proti sledování.
    .label = Spravovat výjimky
preferences-etp-customize-header =
    .heading = Přizpůsobení ochrany proti sledování
preferences-etp-reset =
    .description = Obnoví nastavení na přednastavenou úroveň ochrany.
    .label = Obnovit vlastní nastavení
preferences-etp-reset-standard-button =
    .label = Obnovit standardní nastavení
preferences-etp-reset-strict-button =
    .label = Obnovit přísné nastavení
preferences-etp-custom-control-group =
    .description = Vyberte, které ochrany chcete zapnout nebo vypnout.
    .label = Ochrana proti sledování
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Povolit všechny cookies
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Blokovat sledovací cookies třetích stran
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Blokovat cross-site cookies
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Izolovat cross-site cookies
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Blokovat cookies z dosud nenavštívených stránek
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Blokovat všechny cross-site cookies (může omezit fungování některých stránek)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Všechny cookies (stránky nemusí fungovat správně)
preferences-etp-custom-tracking-protection-enabled =
    .label = Sledující obsah
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Sledující obsah
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Těžba kryptoměn
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Známé vytváření otisku prohlížeče
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Předpokládané vytváření otisku prohlížeče
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Předpokládané vytváření otisku prohlížeče

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = To může umožnit některým sledujícím serverům, aby vás sledovali bez použití cookies.
    .label = Známé vytváření otisku prohlížeče není blokováno
security-privacy-issue-warning-third-party-cookies =
    .description = Cookies třetích stran se používají k tomu, aby vás sledovali na různých webových stránkách.
    .label = Cookies třetích stran jsou povoleny
security-privacy-issue-warning-password-manager =
    .description = Správci hesel vám pomohou ukládat silná hesla pro vaše účty.
    .label = Správce hesel je zakázán
security-privacy-issue-warning-popup-blocker =
    .description = Vyskakovací okna jsou rušivá a potenciálně škodlivá.
    .label = Blokování vyskakovacích oken je zakázáno
security-privacy-issue-warning-extension-install =
    .description = Webové stránky mohou bez ptaní do { -brand-short-name(case: "gen") } instalovat rozšíření.
    .label = Webové stránky mohou instalovat rozšíření
security-privacy-issue-warning-safe-browsing =
    .description = Vaše vystavení podvodům a malwaru z webových stránek se zvyšuje.
    .label = Nebezpečný a klamavý obsah není blokován
security-privacy-issue-warning-doh2 =
    .description = DNS over HTTPS pomáhá skrývat před poskytovatelem sítě, jaké stránky se chystáte navštívit.
    .label = DNS over HTTPS je zakázáno
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello pomáhá skrývat stránky, které se chystáte navštívit, před vaším poskytovatelem sítě.
    .label = Encrypted Client Hello je deaktivováno
security-privacy-issue-warning-doh =
    .description = DNS over HTTPS před poskytovatelem sítě skryje, jaké stránky navštěvujete.
    .label = DNS over HTTPS je zakázáno
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello skryje před vaším síťovým poskytovatelem, jaké stránky navštěvujete.
    .label = Encrypted Client Hello je deaktivováno
security-privacy-issue-warning-proxy-autodetection =
    .description = Automatická konfigurace proxy může umožnit nedůvěryhodným sítím sledovat vaši aktivitu.
    .label = Automatická konfigurace proxy serverů je povolena

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Pozvěte někoho, aby zvolil prohlížeč, u kterého je soukromí na prvním místě.
    .label = Sdílet { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Sdílet { -brand-product-name(case: "acc") }


vorbit-header = Předvolby aplikace vOrbit-lite
vorbit-warning-title = Pozor!
vorbit-general-heading = Chování prohlížeče
vorbit-extension-update-checkbox =
    .label = Automaticky aktualizovat doplňky
vorbit-sync-checkbox =
    .label = Povolit službu Firefox Sync
vorbit-autocopy-checkbox =
    .label = Povolit vkládání kliknutím kolečkem myši
vorbit-styling-checkbox =
    .label = Povolit úpravy stylů userChrome.css
vorbit-ipv6-checkbox =
    .label = Povolit IPv6
vorbit-privacy-heading = Soukromí
vorbit-broken-heading = Vytváření otisků
vorbit-security-heading = Zabezpečení
vorbit-goog-safe-checkbox =
    .label = Povolit službu Bezpečné prohlížení Google
vorbit-goog-safe-download-checkbox =
    .label = Kontrolovat stažené soubory
vorbit-ipv6-description = Povolit aplikaci { -brand-short-name } připojení pomocí protokolu IPv6.
pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = Logicky uspořádaná a jednoduše přístupná konfigurace about:config
vorbit-warning-description = Pečlivě jsme pro vás vybrali výchozí nastavení tak, abychom upřednostnili vaše soukromí a bezpečnost. Pokud budete chtít změnit některé z těchto nastavení, přečtěte si prosím jeho popis, abyste pochopili důsledky těchto změn.
vorbit-network-heading = Sítě
vorbit-xorigin-ref-checkbox =
    .label = Omezit cross-origin referery
vorbit-webgl-checkbox =
    .label = Povolit WebGL s oprávněními pro jednotlivé weby
vorbit-rfp-checkbox =
    .label = Povolit funkci ResistFingerprinting
vorbit-letterboxing-checkbox =
    .label = Povolit rámování (letterboxing)
vorbit-ocsp-checkbox =
    .label = Povolit hard-fail OSCP
vorbit-extension-update-description = Udržovat doplňky aktuální bez ručního zásahu. Dobrá volba pro vaši bezpečnost.
vorbit-extension-update-warning1 = Pokud nekontrolujete před aktualizací doplňků jejich kód, měli byste tuto možnost povolit.
vorbit-ipv6-warning1 = Namísto blokování protokolu IPv6 v prohlížeči doporučujeme v operačním systému povolit rozšíření pro ochranu soukromí v IPv6.
vorbit-ocsp-description = Zabránit připojení k webu, pokud nelze provést kontrolu OSCP.
vorbit-sync-description = Synchronizovat data napříč ostatními prohlížeči. Bude vyžadován restart prohlížeče.
vorbit-webgl-description = Toto povolí WebGL s dotazem na povolení u jednotlivých webů.
vorbit-goog-safe-download-warning1 = Všechny kontroly se odehrávají lokálně.
vorbit-open-profile = Otevřít adresář uživatelského profilu
vorbit-xorigin-ref-description = Zasílat referrer pouze u same-origin.
vorbit-ocsp-warning1 = Tato možnost sice zvýší bezpečnost, ale může způsobit problémy, pokud není server OCSP dostupný.
vorbit-webgl-warning1 = Jakmile se web pokusí vytvořit kontext WebGL, budete dotázáni na oprávnění.
content-blocking-section-top-level-description = vOrbit-lite podporuje – a ve výchozím nastavení zapíná – Rozšířenou ochranu proti sledování v přísném režimu. Jde o jedno z nejdůležitějších nastavení prohlížeče, jelikož poskytuje dělení stavu, striktní seznamy blokovaných a další funkce pro ochranu soukromí. Nedoporučujeme změnu na jiné režimy.
vorbit-sync-warning1 = Služba Firefox Sync zašifruje vaše data ještě před jejich nahráním na server.
vorbit-styling-warning1 = Ujistěte se, že autorovi motivu důvěřujete.
vorbit-autocopy-description = Označte text ke zkopírování, poté jej vložte kliknutým prostředním kolečkem myši.
vorbit-rfp-warning1 = Pokud ovšem funkci potřebujete zakázat, zvažte použití doplňku, jako Canvas Blocker.
vorbit-letterboxing-description = Letterboxing odsadí vaši stránku kolem vašich oken, aby prohlížeč nahlásil omezené zaokrouhlené rozlišení.
vorbit-footer = Užitečné odkazy
vorbit-goog-safe-description = Pokud se obáváte, že narazíte na malware nebo phishing, měli byste tuto možnost povolit.
vorbit-goog-safe-warning1 = Zakázáno kvůli obávám z cenzury, ale doporučeno pro méně pokročilé uživatele. Všechny kontroly se odehrávají lokálně.
vorbit-config-link = Všechna pokročilá nastavení (about:config)
vorbit-goog-safe-download-description = Povolit službě Bezpečné prohlížení kontrolovat stažené soubory pro nalezení podezřelých souborů.
vorbit-styling-description = Tuto možnost povolte, pokud si chcete přizpůsobit rozhraní ručně načteným motivem.
vorbit-xorigin-ref-warning1 = Může způsobit chyby. Navíc i po odeslání budou referrery stále ořezány.
vorbit-rfp-description = ResistFingerprinting je nejlepší nástroj proti vytváření otisku prohlížeče.
vorbit-webgl-prompt-checkbox =
    .label = Skrýt dotaz na WebGL pro jednotlivé weby
vorbit-webgl-prompt-description = Toto skryje dotaz, který se zobrazí, když se web pokusí vytvořit kontext WebGL. Dotaz můžete ručně zobrazit kliknutím na ikonu ve vyhledávací liště.
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = Chování prohlížeče
vorbit-extension-update-checkbox2 =
    .label = Automaticky aktualizovat rozšíření
    .description = Udržovat rozšíření aktuální bez ručního vstupu. Dobrá volba pro vaši bezpečnost.
vorbit-sync-checkbox2 =
    .label = Povolit Firefox Sync
    .description = Synchronizovat vaše data s ostatními prohlížeči. Vyžaduje restart.
vorbit-autocopy-checkbox2 =
    .label = Povolit vložení kolečkem
    .description = Vyberte text pro jeho zkopírování a poté jej vložte kliknutím kolečkem myši.
vorbit-styling-checkbox2 =
    .label = Povolit přizpůsobení userChrome.css
    .description = Povolte, pokud si chcete přizpůsobit rozhraní ručně načteným vzhledem.
vorbit-network-heading2 =
    .label = Síť
vorbit-ipv6-checkbox2 =
    .label = Povolit IPv6
    .description = Povolit aplikaci { -brand-short-name } připojit se pomocí IPv6.
vorbit-privacy-heading2 =
    .label = Soukromí
vorbit-xorigin-ref-checkbox2 =
    .label = Omezit referery z jiných domén
    .description = Posílat referer pouze ze stejné domény.
vorbit-broken-heading2 =
    .label = Vytváření otisků
vorbit-webgl-checkbox2 =
    .label = Vždy povolit WebGL
    .description = Vždy povolí WebGL bez dotazování se na oprávnění.
vorbit-webgl-prompt-checkbox2 =
    .label = Skrýt vyskakovací okno WebGL pro každý web
    .description = Skryje vyskakovací okno, které se objeví, když se web pokusí vytvořit kontext WebGL. Dotaz můžete kdykoli ručně vyvolat kliknutím na ikonu ve vyhledávací liště.
vorbit-rfp-checkbox2 =
    .label = Povolit ResistFingerprinting
    .description = Povolí všechny ochrany proti vytváření otisků prohlížeče, může ale způsobit, že některé weby přestanou správně fungovat.
vorbit-letterboxing-checkbox2 =
    .label = Povolit letterboxing
    .description = Letterboxing nastaví okraje kolem oken tak, aby se vrátila omezená sada zaokrouhlených rozlišení.
vorbit-security-heading2 =
    .label = Zabezpečení
