# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } — anonymní prohlížení
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Rychlé a soukromé prohlížení webu
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos]
            { -brand-full-name.case-status ->
                [with-cases] { -brand-full-name } — Anonymní prohlížení
               *[no-cases] { -brand-full-name } — Anonymní prohlížení
            }
       *[other]
            { -brand-full-name.case-status ->
                [with-cases] Anonymní prohlížení { -brand-full-name(case: "gen") }
               *[no-cases] Anonymní prohlížení — { -brand-full-name }
            }
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Anonymní prohlížení
popups-infobar-dont-show-message2 =
    .label = Nezobrazovat, pokud jsou blokována vyskakovací okna nebo přesměrování třetích stran
    .accesskey = N
edit-popup-settings2 =
    .label = Spravovat nastavení vyskakovacích oken a přesměrování třetích stran…
    .accesskey = S
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Zobrazit informaci o stránce
            [1] Zobrazit informaci o stránce (1 zablokovaný sledovací prvek)
            [one] Zobrazit informaci o stránce (1 zablokovaný sledovací prvek)
            [few] Zobrazit informaci o stránce ({ $count } zablokované sledovací prvky)
            [many] Zobrazit informaci o stránce ({ $count } zablokovaných sledovacích prvků)
           *[other] Zobrazit informaci o stránce ({ $count } zablokovaných sledovacích prvků)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } odkaz
            [few] { $count } odkazy
           *[other] { $count } odkazů
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Zprávy a další…
    .accesskey = A
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Zprávy, Pošta a další…
    .accesskey = Z
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Sdílet…
    .accesskey = S
urlbar-identity-button =
    .aria-label = Zobrazit informace o stránce

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Otevřít instalační panel zpráv
urlbar-web-notification-anchor =
    .tooltiptext = Změní, jestli můžete ze serveru přijímat oznámení
urlbar-midi-notification-anchor =
    .tooltiptext = Otevřít MIDI panel
urlbar-serial-notification-anchor =
    .tooltiptext = Otevřít panel Sériové porty
urlbar-eme-notification-anchor =
    .tooltiptext = Správa využívání softwaru DRM
urlbar-web-authn-anchor =
    .tooltiptext = Otevřít panel webové autentizace
urlbar-canvas-notification-anchor =
    .tooltiptext = Spravovat oprávnění přístupu k informacím canvasu
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Spravovat sdílení mikrofonu se stránkou
urlbar-default-notification-anchor =
    .tooltiptext = Otevře panel zpráv
urlbar-geolocation-notification-anchor =
    .tooltiptext = Otevře panel se žádostmi o polohu
urlbar-localhost-notification-anchor =
    .tooltiptext = Správa přístupu k místnímu zařízení pro tento web
urlbar-local-network-notification-anchor =
    .tooltiptext = Správa sdílení přístupu k místní síti pomocí tohoto webu
urlbar-xr-notification-anchor =
    .tooltiptext = Otevře panel oprávnění pro virtuální realitu
urlbar-storage-access-anchor =
    .tooltiptext = Otevřít nastavení přístupu k informacím o vašem prohlížení
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Spravovat sdílení oken nebo obrazovky se stránkou
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Otevřít panel zpráv offline úložiště
urlbar-password-notification-anchor =
    .tooltiptext = Otevřít panel zpráv uložení hesla
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Spravovat sdílení webkamery a/nebo mikrofonu se stránkou
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Spravovat sdílení zvukového výstupu se stránkou
urlbar-autoplay-notification-anchor =
    .tooltiptext = Otevřít panel automatického přehrávání
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Uložit data natrvalo
urlbar-addons-notification-anchor =
    .tooltiptext = Otevřít panel zpráv instalace doplňku
urlbar-search-tips-confirm = Ok, rozumím
urlbar-search-tips-confirm-short = Rozumím
urlbar-result-menu-button =
    .title = Otevře nabídku
urlbar-result-menu-button-feedback = Zpětná vazba
    .title = Otevřít nabídku
urlbar-result-menu-learn-more2 = Zjistit více
    .accesskey = Z
urlbar-result-menu-remove-from-history2 = Smazat z historie
    .accesskey = r
urlbar-result-menu-tip-get-help2 = Získat pomoc
    .accesskey = Z
urlbar-result-menu-dismiss-suggestion2 = Vyřadit tento návrh
    .accesskey = O
urlbar-result-menu-remove-top-site = Odebrat tuto top stránku
    .accesskey = O
urlbar-result-menu-manage-firefox-suggest2 = Spravovat { -firefox-suggest-brand-name }
    .accesskey = S
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Nahlásit nepřesnou polohu
    .accesskey = N
urlbar-result-menu-show-less-frequently3 = Zobrazit méně často
    .accesskey = Z
urlbar-result-menu-dont-show-weather-suggestions3 = Nezobrazovat návrhy počasí
    .accesskey = N
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Nahlásit nepřesnou polohu
urlbar-result-menu-show-less-frequently2 = Zobrazit méně často
urlbar-result-menu-dont-show-weather-suggestions2 = Nezobrazovat návrhy počasí
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Odmítnout návrh
    .accesskey = O
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Odebrat z historie
    .accesskey = O
urlbar-result-menu-learn-more =
    .label = Zjistit více
    .accesskey = Z
urlbar-result-menu-remove-from-history =
    .label = Smazat z historie
    .accesskey = r
urlbar-result-menu-tip-get-help =
    .label = Získat pomoc
    .accesskey = Z
urlbar-result-menu-dismiss-suggestion =
    .label = Vyřadit tento návrh
    .accesskey = O
urlbar-result-menu-manage-firefox-suggest =
    .label = Spravovat { -firefox-suggest-brand-name }
    .accesskey = S
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Nahlásit nepřesnou polohu
urlbar-result-menu-show-less-frequently =
    .label = Zobrazit méně často
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Nezobrazovat návrhy počasí
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Otevře nabídku
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Děkujeme za vaši zpětnou vazbu
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Děkujeme za vaši zpětnou vazbu. Návrhy počasí už neuvidíte.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Méně psaní, více výsledků: používejte { $engineName } přímo z adresního řádku.
urlbar-search-tips-redirect-2 = Zadejte do adresního řádku hledaný text a uvidíte návrhy od vyhledávače { $engineName } a z vaší historie prohlížení.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Klepněte na tuto zkratku, abyste rychleji našli, co potřebujete.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Záložky
urlbar-search-mode-tabs = Panely
urlbar-search-mode-history = Historie
urlbar-search-mode-actions = Akce

##

urlbar-geolocation-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali zjišťovat vaši polohu.
urlbar-localhost-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali připojení k místním zařízením.
urlbar-local-network-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali připojení k místní síti.
urlbar-xr-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali přístup k vašim zařízením pro virtuální realitu.
urlbar-web-notifications-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali zobrazovat oznámení.
urlbar-camera-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali přístup k vaší kameře.
urlbar-microphone-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali přístup k vašemu mikrofonu.
urlbar-screen-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali sdílení vaší obrazovky.
urlbar-persistent-storage-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali ukládání dat natrvalo.
urlbar-popup-blocked2 =
    .tooltiptext = Pro tuto webovou stránku jste zablokovali vyskakovací okna a přesměrování třetích stran.
urlbar-autoplay-media-blocked =
    .tooltiptext = Pro tento server jste zablokovali automatické přehrávání médií se zvukem.
urlbar-canvas-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali přístup k informacím canvasu.
urlbar-midi-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali přístup k MIDI zařízením.
urlbar-serial-blocked =
    .tooltiptext = Zablokovali jste přístup k sériovému portu pro tuto webovou stránku.
urlbar-install-blocked =
    .tooltiptext = Tomuto serveru jste zablokovali instalaci doplňků.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Upraví tuto záložku ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Přidá tuto stránku do záložek ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Rozdělené zobrazení
    .tooltiptext = Rozdělené zobrazení

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Vložit a jít
    .accesskey = V
urlbar-menuitem-paste-and-search =
    .label = Vložit a hledat
    .accesskey = V

## Searchbar context menu

clear-search-history =
    .label = Vymazat historii vyhledávání
    .accesskey = S

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Nastavení tohoto rozšíření…
    .accesskey = e
page-action-remove-extension2 =
    .label = Odebrat rozšíření
    .accesskey = r

## Auto-hide Context Menu

full-screen-autohide =
    .label = Skrýt nástrojové lišty
    .accesskey = S
full-screen-exit =
    .label = Ukončit režim celé obrazovky
    .accesskey = k

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Vyhledat pomocí
search-one-offs-change-settings-compact-button =
    .tooltiptext = Změnit nastavení vyhledávání
search-one-offs-context-open-new-tab =
    .label = Hledat v novém panelu
    .accesskey = n
search-one-offs-context-set-as-default =
    .label = Nastavit jako výchozí vyhledávač
    .accesskey = v
search-one-offs-context-set-as-default-private =
    .label = Nastavit jako výchozí vyhledávač pro anonymní prohlížení
    .accesskey = p
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Přidat vyhledávač „{ $engineName }“
    .label = Přidat „{ $engineName }“
    .tooltiptext = Přidá vyhledávač „{ $engineName }“
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Přidat vyhledávač
    .accesskey = P
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Přidat vyhledávač

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Záložky ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Otevřené panely ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historie prohlížení ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Akce ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Zobrazit doplňky
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = rozšíření, motivy vzhledu, doplňky
# Opens preferences page at AI controls
quickactions-manageai = Spravovat ovládání AI
quickactions-cmd-manageai = zakázat ai, vypnout ai, spravovat ai
# Opens the bookmarks library window
quickactions-bookmarks2 = Správa záložek
quickactions-cmd-bookmarks = záložky
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Vymazat nedávnou historii
quickactions-cmd-clearrecenthistory2 = cookies, vymazat  cookies, mezipaměť, vymazat mezipaměť, údaje o prohlížení, vymazat údaje o prohlížení, historie, vymazat nedávnou historii
# Opens about:downloads page
quickactions-downloads2 = Zobrazit stahování
quickactions-cmd-downloads = stahování
# Opens about:addons page in the extensions section
quickactions-extensions = Správa rozšíření
quickactions-cmd-extensions2 = rozšíření, doplňky
# Opens Firefox View
quickactions-firefoxview = Otevřít { -firefoxview-brand-name(case: "acc") }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = otevřít { -firefoxview-brand-name }, { -firefoxview-brand-name }, otevřít přehled, přehled
# Opens SUMO home page
quickactions-help =
    { -brand-product-name.case-status ->
        [with-cases] Nápověda { -brand-product-name(case: "gen") }
       *[no-cases] Nápověda aplikace { -brand-product-name }
    }
quickactions-cmd-help = nápověda, podpora
# Opens the devtools web inspector
quickactions-inspector2 = Otevřít nástroje pro vývojáře
quickactions-cmd-inspector2 = inspektor, inspector, devtools, vývojářské nástroje
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Výběr barvy
quickactions-cmd-colorpicker = výběr barvy, kapátko, sejmutí barvy
# Opens Firefox Library
quickactions-cmd-library = knihovna
quickactions-library = Otevřít Knihovnu stránek
# Opens about:logins
quickactions-logins2 = Správa hesel
quickactions-cmd-logins = přihlašovací údaje, hesla
# Mutes all tabs playing audio
quickactions-mute = Ztlumit přehrávání zvuku panelů
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = ztlumit, ticho, pšššt
# Opens the print dialog
quickactions-print2 = Vytisknout stránku
quickactions-cmd-print = tisk
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Uložit stránku jako PDF
quickactions-cmd-savepdf2 = pdf, uložit stránku
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Otevřít editor PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Otevřít anonymní okno
quickactions-cmd-private = anonymní prohlížení
# Opens a SUMO article explaining how to refresh
quickactions-refresh =
    { -brand-short-name.case-status ->
        [with-cases] Obnova { -brand-short-name(case: "gen") }
       *[no-cases] Obnova aplikace { -brand-short-name }
    }
quickactions-cmd-refresh = obnova, obnovit
# Restarts the browser
quickactions-restart =
    { -brand-short-name.case-status ->
        [with-cases] Restartovat { -brand-short-name(case: "acc") }
       *[no-cases] Restartovat aplikaci { -brand-short-name }
    }
quickactions-cmd-restart = restart, restartovat
# Opens the screenshot tool
quickactions-screenshot3 = Pořídit snímek stránky
quickactions-cmd-screenshot2 = snímek obrazovky, pořízení snímku obrazovky
# Opens about:translations
quickactions-translate = Přeložit
quickactions-cmd-translate = přeložit
# Opens about:preferences
quickactions-settings2 = Nastavení
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = nastavení, předvolby, možnosti, spravovat
# Opens about:addons page in the themes section
quickactions-themes = Nastavení vzhledu
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = motivy, vzhledy, doplňky
# Opens a SUMO article explaining how to update the browser
quickactions-update =
    { -brand-short-name.case-status ->
        [with-cases] Aktualizace { -brand-short-name(case: "gen") }
       *[no-cases] Aktualizace aplikace { -brand-short-name }
    }
quickactions-cmd-update = aktualizace, aktualizovat
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Zobrazit zdrojový kód stránky
quickactions-cmd-viewsource2 = zobrazit zdrojový kód, zdrojový kód, zdrojový kód stránky
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Otevřít { -firefoxlabs-brand-name }
quickactions-cmd-labs = laboratoř,experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Zjistit více o rychlých akcích
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Stisknutím tabulátoru vyberte:

## Bookmark Panel

bookmarks-add-bookmark = Přidat záložku
bookmarks-edit-bookmark = Upravit záložku
bookmark-panel-cancel =
    .label = Zrušit
    .accesskey = Z
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Odstranit záložku
            [few] Odstranit { $count } záložky
           *[other] Odstranit { $count } záložek
        }
    .accesskey = O
bookmark-panel-show-editor-checkbox =
    .label = Zobrazovat editor při ukládání
    .accesskey = u
bookmark-panel-save-button2 =
    .label = Uložit
    .accesskey = U
bookmark-panel-save-button =
    .label = Uložit
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Informace o serveru { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Zabezpečení spojení se serverem { $host }
identity-connection-not-secure = Spojení není zabezpečené
identity-connection-secure = Zabezpečené spojení
identity-connection-failure = Chyba spojení
identity-connection-internal =
    { -brand-short-name.case-status ->
        [with-cases] Toto je zabezpečená stránka { -brand-short-name(case: "gen") }.
       *[no-cases] Toto je zabezpečená stránka aplikace { -brand-short-name }.
    }
identity-connection-file = Tato stránka je uložena ve vašem počítači.
identity-connection-associated = Tato stránka je načtena z jiné stránky.
identity-extension-page = Tato stránka je načtena z doplňku.
identity-active-blocked =
    { -brand-short-name.gender ->
        [masculine] { -brand-short-name } zablokoval nezabezpečené části této stránky.
        [feminine] { -brand-short-name } zablokovala nezabezpečené části této stránky.
        [neuter] { -brand-short-name } zablokovalo nezabezpečené části této stránky.
       *[other] Aplikace { -brand-short-name } zablokovala nezabezpečené části této stránky.
    }
identity-custom-root = Připojení je ověřeno vydavatelem certifikátů, kterého Mozilla nezná.
identity-passive-loaded = Části této stránky nejsou zabezpečené (například obrázky).
identity-active-loaded = Na této stránce jste ochranu zakázali.
identity-weak-encryption = Tento server používá slabé šifrování.
identity-https-only-connection-upgraded = (povýšeno na HTTPS)
identity-https-only-label2 = Automaticky povýšit spojení se serverem na zabezpečené
identity-https-only-dropdown-on =
    .label = Zapnuto
identity-https-only-dropdown-off =
    .label = Vypnuto
identity-https-only-dropdown-off-temporarily =
    .label = Dočasně vypnuto
identity-https-only-info-turn-on3 =
    { -brand-short-name.gender ->
        [masculine] Zapněte pro tento server povýšení komunikace na HTTPS, pokud chcete, aby { -brand-short-name } povýšil komunikaci, kdykoliv je to možné.
        [feminine] Zapněte pro tento server povýšení komunikace na HTTPS, pokud chcete, aby { -brand-short-name } povýšila komunikaci, kdykoliv je to možné.
        [neuter] Zapněte pro tento server povýšení komunikace na HTTPS, pokud chcete, aby { -brand-short-name } povýšilo komunikaci, kdykoliv je to možné.
       *[other] Zapněte pro tento server povýšení komunikace na HTTPS, pokud chcete, aby aplikace { -brand-short-name } povýšila komunikaci, kdykoliv je to možné..
    }
identity-https-only-info-turn-off3 = Pokud se zdá stránka rozbitá, můžete povýšení na HTTPS vypnout, aby se znovu načetla za použití nezabezpečeného spojení HTTP.
identity-https-only-info-no-upgrade = Nepodařilo se povýšit spojení z HTTP.
identity-permissions-storage-access-header = Cross-site cookies
identity-permissions-storage-access-hint = Tyto weby mohou používat cross-site cookies a během vaší návštěvy této stránky tak přistupovat k jejím datům.
identity-permissions-storage-access-learn-more = Zjistit více
identity-permissions-reload-hint = Pro provedení změn může být potřeba stránku znovu načíst.
identity-clear-site-data =
    .label = Vymazat cookies a data stránky…
identity-connection-not-secure-security-view = Spojení s tímto serverem není zabezpečené.
identity-connection-verified = Spojení s tímto serverem je zabezpečené.
identity-ev-owner-label2 = Certifikát vydán pro
identity-verifier-label2 = Ověřil
identity-ev-owner-label = Certifikát vydán pro:
identity-verifier-label = Ověřil:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Klasifikovaný podle nařízení (EÚ) 2024/1183.
identity-description-custom-root2 = Mozilla tohoto vydavatele certifikátů nezná. Mohl být přidán operačním systémem nebo správcem vašeho počítače.
identity-cert-exception-overridden = Tomuto serveru jste udělili bezpečnostní výjimku
identity-remove-cert-exception =
    .label = Odstranit výjimku
    .accesskey = O
identity-description-insecure = Vaše spojení s tímto serverem není soukromé. Informace, které odešlete (jako hesla, zprávy, číslo platební karty atd.), mohou být viděny ostatními.
identity-description-weak-cipher-intro = Vaše spojení s tímto serverem používá slabé šifrování a není soukromé.
identity-description-weak-cipher-risk = Ostatní lidé mohou vidět vaše informace nebo pozměnit chování stránky.
identity-description-active-blocked2 =
    { -brand-short-name.gender ->
        [masculine] { -brand-short-name } zablokoval nezabezpečené části této stránky.
        [feminine] { -brand-short-name } zablokovala nezabezpečené části této stránky.
        [neuter] { -brand-short-name } zablokovalo nezabezpečené části této stránky.
       *[other] Aplikace { -brand-short-name } zablokovala nezabezpečené části této stránky.
    }
identity-description-passive-loaded = Vaše připojení není soukromé a informace, které sdílíte s tímto serverem, mohou být viděny ostatními.
identity-description-passive-loaded-insecure2 = Tato webová stránka obsahuje obsah, který není zabezpečen (například obrázky).
identity-description-passive-loaded-mixed2 =
    { -brand-short-name.gender ->
        [masculine] Ačkoli { -brand-short-name } zablokoval nějaký obsah, stránka stále ještě obsahuje nezabezpečený obsah (například obrázky).
        [feminine] Ačkoli { -brand-short-name } zablokovala nějaký obsah, stránka stále ještě obsahuje nezabezpečený obsah (například obrázky).
        [neuter] Ačkoli { -brand-short-name } zablokovalo nějaký obsah, stránka stále ještě obsahuje nezabezpečený obsah (například obrázky).
       *[other] Ačkoli aplikace { -brand-short-name } zablokovala nějaký obsah, stránka stále ještě obsahuje nezabezpečený obsah (například obrázky).
    }
identity-description-active-loaded = Tato webová stránka obsahuje obsah, který není zabezpečen (například skripty), a spojení s tímto serverem tak není soukromé.
identity-description-active-loaded-insecure = Informace, které sdílíte s tímto serverem (jako hesla, zprávy, číslo platební karty, atd.), mohou být viděny ostatními.
identity-description-tls-key-logging-heading = Vaše připojení nemusí být soukromé
identity-description-tls-key-logging-message = Aplikace nebo služba může vidět vaši šifrovanou komunikaci z této stránky.
identity-more-info-link-text =
    .label = Více informací

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimalizovat
browser-window-maximize-button =
    .tooltiptext = Maximalizovat
browser-window-restore-down-button =
    .tooltiptext = Obnovit z maximalizace
browser-window-close-button =
    .tooltiptext = Zavřít
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Návrat zpět

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importovat záložky…
    .tooltiptext =
        { -brand-short-name.case-status ->
            [with-cases] Importovat záložky z jiného prohlížeče do { -brand-short-name(case: "gen") }.
           *[no-cases] Importovat záložky z jiného prohlížeče do aplikace { -brand-short-name }
        }
bookmarks-toolbar-empty-message = Chcete-li mít ke svým záložkám rychlý přístup, umístěte je sem na lištu záložek. <a data-l10n-name="manage-bookmarks">Spravovat záložky…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamera:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamera
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Zvukový výstup
popup-select-window-or-screen =
    .label = Okno nebo obrazovka:
    .accesskey = O
popup-all-windows-shared = Budou sdílena všechna viditelná okna na vaší obrazovce.

## WebRTC window or screen share tab switch warning

sharing-warning-window =
    { -brand-short-name.case-status ->
        [with-cases] Sdílíte obsah okna { -brand-short-name(case: "gen") }. Ostatní lidé uvidí obsah každého panelu, který otevřete.
       *[no-cases] Sdílíte obsah okna aplikace { -brand-short-name }. Ostatní lidé uvidí obsah každého panelu, který otevřete.
    }
sharing-warning-screen = Sdílíte obsah celé své obrazovky. Ostatní lidé uvidí obsah každého panelu, který otevřete.
sharing-warning-proceed-to-tab =
    .label = Otevřít panel
sharing-warning-disable-for-session =
    .label = Zakázat ochranu sdílení pro tuto relaci

## WebSerial "select a port" popup

webserial-select-port-label = Výběr seriového portu:
webserial-no-ports-available = Sériové porty nejsou dostupné

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Zavřít
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Zadejte webovou adresu nebo dotaz pro vyhledávač
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Zadejte webovou adresu
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Vyhledat pomocí { $name }
    .placeholder = Vyhledat na webu
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Vyhledat na serveru { $name }
    .placeholder = Zadejte hledaný výraz
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Hledat v záložkách
    .placeholder = Zadejte hledaný výraz
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Hledat v historii
    .placeholder = Zadejte hledaný výraz
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Hledat v otevřených panelech
    .placeholder = Zadejte hledaný výraz
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Vyhledávání akcí
    .placeholder = Zadejte hledané výrazy
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Zadejte webovou adresu nebo dotaz pro vyhledávač { $name }
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Prohlížeč je ovládán vzdáleně (pomocí nástroje { $component })
urlbar-permissions-granted =
    .tooltiptext = Tomuto serveru jste udělili dodatečná oprávnění.
urlbar-switch-to-tab =
    .value = Přepnout na panel:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Rozšíření:
urlbar-go-button2 =
    .title = Přejde na adresu v adresním řádku
urlbar-page-action-button =
    .tooltiptext = Akce stránky
urlbar-revert-button =
    .tooltiptext = Zobrazí adresu v adresním řádku

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Vyhledat v anonymním okně pomocí { $engine }
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Vyhledat v anonymním okně
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Vyhledat pomocí { $engine }
urlbar-result-action-sponsored = Sponzorováno
urlbar-result-action-switch-tab = Přepnout na panel
urlbar-result-action-move-tab-to-split-view = Přesunout panel do rozděleného zobrazení
urlbar-result-action-visit = Navštívit
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Přepnout na panel · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Nepojmenovaná skupina
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Použít adresu ze schránky
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Stisknutím klávesy Tab provedete vyhledávání pomocí vyhledávače { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Stisknutím klávesy Tab provedete vyhledávání na webu { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Vyhledat pomocí { $engine } přímo z adresního řádku
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Vyhledat na webu { $engine } přímo z adresního řádku
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopírovat
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = nedefinováno
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle =
    { -brand-product-name.case-status ->
        [with-cases] Rozšíření { -brand-product-name(case: "gen") }
       *[no-cases] Rozšíření aplikace { -brand-product-name }
    }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Doporučené
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> ve městě { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> v { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> v { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Sponzorované
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Dotázat se
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Naposledy navštívena { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] Naposledy navštívena před { $daysAgo } dnem
        [few] Naposledy navštívena před { $daysAgo } dny
        [many] Naposledy navštívena před { $daysAgo } dny
       *[other] Naposledy navštívena před { $daysAgo } dny
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] Naposledy navštívena před { $weeksAgo } týdnem
        [few] Naposledy navštívena před { $weeksAgo } týdny
        [many] Naposledy navštívena před { $weeksAgo } týdny
       *[other] Naposledy navštívena před { $weeksAgo } týdny
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] Naposledy navštívena před { $monthsAgo }měsícem
        [few] Naposledy navštívena před { $monthsAgo } měsíci
        [many] Naposledy navštívena před { $monthsAgo } měsíci
       *[other] Naposledy navštívena před { $monthsAgo } měsíci
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Naposledy navštívena dne { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Uloženo do záložek dne { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Naposledy navštívena { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Naposledy navštívena { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Naposledy navštívena { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Burzovní informace přímo v našeptávači adresního řádku
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Nechte si zobrazovat aktuality z akciového trhu a další informace od našich partnerů, když budete s { -vendor-short-name(case: "ins") } sdílet údaje o vyhledávacích dotazech. <a data-l10n-name="learn-more-link">Zjistit více</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Povolit našeptávání
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Teď ne
urlbar-result-realtime-opt-in-dismiss = Zavřít
urlbar-result-realtime-opt-in-dismiss-all2 = Tyto návrhy nezobrazovat
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Nezobrazovat návrhy z akciových trhů
    .accesskey = N
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Nezobrazovat návrhy z akciových trhů
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Tyto návrhy nezobrazovat
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Nezobrazovat návrhy z akciových trhů
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Děkujeme za vaši zpětnou vazbu. Návrhy z akciových trhů se vám už nebudou zobrazovat.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Návrhy pro akciový trh
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Děkujeme za vaši zpětnou vazbu. Tyto návrhy se vám už nebudou zobrazovat.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · V { $daysUntilStart } dni
        [few] { $name } · Ve { $daysUntilStart } dnech
        [many] { $name } · V { $daysUntilStart } dnech
       *[other] { $name } · V { $daysUntilStart } dnech
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Začíná za { $daysUntilStart } den
        [few] { $name } · Začíná za { $daysUntilStart } dny
        [many] { $name } · Začíná za { $daysUntilStart } dní
       *[other] { $name } · Začíná za { $daysUntilStart } dní
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Končí za { $daysUntilEnd } den
        [few] { $name } · Končí za { $daysUntilEnd } dny
        [many] { $name } · Končí za { $daysUntilEnd } dní
       *[other] { $name } · Končí za { $daysUntilEnd } dní
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Dnes
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Končí dnes

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Vyhledat pomocí { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Hledat { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Hledat pomocí { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, vyberte vyhledávač
urlbar-searchmode-button-no-engine2 =
    .title = Není vybrána žádná zkratka, vyberte zkratku
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Vyhledávání pomocí klíčových slov je zakázáno
urlbar-searchmode-dropmarker2 =
    .title = Vyberte vyhledávač
urlbar-searchmode-bookmarks4 = Záložky
urlbar-searchmode-tabs4 = Panely
urlbar-searchmode-history4 = Historie
urlbar-searchmode-actions4 = Akce
urlbar-searchmode-bookmarks3 = Záložky
    .accesskey = Z
urlbar-searchmode-tabs3 = Panely
    .accesskey = P
urlbar-searchmode-history3 = Historie
    .accesskey = H
urlbar-searchmode-actions3 = Akce
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Zavřít
urlbar-searchmode-default2 =
    .title = Výchozí vyhledávač
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Přidat „{ $engineName }“
    .title = Přidá vyhledávač „{ $engineName }“
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Vyhledat pomocí:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Vyhledat pomocí:
urlbar-searchmode-popup-search-settings2 = Nastavení vyhledávání
urlbar-searchmode-popup-settings2 = Nastavení
urlbar-searchmode-popup-search-settings = Nastavení vyhledávání
    .accesskey = N
urlbar-searchmode-popup-settings = Nastavení
    .accesskey = N

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Hledat v záložkách
urlbar-result-action-search-history = Hledat v historii
urlbar-result-action-search-tabs = Najít panel
urlbar-result-action-search-actions = Akce vyhledávání
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Přepnout na { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Otevřít { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Otevřít v novém panelu
    .accesskey = p
urlbar-view-context-menu-open-in-container-tab =
    .label = Otevřít v novém kontejnerovém panelu
    .accesskey = k
urlbar-view-context-menu-open-in-window =
    .label = Otevřít v novém okně
    .accesskey = o
urlbar-view-context-menu-open-in-private-window =
    .label = Otevřít v novém anonymním okně
    .accesskey = a
urlbar-view-context-menu-open-in-tab2 = Otevřít v novém panelu
    .accesskey = p
urlbar-view-context-menu-open-in-container-tab2 = Otevřít v novém kontejnerovém panelu
    .accesskey = k
urlbar-view-context-menu-open-in-window2 = Otevřít v novém okně
    .accesskey = o
urlbar-view-context-menu-open-in-private-window2 = Otevřít v novém anonymním okně
    .accesskey = a
urlbar-view-context-menu-search-in-tab = Vyhledat v novém panelu
    .accesskey = V
urlbar-view-context-menu-search-in-container-tab = Vyhledat v novém kontejnerovém panelu
    .accesskey = k
urlbar-view-context-menu-search-in-window = Vyhledat v novém okně
    .accesskey = o
urlbar-view-context-menu-search-in-private-window = Vyhledat v novém anonymním okně
    .accesskey = a
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Při použití klávesy Tab tuto nabídku přeskočit
    .accesskey = P

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Návrhy vyhledávače { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Rychlé akce
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Nedávno vyhledávané
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Populární na { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Nezobrazovat populární vyhledávání
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Nezobrazovat populární vyhledávání
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Nezobrazovat populární vyhledávání
    .accesskey = N
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Děkujeme za zpětnou vazbu. Už se vám populární vyhledávání nebudou zobrazovat.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Zapnout zobrazení čtečky
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Zavřít zobrazení čtečky

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Zobrazit video jako obraz v obraze ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Zavřít obraz v obraze ({ $shortcut })
picture-in-picture-panel-header = Obraz v obraze
picture-in-picture-panel-headline = Tato webová stránka nedoporučuje režim Obraz v obraze
picture-in-picture-panel-body = Pokud je zapnutý režim Obraz v obraze, videa se nemusí zobrazovat tak, jak vývojář zamýšlel.
picture-in-picture-enable-toggle =
    .label = Přesto povolit

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> je teď v režimu celé obrazovky
fullscreen-warning-no-domain = Tento dokument je teď v režimu celé obrazovky
fullscreen-exit-button = Ukončit režim celé obrazovky (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Ukončit režim celé obrazovky (esc)
fullscreen-keyboardlock-exit-button = Ukončit režim celé obrazovky (stiskněte a podržte klávesu Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Ukončit režim celé obrazovky (stiskněte a podržte klávesu Esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> má kontrolu nad vaším kurzorem. Pro odebrání kontroly stiskněte klávesu Esc.
pointerlock-warning-no-domain = Tento dokument má kontrolu nad vaším kurzorem. Pro odebrání kontroly stiskněte klávesu Esc.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Správa záložek
bookmarks-recent-bookmarks-panel-subheader = Naposledy přidané
bookmarks-toolbar-chevron =
    .tooltiptext = Zobrazí více záložek
bookmarks-sidebar-content =
    .aria-label = Záložky
bookmarks-menu-button =
    .label = Nabídka záložek
bookmarks-other-bookmarks-menu =
    .label = Ostatní záložky
bookmarks-mobile-bookmarks-menu =
    .label = Záložky z mobilu

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Skrýt postranní lištu záložek
           *[other] Zobrazit v postranní liště
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Skrýt lištu záložek
           *[other] Zobrazit lištu záložek
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Skrýt lištu záložek
           *[other] Zobrazit lištu záložek
        }

##

bookmarks-search =
    .label = Hledat v záložkách
bookmarks-tools =
    .label = Nástroje pro práci se záložkami
bookmarks-subview-edit-bookmark =
    .label = Upravit záložku…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Záložky
    .toolbarname = Lišta záložek
    .accesskey = z
bookmarks-toolbar-menu =
    .label = Lišta záložek
bookmarks-toolbar-placeholder =
    .title = Záložky nástrojové lišty
bookmarks-toolbar-placeholder-button =
    .label = Záložky nástrojové lišty
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Přidat současný panel do záložek…

## Library Panel items

library-bookmarks-menu =
    .label = Záložky

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Opravit znakovou sadu textu
    .tooltiptext = Na základě obsahu stránky odhadne správnou znakovou sadu textu

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Nastavení
    .tooltiptext =
        { PLATFORM() ->
            [macos] Otevře nastavení ({ $shortcut })
           *[other] Otevře nastavení
        }
toolbar-overflow-customize-button =
    .label = Nastavení tlačítek a lišt…
    .accesskey = V
toolbar-button-email-link =
    .label = Poslat odkaz e-mailem
    .tooltiptext = Odešle odkaz na aktuální stránku
toolbar-button-logins =
    .label = Hesla
    .tooltiptext = Zobrazení a správa vašich uložených hesel
qrcode-panel-error =
    .message = Nepodařilo se vygenerovat QR kód. Zkuste to prosím znovu.
qrcode-copy-button =
    .label = Kopírovat
qrcode-copy-success =
    .message = QR kód zkopírován do schránky.
qrcode-copy-error =
    .message = Kopírování QR kódu se nezdařilo.
qrcode-save-button =
    .label = Uložit
qrcode-window-title = QR kód
qrcode-dialog-title = QR kód
qrcode-image =
    .aria-label = QR kód
qrcode-close-button =
    .aria-label = Zavřít
toolbar-button-save-page =
    .label = Uložit stránku
    .tooltiptext = Uloží aktuální stránku ({ $shortcut })
toolbar-button-open-file =
    .label = Otevřít soubor
    .tooltiptext = Otevře soubor ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Synchronizované panely
    .tooltiptext = Zobrazí panely z jiných zařízení
toolbar-button-send-tab =
    .label = Poslat panel
    .tooltiptext = Odešle aktuální panel do jiného zařízení
toolbar-button-new-private-window =
    .label = Nové anonymní okno
    .tooltiptext = Otevře nové anonymní okno ({ $shortcut })
toolbar-button-share-tab =
    .label = Sdílet
    .tooltiptext = Sdílet tuto stránku
toolbar-button-tab-groups =
    .label = Skupiny panelů
    .tooltiptext = Zobrazí vaše skupiny panelů
toolbar-button-history =
    .label = Historie
    .tooltiptext = Zobrazí vaši historii ({ $shortcut })
toolbar-button-find =
    .label = Najít na stránce
    .tooltiptext = Prohledá aktuální stránku ({ $shortcut })
toolbar-button-developer =
    .label = Nástroje pro vývojáře
    .tooltiptext = Otevře nástroje pro webové vývojáře ({ $shortcut })
toolbar-button-forget =
    .label = Zapomenout
    .tooltiptext = Zapomene část historie prohlížení
toolbar-zoom-controls =
    .label = Velikost stránky
    .title = Ovládání přiblížení stránky
toolbar-button-zoom-out =
    .label = Zmenšit
    .tooltiptext = Zmenší velikost stránky ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Obnoví velikost stránky ({ $shortcut })
toolbar-button-zoom-in =
    .label = Zvětšit
    .tooltiptext = Zvětší velikost stránky ({ $shortcut })
toolbar-edit-controls =
    .label = Úpravy
    .title = Upraví ovládání
toolbar-button-cut =
    .label = Vyjmout
    .tooltiptext = Vyjme výběr do schránky ({ $shortcut })
toolbar-button-copy =
    .label = Kopírovat
    .tooltiptext = Zkopíruje výběr do schránky ({ $shortcut })
toolbar-button-paste =
    .label = Vložit
    .tooltiptext = Vloží obsah schránky ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing =
    { -brand-short-name.case-status ->
        [with-cases] Některé zvuky nebo videa na této stránce používají DRM software, což může omezit { -brand-short-name(case: "acc") } při práci s tímto obsahem.
       *[no-cases] Některé zvuky nebo videa na této stránce používají DRM software, což může omezit aplikaci { -brand-short-name } při práci s tímto obsahem.
    }
eme-notifications-drm-content-playing-manage = Nastavení
eme-notifications-drm-content-playing-manage-accesskey = N
eme-notifications-drm-content-playing-dismiss = Zavřít
eme-notifications-drm-content-playing-dismiss-accesskey = Z

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Pro přehrání audia nebo videa na této stránce musíte nejdříve povolit DRM.
eme-notifications-drm-content-disabled-button =
    .label = Povolit DRM
    .accesskey = P
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } instaluje součásti potřebné pro přehrání audia nebo videa na této stránce. Zkuste to prosím znovu později.
decoder-doctor-no-codecs-linux-message = Pro přehrávání videa může být potřeba nainstalovat video kodeky.
decoder-doctor-no-hw-acceleration-message = Pro zlepšení kvality videa může být potřeba nainstalovat Media Feature Pack od Microsoftu.
decoder-doctor-no-pulse-audio-message = Pro přehrávání hudby může být potřeba nainstalovat software PulseAudio.
decoder-doctor-unsupported-libavcodec-message = Verze knihovny libavcodec může být zranitelná nebo není podporována a pro přehrání videa je potřeba její aktualizace.
decoder-doctor-decode-error-message = Při dekódování zdroje médií nastala chyba.
decoder-doctor-decode-warning-message = Při dekódování zdroje médií nastala chyba, kterou lze opravit.
decoder-doctor-learn-how-link = Zjistěte jak
decoder-doctor-report-issue-button =
    .label = Nahlásit problém se zobrazením stránky
    .accesskey = r
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Zásuvný modul { $pluginName } spadl.
plugin-crashed-notification-reload-button =
    .label = Znovu načíst stránku
    .accesskey = o
plugin-crashed-notification-submit-button =
    .label = Odeslat hlášení o pádu
    .accesskey = d

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Podvodná stránka!
safebrowsing-reported-attack-site-message = Nahlášená útočná stránka!
safebrowsing-reported-unwanted-site-message = Nahlášená stránka s nežádoucím softwarem!
safebrowsing-reported-harmful-site-message = Nahlášená škodlivá stránka!
safebrowsing-get-me-out-of-here-button =
    .label = Rychle odsud pryč!
    .accesskey = R
safebrowsing-not-a-deceptive-site-button =
    .label = Tato stránka není podvodná…
    .accesskey = k
safebrowsing-not-an-attack-site-button =
    .label = Toto není útočná stránka…
    .accesskey = T

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Pro přístup na internet se musíte do této sítě nejprve přihlásit.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Otevřít přihlašovací stránku k síti

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Nechcete spíše přejít na { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Ano, přejít na { $hostName }
    .accesskey = A

## Password save/update panel

panel-save-update-username-2 =
    .label = Uživatelské jméno
panel-save-update-password-2 =
    .label = Heslo

##

# "More" item in macOS share menu
menu-share-more =
    .label = Více…
menu-share-windows =
    .label = Další možnosti
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Zkopírovat odkaz
            [few] Zkopírovat { $count } odkazy
            [many] Zkopírovat { $count } odkazů
           *[other] Zkopírovat { $count } odkazů
        }
    .accesskey = o
ui-tour-info-panel-close =
    .tooltiptext = Zavřít

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Povolit vyskakovací okna a přesměrování třetích stran pro { $uriHost }
    .accesskey = P

##

picture-in-picture-hide-toggle =
    .label = Skrýt přepínač obrazu v obraze
    .accesskey = v

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Přesunout přepínač obrazu v obraze doprava
    .accesskey = r
picture-in-picture-move-toggle-left =
    .label = Přesunout přepínač obrazu v obraze doleva
    .accesskey = l

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navigace
navbar-downloads =
    .label = Stahování
navbar-overflow-2 =
    .tooltiptext = Další nástroje
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Vytisknout
    .tooltiptext = Vytiskne tuto stránku… ({ $shortcut })
navbar-home =
    .label = Domů
    .tooltiptext =
        { -brand-short-name.case-status ->
            [with-cases] Otevře domovskou stránku { -brand-short-name(case: "gen") }
           *[no-cases] Otevře domovskou stránku aplikace { -brand-short-name }
        }
navbar-library =
    .label = Knihovna stránek
    .tooltiptext = Zobrazí historii, uložené záložky, a mnoho dalšího
navbar-search =
    .title = Pole vyhledávání
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Ouška panelů
tabs-toolbar-new-tab =
    .label = Nový panel
tabs-toolbar-list-all-tabs-2 =
    .label = Vyhledávání a správa panelů
    .tooltiptext = Vyhledávání a správa panelů
tabs-toolbar-list-all-tabs =
    .label = Seznam všech panelů
    .tooltiptext = Seznam všech panelů

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Přetažením panelu sem jej připnete

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message =
    { -brand-short-name.case-status ->
        [with-cases] <strong>Chcete otevřít předchozí panely?</strong> Předchozí relaci { -brand-short-name(case: "gen") } můžete obnovit z nabídky <img data-l10n-name="icon"/> v části Historie.
       *[no-cases] <strong>Chcete otevřít předchozí panely?</strong> Předchozí relaci aplikace { -brand-short-name } můžete obnovit z nabídky <img data-l10n-name="icon"/> v části Historie.
    }
restore-session-startup-suggestion-button = Jak na to

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Vaše organizace zablokovala přístup k místním souborům v tomto počítači.

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } teď slouží k vyhledávání panelů
urlbar-addons-shortcut-moved-description = Rozšíření a motivy vzhledu otevřete pomocí { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Spravovat zkratky
urlbar-addons-shortcut-moved-dismiss = Rozumím

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message =
    { -vendor-short-name.case-status ->
        [with-cases] { -brand-short-name } automaticky odesílá některá data { -vendor-short-name(case: "dat") } z důvodu vylepšení vašeho prohlížení.
       *[no-cases] { -brand-short-name } automaticky odesílá některá data organizaci { -vendor-short-name } z důvodu vylepšení vašeho prohlížení.
    }
data-reporting-notification-button =
    .label = Nastavit odesílaná data
    .accesskey = N
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Anonymní prohlížení
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Anonymní prohlížení
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Informace o anonymním prohlížení
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Jste v anonymním okně
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Toto pomáhá skrýt vaše prohlížení před ostatními na tomto zařízení, ale neudělá vás neviditelnými online. <a data-l10n-name="learn-more">Kdo by mohl vidět moji aktivitu</a>?
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Ochrana před ztrátou dat (DLP) od agenta { $agentName }. Klepněte pro více informací.
content-analysis-panel-title2 = Ochrana před ztrátou dat
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Vaše organizace používá nástroj <b>{ $agentName }</b> k řízení způsobu sdílení citlivých dat. <a data-l10n-name="info">Další informace</a>
content-analysis-panel-title = Ochrana údajů
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Vaše organizace používá k ochraně před ztrátou dat agenta <b>{ $agentName }</b>. <a data-l10n-name="info">Zjistit více</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Rozšíření
    .tooltiptext = Rozšíření

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Rozšíření
    .tooltiptext =
        Rozšíření
        Vyžadována oprávnění

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Rozšíření
    .tooltiptext =
        Rozšíření
        Některá rozšíření nejsou povolena.

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Rozšíření
    .tooltiptext =
        Rozšíření
        Některá rozšíření jsou zakázána

## Private browsing reset button

reset-pbm-panel-heading2 = Vymazat data a zahájit novou anonymní relaci?
reset-pbm-panel-description3 = Tímto vymažete historii a cookies a odhlásíte se z webů. Všechna anonymní okna se zavřou a otevře se nové.
reset-pbm-panel-description2 = Tato akce smaže historii, cookies a všechna další data stránky bez zavření anonymního okna.
reset-pbm-panel-always-ask-checkbox =
    .label = Vždy se mě zeptat
    .accesskey = V
reset-pbm-panel-cancel-button =
    .label = Zrušit
    .accesskey = Z
reset-pbm-panel-confirm-button2 =
    .label = Vymazat anonymní relaci
    .accesskey = V
reset-pbm-panel-complete = Data anonymní relace byla smazána
reset-pbm-toolbar-button2 =
    .label = Vymazat anonymní relaci
    .tooltiptext = Vymaže anonymní relaci

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Smazat všechna data prohlížení?
fire-button-panel-description = Tímto smažete historii, cookies a údaje stránek. Z webů budete odhlášeni. Toto okno se zavře a { -brand-short-name } otevře nové.
fire-button-panel-choose-description = Pokud nechcete smazat vše, vyberte místo toho jen konkrétní data.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Vybrat…
fire-button-panel-cancel-button =
    .label = Zrušit
    .accesskey = Z
fire-button-panel-confirm-button =
    .label = Smazat vše
    .accesskey = S
fire-button-panel-complete = Data o prohlížení byla smazána
fire-button-toolbar-button2 =
    .label = Smazat některá nebo všechna data
    .tooltiptext = Smaže některé nebo všechny údaje o prohlížení

## Autorefresh blocker

refresh-blocked-refresh-label =
    { -brand-short-name.gender ->
        [masculine] { -brand-short-name } zabránil této stránce v automatickém opětovném načtení.
        [feminine] { -brand-short-name } zabránila této stránce v automatickém opětovném načtení.
        [neuter] { -brand-short-name } zabránilo této stránce v automatickém opětovném načtení.
       *[other] Aplikace { -brand-short-name } zabránila této stránce v automatickém opětovném načtení.
    }
refresh-blocked-redirect-label =
    { -brand-short-name.gender ->
        [masculine] { -brand-short-name } zabránil této stránce v automatickém přesměrování na jinou stránku.
        [feminine] { -brand-short-name } zabránila této stránce v automatickém přesměrování na jinou stránku.
        [neuter] { -brand-short-name } zabránilo této stránce v automatickém přesměrování na jinou stránku.
       *[other] Aplikace { -brand-short-name } zabránila této stránce v automatickém přesměrování na jinou stránku.
    }
refresh-blocked-allow =
    .label = Povolit
    .accesskey = P

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Naše bezpečné, snadno použitelné masky chrání vaši identitu a předchází nevyžádané poště tím, že skrývají vaši e-mailovou adresu.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Všechny e-maily odeslané na vaše e-mailové masky budou přeposlány na adresu <strong>{ $useremail }</strong> (dokud se nerozhodnete je zablokovat).
firefox-relay-offer-legal-notice = Klepnutím na „Použít e-mailovou masku“ souhlasíte s <label data-l10n-name="tos-url">podmínkami poskytování služby</label> a <label data-l10n-name="privacy-url">zásadami ochrany osobních údajů</label>.
firefox-relay-offer-legal-notice-1 = Registrací a vytvořením e-mailové masky souhlasíte s <label data-l10n-name="tos-url">podmínkami poskytování služby</label> a se <label data-l10n-name="privacy-url">zásadami ochrany osobních údajů</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Neověřeno)
popup-notification-xpinstall-prompt-learn-more = Zjistit více o bezpečné instalaci doplňků
popup-notification-xpinstall-prompt-block-url = Podrobnosti
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Povolit spuštění rozšíření v anonymních oknech
    .accesskey = P
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Sdílet s vývojářem rozšíření technické údaje a údaje o interakcích
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { -brand-short-name.gender ->
        [masculine]
            { $popupCount ->
                [one] { -brand-short-name } zabránil stránce otevřít vyskakovací okno.
                [few] { -brand-short-name } zabránil stránce otevřít { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránil stránce otevřít { $popupCount } vyskakovacích oken.
            }
        [feminine]
            { $popupCount ->
                [one] { -brand-short-name } zabránila stránce otevřít vyskakovací okno.
                [few] { -brand-short-name } zabránila stránce otevřít { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránila stránce otevřít { $popupCount } vyskakovacích oken.
            }
        [neuter]
            { $popupCount ->
                [one] { -brand-short-name } zabránilo stránce otevřít vyskakovací okno.
                [few] { -brand-short-name } zabránilo stránce otevřít { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránilo stránce otevřít { $popupCount } vyskakovacích oken.
            }
       *[other]
            { $popupCount ->
                [one] Aplikace { -brand-short-name } zabránila stránce otevřít vyskakovací okno.
                [few] Aplikace { -brand-short-name } zabránila stránce otevřít { $popupCount } vyskakovací okna
               *[other] Aplikace { -brand-short-name } zabránila stránce otevřít { $popupCount } vyskakovacích oken.
            }
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } zabránil této stránce v přesměrování.
        [1] { -brand-short-name } zabránil této stránce v otevření { $popupCount } vyskakovacího okna a přesměrování.
        [one] { -brand-short-name } zabránil této stránce v otevření { $popupCount } vyskakovacího okna a přesměrování.
        [few] { -brand-short-name } zabránil této stránce v otevření { $popupCount } vyskakovacích oken a přesměrování.
        [many] { -brand-short-name } zabránil této stránce v otevření { $popupCount } vyskakovacích oken a přesměrování.
       *[other] { -brand-short-name } zabránil této stránce v otevření { $popupCount } vyskakovacích oken a přesměrování.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message =
    { -brand-short-name.gender ->
        [masculine]
            { $popupCount ->
                [one] { -brand-short-name } zabránil stránce otevřít více než jedno vyskakovací okno.
                [few] { -brand-short-name } zabránil stránce otevřít více než { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránil stránce otevřít více než { $popupCount } vyskakovacích oken.
            }
        [feminine]
            { $popupCount ->
                [one] { -brand-short-name } zabránila stránce otevřít více než jedno vyskakovací okno.
                [few] { -brand-short-name } zabránila stránce otevřít více než { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránila stránce otevřít více než { $popupCount } vyskakovacích oken.
            }
        [neuter]
            { $popupCount ->
                [one] { -brand-short-name } zabránilo stránce otevřít více než jedno vyskakovací okno.
                [few] { -brand-short-name } zabránilo stránce otevřít více než { $popupCount } vyskakovací okna
               *[other] { -brand-short-name } zabránilo stránce otevřít více než { $popupCount } vyskakovacích oken.
            }
       *[other]
            { $popupCount ->
                [one] Aplikace { -brand-short-name } zabránila stránce otevřít více než jedno vyskakovací okno.
                [few] Aplikace { -brand-short-name } zabránila stránce otevřít více než { $popupCount } vyskakovací okna
               *[other] Aplikace { -brand-short-name } zabránila stránce otevřít více než { $popupCount } vyskakovacích oken.
            }
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } zabránil této stránce v otevření více než { $popupCount } vyskakovacího okna a přesměrování.
        [few] { -brand-short-name } zabránil této stránce v otevření více než { $popupCount } vyskakovacích oken a přesměrování.
        [many] { -brand-short-name } zabránil této stránce v otevření více než { $popupCount } vyskakovacích oken a přesměrování.
       *[other] { -brand-short-name } zabránil této stránce v otevření více než { $popupCount } vyskakovacích oken a přesměrování.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Možnosti
           *[other] Předvolby
        }
    .accesskey =
        { PLATFORM() ->
            [windows] M
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Zobrazit „{ $popupURI }“
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Zobrazit “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Souborový dialog systému Windows nelze otevřít. Nepodařilo se vybrat žádný soubor nebo složku.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Souborový dialog systému Windows nelze otevřít. Soubor bude uložen do cesty { $path }.
file-picker-failed-save-nowhere = Souborový dialog systému Windows nelze otevřít. Nebyla nalezena žádná výchozí složka; soubor nebude uložen.
file-picker-crashed-open = Souborový dialog systému Windows spadl. Nepodařilo se vybrat žádný soubor nebo složku.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Souborový dialog systému Windows spadl. Soubor bude uložen do cesty { $path }.
file-picker-crashed-save-nowhere = Souborový dialog systému Windows spadl. Nebyla nalezena žádná výchozí složka; soubor nebude uložen.
file-picker-crashed-show-in-folder =
    .label = Zobrazit ve složce
    .accessKey = Z

## Unsigned add-ons notification

unsigned-addons-disabled-message = Jeden nebo více nainstalovaných doplňků nelze ověřit, a proto byly zakázány.
unsigned-addons-disabled-learn-more =
    .label = Zjistit více
    .accesskey = Z

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Tato webová stránka prohlížeč { -brand-short-name } zpomaluje. Pro jeho zrychlení zastavte její načítání.
process-hang-nonspecific-tab-message = Webová stránka zpomaluje prohlížeč { -brand-short-name }. Pro jeho zrychlení zastavte její načítání.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = Webová stránka „{ $title }“ prohlížeč { -brand-short-name } zpomaluje. Pro jeho zrychlení zastavte její načítání.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = Rozšíření „{ $addonName }“ prohlížeč { -brand-short-name } zpomaluje. Pro zrychlení prohlížeče rozšíření zastavte.
process-hang-addon-learn-more =
    .value = Zjistit více
process-hang-stop-button =
    .label = Zastavit
    .accesskey = s

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Dokončit nastavení
onboarding-aw-finish-setup-button =
    .label = Dokončit nastavení
    .tooltiptext = Dokončí nastavení { -brand-short-name(case: "gen") }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Rozšířená ochrana proti sledování je zapnuta
trustpanel-etp-label-disabled = Rozšířená ochrana proti sledování je vypnuta
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Rozšířená ochrana proti sledování: zapnuta pro { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Rozšířená ochrana proti sledování: vypnuta na { $host }
trustpanel-etp-description-enabled = Pokud se vám zdá, že něco na tomto webu nefunguje správně, zkuste ochranu vypnout.
trustpanel-etp-description-disabled =
    { -brand-product-name.case-status ->
        [with-cases] { -brand-product-name } si myslí, že by vás společnosti měly sledovat méně. Když si zapnete ochranu, blokujeme tolik sledovacích prvků, kolik jen můžeme.
       *[no-cases] Aplikace { -brand-product-name } si myslí, že by vás společnosti měly sledovat méně. Když si zapnete ochranu, blokujeme tolik sledovacích prvků, kolik jen můžeme.
    }
trustpanel-connection-label-secure = Zabezpečené spojení
trustpanel-connection-label-insecure = Spojení není zabezpečené
trustpanel-header-enabled = { -brand-product-name } je ve střehu
trustpanel-description-enabled2 = Jste chráněni. Pokud něco zpozorujeme, dáme vám vědět.
trustpanel-header-enabled-insecure = Buďte na této stránce opatrní
trustpanel-description-enabled-insecure = { -brand-product-name } si všiml něčeho podezřelého.
trustpanel-header-disabled = Vypnuli jste ochranu
trustpanel-description-disabled = { -brand-product-name } není ve střehu. Doporučujeme vám ochranu opět zapnout.
trustpanel-clear-cookies-button = Vymazat cookies a uložená data
trustpanel-privacy-link = Nastavení soukromí
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Vymazat cookies a data stránek pro { $host }
trustpanel-clear-cookies-description = Smazání cookies a dat stránek vás může odhlásit z webů a vyprázdnit vám nákupní košíky.
trustpanel-clear-cookies-subview-button-clear = Vymazat
trustpanel-clear-cookies-subview-button-cancel = Zrušit
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Ochrana spojení pro { $host }
trustpanel-siteinformation-morelink = Více informací o webu
trustpanel-blocker-see-all = Zobrazit vše
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Ochrana proti sledování pro { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Nezabezpečeno
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } zablokovaný sledovací prvek
        [few] { $count } zablokované sledovací prvky
        [many] { $count } zablokovaných sledovacích prvků
       *[other] { $count } zablokovaných sledovacích prvků
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } si myslí, že by vás společnosti měly sledovat méně. Proto jich blokujeme co nejvíce.
trustpanel-blocked-header =
    { -brand-product-name.case-status ->
        [with-cases] { -brand-product-name } zablokoval tyto věci:
       *[no-cases] Aplikace { -brand-product-name } zablokovala tyto věci:
    }
trustpanel-tracking-header =
    { -brand-short-name.case-status ->
        [with-cases] { -brand-product-name } povolil tyto věci, aby se stránky nerozbily:
       *[no-cases] Aplikace { -brand-product-name } povolila tyto věci, aby se stránky nerozbily:
    }
trustpanel-tracking-description = Bez sledovacích prvků nemusí některá tlačítka, formuláře a přihlašovací pole správně fungovat.
trustpanel-insecure-section-header = Vaše spojení není zabezpečené
trustpanel-insecure-description = Údaje odesílané na tento server nejsou šifrovány. Mohou být prohlíženy, ukradeny nebo pozměněny.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } sledovací cookie třetí stran
        [few] { $count } sledovací cookies třetích stran
        [many] { $count } sledovacích cookies třetích stran
       *[other] { $count } sledovacích cookies třetích stran
    }
trustpanel-list-label-tracking-content = Sledující obsah
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } vytváření otisku prohlížeče
        [few] { $count } vytváření otisku prohlížeče
        [many] { $count } vytváření otisku prohlížeče
       *[other] { $count } vytváření otisku prohlížeče
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } sledovací prvek sociálních sítí
        [few] { $count } sledovací prvky sociálních sítí
        [many] { $count } sledovacích prvků sociálních sítí
       *[other] { $count } sledovacích prvků sociálních sítí
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } těžba kryptoměn
        [few] { $count } těžby kryptoměn
        [many] { $count } těžeb kryptoměn
       *[other] { $count } těžeb kryptoměn
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } zablokoval { $count } sledovací prvek sociálních sítí
        [few] { -brand-product-name } zablokoval { $count } sledovací prvky sociálních sítí
        [many] { -brand-product-name } zablokoval { $count } sledovacích prvků sociálních sítí
       *[other] { -brand-product-name } zablokoval { $count } sledovacích prvků sociálních sítí
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } povolil { $count } sledovací prvek sociálních sítí
        [few] { -brand-product-name } povolil { $count } sledovací prvky sociálních sítí
        [many] { -brand-product-name } povolil { $count } sledovacích prvků sociálních sítí
       *[other] { -brand-product-name } povolil { $count } sledovacích prvků sociálních sítí
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } zablokoval { $count } sledovací cookie třetí strany
        [few] { -brand-product-name } zablokoval { $count } sledovací cookies třetích stran
        [many] { -brand-product-name } zablokoval { $count } sledovacích cookies třetích stran
       *[other] { -brand-product-name } zablokoval { $count } sledovacích cookies třetích stran
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } povolil { $count } sledovací cookie třetí strany
        [few] { -brand-product-name } povolil { $count } sledovací cookies třetích stran
        [many] { -brand-product-name } povolil { $count } sledovacích cookies třetích stran
       *[other] { -brand-product-name } povolil { $count } sledovacích cookies třetích stran
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } zablokoval { $count } sledovací prvek
        [few] { -brand-product-name } zablokoval { $count } sledovací prvky
        [many] { -brand-product-name } zablokoval { $count } sledovacích prvků
       *[other] { -brand-product-name } zablokoval { $count } sledovacích prvků
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } povolil { $count } sledovací prvek
        [few] { -brand-product-name } povolil { $count } sledovací prvky
        [many] { -brand-product-name } povolil { $count } sledovacích prvků
       *[other] { -brand-product-name } povolil { $count } sledovacích prvků
    }
trustpanel-tracking-content-tab-list-header = Tyto weby se vás snaží sledovat:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } zablokoval { $count } vytváření otisku prohlížeče
        [few] { -brand-product-name } zablokoval { $count } vytváření otisku prohlížeče
        [many] { -brand-product-name } zablokoval { $count } vytváření otisku prohlížeče
       *[other] { -brand-product-name } zablokoval { $count } vytváření otisku prohlížeče
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } povolil { $count } vytváření otisku prohlížeče
        [few] { -brand-product-name } povolil { $count } vytváření otisku prohlížeče
        [many] { -brand-product-name } povolil { $count } vytváření otisku prohlížeče
       *[other] { -brand-product-name } povolil { $count } vytváření otisku prohlížeče
    }
trustpanel-fingerprinter-list-header = Tyto weby se snaží vytvořit otisk vašeho prohlížeče:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } zablokoval { $count } těžbu kryptoměn
        [few] { -brand-product-name } zablokoval { $count } těžby kryptoměn
        [many] { -brand-product-name } zablokoval { $count } těžeb kryptoměn
       *[other] { -brand-product-name } zablokoval { $count } těžeb kryptoměn
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } povolil { $count } těžbu kryptoměn
        [few] { -brand-product-name } povolil { $count } těžby kryptoměn
        [many] { -brand-product-name } povolil { $count } těžeb kryptoměn
       *[other] { -brand-product-name } povolil { $count } těžeb kryptoměn
    }
trustpanel-cryptominer-tab-list-header = Tyto weby se pokouší o těžbu kryptoměn:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Máte účet na této stránce?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } zjistil, že na této stránce došlo v posledních 12 měsících k úniku dat. Zjistěte, zda se vás to týká.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Zavřít
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Spustit bezplatné skenování
trustpanel-blocker-section-header2 =
    { $count ->
        [one] Na této stránce je zablokovaný <span data-l10n-name="count">{ $count }</span> sledovací prvek
        [few] Na této stránce jsou zablokovány <span data-l10n-name="count">{ $count }</span> sledovací prvky
        [many] Na této stránce je zablokováno <span data-l10n-name="count">{ $count }</span> sledovacích prvků
       *[other] Na této stránce je zablokováno <span data-l10n-name="count">{ $count }</span> sledovacích prvků
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Vypadá stránka nefunkčně?</strong> Obnovte stránku, abyste dočasně snížili úroveň ochrany proti sledování.
reduced-protection-infobar-reload-button = Obnovit
    .accesskey = O
reduced-protection-infobar-never-show-button = Příště už nezobrazovat
    .accesskey = n


identity-allow-site-data = Vždy ukládat soubory cookie a data pro tento web
urlbar-webgl-notification-anchor =
    .tooltiptext = Spravovat oprávnění k vytváření kontextů WebGL
urlbar-webgl-blocked =
    .tooltiptext = Zablokovali jste vytváření kontextů WebGL pro tento web.
