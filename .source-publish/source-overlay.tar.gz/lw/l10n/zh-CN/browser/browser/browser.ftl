# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } 隐私浏览
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = 浏览快如风，隐私断跟踪
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — 隐私浏览
       *[other] { -brand-full-name } 隐私浏览
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = 隐私浏览
popups-infobar-dont-show-message2 =
    .label = 弹出式窗口或第三方重定向被拦截时不再显示此消息
    .accesskey = D
edit-popup-settings2 =
    .label = 管理弹出式窗口和第三方重定向设置…
    .accesskey = M
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] 查看网站信息
            [1] 查看网站信息（已拦截 1 个跟踪器）
           *[other] 查看网站信息（已拦截 { $count } 个跟踪器）
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = { $count } 个链接
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = 隔空投送、信息等…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = 信息、邮件等…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = 共享…
    .accesskey = h
urlbar-identity-button =
    .aria-label = 查看网站信息

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = 打开安装消息面板
urlbar-web-notification-anchor =
    .tooltiptext = 更改您是否接收该网站发来的通知
urlbar-midi-notification-anchor =
    .tooltiptext = 打开 MIDI 面板
urlbar-serial-notification-anchor =
    .tooltiptext = 打开串行端口面板
urlbar-eme-notification-anchor =
    .tooltiptext = 管理 DRM 软件使用
urlbar-web-authn-anchor =
    .tooltiptext = 打开 Web 认证面板
urlbar-canvas-notification-anchor =
    .tooltiptext = 管理 Canvas 获取权限
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = 管理您是否与该网站共享麦克风
urlbar-default-notification-anchor =
    .tooltiptext = 打开消息面板
urlbar-geolocation-notification-anchor =
    .tooltiptext = 打开位置请求面板
urlbar-localhost-notification-anchor =
    .tooltiptext = 管理此网站的本地设备访问权限
urlbar-local-network-notification-anchor =
    .tooltiptext = 管理是否与此网站共享本地网络访问
urlbar-xr-notification-anchor =
    .tooltiptext = 打开虚拟现实权限面板
urlbar-storage-access-anchor =
    .tooltiptext = 打开上网活动权限面板
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = 管理您是否与该网站共享窗口或屏幕
urlbar-indexed-db-notification-anchor =
    .tooltiptext = 打开离线存储消息面板
urlbar-password-notification-anchor =
    .tooltiptext = 打开保存密码消息面板
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = 管理您是否与该网站共享摄像头和麦克风
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = 管理是否要与网站共享音频输出设备
urlbar-autoplay-notification-anchor =
    .tooltiptext = 打开自动播放面板
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = 在持久存储中存储数据
urlbar-addons-notification-anchor =
    .tooltiptext = 打开附加组件安装消息面板
urlbar-search-tips-confirm = 好的，明白了
urlbar-search-tips-confirm-short = 知道了
urlbar-result-menu-button =
    .title = 打开菜单
urlbar-result-menu-button-feedback = 意见反馈
    .title = 打开菜单
urlbar-result-menu-learn-more2 = 详细了解
    .accesskey = L
urlbar-result-menu-remove-from-history2 = 从历史记录移除
    .accesskey = R
urlbar-result-menu-tip-get-help2 = 获取帮助
    .accesskey = h
urlbar-result-menu-dismiss-suggestion2 = 忽略此建议
    .accesskey = D
urlbar-result-menu-remove-top-site = 移除此常用网站
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = 管理 { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = 报告位置不准确
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = 减少显示
    .accesskey = f
urlbar-result-menu-dont-show-weather-suggestions3 = 不再显示天气建议
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = 报告位置不准确
urlbar-result-menu-show-less-frequently2 = 减少显示
urlbar-result-menu-dont-show-weather-suggestions2 = 不再显示天气建议
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = 忽略此建议 (i)
    .accesskey = i
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = 从历史记录中移除
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = 详细了解
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = 从历史记录移除
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = 获取帮助
    .accesskey = h
urlbar-result-menu-dismiss-suggestion =
    .label = 忽略此建议
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = 管理 { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = 报告位置不准确
urlbar-result-menu-show-less-frequently =
    .label = 减少显示
urlbar-result-menu-dont-show-weather-suggestions =
    .label = 不再显示天气建议
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = 打开菜单
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = 感谢反馈
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = 感谢反馈，天气建议将不再显示。

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = 输入寥寥，搜遍万千：在地址栏就能用 { $engineName } 搜索。
urlbar-search-tips-redirect-2 = 在地址栏搜索，可以看到 { $engineName } 提供的建议，还有您的相关浏览历史。
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = 一键直达，高效搜索。

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = 书签
urlbar-search-mode-tabs = 标签页
urlbar-search-mode-history = 历史记录
urlbar-search-mode-actions = 操作

##

urlbar-geolocation-blocked =
    .tooltiptext = 您已阻止此网站获取位置信息。
urlbar-localhost-blocked =
    .tooltiptext = 您已阻止此网站连接本地设备。
urlbar-local-network-blocked =
    .tooltiptext = 您已阻止此网站连接本地网络。
urlbar-xr-blocked =
    .tooltiptext = 您已阻止此网站使用虚拟现实设备。
urlbar-web-notifications-blocked =
    .tooltiptext = 您已阻止此网站发送通知。
urlbar-camera-blocked =
    .tooltiptext = 您已阻止此网站使用您的摄像头。
urlbar-microphone-blocked =
    .tooltiptext = 您已阻止此网站使用您的麦克风。
urlbar-screen-blocked =
    .tooltiptext = 您已阻止此网站共享您的屏幕。
urlbar-persistent-storage-blocked =
    .tooltiptext = 您已阻止此网站使用持久存储。
urlbar-popup-blocked2 =
    .tooltiptext = 您已拦截此网站的弹出式窗口和第三方重定向。
urlbar-autoplay-media-blocked =
    .tooltiptext = 您已阻止此网站自动播放有声媒体内容。
urlbar-canvas-blocked =
    .tooltiptext = 您已禁止此网站获取 Canvas 数据。
urlbar-midi-blocked =
    .tooltiptext = 您已阻止此网站访问 MIDI。
urlbar-serial-blocked =
    .tooltiptext = 您已阻止此网站访问串行端口。
urlbar-install-blocked =
    .tooltiptext = 您已阻止此网站安装附加组件。
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = 编辑此书签 ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = 为此页面添加书签 ({ $shortcut })
urlbar-split-view-button =
    .aria-label = 分屏视图
    .tooltiptext = 分屏视图

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = 粘贴并前往
    .accesskey = G
urlbar-menuitem-paste-and-search =
    .label = 粘贴并搜索
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = 清空搜索历史
    .accesskey = H

## Page Action Context Menu

page-action-manage-extension2 =
    .label = 管理扩展…
    .accesskey = E
page-action-remove-extension2 =
    .label = 移除扩展
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = 隐藏工具栏
    .accesskey = H
full-screen-exit =
    .label = 退出全屏模式
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = 本次搜索使用：
search-one-offs-change-settings-compact-button =
    .tooltiptext = 更改搜索设置
search-one-offs-context-open-new-tab =
    .label = 在新标签页中搜索
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = 设为默认搜索引擎
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = 设为隐私窗口的默认搜索引擎
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName }（{ $alias }）
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = 添加搜索引擎“{ $engineName }”
    .label = 添加“{ $engineName }”
    .tooltiptext = 添加搜索引擎“{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = 添加搜索引擎
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = 添加搜索引擎

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = 书签（{ $restrict }）
search-one-offs-tabs =
    .tooltiptext = 标签页（{ $restrict }）
search-one-offs-history =
    .tooltiptext = 历史记录（{ $restrict }）
search-one-offs-actions =
    .tooltiptext = 操作（{ $restrict }）

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = 查看附加组件
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = 扩展, 主题, 附加组件, extensions, themes, addons, add-ons
# Opens preferences page at AI controls
quickactions-manageai = 管理 AI 控制
quickactions-cmd-manageai = 禁用 ai, 关闭 ai, 管理 ai, disable ai, off ai, manage ai
# Opens the bookmarks library window
quickactions-bookmarks2 = 管理书签
quickactions-cmd-bookmarks = 书签, bookmarks
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = 清除最近的历史记录
quickactions-cmd-clearrecenthistory2 = Cookie, 清除 Cookies, 缓存, 清除缓存, 浏览数据, 清除浏览数据, 历史, 历史记录, 清除最近历史, 清除最近历史记录, cookies, clear cookies, cache, clear cache, browsing data, clear browsing data, history, clear recent history
# Opens about:downloads page
quickactions-downloads2 = 查看下载
quickactions-cmd-downloads = 下载, downloads
# Opens about:addons page in the extensions section
quickactions-extensions = 管理扩展
quickactions-cmd-extensions2 = 扩展, 附加组件, 附加组件, extensions, addons, add-ons
# Opens Firefox View
quickactions-firefoxview = 打开 { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = 打开 { -firefoxview-brand-name }, { -firefoxview-brand-name }, 打开 view, view
# Opens SUMO home page
quickactions-help = { -brand-product-name } 帮助
quickactions-cmd-help = 帮助, 支持, help, support
# Opens the devtools web inspector
quickactions-inspector2 = 打开开发者工具
quickactions-cmd-inspector2 = 查看器, 开发者工具, inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = 取色
quickactions-cmd-colorpicker = 取色器, 拾色器, 吸管, 滴管, 选取颜色, color picker, eyedropper, pick color
# Opens Firefox Library
quickactions-cmd-library = 我的足迹, 足迹, library
quickactions-library = 打开“我的足迹”
# Opens about:logins
quickactions-logins2 = 管理密码
quickactions-cmd-logins = 登录信息, 密码, logins, passwords
# Mutes all tabs playing audio
quickactions-mute = 静音正在播放音频的标签页
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = 静音, 关闭声音, mute, shush, sssssh
# Opens the print dialog
quickactions-print2 = 打印页面
quickactions-cmd-print = 打印, print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = 另存页面为 PDF
quickactions-cmd-savepdf2 = pdf, 保存页面, save page
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = 打开 PDF 编辑器
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = 打开隐私窗口
quickactions-cmd-private = 隐私浏览, private browsing
# Opens a SUMO article explaining how to refresh
quickactions-refresh = 翻新 { -brand-short-name }
quickactions-cmd-refresh = 刷新, refresh
# Restarts the browser
quickactions-restart = 重启 { -brand-short-name }
quickactions-cmd-restart = 重新启动, 重启, restart
# Opens the screenshot tool
quickactions-screenshot3 = 截图
quickactions-cmd-screenshot2 = 截图, 截屏, 屏幕截图, screenshot, take a screenshot
# Opens about:translations
quickactions-translate = 翻译
quickactions-cmd-translate = 翻译, translate
# Opens about:preferences
quickactions-settings2 = 管理设置
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = 设置, 首选项, 偏好设置, 偏好, 选项, 管理, settings, preferences, options, manage
# Opens about:addons page in the themes section
quickactions-themes = 管理主题
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = 主题, 附加组件, 附加组件, themes, add-ons, addons
# Opens a SUMO article explaining how to update the browser
quickactions-update = 更新 { -brand-short-name }
quickactions-cmd-update = 更新, update
# Opens the view-source UI with current pages source
quickactions-viewsource2 = 查看页面源代码
quickactions-cmd-viewsource2 = 查看源代码, 源代码, 页面源代码, 查看源码, 源码, 页面源码, view source, source, page source
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = 打开 { -firefoxlabs-brand-name }
quickactions-cmd-labs = 实验室, 实验, labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = 详细了解“快捷操作”
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = 按 Tab 键选择：

## Bookmark Panel

bookmarks-add-bookmark = 新建书签
bookmarks-edit-bookmark = 编辑书签
bookmark-panel-cancel =
    .label = 取消
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label = 移除 { $count } 个书签
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = 保存时显示编辑器
    .accesskey = S
bookmark-panel-save-button2 =
    .label = 保存
    .accesskey = a
bookmark-panel-save-button =
    .label = 保存
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = 网站信息：{ $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = 连接安全性：{ $host }
identity-connection-not-secure = 不安全连接
identity-connection-secure = 安全连接
identity-connection-failure = 连接失败
identity-connection-internal = 这是安全的 { -brand-short-name } 页面。
identity-connection-file = 此页面存储在您的计算机上。
identity-connection-associated = 此页面加载自另一页面。
identity-extension-page = 此页面是扩展页面。
identity-active-blocked = { -brand-short-name } 已拦截此页面上不安全的内容。
identity-custom-root = 连接由 Mozilla 不认可的证书颁发者所验证。
identity-passive-loaded = 此页面上部分内容不安全（例如图像）。
identity-active-loaded = 您在此页面上已禁用保护。
identity-weak-encryption = 此页面使用较弱加密。
identity-https-only-connection-upgraded = （升级为 HTTPS）
identity-https-only-label2 = 自动将此网站的连接升级为安全连接
identity-https-only-dropdown-on =
    .label = 开启
identity-https-only-dropdown-off =
    .label = 关闭
identity-https-only-dropdown-off-temporarily =
    .label = 暂时关闭
identity-https-only-info-turn-on3 = 若想要 { -brand-short-name } 尽可能升级为安全连接，请为此网站开启“升级为 HTTPS”。
identity-https-only-info-turn-off3 = 如果页面看起来不正常，则可能需要为此网站关闭“升级为 HTTPS”，使用不安全的 HTTP 重新加载。
identity-https-only-info-no-upgrade = 无法将网站连接从 HTTP 升级。
identity-permissions-storage-access-header = 跨站 Cookie
identity-permissions-storage-access-hint = 当您在此网站上时，以下各方可以使用跨站 Cookie 和网站数据。
identity-permissions-storage-access-learn-more = 详细了解
identity-permissions-reload-hint = 您可能需要重新加载此页面以应用更改。
identity-clear-site-data =
    .label = 清除 Cookie 和网站数据…
identity-connection-not-secure-security-view = 您并未安全地连接至此网站。
identity-connection-verified = 您已安全地连接至此网站。
identity-ev-owner-label2 = 证书颁发给
identity-verifier-label2 = 验证者：
identity-ev-owner-label = 证书颁发给：
identity-verifier-label = 验证者：
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = 符合 (EU) 2024/1183 法规规范。
identity-description-custom-root2 = Mozilla 不认识此证书颁发者。它可能是由您的操作系统或管理员身份添加。
identity-cert-exception-overridden = 您已将此网站加入安全例外。
identity-remove-cert-exception =
    .label = 移除例外
    .accesskey = R
identity-description-insecure = 您至此网站的连接非私密。您提交的信息可能被其他人看到（例如密码、邮件、信用卡等）。
identity-description-weak-cipher-intro = 您与此网站的连接使用了较弱的加密，并不私密。
identity-description-weak-cipher-risk = 其他人可能查看您的信息或修改该网站的行为。
identity-description-active-blocked2 = { -brand-short-name } 已拦截此页面上不安全的内容。
identity-description-passive-loaded = 您的连接并不私密，您提供给此网站的信息可能会被其他人看到。
identity-description-passive-loaded-insecure2 = 此网站包含不安全的内容（例如图像）。
identity-description-passive-loaded-mixed2 = 尽管 { -brand-short-name } 已拦截部分内容，但页面上仍有内容不安全（例如图像）。
identity-description-active-loaded = 此网站包含不安全内容（例如脚本），并且您至它的连接非私密。
identity-description-active-loaded-insecure = 您提供给此网站的信息（例如密码、聊天消息、信用卡等）可能会被其他人看到。
identity-description-tls-key-logging-heading = 您的连接可能不私密
identity-description-tls-key-logging-message = 其他应用或服务可能可以看到您来自此网站的加密流量。
identity-more-info-link-text =
    .label = 更多信息

## Window controls

browser-window-minimize-button =
    .tooltiptext = 最小化
browser-window-maximize-button =
    .tooltiptext = 最大化
browser-window-restore-down-button =
    .tooltiptext = 向下还原
browser-window-close-button =
    .tooltiptext = 关闭
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = 返回

## Bookmarks toolbar items

browser-import-button2 =
    .label = 导入书签…
    .tooltiptext = 将其他浏览器的书签导入到 { -brand-short-name }。
bookmarks-toolbar-empty-message = 可将书签放在书签工具栏上，方便快速访问。<a data-l10n-name="manage-bookmarks">管理书签…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = 摄像头：
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = 摄像头
popup-select-microphone-device =
    .value = 麦克风：
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = 麦克风
popup-select-speaker-icon =
    .tooltiptext = 音频输出设备
popup-select-window-or-screen =
    .label = 窗口或屏幕：
    .accesskey = W
popup-all-windows-shared = 您的屏幕上的所有可见窗口都将被共享。

## WebRTC window or screen share tab switch warning

sharing-warning-window = 您正在共享 { -brand-short-name }。当切换到新标签页时，其他人可以看到。
sharing-warning-screen = 您正在共享完整屏幕。当切换到新标签页时，其他人可以看到。
sharing-warning-proceed-to-tab =
    .label = 继续前往标签页
sharing-warning-disable-for-session =
    .label = 在本次会话期间禁用共享保护

## WebSerial "select a port" popup

webserial-select-port-label = 选择串行端口：
webserial-no-ports-available = 无可用串行端口

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = 关闭
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = 搜索或输入网址
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = 输入地址
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = 使用 { $name } 搜索
    .placeholder = 网上搜索
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = 搜索 { $name }
    .placeholder = 输入搜索词
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = 搜索书签
    .placeholder = 输入搜索词
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = 搜索历史记录
    .placeholder = 输入搜索词
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = 搜索标签页
    .placeholder = 输入搜索词
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = 搜索操作
    .placeholder = 输入搜索词
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = 使用 { $name } 搜索，或者输入网址
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = 浏览器受到远程控制（原因：{ $component }）
urlbar-permissions-granted =
    .tooltiptext = 您已授予此网站更多权限。
urlbar-switch-to-tab =
    .value = 切换到标签页：
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = 扩展：
urlbar-go-button2 =
    .title = 转到地址栏中指向的网址
urlbar-page-action-button =
    .tooltiptext = 页面操作
urlbar-revert-button =
    .tooltiptext = 在地址栏中显示网址

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = 在隐私窗口中用 { $engine } 搜索
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = 在隐私窗口中搜索
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = 使用 { $engine } 搜索
urlbar-result-action-sponsored = 赞助推广
urlbar-result-action-switch-tab = 切换到标签页
urlbar-result-action-move-tab-to-split-view = 将标签页移动到分屏
urlbar-result-action-visit = 访问
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = 切换到标签页 · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = 未命名群组
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = 访问剪贴板中的网址
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = 按 Tab 键 { $engine } 一下
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = 按 Tab 键在 { $engine } 上搜索
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = 直接从地址栏 { $engine } 一下
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = 直接从地址栏在 { $engine } 上搜索
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = 复制
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = 未定义
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } 扩展
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = 推荐
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> — { $region } { $city }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> — { $country } { $region } { $city }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> — { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · 赞助
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = 询问
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = 上次访问：{ $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days = 上次访问于 { $daysAgo } 天前
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks = 上次访问于 { $weeksAgo } 周前
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months = 上次访问于 { $monthsAgo } 个月前
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = 上次访问于 { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = 书签添加于 { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = 上次访问：{ $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = 上次访问：{ $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = 上次访问：{ $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = 直接通过搜索栏掌握股市数据
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = 与 { -vendor-short-name } 共享您的搜索查询数据，获取由我们的合作伙伴提供的市场资讯等信息。<a data-l10n-name="learn-more-link">详细了解</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = 显示建议
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = 暂时不要
urlbar-result-realtime-opt-in-dismiss = 知道了
urlbar-result-realtime-opt-in-dismiss-all2 = 不再显示此类建议
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = 不再显示市场建议
    .accesskey = n
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = 不再显示市场建议
urlbar-result-realtime-opt-in-dismiss-all =
    .label = 不再显示此类建议
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = 不再显示市场建议
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = 感谢反馈，市场建议将不再显示。
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = “股市”建议
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = 感谢反馈，此类建议将不再显示。

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown = { $name } · { $daysUntilStart } 天后
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range = { $name } · { $daysUntilStart } 天后开始
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing = { $name } · { $daysUntilEnd } 天后结束
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · 今天
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · 今天结束

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = 使用 { $engine } 搜索
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - 搜索{ $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - 使用 { $engine } 搜索
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }，选取搜索引擎
urlbar-searchmode-button-no-engine2 =
    .title = 未选择快捷方式，请选择
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = 关键词搜索已禁用
urlbar-searchmode-dropmarker2 =
    .title = 选取搜索引擎
urlbar-searchmode-bookmarks4 = 书签
urlbar-searchmode-tabs4 = 标签页
urlbar-searchmode-history4 = 历史记录
urlbar-searchmode-actions4 = 操作
urlbar-searchmode-bookmarks3 = 书签
    .accesskey = B
urlbar-searchmode-tabs3 = 标签页
    .accesskey = T
urlbar-searchmode-history3 = 历史记录
    .accesskey = H
urlbar-searchmode-actions3 = 操作
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = 关闭
urlbar-searchmode-default2 =
    .title = 默认搜索引擎
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = 添加“{ $engineName }”
    .title = 添加搜索引擎“{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = 本次搜索使用：
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = 搜索引擎：
urlbar-searchmode-popup-search-settings2 = 搜索设置
urlbar-searchmode-popup-settings2 = 设置
urlbar-searchmode-popup-search-settings = 搜索设置
    .accesskey = S
urlbar-searchmode-popup-settings = 设置
    .accesskey = S

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = 搜索书签
urlbar-result-action-search-history = 搜索历史记录
urlbar-result-action-search-tabs = 搜索标签页
urlbar-result-action-search-actions = 搜索操作
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = 切换到“{ $group }”
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = 打开“{ $group }”

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = 新建标签页打开
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = 新建身份标签页打开
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = 新建窗口打开
    .accesskey = N
urlbar-view-context-menu-open-in-private-window =
    .label = 新建隐私窗口打开
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = 新建标签页打开
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = 新建身份标签页打开
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = 新建窗口打开
    .accesskey = N
urlbar-view-context-menu-open-in-private-window2 = 新建隐私窗口打开
    .accesskey = P
urlbar-view-context-menu-search-in-tab = 新建新标签页搜索
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = 新建身份标签页搜索
    .accesskey = i
urlbar-view-context-menu-search-in-window = 新建窗口搜索
    .accesskey = N
urlbar-view-context-menu-search-in-private-window = 新建隐私窗口搜索
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = 使用 Tab 键时跳过此菜单
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } 建议
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = 快捷操作
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = 近期搜索
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } 热门搜索
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = 不再显示热门搜索
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = 不再显示热门搜索
    .accesskey = D
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = 不再显示热门搜索
    .accesskey = D
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = 感谢反馈，热门搜索将不再显示。

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = 进入阅读模式
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = 关闭阅读模式

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = 打开画中画 ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = 关闭画中画 ({ $shortcut })
picture-in-picture-panel-header = 画中画
picture-in-picture-panel-headline = 不推荐在此网站使用画中画
picture-in-picture-panel-body = 开启画中画后，视频可能会不按开发者预期的效果显示。
picture-in-picture-enable-toggle =
    .label = 仍要启用

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 已进入全屏模式
fullscreen-warning-no-domain = 此文档已进入全屏模式
fullscreen-exit-button = 退出全屏模式 (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = 退出全屏模式 (esc)
fullscreen-keyboardlock-exit-button = 退出全屏（长按 Esc）
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = 退出全屏（长按 Esc）
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 已控制您的鼠标指针。按 Esc 键可收回控制权。
pointerlock-warning-no-domain = 此文档已控制您的鼠标指针。按 Esc 键可收回控制权。

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = 管理书签
bookmarks-recent-bookmarks-panel-subheader = 最近的书签
bookmarks-toolbar-chevron =
    .tooltiptext = 显示更多书签
bookmarks-sidebar-content =
    .aria-label = 书签
bookmarks-menu-button =
    .label = 书签菜单
bookmarks-other-bookmarks-menu =
    .label = 其他书签
bookmarks-mobile-bookmarks-menu =
    .label = 移动设备上的书签

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] 隐藏书签侧栏
           *[other] 显示书签侧栏
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] 隐藏书签工具栏
           *[other] 查看书签工具栏
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] 隐藏书签工具栏
           *[other] 显示书签工具栏
        }

##

bookmarks-search =
    .label = 搜索书签
bookmarks-tools =
    .label = 书签工具
bookmarks-subview-edit-bookmark =
    .label = 编辑此书签…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = 书签
    .toolbarname = 书签工具栏
    .accesskey = B
bookmarks-toolbar-menu =
    .label = 书签工具栏
bookmarks-toolbar-placeholder =
    .title = 书签工具栏项目
bookmarks-toolbar-placeholder-button =
    .label = 书签工具栏项目
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = 为当前标签页添加书签…

## Library Panel items

library-bookmarks-menu =
    .label = 书签

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = 修复文字编码
    .tooltiptext = 根据页面内容猜测正确的文字编码

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = 设置
    .tooltiptext =
        { PLATFORM() ->
            [macos] 打开设置（{ $shortcut }）
           *[other] 打开设置
        }
toolbar-overflow-customize-button =
    .label = 定制工具栏…
    .accesskey = C
toolbar-button-email-link =
    .label = 用邮件发送链接
    .tooltiptext = 用邮件发送此页链接
toolbar-button-logins =
    .label = 密码
    .tooltiptext = 查看并管理您存放的密码
qrcode-panel-error =
    .message = 生成二维码失败，请重试。
qrcode-copy-button =
    .label = 复制
qrcode-copy-success =
    .message = 二维码已复制到剪贴板。
qrcode-copy-error =
    .message = 复制二维码失败。
qrcode-save-button =
    .label = 保存
qrcode-window-title = 二维码
qrcode-dialog-title = 二维码
qrcode-image =
    .aria-label = 二维码
qrcode-close-button =
    .aria-label = 关闭
toolbar-button-save-page =
    .label = 保存页面
    .tooltiptext = 保存此页 ({ $shortcut })
toolbar-button-open-file =
    .label = 打开文件
    .tooltiptext = 打开文件 ({ $shortcut })
toolbar-button-synced-tabs =
    .label = 同步的标签页
    .tooltiptext = 显示来自其他设备的标签页
toolbar-button-send-tab =
    .label = 发送标签页
    .tooltiptext = 发送当前标签页到其他设备
toolbar-button-new-private-window =
    .label = 新建隐私窗口
    .tooltiptext = 新建一个隐私浏览窗口 ({ $shortcut })
toolbar-button-share-tab =
    .label = 共享
    .tooltiptext = 共享此页面
toolbar-button-tab-groups =
    .label = 标签页群组
    .tooltiptext = 显示标签页群组
toolbar-button-history =
    .label = 历史记录
    .tooltiptext = 显示您的历史记录（{ $shortcut }）
toolbar-button-find =
    .label = 查找
    .tooltiptext = 在此页面中查找 ({ $shortcut })
toolbar-button-developer =
    .label = 开发者
    .tooltiptext = 打开 Web 开发者工具 ({ $shortcut })
toolbar-button-forget =
    .label = 抹去足迹
    .tooltiptext = 抹去某些浏览历史
toolbar-zoom-controls =
    .label = 缩放控制
    .title = 缩放控制
toolbar-button-zoom-out =
    .label = 缩小
    .tooltiptext = 缩小 ({ $shortcut })
toolbar-button-zoom-reset-tooltip = 重置缩放 ({ $shortcut })
toolbar-button-zoom-in =
    .label = 放大
    .tooltiptext = 放大 ({ $shortcut })
toolbar-edit-controls =
    .label = 编辑控制
    .title = 编辑控制
toolbar-button-cut =
    .label = 剪切
    .tooltiptext = 剪切 ({ $shortcut })
toolbar-button-copy =
    .label = 复制
    .tooltiptext = 复制 ({ $shortcut })
toolbar-button-paste =
    .label = 粘贴
    .tooltiptext = 粘贴 ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = 二维码-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = 此网站的一些音频或视频使用了含数字版权管理（DRM）的软件，这可能会限制 { -brand-short-name } 能让您使用的功能。
eme-notifications-drm-content-playing-manage = 管理设置
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = 知道了
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = 您必须启用 DRM 才能播放此页面上的某些音频或视频。
eme-notifications-drm-content-disabled-button =
    .label = 启用数字版权管理（DRM）
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } 正在安装组件，以便播放此页面上的音频或视频。请稍后再试。
decoder-doctor-no-codecs-linux-message = 为了播放视频，您可能需要安装所需的视频编解码器。
decoder-doctor-no-hw-acceleration-message = 为了改善视频质量，您可能需要安装 Microsoft 的“媒体功能包”（Media Feature Pack）。
decoder-doctor-no-pulse-audio-message = 要播放音频，您可能需要安装必需的 PulseAudio 软件。
decoder-doctor-unsupported-libavcodec-message = libavcodec 可能存在安全隐患或已不再支持，应当被更新以播放视频。
decoder-doctor-decode-error-message = 解码媒体资源时发生错误。
decoder-doctor-decode-warning-message = 解码媒体资源时发生可恢复的错误。
decoder-doctor-learn-how-link = 了解如何运行
decoder-doctor-report-issue-button =
    .label = 反馈网站问题
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = 插件 { $pluginName } 已崩溃。
plugin-crashed-notification-reload-button =
    .label = 重新加载页面
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = 提交崩溃报告
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = 诈骗网站！
safebrowsing-reported-attack-site-message = 此页面据举报有攻击行为！
safebrowsing-reported-unwanted-site-message = 此网站被举报提供流氓软件！
safebrowsing-reported-harmful-site-message = 举报恶意网站！
safebrowsing-get-me-out-of-here-button =
    .label = 带我离开！
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = 这不是诈骗网站…
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = 这不是一个有害网站…
    .accesskey = a

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = 您必须先登录此网络才能访问互联网。
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = 打开网络登录页面

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = 您是要访问 { $hostName } 吗？
keyword-uri-fixup-go-to-button =
    .label = 是，带我前往 { $hostName }
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = 用户名
panel-save-update-password-2 =
    .label = 密码

##

# "More" item in macOS share menu
menu-share-more =
    .label = 更多…
menu-share-windows =
    .label = 更多选项
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label = 复制 { $count } 个链接
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = 关闭

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = 允许 { $uriHost } 的弹出式窗口和第三方重定向
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = 隐藏画中画切换按钮
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = 右移画中画切换按钮
    .accesskey = R
picture-in-picture-move-toggle-left =
    .label = 左移画中画切换按钮
    .accesskey = L

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = 导航
navbar-downloads =
    .label = 下载
navbar-overflow-2 =
    .tooltiptext = 更多工具
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = 打印
    .tooltiptext = 打印此页… ({ $shortcut })
navbar-home =
    .label = 主页
    .tooltiptext = { -brand-short-name } 主页
navbar-library =
    .label = 我的足迹
    .tooltiptext = 查看浏览历史、已保存的书签等
navbar-search =
    .title = 搜索
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = 浏览器标签页
tabs-toolbar-new-tab =
    .label = 新建标签页
tabs-toolbar-list-all-tabs-2 =
    .label = 搜索和管理标签页
    .tooltiptext = 搜索和管理标签页
tabs-toolbar-list-all-tabs =
    .label = 列出所有标签页
    .tooltiptext = 列出所有标签页

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = 将标签页拖到此处以固定

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>想打开先前的标签页？</strong>您可以从 { -brand-short-name } 应用程序菜单 <img data-l10n-name="icon"/> 中的“历史”恢复先前的浏览状态。
restore-session-startup-suggestion-button = 怎么做

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = 您的组织已阻止此计算机访问本地文件

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } 现用于搜索标签页
urlbar-addons-shortcut-moved-description = 若要打开扩展和主题，请使用 { $addonsShortcut }。
urlbar-addons-shortcut-moved-change-shortcuts = 管理快捷方式
urlbar-addons-shortcut-moved-dismiss = 知道了

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } 会自动向 { -vendor-short-name } 反馈一些数据，以便我们改善您的使用体验。
data-reporting-notification-button =
    .label = 我要选择提供哪些信息
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = 隐私浏览
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = 隐私浏览
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = 隐私浏览信息
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = 您已进入隐私窗口
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = 此功能可以让使用此设备的其他人无法得知您的浏览活动，但并不能让您在网络上隐身。<a data-l10n-name="learn-more">谁可以看到我的活动？</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = 由“{ $agentName }”提供数据泄露防护。点击以了解更多信息。
content-analysis-panel-title2 = 数据泄露防护
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = 您的组织使用 <b>{ $agentName }</b> 管控敏感数据的共享方式。<a data-l10n-name="info">详细了解</a>
content-analysis-panel-title = 数据保护
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = 您的组织使用 <b>{ $agentName }</b> 进行数据泄露防护。<a data-l10n-name="info">详细了解</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = 扩展
    .tooltiptext = 扩展

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = 扩展
    .tooltiptext = 扩展所需权限

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = 扩展
    .tooltiptext =
        扩展
        已禁用部分扩展

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = 扩展
    .tooltiptext =
        扩展
        部分扩展已被禁用

## Private browsing reset button

reset-pbm-panel-heading2 = 确定要清除数据并开始新的隐私浏览吗？
reset-pbm-panel-description3 = 这将清除历史记录和 Cookie，并退出网站登录。隐私窗口将关闭，同时开始新的隐私浏览。
reset-pbm-panel-description2 = 这将删除历史记录、Cookie 以及其他所有网站数据，但不关闭隐私窗口。
reset-pbm-panel-always-ask-checkbox =
    .label = 总是询问
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = 取消
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = 清除本次隐私浏览
    .accesskey = l
reset-pbm-panel-complete = 本次隐私浏览数据已删除
reset-pbm-toolbar-button2 =
    .label = 清除本次隐私浏览
    .tooltiptext = 清除本次隐私浏览

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = 确定要删除所有浏览数据吗？
fire-button-panel-description = 这将删除历史记录、Cookie 和网站数据，并退出网站登录。本窗口将关闭，然后 { -brand-short-name } 会打开新窗口。
fire-button-panel-choose-description = 若不想全部删除，也可选择要删除的数据。
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = 选择…
fire-button-panel-cancel-button =
    .label = 取消
    .accesskey = C
fire-button-panel-confirm-button =
    .label = 全部删除
    .accesskey = D
fire-button-panel-complete = 浏览数据已删除
fire-button-toolbar-button2 =
    .label = 删除部分或所有数据
    .tooltiptext = 删除部分或所有浏览数据

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } 阻止了此页面自动重新加载。
refresh-blocked-redirect-label = { -brand-short-name } 阻止了此页面自动重定向至其他页面。
refresh-blocked-allow =
    .label = 允许
    .accesskey = A

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = 我们安全易用的马甲邮箱可隐藏您的邮件地址，帮助您保护身份信息、防止垃圾邮件侵扰。
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = 发送到马甲邮箱的所有电子邮件都将转发到 <strong>{ $useremail }</strong>（除非您选择拦截）。
firefox-relay-offer-legal-notice = 点击“使用马甲邮箱”，即表示您同意<label data-l10n-name="tos-url">服务条款</label>和<label data-l10n-name="privacy-url">隐私声明</label>。
firefox-relay-offer-legal-notice-1 = 注册和创建马甲邮箱，即表示您同意我们的<label data-l10n-name="tos-url">服务条款</label>和<label data-l10n-name="privacy-url">隐私声明</label>。

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = （未验证）
popup-notification-xpinstall-prompt-learn-more = 详细了解如何安全地安装附加组件
popup-notification-xpinstall-prompt-block-url = 查阅详情
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = 允许扩展在隐私窗口中运行
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = 与扩展开发者分享技术和交互数据
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message = { -brand-short-name } 阻止了此网站的 { $popupCount } 个弹窗。
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } 已阻止此网站重定向。
        [1] { -brand-short-name } 已阻止此网站打开弹出式窗口和重定向。
       *[other] { -brand-short-name } 已阻止此网站打开 { $popupCount } 个弹出式窗口和重定向。
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } 阻止了此网站打开超过 { $popupCount } 个弹出式窗口。
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message = { -brand-short-name } 已阻止此网站打开超过 { $popupCount } 个弹出式窗口和重定向。
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] 选项
           *[other] 首选项
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = 显示“{ $popupURI }”
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = 显示“{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = 无法打开 Windows 文件对话框，因此无法选择文件和文件夹。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = 无法打开 Windows 文件对话框，此文件将保存至 { $path }。
file-picker-failed-save-nowhere = 无法打开 Windows 文件对话框，且找不到默认文件夹，此文件将不会保存。
file-picker-crashed-open = Windows 文件对话框发生崩溃，无法选择文件和文件夹。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows 文件对话框发生崩溃，此文件将保存至 { $path }。
file-picker-crashed-save-nowhere = Windows 文件对话框发生崩溃，且找不到默认文件夹，此文件将不会保存。
file-picker-crashed-show-in-folder =
    .label = 在文件夹中显示
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = 某些已安装的附加组件未通过验证，现已被禁用。
unsigned-addons-disabled-learn-more =
    .label = 详细了解
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = 此网页拖慢了您的 { -brand-short-name }。可停止此页面，恢复浏览速度。
process-hang-nonspecific-tab-message = 有一网页拖慢了您的 { -brand-short-name }。可停止该页面，恢复浏览速度。
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }”拖慢了您的 { -brand-short-name }。可停止该页面，恢复浏览速度。
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }”拖慢了您的 { -brand-short-name }。可停止该扩展，恢复浏览速度。
process-hang-addon-learn-more =
    .value = 详细了解
process-hang-stop-button =
    .label = 停止
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = 完成设置
onboarding-aw-finish-setup-button =
    .label = 完成设置
    .tooltiptext = 完成对 { -brand-short-name } 的设置

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = 增强型跟踪保护已开启
trustpanel-etp-label-disabled = 增强型跟踪保护已关闭
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = 增强型跟踪保护：已对 { $host } 开启
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = 增强型跟踪保护：已对 { $host } 关闭
trustpanel-etp-description-enabled = 若网站功能异常，请尝试关闭保护。
trustpanel-etp-description-disabled = { -brand-product-name } 认为大公司应该减少对您的跟踪。开启保护功能后，我们将尽可能拦截跟踪器。
trustpanel-connection-label-secure = 连接安全
trustpanel-connection-label-insecure = 连接不安全
trustpanel-header-enabled = { -brand-product-name } 正在防护
trustpanel-description-enabled2 = 您已受保护。若发现异常，我们将提醒。
trustpanel-header-enabled-insecure = 谨慎使用此网站
trustpanel-description-enabled-insecure = { -brand-product-name } 发现可疑情况。
trustpanel-header-disabled = 您已关闭保护
trustpanel-description-disabled = { -brand-product-name } 已暂停保护，建议重新启用。
trustpanel-clear-cookies-button = 清除 Cookie 和网站数据
trustpanel-privacy-link = 隐私设置
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = 清除 { $host } 的 Cookie 和网站数据
trustpanel-clear-cookies-description = 移除 Cookie 和网站数据可能会导致网站退出登录或清空购物车。
trustpanel-clear-cookies-subview-button-clear = 清除
trustpanel-clear-cookies-subview-button-cancel = 取消
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = 连接保护：{ $host }
trustpanel-siteinformation-morelink = 更多网站信息
trustpanel-blocker-see-all = 查看全部
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = 跟踪保护：{ $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = 不安全
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label = 已拦截 { $count } 个跟踪器

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } 认为大公司应该减少对您的跟踪，所以我们会尽可能拦截跟踪项。
trustpanel-blocked-header = { -brand-product-name } 为您拦截了以下项目：
trustpanel-tracking-header = 为使网站正常运作，{ -brand-product-name } 已允许以下项目：
trustpanel-tracking-description = 拦截跟踪器可能会使某些按钮、表单、登录信息栏无法正常工作。
trustpanel-insecure-section-header = 您的连接不安全
trustpanel-insecure-description = 您发送到此网站的数据未加密，其可被查看、窃取、改动。
trustpanel-list-label-tracking-cookies = { $count } 个跨站跟踪性 Cookie
trustpanel-list-label-tracking-content = 跟踪性内容
trustpanel-list-label-fingerprinter = { $count } 个数字指纹跟踪程序
trustpanel-list-label-social-tracking = { $count } 个社交媒体跟踪器
trustpanel-list-label-cryptominer = { $count } 个加密货币挖矿程序
trustpanel-social-tracking-blocking-tab-header = { -brand-product-name } 已拦截 { $count } 个社交媒体跟踪器
trustpanel-social-tracking-not-blocking-tab-header = { -brand-product-name } 已允许 { $count } 个社交媒体跟踪器
trustpanel-tracking-cookies-blocking-tab-header = { -brand-product-name } 已拦截 { $count } 个跨站跟踪性 Cookie
trustpanel-tracking-cookies-not-blocking-tab-header = { -brand-product-name } 已允许 { $count } 个跨站跟踪性 Cookie
trustpanel-tracking-content-blocking-tab-header = { -brand-product-name } 已拦截 { $count } 个跟踪器
trustpanel-tracking-content-not-blocking-tab-header = { -brand-product-name } 已允许 { $count } 个跟踪器
trustpanel-tracking-content-tab-list-header = 这些网站正试图跟踪您：
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name } 已拦截 { $count } 个数字指纹跟踪程序
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name } 已允许 { $count } 个数字指纹跟踪程序
trustpanel-fingerprinter-list-header = 这些网站正试图跟踪您的数字指纹：
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name } 已拦截 { $count } 个加密货币挖矿程序
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name } 已允许 { $count } 个加密货币挖矿程序
trustpanel-cryptominer-tab-list-header = 这些网站正试图挖掘加密货币：
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = 在这个网站注册过账户吗？
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } 发现此网站在 12 个月内发生过数据外泄事件，请检查您是否受影响。
trustpanel-breachalerts-anonymous-breached-button-dismiss = 知道了
trustpanel-breachalerts-anonymous-breached-button-check-monitor = 开始免费扫描
trustpanel-blocker-section-header2 = 已在此网站上拦截 <span data-l10n-name="count">{ $count }</span> 个跟踪器

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>网站功能异常？</strong>重新加载页面以暂时降低跟踪保护等级。
reduced-protection-infobar-reload-button = 重新加载
    .accesskey = R
reduced-protection-infobar-never-show-button = 不再显示
    .accesskey = D


identity-allow-site-data = 始终为本网站存储 cookie/数据
urlbar-webgl-notification-anchor =
    .tooltiptext = 管理WebGL上下文创建权限
urlbar-webgl-blocked =
    .tooltiptext = 您已阻止此网站创建WebGL上下文。
