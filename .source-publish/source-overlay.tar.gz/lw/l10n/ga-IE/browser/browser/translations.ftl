# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.



translations-panel-disable-translations =
    .label = Díchumasaigh aistriúcháin go hiomlán
translations-manage-enable =
    .label = Cumasaigh aistriúcháin lánleathanach
translations-manage-autopopup =
    .label = Leid chun leathanaigh nach bhfuil i dteanga cumraithe an bhrabhsálaí a aistriú
