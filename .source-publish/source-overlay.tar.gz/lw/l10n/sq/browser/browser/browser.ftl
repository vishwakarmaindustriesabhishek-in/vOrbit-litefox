# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = Shfletim Privat { -brand-shortcut-name }
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Shfletim i shpejtë dhe privat
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Shfletim Privat
       *[other] Shfletim Privat { -brand-full-name }
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Shfletim Privat
popups-infobar-dont-show-message2 =
    .label = Mos e shfaq këtë mesazh, kur bllokohen flluska, ose ridrejtime nga palë të treta
    .accesskey = M
edit-popup-settings2 =
    .label = Administroni rregullime për flluska dhe ridrejtime nga palë të treta…
    .accesskey = A
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Shihni hollësi sajti
            [1] Shihni hollësi sajti (1 gjurmues i bllokuar)
           *[other] Shihni hollësi sajti ({ $count } gjurmues të bllokuar)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } Lidhje
           *[other] { $count } Lidhje
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Mesazhe, Etj…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Mesazhe, Postë, Etj…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Ndajeni me të tjerë…
    .accesskey = N
urlbar-identity-button =
    .aria-label = Shihni hollësi sajti

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Hapni panelin e mesazheve të instalimit
urlbar-web-notification-anchor =
    .tooltiptext = Ndryshoni zgjedhjen për nëse mund të merrni njoftime nga sajti apo jo
urlbar-midi-notification-anchor =
    .tooltiptext = Hapni panel MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Hapni panelin e Serialit
urlbar-eme-notification-anchor =
    .tooltiptext = Administroni përdorim software-i DRM
urlbar-web-authn-anchor =
    .tooltiptext = Hap panel Mirëfilltësimesh Web
urlbar-canvas-notification-anchor =
    .tooltiptext = Administroni leje përftimesh nga kanavaca
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Administroni ndarjen me sajtin të mikrofonit tuaj
urlbar-default-notification-anchor =
    .tooltiptext = Hapni panelin e mesazheve
urlbar-geolocation-notification-anchor =
    .tooltiptext = Hapni panel kërkesash vendndodhjesh
urlbar-localhost-notification-anchor =
    .tooltiptext = Administroni hyrje pajisjesh vendore për këtë sajt
urlbar-local-network-notification-anchor =
    .tooltiptext = Administroni dhënie përdorimi të rrjetit tuaj vendor këtij sajti
urlbar-xr-notification-anchor =
    .tooltiptext = Hapni panel lejesh për realitet virtual
urlbar-storage-access-anchor =
    .tooltiptext = Hapni panelin e lejeve mbi veprimtari shfletimi
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Administroni ndarjen me sajtin të dritares ose ekranit tuaj
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Hapni panelin për depozitim jashtë linje
urlbar-password-notification-anchor =
    .tooltiptext = Hapni panel mesazhi ruajtje fjalëkalimi
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Administroni ndarjen me sajtin të kamerës dhe/ose mikrofonit tuaj
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Administroni ndarje altoparlantësh të tjerë me sajtin
urlbar-autoplay-notification-anchor =
    .tooltiptext = Hap panel vetëluajtje
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Depozitoni të dhëna në Depozitë të Qëndrueshme
urlbar-addons-notification-anchor =
    .tooltiptext = Hapni kuadratin e mesazhit të instalimit të shtesës
urlbar-search-tips-confirm = OK, E mora vesh
urlbar-search-tips-confirm-short = E mora vesh
urlbar-result-menu-button =
    .title = Hape menunë
urlbar-result-menu-button-feedback = Përshtypje
    .title = Hap menunë
urlbar-result-menu-learn-more2 = Mësoni më tepër
    .accesskey = M
urlbar-result-menu-remove-from-history2 = Hiqe prej historiku
    .accesskey = H
urlbar-result-menu-tip-get-help2 = Merrni ndihmë
    .accesskey = d
urlbar-result-menu-dismiss-suggestion2 = Hidhe tej këtë sugjerim
    .accesskey = H
urlbar-result-menu-remove-top-site = Hiqe këtë sajt kryesues
    .accesskey = k
urlbar-result-menu-manage-firefox-suggest2 = Administroni { -firefox-suggest-brand-name }
    .accesskey = A
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Njoftoni për vendndodhje të pasaktë
    .accesskey = N
urlbar-result-menu-show-less-frequently3 = Shfaqi më rrallë
    .accesskey = S
urlbar-result-menu-dont-show-weather-suggestions3 = Mos shfaq sugjerime moti
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Njoftoni për vendndodhje të pasaktë
urlbar-result-menu-show-less-frequently2 = Shfaqi më rrallë
urlbar-result-menu-dont-show-weather-suggestions2 = Mos shfaq sugjerime moti
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Hidhe tej këtë sugjerim
    .accesskey = H
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Hiqe prej historiku
    .accesskey = H
urlbar-result-menu-learn-more =
    .label = Mësoni më tepër
    .accesskey = M
urlbar-result-menu-remove-from-history =
    .label = Hiqe prej historiku
    .accesskey = H
urlbar-result-menu-tip-get-help =
    .label = Merrni ndihmë
    .accesskey = d
urlbar-result-menu-dismiss-suggestion =
    .label = Hidhe tej këtë sugjerim
    .accesskey = H
urlbar-result-menu-manage-firefox-suggest =
    .label = Administroni { -firefox-suggest-brand-name }
    .accesskey = A
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Njoftoni për vendndodhje të pasaktë
urlbar-result-menu-show-less-frequently =
    .label = Shfaqi më rrallë
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Mos shfaq sugjerime moti
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Hape menunë
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Faleminderit për përshtypjet tuaja
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Faleminderit për përshtypjet. S’do të shihni më sugjerime moti.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Shtypni më pak, gjeni më shumë: Kërkoni me { $engineName } drejt e nga shtylla juaj e adresave.
urlbar-search-tips-redirect-2 = Filloni kërkimin tuaj te shtylla e adresave që të shihni sugjerime nga { $engineName } dhe nga historiku juaj i shfletimit.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Përzgjidhni këtë shkurtore, që të gjeni më shpejt ç’ju duhet.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Faqerojtës
urlbar-search-mode-tabs = Skeda
urlbar-search-mode-history = Historik
urlbar-search-mode-actions = Veprime

##

urlbar-geolocation-blocked =
    .tooltiptext = Ia keni bllokuar këtij sajti të dhënat mbi vendndodhjen tuaj.
urlbar-localhost-blocked =
    .tooltiptext = Keni bllokuar lidhje pajisjesh vendore për këtë sajt.
urlbar-local-network-blocked =
    .tooltiptext = Keni bllokuar lidhje rrjetesh vendorë për këtë sajt.
urlbar-xr-blocked =
    .tooltiptext = E keni bllokuar hyrjen në pajisje realiteti virtual për këtë sajt.
urlbar-web-notifications-blocked =
    .tooltiptext = Ia keni bllokuar këtij sajti njoftimet.
urlbar-camera-blocked =
    .tooltiptext = E keni bllokuar kamerën tuaj për këtë sajt.
urlbar-microphone-blocked =
    .tooltiptext = E keni bllokuar kamerën tuaj për këtë sajt.
urlbar-screen-blocked =
    .tooltiptext = Ia keni bllokuar këtij sajti përdorimin e ekranit tuaj.
urlbar-persistent-storage-blocked =
    .tooltiptext = E keni bllokuar depozitimin e qëndrueshëm për këtë sajt.
urlbar-popup-blocked2 =
    .tooltiptext = Keni bllokuar flluska dhe ridrejtime palësh të treta për këtë sajt.
urlbar-autoplay-media-blocked =
    .tooltiptext = Keni bllokuar vetëluajtje mediash me tinguj për këtë sajt.
urlbar-canvas-blocked =
    .tooltiptext = Për këtë sajt e keni bllokuar përftimin e të dhënave të kanavacës.
urlbar-midi-blocked =
    .tooltiptext = E keni bllokuar hyrjen MIDI për këtë sajt.
urlbar-serial-blocked =
    .tooltiptext = Keni bllokuar hyrje në portë seriale për këtë sajt.
urlbar-install-blocked =
    .tooltiptext = Ia keni bllokuar këtij sajti instalimin e shtesave.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Përpunoni këtë faqerojtës ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Faqeruani këtë faqe ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Pamje krah për krah
    .tooltiptext = Pamje krah për krah

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Ngjite dhe Vazhdo
    .accesskey = N
urlbar-menuitem-paste-and-search =
    .label = Ngjite dhe Kërko
    .accesskey = N

## Searchbar context menu

clear-search-history =
    .label = Spastro Historik Kërkimesh
    .accesskey = P

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Administroni Zgjerime…
    .accesskey = A
page-action-remove-extension2 =
    .label = Hiqe Zgjerimin
    .accesskey = H

## Auto-hide Context Menu

full-screen-autohide =
    .label = Fshihi Panelet
    .accesskey = F
full-screen-exit =
    .label = Dilni nga Sa Krejt Ekrani
    .accesskey = D

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Këtë herë kërko me:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Ndryshoni rregullime kërkimi
search-one-offs-context-open-new-tab =
    .label = Kërkoni në Skedë të Re
    .accesskey = S
search-one-offs-context-set-as-default =
    .label = Caktojeni Si Motor Parazgjedhje Kërkimesh
    .accesskey = P
search-one-offs-context-set-as-default-private =
    .label = Vëre si Motor Kërkimi Parazgjedhje për Dritare Private
    .accesskey = V
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Shtoni motorin e kërkimeve “{ $engineName }”
    .label = Shtoni “{ $engineName }”
    .tooltiptext = Shtoni motorin e kërkimeve “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Shtoni motor kërkimesh
    .accesskey = S
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Shtoni motor kërkimesh

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Faqerojtës ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Skeda ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historik ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Veprime ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Shihini Shtesa
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = zgjerime, tema, shtesa
# Opens preferences page at AI controls
quickactions-manageai = Administroni kontrolle IA
quickactions-cmd-manageai = çaktivizo ia, ia-ja off, administroni ia
# Opens the bookmarks library window
quickactions-bookmarks2 = Administroni faqerojtës
quickactions-cmd-bookmarks = faqerojtës
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Spastro historik së fundi
quickactions-cmd-clearrecenthistory2 = “cookies”, spastro cookie-t, fshehtinë, spastro fshehtinë, të dhëna shfletimi, spastro të dhëna shfletimi, historik, spastro historik së fundi
# Opens about:downloads page
quickactions-downloads2 = Shihni shkarkime
quickactions-cmd-downloads = shkarkime
# Opens about:addons page in the extensions section
quickactions-extensions = Administroni zgjerime
quickactions-cmd-extensions2 = zgjerime, shtesa
# Opens Firefox View
quickactions-firefoxview = Hap { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = hap { -firefoxview-brand-name }, { -firefoxview-brand-name }, hap pamje, pamje
# Opens SUMO home page
quickactions-help = Ndihmë { -brand-product-name }
quickactions-cmd-help = ndihmë, asistencë
# Opens the devtools web inspector
quickactions-inspector2 = Hap Mjete Zhvilluesish
quickactions-cmd-inspector2 = mbikëqyrë, mjete zhvilluesi
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Zgjidhni një ngjyrë
quickactions-cmd-colorpicker = zgjedhës ngjyrash, pikatore, zgjidhni ngjyrë
# Opens Firefox Library
quickactions-cmd-library = bibliotekë
quickactions-library = Hap Bibliotekën
# Opens about:logins
quickactions-logins2 = Administroni fjalëkalime
quickactions-cmd-logins = kredenciale hyrjesh, fjalëkalime
# Mutes all tabs playing audio
quickactions-mute = Heshto skeda që luajnë audio
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = heshtoje, shët, sus
# Opens the print dialog
quickactions-print2 = Shtypni faqe
quickactions-cmd-print = shtype
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Ruaje faqen si PDF
quickactions-cmd-savepdf2 = pdf, ruaje faqen
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Hap përpunues PDF-sh
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Hap dritare private
quickactions-cmd-private = shfletim privat
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Rifreskoni { -brand-short-name }-in
quickactions-cmd-refresh = rifreskoje
# Restarts the browser
quickactions-restart = Riniseni { -brand-short-name }-in
quickactions-cmd-restart = rinise
# Opens the screenshot tool
quickactions-screenshot3 = Bëni një foto ekrani
quickactions-cmd-screenshot2 = foto ekrani, bëni një foto ekrani
# Opens about:translations
quickactions-translate = Përktheje
quickactions-cmd-translate = përktheje
# Opens about:preferences
quickactions-settings2 = Administroni rregullime
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = rregullime, parapëlqime, mundësi, administroni
# Opens about:addons page in the themes section
quickactions-themes = Administroni tema
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temsa, shtesa
# Opens a SUMO article explaining how to update the browser
quickactions-update = Përditësoni { -brand-short-name }
quickactions-cmd-update = përditësoje
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Shihni Burim Faqeje
quickactions-cmd-viewsource2 = shihini burimin, burim, burim faqeje
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Hap { -firefoxlabs-brand-name }
quickactions-cmd-labs = laboratorë, eksperiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Mësoni më tepër rreth Veprimesh të shpejta
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Shtypni tastin tab, që të përzgjidhet:

## Bookmark Panel

bookmarks-add-bookmark = Shto faqerojtës
bookmarks-edit-bookmark = Përpunoni faqerojtësin
bookmark-panel-cancel =
    .label = Anuloje
    .accesskey = A
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Hiqe Faqerojtësin
           *[other] Hiqi Faqerojtësit ({ $count })
        }
    .accesskey = H
bookmark-panel-show-editor-checkbox =
    .label = Shfaqe përpunuesin, kur bëhen ruajtje
    .accesskey = S
bookmark-panel-save-button2 =
    .label = Ruaje
    .accesskey = R
bookmark-panel-save-button =
    .label = Ruaje
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Hollësi sajti për { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Siguri Lidhjeje për { $host }
identity-connection-not-secure = Lidhje jo e siguruar
identity-connection-secure = Lidhje e siguruar
identity-connection-failure = Dështim lidhjeje
identity-connection-internal = Kjo është një faqe { -brand-short-name } e siguruar.
identity-connection-file = Kjo është faqe e depozituar në kompjuterin tuaj.
identity-connection-associated = Kjo faqe është ngarkuar nga një tjetër faqe.
identity-extension-page = Kjo faqe është ngarkuar nga një zgjerim.
identity-active-blocked = { -brand-short-name }-i ka bllokuar pjesë të kësaj faqeje që s'janë të siguruara.
identity-custom-root = Lidhje e verifikuar nga një lëshues dëshmish që s’njihet nga Mozilla.
identity-passive-loaded = Pjesë të kësaj faqeje (fjala vjen, figura) s'janë të siguruara.
identity-active-loaded = E keni çaktivizuar mbrojtjen për këtë faqe.
identity-weak-encryption = Kjo faqe përdor fshehtëzim të dobët.
identity-https-only-connection-upgraded = (u përmirësua në HTTPS)
identity-https-only-label2 = Përmirësoje automatikisht këtë sajt me një lidhje të siguruar
identity-https-only-dropdown-on =
    .label = On
identity-https-only-dropdown-off =
    .label = Off
identity-https-only-dropdown-off-temporarily =
    .label = Off përkohësisht
identity-https-only-info-turn-on3 = Nëse doni që { -brand-short-name }-i të përmirësojë lidhjen, kur kjo është e mundur, aktivizoni përmirësime HTTPS për këtë sajt.
identity-https-only-info-turn-off3 = Nëse faqja duket e dëmtuar, mund të doni të çaktivizoni përmirësime  HTTPS për këtë sajt, që të ngarkohet duke përdorur HTTP jo të siguruar.
identity-https-only-info-no-upgrade = S’arrihet të përmirësohet lidhja nga HTTP.
identity-permissions-storage-access-header = “Cookies” palësh të treta
identity-permissions-storage-access-hint = Këto palë mund të përdorin “cookies” palësh të treta të dhëna sajtesh, ndërkohë që jeni në këtë sajt.
identity-permissions-storage-access-learn-more = Mësoni më tepër
identity-permissions-reload-hint = Mund t'ju duhet të ringarkoni faqen që të hyjnë në fuqi ndryshimet.
identity-clear-site-data =
    .label = Spastroni Cookie-t dhe të Dhëna Sajti…
identity-connection-not-secure-security-view = S'jeni lidhur në mënyrë të siguruar me këtë sajt.
identity-connection-verified = Jeni lidhur në mënyrë të siguruar me këtë sajt.
identity-ev-owner-label2 = Dëshmi lëshuar për
identity-verifier-label2 = Verifikuar nga
identity-ev-owner-label = Dëshmi lëshuar për:
identity-verifier-label = Vërtetuar nga:
identity-description-custom-root2 = Mozilla nuk e njeh këtë lëshues dëshmish. Mund të jetë shtuar nga sistemi juaj operativ ose nga një përgjegjës.
identity-cert-exception-overridden = Keni shtuar përjashtim sigurie për këtë sajt.
identity-remove-cert-exception =
    .label = Hiqeni Përjashtimin
    .accesskey = H
identity-description-insecure = Lidhja juaj te ky sajt, s'është private. Hollësitë që parashtroni (fjala vjen, fjalëkalime, mesazhe, karta krediti, etj.) mund të shihen nga të tjerë.
identity-description-weak-cipher-intro = Lidhja juaj te ky sajt përdor fshehtëzim të dobët dhe s'është private.
identity-description-weak-cipher-risk = Të tjerët mund të shohin të dhënat tuaja ose të ndryshojnë sjelljen e sajtit.
identity-description-active-blocked2 = { -brand-short-name }-i ka bllokuar pjesë të kësaj faqeje që s'janë të siguruara.
identity-description-passive-loaded = Lidhja juaj s'është private dhe të dhënat që ndani me të tjerët në këtë saj mund të shihen nga të tjerë.
identity-description-passive-loaded-insecure2 = Ky sajt përmban lëndë që s'është e siguruar (fjala vjen, figura).
identity-description-passive-loaded-mixed2 = Edhe pse { -brand-short-name }-i ka bllokuar një pjesë të lëndës, në këtë faqe prapë ka lëndë që s'është e siguruar (fjala vjen, figura).
identity-description-active-loaded = Ky sajt përmban lëndë që s'është e siguruar (fjala vjen, programthe) dhe lidhja juaj me të s'është private.
identity-description-active-loaded-insecure = Të dhënat që ndani me këtë sajt mund të shihen nga të tjerë (fjala vjen, fjalëkalime, mesazhe, karta krediti, etj.).
identity-description-tls-key-logging-heading = Lidhja juaj mund të mos jetë private
identity-description-tls-key-logging-message = Një aplikacion, apo  një shërbim mund të shohë trafikun tuaj të fshehtëzuar nga ky sajt.
identity-more-info-link-text =
    .label = Më tepër hollësi

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimizojeni
browser-window-maximize-button =
    .tooltiptext = Maksimizoje
browser-window-restore-down-button =
    .tooltiptext = Riktheje Poshtë
browser-window-close-button =
    .tooltiptext = Mbylleni
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Riktheje

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importoni faqerojtës…
    .tooltiptext = Importoni faqerojtës nga një shfletues tjetër në { -brand-short-name }
bookmarks-toolbar-empty-message = Për përdorim të shpejtë, vendosini faqerojtësit këtu te paneli i faqerojtësve. <a data-l10n-name="manage-bookmarks">Administroni faqerojtës…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Kamerë:
    .accesskey = K
popup-select-camera-icon =
    .tooltiptext = Kamerë
popup-select-microphone-device =
    .value = Mikrofon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Mikrofon
popup-select-speaker-icon =
    .tooltiptext = Altoparlantë
popup-select-window-or-screen =
    .label = Dritare ose skenë:
    .accesskey = D
popup-all-windows-shared = Do të ndahen me të tjerët krejt dritaret e dukshme në ekranin tuaj.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Jeni duke ndarë { -brand-short-name }-in me të tjerë. Persona të tjerë mund ta shohin, kur kaloni te një skedë e re.
sharing-warning-screen = Po ndani me të tjerë krejt ekranin. Persona të tjerë mund ta shohin, kur kaloni te një skedë e re.
sharing-warning-proceed-to-tab =
    .label = Kalo te Skeda
sharing-warning-disable-for-session =
    .label = Çaktivizo mbrojtje ndarjeje për këtë sesion

## WebSerial "select a port" popup

webserial-select-port-label = Përzgjidhni një portë seriale:
webserial-no-ports-available = S’ka porta seriale të përdorshme

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Mbylleni
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Bëni kërkim, ose jepni adresë
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Jepni adresë
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Kërkoni me { $name }
    .placeholder = Kërkoni në Web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Kërkoni me { $name }
    .placeholder = Jepni terma kërkimi
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Kërko te faqerojtësit
    .placeholder = Jepni terma kërkimi
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Kërko në historik
    .placeholder = Jepni terma kërkimi
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Kërko në skeda
    .placeholder = Jepni terma kërkimi
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Veprime kërkimi
    .placeholder = Jepni terma kërkimi
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Kërkoni me { $name } ose jepni adresë
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Shfletuesi gjendet nën kontroll së largëti (arsye: { $component })
urlbar-permissions-granted =
    .tooltiptext = I keni akorduar leje shtesë këtij sajti.
urlbar-switch-to-tab =
    .value = Kalo te skeda:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Zgjerim:
urlbar-go-button2 =
    .title = Shkoni te adresa e dhënë te Shtylla e Vendndodhjeve
urlbar-page-action-button =
    .tooltiptext = Veprime faqeje
urlbar-revert-button =
    .tooltiptext = Shfaqe adresën te Shtylla e Vendndodhjeve

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Kërko me { $engine } në një Dritare Private
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Kërko në Dritare Private
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Kërko me { $engine }
urlbar-result-action-sponsored = E sponsorizuar
urlbar-result-action-switch-tab = Kalo te Skeda
urlbar-result-action-move-tab-to-split-view = Kaloje Skedën nën Pamje të Ndarë
urlbar-result-action-visit = Vizitojeni
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Kaloni te Skeda · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Grup i paemër
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Vizitojeni që nga e papastra
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Shtypni tastin Tab që të kërkohet me { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Shtypni tastin Tab që të kërkohet me { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Kërkoni me { $engine } drejt e nga shtylla e adresave
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Kërkoni me { $engine } drejt e nga shtylla e adresave
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Kopjoje
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = e papërcaktuar
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Zgjerim { -brand-product-name }-i
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = I rekomanduar
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> në { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> në { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> në { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } ·E sponsorizuar
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Pyetni
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = E vizituar së fundi më { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] E vizituat së fundi { $daysAgo } ditë më parë
       *[other] E vizituat së fundi { $daysAgo } ditë më parë
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] E vizituat së fundi { $weeksAgo } javë më parë
       *[other] E vizituat së fundi { $weeksAgo } javë më parë
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] E vizituat së fundi { $monthsAgo } muaj më parë
       *[other] E vizituat së fundi { $monthsAgo } muaj më parë
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = E vizituat së fundi më { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Faqeruajtur më { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Vizituar së fundi më { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Vizituar së fundi më { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Vizituar së fundi më { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Merrni të dhëna tregu aksionesh drejt e te shtylla juaj e kërkimeve
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Shfaq përditësime tregjesh, etj, nga partnerët tanë, kur ndani me { -vendor-short-name } të dhëna termash kërkimi. <a data-l10n-name="learn-more-link">Mësoni më tepër</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Shfaq sugjerime
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Jo tani
urlbar-result-realtime-opt-in-dismiss = Hidhe tej
urlbar-result-realtime-opt-in-dismiss-all2 = Mos i shfaq këto sugjerime
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Mos shfaq sugjerime tregu
    .accesskey = M
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Mos shfaq sugjerime tregu
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Mos i shfaq këto sugjerime
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Mos shfaq sugjerime tregu
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Faleminderit për përshtypjet. S’do të shihni më sugjerime tregu.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Sugjerime për aksione
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Faleminderit për përshtypjet. S’do të shihni më këto sugjerime.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · në { $daysUntilStart } ditë
       *[other] { $name } · në { $daysUntilStart } ditë
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Fillon për  { $daysUntilStart } ditë
       *[other] { $name } · Fillon për { $daysUntilStart } ditë
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Përfundon pas { $daysUntilEnd } dite
       *[other] { $name } · Përfundon pas { $daysUntilEnd } ditësh
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Sot
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Përfundon sot

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Kërko me { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Kërkoni me { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Kërkoni me { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, zgjidhni një motor kërkimesh
urlbar-searchmode-button-no-engine2 =
    .title = S’u përzgjodh shkurtore, zgjidhni një shkurtore
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Kërkimi me fjalëkyçe është i çaktivizuar
urlbar-searchmode-dropmarker2 =
    .title = Zgjidhni një Motor Kërkimesh
urlbar-searchmode-bookmarks4 = Faqerojtës
urlbar-searchmode-tabs4 = Skeda
urlbar-searchmode-history4 = Historik
urlbar-searchmode-actions4 = Veprime
urlbar-searchmode-bookmarks3 = Faqerojtës
    .accesskey = F
urlbar-searchmode-tabs3 = Skeda
    .accesskey = S
urlbar-searchmode-history3 = Historik
    .accesskey = H
urlbar-searchmode-actions3 = Veprime
    .accesskey = V
urlbar-searchmode-exit-button2 =
    .title = Mbylle
urlbar-searchmode-default2 =
    .title = Motor parazgjedhje kërkimesh
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Shtoni “{ $engineName }”
    .title = Shtoni motorin e kërkimeve “{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Këtë herë kërko me:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Kërko me:
urlbar-searchmode-popup-search-settings2 = Rregullime Mbi Kërkimin
urlbar-searchmode-popup-settings2 = Rregullime
urlbar-searchmode-popup-search-settings = Rregullime Kërkimi
    .accesskey = K
urlbar-searchmode-popup-settings = Rregullime
    .accesskey = R

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Kërkoni Te Faqerojtësit
urlbar-result-action-search-history = Kërkoni Në Historik
urlbar-result-action-search-tabs = Kërkoni Në Skeda
urlbar-result-action-search-actions = Veprime Kërkimi
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Kalo te { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Hap { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Hape në Skedë të Re
    .accesskey = H
urlbar-view-context-menu-open-in-container-tab =
    .label = Hape në Skedë të Re Kontejneri
    .accesskey = H
urlbar-view-context-menu-open-in-window =
    .label = Hape në Dritare të Re
    .accesskey = H
urlbar-view-context-menu-open-in-private-window =
    .label = Hape në Dritare të Re Private
    .accesskey = H
urlbar-view-context-menu-open-in-tab2 = Hape në Skedë të Re
    .accesskey = H
urlbar-view-context-menu-open-in-container-tab2 = Hape në Skedë të Re Kontejneri
    .accesskey = H
urlbar-view-context-menu-open-in-window2 = Hape në Dritare të Re
    .accesskey = H
urlbar-view-context-menu-open-in-private-window2 = Hape në Dritare të Re Private
    .accesskey = H
urlbar-view-context-menu-search-in-tab = Kërkim në Skedë të Re
    .accesskey = K
urlbar-view-context-menu-search-in-container-tab = Kërkim në Skedë të Re Kontejneri
    .accesskey = o
urlbar-view-context-menu-search-in-window = Kërkim në Dritare të Re
    .accesskey = D
urlbar-view-context-menu-search-in-private-window = Kërkoni në Dritare Private të Re
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Anashkaloje këtë menu, kur përdoret tasti TAB
    .accesskey = A

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Sugjerime nga { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Veprime të Shpejta
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Kërkime Së Fundi
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Prirje te { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Mos shfaq prirje kërkimesh
    .accesskey = M
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Mos shfaq prirje kërkimesh
    .accesskey = M
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Mos shfaq prirje kërkimesh
    .accesskey = M
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Faleminderit për përshtypjet. S’do të shihni më prirje kërkimi.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Kalo në Pamjen Lexues
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Mbylle Pamjen Lexues

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Hap Picture-in-Picture ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Mbylle Picture-in-Picture ({ $shortcut })
picture-in-picture-panel-header = Picture-in-Picture
picture-in-picture-panel-headline = Ky sajt nuk rekomandon përdorim të “Picture-in-Picture”
picture-in-picture-panel-body = Videot mund të mos shfaqen, ngaqë zhvilluesi i pat menduar me Picture-in-Picture të aktivizuar.
picture-in-picture-enable-toggle =
    .label = Aktivizoje, sido qoftë

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> tani është sa krejt ekrani
fullscreen-warning-no-domain = Ky dokument tani shfaqet sa krejt ekrani
fullscreen-exit-button = Dilni nga Sa Krejt Ekrani (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Dilni Nga Sa Krejt Ekrani (esc)
fullscreen-keyboardlock-exit-button = Dil Nga Mënyra “Sa Krejt Ekrani” (Shtypni dhe mbani të shtypur tastin Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Dil Nga Mënyra “Sa Krejt Ekrani” (Shtypni dhe mbani të shtypur tastin esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> është në kontroll të kursorit tuaj. Shtypni Esc që të rimerrni kontrollin.
pointerlock-warning-no-domain = Kursori është nën kontrollin e kursorit tuaj. Shtypni Esc që të rimerrni kontrollin.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Administroni faqerojtës
bookmarks-recent-bookmarks-panel-subheader = Faqerojtës Së Fundi
bookmarks-toolbar-chevron =
    .tooltiptext = Shfaqni më tepër faqerojtës
bookmarks-sidebar-content =
    .aria-label = Faqerojtës
bookmarks-menu-button =
    .label = Menu Faqerojtësish
bookmarks-other-bookmarks-menu =
    .label = Faqerojtës të Tjerë
bookmarks-mobile-bookmarks-menu =
    .label = Faqerojtës Celulari

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Fshihe Anështyllën e Faqerojtësve
           *[other] Shihni Anështyllë Faqerojtësish
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Fshihe Panelin e Faqerojtësve
           *[other] Shihni Panel Faqerojtësish
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Fshih Panel Faqerojtësish
           *[other] Shfaq Panel Faqerojtësish
        }

##

bookmarks-search =
    .label = Kërkoni Te Faqerojtësit
bookmarks-tools =
    .label = Mjete Faqeruajtjeje
bookmarks-subview-edit-bookmark =
    .label = Përpunojeni këtë faqerojtës…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Faqerojtës
    .toolbarname = Panel Faqerojtësish
    .accesskey = F
bookmarks-toolbar-menu =
    .label = Panel Faqerojtësish
bookmarks-toolbar-placeholder =
    .title = Objekte Paneli Faqerojtësish
bookmarks-toolbar-placeholder-button =
    .label = Objekte Paneli Faqerojtësish
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Faqeruani skedën e tanishme…

## Library Panel items

library-bookmarks-menu =
    .label = Faqerojtës

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Riparo kodim teksti
    .tooltiptext = Hamendësoje kodimin e saktë të tekstit që nga lënda e faqes

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Rregullime
    .tooltiptext =
        { PLATFORM() ->
            [macos] Hapni rregullimet ({ $shortcut })
           *[other] Hapni rregullimet
        }
toolbar-overflow-customize-button =
    .label = Përshtateni Panelin…
    .accesskey = P
toolbar-button-email-link =
    .label = Dërgojeni Lidhjen me Email
    .tooltiptext = Dërgoni me email një lidhje për te kjo faqe
toolbar-button-logins =
    .label = Fjalëkalime
    .tooltiptext = Shihni dhe administroni fjalëkalimet tuaj të ruajtur
qrcode-panel-error =
    .message = S’u arrit të prodhohej kod QR. Ju lutemi, riprovoni.
qrcode-copy-button =
    .label = Kopjoje
qrcode-copy-success =
    .message = Kodi QR u kopjua në të papastër.
qrcode-copy-error =
    .message = S’u arrit të kopjohej kodi QR.
qrcode-save-button =
    .label = Ruaje
qrcode-window-title = Kod QR
qrcode-dialog-title = Kod QR
qrcode-image =
    .aria-label = Kod QR
qrcode-close-button =
    .aria-label = Mbylle
toolbar-button-save-page =
    .label = Ruaje Faqen
    .tooltiptext = Ruajeni këtë faqe ({ $shortcut })
toolbar-button-open-file =
    .label = Hap Kartelë
    .tooltiptext = Hapni kartelë ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Skeda të Njëkohësuara
    .tooltiptext = Shfaqni skeda nga pajisje të tjera
toolbar-button-send-tab =
    .label = Dërgoni skedë
    .tooltiptext = Dërgojeni skedën e tanishme te një tjetër pajisje
toolbar-button-new-private-window =
    .label = Dritare e re private
    .tooltiptext = Hapni një dritare të re shfletimi privat ({ $shortcut })
toolbar-button-share-tab =
    .label = Ndajeni me të tjerët
    .tooltiptext = Ndajeni këtë faqe me të tjerët
toolbar-button-tab-groups =
    .label = Grupe skedash
    .tooltiptext = Shfaqni grupet tuaj të skedave
toolbar-button-history =
    .label = Historik
    .tooltiptext = Shfaqni historikun tuaj ({ $shortcut })
toolbar-button-find =
    .label = Gjej
    .tooltiptext = Gjeni në këtë faqe ({ $shortcut })
toolbar-button-developer =
    .label = Zhvillues
    .tooltiptext = Hapni mjete zhvilluesish Web ({ $shortcut })
toolbar-button-forget =
    .label = Harroje
    .tooltiptext = Harro historikun e shfletimit
toolbar-zoom-controls =
    .label = Kontrolle Zoom-i
    .title = Kontrolle zoom-i
toolbar-button-zoom-out =
    .label = Zvogëlojeni
    .tooltiptext = Zvogëlojeni ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Zeroni shkallën e zoom-it ({ $shortcut })
toolbar-button-zoom-in =
    .label = Zmadhojeni
    .tooltiptext = Zmadhojeni ({ $shortcut })
toolbar-edit-controls =
    .label = Kontrolle Përpunimi
    .title = Kontrolle përpunimi
toolbar-button-cut =
    .label = Prije
    .tooltiptext = Prijeni ({ $shortcut })
toolbar-button-copy =
    .label = Kopjoje
    .tooltiptext = Kopjojeni ({ $shortcut })
toolbar-button-paste =
    .label = Ngjite
    .tooltiptext = Ngjiteni ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = kodqr
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Audio ose video në këtë sajt përdor software DRM, çka mund të kufizojë ato që { -brand-short-name }-i mund t’ju lejojë të bëni me të.
eme-notifications-drm-content-playing-manage = Administroni rregullime
eme-notifications-drm-content-playing-manage-accesskey = A
eme-notifications-drm-content-playing-dismiss = Hidhe tej
eme-notifications-drm-content-playing-dismiss-accesskey = H

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Që të luhet video ose audio në këtë faqe, duhet të aktivizoni DRM-në.
eme-notifications-drm-content-disabled-button =
    .label = Aktivizoje DRM-n
    .accesskey = A
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name }-i po instalon përbërës të nevojshëm për të luajtur audio ose video në këtë faqe. Ju lutemi, riprovoni më vonë.
decoder-doctor-no-codecs-linux-message = Që të luani videon, mund t’ju duhet të instaloni kodekët e domosdoshëm për video.
decoder-doctor-no-hw-acceleration-message = Që të përmirësoni cilësinë e videos, mund t’ju duhet të instaloni Media Feature Pack të Microsoft-it.
decoder-doctor-no-pulse-audio-message = Që të luhet audio, mund  t’ju duhet të instaloni software-in e domosdoshëm PulseAudio.
decoder-doctor-unsupported-libavcodec-message = libavcodec mund të jetë i cenueshëm, ose nuk mbulohet dhe duhet përditësuar që të luhet videoja.
decoder-doctor-decode-error-message = Ndodhi një gabim gjatë shkodimit të një burimi media.
decoder-doctor-decode-warning-message = Ndodhi një gabim i riparueshëm gjatë shkodimit të një burimi media.
decoder-doctor-learn-how-link = Mësoni se si
decoder-doctor-report-issue-button =
    .label = Raporto problem sajti
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Shtojca { $pluginName } u vithis.
plugin-crashed-notification-reload-button =
    .label = Ringarkoje faqen
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = Parashtroni një njoftim vithisjeje
    .accesskey = P

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Sajt i Rremë!
safebrowsing-reported-attack-site-message = I raportuar si Sajt Sulmesh!
safebrowsing-reported-unwanted-site-message = I raportuar si Sajt Software-i të Padëshiruar!
safebrowsing-reported-harmful-site-message = Sajt i Raportuar Si i Dëmshëm!
safebrowsing-get-me-out-of-here-button =
    .label = Hiqmë prej këtej!
    .accesskey = H
safebrowsing-not-a-deceptive-site-button =
    .label = Ky s’është sajt i rremë…
    .accesskey = R
safebrowsing-not-an-attack-site-button =
    .label = Ky s’është sajt sulmesh…
    .accesskey = S

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Duhet të bëni hyrjen në këtë rrjet, përpara se të përdorni Internetin.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Hap faqe hyrjeje në rrjet

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Te { $hostName } synonit të shkonit?
keyword-uri-fixup-go-to-button =
    .label = Po, shpjemëni te { $hostName }
    .accesskey = P

## Password save/update panel

panel-save-update-username-2 =
    .label = Emër përdoruesi
panel-save-update-password-2 =
    .label = Fjalëkalim

##

# "More" item in macOS share menu
menu-share-more =
    .label = Më tepër…
menu-share-windows =
    .label = Më tepër Mundësi
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Kopjo Lidhjen
           *[other] Kopjo { $count } Lidhje
        }
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = Mbylleni

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Lejo flluska dhe ridrejtime palësh të treta për { $uriHost }
    .accesskey = L

##

picture-in-picture-hide-toggle =
    .label = Fshih Buton Picture-in-Picture
    .accesskey = F

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Kaloje Butonin për “Picture-in-Picture” në të Djathtë Toggle to Right Side
    .accesskey = D
picture-in-picture-move-toggle-left =
    .label = Kaloje Butonin për “Picture-in-Picture” në të Majtë
    .accesskey = M

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Lëvizje
navbar-downloads =
    .label = Shkarkime
navbar-overflow-2 =
    .tooltiptext = Më tepër mjete
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Shtype
    .tooltiptext = Shtypeni këtë faqe… ({ $shortcut })
navbar-home =
    .label = Kreu
    .tooltiptext = Faqe Hyrëse e { -brand-short-name }-it
navbar-library =
    .label = Arkiv
    .tooltiptext = Shihni historikun, faqerojtësit e ruajtur, etj
navbar-search =
    .title = Kërkoni
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Skedash shfletuesi
tabs-toolbar-new-tab =
    .label = Skedë e Re
tabs-toolbar-list-all-tabs-2 =
    .label = Kërkoni dhe administroni skeda
    .tooltiptext = Kërkoni dhe administroni skeda
tabs-toolbar-list-all-tabs =
    .label = Paraqiti krejt skedat
    .tooltiptext = Paraqiti krejt skedat

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Lini këtu skedë që duhet fiksuar

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Të hapen skeda të mëparshme?</strong> Sesionin tuaj të mëparshëm mund ta riktheni që nga menuja e aplikacionit { -brand-short-name } <img data-l10n-name="icon"/>, nën Historik.
restore-session-startup-suggestion-button = Tregomëni se si

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Enti juaj e ka bllokuar hyrjen te kartela vendore në këtë kompjuter

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } tani kërkon skeda
urlbar-addons-shortcut-moved-description = Që të hapni zgjerime dhe tema, përdorni { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Administroni shkurtore
urlbar-addons-shortcut-moved-dismiss = E mora vesh

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } dërgon vetvetiu disa të dhëna te { -vendor-short-name } që të mund të përmirësojmë punimin e tij për ju.
data-reporting-notification-button =
    .label = Zgjidhni Ç’Të Ndahet Me Të Tjerët
    .accesskey = Z
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Shfletim privat
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Shfletim privat
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Hollësi shfletimi privat
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Gjendeni në Dritare Private
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Kjo ndihmon të mbahet shfletimi juaj i fshehur nga të tjerë në këtë pajisje, por s’ju bën të padukshëm në internet. <a data-l10n-name="learn-more">Cilët mund të jenë në gjendje të shohin veprimtarinë time?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Parandalim humbjeje të dhënash (DLP) nga { $agentName }. Klikoni për më tepër hollësi.
content-analysis-panel-title2 = Parandalim humbjesh të dhënash
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Enti juaj përdor <b>{ $agentName }</b> që të kontrollojë se si mund të ndahen me të tjerë të dhëna me spec. <a data-l10n-name="info">Mësoni më tepër</a>
content-analysis-panel-title = Mbrojtje të dhënash
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Enti juaj përdor <b>{ $agentName }</b> për mbrojtje kundër humbjesh të dhënash. <a data-l10n-name="info">Mësoni më tepër</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Zgjerime
    .tooltiptext = Zgjerime

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Zgjerime
    .tooltiptext = Zgjerime

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Zgjerime
    .tooltiptext =
        Zgjerime
        Disa zgjerime nuk lejohen

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Zgjerime
    .tooltiptext =
        Zgjerime
        Disa zgjerime janë aktivizuar

## Private browsing reset button

reset-pbm-panel-heading2 = Të spastrohen të dhënat dhe të niset sesion i ri privat?
reset-pbm-panel-description3 = Kjo spastron historikun dhe cookie-t tuaj dhe bën daljen tuaj nga llogari nëpër sajte. Dritarja juaj Private do të mbyllet dhe do të hapet një nga e para.
reset-pbm-panel-description2 = Kjo fshin historikun, cookie-t dhe krejt të dhëna të tjera sajtesh, pa mbyllur Dritaren tuaj Private.
reset-pbm-panel-always-ask-checkbox =
    .label = Pyetmë përherë
    .accesskey = P
reset-pbm-panel-cancel-button =
    .label = Anuloje
    .accesskey = A
reset-pbm-panel-confirm-button2 =
    .label = Spastro sesion privat
    .accesskey = S
reset-pbm-panel-complete = Të dhënat e sesionit privat u fshinë
reset-pbm-toolbar-button2 =
    .label = Spastro sesion privat
    .tooltiptext = Spastroni sesion privat

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Të fshihen krejt të dhënat e shfletimit?
fire-button-panel-description = Kjo sjell fshirjen e historikut, cookie-ve dhe të dhënave të sajteve. Do të bëhet dalja juaj nga llogari nëpër sajte. Kjo dritare do të mbyllet dhe { -brand-short-name }-i do të hapë një të re.
fire-button-panel-choose-description = Nëse s’doni të fshihet gjithçka, zgjidhni të dhëna specifike atëherë.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Zgjidhni…
fire-button-panel-cancel-button =
    .label = Anuloje
    .accesskey = A
fire-button-panel-confirm-button =
    .label = Fshiji krejt
    .accesskey = F
fire-button-panel-complete = Të dhënat e shfletimit u fshinë
fire-button-toolbar-button2 =
    .label = Fshini ca, ose krejt të dhëna
    .tooltiptext = Fshini ca, ose krejt të dhënat tuaja të shfletimit

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name }-i i pengoi kësaj faqeje ringarkimin e vetvetishëm.
refresh-blocked-redirect-label = { -brand-short-name }-i i pengoi kësaj faqeje ridrejtimin e vetvetishëm te një faqe tjetër.
refresh-blocked-allow =
    .label = Lejoje
    .accesskey = L

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Maskat tona të siguruara, të lehta për t’u përdorur mbrojnë identitetin tuaj dhe parandalojnë mesazhe të padëshiruar, duke fshehur adresën tuaj email.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Krejt email-et dërguar te maskat e emal-eve tuaj do të përcillen te <strong>{ $useremail }</strong> (veç në vendosshi t’i bllokoni ato).
firefox-relay-offer-legal-notice = Duke klikuar mbi “Përdor maskë email-i”, pajtoheni me <label data-l10n-name="tos-url">Kushte Shërbimi</label> dhe <label data-l10n-name="privacy-url">Shënim Privatësie</label>.
firefox-relay-offer-legal-notice-1 = Duke u regjistruar dhe duke krijuar një maskë email-i”, pajtoheni me <label data-l10n-name="tos-url">Kushte Shërbimi</label> dhe <label data-l10n-name="privacy-url">Shënim Privatësie</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (E paverifikuar)
popup-notification-xpinstall-prompt-learn-more = Mësoni më tepër rreth instalimit të shtesave në mënyrë të parrezik
popup-notification-xpinstall-prompt-block-url = Shihni hollësitë
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Lejoje zgjerimin të xhirojë në dritare private
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Ndani me zhvillues të zgjerimit të dhëna teknike dhe ndërveprimi
    .accesskey = N

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] { -brand-short-name } pengoi këtë sajt të hapë një dritare flluskë.
       *[other] { -brand-short-name } pengoi kë të sajt të hapë { $popupCount } dritare flluska.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name }-i i pengoi këtij sajti ridrejtimin.
        [1] { -brand-short-name }-i e pengoi këtë sajt të hapë një dritare flluskë dhe të bëjë ridrejtim.
       *[other] { -brand-short-name } e pengoi këtë sajt të hapë { $popupCount } dritare flluskë dhe të bëjë ridrejtim.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } e pengoi këtë sajt të hapë më shumë se { $popupCount } dritare flluska.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } e pengoi këtë sajt të hapë më tepër se { $popupCount } dritare flluskë dhe të bëjë ridrejtim.
       *[other] { -brand-short-name } e pengoi këtë sajt të hapë më tepër se { $popupCount } dritare flluskë dhe të bëjë ridrejtim.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Mundësi
           *[other] Parapëlqime
        }
    .accesskey =
        { PLATFORM() ->
            [windows] M
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Shfaq '{ $popupURI }'
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Shfaq “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Dialogu Windows për kartela s’u hap dot. S’përzgjidhej dot kartelë, ose dosje.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Dialogu Windows për kartela s’u hap dot. Kartela do të ruhet te { $path }.
file-picker-failed-save-nowhere = Dialogu Windows për kartela s’u hap dot. S’u gjet dot dosje parazgjedhje, kartela s’do të ruhet.
file-picker-crashed-open = Dialogu Windows për kartela u vithis. S’përzgjidhej dot kartelë, ose dosje.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Dialogu Windows për kartela u vithis. Kartela do të ruhet te { $path }.
file-picker-crashed-save-nowhere = Dialogu Windows për kartela u vithis. S’përzgjidhej dot dosje parazgjedhje; kartela s’do të ruhet.
file-picker-crashed-show-in-folder =
    .label = Shfaqe Në Dosje
    .accessKey = D

## Unsigned add-ons notification

unsigned-addons-disabled-message = S’verifikohet dot një ose më tepër shtesa të instaluara dhe u çaktivizuan.
unsigned-addons-disabled-learn-more =
    .label = Mësoni Më Tepër
    .accesskey = M

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Kjo faqe po ngadalëson { -brand-short-name }. Që shfletuesi juaj të bëhet më i shpejtë, ndaleni këtë faqe.
process-hang-nonspecific-tab-message = Një faqe po ngadalëson { -brand-short-name }. Që shfletuesi juaj të bëhet më i shpejtë, ndaleni këtë faqe.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” po ngadalëson { -brand-short-name }. Që shfletuesi juaj të bëhet më i shpejtë, ndaleni këtë faqe.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” po ngadalëson { -brand-short-name }. Që shfletuesi juaj të bëhet më i shpejtë, ndaleni atë zgjerim.
process-hang-addon-learn-more =
    .value = Mësoni më tepër
process-hang-stop-button =
    .label = Ndale
    .accesskey = N

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Përfundo ujdisjen
onboarding-aw-finish-setup-button =
    .label = Përfundo ujdisjen
    .tooltiptext = Përfundoni ujdisjen e { -brand-short-name }-it

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Mbrojtje e Thelluar Nga Gjurmimi është aktive
trustpanel-etp-label-disabled = Mbrojtje e Thelluar Nga Gjurmimi është joaktive
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Mbrojtje e Thelluar Nga Gjurmimi: On për { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Mbrojtje e Thelluar Nga Gjurmimi: Off për { $host }
trustpanel-etp-description-enabled = Nëse diçka duket se nuk punon në këtë sajt, provoni të çaktivizoni mbrojtjet.
trustpanel-etp-description-disabled = { -brand-product-name }-i mendon se shoqëritë duhet t’ju ndjekin më pak. Bllokojmë aq gjurmues sa mundim, kur aktivizoni mbrojtjet.
trustpanel-trackercount-label = Shfaq te shtylla e adresave gjurmues të bllokuar
trustpanel-trackercount-toggle =
    .aria-label = Shfaq te shtylla e adresave gjurmues të bllokuar
trustpanel-connection-label-secure = Lidhje e siguruar
trustpanel-connection-label-insecure = Lidhje jo e siguruar
trustpanel-header-enabled = { -brand-product-name }-i po bën rojë
trustpanel-description-enabled2 = Jeni i mbrojtur. Nëse vërejmë gjë, do t’ua bëjmë të ditur.
trustpanel-header-enabled-insecure = Hapni sytë në këtë sajt
trustpanel-description-enabled-insecure = { -brand-product-name } vuri re diçka të dyshimtë.
trustpanel-header-disabled = Keni mbyllur mbrojtjet
trustpanel-description-disabled = { -brand-product-name }-i s’është në shërbim. Sugjerojmë të riaktivizoni mbrojtjet.
trustpanel-clear-cookies-button = Spastro cookie-t dhe të dhëna sajti
trustpanel-privacy-link = Rregullime Privatësie
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Spastro “ cookies” dhe të dhëna sajti për { $host }
trustpanel-clear-cookies-description = Heqja e cookie-eve dhe të dhënave të sajteve mund të sjellë daljen tuaj nga sajte dhe spastrim shportash blerjesh.
trustpanel-clear-cookies-subview-button-clear = Spastroje
trustpanel-clear-cookies-subview-button-cancel = Anuloje
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Mbrojtje lidhjeje për { $host }
trustpanel-siteinformation-morelink = Më tepër hollësi sajti
trustpanel-blocker-see-all = Shihini Krejt
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Mbrojtje nga gjurmimet për { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Jo i Siguruar
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] U bllokua { $count } gjurmues
       *[other] U bllokuan { $count } gjurmues
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } mendon se shoqëritë duhet t’ju ndjekin më pak. Ndaj bllokojmë sa më shumë të mundemi.
trustpanel-blocked-header = { -brand-product-name }-i bllokoi këto gjëra për ju:
trustpanel-tracking-header = { -brand-product-name }-i lejoi këto gjëra, që kështu të mos dëmtohet funksionimi i sajteve:
trustpanel-tracking-description = Pa gjurmues, disa butona, formularë dhe fusha në kredenciale hyrjesh mund të mos funksionojnë.
trustpanel-insecure-section-header = Lidhja juaj s’është e sigurt
trustpanel-insecure-description = Të dhënat që po dërgoni te ky sajt s’janë të fshehtëzuara. Mund të shihen, vidhen, ose ndryshohen.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } “Cookie” gjurmimi nga sajte në sajte
       *[other] { $count } “Cookies” gjurmimi nga sajte në sajte
    }
trustpanel-list-label-tracking-content = Lëndë gjurmimi
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } Krijues Shenjash Gishtash
       *[other] { $count } Krijues Shenjash Gishtash
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } Gjurmues mediash shoqërore
       *[other] { $count } Gjurmues mediash shoqërore
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } Nxjerrës kriptomonedhash
       *[other] { $count } Nxjerrës kriptomonedhash
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i bllokoi { $count } gjurmues mediash shoqërore
       *[other] { -brand-product-name }-i bllokoi { $count } gjurmues mediash shoqërore
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i lejoi { $count } gjurmues mediash shoqërore
       *[other] { -brand-product-name }-i lejoi { $count } gjurmues mediash shoqërore
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i bllokoi { $count } “cookie” gjurmimi nga sajti në sajt
       *[other] { -brand-product-name }-i bllokoi { $count } “cookies” gjurmimi nga sajti në sajt
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i lejoi { $count } “cookie” gjurmimi nga sajti në sajt
       *[other] { -brand-product-name }-i lejoi { $count } “cookies” gjurmimi nga sajti në sajt
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i bllokoi { $count } gjurmues
       *[other] { -brand-product-name }-i bllokoi { $count } gjurmues
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i lejoi { $count } gjurmues
       *[other] { -brand-product-name }-i lejoi { $count } gjurmues
    }
trustpanel-tracking-content-tab-list-header = Këto sajte po rreken t’ju ndjekin:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i bllokoi { $count } krijues shenjash gishtash
       *[other] { -brand-product-name }-i bllokoi { $count } krijues shenjash gishtash
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name }-i lejoi { $count } krijues shenjash gishtash
       *[other] { -brand-product-name }-i lejoi { $count } krijues shenjash gishtash
    }
trustpanel-fingerprinter-list-header = Këto sajte po rreken të krijojnë shenja gishtash rreth jush:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } bllokoi { $count } nxjerrës kriptomonedhash
       *[other] { -brand-product-name } bllokoi { $count } nxjerrës kriptomonedhash
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] { -brand-product-name } lejoi { $count } nxjerrës kriptomonedhash
       *[other] { -brand-product-name } lejoi { $count } nxjerrës kriptomonedhash
    }
trustpanel-cryptominer-tab-list-header = Këto sajte po rreken të nxjerrin kriptomonedha:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Keni një llogari në këtë sajt?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name }-i pa se ky sajt pat një cenim të dhënash 12 muajt e fundit. Shihni nëse qetë prekur dhe ju.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Hidhe tej
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Fillo kontroll falas
trustpanel-blocker-section-header2 =
    { $count ->
        [one] <span data-l10n-name="count">{ $count }</span> Gjurmues i bllokuar në këtë sajt
       *[other] <span data-l10n-name="count">{ $count }</span> Gjurmues të bllokuar në këtë sajt
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Sajti duket i dëmtuar?</strong> Ringarkoni faqen, që të ulet përkohësisht mbrojtja juaj nga gjurmimet.
reduced-protection-infobar-reload-button = Ringarkoje
    .accesskey = R
reduced-protection-infobar-never-show-button = Mos e shfaq sërish
    .accesskey = M


identity-allow-site-data = Depozito përherë “cookies”/të dhëna për këtë sajt
urlbar-webgl-notification-anchor =
    .tooltiptext = Administroni leje krijimi konteksti WebGL
urlbar-webgl-blocked =
    .tooltiptext = Keni bllokuar krijim konteksti WebGL për këtë sajt.
