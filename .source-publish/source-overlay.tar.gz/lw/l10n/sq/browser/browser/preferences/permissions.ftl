# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 36em
    .title = Përjashtime
permissions-close-key =
    .key = w
permissions-address = Adresë e sajtit
    .accesskey = d
permissions-block =
    .label = Bllokoje
    .accesskey = B
permissions-disable-etp =
    .label = Shtoni Përjashtim
    .accesskey = S
permissions-session =
    .label = Lejoje për Sesionin
    .accesskey = S
permissions-allow =
    .label = Lejoje
    .accesskey = L
permissions-add =
    .label = Shtoje
    .accesskey = S
permissions-button-off =
    .label = Çaktivizoje
    .accesskey = Ç
permissions-button-off-temporarily =
    .label = Çaktivizoje Përkohësisht
    .accesskey = P
permissions-site-name =
    .label = Sajt
permissions-status =
    .label = Gjendje
permissions-remove =
    .label = Hiqe Sajtin
    .accesskey = H
permissions-remove-all =
    .label = Hiqi Krejt Sajtet
    .accesskey = k
permissions-save-changes-2 =
    .buttonlabelaccept = Ruaji Ndryshimet
    .buttonaccesskeyaccept = R
permission-dialog =
    .buttonlabelaccept = Ruaji Ndryshimet
    .buttonaccesskeyaccept = R
permissions-autoplay-menu = Parazgjedhje për krejt sajtet:
permissions-searchbox =
    .placeholder = Kërko Në Sajte
permissions-capabilities-autoplay-allow =
    .label = Lejo Audio dhe Video
permissions-capabilities-autoplay-block =
    .label = Blloko Audion
permissions-capabilities-autoplay-blockall =
    .label = Blloko Audio dhe Video
permissions-capabilities-allow =
    .label = Lejoje
permissions-capabilities-block =
    .label = Bllokoje
permissions-capabilities-prompt =
    .label = Pyet Përherë
permissions-capabilities-listitem-allow =
    .value = Lejoje
permissions-capabilities-listitem-block =
    .value = Bllokoje
permissions-capabilities-listitem-allow-session =
    .value = Lejoje për Sesionin
permissions-capabilities-listitem-off =
    .value = Off
permissions-capabilities-listitem-off-temporarily =
    .value = Off përkohësisht

## Invalid Hostname Dialog

permissions-invalid-uri-title = U dha Strehëemër i Pavlefshëm
permissions-invalid-uri-label = Ju lutemi, jepni një strehëemër të vlefshëm

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Përjashtime nga Mbrojtje e Thelluar Nga Gjurmimet
permissions-exceptions-manage-etp-desc = Mund të përcaktoni cilët sajte e kanë të mbyllur Mbrojtjen e Thelluar Nga Gjurmimet. Shtypni adresën e saktë të sajtit që doni të administroni dhe mandej klikoni mbi Shto Përjashtim.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Përjashtime - “Cookies” dhe të Dhëna Sajtesh
permissions-exceptions-cookie-desc = Mund të caktoni cilëve sajte u lejohet përherë ose kurrë të përdorin “cookies” dhe të dhëna sajtesh. Shtypni adresën e saktë të sajtit që doni të administroni dhe mandej klikoni Bllokoje, Lejoje për Sesion, ose Lejoje.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Përjashtim - Spastroje Historikun gjatë Fikjes
permissions-exceptions-shutdown-clearing-desc = Mund të specifikoni cilët sajte do të mbajnë të dhënat e tyre, kur { -brand-short-name }-i spastron historikun gjatë mbylljesh. Shtypni adresën e saktë të sajtit që doni të administroni dhe mandej klikoni mbi “Lejoje”.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Përjashtime - Mënyra Vetëm-HTTPS
permissions-exceptions-https-only-desc2 = Mënyrën Vetëm-HTTPS mund ta çaktivizoni për sajte specifike. Për këto sajte, { -brand-short-name }-i s’do të provojë të përmirësojë lidhjen me HTTPS të siguruar.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Sajte të Lejuar - Ridrejtime nga Dritare Flluska dhe Palë të Treta
permissions-exceptions-popup-desc2 = Mund të përcaktoni cilët sajte lejohen të hapin dritare flluska dhe të ridrejtohen nga kuadro palësh të treta.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Përjashtime - Fjalëkalime të Ruajtur
permissions-exceptions-saved-passwords-desc = { -brand-short-name } s’do të ruajë fjalëkalime për sajtet që tregohen këtu.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Sajte të Lejuar - Instalim Shtesash
permissions-exceptions-addons-desc = Mund të përcaktoni cilëve sajte u lejohet të instalojnë shtesa. Shtypni adresën e saktë të sajtit që doni të lejoni dhe mandej klikoni Lejoje

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Vetëluajtje
permissions-site-autoplay-desc = Këtu mund të trajtoni sajtet që nuk ndjekin rregullimet tuaja parazgjedhje për vetëluajtjen.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Njoftimesh
permissions-site-notification-desc = Sajtet vijues kanë kërkuar t’ju dërgojnë njoftime. Mund të specifikoni cilët sajte lejohen t’ju dërgojnë njoftime. Mundeni edhe të bllokoni kërkesa të reja për lejim njoftimesh.
permissions-site-notification-disable-label =
    .label = Blloko kërkesa të reja për lejim njoftimesh
permissions-site-notification-disable-desc = Kjo do të pengojë çfarëdo sajti jo të pranishëm më sipër të kërkojë leje për të dërguar njoftime. Bllokimi i njoftimeve mund të prishë punimin e ndonjë veçorie të sajtit.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Lejo njoftime  sajti, kur { -brand-short-name }-i është i mbyllur
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Zbatohen edhe rregullime njoftimesh të OS-it tuaj.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Vendndodhjesh
permissions-site-location-desc = Sajtet vijues kanë kërkuar të dinë vendndodhjen tuaj. Mund të specifikoni cilët sajte lejohen të mësojnë vendndodhjen tuaj. Mundeni edhe të bllokoni kërkesa të reja për njohje vendndodhjesh.
permissions-site-location-disable-label =
    .label = Blloko kërkesa të reja për njohje vendndodhjesh
permissions-site-location-disable-desc = Kjo do të pengojë çfarëdo sajti jo të pranishëm më sipër të kërkojë leje të njohë vendndodhjen tuaj. Bllokimi i njohjes së vendndodhjes tuaj mund të prishë punimin e ndonjë veçorie të sajtit.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Realiteti Virtual
permissions-site-xr-desc = Sajtet vijues kanë kërkuar të hyjnë në pajisje tuajat për realitet virtual. Mund të specifikoni cilët sajte lejohen të hyjnë në pajisjet tuaja të realitetit virtual. Mundeni edhe të bllokoni kërkesa të reja për hyrje në pajisjet tuaja të realitetit virtual.
permissions-site-xr-disable-label =
    .label = Blloko kërkesa të reja për hyrje në pajisjet tuaja të realitetit virtual
permissions-site-xr-disable-desc = Kjo do të pengojë çfarëdo sajti jo të pranishëm më sipër të kërkojë leje të hyjë në pajisje tuaja të realitetit virtual. Bllokimi i hyrjes në pajisjet tuaja të realitetit virtual mund të prishë punimin e ca anëve të sajtit.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Rregullime - Sajte të Bllokuar për Lidhje Aplikacionesh
permissions-site-app-links-desc = Këtyre sajteve u është bllokuar të kërkojnë të hapin lidhje aplikacionesh, fjala vjen, email-esh (mailto:). Që të lejoni të pyetet për të, hiqeni një sajt.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Kamere
permissions-site-camera-desc = Sajtet vijues kanë kërkuar të përdorin kamerën tuaj. Mund të specifikoni cilët sajte lejohen të përdorin kamerën tuaj. Mundeni edhe të bllokoni kërkesa të reja për përdorim kamere.
permissions-site-camera-disable-label =
    .label = Bllokoni kërkesa të reja për përdorim kamere
permissions-site-camera-disable-desc = Kjo do të pengojë çfarëdo sajti jo të pranishëm më sipër të kërkojë leje për të përdorur kamerën tuaj. Bllokimi i përdorimit të kamerës tuaj mund të prishë punimin e ndonjë veçorie të sajtit.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Rregullime - Aplikacione dhe shërbime pajisjeje
permissions-site-localhost-desc = Këto sajte kanë kërkuar të përdorin aplikacione dhe shërbime në këtë pajisje. Mund të zgjidhni të lejohen apo t’u bllokohet sajteve të bëjnë kështu.
permissions-site-localhost-disable-label =
    .label = Blloko kërkesa të reja për përdorim aplikacionesh dhe shërbimesh në këtë pajisje
permissions-site-localhost-disable-desc = Kjo do të ndalë çfarëdo sajti jo të dhënë më sipër të kërkojë të përdorë aplikacione dhe shërbime në këtë pajisje. Duke bërë kështu mund të dëmtohen disa veçori sajtesh.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Rregullime - Pajisje Rrjeti Vendor
permissions-site-local-network-desc = Këto sajte kanë kërkuar të përdorin aplikacione dhe shërbime në pajisje të lidhura te rrjeti juaj vendor apo ai Wi-Fi. Mund të zgjidhni të lejohen apo t’u bllokohet sajteve të bëjnë kështu.
permissions-site-local-network-disable-label =
    .label = Blloko kërkesa të reja për përdorim aplikacionesh dhe shërbimesh në pajisje të lidhura te Wi-Fi apo rrjeti vendor i juaji.
permissions-site-local-network-disable-desc = Kjo do të ndalë çfarëdo sajti jo të dhënë më sipër të kërkojë të përdorë aplikacione dhe shërbime në pajisje të lidhura te Wi-Fi apo rrjeti juaj vendor. Duke bërë kështu mund të dëmtohen disa veçori sajtesh.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Mikrofoni
permissions-site-microphone-desc = Sajtet vijues kanë kërkuar të përdorin mikrofonin tuaj. Mund të specifikoni cilët sajte lejohen të përdorin mikrofonin tuaj. Mundeni edhe të bllokoni kërkesa të reja për përdorim të mikrofonit.
permissions-site-microphone-disable-label =
    .label = Bllokoni kërkesa të reja për përdorim të mikrofonit
permissions-site-microphone-disable-desc = Kjo do të pengojë çfarëdo sajti jo të pranishëm më sipër të kërkojë leje për të përdorur mikrofonin tuaj. Bllokimi i përdorimit të mikrofonit tuaj mund të prishë punimin e ndonjë veçorie të sajtit.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Rregullime - Leje Altoparlanti
permissions-site-speaker-desc = Sajtet vijues kanë kërkuar të përzgjedhin një pajisje zëri në dalje. Mund të përcaktoni cilëve sajte u lejohet të përzgjedhin një pajisje zëri në dalje.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Përjashtime Sajtesh për DNS përmes HTTPS-je
permissions-exceptions-manage-doh-desc = { -brand-short-name }-i s’do të përdorë DNS të siguruar në këto sajte dhe nënpërkatësitë e tyre.
permissions-doh-entry-field = Jepni emrin e përkatësisë së sajtit
    .accesskey = p
permissions-doh-add-exception =
    .label = Shtoje
    .accesskey = S
permissions-doh-col =
    .label = Përkatësi
permissions-doh-remove =
    .label = Hiqe
    .accesskey = H
permissions-doh-remove-all =
    .label = Hiqi Krejt
    .accesskey = K


permissions-site-webgl-window2 =
    .title = Rregullime - Leje WebGL
    .style = { permissions-window2.style }
permissions-site-webgl-desc = Sajtet vijues kanë kërkuar të krijojnë kontekst WebGL. Mund të përcaktoni cilët sajte lejohen të krijojnë kontekste WebGL. Mundeni edhe të bllokoni kërkesa të reja që bëhen për të lejuar krijim konteksti WebGL.
