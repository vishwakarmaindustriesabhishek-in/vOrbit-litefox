# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = Exceções
permissions-close-key =
    .key = W
permissions-address = Endereço do site
    .accesskey = E
permissions-block =
    .label = Bloquear
    .accesskey = B
permissions-disable-etp =
    .label = Adicionar exceção
    .accesskey = e
permissions-session =
    .label = Permitir nesta sessão
    .accesskey = n
permissions-allow =
    .label = Permitir
    .accesskey = P
permissions-add =
    .label = Adicionar
    .accesskey = A
permissions-button-off =
    .label = Desativar
    .accesskey = D
permissions-button-off-temporarily =
    .label = Desativar temporariamente
    .accesskey = t
permissions-site-name =
    .label = Site
permissions-status =
    .label = Estado
permissions-remove =
    .label = Remover site
    .accesskey = R
permissions-remove-all =
    .label = Remover todos os sites
    .accesskey = t
permissions-save-changes-2 =
    .buttonlabelaccept = Salvar alterações
    .buttonaccesskeyaccept = S
permission-dialog =
    .buttonlabelaccept = Salvar alterações
    .buttonaccesskeyaccept = S
permissions-autoplay-menu = Padrão em todos os sites:
permissions-searchbox =
    .placeholder = Pesquisar sites
permissions-capabilities-autoplay-allow =
    .label = Permitir áudio e vídeo
permissions-capabilities-autoplay-block =
    .label = Bloquear áudio
permissions-capabilities-autoplay-blockall =
    .label = Bloquear áudio e vídeo
permissions-capabilities-allow =
    .label = Permitir
permissions-capabilities-block =
    .label = Bloquear
permissions-capabilities-prompt =
    .label = Sempre perguntar
permissions-capabilities-listitem-allow =
    .value = Permitir
permissions-capabilities-listitem-block =
    .value = Bloquear
permissions-capabilities-listitem-allow-session =
    .value = Permitir nesta sessão
permissions-capabilities-listitem-off =
    .value = Desativado
permissions-capabilities-listitem-off-temporarily =
    .value = Desativado temporariamente

## Invalid Hostname Dialog

permissions-invalid-uri-title = Nome de servidor inválido
permissions-invalid-uri-label = Digite um nome de servidor válido

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Exceções à proteção aprimorada contra rastreamento
permissions-exceptions-manage-etp-desc = Você pode especificar quais sites têm a proteção aprimorada contra rastreamento desativada. Digite o endereço exato do site que você quer gerenciar e clique em 'Adicionar exceção'.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Exceções - Cookies e dados de sites
permissions-exceptions-cookie-desc = Você pode especificar alguns sites para sempre ou nunca ter permissão para armazenar cookies e dados neste computador. Digite o endereço exato de um site e clique em Permitir, Bloquear ou Permitir nesta sessão.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Exceções - Limpar histórico ao fechar
permissions-exceptions-shutdown-clearing-desc = Você pode especificar quais sites mantêm seus dados quando o { -brand-short-name } limpa o histórico ao fechar. Digite o endereço exato do site que você quer configurar e clique em Permitir.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Exceções - Modo somente HTTPS
permissions-exceptions-https-only-desc2 = Você pode desativar o modo somente HTTPS em sites específicos. O { -brand-short-name } não tenta mudar a conexão para HTTPS seguro nesses sites.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Sites permitidos - Abertura de janelas e redirecionamento de terceiros
permissions-exceptions-popup-desc2 = Você pode especificar quais sites têm permissão para abrir janelas e ser redirecionados por frames de terceiros.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Exceções - Salvamento de senhas
permissions-exceptions-saved-passwords-desc = O { -brand-short-name } não salva senhas dos sites desta lista.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Sites permitidos - Instalação de extensões
permissions-exceptions-addons-desc = Você pode especificar que sites têm permissão para instalar extensões. Digite o endereço exato de um site e clique em Permitir.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Reprodução automática
permissions-site-autoplay-desc = Você pode gerenciar aqui os sites que não devem seguir sua configuração padrão de reprodução automática.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de notificações
permissions-site-notification-desc = Os seguintes sites solicitaram enviar notificações. Você pode especificar quais sites podem enviar notificações. Também pode bloquear novas solicitações de permissão para exibir notificações.
permissions-site-notification-disable-label =
    .label = Bloquear novas solicitações de permissão para exibir notificações
permissions-site-notification-disable-desc = Isso impede que qualquer site solicite nova permissão para enviar notificações. Bloquear notificações pode atrapalhar funcionalidades de alguns sites.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Permitir notificações de sites quando o { -brand-short-name } estiver fechado
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Também se aplicam as configurações de notificações do sistema operacional.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de localização
permissions-site-location-desc = Os seguintes sites solicitaram acessar sua localização. Você pode especificar quais sites podem acessar sua localização. Também pode bloquear novas solicitações de permissão de acesso à sua localização.
permissions-site-location-disable-label =
    .label = Bloquear novas solicitações de permissão para acessar sua localização
permissions-site-location-disable-desc = Isso impede que qualquer site solicite nova permissão para acessar sua localização. Bloquear o acesso à sua localização pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de realidade virtual
permissions-site-xr-desc = Os seguintes sites solicitaram acesso a seus dispositivos de realidade virtual. Você pode especificar quais sites podem acessar seus dispositivos de realidade virtual. Também pode bloquear novas solicitações de permissão de acesso a seus dispositivos de realidade virtual.
permissions-site-xr-disable-label =
    .label = Bloquear novas solicitações de permissão para acessar seus dispositivos de realidade virtual
permissions-site-xr-disable-desc = Isso impede que qualquer site solicite nova permissão para acessar seus dispositivos de realidade virtual. Bloquear o acesso a seus dispositivos de realidade virtual pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Configurações - Sites bloqueados para links de aplicativos
permissions-site-app-links-desc = Esses sites estão impedidos de pedir para abrir links de aplicativos, como email (mailto:). Remova um site para permitir que volte a pedir.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de câmera
permissions-site-camera-desc = Os seguintes sites solicitaram acesso à sua câmera. Você pode especificar quais sites podem acessar sua câmera. Também pode bloquear novas solicitações de permissão de acesso à sua câmera.
permissions-site-camera-disable-label =
    .label = Bloquear novas solicitações de permissão para acessar sua câmera
permissions-site-camera-disable-desc = Isso impede que qualquer site solicite nova permissão para acessar sua câmera. Bloquear o acesso à sua câmera pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Configurações - Aplicativos e serviços do dispositivo
permissions-site-localhost-desc = Estes sites solicitaram acesso a aplicativos e serviços neste dispositivo. Você pode optar por permitir ou bloquear que sites façam isso.
permissions-site-localhost-disable-label =
    .label = Bloquear novas solicitações de acesso a aplicativos e serviços neste dispositivo
permissions-site-localhost-disable-desc = Isto impede que qualquer site que não esteja na lista acima solicite acesso a aplicativos e serviços neste dispositivo. Fazer isso pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Configurações - Dispositivos de rede local
permissions-site-local-network-desc = Estes sites solicitaram acesso a aplicativos e serviços em dispositivos conectados à sua rede local ou WiFi. Você pode optar por permitir ou bloquear que sites façam isso.
permissions-site-local-network-disable-label =
    .label = Bloquear novas solicitações de acesso a aplicativos e serviços em dispositivos conectados à sua rede local ou WiFi.
permissions-site-local-network-disable-desc = Isto impede que qualquer site que não esteja na lista acima solicite acesso a aplicativos e serviços em dispositivos conectados ao seu WiFi ou dispositivos na rede local. Fazer isso pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de microfone
permissions-site-microphone-desc = Os seguintes sites solicitaram acesso ao seu microfone. Você pode especificar quais sites podem acessar seu microfone. Também pode bloquear novas solicitações de permissão de acesso ao seu microfone.
permissions-site-microphone-disable-label =
    .label = Bloquear novas solicitações de permissão para acessar seu microfone
permissions-site-microphone-disable-desc = Isso impede que qualquer site solicite nova permissão para acessar seu microfone. Bloquear o acesso ao seu microfone pode atrapalhar funcionalidades de alguns sites.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Configurações - Permissões de saídas de áudio
permissions-site-speaker-desc = Os seguintes sites solicitaram poder selecionar um dispositivo de saída de áudio. Você pode especificar quais sites têm permissão para selecionar um dispositivo de saída de áudio.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Exceções de sites para DNS sobre HTTPS
permissions-exceptions-manage-doh-desc = O { -brand-short-name } não usará DNS seguro nesses sites e seus subdomínios.
permissions-doh-entry-field = Digite o nome do domínio do site
    .accesskey = d
permissions-doh-add-exception =
    .label = Adicionar
    .accesskey = A
permissions-doh-col =
    .label = Domínio
permissions-doh-remove =
    .label = Remover
    .accesskey = R
permissions-doh-remove-all =
    .label = Remover tudo
    .accesskey = e


