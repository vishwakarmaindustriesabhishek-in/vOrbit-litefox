# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Pedir aos sites para não vender nem compartilhar meus dados
    .accesskey = t
non-technical-privacy-group =
    .label = Preferências de privacidade em sites
do-not-track-removal3 =
    .message = Não oferecemos mais suporte ao recurso “Não rastrear”.
non-technical-privacy-heading =
    .label = Proteções adicionais
preferences-privacy-relay-available =
    .description = Oculta seu endereço de email real para proteger sua caixa de entrada contra spam.
    .label = Sugerir máscaras de email do { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Configurações
category-nav-heading =
    .heading = Configurações
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Procurar em configurações
    .style = width: 15.4em
managed-notice = Seu navegador está sendo gerenciado pela sua organização.
managed-notice-info-icon =
    .alt = informações
managed-notice-nav =
    .label = Seu navegador está sendo gerenciado pela sua organização.
tls-key-logging-notice-nav =
    .label = Um aplicativo ou serviço pode ver seu tráfego criptografado.
category-list =
    .aria-label = Categorias
pane-general-title = Geral
pane-home-title = Início
pane-home-startup-title2 = Página inicial e início
    .title = Página inicial e início
pane-search-title2 = Pesquisa
    .title = Pesquisa
pane-privacy-title3 = Privacidade e Segurança
    .title = Privacidade e Segurança
pane-privacy-section =
    .heading = Privacidade e Segurança
pane-sync-title3 = Sincronização
pane-ai-controls-title2 = Controles de inteligência artificial
    .title = Controles de inteligência artificial
pane-about-firefox-title = Sobre o { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Aparência
    .title = { pane-appearance-title }
pane-downloads-title2 = Downloads
    .title = Downloads
pane-downloads3 =
    .heading = Downloads
pane-accessibility-title = Acessibilidade
    .title = { pane-accessibility-title }
pane-languages-title2 = Idiomas
    .title = Idiomas
preferences-languages-header3 =
    .heading = Idiomas
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Experimente nossos recursos experimentais! Eles estão em desenvolvimento e evolução, o que pode afetar o funcionamento do { -brand-short-name }. Só recebemos dados sobre seu uso desses recursos se você tiver ativado os <a data-l10n-name="data-collection">dados técnicos e de interação</a>.
pane-experimental-reset =
    .label = Restaurar padrão
    .accesskey = R
help-button-label2 = Suporte { -brand-short-name }
    .title = Suporte { -brand-short-name }
addons-button-label2 = Extensões e Temas
    .title = Extensões e Temas
focus-search =
    .key = f
close-button =
    .aria-label = Fechar
do-not-track-removal2 =
    .label = Não oferecemos mais suporte ao sinal “Não rastrear”
applications-setting-new-file-types =
    .label = O que o { -brand-short-name } deve fazer com outros arquivos?

## Browser Restart Dialog

feature-enable-requires-restart = O { -brand-short-name } deve ser reiniciado para ativar esta funcionalidade.
feature-disable-requires-restart = O { -brand-short-name } deve ser reiniciado para desativar esta funcionalidade.
should-restart-title = Reiniciar o { -brand-short-name }
should-restart-ok = Reiniciar o { -brand-short-name } agora
cancel-no-restart-button = Cancelar
restart-later = Reiniciar depois

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla esta configuração.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla esta configuração.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> requer abas contêiner.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla esta configuração.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> controla como o { -brand-short-name } se conecta à internet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Para ativar a extensão, vá em <img data-l10n-name="addons-icon"/> Extensões <img data-l10n-name="menu-icon"/> no menu.
extension-controlled-enable-2 = Para reativar esta extensão, acesse <a data-l10n-name="addons-link">Extensões e temas</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } controla algumas configurações da sua página inicial.

## Preferences UI Search Results

search-results-header = Resultados da pesquisa
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Desculpe, não há nenhum resultado de “<span data-l10n-name="query"></span>” nas configurações.
search-results-help-link = Precisa de ajuda? Visite o <a data-l10n-name="url">Suporte do { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Sempre verificar se o { -brand-short-name } é o navegador padrão
    .accesskey = S
startup-restore-windows-and-tabs =
    .label = Abrir janelas e abas anteriores
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = Ative esta preferência marcando “{ profile-manager-use-selected.label }” na janela “Perfil de usuário”.
windows-launch-on-login =
    .label = Abrir o { -brand-short-name } automaticamente ao iniciar o computador
    .accesskey = A
windows-launch-on-login-disabled = Esta preferência foi desativada no Windows. Para alterar, visite <a data-l10n-name="startup-link">Aplicativos de inicialização</a> nas configurações do sistema.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Também abrir uma nova aba
    .accesskey = n
disable-extension =
    .label = Desativar extensão
preferences-data-migration-group =
    .description = Traga seus favoritos, senhas, histórico, extensões e dados de preenchimento automático de outro navegador.
    .label = Importar dados de navegador
preferences-data-migration-button =
    .label = Importar dados
    .accesskey = m
preferences-profiles-group-header =
    .heading = Perfis
preferences-profiles-subpane-description =
    .description = Cada perfil tem configurações e dados de navegação separados, como histórico, senhas, etc.
preferences-profiles-section-header =
    .description = Cada perfil tem configurações e dados de navegação separados, como histórico, senhas, etc.
    .label = Perfis
preferences-manage-profiles-button =
    .label = Gerenciar perfis
preferences-profiles-settings-button =
    .label = Configurações
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = O novo perfil terá cópia de suas configurações, extensões, histórico e dados salvos como favoritos e senhas, mas não informações de sua conta ou de sincronização.
    .label = Copiar um perfil existente
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Perfil a copiar
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Selecionar perfil
preferences-copy-profile-button = Copiar
tabs-browsing-section =
    .heading = Abas e navegação
pane-tabs-browsing-title2 = Abas e navegação
    .title = Abas e navegação
tabs-group-header2 =
    .label = Abas
tabs-opening-heading =
    .label = Abertura
tabs-interaction-heading =
    .label = Interação
tabs-containers-heading =
    .label = Contêineres
tabs-closing-heading =
    .label = Fechamento
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab alternar entre abas por ordem de uso
    .accesskey = T
open-new-link-as-tabs =
    .label = Abrir links em abas em vez de novas janelas
    .accesskey = j
open-external-link-next-to-active-tab =
    .label = Abrir links de aplicativos ao lado da aba ativa
ask-on-close-multiple-tabs =
    .label = Perguntar antes de fechar várias abas
    .accesskey = v
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Perguntar antes de sair com { $quitKey }
    .accesskey = n
warn-on-open-many-tabs =
    .label = Ao abrir muitas abas, avisar que o { -brand-short-name } pode ficar lento
    .accesskey = m
switch-to-new-tabs-2 =
    .label = Ao abrir links ou mídias em uma nova aba, mudar para ela imediatamente
    .accesskey = k
show-tabs-in-taskbar =
    .label = Mostrar conteúdo de abas na barra de tarefas do Windows
    .accesskey = f
browser-containers-enabled-2 =
    .label = Usar abas contêiner
    .accesskey = n
browser-containers-learn-more = Saiba mais
browser-containers-settings-2 =
    .label = Gerenciar configurações
    .accesskey = f
containers-disable-alert-title = Fechar todas as abas contêiner?
startup-group =
    .label = Iniciar

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Se desativar abas contêiner agora, { $tabCount } aba contêiner será fechada. Tem certeza que quer desativar abas contêiner?
       *[other] Se desativar abas contêiner agora, { $tabCount } abas contêiner serão fechadas. Tem certeza que quer desativar abas contêiner?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Fechar { $tabCount } aba contêiner
       *[other] Fechar { $tabCount } abas contêiner
    }

##

containers-disable-alert-cancel-button = Manter ativado
containers-remove-alert-title = Remover este contêiner?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Se você remover este contêiner agora, { $count } aba contêiner será fechada. Tem certeza que quer remover este contêiner?
       *[other] Se você remover este contêiner agora, { $count } abas contêiner serão fechadas. Tem certeza que quer remover este contêiner?
    }
containers-remove-ok-button = Remover este contêiner
containers-remove-cancel-button = Não remover este contêiner
settings-tabs-show-image-in-preview =
    .label = Exibir uma imagem prévia ao passar o mouse sobre uma aba
    .accessKey = b
settings-tabs-drag-to-create-tab-groups =
    .label = Arrastar abas juntas para criar grupos de abas
browser-layout-header2 =
    .label = Disposição do navegador
browser-layout-horizontal-tabs2 =
    .description = Abas no alto
    .label = Abas na horizontal
    .title = Abas no alto
browser-layout-vertical-tabs2 =
    .description = Abas ao lado, no painel lateral
    .label = Abas na vertical
    .title = Abas ao lado, no painel lateral
browser-layout-show-sidebar2 =
    .description = Acesse rapidamente favoritos, abas do seu celular, chatbots de inteligência artificial e muito mais sem sair da visão principal.
    .label = Mostrar painel lateral
page-navigation-group =
    .label = Navegação em páginas

## General Section - Language & Appearance

language-and-appearance-header = Idioma e aparência
appearance-group2 =
    .description = Alguns sites mudam as cores para combinar com suas preferências. Escolha seu esquema de cores.
    .label = Aparência de sites
preferences-web-appearance-choice-auto3 =
    .label = Sistema
    .title = Mudar automaticamente o fundo e o conteúdo de sites com base na configuração do seu sistema e no tema do { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Claro
    .title = Usar uma aparência clara no fundo e conteúdo de sites.
preferences-web-appearance-choice-dark2 =
    .label = Escuro
    .title = Usar uma aparência escura no fundo e conteúdo de sites.
web-appearance-group =
    .aria-label = Aparência de sites
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Sua configuração de controle de contraste está sobrepondo a aparência de sites.
preferences-web-appearance-link =
    .label = Gerencie temas do { -brand-short-name } em Extensões e temas
preferences-contrast-control-group =
    .description = Sites usam uma variedade de cores de frente e de fundo. Para obter um contraste consistente, você pode usar as mesmas cores em todos os sites.
    .label = Contraste de sites
preferences-contrast-control-radio-group =
    .label = Substituir cores
preferences-contrast-control-use-platform-settings =
    .label = Automático (usar configuração do sistema)
    .accesskey = A
preferences-contrast-control-off =
    .label = Desativado
    .accesskey = D
preferences-contrast-control-custom =
    .label = Personalizado
    .accesskey = P
preferences-colors-manage-button2 =
    .label = Gerenciar cores
    .accesskey = c
preferences-colors-manage-button =
    .label = Gerenciar cores…
    .accesskey = c
preferences-fonts-header2 =
    .label = Fontes
preferences-default-zoom-label =
    .label = Zoom padrão
    .accesskey = Z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Zoom só no texto
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Se estiver ativado “Zoom apenas no texto” e seu nível de zoom padrão não for 100%, alguns sites podem não exibir o conteúdo corretamente.
language-header = Idioma
choose-language-description = Escolha o idioma preferido para exibir páginas
website-language-heading =
    .description = Algumas páginas do site são exibidas em vários idiomas. Escolha idiomas em sua ordem de preferência.
    .label = Idioma do site
website-preferred-language =
    .label = Idiomas preferidos
website-language-list =
    .aria-label = Idiomas preferidos
website-add-language =
    .label = Adicionar idioma
website-add-language-button =
    .aria-label = Adicionar idioma selecionado
    .title = Adicionar idioma selecionado
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Remover { $locale }
    .title = Remover { $locale }
choose-button =
    .label = Selecionar…
    .accesskey = S
choose-browser-language-description = Escolha o idioma usado para exibir menus, mensagens e notificações do { -brand-short-name }
manage-browser-languages-button =
    .label = Definir alternativas…
    .accesskey = l
confirm-browser-language-change-description = Reiniciar o { -brand-short-name } para aplicar estas alterações
confirm-browser-language-change-button = Aplicar e reiniciar
browser-language-heading =
    .description = Escolher o idioma usado para exibir menus, mensagens e notificações do { -brand-short-name }.
    .label = Idioma do navegador
browser-language-preferred-label =
    .label = Idioma preferido
browser-language-fallback-label =
    .description = Usado quando a tradução para o idioma de preferência está incompleta.
    .label = Idioma alternativo
browser-language-install-error =
    .message = O { -brand-short-name } não pode atualizar seus idiomas agora. Verifique se você está conectado à Internet e tente novamente.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Exceções…
    .accesskey = x
settings-translations-header =
    .aria-label = Traduções
    .description = Traduza páginas ou texto selecionado. Para proteger sua privacidade, as traduções ficam no seu dispositivo.
    .label = Traduções
settings-translations-offer-to-translate-label =
    .label = Oferecer tradução de página inteira
settings-translations-more-settings-button =
    .description = Defina preferências de idiomas, sites e tradução offline.
    .label = Mais configurações de tradução
settings-translations-subpage-header =
    .heading = Mais configurações de tradução
settings-translations-subpage-speed-up-translation-header =
    .description = Baixe idiomas completos para traduções mais rápidas e para traduzir offline.
    .label = Acelerar tradução
settings-translations-subpage-automatic-translation-header =
    .label = Tradução automática
settings-translations-subpage-always-translate-header =
    .label = Sempre traduzir destes idiomas
settings-translations-subpage-never-translate-header =
    .label = Nunca traduzir destes idiomas
settings-translations-subpage-never-translate-sites-header =
    .label = Nunca traduzir estes sites
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Para adicionar um site, abra o painel de tradução <img data-l10n-name="translations-icon"/>, selecione as configurações de tradução <img data-l10n-name="settings-icon"/> e escolha “Nunca traduzir este site”.
settings-translations-subpage-language-select-option =
    .label = Adicionar idioma
settings-translations-subpage-language-add-button =
    .aria-label = Adicionar idioma
    .title = Adicionar idioma
settings-translations-subpage-download-languages-header =
    .label = Baixar idiomas
settings-translations-subpage-download-languages-select-option =
    .label = Selecionar idioma
settings-translations-subpage-download-languages-button =
    .aria-label = Baixar idioma
    .title = Baixar idioma
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Nenhum idioma baixado
settings-translations-subpage-no-languages-added =
    .label = Nenhum idioma adicionado
settings-translations-subpage-download-progress = Transferência em andamento…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Não foi possível baixar { $language } ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Tentar novamente
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Excluir { $language } ({ $size } MB)?
settings-translations-subpage-download-delete-button =
    .label = Excluir
settings-translations-subpage-download-cancel-button =
    .label = Cancelar
settings-translations-subpage-no-sites-added =
    .label = Nenhum site adicionado
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Usar as configurações de “{ $localeName }” do sistema operacional para formatar datas, horários, números e medidas.
settings-spellcheck-header =
    .label = Correção ortográfica
check-user-spelling =
    .label = Verificar a ortografia ao digitar
    .accesskey = t
spellcheck-download-dictionaries =
    .label = Baixar dicionários
spellcheck-promo =
    .heading = Como usar a verificação ortográfica
    .message = Clique com o botão direito em um campo de texto para ativar ou desativar a verificação ortográfica, ou mudar o idioma. Nem todos os campos oferecem suporte a verificação ortográfica.

## Downloads - Files and applications

files-and-applications-title = Arquivos e aplicativos
download-save-files-header =
    .label = Salvar arquivos em
download-save-where-3 =
    .aria-label = Salvar arquivos em
download-always-ask-where2 =
    .label = Perguntar onde salvar arquivos antes de baixar
    .accesskey = P
download-private-browsing-delete2 =
    .label = Excluir arquivos baixados de janelas privativas ao fechar
    .accesskey = E
applications-header = Aplicativos
applications-description = Escolha o que o { -brand-short-name } deve fazer com os arquivos que você baixa e aplicativos que você usa ao navegar.
applications-setting2 =
    .description = Escolher como o { -brand-short-name } lida com arquivos e conteúdo baixados.
    .label = Arquivos e aplicativos
applications-filter =
    .placeholder = Pesquisar tipos de arquivos ou aplicativos
applications-type-column =
    .label = Tipo de conteúdo
    .accesskey = T
applications-type-heading = Tipo de conteúdo
applications-action-column =
    .label = Ação
    .accesskey = A
applications-action-heading = Ação
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = arquivo { $extension }
applications-action-save =
    .label = Salvar arquivo
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Usar { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Usar { $app-name } (padrão)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Usar aplicação padrão do macOS
            [windows] Usar aplicação padrão do Windows
           *[other] Usar aplicação padrão do sistema
        }
applications-use-other =
    .label = Abrir com…
applications-select-helper = Selecionar aplicativo
applications-manage-app =
    .label = Detalhes do aplicativo…
applications-always-ask =
    .label = Sempre perguntar
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Abrir no { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = O que o { -brand-short-name } deve fazer com outros arquivos?
applications-save-for-new-types =
    .label = Salvar arquivos
    .accesskey = S
applications-save-for-new-types2 =
    .label = Salvar arquivos automaticamente
    .accesskey = S
applications-ask-before-handling =
    .label = Perguntar se deve abrir ou salvar arquivos
    .accesskey = P
applications-ask-before-handling2 =
    .label = Pedir para abrir ou salvar arquivos
    .accesskey = P
drm-group =
    .label = Conteúdo DRM (gerenciamento de direitos digitais)
play-drm-content =
    .label = Reproduzir conteúdo controlado por DRM
    .accesskey = R
play-drm-content-learn-more = Saiba mais
# Variables:
# $version (string) - Firefox version
update-application-version = Versão { $version } <a data-l10n-name="learn-more">Novidades</a>
update-history-2 =
    .label = Mostrar histórico de atualizações
    .accesskey = h
update-application-installation =
    .label = Instalação
update-application-radio-group =
    .aria-label = Instalação
update-application-auto-2 =
    .label = Instalar atualizações automaticamente (recomendado)
    .accesskey = m
update-application-check-choose-2 =
    .label = Verificar se há atualizações, mas escolher quando instalar
    .accesskey = V
update-application-background-enabled =
    .label = Quando o { -brand-short-name } não estiver sendo executado
    .accesskey = Q
update-application-warning-cross-user-setting-2 =
    .message = Esta configuração se aplica a todas as contas do Windows e perfis do { -brand-short-name } que usam esta instalação do { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Mostrar menos lembretes de atualização
    .accesskey = n
update-setting-write-failure-title2 = Erro ao salvar configurações de atualização
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    O { -brand-short-name } encontrou um erro e não salvou esta alteração. Note que alterar esta configuração de atualização requer permissão para gravar no arquivo abaixo. Você ou um administrador do sistema pode conseguir resolver o erro dando ao grupo 'Users' total controle sobre este arquivo.
    
    Não foi possível gravar no arquivo: { $path }
update-in-progress-title = Atualização em andamento
update-in-progress-message = Quer que o { -brand-short-name } continue esta atualização?
update-in-progress-ok-button = &Descartar
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Continuar

## About Firefox

about-firefox-header =
    .heading = Sobre o { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Atualizações melhoram a velocidade, estabilidade e segurança do { -brand-short-name }.
    .label = Atualização do { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Notificações
update-application-updates-managed-by-os =
    .message = As atualizações são gerenciadas pelo seu sistema operacional

## Firefox support

support-application-heading =
    .description = Resolva problemas ou compartilhe ideias com a comunidade.
    .label = Suporte do { -brand-short-name }
support-get-help =
    .label = Obtenha ajuda
support-share-ideas =
    .label = Compartilhar ideias e opiniões

## Firefox newsletter

newsletter-settings-heading =
    .description = Receba guias, conselhos e novidades para tornar sua experiência de uso do { -brand-product-name } melhor para você.
    .label = Boletim informativo do { -brand-product-name }
newsletter-sign-up-link =
    .label = Criar uma conta

## General Section - Performance

performance-settings-learn-more = Saiba mais
performance-allow-hw-accel =
    .label = Usar aceleração de hardware quando disponível
    .accesskey = r
performance-limit-content-process-option = Limite de processos de conteúdo
    .accesskey = L
performance-limit-content-process-enabled-desc = Processos de conteúdo adicionais podem melhorar o desempenho ao usar várias abas, mas também usam mais memória.
performance-limit-content-process-blocked-desc = Modificar o número de processos de conteúdo só é possível com o multiprocessamento do { -brand-short-name }. <a data-l10n-name="learn-more">Saiba como verificar se o multiprocessamento está ativado</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (padrão)
performance-group =
    .label = Desempenho
performance-use-recommended-settings-checkbox-2 =
    .description = Essas configurações são feitas sob medida para seu equipamento e sistema operacional.
    .label = Usar configurações de desempenho recomendadas
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = Usar rolagem automática
    .accesskey = a
keyboard-and-scrolling-group =
    .label = Navegação e rolagem pelo teclado
motion-and-link-group =
    .label = Animação e estilo de links
browsing-use-smooth-scrolling =
    .label = Usar rolagem suave
    .accesskey = m
browsing-gtk-use-non-overlay-scrollbars =
    .label = Sempre mostrar barras de rolagem
    .accesskey = o
browsing-always-underline-links =
    .label = Sempre sublinhar links
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = Mostrar um teclado sensível ao toque quando necessário
    .accesskey = t
browsing-use-cursor-navigation =
    .label = Sempre usar as teclas de cursor para navegar dentro das páginas
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = Use a tecla “tab” para mover o foco entre controles de formulário e links
    .accesskey = t
browsing-search-on-start-typing =
    .label = Procurar texto quando começar a digitar
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = Controle como você navega e interage com o { -brand-short-name }.
    .label = Atalhos de teclado
settings-keyboard-shortcuts-customkeys-link =
    .label = Personalizar atalhos de teclado
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Personalizar configurações da barra de endereços, em Pesquisa
settings-media-group =
    .label = Mídia
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Usar picture-in-picture
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Continuar a reproduzir vídeos em picture-in-picture ao mudar de aba
    .accesskey = s
browsing-media-control =
    .label = Controlar mídia via teclado, fone de ouvido ou interface virtual
    .accesskey = v
recommendations-group =
    .label = Recomendações
browsing-cfr-recommendations =
    .label = Recomendar extensões enquanto você navega
    .accesskey = R
browsing-cfr-features =
    .label = Recomendar recursos enquanto você navega
    .accesskey = R
browsing-group =
    .label = Navegação
preferences-accessibility-header =
    .heading = Acessibilidade
preferences-default-zoom-select =
    .aria-label = Zoom padrão
preferences-fonts-family =
    .label = Família da fonte
    .accesskey = D
preferences-fonts-size =
    .label = Tamanho da fonte
    .accesskey = T
preferences-fonts-advanced-settings =
    .label = Configurações avançadas
    .accesskey = v

## General Section - Proxy

network-proxy-group2 =
    .description = Configure como o { -brand-short-name } se conecta com a internet.
    .label = Configurações de proxy
network-proxy-connection-settings2 =
    .description = Mudar essas configurações pode causar problemas de conexão
    .label = Configurar proxy
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Novas janelas e abas
home-new-windows-tabs-description2 = Escolha o que aparece ao abrir a página inicial, novas janelas e novas abas.
home-section =
    .heading = Página inicial e inicialização

## Home Section - Default Browser

home-default-browser-title =
    .label = Navegador padrão
is-default-browser-2 =
    .message = { -brand-short-name } é o seu navegador padrão. Ótima escolha.
is-not-default-browser-2 =
    .message = Ei, o { -brand-short-name } não é o navegador padrão.
set-as-my-default-browser-2 =
    .label = Definir como padrão
    .accesskey = D

## Custom Homepage subpage

home-homepage-mode-label = Página inicial e novas janelas
home-newtabs-mode-label = Novas abas
home-restore-defaults =
    .label = Restaurar padrão
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (padrão)
home-mode-choice-custom =
    .label = Endereço personalizado…
home-mode-choice-blank =
    .label = Página vazia
home-homepage-custom-url =
    .placeholder = Cole uma URL...
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Gerenciar extensão
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Usar a página aberta
           *[other] Usar as páginas abertas
        }
    .accesskey = a
choose-bookmark =
    .label = Usar favorito…
    .accesskey = f
home-homepage-title =
    .label = Página inicial
home-homepage-new-windows =
    .label = Novas janelas
home-homepage-new-tabs =
    .label = Novas abas
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Escolher um site específico
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Endereços de sites
home-custom-homepage-list =
    .aria-label = Endereços de sites
home-custom-homepage-address =
    .placeholder = Inserir endereço
home-custom-homepage-address-button =
    .label = Adicionar endereço
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Nenhum site adicionado ainda.
home-custom-homepage-delete-address-button =
    .aria-label = Excluir endereço
    .title = Excluir endereço
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Substituir por
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Páginas abertas no momento
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Favoritos…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Extensão ({ $extension })
home-custom-homepage-header = Página inicial personalizada
home-custom-homepage-subpage =
    .heading = Página inicial personalizada

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Conteúdo da { -firefox-home-brand-name }
home-prefs-content-description2 = Escolha que conteúdo você quer na { -firefox-home-brand-name }.
home-prefs-search-header =
    .label = Campo de pesquisa na web
home-prefs-shortcuts-header =
    .label = Atalhos
home-prefs-shortcuts-description = Sites que você salva ou visita
home-prefs-shortcuts-by-option-sponsored =
    .label = Atalhos patrocinados
home-prefs-recommended-by-header-generic =
    .label = Histórias recomendadas
home-prefs-recommended-by-description-generic = Conteúdo excepcional selecionado pela família { -brand-product-name }
home-prefs-stories-header =
    .label = Histórias
home-prefs-stories-description = Histórias personalizadas com base na sua atividade

##

home-prefs-recommended-by-learn-more = Como funciona
home-prefs-recommended-by-option-sponsored-stories =
    .label = Histórias patrocinadas
home-prefs-highlights-option-visited-pages =
    .label = Páginas visitadas
home-prefs-highlights-options-bookmarks =
    .label = Favoritos
home-prefs-highlights-option-most-recent-download =
    .label = Downloads mais recentes
home-prefs-recent-activity-header =
    .label = Atividade recente
home-prefs-recent-activity-description = Uma seleção de sites e conteúdos recentes
home-prefs-weather-header =
    .label = Tempo
home-prefs-weather-description = Visão geral da previsão para hoje
home-prefs-weather-learn-more-link = Saiba mais
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Apoie o { -brand-product-name }
home-prefs-mission-message = Nossos patrocinadores apoiam nossa missão de construir uma web melhor
home-prefs-mission-message-learn-more-link = Descubra como
home-prefs-manage-topics-link = Gerenciar tópicos
home-prefs-choose-wallpaper-link = Escolher um fundo de tela
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } linha
           *[other] { $num } linhas
        }

## Search Section

search-show-suggestions-option =
    .label = Mostrar sugestões de pesquisa
    .accesskey = M
search-show-suggestions-url-bar-option =
    .label = Mostrar sugestões de pesquisa nos resultados da barra de endereços
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Mostrar sugestões de pesquisa antes do histórico de navegação nos resultados da barra de endereços
search-show-suggestions-private-windows-2 =
    .label = Sugestões de pesquisa em janelas privativas
search-suggestions-cant-show-2 =
    .message = As sugestões de pesquisa não serão mostradas nos resultados da barra de endereço, porque você configurou o { -brand-short-name } para nunca memorizar o histórico.
addressbar-header-1 =
    .description = Escolher quais sugestões exibir na barra de endereços
    .label = Barra de endereços
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Sugestões do { -brand-short-name } e de nossos parceiros na barra de endereços.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Mostrar termos de pesquisa na barra de endereços em páginas de resultados
search-separate-default-engine-2 =
    .label = Usar outro mecanismo de pesquisa padrão em janelas privativas
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = Mecanismo de pesquisa padrão em janelas privativas
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Navegação na barra de endereços
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Pular o menu de resultados ao usar a tecla tab para mover o foco
search-suggestions-header-2 =
    .label = Sugestões de mecanismos de pesquisa
search-one-click-header2 = Atalhos de pesquisa
search-one-click-desc = Escolha os mecanismos de pesquisa alternativos que aparecem abaixo da barra de endereços e da barra de pesquisa quando você começa a digitar um atalho.
search-one-click-header-3 =
    .description = Escolha quais mecanismos de pesquisa e atalhos devem aparecer na barra de endereços.
    .label = Mecanismos de pesquisa adicionais
search-engine-list =
    .aria-label = Mecanismos de pesquisa e atalhos
update-search-engine-success =
    .message = Mecanismo de pesquisa atualizado com sucesso
search-edit-engine-2 =
    .title = Editar mecanismo de pesquisa
search-delete-engine =
    .title = Excluir mecanismo de pesquisa
search-enable-engine =
    .title = Ativar mecanismo de pesquisa
search-outlink-to-extensions-page =
    .title = Gerenciamento de extensões e temas
search-choose-engine-column =
    .label = Mecanismo de pesquisa
search-choose-keyword-column =
    .label = Atalho
search-restore-default =
    .label = Restaurar mecanismos de pesquisa padrão
    .accesskey = p
search-remove-engine =
    .label = Remover
    .accesskey = R
search-add-engine =
    .label = Adicionar
    .accesskey = A
search-add-engine-2 =
    .label = Adicionar mecanismo de pesquisa
    .accesskey = A
search-edit-engine =
    .label = Editar
    .accesskey = E
search-find-more-link = Procurar mais mecanismos de pesquisa
search-filtering-for-add-engine = Adicionar mecanismo
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Atalho duplicado
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Este atalho já está sendo usado para o “{ $name }”. Escolha outro.
search-keyword-warning-bookmark = Este atalho já está sendo usado em um favorito. Escolha outro.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Já existe um mecanismo de pesquisa com o nome “{ $name }”. Escolha outro nome.
remove-engine-confirmation = Tem certeza que quer remover este mecanismo de pesquisa?
remove-engine-remove = Remover
remove-addon-engine-alert = Para remover este mecanismo de pesquisa, remova a extensão associada.
search-engine-group =
    .label = Mecanismo de pesquisa padrão
search-default-engine =
    .aria-label = Mecanismo de pesquisa padrão
# Header for the search section ("search" is a noun).
search-section =
    .heading = Pesquisar

## Containers Section

containers-section-header2 =
    .heading = Configurações de contêineres
containers-card-header2 =
    .description = Separe cookies por contêiner para poder usar contas diferentes no mesmo site e limitar o rastreamento entre sites.
    .label = Contêineres
containers-add-button2 =
    .label = Adicionar novo contêiner
    .accesskey = A
containers-list =
    .aria-label = Contêineres
containers-new-tab-check3 =
    .label = Selecionar um contêiner para cada nova aba
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Não usar contêineres em links abertos de aplicativos externos
    .accesskey = N
containers-new-tab-check2 =
    .description = Abre o menu de contêineres sempre que você clicar no botão de nova aba.
    .label = Selecionar um contêiner para cada nova aba
    .accesskey = S
containers-settings-button2 =
    .title = Configurações
containers-remove-button3 =
    .title = Excluir
containers-sites-card-header =
    .description = Escolha um contêiner para um site e o { -brand-short-name } o usará toda vez que o site for aberto.
    .label = Contêineres de sites especificos
containers-sites-add-button =
    .label = Adicionar site
    .accesskey = s
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Contêiner de { $site }
containers-site-remove-button =
    .title = Excluir
containers-remove-button2 =
    .title = Remover

## Account and sync

sync-group-label =
    .label = Sincronização
account-group-label2 =
    .label = Conta
account-disabled-group =
    .description = As configurações da conta não estão disponíveis.
    .label = Conta
account-placeholder2 =
    .description = Entre na sua conta e mantenha seus dados privativos, criptografados e acessíveis imediatamente onde quer que use o { -brand-short-name }.
    .label = Você não está conectado.
account-sync-section =
    .heading = Conta e sincronização
pane-account-sync-title2 = Conta e sincronização
    .title = Conta e sincronização

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Leve a web com você
sync-signedout-description2 = Sincronize seus favoritos, histórico, abas, senhas, extensões e configurações em todos os seus dispositivos.
sync-signedout-account-signin3 =
    .label = Entrar na conta para sincronizar…
    .accesskey = E
sync-signedout-account-signin-4 =
    .label = Entre na sua conta para iniciar a sincronização
    .accesskey = i
sync-signedout-account-short =
    .label = Entrar
    .accesskey = E
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Instale o Firefox no <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> ou <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> para sincronizar com seu dispositivo móvel.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Alterar imagem do perfil
    .tooltiptext = Alterar imagem do perfil
sync-profile-picture-account-problem =
    .alt = Imagem do perfil da conta
fxa-login-rejected-warning =
    .alt = Alerta
sync-sign-out =
    .label = Desconectar…
    .accesskey = D
sync-sign-out2 =
    .label = Desconectar
    .accesskey = D
sync-manage-account = Gerenciar conta
    .accesskey = o
sync-manage-account2 =
    .label = Gerenciar conta
    .accesskey = o

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } não foi verificado.
sync-signedin-unverified2 =
    .description = Verifique sua caixa de entrada para confirmar sua conta e a tornar oficial.
    .label = { $email } ainda não foi confirmado
sync-signedin-login-failure = Entre para reconectar { $email }
sync-signedin-login-failure2 =
    .description = Entre novamente na sua conta para reconectar e começar a sincronizar seus dados.
    .label = Você está desconectado do { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Verificar conta
    .accesskey = V
sync-remove-account =
    .label = Remover conta
    .accesskey = R
sync-sign-in =
    .label = Entrar
    .accesskey = t

## Sync section - enabling or disabling sync.

prefs-syncing-on = Sincronização: ATIVADA
prefs-syncing-on-2 =
    .label = Sincronização ATIVADA
prefs-syncing-off = Sincronização: DESATIVADA
prefs-syncing-off-2 =
    .description = Ative a sincronização para ter seus favoritos, senhas, histórico e outras informações em qualquer dispositivo.
    .label = Sincronização DESATIVADA
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Ative a sincronização para ter seus favoritos, senhas, histórico e mais neste dispositivo.
    .label = Sincronização DESATIVADA
prefs-sync-turn-on-syncing =
    .label = Ativar sincronização…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Ativar sincronização
    .accesskey = s
prefs-sync-offer-setup-label2 = Sincronize seus favoritos, histórico, abas, senhas, extensões e configurações em todos os seus dispositivos.
prefs-sync-now-button =
    .label = Sincronizar agora
    .accesskey = n
prefs-sync-now-button-2 =
    .label = Sincronizar agora
    .accesskey = n
prefs-syncing-button =
    .label = Sincronizando…
prefs-syncing-button-2 =
    .label = Sincronizando…
    .title = Sincronizar agora
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Suas preferências de sincronização agora se aplicam somente a este dispositivo.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Estes itens estão sendo sincronizados em todos os seus dispositivos conectados:
sync-syncing-across-devices-heading-2 = Dados sincronizados entre dispositivos
sync-syncing-across-devices-heading-3 = Sincronização de dados neste dispositivo
sync-syncing-across-devices-empty-state2 =
    .description = Você não tem nada sendo sincronizado… ainda. Inicie a sincronização para ter todos os seus dados em todos os seus dispositivos.
    .label = Gerenciar dados sincronizados
sync-syncing-across-devices-empty-state3 =
    .description = Não está sincronizando nada... ainda. Escolha o que sincronizar neste dispositivo.
    .label = Gerenciar dados sincronizados
sync-currently-syncing-bookmarks = Favoritos
sync-currently-syncing-history = Histórico
sync-currently-syncing-tabs = Abas abertas
sync-currently-syncing-passwords = Senhas
sync-currently-syncing-addresses = Endereços
sync-currently-syncing-payment-methods = Métodos de pagamento
sync-currently-syncing-addons = Extensões
sync-currently-syncing-settings = Configurações
sync-manage-options =
    .label = Gerenciar sincronização…
    .accesskey = G
sync-manage-options-2 =
    .label = Gerenciar dados sincronizados
    .accesskey = G
settings-sync-disconnect-button =
    .label = Desconectar

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Favoritos
    .accesskey = F
sync-engine-history =
    .label = Histórico
    .accesskey = H
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Abrir abas
    .tooltiptext = Abrir abas de seus outros dispositivos
    .accesskey = b
sync-engine-tabs =
    .label = Abas abertas
    .tooltiptext = Uma lista do que está aberto em todos os dispositivos sincronizados
    .accesskey = A
sync-engine-passwords =
    .label = Senhas
    .tooltiptext = Senhas que você salvou
    .accesskey = S
sync-engine-addresses2 =
    .label = Endereços
    .tooltiptext = Endereços que você salvou no { -brand-short-name }
    .accesskey = E
sync-engine-payment-methods3 =
    .label = Métodos de pagamento
    .tooltiptext = Métodos de pagamento que você salvou
    .accesskey = M
sync-engine-addons2 =
    .label = Extensões
    .tooltiptext = Extensões e temas que você adicionou ao { -brand-short-name } de computador
    .accesskey = E
sync-engine-settings2 =
    .label = Configurações
    .tooltiptext = Configurações do { -brand-short-name }, onde se aplicam
    .accesskey = C
sync-engine-addresses =
    .label = Endereços
    .tooltiptext = Endereços postais que você salvou (computador apenas)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = Métodos de pagamento
    .tooltiptext = Nomes, números de cartões e datas de validade
    .accesskey = n
sync-engine-addons =
    .label = Extensões
    .tooltiptext = Extensões e temas para o Firefox no computador
    .accesskey = x
sync-engine-settings =
    .label = Configurações
    .tooltiptext = Configurações gerais, de privacidade e segurança que você alterou
    .accesskey = C
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Salvar
    .buttonlabelextra2 = Desconectar…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Gerencie o que é sincronizado em todos os seus dispositivos conectados
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Salvar
    .buttonlabelextra2 = Desconectar…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Gerenciar o que é sincronizado neste dispositivo

## The device name controls.

sync-device-name-header = Nome do dispositivo
sync-device-name-header-2 =
    .label = Nome do dispositivo
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Nome do dispositivo
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Alterar nome do dispositivo
    .accesskey = n
sync-device-name-change =
    .label = Alterar nome do dispositivo…
    .accesskey = n
sync-device-name-cancel =
    .label = Cancelar
    .accesskey = n
sync-device-name-save =
    .label = Salvar
    .accesskey = v
sync-connect-another-device = Conectar outro dispositivo
sync-connect-another-device-2 =
    .label = Conectar outro dispositivo

## Privacy Section

privacy-header = Privacidade do navegador

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Senhas
    .searchkeywords = contas
forms-passwords-header =
    .aria-label = Senhas
    .label = Senhas
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Perguntar se quer salvar senhas
    .accesskey = P
forms-manage-password-exceptions =
    .label = Gerenciar exceções de senha
    .accesskey = G
forms-exceptions =
    .label = Exceções…
    .accesskey = x
forms-suggest-passwords =
    .label = Sugerir senhas fortes
    .accesskey = S
forms-breach-alerts =
    .label = Exibir alertas sobre senhas de sites vazados
    .accesskey = v
forms-breach-alerts-learn-more-link = Saiba mais
preferences-relay-integration-checkbox2 =
    .label = Sugerir máscaras de email do { -relay-brand-name } para proteger seu endereço de email
    .accesskey = r
relay-integration-learn-more-link = Saiba mais
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Preencher nomes de usuário e senhas automaticamente
    .accesskey = P
forms-fill-usernames-and-passwords-2 =
    .label = Salvar e preencher automaticamente nomes de usuário e senhas
    .accesskey = h
forms-saved-passwords =
    .label = Senhas salvas
    .accesskey = h
forms-saved-passwords-2 =
    .label = Gerenciar senhas salvas
    .accesskey = s
forms-saved-passwords-searchkeywords = As contas de acesso dos seguintes sites estão armazenadas neste computador
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Proteções adicionais
forms-primary-pw-use =
    .label = Usar uma senha principal
    .accesskey = U
forms-primary-pw-use-2 =
    .description = Adicionar uma camada adicional de segurança para proteger suas senhas salvas.
    .label = Usar uma senha principal
    .accesskey = U
forms-primary-pw-set =
    .label = Definir senha principal
forms-primary-pw-on-2 = A senha principal está <strong>ATIVADA</strong>
forms-primary-pw-on =
    .label = Senha principal está ATIVADA
forms-primary-pw-change-2 =
    .label = Mudar senha principal
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Desativar
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Exigir autenticação do dispositivo para preencher e gerenciar senhas
forms-os-reauth-2 =
    .label = Exigir autenticação do dispositivo para gerenciar senhas
forms-primary-pw-learn-more-link = Saiba mais
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Alterar senha mestra…
    .accesskey = m
forms-primary-pw-change =
    .label = Alterar senha principal…
    .accesskey = p
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = Anteriormente conhecida como senha mestra
forms-primary-pw-fips-title = Você está no momento no modo FIPS. O FIPS exige uma senha principal não vazia.
forms-master-pw-fips-desc = Falha na alteração da senha
forms-windows-sso =
    .label = Permitir autenticação única (single sign-on) do Windows em contas da Microsoft no trabalho e na escola
forms-windows-sso-learn-more-link = Saiba mais
forms-windows-sso-desc = Gerencie contas nas configurações do seu dispositivo
windows-passkey-settings-label = Gerenciar chaves de acesso nas configurações do sistema
privacy-panel-settings-header =
    .description = Obtenha ajuda para proteger suas informações online no { -brand-short-name }.
    .label = Configurações do painel de privacidade
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Mostrar mensagens de vazamentos
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Para criar uma senha principal, insira suas credenciais de acesso ao Windows. Isso ajuda a proteger a segurança de suas contas.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = criar uma senha principal
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] alterar configurações de métodos de pagamento
       *[other] O { -brand-short-name } está tentando alterar configurações de métodos de pagamento. Use a autenticação do dispositivo para permitir.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Métodos de pagamento
autofill-payment-methods-checkbox-message-2 =
    .label = Salvar e preencher automaticamente informações de pagamento
    .accesskey = g
autofill-payment-methods-manage-payments-title =
    .heading = Gerenciar métodos de pagamento
autofill-payment-methods-manage-payments-button =
    .label = Gerenciar métodos de pagamento
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Exigir autenticação do dispositivo para preencher automaticamente
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Exigir autenticação do dispositivo para preencher automaticamente e gerenciar métodos de pagamento
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Salvar códigos de segurança
    .accesskey = c
autofill-payment-methods-add-button = Adicionar novo método de pagamento
payments-list-header =
    .label = Métodos de pagamento
payments-delete-payment-prompt-title = Excluir este método de pagamento?
payments-delete-payment-prompt-confirm-button = Excluir
payments-delete-payment-prompt-cancel-button = Cancelar
payments-delete-payment-button-label =
    .aria-label = Excluir
payments-edit-payment-button-label =
    .aria-label = Editar
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Nenhum método de pagamento adicionado
autofill-addresses-checkbox-message =
    .label = Salvar e preencher endereços automaticamente
    .accesskey = S
autofill-addresses-manage-addresses-button =
    .label = Gerenciar endereços e outras informações
    .accesskey = G
addresses-list-header =
    .label = Endereços
addreses-delete-address-button-label =
    .aria-label = Excluir
addreses-edit-address-button-label =
    .aria-label = Editar
addresses-delete-address-prompt-title = Excluir este endereço?
addresses-delete-address-prompt-confirm-button = Excluir
addresses-delete-address-prompt-cancel-button = Cancelar
autofill-addresses-add-button = Adicionar novo endereço
autofill-addresses-manage-addresses-title =
    .heading = Gerenciar endereços e outras informações
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Nenhum endereço adicionado
personal-info-group =
    .label = Informações pessoais
autofill-personal-info-checkbox-message =
    .label = Salvar e preencher informações pessoais automaticamente
autofill-personal-info-manage-button =
    .label = Gerenciar informações pessoais
passports-list-header =
    .label = Passaportes
passports-delete-passport-button-label =
    .aria-label = Excluir
passports-edit-passport-button-label =
    .aria-label = Editar
passports-delete-passport-prompt-title = Excluir este passaporte?
passports-delete-passport-prompt-confirm-button = Excluir
passports-delete-passport-prompt-cancel-button = Cancelar
autofill-passports-add-button = Adicionar novo passaporte
autofill-personal-info-manage-title =
    .heading = Gerenciar informações pessoais
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Nenhum passaporte adicionado
pane-passwords-autofill-title2 = Senhas e preenchimento automático
    .title = Senhas e preenchimento automático
preferences-passwords-autofill-header =
    .heading = Senhas e preenchimento automático
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Endereços e outras informações
payments-group =
    .label = Métodos de pagamento

## Privacy Section - History

history-remember-option-never2 =
    .description = Cada janela age como uma janela privativa. Quando ativado, extensões precisam ser permitidas.
    .label = Nunca memorizar o histórico
history-remember-option-custom2 =
    .label = Personalização do histórico
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = O { -brand-short-name } está memorizando seu histórico de navegação, downloads, formulários e pesquisas.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = O { -brand-short-name } está usando as mesmas configurações da navegação privativa, não memorizando nenhum histórico.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = O { -brand-short-name } usará configurações personalizadas no histórico de navegação, arquivos baixados, formulários e pesquisas.
history-private-browsing-permanent =
    .label = Sempre usar o modo de navegação privativa
    .accesskey = v
history-remember-browser-option =
    .label = Memorizar histórico de navegação e downloads
    .accesskey = h
history-remember-search-option =
    .label = Memorizar histórico de pesquisa e formulários
    .accesskey = z
history-clear-on-close-option =
    .label = Limpar histórico ao fechar o { -brand-short-name }
    .accesskey = i
history-clear-on-close-settings =
    .label = Configurações…
    .accesskey = C
history-shutdown-exceptions =
    .label = Gerenciar exceções
    .accesskey = x
history-clear-button =
    .label = Limpar histórico…
    .accesskey = h
history-header2 =
    .heading = Histórico
history-section-header =
    .description = Escolha o que você quer que o { -brand-short-name } memorize quando você fecha o navegador.
    .label = Histórico
history-custom-section-header =
    .description = Personalize o que você quer que o { -brand-short-name } memorize quando você fecha o navegador.
    .label = Configurações avançadas
history-custom-button =
    .label = Escolha o que você quer que o { -brand-short-name } memorize
history-group =
    .label = Histórico
history-mode-radio-group =
    .aria-label = Histórico
history-remember-option-all2 =
    .label = Memorizar o histórico

## Privacy Section - Site Data

sitedata-total-size-calculating = Calculando o tamanho dos dados de sites e do cache…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = No momento, sites estão usando <strong>{ $value } { $unit }</strong> de espaço em disco.
sitedata-learn-more = Saiba mais
sitedata-delete-on-close2 =
    .label = Limpar cookies e dados de sites sempre que fechar o { -brand-short-name }
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = Com base nas configurações do histórico, o { -brand-short-name } exclui cookies e dados de sites de sua sessão quando você fecha o navegador.
sitedata-delete-on-close-private-browsing4 =
    .heading = O histórico não é salvo
    .message = O { -brand-short-name } limpa cookies e dados de sites da sessão quando você fecha o navegador.
sitedata-option-block-cross-site-trackers =
    .label = Rastreadores entre sites
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cookies de rastreamento entre sites
sitedata-option-block-cross-site-cookies2 =
    .label = Isolar cookies entre sites
sitedata-option-block-unvisited =
    .label = Cookies de sites não visitados
sitedata-option-block-all-cross-site-cookies =
    .label = Todos os cookies entre sites (pode atrapalhar alguns sites)
sitedata-option-block-all =
    .label = Todos os cookies (atrapalha vários sites)
sitedata-clear2 =
    .label = Limpar dados de navegação
    .accesskey = L
sitedata-settings2 =
    .label = Gerenciar dados de navegação
    .accesskey = G
sitedata-cookies-exceptions =
    .label = Gerenciar exceções…
    .accesskey = x
sitedata-cookies-exceptions2 =
    .description = Você pode especificar quais sites sempre ou nunca têm permissão para usar cookies e dados de sites.
    .label = Gerenciar exceções
    .accesskey = x
sitedata-heading =
    .description = Gerencie seus cookies, histórico, cache, dados de sites e muito mais
    .label = Dados de navegação
sitedata-settings3 =
    .label = Limpar dados de sites específicos
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Escolha como lidar com cookies e dados de sites específicos.
    .label = Gerenciar exceções
    .accesskey = x
cookies-site-data-group =
    .label = Cookies e dados de sites

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Bloqueador de avisos de cookies
cookie-banner-blocker-description = Quando um site pergunta se pode usar cookies no modo de navegação privativa, o { -brand-short-name } recusa automaticamente para você. Somente em sites suportados.
cookie-banner-learn-more = Saiba mais
cookie-banner-blocker-checkbox-label =
    .label = Recusar avisos de cookies automaticamente

## Search Section

addressbar-locbar-history-option =
    .label = Histórico de navegação
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = Favoritos
    .accesskey = F
addressbar-locbar-clipboard-option =
    .label = Área de transferência
    .accesskey = t
addressbar-locbar-openpage-option =
    .label = Abas abertas
    .accesskey = A
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Atalhos
    .accesskey = s
addressbar-locbar-topsites-option =
    .label = Sites preferidos
    .accesskey = S
addressbar-locbar-engines-option-1 =
    .label = Sugerir mecanismos de pesquisa a usar
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = Ações rápidas
    .accesskey = A
addressbar-locbar-showrecentsearches-option-2 =
    .label = Pesquisas recentes
    .accesskey = P
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Sugestões de pesquisa em alta
    .accesskey = S
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Receba sugestões da web relacionadas à sua pesquisa.
    .label = Sugestões do { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Apoie o { -brand-short-name } com sugestões patrocinadas esporádicas.
    .label = Sugestões de patrocinadores
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Obter sugestões da Mozilla à medida que você digita
addressbar-dismissed-suggestions-label-2 =
    .description = Restaurar sugestões descartadas de patrocinadores e do { -brand-short-name }.
    .label = Sugestões descartadas
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Restaurar sugestões

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Proteção aprimorada contra rastreamento
content-blocking-section-top-level-description = Rastreadores tentam nos seguir por todo canto para coletar informações sobre nossos interesses e hábitos de navegação. O { -brand-short-name } bloqueia muitos desses rastreadores e outros códigos maliciosos.
content-blocking-learn-more = Saiba mais
content-blocking-fpi-incompatibility-warning = Você está usando isolamento primário (FPI), que substitui algumas configurações de cookies de { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Você está usando Resist Fingerprinting (RFP), que substitui algumas configurações de proteção contra rastreamento de identidade digital do { -brand-short-name }. Isso pode fazer com que alguns sites não funcionem corretamente.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Normal
    .accesskey = N
enhanced-tracking-protection-setting-strict =
    .label = Rigoroso
    .accesskey = R
enhanced-tracking-protection-setting-custom =
    .label = Personalizado
    .accesskey = e

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Balanceado entre proteção e desempenho. Páginas são carregadas normalmente.
content-blocking-etp-strict-desc = Proteção reforçada, mas pode atrapalhar alguns sites ou conteúdos.
content-blocking-etp-custom-desc = Escolha que rastreadores e scripts bloquear.
content-blocking-etp-blocking-desc = { -brand-short-name } bloqueia o seguinte:
content-blocking-private-windows = Conteúdo com rastreamento em janelas privativas
content-blocking-cross-site-cookies-in-all-windows2 = Cookies entre sites em todas as janelas
content-blocking-cross-site-tracking-cookies = Cookies de rastreamento entre sites
content-blocking-all-cross-site-cookies-private-windows = Cookies entre sites em janelas privativas
content-blocking-isolate-cross-site-cookies = Isolar cookies entre sites
content-blocking-social-media-trackers = Rastreadores de mídias sociais
content-blocking-all-cookies = Todos os cookies
content-blocking-unvisited-cookies = Cookies de sites não visitados
content-blocking-all-windows-tracking-content = Conteúdo com rastreamento em todas as janelas
content-blocking-all-cross-site-cookies = Todos os cookies entre sites
content-blocking-cryptominers = Criptomineradores
content-blocking-fingerprinters = Fingerprinters (rastreadores de identidade digital)
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Rastreadores de identidade digital (fingerprinters) suspeitos e conhecidos
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = A proteção total contra cookies isola os cookies do site em que você está, assim os rastreadores não conseguem usá-los para te seguir de um site para outro.
content-blocking-etp-standard-tcp-rollout-learn-more = Saiba mais
content-blocking-etp-standard-tcp-title = Inclui a proteção total contra cookies, nosso recurso de privacidade mais poderoso já feito
content-blocking-warning-title-2 = Alguns sites podem não funcionar corretamente com a proteção rigorosa contra rastreamento
content-blocking-warning-title-custom = Alguns sites podem não funcionar corretamente com a proteção personalizada contra rastreamento
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = O { -brand-short-name } recomenda usar a configuração “Corrigir problemas em sites” para reduzir funcionalidades e conteúdos com problemas em sites. Se um site parecer não funcionar corretamente, experimente desativar a proteção contra rastreamento no site para carregar todo o conteúdo.
content-blocking-warning-learn-how = Saiba como
content-blocking-baseline-exceptions-3 =
    .description = Ajuda a carregar sites e recursos, desbloqueando apenas elementos essenciais que podem conter rastreadores. Abrange os problemas mais comuns.
    .label = Corrigir principais problemas em sites (recomendado)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Restaura coisas como vídeos em um artigo ou seções de comentários, ao desbloquear elementos que podem conter rastreadores. Isso pode reduzir problemas em sites, mas oferece menos proteção. Deve ser usado com correções de principais problemas.
    .label = Corrigir problemas menores em sites
content-blocking-baseline-uncheck-warning-dialog-title = Tem certeza que quer desativar correções?
content-blocking-baseline-uncheck-warning-dialog-body = Esta configuração ajuda a corrigir os problemas mais comuns em sites. Se você desativar, alguns sites podem não funcionar e o { -brand-short-name } não poderá ajudar a resolver esses problemas.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Desativar correções
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Manter correções ativadas
content-blocking-reload-description = É preciso recarregar as abas para aplicar essas mudanças.
content-blocking-reload-tabs-button =
    .label = Recarregar todas as abas
    .accesskey = R
content-blocking-tracking-content-label =
    .label = Conteúdo com rastreamento
    .accesskey = C
content-blocking-tracking-protection-option-all-windows =
    .label = Em todas as janelas
    .accesskey = a
content-blocking-option-private =
    .label = Só em janelas privativas
    .accesskey = p
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Mais informações
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Criptomineradores
    .accesskey = i
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Rastreadores de identidade digital (fingerprinters) conhecidos
    .accesskey = h
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Suspeitos de ser rastreadores de identidade digital (fingerprinters)
    .accesskey = S

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Gerenciar exceções…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Inibir notificações até o { -brand-short-name } ser reiniciado
    .accesskey = n
permissions-autoplay2 =
    .label = Reprodução automática
permissions-block-popups2 =
    .label = Bloquear abertura de janelas e redirecionamento de terceiros
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Adicionar sites que possam abrir janelas e usar redirecionamento de terceiros.
    .label = Gerenciar exceções
    .searchkeywords = popup, abertura de janelas
    .accesskey = E
permissions-addon-install-warning3 =
    .label = Avisar quando sites tentam instalar extensões
    .accesskey = v
permissions-addon-exceptions2 =
    .label = Escolher quais sites podem instalar extensões
    .accesskey = E
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Permitir que sites peçam para abrir links de aplicativos.
    .accesskey = P
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Gerenciar sites bloqueados
    .accesskey = G
permissions-location2 =
    .label = Localização
permissions-localhost2 =
    .label = Aplicativos e serviços do dispositivo
permissions-local-network2 =
    .label = Dispositivos de rede local
permissions-xr2 =
    .label = Realidade Virtual
permissions-camera2 =
    .label = Câmera
permissions-microphone2 =
    .label = Microfone
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Saída de áudio
permissions-notification2 =
    .label = Notificações
permissions-header3 =
    .description = Gerencie quais sites podem acessar, controlar ou acionar.
    .label = Permissões
permissions-data-section =
    .heading = Permissões e dados
pane-permissions-data-title2 = Permissões e dados
    .title = Permissões e dados
notifications-section-header =
    .heading = Notificações
notifications-entry-card-header =
    .description = Escolher quais sites podem enviar notificações e como esses alertas são exibidos.
    .label = Notificações
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } site
           *[other] { $count } sites
        }
    .label = Gerenciar configurações de notificações
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Gerenciar configurações de notificações de sites
notifications-website-card-header =
    .description = Escolher como sites podem enviar notificações.
    .label = Notificações de sites
notifications-filter =
    .placeholder = Pesquisar sites
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Site
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Permitir notificações
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Sites
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Sempre
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Permitir
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Nunca
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Nenhum site adicionado com configuração de notificações
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Nenhum site com configuração de notificações corresponde à pesquisa.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Para garantir que essas alterações sejam incluídas nos seus backups, abra cada perfil e escolha “Fazer backup agora” nas configurações.
nimbus-rollouts =
    .description = Mudanças são disponibilizadas remotamente.
    .label = Permitir que o { -brand-short-name } melhore funcionalidades, desempenho e estabilidade entre uma atualização e outra
addon-recommendations3 =
    .description = Receber recomendações de extensões para melhorar sua experiência de navegação.
    .label = Permitir recomendações personalizadas de extensões
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = O relatório de dados está desativado na configuração desta versão.
collection-backlogged-crash-reports2 =
    .label = Enviar relatórios de falhas automaticamente
    .accesskey = f
collection-backlogged-crash-reports-description = Isso ajuda a { -vendor-short-name } a diagnosticar e resolver problemas relacionados ao navegador. Os relatórios podem conter dados pessoais ou sensíveis.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = As mesmas configurações, novo visual!
    .message = Reorganizamos esta página para ficar mais fácil analisar e descobrir. Suas configurações pessoais não foram alteradas, tudo foi mantido. Dica: use a pesquisa acima para ir direto ao que você precisa.
settings-redesign-promo-dismiss-button =
    .label = Entendi
privacy-segmentation-section-header = Novos recursos que aprimoram sua navegação
privacy-segmentation-section-description = Quando oferecemos recursos que usam seus dados para oferecer uma experiência de uso mais pessoal:
privacy-segmentation-radio-off =
    .label = Usar recomendações do { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Mostrar informações detalhadas
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Nos empenhamos em oferecer escolhas e coletar somente o mínimo de dados necessários para melhorar o { -brand-product-name } para todos.
    .label = Coleta e uso de dados pelo { -brand-short-name }
    .searchkeywords = telemetria
data-collection-link = Ver aviso de privacidade
data-collection-preferences-across-profiles =
    .message = Estas configurações se aplicam a todos os perfis do { -brand-product-name } neste dispositivo.
data-collection-profiles-link = Ver todos os perfis
data-collection-health-report-telemetry-disabled =
    .message = Você não está mais permitindo que a { -vendor-short-name } capture dados técnicos e de interação. Todos os dados coletados anteriormente serão apagados em até 30 dias.
data-collection-health-report =
    .description = Isto ajuda a melhorar recursos, desempenho e estabilidade do { -brand-product-name }.
    .label = Enviar dados técnicos e de interação para a { -vendor-short-name }
    .accesskey = r
data-collection-health-report-disabled =
    .description = O envio de dados em relatórios é desativado nesta configuração de compilação.
    .label = Enviar dados técnicos e de interação para a { -vendor-short-name }
    .accesskey = r
data-collection-run-studies =
    .description = O { -brand-short-name } seleciona usuários aleatoriamente para testar recursos, ajudando a melhorar a qualidade para todos.
    .label = Permitir que o { -brand-short-name } execute estudos de funcionalidades
data-collection-studies-link =
    .label = Ver estudos do { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = Ajuda a { -vendor-short-name } a diagnosticar e corrigir problemas no navegador. OS relatórios podem incluir dados pessoais ou sensíveis.
    .label = Enviar relatórios de falhas automaticamente
    .accesskey = f
data-collection-usage-ping =
    .description = Isto ajuda a { -vendor-short-name } a estimar o número de usuários ativos.
    .label = Enviar ping de uso diário para a { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Segurança
browsing-protection-group2 =
    .description = Sites e downloads perigosos podem colocar seus dados e o dispositivo em risco. O { -brand-short-name } os bloqueia automaticamente e te avisa sobre softwares arriscados ou indesejados.
    .label = Proteção contra conteúdo enganoso e softwares perigosos
security-enable-safe-browsing =
    .label = Bloquear conteúdo perigoso ou enganoso
    .accesskey = B
security-enable-safe-browsing-link = Saiba mais
security-safe-browsing-warning =
    .message = Desativar isto reduz a proteção contra golpes, sites maliciosos e downloads perigosos.
security-block-downloads =
    .label = Bloquear downloads perigosos
    .accesskey = d
security-block-uncommon-software =
    .label = Avisar sobre softwares indesejados ou incomuns
    .accesskey = c

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Permitir que o { -brand-short-name } confie automaticamente em certificados raiz de terceiros que você instalar
    .accesskey = t
certs-devices-enable-fips = Ativar FIPS
space-alert-over-5gb-settings-button =
    .label = Abrir configurações
    .accesskey = A
space-alert-over-5gb-message2 = <strong>O { -brand-short-name } está ficando sem espaço em disco.</strong> Conteúdos de sites podem não ser exibidos corretamente. Você pode limpar o armazenamento de dados em Configurações > Privacidade e Segurança > Cookies e dados de sites.
space-alert-under-5gb-message2 = <strong>O { -brand-short-name } está ficando sem espaço em disco.</strong> Conteúdos de sites podem não ser exibidos corretamente. Acesse “Saiba mais” para otimizar seu uso de disco para ter uma melhor experiência de navegação.
certs-description3 =
    .description = Configure os certificados que o { -brand-short-name } usa para verificar conexões seguras.
    .label = Certificados
certs-view2 =
    .label = Gerenciar certificados
    .accesskey = c
certs-devices2 =
    .label = Gerenciador de dispositivos de segurança
    .accesskey = d

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Como funciona somente HTTPS
httpsonly-radio-enabled =
    .label = Ativar o modo somente HTTPS em todas as janelas
httpsonly-radio-enabled-pbm =
    .label = Ativar o modo somente HTTPS apenas em janelas privativas
httpsonly-radio-disabled3 =
    .description = O { -brand-short-name } ainda pode mudar algumas conexões
    .label = Não ativar o modo somente HTTPS
httpsonly-group =
    .description = Só permite conexões seguras com sites. O { -brand-short-name } pergunta antes de conectar em modo não seguro.
    .label = Modo somente HTTPS
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS sobre HTTPS
dns-over-https-group2 =
    .description = Domain Name System sobre HTTPS (DoH) criptografa a procura de sites, dificultando que seu provedor de internet ou outros vejam quais sites você vai visitar.
    .label = DNS sobre HTTPS
preferences-doh-description2 = O DNS (Domain Name System) sobre HTTPS envia sua requisição de nome de domínio através de uma conexão criptografada, fornecendo um DNS seguro e dificultando a outras pessoas ver qual site você irá acessar.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Status: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Provedor: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = URL inválida
preferences-doh-steering-status = Usando provedor local
preferences-doh-status-active = Ativo
preferences-doh-status-disabled = Desativado
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Não ativo ({ $reason })
preferences-doh-group-message2 = Ativar DNS sobre HTTPS usando:
preferences-doh-radio-group =
    .aria-label = Ativar DNS sobre HTTPS usando:
preferences-doh-expand-section =
    .tooltiptext = Mais informações
preferences-doh-setting-default =
    .label = Proteção padrão
    .accesskey = P
preferences-doh-default-desc = O { -brand-short-name } decide quando usar DNS seguro para proteger sua privacidade.
preferences-doh-default-detailed-desc-1 = Usar DNS seguro em regiões onde estiver disponível
preferences-doh-default-detailed-desc-2 = Usar seu resolvedor de DNS padrão se houver um problema com o provedor de DNS seguro
preferences-doh-default-detailed-desc-3 = Usar um provedor local, se possível
preferences-doh-default-detailed-desc-4 = Desativar quando estiver ativo VPN, controle dos pais ou diretivas corporativas
preferences-doh-default-detailed-desc-5 = Desativar quando uma rede informar ao { -brand-short-name } que ele não deve usar DNS seguro
preferences-doh-setting-enabled =
    .label = Proteção maior
    .accesskey = m
preferences-doh-enabled-desc = Você controla quando usar DNS seguro e escolhe seu provedor.
preferences-doh-enabled-detailed-desc-1 = Usar o provedor que você selecionar
preferences-doh-enabled-detailed-desc-2 = Só usar seu resolvedor de DNS padrão se houver um problema com DNS seguro
preferences-doh-setting-strict =
    .label = Proteção máxima
    .accesskey = m
preferences-doh-strict-desc = O { -brand-short-name } sempre usa DNS seguro. Aparece um aviso de risco de segurança antes de usar o DNS do seu sistema.
preferences-doh-strict-detailed-desc-1 = Só usar o provedor que você selecionar
preferences-doh-strict-detailed-desc-2 = Sempre avisar se DNS seguro não estiver disponível
preferences-doh-strict-detailed-desc-3 = Se não tiver DNS seguro disponível, alguns sites podem não ser carregados ou não funcionar corretamente
preferences-doh-setting-off =
    .label = Desativado
    .accesskey = D
preferences-doh-off-desc = Usar seu resolvedor de DNS padrão
preferences-doh-select-resolver = Escolher provedor:
preferences-doh-manage-exceptions =
    .label = Gerenciar exceções…
    .accesskey = x
preferences-doh-overview-default =
    .description = Usar DNS seguro em regiões onde estiver disponível.
    .label = Proteção padrão
preferences-doh-overview-custom =
    .description = Sempre usar DNS seguro com controle sobre seu provedor e comportamento de usar alternativas.
    .label = Personalizado
preferences-doh-overview-off =
    .description = Usar seu resolvedor padrão de DNS.
    .label = Desativado
preferences-doh-advanced-button =
    .label = Configurações avançadas
preferences-doh-advanced-section =
    .description = Domain Name System sobre HTTPS (DoH) criptografa a procura de sites, dificultando que seu provedor de internet ou outros vejam quais sites você vai visitar.
    .label = Configurações avançadas
preferences-doh-manage-exceptions2 =
    .label = Gerenciar exceções
    .accesskey = x
preferences-doh-radio-default =
    .description = Usar DNS seguro em regiões onde estiver disponível
    .label = Padrão
preferences-doh-radio-custom =
    .description = Sempre usar DNS seguro com controle sobre seu provedor e comportamento de usar alternativas
    .label = Personalizado
preferences-doh-radio-off =
    .description = Usar seu resolvedor de DNS padrão
    .label = Desativado
preferences-doh-fallback-label =
    .label = Sempre me avisar se DNS seguro não estiver disponível
preferences-doh-status-item-off =
    .message = DNS sobre HTTPS está desativado
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = O DNS sobre HTTPS não está funcionando porque encontramos um erro ({ $reason }) ao tentar usar o provedor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = O DNS sobre HTTPS não está funcionando porque recebemos uma URL inválida ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS sobre HTTPS está usando o provedor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = O DNS sobre HTTPS não está funcionando porque encontramos um erro ({ $reason }) ao tentar usar o provedor local { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = O DNS sobre HTTPS está usando o provedor local { $name }
preferences-doh-select-resolver-label =
    .label = Escolher provedor:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Usar este provedor para resolver DNS sobre HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Insira uma URL de provedor personalizado
preferences-doh-header2 =
    .heading = DNS sobre HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Conexão e segurança de software
preferences-connection-link-section =
    .description = Ver como conexões permanecem seguras, software prejudicial é bloqueado e sites são verificados.
    .label = Conexão e segurança de software
preferences-connection-link-button =
    .label = Configurações avançadas

## The following strings are used in the Download section of settings

desktop-folder-name = Área de trabalho
downloads-folder-name = Downloads

## Appearance page

preferences-appearance-header =
    .heading = Aparência
browser-theme-group =
    .description = Estilize o { -brand-short-name } do seu jeito. Cores de temas se aplicam à barras de ferramentas, menus e mensagens.
    .label = Tema do navegador
browser-theme-manage-link =
    .label = Gerenciar temas do { -brand-short-name }
appearance-window-density-group =
    .description = Ajustar o espaçamento em torno de elementos da janela, como barra de ferramentas, abas e painel lateral.
    .label = Densidade da janela
appearance-window-density-radio-group =
    .aria-label = Densidade da janela
appearance-window-density-automatic =
    .description = Espaçamento normal, compacto ou de toque é aplicado automaticamente
    .label = Automático (padrão)
appearance-window-density-automatic-no-touch =
    .description = Espaçamento normal ou compacto é aplicado automaticamente
    .label = Automático (padrão)
appearance-window-density-standard =
    .description = Espaçamento balanceado para a maioria das telas
    .label = Normal
appearance-window-density-auto-touch-mode =
    .label = Usar espaçamento de toque no modo tablet
appearance-window-density-compact =
    .description = Espaçamento reduzido para telas menores
    .label = Compacto
appearance-window-density-touch =
    .description = Elementos de janela e alvos de clique maiores, otimizado para telas de toque
    .label = Toque
related-settings-group =
    .label = Configurações relacionadas
related-settings-accessibility-link =
    .label = Personalizar configurações de zoom e fonte na acessibilidade
related-settings-home-link =
    .label = Personalizar a { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = Personalizar layout do navegador

## AI controls page

preferences-ai-controls-description = Você sempre tem escolhas no { -brand-short-name }, inclusive se quer ou não usar recursos aprimorados com inteligência artificial. Mais controles em breve.
preferences-ai-controls-block-ai-label = Bloquear aprimoramentos de inteligência artificial
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Bloquear significa que não aparecerão novos ou atuais aprimoramentos de inteligência artificial no { -brand-short-name }, nem notificações sobre eles. <a data-l10n-name="link">Veja mais detalhes</a> sobre o que está incluído e como controlar recursos tradicionais de aprendizado de máquina, como sugestões de pesquisa e recomendações.
preferences-ai-controls-blocked-message =
    .message = Aprimoramentos novos e atuais de inteligência artificial são bloqueados por padrão. Para desbloquear um recurso específico, use os controles abaixo.
preferences-ai-controls-on-device-group =
    .description = Usa pequenos modelos de inteligência artificial que são baixados para este dispositivo, se você usar o recurso. Esta abordagem ajuda a proteger sua privacidade.
    .label = Inteligência artificial no dispositivo
preferences-ai-controls-translations-control =
    .description = Navegue na web tranquilamente em seu idioma preferido
    .label = Tradução
preferences-ai-controls-translations-more-link = Mais configurações de tradução
preferences-ai-controls-pdfjs-control =
    .description = Ao adicionar uma imagem em um PDF, é adicionada uma descrição para tornar a imagem acessível.
    .label = Texto alternativo de imagens no visor de PDF do { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Receber sugestões de nome e organizar suas abas.
    .label = Sugestões de grupos de abas
preferences-ai-controls-key-points-control =
    .description = Ver um breve resumo antes de abrir um link.
    .label = Pontos-chave na exibição prévia de links
preferences-ai-controls-speech-recognition-control =
    .description = Transcrever fala localmente.
    .label = Reconhecimento de voz
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Manter um chatbot ao alcance enquanto navega. Escolha entre vários provedores e mude quando quiser.
    .label = Provedores de chatbot de inteligência artificial no painel lateral
preferences-ai-controls-sidebar-chatbot-group =
    .description = Mantenha um chatbot à mão enquanto navega. Escolha Anthropic Claude, ChatGPT, Copilot, Google Gemini ou Le Chat Mistral.
    .label = Provedores de chatbot de inteligência artificial no painel lateral
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot no painel lateral
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Disponível
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Ativado
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Bloqueado
preferences-ai-controls-state-description-before = O que significam as opções:
preferences-ai-controls-state-description-available = <strong>Disponível:</strong> O recurso aparece e você pode usar.
preferences-ai-controls-state-description-enabled = <strong>Ativado:</strong> Você optou por usar o recurso.
preferences-ai-controls-state-description-blocked = <strong>Bloqueado:</strong> Não aparece e você não pode usar o recurso. Para inteligência artificial no dispositivo, quaisquer modelos já baixados são removidos.
preferences-ai-controls-block-confirmation-heading = Bloquear aprimoramentos de inteligência artificial?
preferences-ai-controls-block-confirmation-description = Não aparecem melhorias de inteligência artificial novas ou atuais no { -brand-short-name }, nem notificações sobre elas. Depois, você pode desbloquear qualquer coisa que quiser continuar usando.
preferences-ai-controls-block-confirmation-features-start = O que será bloqueado:
preferences-ai-controls-block-confirmation-translations = Tradução
preferences-ai-controls-block-confirmation-pdfjs = Texto alternativo de imagens no visor de PDF do { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Sugestões de grupos de abas
preferences-ai-controls-block-confirmation-key-points = Pontos-chave na exibição prévia de links
preferences-ai-controls-block-confirmation-sidebar-chatbot = Provedores de chatbot no painel lateral
preferences-ai-controls-block-confirmation-speech-recognition = Reconhecimento de voz
preferences-ai-controls-block-confirmation-features-after = O bloqueio também afeta extensões que usam inteligência artificial fornecida pelo { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Cancelar
preferences-ai-controls-block-confirmation-confirm =
    .label = Bloquear
preferences-ai-controls-header3 =
    .heading = Controles de inteligência artificial

## Privacy and security status card

security-privacy-status-ok-header = O { -brand-short-name } está em guarda
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = O { -brand-short-name } recomenda algumas melhorias de segurança
security-privacy-status-ok-label = A proteção aprimorada contra rastreamento está ativada
security-privacy-status-problem-label = Encontramos configurações que afetam sua proteção
security-privacy-status-problem-helper-label = Ver problemas
security-privacy-status-pending-trackers-label = Verificando quantos rastreadores o { -brand-short-name } bloqueou no último mês
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [zero] Nenhum rastreador bloqueado no último mês
        [one] { $trackerCount } rastreador bloqueado no último mês
       *[other] { $trackerCount } rastreadores bloqueados no último mês
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Você tem <a data-l10n-name="strict-tracking-protection">proteção rigorosa</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Você tem <a data-l10n-name="custom-tracking-protection">proteção personalizada</a>
security-privacy-status-up-to-date-label = Você tem a versão mais recente e segura do { -brand-short-name }
security-privacy-status-update-needed-label = Está disponível uma nova versão do { -brand-short-name }.
security-privacy-status-update-error-label = O { -brand-short-name } está tendo problemas em se atualizar
security-privacy-status-update-checking-label = O { -brand-short-name } está verificando se há atualizações
security-privacy-status-update-needed-description = Atualize para as atualizações mais recentes de velocidade, estabilidade e segurança.
security-privacy-status-update-button-label =
    .label = Atualizar o { -brand-short-name }
security-privacy-image-warning =
    .alt = Um escudo com um ponto de exclamação, expressando preocupação com seus avisos de segurança
security-privacy-image-ok =
    .alt = Um escudo com uma marca de seleção, mostrando que você não tem problemas de segurança pendentes
security-privacy-issue-card =
    .heading = Avisos de segurança
issue-card-reset-button =
    .label = Redefinir
issue-card-dismiss-button =
    .aria-label = Descartar
    .tooltiptext = Descartar

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Sites usam rastreadores para tentar te seguir online e mostrar anúncios invasivos. O { -brand-short-name } protege você enquanto navega, bloqueando rastreadores automaticamente para que você tenha controle sobre o seu rastro digital.
    .label = Proteção aprimorada contra rastreamento
preferences-etp-level-radio-group =
    .aria-label = Proteção aprimorada contra rastreamento
preferences-etp-level-standard =
    .description = Proteções poderosas e confiáveis que funcionam suavemente na maioria dos sites.
    .label = Normal (padrão)
preferences-etp-level-strict =
    .description = Proteções ainda mais fortes que bloqueiam mais rastreadores, mas podem atrapalhar alguns sites.
    .label = Rigoroso
preferences-etp-level-custom =
    .description = Escolha quais proteções ativar ou desativar.
    .label = Personalizado
preferences-etp-status-advanced-button =
    .label = Configurações avançadas
preferences-etp-tracker-count-enabled =
    .label = Mostrar rastreadores bloqueados na barra de endereços
preferences-etp-status-protections-dashboard-link =
    .description = Veja quantos rastreadores ocultos o { -brand-short-name } bloqueou para você, incluindo rastreadores de redes sociais, identificadores de dispositivos e mineradores de criptomoedas.
    .label = Ver o painel de proteções personalizadas
preferences-etp-header =
    .heading = Proteção aprimorada contra rastreamento
preferences-etp-advanced-settings-group =
    .description = Sites usam rastreadores para tentar te seguir online e mostrar anúncios invasivos. O { -brand-short-name } protege você enquanto navega, bloqueando a maioria dos rastreadores automaticamente para que você possa estar no controle de seu rastro digital.
    .label = Configurações avançadas
preferences-etp-customize-button =
    .label = Personalizar a proteção contra rastreamento
preferences-etp-reload-tabs-hint =
    .message = Recarregue suas abas para aplicar estas alterações.
preferences-etp-reload-tabs-hint-button =
    .label = Recarregar todas as abas
preferences-etp-rfp-warning-message =
    .message = Você está usando Resist Fingerprinting (RFP), que substitui algumas configurações de proteção contra rastreamento de identidade digital do { -brand-short-name }. Isso pode fazer com que alguns sites não funcionem corretamente.
preferences-etp-level-warning-message =
    .heading = Atenção! Alguns sites podem não funcionar como esperado.
    .message = Alguns sites incorporam rastreadores em seus recursos ou conteúdo. Quando o { -brand-short-name } os bloqueia, um site pode não funcionar corretamente. Experimente usar “Corrigir problemas em sites” ou desativar a proteção contra rastreamento no site.
preferences-etp-manage-exceptions-button =
    .description = Gerenciar sites em que a proteção aprimorada contra rastreamento é desativada.
    .label = Gerenciar exceções
preferences-etp-customize-header =
    .heading = Personalizar a proteção contra rastreamento
preferences-etp-reset =
    .description = Restaurar configurações para um nível de proteção predefinido.
    .label = Redefinir personalizações
preferences-etp-reset-standard-button =
    .label = Redefinir para normal
preferences-etp-reset-strict-button =
    .label = Redefinir para rigoroso
preferences-etp-custom-control-group =
    .description = Escolher quais proteções ativar ou desativar.
    .label = Proteção contra rastreamento
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Permitir todos os cookies
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Bloquear cookies de rastreamento entre sites
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Bloquear cookies entre sites
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Isolar cookies entre sites
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Bloquear cookies de sites não visitados
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Bloquear todos os cookies entre sites (alguns sites podem não funcionar corretamente)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Bloquear todos os cookies (vários sites não funcionarão corretamente)
preferences-etp-custom-tracking-protection-enabled =
    .label = Conteúdo com rastreamento
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Conteúdo com rastreamento
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Criptomineradores
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Rastreadores de identidade digital (fingerprinters) conhecidos
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Suspeitos de ser rastreadores de identidade digital (fingerprinters)
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Suspeitos de ser rastreadores de identidade digital (fingerprinters)

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Isto pode permitir que alguns rastreadores sigam você sem usar cookies.
    .label = Rastreadores de identidade digital (fingerprinters) conhecidos não são bloqueados
security-privacy-issue-warning-third-party-cookies =
    .description = Cookies de terceiros são usados para rastrear você de um site para outro.
    .label = Cookies de terceiros estão habilitados.
security-privacy-issue-warning-password-manager =
    .description = Gerenciadores de senhas te ajudam a armazenar senhas fortes de suas contas.
    .label = O gerenciador de senhas está desativado
security-privacy-issue-warning-popup-blocker =
    .description = Abertura de janelas é intrusivo e potencialmente prejudicial.
    .label = O bloqueio de abertura de janelas está desativado
security-privacy-issue-warning-extension-install =
    .description = Sites podem instalar extensões no { -brand-short-name } sem perguntar.
    .label = Sites podem instalar extensões
security-privacy-issue-warning-safe-browsing =
    .description = Sua exposição a golpes e softwares maliciosos de sites fica maior.
    .label = Conteúdo perigoso e enganoso não é bloqueado
security-privacy-issue-warning-doh2 =
    .description = DNS sobre HTTPS ajuda a ocultar de seu provedor de internet quais sites você visita.
    .label = DNS sobre HTTPS está desativado
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello ajuda a ocultar de seu provedor de internet quais sites você visita.
    .label = Encrypted Client Hello está desativado
security-privacy-issue-warning-doh =
    .description = DNS sobre HTTPS oculta do seu provedor de rede quais sites você visita.
    .label = DNS sobre HTTPS está desativado
security-privacy-issue-warning-ech =
    .description = O Encrypted Client Hello oculta do seu provedor de rede quais sites você visita.
    .label = O Encrypted Client Hello está desativado
security-privacy-issue-warning-proxy-autodetection =
    .description = A configuração automática de proxy pode deixar redes não confiáveis monitorar sua atividade.
    .label = A configuração automática de proxy está ativada

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Convidar a usar o navegador que põe a privacidade em primeiro lugar.
    .label = Recomendar o { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Recomendar o { -brand-product-name }


pane-vorbit-title = vOrbit-lite
vorbit-header = Preferências do vOrbit-lite
vorbit-warning-title = Atenção!
vorbit-general-heading = Comportamento do Navegador
vorbit-extension-update-checkbox =
    .label = Atualizar complementos automaticamente
vorbit-sync-checkbox =
    .label = Ativar a Sincronização do Firefox
vorbit-autocopy-checkbox =
    .label = Habilitar colar com o clique do meio
vorbit-network-heading = Rede
vorbit-ipv6-checkbox =
    .label = Habilitar IPv6
vorbit-privacy-heading = Privacidade
vorbit-xorigin-ref-checkbox =
    .label = Restringir envio de referências entre sites
vorbit-broken-heading = Impressões digitais
vorbit-webgl-checkbox =
    .label = Habilitar WebGL
vorbit-letterboxing-checkbox =
    .label = Habilitar Letterboxing
category-vorbit =
    .tooltiptext = As alterações do about:config, logicamente agrupadas e facilmente acessíveis
vorbit-warning-description = Escolhemos cuidadosamente as configurações padrão para focar na privacidade e segurança. Ao alterar essas configurações, leia as descrições para entender as implicações dessas mudanças.
vorbit-styling-checkbox =
    .label = Permitir personalização do userChrome.css
vorbit-rfp-checkbox =
    .label = Habilitar Resistência a Impressão Digital
vorbit-security-heading = Segurança
vorbit-ocsp-checkbox =
    .label = Impor OCSP de falha rígida
vorbit-goog-safe-checkbox =
    .label = Habilitar Navegação Segura do Google
vorbit-extension-update-warning1 = Se você não revisa o código de suas extensões antes de cada atualização, você deveria habilitar esta opção.
vorbit-ipv6-description = Permitir que o { -brand-short-name } se conecte usando IPv6.
vorbit-ipv6-warning1 = Em vez de bloquear o IPv6 no navegador, sugerimos ativar a extensão de privacidade IPv6 no seu SO.
vorbit-ocsp-warning1 = Isso reforça a segurança, mas causará falhas quando um servidor OCSP estiver indisponível.
vorbit-sync-description = Sincronizar seus dados com outros navegadores. É necessário reiniciar.
vorbit-goog-safe-download-checkbox =
    .label = Habilitar Verificação de Downloads
vorbit-extension-update-description = Manter as extensões atualizadas sem intervenção manual. Recomendado para sua segurança.
vorbit-autocopy-description = Selecione um texto para copiar, e cole com o botão do meio do mouse.
vorbit-ocsp-description = Impedir conexão a um site se a verificação OCSP falhar.
vorbit-sync-warning1 = O Firefox Sync criptografa os dados localmente antes de transmiti-los ao servidor.
vorbit-styling-description = Habilite isto se quiser personalizar a interface do usuário com um tema carregado manualmente.
vorbit-styling-warning1 = Certifique-se de que você confia no fornecedor do tema.
vorbit-xorigin-ref-description = Enviar referrer somente na mesma origem.
vorbit-xorigin-ref-warning1 = Isso pode causar problemas. Além disso, mesmo se enviados, referrers ainda serão reduzidos.
vorbit-webgl-description = WebGL é um forte vetor de impressões digitais.
vorbit-webgl-warning1 = Se você precisar habilitá-lo, considere usar uma extensão como Canvas Blocker.
vorbit-rfp-warning1 = Se você precisar desabilitá-lo, considere usar uma extensão como Canvas Blocker.
vorbit-letterboxing-description = O letterboxing aplica margens ao redor de suas janelas para retornar um conjunto limitado de resoluções.
vorbit-goog-safe-description = Se você estiver preocupado com malware e phishing, considere ativá-lo.
vorbit-goog-safe-download-description = Permitir que a Navegação Segura verifique seus downloads para identificar arquivos suspeitos.
vorbit-footer = Links Úteis
vorbit-config-link = Todas as configurações avançadas (about:config)
vorbit-open-profile = Abrir pasta do perfil do usuário
content-blocking-section-top-level-description = vOrbit-lite suporta - e habilita por padrão - Proteção Aprimorada Contra Rastreamento no modo Estrito. Essa é uma das opções mais importantes do navegador, pois oferece particionamento de estado, listas de bloqueio estritas e outras funcionalidades de privacidade úteis. Não recomendamos alterar para outros modos.
vorbit-rfp-description = ResistFingerprinting é a melhor ferramenta da categoria contra impressões digitais.
vorbit-goog-safe-warning1 = Desativado por motivos de censura, mas recomendado para usuários menos experientes. Todas as verificações são feitas localmente.
vorbit-goog-safe-download-warning1 = Todas as verificações são feitas localmente.
