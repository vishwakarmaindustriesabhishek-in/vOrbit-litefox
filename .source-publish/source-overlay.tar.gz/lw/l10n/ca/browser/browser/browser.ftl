# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = Navegació privada del { -brand-shortcut-name }
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Navegació web ràpida i privada
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — (Navegació privada)
       *[other] { -brand-full-name } (Navegació privada)
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Navegació privada
popups-infobar-dont-show-message2 =
    .label = No mostris aquest missatge quan les finestres emergents o les redireccions de tercers estiguin bloquejades
    .accesskey = N
edit-popup-settings2 =
    .label = Gestioneu la configuració de les finestres emergents i la redirecció de tercers…
    .accesskey = G
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Mostra la informació del lloc
            [1] Mostra la informació del lloc (1 element de seguiment blocat)
            [one] Mostra la informació del lloc ({ $count } element de seguiment blocat)
           *[other] Mostra la informació del lloc ({ $count } elements de seguiment blocats)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label =
        { $count ->
            [one] { $count } enllaç
           *[other] { $count } enllaços
        }
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Missatges i més…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Missatges, correu i més…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Comparteix…
    .accesskey = C
urlbar-identity-button =
    .aria-label = Mostra la informació del lloc

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Obre la subfinestra del missatge d'instal·lació
urlbar-web-notification-anchor =
    .tooltiptext = Canvia l'opció de si es poden rebre notificacions d'aquest lloc
urlbar-midi-notification-anchor =
    .tooltiptext = Obre la subfinestra MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Obre la subfinestra en sèrie
urlbar-eme-notification-anchor =
    .tooltiptext = Gestiona l'ús de programari de DRM
urlbar-web-authn-anchor =
    .tooltiptext = Obre la subfinestra d'autenticació web
urlbar-canvas-notification-anchor =
    .tooltiptext = Gestiona el permís d'extracció de llenç
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Gestiona la compartició del micròfon amb el lloc
urlbar-default-notification-anchor =
    .tooltiptext = Obre la subfinestra del missatge
urlbar-geolocation-notification-anchor =
    .tooltiptext = Obre la subfinestra de la sol·licitud d'ubicació
urlbar-localhost-notification-anchor =
    .tooltiptext = Gestiona l’accés als dispositius locals per a aquest lloc
urlbar-local-network-notification-anchor =
    .tooltiptext = Gestiona la compartició de l’accés a la xarxa local amb el lloc
urlbar-xr-notification-anchor =
    .tooltiptext = Obre el tauler de permisos de realitat virtual
urlbar-storage-access-anchor =
    .tooltiptext = Obre la subfinestra de permisos d'activitat de navegació
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Gestiona la compartició de finestres o de la pantalla amb el lloc
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Obre la subfinestra del missatge d'emmagatzematge fora de línia
urlbar-password-notification-anchor =
    .tooltiptext = Obre la subfinestra del missatge de desar la contrasenya
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Gestiona la compartició de la càmera o del micròfon amb el lloc
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Gestiona la compartició d'altres altaveus amb el lloc
urlbar-autoplay-notification-anchor =
    .tooltiptext = Obre la subfinestra de reproducció automàtica
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Desa dades en l'emmagatzematge persistent
urlbar-addons-notification-anchor =
    .tooltiptext = Obre la subfinestra del missatge d'instal·lació del complement
urlbar-search-tips-confirm = Entesos
urlbar-search-tips-confirm-short = Entesos
urlbar-result-menu-button =
    .title = Obre el menú
urlbar-result-menu-button-feedback = Comentaris
    .title = Obre el menú
urlbar-result-menu-learn-more2 = Més informació
    .accesskey = M
urlbar-result-menu-remove-from-history2 = Elimina de l'historial
    .accesskey = r
urlbar-result-menu-tip-get-help2 = Obteniu ajuda
    .accesskey = j
urlbar-result-menu-dismiss-suggestion2 = Descarta aquest suggeriment
    .accesskey = D
urlbar-result-menu-remove-top-site = Elimina aquest lloc principal
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = Gestiona el { -firefox-suggest-brand-name }
    .accesskey = G
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Informa d’una ubicació incorrecta
    .accesskey = n
urlbar-result-menu-show-less-frequently3 = Mostra-ho menys sovint
    .accesskey = M
urlbar-result-menu-dont-show-weather-suggestions3 = No mostris la informació meteorològica
    .accesskey = N
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Informa d’una ubicació incorrecta
urlbar-result-menu-show-less-frequently2 = Mostra-ho menys sovint
urlbar-result-menu-dont-show-weather-suggestions2 = No mostris la informació meteorològica
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Descarta aquest suggeriment
    .accesskey = e
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Suprimeix de l'historial
    .accesskey = u
urlbar-result-menu-learn-more =
    .label = Més informació
    .accesskey = M
urlbar-result-menu-remove-from-history =
    .label = Elimina de l'historial
    .accesskey = r
urlbar-result-menu-tip-get-help =
    .label = Obteniu ajuda
    .accesskey = j
urlbar-result-menu-dismiss-suggestion =
    .label = Descarta aquest suggeriment
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = Gestiona el { -firefox-suggest-brand-name }
    .accesskey = G
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Informa d’una ubicació incorrecta
urlbar-result-menu-show-less-frequently =
    .label = Mostra-ho menys sovint
urlbar-result-menu-dont-show-weather-suggestions =
    .label = No mostris la informació meteorològica
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Obre el menú
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Gràcies per la vostra opinió
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Gràcies pels vostres comentaris. Ja no veureu la informació meteorològica.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Escriviu menys i trobeu més: Cerqueu amb { $engineName } directament des de la barra d'adreces.
urlbar-search-tips-redirect-2 = Comenceu la vostra cerca en la barra d'adreces per veure suggeriments de { $engineName } i del vostre historial de navegació.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Seleccioneu aquesta drecera per trobar el que necessiteu més ràpidament.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Adreces d'interès
urlbar-search-mode-tabs = Pestanyes
urlbar-search-mode-history = Historial
urlbar-search-mode-actions = Accions

##

urlbar-geolocation-blocked =
    .tooltiptext = Heu blocat la informació d'ubicació per a aquest lloc web.
urlbar-localhost-blocked =
    .tooltiptext = Heu blocat les connexions a dispositius locals per a aquest lloc web.
urlbar-local-network-blocked =
    .tooltiptext = Heu blocat les connexions a la xarxa local per a aquest lloc web.
urlbar-xr-blocked =
    .tooltiptext = Heu blocat l'accés a dispositius de realitat virtual per a aquest lloc web.
urlbar-web-notifications-blocked =
    .tooltiptext = Heu blocat les notificacions per a aquest lloc web.
urlbar-camera-blocked =
    .tooltiptext = Heu blocat la càmera per a aquest lloc web.
urlbar-microphone-blocked =
    .tooltiptext = Heu blocat el micròfon per a aquest lloc web.
urlbar-screen-blocked =
    .tooltiptext = Heu blocat la compartició de la pantalla en aquest lloc web.
urlbar-persistent-storage-blocked =
    .tooltiptext = Heu blocat l'emmagatzematge persistent per a aquest lloc web.
urlbar-popup-blocked2 =
    .tooltiptext = Heu blocat les finestres emergents i les redireccions de tercers per a aquest lloc web.
urlbar-autoplay-media-blocked =
    .tooltiptext = Heu blocat la reproducció automàtica de contingut multimèdia amb so per a aquest lloc web.
urlbar-canvas-blocked =
    .tooltiptext = Heu blocat l'extracció de dades de llenç (canvas) per a aquest lloc web.
urlbar-midi-blocked =
    .tooltiptext = Heu blocat l'accés MIDI per a aquest lloc web.
urlbar-serial-blocked =
    .tooltiptext = Heu blocat l'accés al port en sèrie per a aquest lloc web.
urlbar-install-blocked =
    .tooltiptext = Heu blocat la instal·lació de complements per a aquest lloc web.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Edita l'adreça d'interès ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Afegeix la pàgina a les adreces d'interès ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Vista dividida
    .tooltiptext = Vista dividida

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Enganxa i vés-hi
    .accesskey = E
urlbar-menuitem-paste-and-search =
    .label = Enganxa i cerca
    .accesskey = E

## Searchbar context menu

clear-search-history =
    .label = Esborra l'historial de cerques
    .accesskey = c

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Gestiona l'extensió…
    .accesskey = e
page-action-remove-extension2 =
    .label = Elimina l'extensió
    .accesskey = l

## Auto-hide Context Menu

full-screen-autohide =
    .label = Amaga les barres d'eines
    .accesskey = g
full-screen-exit =
    .label = Surt del mode de pantalla completa
    .accesskey = p

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Aquesta vegada, cerca amb:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Canvia els paràmetres de cerca
search-one-offs-context-open-new-tab =
    .label = Cerca en una pestanya nova
    .accesskey = t
search-one-offs-context-set-as-default =
    .label = Defineix com a motor de cerca per defecte
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = Defineix com a motor de cerca per defecte per a les finestres privades
    .accesskey = D
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Afegeix el motor de cerca «{ $engineName }»
    .label = Afegeix «{ $engineName }»
    .tooltiptext = Afegeix el motor de cerca «{ $engineName }»
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Afegeix un motor de cerca
    .accesskey = A
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Afegeix un motor de cerca

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Adreces d'interès ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Pestanyes ({ $restrict })
search-one-offs-history =
    .tooltiptext = Historial ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Accions ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Mostra els complements
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = extensions, temes, complements
# Opens preferences page at AI controls
quickactions-manageai = Gestioneu els controls d'IA
quickactions-cmd-manageai = desactiva la IA, IA off, gestiona la IA
# Opens the bookmarks library window
quickactions-bookmarks2 = Gestiona les adreces d'interès
quickactions-cmd-bookmarks = adreces d'interès
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Esborra l’historial recent
quickactions-cmd-clearrecenthistory2 = galetes, esborra galetes, memòria cau, esborra la memòria cau, dades de navegació, esborra dades de navegació, historial, esborra l'historial recent
# Opens about:downloads page
quickactions-downloads2 = Mostra les baixades
quickactions-cmd-downloads = baixades, descàrregues
# Opens about:addons page in the extensions section
quickactions-extensions = Gestiona les extensions
quickactions-cmd-extensions2 = extensions, complements, add-ons, addons
# Opens Firefox View
quickactions-firefoxview = Obre la { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = obre la { -firefoxview-brand-name }, { -firefoxview-brand-name }, obre la vista, vista
# Opens SUMO home page
quickactions-help = Ajuda del { -brand-product-name }
quickactions-cmd-help = ajuda, assistència, suport
# Opens the devtools web inspector
quickactions-inspector2 = Obre les eines per a desenvolupadors
quickactions-cmd-inspector2 = inspector, eines de desenvolupament, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Trieu un color
quickactions-cmd-colorpicker = selector de color, comptagotes, tria color
# Opens Firefox Library
quickactions-cmd-library = biblioteca
quickactions-library = Obre la biblioteca
# Opens about:logins
quickactions-logins2 = Gestiona les contrasenyes
quickactions-cmd-logins = inicis de sessió, contrasenyes, credencials
# Mutes all tabs playing audio
quickactions-mute = Silencia les pestanyes que reprodueixin àudio
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = silenci, calla, xxx, shhh
# Opens the print dialog
quickactions-print2 = Imprimeix la pàgina
quickactions-cmd-print = imprimir, impressió, imprimeix
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Desa la pàgina com a PDF
quickactions-cmd-savepdf2 = pdf, desa pàgina, desar pàgina
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Obre l'editor de PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Obre una finestra privada
quickactions-cmd-private = navegació privada
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Restableix el { -brand-short-name } a l'estat inicial
quickactions-cmd-refresh = restableix
# Restarts the browser
quickactions-restart = Reinicia el { -brand-short-name }
quickactions-cmd-restart = reiniciar
# Opens the screenshot tool
quickactions-screenshot3 = Fes una captura de pantalla
quickactions-cmd-screenshot2 = captura de pantalla, fes una captura de pantalla, fer una captura de pantalla
# Opens about:translations
quickactions-translate = Tradueix
quickactions-cmd-translate = tradueix
# Opens about:preferences
quickactions-settings2 = Gestiona els paràmetres
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = paràmetres, configuració, preferències, opcions, gestiona
# Opens about:addons page in the themes section
quickactions-themes = Gestiona els temes
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = temes, complements, add-ons, addons
# Opens a SUMO article explaining how to update the browser
quickactions-update = Actualitza el { -brand-short-name }
quickactions-cmd-update = actualitzar
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Codi font de la pàgina
quickactions-cmd-viewsource2 = mostra font, mostrar font, veure font, font, codi font, font de la pàgina
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Obre el { -firefoxlabs-brand-name }
quickactions-cmd-labs = labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Més informació sobre les accions ràpides
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Premeu el tabulador per seleccionar:

## Bookmark Panel

bookmarks-add-bookmark = Afegeix a les adreces d'interès
bookmarks-edit-bookmark = Edita l'adreça d'interès
bookmark-panel-cancel =
    .label = Cancel·la
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [one] Elimina l'adreça d'interès
           *[other] Elimina { $count } adreces d'interès
        }
    .accesskey = E
bookmark-panel-show-editor-checkbox =
    .label = Mostra l'editor en desar
    .accesskey = s
bookmark-panel-save-button2 =
    .label = Desa
    .accesskey = a
bookmark-panel-save-button =
    .label = Desa
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 30em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Informació del lloc { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Seguretat de la connexió per a { $host }
identity-connection-not-secure = La connexió no és segura
identity-connection-secure = Connexió segura
identity-connection-failure = La connexió ha fallat
identity-connection-internal = Aquesta és una pàgina del { -brand-short-name } segura.
identity-connection-file = Aquesta pàgina està desada a l'ordinador.
identity-connection-associated = Aquesta pàgina s'ha carregat des d'una altra pàgina.
identity-extension-page = Aquesta pàgina s'ha carregat des d'una extensió.
identity-active-blocked = El { -brand-short-name } ha blocat parts d'aquesta pàgina que no són segures.
identity-custom-root = Connexió verificada per un emissor de certificats que no és reconegut per Mozilla.
identity-passive-loaded = Parts d'aquesta pàgina no són segures (com les imatges).
identity-active-loaded = Heu desactivat la protecció en aquesta pàgina.
identity-weak-encryption = Aquesta pàgina utilitza xifratge feble.
identity-https-only-connection-upgraded = (actualitzat a HTTPS)
identity-https-only-label2 = Actualitza automàticament aquest lloc a una connexió segura
identity-https-only-dropdown-on =
    .label = Activat
identity-https-only-dropdown-off =
    .label = Desactivat
identity-https-only-dropdown-off-temporarily =
    .label = Desactivat temporalment
identity-https-only-info-turn-on3 = Activeu l'actualització a HTTPS per a aquest lloc si voleu que el { -brand-short-name } canviï a una connexió segura quan sigui possible.
identity-https-only-info-turn-off3 = Si sembla que la pàgina no funciona bé, podeu provar de desactivar l'actualització a HTTPS per a aquest lloc perquè es torni a carregar amb HTTP insegur.
identity-https-only-info-no-upgrade = No s'ha pogut actualitzar la connexió des d'HTTP.
identity-permissions-storage-access-header = Galetes entre llocs
identity-permissions-storage-access-hint = Aquests subjectes poden utilitzar galetes entre llocs i dades del lloc mentre esteu en aquest lloc.
identity-permissions-storage-access-learn-more = Més informació
identity-permissions-reload-hint = Potser cal que actualitzeu la pàgina per aplicar els canvis.
identity-clear-site-data =
    .label = Esborra les galetes i dades del lloc…
identity-connection-not-secure-security-view = No esteu connectat de forma segura a aquest lloc.
identity-connection-verified = Esteu connectat de forma segura a aquest lloc.
identity-ev-owner-label2 = Certificat emès per a
identity-verifier-label2 = Verificat per
identity-ev-owner-label = Certificat emès per a:
identity-verifier-label = Verificat per:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Qualificat segons l'especificació del Reglament (UE) 2024/1183.
identity-description-custom-root2 = Mozilla no reconeix aquest emissor de certificats. És possible que l'hagi afegit el vostre sistema operatiu o un administrador.
identity-cert-exception-overridden = Heu afegit una excepció de seguretat per a aquest lloc web.
identity-remove-cert-exception =
    .label = Elimina l'excepció
    .accesskey = x
identity-description-insecure = La connexió a aquest lloc no és privada. La informació que envieu podria ser visualitzada per altres persones (com contrasenyes, missatges, targetes de crèdit, etc.).
identity-description-weak-cipher-intro = La connexió a aquest lloc web utilitza un xifratge feble i no és privada.
identity-description-weak-cipher-risk = Altres persones podrien visualitzar la informació o modificar el comportament del lloc web.
identity-description-active-blocked2 = El { -brand-short-name } ha blocat parts d'aquesta pàgina que no són segures.
identity-description-passive-loaded = La connexió no és privada i la informació que compartiu amb el lloc podria ser visualitzada per altres persones.
identity-description-passive-loaded-insecure2 = Aquest lloc web inclou contingut que no és segur (com les imatges).
identity-description-passive-loaded-mixed2 = Malgrat que el { -brand-short-name } ha blocat parts del contingut, encara hi ha contingut de la pàgina que no és segur (such as images).
identity-description-active-loaded = Aquest lloc web inclou contingut que no és segur (com els scripts) i la connexió no és privada.
identity-description-active-loaded-insecure = La informació que compartiu amb aquest lloc podria ser visualitzada per altres persones (com contrasenyes, missatges, targetes de crèdit, etc.).
identity-description-tls-key-logging-heading = La vostra connexió no és privada
identity-description-tls-key-logging-message = Una aplicació o un servei pot veure el trànsit xifrat d'aquest lloc.
identity-more-info-link-text =
    .label = Més informació

## Window controls

browser-window-minimize-button =
    .tooltiptext = Minimitza
browser-window-maximize-button =
    .tooltiptext = Maximitza
browser-window-restore-down-button =
    .tooltiptext = Restaura avall
browser-window-close-button =
    .tooltiptext = Tanca
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Torna

## Bookmarks toolbar items

browser-import-button2 =
    .label = Importa les adreces d'interès…
    .tooltiptext = Importa les adreces d'interès d'un altre navegador al { -brand-short-name }.
bookmarks-toolbar-empty-message = Col·loqueu les adreces d'interès aquí, a la barra de les adreces d'interès, per accedir-hi ràpidament. <a data-l10n-name="manage-bookmarks">Gestiona les adreces d'interès…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Càmera:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = Càmera
popup-select-microphone-device =
    .value = Micròfon:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Micròfon
popup-select-speaker-icon =
    .tooltiptext = Altaveus
popup-select-window-or-screen =
    .label = Finestra o pantalla:
    .accesskey = F
popup-all-windows-shared = Es compartiran totes les finestres visibles de la pantalla.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Esteu compartint el { -brand-short-name }. Les altres persones poden veure quan canvieu a una pestanya nova.
sharing-warning-screen = Esteu compartint la pantalla sencera. Les altres persones poden veure quan canvieu a una pestanya nova.
sharing-warning-proceed-to-tab =
    .label = Vés a la pestanya
sharing-warning-disable-for-session =
    .label = Desactiva la protecció de compartició durant aquesta sessió

## WebSerial "select a port" popup

webserial-select-port-label = Seleccioneu un port en sèrie:
webserial-no-ports-available = No hi ha cap port en sèrie disponible

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Tanca
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Escriviu una cerca o adreça
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Escriviu una adreça
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Cerca amb { $name }
    .placeholder = Cerca al web
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Cerca en { $name }
    .placeholder = Escriviu els termes de la cerca
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Cerca en les adreces d'interès
    .placeholder = Escriviu els termes de la cerca
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Cerca en l'historial
    .placeholder = Escriviu els termes de la cerca
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Cerca en les pestanyes
    .placeholder = Escriviu els termes de la cerca
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Cerca d'accions
    .placeholder = Escriviu els termes de la cerca
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Cerqueu amb { $name } o escriviu una adreça
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = El navegador està sota control remot (motiu: { $component })
urlbar-permissions-granted =
    .tooltiptext = Heu donat permisos addicionals a aquest lloc web.
urlbar-switch-to-tab =
    .value = Canvia a la pestanya:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Extensió:
urlbar-go-button2 =
    .title = Vés a l'adreça de la barra d'ubicació
urlbar-page-action-button =
    .tooltiptext = Accions de la pàgina
urlbar-revert-button =
    .tooltiptext = Mostra l'adreça a la barra d'ubicació

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Cerca amb { $engine } en una finestra privada
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Cerca en una finestra privada
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Cerca amb { $engine }
urlbar-result-action-sponsored = Patrocinat
urlbar-result-action-switch-tab = Canvia a la pestanya
urlbar-result-action-move-tab-to-split-view = Mou la pestanya a la vista dividida
urlbar-result-action-visit = Visita
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Canvia a la pestanya · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Grup sense nom
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Obre l'adreça del porta-retalls
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Premeu Tab per cercar amb { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Premeu Tab per cercar en { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Cerca amb { $engine } directament des de la barra d'adreces
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Cerca en { $engine } directament des de la barra d'adreces
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Copia
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = indefinit
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Extensió del { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Recomanat
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> a { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> a { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> a { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Patrocinat
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Pregunta
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = L'heu visitat per darrer cop { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days =
    { $daysAgo ->
        [one] L'heu visitat per darrer cop fa { $daysAgo } dia
       *[other] L'heu visitat per darrer cop fa { $daysAgo } dies
    }
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks =
    { $weeksAgo ->
        [one] L'heu visitat per darrer cop fa { $weeksAgo } setmana
       *[other] L'heu visitat per darrer cop fa { $weeksAgo } setmanes
    }
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months =
    { $monthsAgo ->
        [one] L'heu visitat per darrer cop fa { $monthsAgo } mes
       *[other] L'heu visitat per darrer cop fa { $monthsAgo } mesos
    }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = L'heu visitat per darrer cop el dia { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Es va afegir a les adreces d'interès el dia { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = L'heu visitat per darrer cop el dia { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = L'heu visitat per darrer cop el dia { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = L'heu visitat per darrer cop el dia { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Obteniu dades del mercat de valors directament a la barra de cerca
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Mostra actualitzacions dels mercats i més informació dels nostres socis quan compartiu dades de consultes de cerca amb { -vendor-short-name }. <a data-l10n-name="learn-more-link">Més informació</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Mostra suggeriments
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Ara no
urlbar-result-realtime-opt-in-dismiss = Descarta
urlbar-result-realtime-opt-in-dismiss-all2 = No mostris aquests suggeriments
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = No mostris suggeriments dels mercats
    .accesskey = N
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = No mostris suggeriments dels mercats
urlbar-result-realtime-opt-in-dismiss-all =
    .label = No mostris aquests suggeriments
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = No mostris suggeriments dels mercats
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Gràcies pels vostres comentaris. Ja no veureu suggeriments dels mercats.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Suggeriments del mercat de valors
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Gràcies pels vostres comentaris. Ja no veureu aquests suggeriments.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [one] { $name } · D’aquí a { $daysUntilStart } dia
       *[other] { $name } · D’aquí a { $daysUntilStart } dies
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [one] { $name } · Comença d’aquí a { $daysUntilStart } dia
       *[other] { $name } · Comença d’aquí a { $daysUntilStart } dies
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [one] { $name } · Acaba d’aquí a { $daysUntilEnd } dia
       *[other] { $name } · Acaba d’aquí a { $daysUntilEnd } dies
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Avui
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Acaba avui

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Cerca amb { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Cerca { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Cerca amb { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, trieu un motor de cerca
urlbar-searchmode-button-no-engine2 =
    .title = No s'ha seleccionat cap drecera, trieu una drecera
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = La cerca de paraules clau està desactivada
urlbar-searchmode-dropmarker2 =
    .title = Trieu un motor de cerca
urlbar-searchmode-bookmarks4 = Adreces d'interès
urlbar-searchmode-tabs4 = Pestanyes
urlbar-searchmode-history4 = Historial
urlbar-searchmode-actions4 = Accions
urlbar-searchmode-bookmarks3 = Adreces d'interès
    .accesskey = A
urlbar-searchmode-tabs3 = Pestanyes
    .accesskey = P
urlbar-searchmode-history3 = Historial
    .accesskey = H
urlbar-searchmode-actions3 = Accions
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Tanca
urlbar-searchmode-default2 =
    .title = Motor de cerca per defecte
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Afegeix «{ $engineName }»
    .title = Afegeix el motor de cerca «{ $engineName }»
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Aquesta vegada, cerca amb:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Cerca amb:
urlbar-searchmode-popup-search-settings2 = Cerca paràmetres
urlbar-searchmode-popup-settings2 = Paràmetres
urlbar-searchmode-popup-search-settings = Cerca paràmetres
    .accesskey = C
urlbar-searchmode-popup-settings = Paràmetres
    .accesskey = P

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Cerca en les adreces d'interès
urlbar-result-action-search-history = Cerca en l'historial
urlbar-result-action-search-tabs = Cerca en les pestanyes
urlbar-result-action-search-actions = Cerca accions
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Canvia a { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Obre { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Obre en una pestanya nova
    .accesskey = v
urlbar-view-context-menu-open-in-container-tab =
    .label = Obre en una pestanya de contenidor nova
    .accesskey = e
urlbar-view-context-menu-open-in-window =
    .label = Obre en una finestra nova
    .accesskey = n
urlbar-view-context-menu-open-in-private-window =
    .label = Obre en una finestra privada nova
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = Obre en una pestanya nova
    .accesskey = v
urlbar-view-context-menu-open-in-container-tab2 = Obre en una pestanya de contenidor nova
    .accesskey = e
urlbar-view-context-menu-open-in-window2 = Obre en una finestra nova
    .accesskey = n
urlbar-view-context-menu-open-in-private-window2 = Obre en una finestra privada nova
    .accesskey = P
urlbar-view-context-menu-search-in-tab = Cerca en una pestanya nova
    .accesskey = C
urlbar-view-context-menu-search-in-container-tab = Cerca en una pestanya de contenidor nova
    .accesskey = i
urlbar-view-context-menu-search-in-window = Cerca en una finestra nova
    .accesskey = n
urlbar-view-context-menu-search-in-private-window = Cerca en una finestra privada nova
    .accesskey = p
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Omet aquest menú en utilitzar la tecla de tabulació
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Suggeriments de: { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Accions ràpides
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Cerques recents
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = És tendència a { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = No mostris les cerques que són tendència
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = No mostris les cerques que són tendència
    .accesskey = N
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = No mostris les cerques que són tendència
    .accesskey = N
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Gràcies pels vostres comentaris. Ja no veureu les cerques que són tendència.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Entra a la vista de lectura
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Tanca la vista de lectura

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Obre en mode d'Imatge sobre imatge ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Tanca el mode d'Imatge sobre imatge ({ $shortcut })
picture-in-picture-panel-header = Imatge sobre imatge
picture-in-picture-panel-headline = Aquest lloc web no recomana l'ús de la funció «imatge sobre imatge»
picture-in-picture-panel-body = Si activeu la funció d'«imatge sobre imatge», és possible que els vídeos no es mostrin com pretenia el desenvolupador.
picture-in-picture-enable-toggle =
    .label = Activa-ho igualment

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> està a pantalla completa
fullscreen-warning-no-domain = Aquest document està a pantalla completa
fullscreen-exit-button = Surt de la pantalla completa (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Surt de la pantalla completa (esc)
fullscreen-keyboardlock-exit-button = Surt de la pantalla completa (manteniu premuda la tecla Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Surt de la pantalla completa (manteniu premuda la tecla esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> té el control del punter. Premeu Esc per recuperar el control.
pointerlock-warning-no-domain = Aquest document té el control del punter. Premeu Esc per recuperar el control.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Gestiona les adreces d'interès
bookmarks-recent-bookmarks-panel-subheader = Adreces d'interès recents
bookmarks-toolbar-chevron =
    .tooltiptext = Mostra més adreces d'interès
bookmarks-sidebar-content =
    .aria-label = Adreces d'interès
bookmarks-menu-button =
    .label = Menú de les adreces d'interès
bookmarks-other-bookmarks-menu =
    .label = Altres adreces d'interès
bookmarks-mobile-bookmarks-menu =
    .label = Adreces del mòbil

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Amaga la barra lateral d'adreces d'interès
           *[other] Mostra la barra lateral de les adreces d'interès
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Amaga la barra d'eines d'adreces d'interès
           *[other] Mostra la barra de les adreces d'interès
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Amaga la barra de les adreces d'interès
           *[other] Mostra la barra de les adreces d'interès
        }

##

bookmarks-search =
    .label = Cerca adreces d'interès
bookmarks-tools =
    .label = Eines d'adreces d'interès
bookmarks-subview-edit-bookmark =
    .label = Edita aquesta adreça d'interès…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Adreces d'interès
    .toolbarname = Barra de les adreces d'interès
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Barra de les adreces d'interès
bookmarks-toolbar-placeholder =
    .title = Elements de la barra de les adreces d'interès
bookmarks-toolbar-placeholder-button =
    .label = Elements de la barra de les adreces d'interès
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Afegeix la pestanya actual a les adreces d'interès…

## Library Panel items

library-bookmarks-menu =
    .label = Adreces d'interès

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Repara la codificació del text
    .tooltiptext = Detecta la codificació del text correcta a partir del contingut de la pàgina

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Paràmetres
    .tooltiptext =
        { PLATFORM() ->
            [macos] Obre els paràmetres ({ $shortcut })
           *[other] Obre els paràmetres
        }
toolbar-overflow-customize-button =
    .label = Personalitza la barra d'eines…
    .accesskey = P
toolbar-button-email-link =
    .label = Envia l'enllaç per correu
    .tooltiptext = Envia per correu un enllaç a aquesta pàgina
toolbar-button-logins =
    .label = Contrasenyes
    .tooltiptext = Vegeu i gestioneu les contrasenyes que heu desat
qrcode-panel-error =
    .message = No s’ha pogut generar el codi QR. Torneu-ho a provar.
qrcode-copy-button =
    .label = Copia
qrcode-copy-success =
    .message = S’ha copiat el codi QR al porta-retalls
qrcode-copy-error =
    .message = No s’ha pogut copiar el codi QR.
qrcode-save-button =
    .label = Desa
qrcode-window-title = Codi QR
qrcode-dialog-title = Codi QR
qrcode-image =
    .aria-label = Codi QR
qrcode-close-button =
    .aria-label = Tanca
toolbar-button-save-page =
    .label = ­Desa la pàgina
    .tooltiptext = Desa aquesta pàgina ({ $shortcut })
toolbar-button-open-file =
    .label = Obre un fitxer
    .tooltiptext = Obre un fitxer ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Pestanyes sincronitzades
    .tooltiptext = Mostra les pestanyes d'altres dispositius
toolbar-button-send-tab =
    .label = Envia la pestanya
    .tooltiptext = Envieu la pestanya actual a un altre dispositiu
toolbar-button-new-private-window =
    .label = Finestra privada nova
    .tooltiptext = Obre una finestra de navegació privada nova ({ $shortcut })
toolbar-button-share-tab =
    .label = Comparteix
    .tooltiptext = Comparteix aquesta pàgina
toolbar-button-tab-groups =
    .label = Grups de pestanyes
    .tooltiptext = Mostreu els vostres grups de pestanyes
toolbar-button-history =
    .label = Historial
    .tooltiptext = Mostra l'historial ({ $shortcut })
toolbar-button-find =
    .label = Cerca
    .tooltiptext = Cerca en aquesta pàgina ({ $shortcut })
toolbar-button-developer =
    .label = Desenvolupador
    .tooltiptext = Obre les eines per a desenvolupadors web ({ $shortcut })
toolbar-button-forget =
    .label = Oblida
    .tooltiptext = Oblida part de l'historial de navegació
toolbar-zoom-controls =
    .label = Controls del zoom
    .title = Controls del zoom
toolbar-button-zoom-out =
    .label = Redueix
    .tooltiptext = Redueix ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Reinicia el nivell de zoom ({ $shortcut })
toolbar-button-zoom-in =
    .label = Amplia
    .tooltiptext = Amplia ({ $shortcut })
toolbar-edit-controls =
    .label = Controls d'edició
    .title = Controls d'edició
toolbar-button-cut =
    .label = Retalla
    .tooltiptext = Retalla ({ $shortcut })
toolbar-button-copy =
    .label = Copia
    .tooltiptext = Copia ({ $shortcut })
toolbar-button-paste =
    .label = Enganxa
    .tooltiptext = Enganxa ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = codiqr
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = codi qr-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Aquest lloc conté àudio o vídeo que utilitza programari de DRM, cosa que pot limitar allò que el { -brand-short-name } us pot permetre fer.
eme-notifications-drm-content-playing-manage = Gestiona els paràmetres
eme-notifications-drm-content-playing-manage-accesskey = G
eme-notifications-drm-content-playing-dismiss = Descarta
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Cal activar el DRM per reproduir àudio o vídeo d'aquesta pàgina.
eme-notifications-drm-content-disabled-button =
    .label = Activa el DRM
    .accesskey = v
eme-notifications-drm-content-cdm-installing-message = El { -brand-short-name } està instal·lant els components necessaris per reproduir l'àudio o vídeo d'aquesta pàgina. Torneu-ho a provar més tard.
decoder-doctor-no-codecs-linux-message = Per reproduir vídeo, potser us cal instal·lar els còdecs de vídeo necessaris.
decoder-doctor-no-hw-acceleration-message = Per millorar la qualitat del vídeo, potser us cal instal·lar el Media Feature Pack de Microsoft.
decoder-doctor-no-pulse-audio-message = Per reproduir àudio, potser us cal instal·lar el programari PulseAudio necessari.
decoder-doctor-unsupported-libavcodec-message = libavcodec podria ser vulnerable o incompatible, i cal actualitzar-lo per reproduir vídeo.
decoder-doctor-decode-error-message = S'ha produït un error en descodificar un recurs multimèdia.
decoder-doctor-decode-warning-message = S'ha produït un error recuperable en descodificar un recurs multimèdia.
decoder-doctor-learn-how-link = Vegeu com fer-ho
decoder-doctor-report-issue-button =
    .label = Informa d'un problema amb el lloc
    .accesskey = I
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = El connector { $pluginName } ha fallat.
plugin-crashed-notification-reload-button =
    .label = Torna a carregar la pàgina
    .accesskey = r
plugin-crashed-notification-submit-button =
    .label = Envia un informe de fallada
    .accesskey = f

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Aquest lloc pot ser enganyós!
safebrowsing-reported-attack-site-message = S'ha informat que es tracta d'un lloc atacant!
safebrowsing-reported-unwanted-site-message = Aquest lloc pot contenir programari indesitjable!
safebrowsing-reported-harmful-site-message = S'ha informat que el lloc web és maliciós!
safebrowsing-get-me-out-of-here-button =
    .label = Treu-me d'aquí!
    .accesskey = T
safebrowsing-not-a-deceptive-site-button =
    .label = No és cap lloc enganyós…
    .accesskey = e
safebrowsing-not-an-attack-site-button =
    .label = No és cap lloc atacant…
    .accesskey = a

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Heu d'iniciar la sessió en aquesta xarxa per poder accedir a Internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Obre la pàgina d'inici de sessió a la xarxa

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Potser volíeu anar a { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Sí, vés a { $hostName }
    .accesskey = S

## Password save/update panel

panel-save-update-username-2 =
    .label = Nom d'usuari
panel-save-update-password-2 =
    .label = Contrasenya

##

# "More" item in macOS share menu
menu-share-more =
    .label = Més…
menu-share-windows =
    .label = Més opcions
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] Copia l’enllaç
           *[other] Copia { $count } enllaços
        }
    .accesskey = l
ui-tour-info-panel-close =
    .tooltiptext = Tanca

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Permet les finestres emergents i les redireccions de tercers per a { $uriHost }
    .accesskey = P

##

picture-in-picture-hide-toggle =
    .label = Amaga el botó d'Imatge sobre imatge
    .accesskey = m

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Mou el botó d'Imatge sobre imatge al costat dret
    .accesskey = d
picture-in-picture-move-toggle-left =
    .label = Mou el botó d'Imatge sobre imatge al costat esquerre
    .accesskey = e

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Navegació
navbar-downloads =
    .label = Baixades
navbar-overflow-2 =
    .tooltiptext = Més eines
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = Imprimeix
    .tooltiptext = Imprimeix aquesta pàgina… ({ $shortcut })
navbar-home =
    .label = Inici
    .tooltiptext = Pàgina d'inici del { -brand-short-name }
navbar-library =
    .label = Biblioteca
    .tooltiptext = Mostra l'historial, les adreces d'interès desades i més
navbar-search =
    .title = Cerca
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Pestanyes del navegador
tabs-toolbar-new-tab =
    .label = Pestanya nova
tabs-toolbar-list-all-tabs-2 =
    .label = Cerca i gestiona les pestanyes
    .tooltiptext = Cerca i gestiona les pestanyes
tabs-toolbar-list-all-tabs =
    .label = Llista totes les pestanyes
    .tooltiptext = Llista totes les pestanyes

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Deixeu anar la pestanya aquí per a fixar-la

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Voleu obrir les pestanyes anteriors?</strong> Podeu restaurar la sessió anterior des del menú de l'aplicació del { -brand-short-name } <img data-l10n-name="icon"/>, dins l'«Historial».
restore-session-startup-suggestion-button = Mostra com fer-ho

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = La vostra organització ha blocat l'accés als fitxers locals d'aquest ordinador

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } ara cerca a les pestanyes
urlbar-addons-shortcut-moved-description = Per obrir les extensions i els temes, utilitzeu { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Gestiona les dreceres
urlbar-addons-shortcut-moved-dismiss = Entesos

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } tramet automàticament algunes dades a { -vendor-short-name } perquè puguem millorar la vostra experiència.
data-reporting-notification-button =
    .label = Deixa'm triar què vull compartir
    .accesskey = c
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Navegació privada
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Navegació privada
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Informació de navegació privada
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Sou en una finestra privada
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Això ajuda a mantenir la vostra navegació oculta als altres usuaris d'aquest dispositiu, però no us fa invisible en línia. <a data-l10n-name="learn-more">Qui podria veure la meva activitat?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Prevenció de pèrdua de dades (DLP) de { $agentName }. Feu clic per a més informació.
content-analysis-panel-title2 = Prevenció de la pèrdua de dades
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = La vostra organització utilitza <b>{ $agentName }</b> per controlar com es poden compartir dades sensibles. <a data-l10n-name="info">Més informació</a>
content-analysis-panel-title = Protecció de dades
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = La vostra organització utilitza <b>{ $agentName }</b> per a protegir-se contra la pèrdua de dades. <a data-l10n-name="info">Més informació</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Extensions
    .tooltiptext = Extensions

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Extensions
    .tooltiptext =
        Extensions
        Calen permisos

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Extensions
    .tooltiptext =
        Extensions
        No es permeten algunes extensions

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Extensions
    .tooltiptext =
        Extensions
        Algunes extensions estan desactivades

## Private browsing reset button

reset-pbm-panel-heading2 = Voleu esborrar les dades i iniciar una sessió privada nova?
reset-pbm-panel-description3 = Això esborra l'historial i les galetes, i tanca la sessió dels llocs web. Les finestres privades es tancaran i se n'obrirà una de nova.
reset-pbm-panel-description2 = Això suprimeix l'historial, les galetes i totes les altres dades del lloc sense tancar la finestra privada.
reset-pbm-panel-always-ask-checkbox =
    .label = Demana-m'ho sempre
    .accesskey = D
reset-pbm-panel-cancel-button =
    .label = Cancel·la
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = Esborra la sessió privada
    .accesskey = s
reset-pbm-panel-complete = S'han suprimit les dades de la sessió privada
reset-pbm-toolbar-button2 =
    .label = Esborra la sessió privada
    .tooltiptext = Esborreu la sessió privada

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Voleu suprimir totes les dades de navegació?
fire-button-panel-description = Això suprimeix l'historial, les galetes i les dades dels llocs. Es tancarà la sessió als llocs. Aquesta finestra es tancarà i el { -brand-short-name } n'obrirà una de nova.
fire-button-panel-choose-description = Si no voleu suprimir-ho tot, trieu només algunes dades.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Tria…
fire-button-panel-cancel-button =
    .label = Cancel·la
    .accesskey = C
fire-button-panel-confirm-button =
    .label = Suprimeix-ho tot
    .accesskey = S
fire-button-panel-complete = S'han suprimit les dades de navegació
fire-button-toolbar-button2 =
    .label = Suprimeix algunes o totes les dades
    .tooltiptext = Suprimeix algunes o totes les dades de navegació

## Autorefresh blocker

refresh-blocked-refresh-label = El { -brand-short-name } ha evitat que la pàgina s'actualitzi automàticament.
refresh-blocked-redirect-label = El { -brand-short-name } ha evitat que la pàgina redirigeixi automàticament a una altra.
refresh-blocked-allow =
    .label = Permet
    .accesskey = P

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Les màscares, segures i fàcils d'utilitzar, protegeixen la vostra identitat i eviten el correu brossa amagant la vostra adreça electrònica.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Tots els missatges de correu enviats a les vostres màscares d'adreça electrònica es reenviaran a <strong>{ $useremail }</strong> (tret que decidiu blocar-los).
firefox-relay-offer-legal-notice = En fer clic a «Utilitza una màscara d'adreça electrònica», accepteu les <label data-l10n-name="tos-url">condicions d'ús del servei</label> i l'<label data-l10n-name="privacy-url">avís de privadesa</label>.
firefox-relay-offer-legal-notice-1 = En registrar-vos i crear una màscara d'adreça electrònica, accepteu les <label data-l10n-name="tos-url">Condicions del servei</label> i l'<label data-l10n-name="privacy-url">Avís de privadesa</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (No verificat)
popup-notification-xpinstall-prompt-learn-more = Més informació sobre la instal·lació de complements de forma segura
popup-notification-xpinstall-prompt-block-url = Mostra detalls
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Permet que l’extensió s’executi en finestres privades
    .accesskey = P
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Comparteix dades tècniques i d’interacció amb el desenvolupador de l’extensió
    .accesskey = d

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] El { -brand-short-name } ha impedit que aquest lloc obrís una finestra emergent.
       *[other] El { -brand-short-name } ha impedit que aquest lloc obrís { $popupCount } finestres emergents.
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } ha evitat que aquest lloc redirigeixi.
        [1] { -brand-short-name } ha evitat que aquest lloc obri una finestra emergent i redirigeixi.
        [one] { -brand-short-name } ha evitat que aquest lloc obri una finestra emergent i redirigeixi.
       *[other] { -brand-short-name } ha evitat que aquest lloc obri { $popupCount } finestres emergents i redirigeixi.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = El { -brand-short-name } ha impedit que aquest lloc obrís més de { $popupCount } finestres emergents.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
        [one] { -brand-short-name } ha evitat que aquest lloc obri més d'{ $popupCount } finestra emergent i redirigeixi.
       *[other] { -brand-short-name } ha evitat que aquest lloc obri més de { $popupCount } finestres emergents i redirigeixi.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Opcions
           *[other] Preferències
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Mostra «{ $popupURI }»
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Mostra “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = No s'ha pogut obrir el diàleg de fitxers del Windows. No s'ha pogut seleccionar cap fitxer ni carpeta.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = No s'ha pogut obrir el diàleg de fitxers del Windows. El fitxer es desarà a { $path }.
file-picker-failed-save-nowhere = No s'ha pogut obrir el diàleg de fitxers del Windows. No s'ha trobat cap carpeta per defecte; el fitxer no es desarà.
file-picker-crashed-open = El diàleg de fitxers del Windows ha fallat. No s'ha pogut seleccionar cap fitxer ni carpeta.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = El diàleg de fitxers del Windows ha fallat. El fitxer es desarà a { $path }.
file-picker-crashed-save-nowhere = El diàleg de fitxers del Windows ha fallat. No s'ha trobat cap carpeta per defecte; el fitxer no es desarà.
file-picker-crashed-show-in-folder =
    .label = Mostra en la carpeta
    .accessKey = M

## Unsigned add-ons notification

unsigned-addons-disabled-message = Un o més complements instal·lats no estan verificats i s'han inhabilitat.
unsigned-addons-disabled-learn-more =
    .label = Més informació
    .accesskey = M

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Aquesta pàgina fa que el { -brand-short-name } vagi més lent. Per accelerar el navegador, atureu-la.
process-hang-nonspecific-tab-message = Una pàgina web fa que el { -brand-short-name } vagi més lent. Per accelerar el navegador, atureu-la.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = La pàgina «{ $title }» fa que el { -brand-short-name } vagi més lent. Per accelerar el navegador, atureu-la.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = L'extensió «{ $addonName }» fa que el { -brand-short-name } vagi més lent. Per accelerar el navegador, atureu-la.
process-hang-addon-learn-more =
    .value = Més informació
process-hang-stop-button =
    .label = Atura
    .accesskey = A

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Finalitza la configuració
onboarding-aw-finish-setup-button =
    .label = Finalitza la configuració
    .tooltiptext = Finalitza la configuració del { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = La protecció contra el seguiment millorada està activada
trustpanel-etp-label-disabled = La protecció contra el seguiment millorada està desactivada
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Protecció contra el seguiment millorada: Activada per a { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Protecció contra el seguiment millorada: Desactivada per a { $host }
trustpanel-etp-description-enabled = Si us sembla que aquest lloc no funciona bé, proveu de desactivar les proteccions.
trustpanel-etp-description-disabled = El { -brand-product-name } creu que les empreses us haurien de fer menys seguiment. Bloquem tants elements de seguiment com podem quan activeu les proteccions.
trustpanel-connection-label-secure = Connexió segura
trustpanel-connection-label-insecure = La connexió no és segura
trustpanel-header-enabled = El { -brand-product-name } està en guàrdia
trustpanel-description-enabled2 = Esteu protegit. Si detectem alguna cosa, us ho farem saber.
trustpanel-header-enabled-insecure = Aneu amb compte en aquest lloc
trustpanel-description-enabled-insecure = El { -brand-product-name } ha notat alguna cosa sospitosa.
trustpanel-header-disabled = Heu desactivat les proteccions
trustpanel-description-disabled = El { -brand-product-name } està fora de servei. Us recomanem reactivar les proteccions.
trustpanel-clear-cookies-button = Esborra les galetes i dades del lloc
trustpanel-privacy-link = Paràmetres de privadesa
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Esborra les galetes i les dades del lloc { $host }
trustpanel-clear-cookies-description = En eliminar les galetes i les dades del lloc, pot ser que se us tanquin les sessions o que se us buidin els carros de la compra dels llocs web.
trustpanel-clear-cookies-subview-button-clear = Esborra
trustpanel-clear-cookies-subview-button-cancel = Cancel·la
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Proteccions de connexió per a { $host }
trustpanel-siteinformation-morelink = Més informació del lloc
trustpanel-blocker-see-all = Mostra-ho tot
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Proteccions conta el seguiment per a { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Insegur
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label =
    { $count ->
        [one] { $count } element de seguiment blocat
       *[other] { $count } elements de seguiment blocats
    }

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = El { -brand-product-name } creu que les empreses us haurien de fer menys seguiment, així que bloquem tot allò que podem.
trustpanel-blocked-header = El { -brand-product-name } ha blocat això:
trustpanel-tracking-header = El { -brand-product-name } ha permès això perquè els llocs web funcionin bé:
trustpanel-tracking-description = Sense elements de seguiment, és possible que no funcionin alguns botons, formularis o camps d’inici de sessió.
trustpanel-insecure-section-header = La connexió no és segura
trustpanel-insecure-description = Les dades que envieu a aquest lloc no estan xifrades. Es podrien visualitzar, robar alterar.
trustpanel-list-label-tracking-cookies =
    { $count ->
        [one] { $count } galeta de seguiment entre llocs
       *[other] { $count } galetes de seguiment entre llocs
    }
trustpanel-list-label-tracking-content = Contingut que fa seguiment
trustpanel-list-label-fingerprinter =
    { $count ->
        [one] { $count } generador d’empremtes digitals
       *[other] { $count } generadors d’empremtes digitals
    }
trustpanel-list-label-social-tracking =
    { $count ->
        [one] { $count } element de seguiment de xarxes socials
       *[other] { $count } elements de seguiment de xarxes socials
    }
trustpanel-list-label-cryptominer =
    { $count ->
        [one] { $count } miner de criptomonedes
       *[other] { $count } miners de criptomonedes
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha blocat { $count } element de seguiment de xarxes socials
       *[other] El { -brand-product-name } ha blocat { $count } elements de seguiment de xarxes socials
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha permès { $count } element de seguiment de xarxes socials
       *[other] El { -brand-product-name } ha permès { $count } elements de seguiment de xarxes socials
    }
trustpanel-tracking-cookies-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha blocat { $count } galeta de seguiment entre llocs
       *[other] El { -brand-product-name } ha blocat { $count } galetes de seguiment entre llocs
    }
trustpanel-tracking-cookies-not-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha permès { $count } galeta de seguiment entre llocs
       *[other] El { -brand-product-name } ha permès { $count } galetes de seguiment entre llocs
    }
trustpanel-tracking-content-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha blocat { $count } element de seguiment
       *[other] El { -brand-product-name } ha blocat { $count } elements de seguiment
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha permès { $count } element de seguiment
       *[other] El { -brand-product-name } ha permès { $count } elements de seguiment
    }
trustpanel-tracking-content-tab-list-header = Aquests llocs us intenten fer seguiment:
trustpanel-fingerprinter-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha blocat { $count } generador d’empremtes digitals
       *[other] El { -brand-product-name } ha blocat { $count } generadors d’empremtes digitals
    }
trustpanel-fingerprinter-not-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha permès { $count } generador d’empremtes digitals
       *[other] El { -brand-product-name } ha permès { $count } generadors d’empremtes digitals
    }
trustpanel-fingerprinter-list-header = Aquests llocs intenten generar la vostra empremta digital:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha blocat { $count } miner de criptomonedes
       *[other] El { -brand-product-name } ha blocat { $count } miners de criptomonedes
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [one] El { -brand-product-name } ha permès { $count } miner de criptomonedes
       *[other] El { -brand-product-name } ha permès { $count } miners de criptomonedes
    }
trustpanel-cryptominer-tab-list-header = Aquests llocs intenten minar criptomonedes:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Ja teniu un compte en aquest lloc?
trustpanel-breachalerts-anonymous-breached-description = El { -brand-product-name } ha descobert que aquest lloc web ha patit una filtració de dades els últim 12 mesos. Esbrineu si us ha afectat.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Ignora
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Inicia l'escaneig gratuït
trustpanel-blocker-section-header2 =
    { $count ->
        [one] S'ha bloquejat <span data-l10n-name="count">{ $count }</span> element de seguiment en aquest lloc
       *[other] S'han bloquejat <span data-l10n-name="count">{ $count }</span> elements de seguiment en aquest lloc
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>El lloc web sembla trencat?</strong> Torneu a carregar la pàgina per a reduir temporalment la protecció contra el seguiment.
reduced-protection-infobar-reload-button = Torna a carregar
    .accesskey = T
reduced-protection-infobar-never-show-button = No tornis a mostrar-ho
    .accesskey = N


identity-allow-site-data = vOrbit-lite: Emmagatzema sempre les galetes/dades d'aquest lloc
