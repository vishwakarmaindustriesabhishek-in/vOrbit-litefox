# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Sol·licita als llocs web que no venguin ni comparteixin les meves dades
    .accesskey = S
non-technical-privacy-group =
    .label = Preferències de privadesa del lloc web
do-not-track-removal3 =
    .message = Ja no s'admet la funció «No vull ser seguit».
non-technical-privacy-heading =
    .label = Proteccions addicionals
preferences-privacy-relay-available =
    .description = Amaga la vostra adreça electrònica real per protegir-vos del correu brossa
    .label = Suggereix màscares d'adreça electrònica del { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Paràmetres
category-nav-heading =
    .heading = Paràmetres
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Cerca en els paràmetres
    .style = width: 15.4em
managed-notice = El navegador està gestionat per la vostra organització.
managed-notice-info-icon =
    .alt = Informació
managed-notice-nav =
    .label = El navegador està gestionat per la vostra organització.
tls-key-logging-notice-nav =
    .label = Una aplicació o un servei pot veure el trànsit xifrat.
category-list =
    .aria-label = Categories
pane-general-title = General
pane-home-title = Inici
pane-home-startup-title2 = Pàgina d’inici i inicialització
    .title = Pàgina d’inici i inicialització
pane-search-title2 = Cerca
    .title = Cerca
pane-privacy-title3 = Privadesa i seguretat
    .title = Privadesa i seguretat
pane-privacy-section =
    .heading = Privadesa i seguretat
pane-sync-title3 = Sincronització
pane-ai-controls-title2 = Controls d’IA
    .title = Controls d’IA
pane-about-firefox-title = Quant al { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Aparença
    .title = { pane-appearance-title }
pane-downloads-title2 = Baixades
    .title = Baixades
pane-downloads3 =
    .heading = Baixades
pane-accessibility-title = Accessibilitat
    .title = { pane-accessibility-title }
pane-languages-title2 = Llengües
    .title = Llengües
preferences-languages-header3 =
    .heading = Llengües
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Proveu les funcions experimentals. Com que estan en desenvolupament i en continua evolució, podrien afectar el funcionament del { -brand-short-name }. Només es recullen dades sobre com utilitzeu aquestes funcions si teniu activades les <a data-l10n-name="data-collection">dades tècniques i d’interacció</a>.
pane-experimental-reset =
    .label = Restaura els valors per defecte
    .accesskey = R
help-button-label2 = Assistència del { -brand-short-name }
    .title = Assistència del { -brand-short-name }
addons-button-label2 = Extensions i temes
    .title = Extensions i temes
focus-search =
    .key = f
close-button =
    .aria-label = Tanca
do-not-track-removal2 =
    .label = Ja no s'admet el senyal «No vull ser seguit»
applications-setting-new-file-types =
    .label = Què ha de fer el { -brand-short-name } amb els altres fitxers?

## Browser Restart Dialog

feature-enable-requires-restart = Heu de reiniciar el { -brand-short-name } per habilitar aquesta característica.
feature-disable-requires-restart = Heu de reiniciar el { -brand-short-name } per inhabilitar aquesta característica.
should-restart-title = Reinicia el { -brand-short-name }
should-restart-ok = Reinicia el { -brand-short-name } ara
cancel-no-restart-button = Cancel·la
restart-later = Reinicia més tard

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = L'extensió <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla aquest paràmetre.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = L'extensió <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla aquest paràmetre.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = L'extensió <img data-l10n-name="icon"/> <strong>{ $name }</strong> requereix pestanyes de contenidor.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = L'extensió <img data-l10n-name="icon"/> <strong>{ $name }</strong> controla aquest paràmetre.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = L'extensió <img data-l10n-name ="icon"/> <strong>{ $name }</strong> controla com el { -brand-short-name } es connecta a Internet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Per activar l'extensió, aneu a <img data-l10n-name="addons-icon"/> Complements del menú <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Per tornar a activar aquesta extensió, aneu a <a data-l10n-name="addons-link">Extensions i temes</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } controla alguns dels paràmetres de la pàgina d'inici.

## Preferences UI Search Results

search-results-header = Resultats de la cerca
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = No s'ha trobat «<span data-l10n-name="query"></span>» als paràmetres.
search-results-help-link = Necessiteu ajuda? Visiteu l'<a data-l10n-name="url">assistència del { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Comprova sempre si el { -brand-short-name } és el navegador per defecte
    .accesskey = o
startup-restore-windows-and-tabs =
    .label = Obre les finestres i pestanyes anteriors
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = Activeu aquesta preferència marcant «{ profile-manager-use-selected.label }» a la finestra «Trieu un perfil d'usuari».
windows-launch-on-login =
    .label = Obre el { -brand-short-name } automàticament en iniciar l'ordinador
    .accesskey = O
windows-launch-on-login-disabled = Aquesta preferència s'ha desactivat al Windows. Per canviar-la, aneu a <a data-l10n-name="startup-link">Aplicacions d'inici</a> en els paràmetres del sistema.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Obre també una pestanya nova
    .accesskey = n
disable-extension =
    .label = Inhabilita l'extensió
preferences-data-migration-group =
    .description = Importeu les adreces d'interès, les contrasenyes, l'historial, les extensions i les dades d'emplenament automàtic d'un altre navegador.
    .label = Importa les dades d'un altre navegador
preferences-data-migration-button =
    .label = Importa les dades
    .accesskey = m
preferences-profiles-group-header =
    .heading = Perfils
preferences-profiles-subpane-description =
    .description = Cada perfil té els paràmetres i les dades de navegació separats, com ara l'historial i les contrasenyes, entre d'altres.
preferences-profiles-section-header =
    .description = Cada perfil té els paràmetres i les dades de navegació separats, com ara l'historial i les contrasenyes, entre d'altres.
    .label = Perfils
preferences-manage-profiles-button =
    .label = Gestiona els perfils
preferences-profiles-settings-button =
    .label = Paràmetres
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = El perfil nou copiarà els paràmetres, els complements, l'historial i les dades desades, com ara les adreces d'interès i les contrasenyes, però no copiarà la informació del compte ni la de sincronització.
    .label = Copia un perfil existent
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Perfil que voleu copiar
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Seleccioneu el perfil
preferences-copy-profile-button = Copia
tabs-browsing-section =
    .heading = Pestanyes i navegació
pane-tabs-browsing-title2 = Pestanyes i navegació
    .title = Pestanyes i navegació
tabs-group-header2 =
    .label = Pestanyes
tabs-opening-heading =
    .label = Obertura
tabs-interaction-heading =
    .label = Interacció
tabs-containers-heading =
    .label = Contenidors
tabs-closing-heading =
    .label = Tancament
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab canvia de pestanya en ordre d'ús recent
    .accesskey = T
open-new-link-as-tabs =
    .label = Obre els enllaços en pestanyes en lloc de finestres noves
    .accesskey = t
open-external-link-next-to-active-tab =
    .label = Obre els enllaços provinents d'aplicacions al costat de la pestanya activa
ask-on-close-multiple-tabs =
    .label = Pregunta abans de tancar diverses pestanyes de cop
    .accesskey = P
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Pregunta abans de sortir amb { $quitKey }
    .accesskey = b
warn-on-open-many-tabs =
    .label = Avisa quan el fet d'obrir moltes pestanyes pugui alentir el { -brand-short-name }
    .accesskey = o
switch-to-new-tabs-2 =
    .label = En obrir enllaços o contingut multimèdia en una pestanya nova, vés-hi immediatament
    .accesskey = E
show-tabs-in-taskbar =
    .label = Mostra les previsualitzacions de les pestanyes a la barra de tasques del Windows
    .accesskey = q
browser-containers-enabled-2 =
    .label = Utilitza pestanyes de contenidor
    .accesskey = n
browser-containers-learn-more = Més informació
browser-containers-settings-2 =
    .label = Gestiona els paràmetres
    .accesskey = i
containers-disable-alert-title = Voleu tancar totes les pestanyes de contenidor?
startup-group =
    .label = Inici

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Si desactiveu les pestanyes de contenidor ara, es tancarà { $tabCount } pestanya de contenidor. Segur que voleu desactivar les pestanyes de contenidor?
       *[other] Si desactiveu les pestanyes de contenidor ara, es tancaran { $tabCount } pestanyes de contenidor. Segur que voleu desactivar les pestanyes de contenidor?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Tanca { $tabCount } pestanya de contenidor
       *[other] Tanca { $tabCount } pestanyes de contenidor
    }

##

containers-disable-alert-cancel-button = Mantén activades
containers-remove-alert-title = Voleu eliminar aquest contenidor?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Si elimineu aquest contenidor ara, es tancarà { $count } pestanya de contenidor. Segur que voleu eliminar aquest contenidor?
       *[other] Si elimineu aquest contenidor ara, es tancaran { $count } pestanyes de contenidor. Segur que voleu eliminar aquest contenidor?
    }
containers-remove-ok-button = Elimina aquest contenidor
containers-remove-cancel-button = No eliminis aquest contenidor
settings-tabs-show-image-in-preview =
    .label = Mostra una vista prèvia de la imatge en passar el cursor per sobre d'una pestanya
    .accessKey = M
settings-tabs-drag-to-create-tab-groups =
    .label = Arrossegueu una pestanya a sobre d'una altra per crear grups de pestanyes
browser-layout-header2 =
    .label = Disposició del navegador
browser-layout-horizontal-tabs2 =
    .description = Pestanyes a la part superior
    .label = Pestanyes horitzontals
    .title = Pestanyes a la part superior
browser-layout-vertical-tabs2 =
    .description = Pestanyes al costat, a la barra lateral
    .label = Pestanyes verticals
    .title = Pestanyes al costat, a la barra lateral
browser-layout-show-sidebar2 =
    .description = Accediu ràpidament a les adreces d'interès, a les pestanyes del telèfon, als bots de conversa d'IA i molt més sense sortir de la vista principal.
    .label = Mostra la barra lateral
page-navigation-group =
    .label = Navegació de la pàgina

## General Section - Language & Appearance

language-and-appearance-header = Llengua i aparença
appearance-group2 =
    .description = Alguns llocs web canvien els colors per adaptar-se a les vostres preferències. Trieu l'esquema de colors.
    .label = Aparença dels llocs web
preferences-web-appearance-choice-auto3 =
    .label = Sistema
    .title = Automàticament canvia el fons i el contingut dels llocs webs segons els paràmetres del sistema i el tema del { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Clar
    .title = Usa un aspecte clar per al fons i el contingut dels llocs web.
preferences-web-appearance-choice-dark2 =
    .label = Fosc
    .title = Usa un aspecte fosc per al fons i el contingut dels llocs web.
web-appearance-group =
    .aria-label = Aparença dels llocs web
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Els paràmetres de control del contrast modifiquen l'aparença dels llocs web.
preferences-web-appearance-link =
    .label = Gestioneu els temes del { -brand-short-name } a Extensions i temes
preferences-contrast-control-group =
    .description = Els llocs web utilitzen una varietat de colors de primer pla i de fons. Si voleu que el contrast sigui constant, podeu utilitzar els mateixos colors en tots els llocs web.
    .label = Contrast dels llocs web
preferences-contrast-control-radio-group =
    .label = Substitueix els colors
preferences-contrast-control-use-platform-settings =
    .label = Automàtic (utilitza els paràmetres del sistema)
    .accesskey = A
preferences-contrast-control-off =
    .label = Desactivat
    .accesskey = D
preferences-contrast-control-custom =
    .label = Personalitzat
    .accesskey = P
preferences-colors-manage-button2 =
    .label = Gestiona els colors
    .accesskey = c
preferences-colors-manage-button =
    .label = Gestiona els colors…
    .accesskey = c
preferences-fonts-header2 =
    .label = Tipus de lletra
preferences-default-zoom-label =
    .label = Zoom per defecte
    .accesskey = Z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Amplia només el text
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = Si l'opció «Amplia només el text» està activada i el zoom per defecte no és del 100 %, és possible que alguns llocs web no mostrin el contingut correctament.
language-header = Llengua
choose-language-description = Trieu la llengua en què es mostraran preferentment les pàgines
website-language-heading =
    .description = Algunes pàgines web es mostren en diverses llengües. Trieu les llengües en l'ordre que preferiu.
    .label = Llengua dels llocs web
website-preferred-language =
    .label = Llengües preferides
website-language-list =
    .aria-label = Llengües preferides
website-add-language =
    .label = Afegeix una llengua
website-add-language-button =
    .aria-label = Afegeix la llengua seleccionada
    .title = Afegeix la llengua seleccionada
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Elimina { $locale }
    .title = Elimina { $locale }
choose-button =
    .label = Trieu…
    .accesskey = T
choose-browser-language-description = Trieu la llengua en què es mostraran els menús, els missatges i les notificacions del { -brand-short-name }.
manage-browser-languages-button =
    .label = Defineix alternatives…
    .accesskey = l
confirm-browser-language-change-description = Reinicieu el { -brand-short-name } per aplicar aquests canvis
confirm-browser-language-change-button = Aplica i reinicia
browser-language-heading =
    .description = Trieu la llengua usada per a mostrar els menús, missatges i notificacions del { -brand-short-name }.
    .label = Llengua del navegador
browser-language-preferred-label =
    .label = Llengua preferida
browser-language-fallback-label =
    .description = S'utilitza quan la localització de l'idioma preferit és incompleta.
    .label = Idioma alternatiu
browser-language-install-error =
    .message = El { -brand-short-name } no ha pogut actualitzar les llengües. Comproveu que esteu connectat a Internet o torneu-ho a provar.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Excepcions…
    .accesskey = x
settings-translations-header =
    .aria-label = Traduccions
    .description = Traduïu pàgines o el text seleccionat. Per protegir la vostra privadesa, les traduccions es fan en el vostre dispositiu.
    .label = Traduccions
settings-translations-offer-to-translate-label =
    .label = Ofereix traduir la pàgina sencera
settings-translations-more-settings-button =
    .description = Definiu les preferències pel que fa a llengües, llocs web i traducció fora de línia.
    .label = Més paràmetres de traducció
settings-translations-subpage-header =
    .heading = Més paràmetres de traducció
settings-translations-subpage-speed-up-translation-header =
    .description = Baixeu llengües senceres per tal que les traduccions siguin més ràpides i es facin fora de línia.
    .label = Accelereu la traducció
settings-translations-subpage-automatic-translation-header =
    .label = Traducció automàtica
settings-translations-subpage-always-translate-header =
    .label = Tradueix sempre d'aquestes llengües
settings-translations-subpage-never-translate-header =
    .label = No tradueixis mai d'aquestes llengües
settings-translations-subpage-never-translate-sites-header =
    .label = No tradueixis mai aquests llocs
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Per afegir un lloc web, obriu el tauler de traducció <img data-l10n-name="translations-icon"/>, seleccioneu els paràmetres de traducció <img data-l10n-name="settings-icon"/> i, a continuació, trieu «No tradueixis mai aquest lloc».
settings-translations-subpage-language-select-option =
    .label = Afegeix una llengua
settings-translations-subpage-language-add-button =
    .aria-label = Afegeix una llengua
    .title = Afegeix una llengua
settings-translations-subpage-download-languages-header =
    .label = Baixa llengües
settings-translations-subpage-download-languages-select-option =
    .label = Trieu una llengua
settings-translations-subpage-download-languages-button =
    .aria-label = Baixa la llengua
    .title = Baixa la llengua
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = No heu baixat cap llengua
settings-translations-subpage-no-languages-added =
    .label = No heu afegit cap llengua
settings-translations-subpage-download-progress = S’està baixant…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = No s'ha pogut baixar { $language } ({ $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Torna-ho a provar
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Voleu suprimir { $language } ({ $size } MB)?
settings-translations-subpage-download-delete-button =
    .label = Suprimeix
settings-translations-subpage-download-cancel-button =
    .label = Cancel·la
settings-translations-subpage-no-sites-added =
    .label = No heu afegit cap lloc web
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Utilitza els paràmetres del sistema operatiu de «{ $localeName }» per formatar dates, hores, nombres i mesures.
settings-spellcheck-header =
    .label = Corrector ortogràfic
check-user-spelling =
    .label = Verifica l'ortografia a mesura que s'escriu
    .accesskey = o
spellcheck-download-dictionaries =
    .label = Baixeu diccionaris
spellcheck-promo =
    .heading = Com s'utilitza la correcció ortogràfica
    .message = Feu clic amb el botó dret en un camp de text per activar o desactivar la correcció ortogràfica o per canviar la llengua. No tots els camps admeten la correcció ortogràfica.

## Downloads - Files and applications

files-and-applications-title = Fitxers i aplicacions
download-save-files-header =
    .label = Desa els fitxers a
download-save-where-3 =
    .aria-label = Desa els fitxers a
download-always-ask-where2 =
    .label = Demana on desar els fitxers abans de baixar
    .accesskey = A
download-private-browsing-delete2 =
    .label = Suprimeix les baixades de les finestres privades en tancar
    .accesskey = D
applications-header = Aplicacions
applications-description = Trieu com voleu que el { -brand-short-name } tracti els fitxers que baixeu del web o les aplicacions que utilitzeu mentre navegueu.
applications-setting2 =
    .description = Trieu com el { -brand-short-name } gestiona els fitxers i el contingut que baixeu.
    .label = Fitxers i aplicacions
applications-filter =
    .placeholder = Cerca tipus de fitxers o aplicacions
applications-type-column =
    .label = Tipus de contingut
    .accesskey = T
applications-type-heading = Tipus de contingut
applications-action-column =
    .label = Acció
    .accesskey = A
applications-action-heading = Acció
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = fitxer { $extension }
applications-action-save =
    .label = Desa el fitxer
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Utilitza { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Utilitza { $app-name } (per defecte)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Utilitza l'aplicació per defecte del macOS
            [windows] Utilitza l'aplicació per defecte del Windows
           *[other] Utilitza l'aplicació per defecte del sistema
        }
applications-use-other =
    .label = Utilitza una altra aplicació…
applications-select-helper = Seleccioneu l'aplicació auxiliar
applications-manage-app =
    .label = Detalls de l'aplicació…
applications-always-ask =
    .label = Demana-m'ho sempre
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Obre en el { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Què ha de fer el { -brand-short-name } amb els altres fitxers?
applications-save-for-new-types =
    .label = Desa els fitxers
    .accesskey = s
applications-save-for-new-types2 =
    .label = Desa els fitxers automàticament
    .accesskey = D
applications-ask-before-handling =
    .label = Demana si els fitxers s'han d'obrir o de desar
    .accesskey = a
applications-ask-before-handling2 =
    .label = Demana obrir o desar fitxers
    .accesskey = A
drm-group =
    .label = Contingut DRM (Digital Rights Management, Gestió de drets digitals)
play-drm-content =
    .label = Reprodueix contingut controlat per DRM
    .accesskey = p
play-drm-content-learn-more = Més informació
# Variables:
# $version (string) - Firefox version
update-application-version = Versió { $version } <a data-l10n-name="learn-more">Novetats</a>
update-history-2 =
    .label = Mostra l'historial d'actualitzacions
    .accesskey = h
update-application-installation =
    .label = Instal·lació
update-application-radio-group =
    .aria-label = Instal·lació
update-application-auto-2 =
    .label = Instal·la les actualitzacions automàticament (recomanat)
    .accesskey = A
update-application-check-choose-2 =
    .label = Comprova si hi ha actualitzacions, però tria quan instal·lar
    .accesskey = C
update-application-background-enabled =
    .label = Quan el { -brand-short-name } no s'estigui executant
    .accesskey = Q
update-application-warning-cross-user-setting-2 =
    .message = Aquest paràmetre s'aplicarà a tots els comptes del Windows i perfils del { -brand-short-name } que utilitzin aquesta instal·lació del { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Mostra menys recordatoris d'actualització
    .accesskey = M
update-setting-write-failure-title2 = Error en desar els paràmetres d'actualització
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    El { -brand-short-name } ha trobat un error i no ha desat aquest canvi. Tingueu en compte que, per canviar aquest paràmetre d'actualització, necessiteu permís per escriure al fitxer següent. Podeu resoldre l’error, o un administrador del sistema, concedint al grup «Usuaris» el control total d'aquest fitxer.
    
    No s'ha pogut escriure al fitxer: { $path }
update-in-progress-title = Actualització en curs
update-in-progress-message = Voleu que el { -brand-short-name } continuï amb aquesta actualització?
update-in-progress-ok-button = &Descarta
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Continua

## About Firefox

about-firefox-header =
    .heading = Quant al { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Les actualitzacions milloren la velocitat, l'estabilitat i la seguretat del { -brand-short-name }.
    .label = Actualitzacions del { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Notificacions
update-application-updates-managed-by-os =
    .message = Les actualitzacions són gestionades pel vostre sistema operatiu

## Firefox support

support-application-heading =
    .description = Resoleu problemes o compartiu idees amb la comunitat.
    .label = Assistència del { -brand-short-name }
support-get-help =
    .label = Obteniu ajuda
support-share-ideas =
    .label = Comparteix idees i comentaris

## General Section - Performance

performance-settings-learn-more = Més informació
performance-allow-hw-accel =
    .label = Utilitza l'acceleració de maquinari quan sigui disponible
    .accesskey = r
performance-limit-content-process-option = Límit de processos de contingut
    .accesskey = L
performance-limit-content-process-enabled-desc = Més processos de contingut poden millorar el rendiment quan utilitzeu diverses pestanyes, però també utilitzaran més memòria.
performance-limit-content-process-blocked-desc = El nombre de processos de contingut només es pot modificar amb el { -brand-short-name } multiprocés. <a data-l10n-name="learn-more">Més informació sobre com comprovar si el multiprocés està activat.</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (per defecte)
performance-group =
    .label = Rendiment
performance-use-recommended-settings-checkbox-2 =
    .description = Aquests ajustos s'adapten al vostre maquinari i sistema operatiu.
    .label = Utilitza els paràmetres de rendiment recomanats
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = Utilitza el desplaçament automàtic
    .accesskey = a
keyboard-and-scrolling-group =
    .label = Navegació i desplaçament del teclat
motion-and-link-group =
    .label = Moviment i estil d'enllaços
browsing-use-smooth-scrolling =
    .label = Utilitza el desplaçament suau
    .accesskey = s
browsing-gtk-use-non-overlay-scrollbars =
    .label = Mostra sempre les barres de desplaçament
    .accesskey = o
browsing-always-underline-links =
    .label = Subratlla sempre els enllaços
    .accesskey = S
browsing-use-onscreen-keyboard =
    .label = Mostra un teclat tàctil quan calgui
    .accesskey = M
browsing-use-cursor-navigation =
    .label = Utilitza sempre les tecles de cursor per navegar en les pàgines
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = Utilitza la tecla de tabulació per moure el focus entre els controls de formulari i els enllaços
    .accesskey = U
browsing-search-on-start-typing =
    .label = Cerca el text en començar a teclejar
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = Controleu com us moveu i interactueu amb el { -brand-short-name }.
    .label = Dreceres de teclat
settings-keyboard-shortcuts-customkeys-link =
    .label = Personalitza les dreceres de teclat
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Personalitzeu els paràmetres de la barra d'adreces a Cerca
settings-media-group =
    .label = Multimèdia
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Usa la imatge sobre imatge
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = En canviar de pestanya, segueix reproduint els vídeos en mode d'Imatge sobre imatge
    .accesskey = s
browsing-media-control =
    .label = Controla el contingut multimèdia amb teclat, auriculars o interfície virtual
    .accesskey = v
recommendations-group =
    .label = Recomanacions
browsing-cfr-recommendations =
    .label = Recomana extensions durant la navegació
    .accesskey = R
browsing-cfr-features =
    .label = Recomana funcions durant la navegació
    .accesskey = f
browsing-group =
    .label = Navegació
preferences-accessibility-header =
    .heading = Accessibilitat
preferences-default-zoom-select =
    .aria-label = Zoom per defecte
preferences-fonts-family =
    .label = Família de la lletra
    .accesskey = D
preferences-fonts-size =
    .label = Mida de la lletra
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = Paràmetres avançats
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .description = Configureu com el { -brand-short-name } es connecta a Internet.
    .label = Paràmetres del servidor intermediari
network-proxy-connection-settings2 =
    .description = Canviar aquesta configuració pot causar problemes de connexió
    .label = Configura el servidor intermediari
    .accesskey = C

## Home Section

home-new-windows-tabs-header = Finestres i pestanyes noves
home-new-windows-tabs-description2 = Trieu què voleu veure en obrir la pàgina d'inici, finestres noves i pestanyes noves.
home-section =
    .heading = Pàgina d'inici i inicialització

## Home Section - Default Browser

home-default-browser-title =
    .label = Navegador per defecte
is-default-browser-2 =
    .message = El { -brand-short-name } és el navegador per defecte. Molt bona elecció.
is-not-default-browser-2 =
    .message = Ep! El { -brand-short-name } no és el navegador per defecte.
set-as-my-default-browser-2 =
    .label = Fes que sigui el navegador per defecte
    .accesskey = d

## Custom Homepage subpage

home-homepage-mode-label = Pàgina d'inici i finestres noves
home-newtabs-mode-label = Pestanyes noves
home-restore-defaults =
    .label = Restaura els valors per defecte
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (Per defecte)
home-mode-choice-custom =
    .label = URL personalitzats…
home-mode-choice-blank =
    .label = Pàgina en blanc
home-homepage-custom-url =
    .placeholder = Enganxeu un URL…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Gestiona l'extensió
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Utilitza la pàgina actual
           *[other] Utilitza les pàgines actuals
        }
    .accesskey = c
choose-bookmark =
    .label = Utilitza una adreça d'interès…
    .accesskey = z
home-homepage-title =
    .label = Pàgina d’inici
home-homepage-new-windows =
    .label = Finestres noves
home-homepage-new-tabs =
    .label = Pestanyes noves
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Tria un lloc específic
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Adreces de llocs web
home-custom-homepage-list =
    .aria-label = Adreces web
home-custom-homepage-address =
    .placeholder = Escriviu una adreça
home-custom-homepage-address-button =
    .label = Afegeix l'adreça
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Encara no heu afegit cap lloc web.
home-custom-homepage-delete-address-button =
    .aria-label = Suprimeix l’adreça
    .title = Suprimeix l’adreça
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Reemplaça amb
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Pàgines obertes actualment
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Adreces d'interès…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Extensió ({ $extension })
home-custom-homepage-header = Pàgina d'inici personalitzada
home-custom-homepage-subpage =
    .heading = Pàgina d'inici personalitzada

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Contingut de l'{ -firefox-home-brand-name }
home-prefs-content-description2 = Trieu el contingut que voleu en la pantalla d'{ -firefox-home-brand-name }.
home-prefs-search-header =
    .label = Cerca web
home-prefs-shortcuts-header =
    .label = Dreceres
home-prefs-shortcuts-description = Llocs que deseu o visiteu
home-prefs-shortcuts-by-option-sponsored =
    .label = Dreceres patrocinades
home-prefs-recommended-by-header-generic =
    .label = Articles recomanats
home-prefs-recommended-by-description-generic = Contingut excepcional seleccionat per la família del { -brand-product-name }
home-prefs-stories-header =
    .label = Articles
home-prefs-stories-description = Articles personalitzats basats en la vostra activitat

##

home-prefs-recommended-by-learn-more = Com funciona
home-prefs-recommended-by-option-sponsored-stories =
    .label = Articles patrocinats
home-prefs-highlights-option-visited-pages =
    .label = Pàgines visitades
home-prefs-highlights-options-bookmarks =
    .label = Adreces d'interès
home-prefs-highlights-option-most-recent-download =
    .label = Baixada més recent
home-prefs-recent-activity-header =
    .label = Activitat recent
home-prefs-recent-activity-description = Una selecció de continguts i llocs recents
home-prefs-weather-header =
    .label = Informació meteorològica
home-prefs-weather-description = La previsió d'avui d'un cop d'ull
home-prefs-weather-learn-more-link = Més informació
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Doneu suport al { -brand-product-name }
home-prefs-mission-message = Els nostres patrocinadors donen suport a la nostra missió de crear un web millor
home-prefs-mission-message-learn-more-link = Descobriu com
home-prefs-manage-topics-link = Gestiona els temes
home-prefs-choose-wallpaper-link = Trieu un fons de pantalla
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } fila
           *[other] { $num } files
        }

## Search Section

search-show-suggestions-option =
    .label = Mostra suggeriments de cerca
    .accesskey = M
search-show-suggestions-url-bar-option =
    .label = Mostra suggeriments de cerca als resultats de la barra d'adreces
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = En els resultats de la barra d'adreces, mostra els suggeriments de cerca abans de l'historial de navegació
search-show-suggestions-private-windows-2 =
    .label = Suggeriments de cerca en les finestres privades
search-suggestions-cant-show-2 =
    .message = No es mostraran suggeriments de cerca als resultats de la barra d'ubicació perquè heu configurat el { -brand-short-name } per tal que no recordi mai l'historial.
addressbar-header-1 =
    .description = Trieu quins suggeriments es mostren a la barra d’adreces
    .label = Barra d’adreces
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Suggeriments del { -brand-short-name } i dels nostres socis a la barra d’adreces.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Mostra els termes de cerca a la barra d'adreces de les pàgines de resultats
search-separate-default-engine-2 =
    .label = Utilitza un altre motor de cerca per defecte en les finestres privades
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = Motor de cerca per defecte en les finestres privades
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Navegació per la barra d'adreces
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Omet el menú de resultats quan s'utilitza la tecla de tabulació per moure el focus
search-suggestions-header-2 =
    .label = Suggeriments de motors de cerca
search-one-click-header2 = Dreceres de cerca
search-one-click-desc = Trieu els motors de cerca alternatius que es mostraran sota la barra d'adreces i de cerca en començar a escriure una paraula.
search-one-click-header-3 =
    .description = Trieu quins motors de cerca i dreceres apareixen a la barra d’adreces.
    .label = Motors de cerca addicionals
search-engine-list =
    .aria-label = Motors de cerca i dreceres
update-search-engine-success =
    .message = El motor de cerca s'ha actualitzat correctament
search-edit-engine-2 =
    .title = Edita el motor de cerca
search-delete-engine =
    .title = Suprimeix el motor de cerca
search-enable-engine =
    .title = Activa el motor de cerca
search-outlink-to-extensions-page =
    .title = Gestioneu-ho dins d'extensions i temes
search-choose-engine-column =
    .label = Motor de cerca
search-choose-keyword-column =
    .label = Paraula clau
search-restore-default =
    .label = Restaura els motors de cerca per defecte
    .accesskey = R
search-remove-engine =
    .label = Elimina
    .accesskey = E
search-add-engine =
    .label = Afegeix
    .accesskey = A
search-add-engine-2 =
    .label = Afegeix un motor de cerca
    .accesskey = A
search-edit-engine =
    .label = Edita
    .accesskey = E
search-find-more-link = Afegiu més motors de cerca
search-filtering-for-add-engine = Afegeix el motor
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Duplica la paraula clau
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Heu triat una paraula clau que ja utilitza «{ $name }». Seleccioneu-ne una altra.
search-keyword-warning-bookmark = Heu triat una paraula clau que ja utilitza una adreça d'interès. Seleccioneu-ne una altra.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Ja hi ha un motor de cerca amb el nom «{ $name }». Trieu-ne un altre.
remove-engine-confirmation = Segur que voleu eliminar aquest motor de cerca?
remove-engine-remove = Elimina
remove-addon-engine-alert = Per eliminar aquest motor de cerca, elimineu el complement associat.
search-engine-group =
    .label = Motor de cerca per defecte
search-default-engine =
    .aria-label = Motor de cerca per defecte
# Header for the search section ("search" is a noun).
search-section =
    .heading = Cerca

## Containers Section

containers-section-header2 =
    .heading = Configuració del contenidor
containers-card-header2 =
    .description = Separeu les galetes per contenidor per poder utilitzar diferents comptes en un mateix lloc i limitar el seguiment entre llocs.
    .label = Contenidors
containers-add-button2 =
    .label = Afegeix un contenidor nou
    .accesskey = A
containers-list =
    .aria-label = Contenidors
containers-new-tab-check3 =
    .label = Selecciona un contenidor per a cada pestanya nova
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = No utilitzis contenidors per a enllaços oberts des d'aplicacions externes
    .accesskey = N
containers-new-tab-check2 =
    .description = Això obrirà el menú contenidors cada vegada que premeu el botó Obre una pestanya nova.
    .label = Selecciona un contenidor per a cada pestanya nova
    .accesskey = S
containers-settings-button2 =
    .title = Paràmetres
containers-remove-button3 =
    .title = Suprimeix
containers-sites-card-header =
    .description = Trieu un contenidor per a un lloc web i el { -brand-short-name } l'utilitzarà cada vegada que s'obri aquell lloc.
    .label = Contenidors específics del lloc
containers-sites-add-button =
    .label = Afegeix un lloc web
    .accesskey = w
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Contenidor per a { $site }
containers-site-remove-button =
    .title = Suprimeix
containers-remove-button2 =
    .title = Elimina

## Account and sync

sync-group-label =
    .label = Sincronització
account-group-label2 =
    .label = Compte
account-disabled-group =
    .description = Els paràmetres del compte no estan disponibles.
    .label = Compte
account-placeholder2 =
    .description = Inicieu la sessió i mantingueu les vostres dades privades, xifrades i accessibles instantàniament arreu on useu el { -brand-short-name }
    .label = No heu iniciat la sessió
account-sync-section =
    .heading = Compte i sincronització
pane-account-sync-title2 = Compte i sincronització
    .title = Compte i sincronització

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = El vostre web a tot arreu
sync-signedout-description2 = Sincronitzeu les vostres adreces d'interès, historial, pestanyes, contrasenyes, complements i paràmetres en tots els vostres dispositius.
sync-signedout-account-signin3 =
    .label = Inicia la sessió per sincronitzar…
    .accesskey = I
sync-signedout-account-signin-4 =
    .label = Inicieu la sessió al compte per començar la sincronització
    .accesskey = I
sync-signedout-account-short =
    .label = Inicia la sessió
    .accesskey = I
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Baixeu el Firefox per a l'<img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> o per a l'<img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> per sincronitzar amb el vostre dispositiu mòbil.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Canvia la imatge de perfil
    .tooltiptext = Canvia la imatge de perfil
sync-profile-picture-account-problem =
    .alt = Imatge de perfil del compte
fxa-login-rejected-warning =
    .alt = Avís
sync-sign-out =
    .label = Tanca la sessió…
    .accesskey = T
sync-sign-out2 =
    .label = Tanca la sessió
    .accesskey = T
sync-manage-account = Gestiona el compte
    .accesskey = a
sync-manage-account2 =
    .label = Gestiona el compte
    .accesskey = a

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } no està verificat.
sync-signedin-unverified2 =
    .description = Comproveu la safata d'entrada per confirmar el vostre compte i fer-lo oficial.
    .label = { $email } encara no està confirmat
sync-signedin-login-failure = Inicieu la sessió per tornar-vos a connectar { $email }
sync-signedin-login-failure2 =
    .description = Torneu a iniciar la sessió per connectar-vos i començar a sincronitzar les vostres dades.
    .label = La sessió de { $email } és tancada
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Verifica el compte
    .accesskey = V
sync-remove-account =
    .label = Elimina el compte
    .accesskey = E
sync-sign-in =
    .label = Inicia la sessió
    .accesskey = I

## Sync section - enabling or disabling sync.

prefs-syncing-on = Sincronització: ACTIVADA
prefs-syncing-on-2 =
    .label = La sincronització està ACTIVADA
prefs-syncing-off = Sincronització: DESACTIVADA
prefs-syncing-off-2 =
    .description = Activeu la sincronització per tenir les adreces d'interès, contrasenyes, historial i molt més en tots els dispositius.
    .label = La sincronització està DESACTIVADA
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Activeu la sincronització per tenir les adreces d'interès, les contrasenyes, l'historial i molt més en aquest dispositiu.
    .label = La sincronització està desactivada
prefs-sync-turn-on-syncing =
    .label = Activa la sincronització…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Activa la sincronització
    .accesskey = s
prefs-sync-offer-setup-label2 = Sincronitzeu les vostres adreces d'interès, historial, pestanyes, contrasenyes, complements i paràmetres en tots els vostres dispositius.
prefs-sync-now-button =
    .label = Sincronitza ara
    .accesskey = S
prefs-sync-now-button-2 =
    .label = Sincronitza ara
    .accesskey = S
prefs-syncing-button =
    .label = S'està sincronitzant…
prefs-syncing-button-2 =
    .label = S'està sincronitzant…
    .title = Sincronitza ara
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Les opcions de sincronització ara només s’apliquen a aquest dispositiu.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Actualment, sincronitzeu aquests elements en tots els vostres dispositius connectats:
sync-syncing-across-devices-heading-2 = Dades sincronitzades entre dispositius
sync-syncing-across-devices-heading-3 = Dades que se sincronitzen en aquest dispositiu
sync-syncing-across-devices-empty-state2 =
    .description = Encara no esteu sincronitzant res… Comenceu a sincronitzar per accedir a totes les vostres dades en tots els vostres dispositius.
    .label = Gestiona les dades sincronitzades
sync-syncing-across-devices-empty-state3 =
    .description = Encara no esteu sincronitzant res… Trieu què voleu sincronitzar en aquest dispositiu.
    .label = Gestiona les dades sincronitzades
sync-currently-syncing-bookmarks = Adreces d'interès
sync-currently-syncing-history = Historial
sync-currently-syncing-tabs = Pestanyes obertes
sync-currently-syncing-passwords = Contrasenyes
sync-currently-syncing-addresses = Adreces
sync-currently-syncing-payment-methods = Formes de pagament
sync-currently-syncing-addons = Complements
sync-currently-syncing-settings = Paràmetres
sync-manage-options =
    .label = Gestiona la sincronització…
    .accesskey = G
sync-manage-options-2 =
    .label = Gestiona les dades sincronitzades
    .accesskey = G
settings-sync-disconnect-button =
    .label = Desconnecta

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Adreces d'interès
    .accesskey = d
sync-engine-history =
    .label = Historial
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Pestanyes obertes
    .tooltiptext = Pestanyes que teniu obertes en altres dispositius
    .accesskey = P
sync-engine-tabs =
    .label = Pestanyes obertes
    .tooltiptext = Una llista d'allò que està obert en tots els dispositius sincronitzats
    .accesskey = T
sync-engine-passwords =
    .label = Contrasenyes
    .tooltiptext = Contrasenyes que heu desat
    .accesskey = C
sync-engine-addresses2 =
    .label = Adreces
    .tooltiptext = Adreces que heu en el { -brand-short-name }
    .accesskey = A
sync-engine-payment-methods3 =
    .label = Formes de pagament
    .tooltiptext = Formes de pagament que heu desat
    .accesskey = F
sync-engine-addons2 =
    .label = Complements
    .tooltiptext = Extensions i temes que heu afegit al { -brand-short-name } per a l’escriptori
    .accesskey = C
sync-engine-settings2 =
    .label = Paràmetres
    .tooltiptext = Paràmetres rellevants del { -brand-short-name }
    .accesskey = P
sync-engine-addresses =
    .label = Adreces
    .tooltiptext = Adreces postals que heu desat (només a l'ordinador)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = Formes de pagament
    .tooltiptext = Noms, números de targetes i dates d'expiració
    .accesskey = p
sync-engine-addons =
    .label = Complements
    .tooltiptext = Extensions i temes per al Firefox d'escriptori
    .accesskey = C
sync-engine-settings =
    .label = Paràmetres
    .tooltiptext = Paràmetres generals, de privadesa i de seguretat que heu canviat
    .accesskey = P
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Desa
    .buttonlabelextra2 = Desconnecta…
    .buttonaccesskeyaccept = s
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = Gestioneu què voleu sincronitzar en tots els vostres dispositius connectats
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Desa
    .buttonlabelextra2 = Desconnecta…
    .buttonaccesskeyaccept = D
    .buttonaccesskeyextra2 = e
    .style = min-width: 36em;
    .title = Gestioneu què se sincronitza en aquest dispositiu

## The device name controls.

sync-device-name-header = Nom del dispositiu
sync-device-name-header-2 =
    .label = Nom del dispositiu
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Nom del dispositiu
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Canvia el nom del dispositiu
    .accesskey = v
sync-device-name-change =
    .label = Canvia el nom del dispositiu…
    .accesskey = v
sync-device-name-cancel =
    .label = Cancel·la
    .accesskey = n
sync-device-name-save =
    .label = Desa
    .accesskey = D
sync-connect-another-device = Connecta un altre dispositiu
sync-connect-another-device-2 =
    .label = Connecta un altre dispositiu

## Privacy Section

privacy-header = Privadesa del navegador

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Contrasenyes
    .searchkeywords = inicis de sessió
forms-passwords-header =
    .aria-label = Contrasenyes
    .label = Contrasenyes
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Demana desar les contrasenyes
    .accesskey = D
forms-manage-password-exceptions =
    .label = Gestiona les excepcions de contrasenya
    .accesskey = G
forms-exceptions =
    .label = Excepcions…
    .accesskey = x
forms-suggest-passwords =
    .label = Suggereix contrasenyes segures
    .accesskey = S
forms-breach-alerts =
    .label = Mostra alertes sobre contrasenyes per als llocs web relacionats amb filtracions de dades
    .accesskey = b
forms-breach-alerts-learn-more-link = Més informació
preferences-relay-integration-checkbox2 =
    .label = Suggereix màscares d'adreça electrònica del { -relay-brand-name } per a protegir la vostra adreça electrònica
    .accesskey = r
relay-integration-learn-more-link = Més informació
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Emplena automàticament els noms d'usuari i les contrasenyes
    .accesskey = E
forms-fill-usernames-and-passwords-2 =
    .label = Desa i emplena automàticament els noms d'usuari i contrasenyes
    .accesskey = e
forms-saved-passwords =
    .label = Contrasenyes desades
    .accesskey = d
forms-saved-passwords-2 =
    .label = Gestiona les contrasenyes desades
    .accesskey = d
forms-saved-passwords-searchkeywords = S'han emmagatzemat les dades d'inici de sessió dels llocs següents en el vostre ordinador
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Proteccions addicionals
forms-primary-pw-use =
    .label = Utilitza una contrasenya principal
    .accesskey = U
forms-primary-pw-use-2 =
    .description = Afegeix una capa addicional de seguretat per protegir les contrasenyes desades.
    .label = Utilitza una contrasenya principal
    .accesskey = U
forms-primary-pw-set =
    .label = Defineix la contrasenya principal
forms-primary-pw-on-2 = La contrasenya principal està <strong>ACTIVADA</strong>
forms-primary-pw-on =
    .label = La contrasenya principal està ACTIVADA
forms-primary-pw-change-2 =
    .label = Canvia la contrasenya principal
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Desactiva
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Demana iniciar la sessió en el dispositiu per emplenar i gestionar les contrasenyes
forms-os-reauth-2 =
    .label = Demana iniciar la sessió en el dispositiu per gestionar les contrasenyes
forms-primary-pw-learn-more-link = Més informació
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Canvia la contrasenya mestra…
    .accesskey = m
forms-primary-pw-change =
    .label = Canvia la contrasenya principal…
    .accesskey = p
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = Anteriorment anomenada «Contrasenya mestra»
forms-primary-pw-fips-title = Us trobeu en mode FIPS. El FIPS requereix una contrasenya principal que no sigui buida.
forms-master-pw-fips-desc = El canvi de contrasenya ha fallat
forms-windows-sso =
    .label = Permet l'inici de sessió únic del Windows per a comptes laborals i acadèmics de Microsoft
forms-windows-sso-learn-more-link = Més informació
forms-windows-sso-desc = Gestioneu els comptes en els paràmetres del dispositiu
windows-passkey-settings-label = Gestiona les claus d'accés en els paràmetres del sistema
privacy-panel-settings-header =
    .description = Obteniu ajuda per protegir la vostra informació en línia a { -brand-short-name }.
    .label = Configuració del panell de privacitat
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Mostra els missatges de filtratge
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Per crear una contrasenya principal, introduïu les vostres credencials d'inici de sessió al Windows. Això ajuda a protegir la seguretat dels vostres comptes.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = crear una contrasenya principal
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] canviar els paràmetres de les formes de pagament
       *[other] El { -brand-short-name } està provant de canviar els paràmetres de les formes de pagament. Inicieu la sessió en el dispositiu per a permetre-ho.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Formes de pagament
autofill-payment-methods-checkbox-message-2 =
    .label = Desa i emplena automàticament les formes de pagament
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = Gestiona les formes de pagament
autofill-payment-methods-manage-payments-button =
    .label = Gestiona les formes de pagament
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Requereix l'inici de sessió del dispositiu per emplenar-ho automàticament
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Demana iniciar la sessió en el dispositiu per emplenar automàticament i gestionar les formes de pagament
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Desa els codis de seguretat
    .accesskey = c
autofill-payment-methods-add-button = Afegeix una forma de pagament nova
payments-list-header =
    .label = Formes de pagament
payments-delete-payment-prompt-title = Voleu suprimir aquesta forma de pagament?
payments-delete-payment-prompt-confirm-button = Suprimeix
payments-delete-payment-prompt-cancel-button = Cancel·la
payments-delete-payment-button-label =
    .aria-label = Suprimeix
payments-edit-payment-button-label =
    .aria-label = Edita
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = No heu afegit cap mètode de pagament
autofill-addresses-checkbox-message =
    .label = Desa i emplena automàticament les adreces
    .accesskey = s
autofill-addresses-manage-addresses-button =
    .label = Gestiona les adreces i altra informació
    .accesskey = m
addresses-list-header =
    .label = Adreces
addreses-delete-address-button-label =
    .aria-label = Suprimeix
addreses-edit-address-button-label =
    .aria-label = Edita
addresses-delete-address-prompt-title = Voleu suprimir aquesta adreça?
addresses-delete-address-prompt-confirm-button = Suprimeix
addresses-delete-address-prompt-cancel-button = Cancel·la
autofill-addresses-add-button = Afegeix una adreça nova
autofill-addresses-manage-addresses-title =
    .heading = Gestiona les adreces i altra informació
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = No heu afegit cap adreça
personal-info-group =
    .label = Informació personal
autofill-personal-info-checkbox-message =
    .label = Desa i emplena automàticament la informació personal
autofill-personal-info-manage-button =
    .label = Gestiona la informació personal
passports-list-header =
    .label = Passaports
passports-delete-passport-button-label =
    .aria-label = Suprimeix
passports-edit-passport-button-label =
    .aria-label = Edita
passports-delete-passport-prompt-title = Voleu suprimir aquest passaport?
passports-delete-passport-prompt-confirm-button = Suprimeix
passports-delete-passport-prompt-cancel-button = Cancel·la
autofill-passports-add-button = Afegeix un passaport nou
autofill-personal-info-manage-title =
    .heading = Gestiona la informació personal
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = No s'han afegit passaports
pane-passwords-autofill-title2 = Contrasenyes i emplenament automàtic
    .title = Contrasenyes i emplenament automàtic
preferences-passwords-autofill-header =
    .heading = Contrasenyes i emplenament automàtic
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adreces i altra informació
payments-group =
    .label = Formes de pagament

## Privacy Section - History

history-remember-option-never2 =
    .description = Cada finestra actua com una finestra privada. Amb aquesta opció activada, haureu de permetre les extensions.
    .label = No recordis mai l'historial
history-remember-option-custom2 =
    .label = Personalitza l'historial
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = El { -brand-short-name } recordarà el vostre historial de navegació, de baixades, de formularis i de cerques.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = El { -brand-short-name } utilitzarà els mateixos paràmetres de la navegació privada, i no conservarà cap historial mentre navegueu.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = El { -brand-short-name } utilitzarà una configuració personalitzada per a l'historial de navegació, baixades, formularis i cerques.
history-private-browsing-permanent =
    .label = Utilitza sempre el mode de navegació privada
    .accesskey = p
history-remember-browser-option =
    .label = Recorda l'historial de navegació i de baixades
    .accesskey = b
history-remember-search-option =
    .label = Recorda l'historial de cerques i de formularis
    .accesskey = f
history-clear-on-close-option =
    .label = Esborra l'historial en tancar el { -brand-short-name }
    .accesskey = b
history-clear-on-close-settings =
    .label = Paràmetres…
    .accesskey = t
history-shutdown-exceptions =
    .label = Gestiona les excepcions
    .accesskey = x
history-clear-button =
    .label = Esborra l'historial…
    .accesskey = s
history-header2 =
    .heading = Historial
history-section-header =
    .description = Trieu què voleu que el { -brand-short-name } recordi en tancar el navegador.
    .label = Historial
history-custom-section-header =
    .description = Personalitzeu què voleu que el { -brand-short-name } recordi en tancar el navegador.
    .label = Paràmetres avançats
history-custom-button =
    .label = Trieu què voleu que el { -brand-short-name } recordi en tancar el navegador.
history-group =
    .label = Historial
history-mode-radio-group =
    .aria-label = Historial
history-remember-option-all2 =
    .label = Recorda l'historial

## Privacy Section - Site Data

sitedata-total-size-calculating = S'està calculant la mida de les dades dels llocs i de la memòria cau…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Els llocs web actualment utilitzen <strong>{ $value } { $unit }</strong> d'espai en disc.
sitedata-learn-more = Més informació
sitedata-delete-on-close2 =
    .label = Esborra les galetes i les dades dels llocs en tancar el { -brand-short-name }
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = D'acord amb els paràmetres de l'historial, el { -brand-short-name } suprimirà les galetes i les dades dels llocs en tancar el navegador.
sitedata-delete-on-close-private-browsing4 =
    .heading = No es desarà l’historial.
    .message = El { -brand-short-name } esborrarà les galetes i les dades dels llocs en tancar el navegador.
sitedata-option-block-cross-site-trackers =
    .label = Elements de seguiment entre llocs
sitedata-option-block-cross-site-tracking-cookies =
    .label = Galetes de seguiment entre llocs
sitedata-option-block-cross-site-cookies2 =
    .label = Aïlla les galetes entre llocs
sitedata-option-block-unvisited =
    .label = Galetes de llocs web no visitats
sitedata-option-block-all-cross-site-cookies =
    .label = Totes les galetes entre llocs (pot fer que alguns llocs web no funcionin)
sitedata-option-block-all =
    .label = Totes les galetes (farà que alguns llocs web no funcionin)
sitedata-clear2 =
    .label = Esborra les dades de navegació
    .accesskey = l
sitedata-settings2 =
    .label = Gestiona les dades de navegació
    .accesskey = G
sitedata-cookies-exceptions =
    .label = Gestiona les excepcions…
    .accesskey = x
sitedata-cookies-exceptions2 =
    .description = Podeu especificar quins llocs web poden o no poden utilitzar galetes i dades dels llocs.
    .label = Gestiona les excepcions
    .accesskey = x
sitedata-heading =
    .description = Gestioneu les galetes, l'historial, la memòria cau, les dades dels llocs web i més.
    .label = Dades de navegació
sitedata-settings3 =
    .label = Esborra les dades de llocs específics
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = Trieu com es gestionen les galetes i les dades del lloc en llocs web específics.
    .label = Gestiona les excepcions
    .accesskey = x
cookies-site-data-group =
    .label = Galetes i dades dels llocs

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Blocador de bàners de galetes
cookie-banner-blocker-description = Quan un lloc demana si es poden utilitzar galetes en mode de navegació privada, el { -brand-short-name } ho rebutjarà automàticament. Només s'aplica als llocs compatibles.
cookie-banner-learn-more = Més informació
cookie-banner-blocker-checkbox-label =
    .label = Rebutja automàticament els bàners de galetes

## Search Section

addressbar-locbar-history-option =
    .label = Historial de navegació
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = Adreces d'interès
    .accesskey = d
addressbar-locbar-clipboard-option =
    .label = Porta-retalls
    .accesskey = P
addressbar-locbar-openpage-option =
    .label = Pestanyes obertes
    .accesskey = P
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Dreceres
    .accesskey = D
addressbar-locbar-topsites-option =
    .label = Llocs principals
    .accesskey = L
addressbar-locbar-engines-option-1 =
    .label = Suggereix motors de cerca per utilitzar
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = Accions ràpides
    .accesskey = r
addressbar-locbar-showrecentsearches-option-2 =
    .label = Cerques recents
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Suggeriments de cerca que són tendència
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Obtén suggeriments del web relacionats amb la cerca.
    .label = Suggeriments del { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Doneu suport al { -brand-short-name } activant els suggeriments patrocinats ocasionals.
    .label = Suggeriments dels patrocinadors
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Mostra suggeriments de Mozilla mentre escriviu
addressbar-dismissed-suggestions-label-2 =
    .description = Restaura els suggeriments descartats dels patrocinadors i del { -brand-short-name }.
    .label = Suggeriments descartats
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Restaura els suggeriments

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Protecció contra el seguiment millorada
content-blocking-section-top-level-description = Hi ha elements que us fan el seguiment mentre navegueu per recopilar informació sobre els vostres hàbits de navegació i interessos. El { -brand-short-name } bloca molts d'aquests elements de seguiment i altres scripts maliciosos.
content-blocking-learn-more = Més informació
content-blocking-fpi-incompatibility-warning = Esteu utilitzant FPI (First Party Isolation), que substitueix alguns paràmetres de galetes del { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Esteu utilitzant RFP (Resist Fingerprinting), que substitueix alguns dels paràmetres de protecció d'empremtes digitals del { -brand-short-name }. Això pot fer que alguns llocs no funcionin correctament.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Estàndard
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Estricta
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Personalitzada
    .accesskey = P

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Equilibri entre protecció i rendiment. Les pàgines es carregaran amb normalitat.
content-blocking-etp-strict-desc = Més protecció, però pot fer que alguns llocs o algun contingut no funcionin correctament.
content-blocking-etp-custom-desc = Trieu quins elements de seguiment i scripts cal blocar.
content-blocking-etp-blocking-desc = El { -brand-short-name } bloca el següent:
content-blocking-private-windows = Contingut que fa seguiment en finestres privades
content-blocking-cross-site-cookies-in-all-windows2 = Galetes entre llocs en totes les finestres
content-blocking-cross-site-tracking-cookies = Galetes de seguiment entre llocs
content-blocking-all-cross-site-cookies-private-windows = Galetes entre llocs en finestres privades
content-blocking-isolate-cross-site-cookies = Aïlla les galetes entre llocs
content-blocking-social-media-trackers = Elements de seguiment de xarxes socials
content-blocking-all-cookies = Totes les galetes
content-blocking-unvisited-cookies = Galetes de llocs no visitats
content-blocking-all-windows-tracking-content = Contingut que fa seguiment en totes les finestres
content-blocking-all-cross-site-cookies = Totes les galetes entre llocs
content-blocking-cryptominers = Miners de criptomonedes
content-blocking-fingerprinters = Generadors d'empremtes digitals
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Generadors d'empremtes digitals coneguts i sospitosos
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = La protecció total de galetes aïlla les galetes del lloc on us trobeu, de manera que els elements de seguiment no les poden utilitzar per a seguir-vos d'un lloc a l'altre.
content-blocking-etp-standard-tcp-rollout-learn-more = Més informació
content-blocking-etp-standard-tcp-title = Inclou la Protecció total de galetes, la nostra funció de privadesa més potent fins ara
content-blocking-warning-title-2 = La protecció contra el seguiment estricta pot fer que alguns llocs no funcionin correctament
content-blocking-warning-title-custom = La protecció contra el seguiment personalitzada pot fer que alguns llocs no funcionin correctament
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = El { -brand-short-name } recomana utilitzar els paràmetres de «Corregeix els problemes dels llocs» per reduir el nombre de funcions i continguts que no funcionen correctament. Si un lloc sembla que no funciona correctament, proveu de desactivar la protecció contra el seguiment per tal que es carregui tot el contingut del lloc.
content-blocking-warning-learn-how = Vegeu com fer-ho
content-blocking-baseline-exceptions-3 =
    .description = Ajuda a carregar els llocs i les funcions desblocant només els elements essencials que poden fer seguiment. Inclou els problemes més comuns.
    .label = Corregeix els problemes més greus dels llocs (recomanat)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Restaura elements com ara els vídeos d'un article o les seccions de comentaris desblocant elements que poden fer seguiment. Això pot reduir els problemes del lloc web, però ofereix menys protecció. Cal utilitzar-ho conjuntament amb la correcció dels  problemes més greus.
    .label = Corregeix els problemes menors dels llocs
content-blocking-baseline-uncheck-warning-dialog-title = Segur que voleu desactivar les correccions?
content-blocking-baseline-uncheck-warning-dialog-body = Aquest paràmetre ajuda a solucionar els problemes més comuns dels llocs web. Si el desactiveu, és possible que alguns llocs web no funcionin i el { -brand-short-name } no us podrà ajudar a resoldre-ho.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Desactiva les correccions
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Mantén activades les correccions
content-blocking-reload-description = Cal tornar a carregar les pestanyes per aplicar aquests canvis.
content-blocking-reload-tabs-button =
    .label = Torna a carregar totes les pestanyes
    .accesskey = r
content-blocking-tracking-content-label =
    .label = Contingut que fa seguiment
    .accesskey = o
content-blocking-tracking-protection-option-all-windows =
    .label = En totes les finestres
    .accesskey = f
content-blocking-option-private =
    .label = Només en finestres privades
    .accesskey = N
content-blocking-cookies-label =
    .label = Galetes
    .accesskey = G
content-blocking-expand-section =
    .tooltiptext = Més informació
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Miners de criptomonedes
    .accesskey = M
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Generadors d'empremtes digitals coneguts
    .accesskey = G
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Generadors d'empremtes digitals sospitosos
    .accesskey = s

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Gestiona les excepcions…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Posa en pausa les notificacions fins que es reiniciï el { -brand-short-name }
    .accesskey = n
permissions-autoplay2 =
    .label = Reproducció automàtica
permissions-block-popups2 =
    .label = Bloca les finestres emergents i les redireccions de tercers
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Afegiu els llocs web que poden obrir finestres emergents i utilitzar redireccions de tercers.
    .label = Gestiona les excepcions
    .searchkeywords = popup,pop-up
    .accesskey = e
permissions-addon-install-warning3 =
    .label = Mostra un avís quan els llocs web intentin instal·lar extensions
    .accesskey = w
permissions-addon-exceptions2 =
    .label = Tria quins llocs web poden instal·lar extensions
    .accesskey = e
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Permet que els llocs demanin obrir enllaços d'aplicacions.
    .accesskey = A
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Gestiona els llocs blocats
    .accesskey = G
permissions-location2 =
    .label = Ubicació
permissions-localhost2 =
    .label = Aplicacions i serveis del dispositiu
permissions-local-network2 =
    .label = Dispositius de la xarxa local
permissions-xr2 =
    .label = Realitat virtual
permissions-camera2 =
    .label = Càmera
permissions-microphone2 =
    .label = Micròfon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Altaveu
permissions-notification2 =
    .label = Notificacions
permissions-header3 =
    .description = Gestiona a què poden accedir, controlar o activar els llocs web.
    .label = Permisos
permissions-data-section =
    .heading = Permisos i dades
pane-permissions-data-title2 = Permisos i dades
    .title = Permisos i dades
notifications-section-header =
    .heading = Notificacions
notifications-entry-card-header =
    .description = Trieu quins llocs web poden enviar notificacions i com es mostren aquestes alertes.
    .label = Notificacions
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } lloc web
           *[other] { $count } llocs web
        }
    .label = Gestiona la configuració de les notificacions
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Gestiona la configuració de notificacions dels llocs web
notifications-website-card-header =
    .description = Trieu com els llocs web poden enviar notificacions.
    .label = Notificacions dels llocs web
notifications-filter =
    .placeholder = Cerca llocs web
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Lloc web
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Permet notificacions
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Llocs web
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Sempre
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Permet
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Mai
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = No s'ha afegit cap notificació de llocs web.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = No hi ha cap notificació de llocs web que coincideixi amb la cerca.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Per assegurar-vos que aquest canvi s'inclou a les vostres còpies de seguretat, obriu cada perfil i seleccioneu "Fes una còpia de seguretat ara" a  la configuració.
nimbus-rollouts =
    .description = Els canvis s'aplicaran de manera remota.
    .label = Permet que el { -brand-short-name } millori les funcions, el rendiment i l'estabilitat entre actualitzacions
addon-recommendations3 =
    .description = Rebeu recomanacions d'extensions per millorar l'experiència de navegació.
    .label = Permet les recomanacions d'extensions personalitzades
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = L'informe de dades està desactivat en la configuració d'aquesta versió.
collection-backlogged-crash-reports2 =
    .label = Envia automàticament informes de fallada
    .accesskey = c
collection-backlogged-crash-reports-description = Això ajuda a { -vendor-short-name } a diagnosticar i solucionar problemes del navegador. Els informes poden incloure dades personals o confidencials.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = La mateixa configuració, aparença nova!
    .message = Hem reorganitzat aquesta pàgina perquè sigui més fàcil escanejar i explorar. La vostra configuració personal no ha canviat, i tot segueix aquí. Consell: utilitza la cerca per a saltar directament al que necessites.
settings-redesign-promo-dismiss-button =
    .label = Entesos
privacy-segmentation-section-header = Noves funcions que milloren la navegació
privacy-segmentation-section-description = Quan us oferim funcions que utilitzen les vostres dades per oferir-vos una experiència més personal:
privacy-segmentation-radio-off =
    .label = Utilitza les recomanacions del { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Mostra informació detallada
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Ens esforcem per oferir-vos opcions i només recollim el mínim de dades necessàries per millorar el { -brand-product-name } per a tothom.
    .label = Ús i recollida de dades i del { -brand-short-name }
    .searchkeywords = telemetria
data-collection-link = Mostra l'avís de privadesa
data-collection-preferences-across-profiles =
    .message = Aquesta configuració s'aplica a tots els perfils del { -brand-product-name } en aquest dispositiu.
data-collection-profiles-link = Mostra tots els perfils
data-collection-health-report-telemetry-disabled =
    .message = Ja no permeteu a { -vendor-short-name } capturar dades tècniques i d'interacció. Totes les dades antigues se suprimiran d'aquí a 30 dies.
data-collection-health-report =
    .description = Això ens ajuda a millorar les funcions, el rendiment i l'estabilitat del { -brand-product-name }.
    .label = Envia dades tècniques i d’interacció a { -vendor-short-name }
    .accesskey = r
data-collection-health-report-disabled =
    .description = L'informe de dades està desactivat en la configuració d'aquesta versió.
    .label = Envia dades tècniques i d’interacció a { -vendor-short-name }
    .accesskey = r
data-collection-run-studies =
    .description = El { -brand-short-name } selecciona aleatòriament usuaris per provar funcions, cosa que ajuda a millorar la qualitat per a tothom.
    .label = Permet al { -brand-short-name } instal·lar i executar estudis de funcionalitat
data-collection-studies-link =
    .label = Mostra els estudis del { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = Això ajuda { -vendor-short-name } a diagnosticar i solucionar problemes del navegador. Els informes poden incloure dades personals o confidencials.
    .label = Envia automàticament informes de fallada
    .accesskey = c
data-collection-usage-ping =
    .description = Això ajuda a { -vendor-short-name } a estimar els usuaris actius.
    .label = Envia un ping d'ús diari a { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Seguretat
browsing-protection-group2 =
    .description = Els llocs o les descàrregues perilloses poden posar les vostres dades i dispositiu en risc. El { -brand-short-name } automàticament els bloca, i us avisa sobre programari perillós o no sol·licitat.
    .label = Protecció contra contingut enganyós i programari perillós
security-enable-safe-browsing =
    .label = Bloca el contingut enganyós i perillós
    .accesskey = B
security-enable-safe-browsing-link = Més informació
security-safe-browsing-warning =
    .message = Desactivar això redueix la protecció contra estafes, llocs maliciosos i descàrregues perilloses.
security-block-downloads =
    .label = Bloca les baixades perilloses
    .accesskey = l
security-block-uncommon-software =
    .label = Avisa en baixar programari indesitjable i poc habitual
    .accesskey = c

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Permet que el { -brand-short-name } confiï automàticament en els certificats arrel de tercers que instal·leu
    .accesskey = t
certs-devices-enable-fips = Habilita els FIPS
space-alert-over-5gb-settings-button =
    .label = Obre els paràmetres
    .accesskey = O
space-alert-over-5gb-message2 = <strong>El { -brand-short-name } s'està quedant sense espai de disc.</strong> És possible que el contingut dels llocs web no es mostri correctament. Podeu esborrar les dades emmagatzemades dels llocs a «Paràmetres > Privadesa i seguretat > Galetes i dades dels llocs».
space-alert-under-5gb-message2 = <strong>El { -brand-short-name } s'està quedant sense espai de disc.</strong> És possible que el contingut dels llocs web no es mostri correctament. Vegeu «Més informació» per optimitzar l'ús de disc i millorar l'experiència de navegació.
certs-description3 =
    .description = Configureu els certificats que el { -brand-short-name } usa per a verificar les connexions segures.
    .label = Certificats
certs-view2 =
    .label = Gestiona els certificats
    .accesskey = c
certs-devices2 =
    .label = Gestiona els dispositius de seguretat
    .accesskey = d

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Com funciona el mode només HTTPS
httpsonly-radio-enabled =
    .label = Activa el mode només HTTPS en totes les finestres
httpsonly-radio-enabled-pbm =
    .label = Activa el mode només HTTPS únicament en les finestres privades
httpsonly-radio-disabled3 =
    .description = El { -brand-short-name } igualment pot actualitzar algunes connexions
    .label = No activis el mode només HTTPS
httpsonly-group =
    .description = Permet només connexions segures als llocs web. El { -brand-short-name } us preguntarà abans de connectar-se de manera no segura.
    .label = Mode només HTTPS
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS sobre HTTPS
dns-over-https-group2 =
    .description = El Sistema de noms de domini sobre HTTPS (DoH) xifra les cerques sobre llocs de manera que fa més difícil que el vostre proveïdor d'internet o altres puguin veure quins llocs webs visitareu.
    .label = DNS sobre HTTPS
preferences-doh-description2 = El sistema de noms de domini (DNS) sobre HTTPS envia la vostra sol·licitud d'un nom de domini mitjançant una connexió xifrada, proporcionant un DNS segur i dificultant que els altres vegin a quin lloc web esteu a punt d'accedir.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Estat: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Proveïdor: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = L'URL no és vàlid
preferences-doh-steering-status = Mitjançant un proveïdor local
preferences-doh-status-active = Actiu
preferences-doh-status-disabled = Desactivat
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Inactiu ({ $reason })
preferences-doh-group-message2 = Habilita DNS sobre HTTPS mitjançant:
preferences-doh-radio-group =
    .aria-label = Habilita DNS sobre HTTPS mitjançant:
preferences-doh-expand-section =
    .tooltiptext = Més informació
preferences-doh-setting-default =
    .label = Protecció per defecte
    .accesskey = P
preferences-doh-default-desc = El { -brand-short-name } decideix quan cal utilitzar el DNS segur per a protegir la vostra privadesa.
preferences-doh-default-detailed-desc-1 = Utilitza el DNS segur en les regions on estigui disponible
preferences-doh-default-detailed-desc-2 = Utilitza el vostre sistema de resolució de DNS per defecte si hi ha algun problema amb el proveïdor de DNS segur
preferences-doh-default-detailed-desc-3 = Utilitza un proveïdor local, si és possible
preferences-doh-default-detailed-desc-4 = Desactiva quan la VPN, el control parental o les polítiques empresarials estiguin activats
preferences-doh-default-detailed-desc-5 = Desactiva quan una xarxa digui al { -brand-short-name } que no utilitzi el DNS segur
preferences-doh-setting-enabled =
    .label = Protecció ampliada
    .accesskey = P
preferences-doh-enabled-desc = Controleu quan voleu utilitzar el DNS segur i trieu el vostre proveïdor.
preferences-doh-enabled-detailed-desc-1 = Utilitza el proveïdor que trieu
preferences-doh-enabled-detailed-desc-2 = Utilitza el vostre sistema de resolució de DNS per defecte només si hi ha algun problema amb el DNS segur
preferences-doh-setting-strict =
    .label = Protecció màxima
    .accesskey = m
preferences-doh-strict-desc = El { -brand-short-name } sempre utilitzarà el DNS segur. Si cal utilitzar el DNS del vostre sistema, veureu un avís de risc de seguretat.
preferences-doh-strict-detailed-desc-1 = Utilitza només el proveïdor que trieu
preferences-doh-strict-detailed-desc-2 = Sempre avisa si el DNS segur no està disponible
preferences-doh-strict-detailed-desc-3 = Si el DNS segur no està disponible, els llocs no es carregaran ni funcionaran correctament
preferences-doh-setting-off =
    .label = Desactivat
    .accesskey = D
preferences-doh-off-desc = Utilitza el vostre sistema de resolució de DNS per defecte
preferences-doh-select-resolver = Trieu el proveïdor:
preferences-doh-manage-exceptions =
    .label = Gestiona les excepcions…
    .accesskey = x
preferences-doh-overview-default =
    .description = Utilitza DNS segur en regions on està disponible.
    .label = Protecció predeterminada
preferences-doh-overview-custom =
    .description = Utilitzeu sempre DNS segurs amb control sobre el vostre proveïdor i el comportament alternatiu.
    .label = Personalitzat
preferences-doh-overview-off =
    .description = Utilitza el vostre sistema de resolució de DNS per defecte.
    .label = Desactivat
preferences-doh-advanced-button =
    .label = Paràmetres avançats
preferences-doh-advanced-section =
    .description = El Sistema de noms de domini sobre HTTPS (DoH) xifra les cerques sobre llocs de manera que fa més difícil que el vostre proveïdor d'internet o altres puguin veure quins llocs webs visitareu.
    .label = Paràmetres avançats
preferences-doh-manage-exceptions2 =
    .label = Gestiona les excepcions
    .accesskey = x
preferences-doh-radio-default =
    .description = Utilitza el DNS segur en les regions on estigui disponible
    .label = Per defecte
preferences-doh-radio-custom =
    .description = Utilitzeu sempre DNS segurs amb control sobre el vostre proveïdor i el comportament alternatiu
    .label = Personalitzat
preferences-doh-radio-off =
    .description = Utilitza el vostre sistema de resolució de DNS per defecte
    .label = Desactivat
preferences-doh-fallback-label =
    .label = Avisa'm sempre si el DNS segur no està disponible
preferences-doh-status-item-off =
    .message = El DNS sobre HTTPS està desactivat
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = El DNS sobre HTTPS no funciona perquè hem trobat un error ({ $reason }) en intentar utilitzar el proveïdor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = El DNS sobre HTTPS no funciona perquè hem rebut un URL no vàlid ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS sobre HTTPS està utilitzant el proveïdor { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = El DNS sobre HTTPS no funciona perquè hem trobat un error ({ $reason }) en intentar utilitzar el proveïdor local { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS sobre HTTPS utilitza el proveïdor local { $name }
preferences-doh-select-resolver-label =
    .label = Trieu el proveïdor:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Utilitza aquest proveïdor per a resoldre DNS a través d'HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Introduïu un URL de proveïdor personalitzat
preferences-doh-header2 =
    .heading = DNS sobre HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Connexió i seguretat del programari
preferences-connection-link-section =
    .description = Vegeu com les connexions es mantenen segures, es bloqueja el programari nociu i es verifiquen els llocs web.
    .label = Connexió i seguretat del programari
preferences-connection-link-button =
    .label = Paràmetres avançats

## The following strings are used in the Download section of settings

desktop-folder-name = Escriptori
downloads-folder-name = Baixades

## Appearance page

preferences-appearance-header =
    .heading = Aparença
browser-theme-group =
    .description = Estilitzeu el { -brand-short-name } a la vostra manera. Els colors del tema s'apliquen a les barres d'eines, menús i missatges.
    .label = Tema del navegador
browser-theme-manage-link =
    .label = Gestiona els temes del { -brand-short-name }
appearance-window-density-group =
    .description = Ajusta l'espaiat al voltant dels elements de la finestra com la barra d'eines, les pestanyes i la barra lateral.
    .label = Densitat de la finestra
appearance-window-density-radio-group =
    .aria-label = Densitat de la finestra
appearance-window-density-automatic =
    .description = L'espaiat estàndard, compacte o tàctil s'aplica automàticament
    .label = Automàtica (per defecte)
appearance-window-density-automatic-no-touch =
    .description = L'espaiat estàndard o compacte s'aplica automàticament
    .label = Automàtica (per defecte)
appearance-window-density-standard =
    .description = Espaiat equilibrat per a la majoria de pantalles
    .label = Estàndard
appearance-window-density-auto-touch-mode =
    .label = Utilitza l'espaiat tàctil per al mode tauleta
appearance-window-density-compact =
    .description = Espaiat reduït per a pantalles més petites
    .label = Compacta
appearance-window-density-touch =
    .description = Elements de finestra i objectius de clic més grans, optimitzats per a pantalles tàctils
    .label = Tàctil
related-settings-group =
    .label = Paràmetres relacionats
related-settings-accessibility-link =
    .label = Personalitzeu els paràmetres del zoom i tipus de lletra a Accessibilitat
related-settings-home-link =
    .label = Personalitza { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = Personalitza la disposició del navegador

## AI controls page

preferences-ai-controls-description = Sempre teniu una opció a { -brand-short-name }, incloent-hi si voleu utilitzar funcions millorades amb IA. Aviat arribaran més controls.
preferences-ai-controls-block-ai-label = Bloca les millores basades en IA
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = El fet de blocar implica que no veureu millores d'IA noves o actuals al { -brand-short-name }, ni finestres emergents sobre elles. <a data-l10n-name="link">Obteniu més detalls</a> sobre què s'inclou i com controlar les funcions tradicionals d'aprenentatge automàtic, com ara suggeriments de cerca i recomanacions.
preferences-ai-controls-blocked-message =
    .message = Les millores noves i actuals de la IA estan bloquejades per defecte. Per a desbloquejar una característica específica, utilitzeu els controls següents.
preferences-ai-controls-on-device-group =
    .description = Aquests utilitzen petits models d'IA que es descarreguen al vostre dispositiu si utilitzeu la funció. Aquest enfocament ajuda a protegir la vostra privacitat.
    .label = IA en dispositiu
preferences-ai-controls-translations-control =
    .description = Navegueu sense problemes per la web en la vostra llengua preferida.
    .label = Traduccions
preferences-ai-controls-translations-more-link = Més paràmetres de traducció
preferences-ai-controls-pdfjs-control =
    .description = Quan afegiu imatges als PDF, això hi afegeix descripcions per fer-les accessibles.
    .label = Text alternatiu de la imatge al visor de PDF del { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Obteniu suggeriments per anomenar i organitzar les pestanyes
    .label = Suggeriments de grups de pestanyes
preferences-ai-controls-key-points-control =
    .description = Vegeu un resum ràpid de l'enllaç abans d'obrir-lo.
    .label = Punts clau a les previsualitzacions dels enllaços
preferences-ai-controls-speech-recognition-control =
    .description = Transcriviu la parla en local.
    .label = Reconeixement de la parla
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Mostra un bot de conversa d’IA mentre navegueu. Podeu triar entre diversos proveïdors i canviar-los en qualsevol moment.
    .label = Proveïdors de bot de conversa d’IA a la barra lateral
preferences-ai-controls-sidebar-chatbot-group =
    .description = Tingueu un bot de conversa a la vista mentre navegueu. Escolliu entre Anthropic Claude, ChatGPT, Copilot, Google Gemini i Le Chat Mistral.
    .label = Proveïdors de bots de conversa d'IA a la barra lateral
preferences-ai-controls-sidebar-chatbot-control =
    .label = Bot de conversa a la barra lateral
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Disponible
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Activat
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Blocat
preferences-ai-controls-state-description-before = Què signifiquen les opcions:
preferences-ai-controls-state-description-available = <strong>Disponible:</strong> Veureu la funció i la podreu utilitzar.
preferences-ai-controls-state-description-enabled = <strong>Activat:</strong> Heu optat per utilitzar la funció.
preferences-ai-controls-state-description-blocked = <strong>Blocat</strong>: No veureu la funció ni la podreu utilitzar. Per a la IA en el dispositiu, s’eliminaran tots els models baixats.
preferences-ai-controls-block-confirmation-heading = Voleu blocar les millores basades en IA?
preferences-ai-controls-block-confirmation-description = No veureu millores noves o actuals de la IA al { -brand-short-name }, ni finestres emergents sobre elles. Després, podeu desbloquejar tot el que vulgueu continuar utilitzant.
preferences-ai-controls-block-confirmation-features-start = Què es blocarà:
preferences-ai-controls-block-confirmation-translations = Traduccions
preferences-ai-controls-block-confirmation-pdfjs = Text alternatiu de la imatge al visor de PDF del { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Suggeriments de grups de pestanyes
preferences-ai-controls-block-confirmation-key-points = Punts clau a les previsualitzacions dels enllaços
preferences-ai-controls-block-confirmation-sidebar-chatbot = Proveïdors de xat a la barra lateral
preferences-ai-controls-block-confirmation-speech-recognition = Reconeixement de veu
preferences-ai-controls-block-confirmation-features-after = El bloqueig també afecta les extensions que utilitzen la IA proporcionada per { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Cancel·la
preferences-ai-controls-block-confirmation-confirm =
    .label = Bloca
preferences-ai-controls-header3 =
    .heading = Controls d’IA

## Privacy and security status card

security-privacy-status-ok-header = El { -brand-short-name } està en guàrdia
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = El { -brand-short-name } recomana algunes millores de seguretat
security-privacy-status-ok-label = La protecció contra el seguiment millorada està activada
security-privacy-status-problem-label = Hem trobat paràmetres que afecten la vostra protecció
security-privacy-status-problem-helper-label = Mostra els problemes
security-privacy-status-pending-trackers-label = S'està cercant quants elements de seguiment { -brand-short-name } s'han blocat durant l'últim mes
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] S'ha bloquejat { $trackerCount } element de seguiment durant l'últim mes
       *[other] S'han bloquejat { $trackerCount } elements de seguiment durant l'últim mes
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Teniu <a data-l10n-name="strict-tracking-protection">protecció estricta</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Teniu <a data-l10n-name="custom-tracking-protection">protecció personalitzada</a>
security-privacy-status-up-to-date-label = Teniu la versió més recent i segura del { -brand-short-name }
security-privacy-status-update-needed-label = Hi ha disponible una nova versió del { -brand-short-name }.
security-privacy-status-update-error-label = El { -brand-short-name } té problemes per actualitzar-se
security-privacy-status-update-checking-label = El { -brand-short-name } està comprovant si hi ha actualitzacions
security-privacy-status-update-needed-description = Actualitzeu per a les últimes actualitzacions de velocitat, estabilitat i seguretat.
security-privacy-status-update-button-label =
    .label = Actualitza el { -brand-short-name }
security-privacy-image-warning =
    .alt = Un escut amb una exclamació, expressant preocupació pels vostres avisos de seguretat
security-privacy-image-ok =
    .alt = Un escut amb una marca de verificació, que demostra que no teniu problemes de seguretat pendents
security-privacy-issue-card =
    .heading = Avisos de seguretat
issue-card-reset-button =
    .label = Reinicia
issue-card-dismiss-button =
    .aria-label = Descarta
    .tooltiptext = Descarta

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Els llocs web utilitzen elements que fan el seguiment de la vostra navegació i que mostren anuncis esgarrifosos. El { -brand-short-name } us protegeix mentre navegueu, blocant els elements de seguiment automàticament perquè tingueu el control del vostre rastre digital.
    .label = Protecció contra el seguiment millorada
preferences-etp-level-radio-group =
    .aria-label = Protecció contra el seguiment millorada
preferences-etp-level-standard =
    .description = Proteccions fortes i fiables que funcionen sense problemes amb la majoria de llocs web.
    .label = Estàndard (per defecte)
preferences-etp-level-strict =
    .description = Proteccions més fortes que bloquegen més elements de seguiment, però que poden provocar que alguns llocs no funcionin correctament.
    .label = Estricta
preferences-etp-level-custom =
    .description = Trieu quines proteccions voleu activar o desactivar.
    .label = Personalitzada
preferences-etp-status-advanced-button =
    .label = Paràmetres avançats
preferences-etp-tracker-count-enabled =
    .label = Mostra els elements de seguiment bloquejats a la barra d'adreces
preferences-etp-status-protections-dashboard-link =
    .description = Vegeu quants elements de seguiment furtius ha blocat el { -brand-short-name }, inclosos els elements de seguiment de les xarxes socials, els generadors d'empremtes digitals i els miners de criptomonedes.
    .label = Visualitzeu el vostre tauler de proteccions personalitzades
preferences-etp-header =
    .heading = Protecció contra el seguiment millorada
preferences-etp-advanced-settings-group =
    .description = Els llocs utilitzen elements de seguiment per seguir-vos en línia i mostrar anuncis inquietants. El { -brand-short-name } us protegeix mentre navegueu: bloca automàticament la majoria d'elements de seguiment perquè tingueu el control del vostre rastre digital.
    .label = Paràmetres avançats
preferences-etp-customize-button =
    .label = Personalitzeu la protecció contra el seguiment
preferences-etp-reload-tabs-hint =
    .message = Torneu a carregar les pestanyes per aplicar aquests canvis.
preferences-etp-reload-tabs-hint-button =
    .label = Torna a carregar totes les pestanyes
preferences-etp-rfp-warning-message =
    .message = Esteu utilitzant RFP (Resist Fingerprinting), que substitueix alguns dels paràmetres de protecció d'empremtes digitals del { -brand-short-name }. Això pot fer que alguns llocs no funcionin correctament.
preferences-etp-level-warning-message =
    .heading = Compte! És possible que alguns llocs no funcionin de la manera prevista.
    .message = Alguns llocs integren elements de seguiment en les seves funcions o en el contingut. Quan el { -brand-short-name } els bloca, és possible que el lloc no funcioni bé. Proveu d'utilitzar «Corregeix el problema del lloc» o de desactivar la protecció contra el seguiment en aquest lloc.
preferences-etp-manage-exceptions-button =
    .description = Gestioneu els llocs web on la protecció contra el seguiment millorada està desactivada.
    .label = Gestiona les excepcions
preferences-etp-customize-header =
    .heading = Personalitzeu la protecció contra el seguiment
preferences-etp-reset =
    .description = Restableix la configuració a un nivell de protecció preestablert.
    .label = Restableix les personalitzacions
preferences-etp-reset-standard-button =
    .label = Restableix a estàndard
preferences-etp-reset-strict-button =
    .label = Restableix a estricte
preferences-etp-custom-control-group =
    .description = Trieu quines proteccions voleu activar o desactivar.
    .label = Protecció contra el seguiment
preferences-etp-custom-cookies-enabled =
    .label = Galetes
preferences-etp-custom-cookie-behavior =
    .aria-label = Galetes
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Permet totes les galetes
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Bloca les galetes de seguiment entre llocs
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Bloqueja les galetes entre llocs
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Aïlla les galetes entre llocs
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Bloqueja les galetes dels llocs web no visitats
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Bloqueja totes les galetes entre llocs (pot fer que els llocs web no funcionin)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Bloqueja totes les galetes (farà que els llocs web no funcionin)
preferences-etp-custom-tracking-protection-enabled =
    .label = Contingut que fa seguiment
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Contingut que fa seguiment
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Miners de criptomonedes
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Generadors d'empremtes digitals coneguts
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Generadors d'empremtes digitals sospitosos
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Generadors d'empremtes digitals sospitosos

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Això pot permetre que alguns elements de seguiment us segueixin sense galetes.
    .label = Els generadors d'empremtes digitals coneguts no estan bloquejats
security-privacy-issue-warning-third-party-cookies =
    .description = Les galetes de tercers s'utilitzen per fer-vos el seguiment entre llocs web.
    .label = Les galetes de tercers estan activades
security-privacy-issue-warning-password-manager =
    .description = Els gestors de contrasenyes us ajuden a emmagatzemar contrasenyes segures per als vostres comptes.
    .label = El gestor de contrasenyes està desactivat
security-privacy-issue-warning-popup-blocker =
    .description = Les finestres emergents són intrusives i potencialment perjudicials.
    .label = El blocador emergent està desactivat
security-privacy-issue-warning-extension-install =
    .description = Els llocs web poden instal·lar extensions al { -brand-short-name } sense preguntar.
    .label = Els llocs web poden instal·lar extensions
security-privacy-issue-warning-safe-browsing =
    .description = S'incrementa la vostra exposició a estafes i programari maliciós dels llocs web.
    .label = El contingut perillós i enganyós no està bloquejat
security-privacy-issue-warning-doh2 =
    .description = DNS sobre HTTPS ajuda a ocultar quins llocs esteu a punt de visitar des del vostre proveïdor de xarxa.
    .label = DNS sobre HTTPS està desactivat
security-privacy-issue-warning-ech2 =
    .description = El «Client Hello» xifrat ajuda a ocultar quins llocs esteu a punt de visitar des del vostre proveïdor de xarxa.
    .label = L'Encrypted Client Hello està desactivat
security-privacy-issue-warning-doh =
    .description = DNS sobre HTTPS oculta els llocs que visiteu des del vostre proveïdor de xarxa.
    .label = DNS sobre HTTPS està desactivat
security-privacy-issue-warning-ech =
    .description = El «Client Hello» xifrat oculta els llocs que visiteu des del vostre proveïdor de xarxa.
    .label = El «Client Hello» xifrat està desactivat
security-privacy-issue-warning-proxy-autodetection =
    .description = La configuració automàtica del servidor intermediari podria permetre que xarxes no fiables supervisin la vostra activitat.
    .label = La configuració automàtica del servidor intermediari està activada

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Convideu algú a triar el navegador que dona prioritat a la privadesa.
    .label = Compartiu el { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Comparteix el { -brand-product-name }


pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = about:config canvis, lògicament agrupat i fàcilment accessible
vorbit-header = Preferències
vorbit-warning-title = Atenció!
vorbit-warning-description = Nosaltres triem acuradament la configuració predeterminada per centrar-nos en la privadesa i la seguretat. Quan canvieu aquesta configuració, llegiu les descripcions per entendre les implicacions d'aquests canvis.
vorbit-general-heading = Conducta del navegador
vorbit-extension-update-checkbox =
    .label = Actualitza els complements automáticament
vorbit-sync-checkbox =
    .label = Habilita la sincronització de Firefox
vorbit-autocopy-checkbox =
    .label = Activa enganxa amb el clic central
vorbit-styling-checkbox =
    .label = Permet la customització userChrome.css
vorbit-network-heading = Xarxes
vorbit-ipv6-checkbox =
    .label = Activa IPv6
vorbit-privacy-heading = Privacitat
vorbit-xorigin-ref-checkbox =
    .label = Limita Les referéncies d'origen creuat
vorbit-broken-heading = Empremtes dactilars
vorbit-webgl-checkbox =
    .label = Activa WebGL amb permisos per página.
vorbit-rfp-checkbox =
    .label = Activa ResistFingerprinting
vorbit-letterboxing-checkbox =
    .label = Activa la impressió en bústia
vorbit-security-heading = Seguretat
vorbit-ocsp-checkbox =
    .label = Força l'errada d'OCSP
vorbit-goog-safe-checkbox =
    .label = Activa la Navegació Segura de Google
vorbit-goog-safe-download-checkbox =
    .label = Analitza les descárregues
vorbit-extension-update-description = Mantingueu les extensions actualitzades sense intervenció manual. Una bona opció per a la vostra seguretat.
vorbit-extension-update-warning1 = Si no reviseu el codi de les extensions abans de cada actualització, hauríeu d'activar aquesta opció.
vorbit-ipv6-description = Allow { -brand-short-name } per a connectar emprant IPv6.
vorbit-ipv6-warning1 = En comptes de bloquejar l'IPv6 al navegador, vos suggerim que activeu l'extensió de privadesa IPv6 al vostre sistema operatiu.
vorbit-ocsp-description = Impedir la connexió a un lloc web si no es pot realitzar la comprovació OCSP.
vorbit-ocsp-warning1 = Això augmenta la seguretat, però causarà fallades quan un servidor OCSP no funcioni.
vorbit-sync-description = Sincronitza les teues dades amb altres navegadors. Cal reiniciar.
vorbit-sync-warning1 = Firefox Sync xifra les dades localment abans de transmetre-les al servidor.
vorbit-autocopy-description = Seleccioneu text per copiar-lo i, a continuació, enganxeu-lo amb un clic amb el botó central del ratolí.
vorbit-styling-description = Activeu això si voleu personalitzar la interfície d'usuari amb un tema carregat manualment.
vorbit-styling-warning1 = Assegureu-vos de confiar en el proveïdor del tema.
vorbit-xorigin-ref-description = Envia un referent només al mateix origen.
vorbit-xorigin-ref-warning1 = Això pot causar trencaments. A més, fins i tot quan s'enviïn, els referents es retallaran.
vorbit-webgl-description = WebGL és un vector d'empremtes dactilars potent. Això activa WebGL amb una sol·licitud de permís per lloc.
vorbit-webgl-warning1 = Quan un lloc intenti crear un context WebGL, se us demanarà permís primer.
vorbit-rfp-description = ResistFingerprinting és la millor eina antiempremtes dactilars de la seva classe.
vorbit-rfp-warning1 = Si cal desactivar-ho, considereu la possibilitat d'utilitzar una extensió com ara Canvas Blocker.
vorbit-letterboxing-description = El letterboxing aplica marges al voltant de les finestres per retornar un conjunt limitat de resolucions arrodonides.
vorbit-goog-safe-description = Si vos preocupa el programari maliciós i el phishing, considereu activar-lo.
vorbit-goog-safe-warning1 = Desactivat per motius de censura, però recomanat per a usuaris menys avançats. Totes les comprovacions es fan localment.
vorbit-goog-safe-download-description = Permet que Navegació Segura escanegi les teues baixades per identificar fitxers sospitosos.
vorbit-goog-safe-download-warning1 = Totes les comprovacions es fan localment.
vorbit-footer = Enllaços útils
vorbit-config-link = Tots els paràmetres avançats (about:config)
vorbit-open-profile = Obre el directori del perfil d'usuari
content-blocking-section-top-level-description = vOrbit-lite admet (i habilita per defecte) la protecció de seguiment millorada en mode estricte. Aquesta és una de les configuracions més importants del navegador, ja que proporciona particions d'estat, llistes de bloqueig estrictes i altres funcions de privadesa útils. No recomanem canviar a altres modes.
vorbit-webgl-prompt-checkbox =
    .label = Amaga la finestra emergent lloc per lloc de WebGL
vorbit-webgl-prompt-description = Això amaga la finestra emergent que apareix quan un lloc intenta crear un context WebGL. Encara podeu mostrar manualment la sol·licitud fent clic a la icona de la barra de cerca.
permissions-webgl2 =
    .label = WebGL
