# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 48em
    .title = Excepcions
permissions-close-key =
    .key = w
permissions-address = Adreça del lloc web
    .accesskey = d
permissions-block =
    .label = Bloca
    .accesskey = B
permissions-disable-etp =
    .label = Afegeix una excepció
    .accesskey = e
permissions-session =
    .label = Permet durant la sessió
    .accesskey = s
permissions-allow =
    .label = Permet
    .accesskey = P
permissions-add =
    .label = Afegeix
    .accesskey = A
permissions-button-off =
    .label = Desactiva
    .accesskey = D
permissions-button-off-temporarily =
    .label = Desactiva temporalment
    .accesskey = t
permissions-site-name =
    .label = Lloc web
permissions-status =
    .label = Estat
permissions-remove =
    .label = Elimina el lloc web
    .accesskey = E
permissions-remove-all =
    .label = Elimina tots els llocs web
    .accesskey = E
permissions-save-changes-2 =
    .buttonlabelaccept = Desa els canvis
    .buttonaccesskeyaccept = s
permission-dialog =
    .buttonlabelaccept = Desa els canvis
    .buttonaccesskeyaccept = s
permissions-autoplay-menu = Per defecte per a tots els llocs web:
permissions-searchbox =
    .placeholder = Cerca el lloc web
permissions-capabilities-autoplay-allow =
    .label = Permet àudio i vídeo
permissions-capabilities-autoplay-block =
    .label = Bloca àudio
permissions-capabilities-autoplay-blockall =
    .label = Bloca àudio i vídeo
permissions-capabilities-allow =
    .label = Permet
permissions-capabilities-block =
    .label = Bloca
permissions-capabilities-prompt =
    .label = Demana-m'ho sempre
permissions-capabilities-listitem-allow =
    .value = Permet
permissions-capabilities-listitem-block =
    .value = Bloca
permissions-capabilities-listitem-allow-session =
    .value = Permet durant la sessió
permissions-capabilities-listitem-off =
    .value = Desactivat
permissions-capabilities-listitem-off-temporarily =
    .value = Desactivat temporalment

## Invalid Hostname Dialog

permissions-invalid-uri-title = S'ha introduït un nom d'ordinador central no vàlid
permissions-invalid-uri-label = Introduïu un nom d'ordinador central vàlid

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Excepcions a la protecció contra el seguiment millorada
permissions-exceptions-manage-etp-desc = Podeu especificar quins llocs web tenen desactivada la protecció contra el seguiment millorada. Escriviu l'adreça exacta del lloc que voleu gestionar i feu clic a Afegeix una excepció.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Excepcions - Galetes i dades dels llocs
permissions-exceptions-cookie-desc = Podeu especificar quins llocs web poden utilitzar galetes i dades dels llocs. Escriviu l'adreça exacta del lloc que voleu gestionar i feu clic a Bloca, Permet durant la sessió o Permet.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Excepcions: esborra l'historial en tancar.
permissions-exceptions-shutdown-clearing-desc = Podeu especificar quins llocs web poden conservar les seves dades quan el { -brand-short-name } esborra l'historial en acabar. Escriviu l'adreça exacta del lloc que vulgueu gestionar i després cliqueu a Permetre.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Excepcions - Mode només HTTPS
permissions-exceptions-https-only-desc2 = Podeu desactivar el mode només HTTPS per a llocs web específics. El { -brand-short-name } no intentarà canviar a una connexió HTTPS segura per a aquests llocs.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Llocs web permesos - Finestres emergents i redireccions de tercers
permissions-exceptions-popup-desc2 = Podeu especificar quins llocs web poden obrir finestres emergents i ser redirigits per marcs de tercers.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Excepcions - Contrasenyes desades
permissions-exceptions-saved-passwords-desc = El { -brand-short-name } no desarà les contrasenyes dels llocs llistats aquí.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Llocs web permesos - Instal·lació de complements
permissions-exceptions-addons-desc = Podeu especificar quins llocs web poden instal·lar complements. Escriviu l'adreça exacta del lloc que vulgueu permetre i feu clic a Permet.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Reproducció automàtica
permissions-site-autoplay-desc = Aquí podeu gestionar els llocs que no segueixen els vostres paràmetres de reproducció automàtica per defecte.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos de notificacions
permissions-site-notification-desc = Els llocs web següents han sol·licitat enviar-vos notificacions. Podeu indicar quins llocs web tenen permís per enviar-vos notificacions. També podeu blocar les noves sol·licituds de permetre notificacions.
permissions-site-notification-disable-label =
    .label = Bloca les noves sol·licituds de permetre les notificacions
permissions-site-notification-disable-desc = Això impedirà que els llocs web que no estiguin en aquesta llista us sol·licitin permís per enviar notificacions. Blocar les notificacions podria fer que algunes funcions dels llocs web no funcionin correctament.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Permet les notificacions de llocs web quan el { -brand-short-name } estigui tancat
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = També s'aplica la configuració de notificacions del sistema operatiu.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos d'ubicació
permissions-site-location-desc = Els llocs web següents han sol·licitat accés a la vostra ubicació. Podeu indicar quins llocs web tenen permís per accedir a la vostra ubicació. També podeu blocar les noves sol·licituds d'accedir a la vostra ubicació.
permissions-site-location-disable-label =
    .label = Bloca les noves sol·licituds d'accés a la vostra ubicació
permissions-site-location-disable-desc = Això impedirà que els llocs web que no estiguin en aquesta llista us sol·licitin permís per accedir a la vostra ubicació. Blocar l'accés a la vostra ubicació podria fer que algunes funcions dels llocs web no funcionin correctament.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos de realitat virtual
permissions-site-xr-desc = Els llocs web següents han sol·licitat accés als dispositius de realitat virtual. Podeu indicar quins llocs web tenen permís per accedir als dispositius de realitat virtual. També podeu blocar les noves sol·licituds d'accedir als dispositius de realitat virtual.
permissions-site-xr-disable-label =
    .label = Bloca les noves sol·licituds d'accés als dispositius de realitat virtual
permissions-site-xr-disable-desc = Això impedirà que els llocs web que no estiguin en aquesta llista us sol·licitin permís per accedir als dispositius de realitat virtual. Blocar l'accés als dispositius de realitat virtual podria fer que algunes funcions dels llocs web no funcionin correctament.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Paràmetres - Llocs blocats per als enllaços d'aplicacions
permissions-site-app-links-desc = Aquests llocs no poden demanar obrir enllaços d'aplicacions, com ara els de correu electrònic (mailto:). Elimineu un lloc perquè ho pugui tornar a demanar.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos de la càmera
permissions-site-camera-desc = Els llocs web següents han sol·licitat accés a la càmera. Podeu indicar quins llocs web tenen permís per accedir a la càmera. També podeu blocar les noves sol·licituds d'accedir a la càmera.
permissions-site-camera-disable-label =
    .label = Bloca les noves sol·licituds d'accés a la càmera
permissions-site-camera-disable-desc = Això impedirà que els llocs web que no estiguin en aquesta llista us sol·licitin permís per accedir a la càmera. Blocar l'accés a la càmera podria fer que algunes funcions dels llocs web no funcionin correctament.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Paràmetres - Aplicacions i serveis del dispositiu
permissions-site-localhost-desc = Aquests llocs web han sol·licitat accés a aplicacions i serveis en aquest dispositiu. Podeu optar per permetre o bloquejar quins llocs web ho fan.
permissions-site-localhost-disable-label =
    .label = Bloca les noves sol·licituds d'accés a aplicacions i serveis en aquest dispositiu
permissions-site-localhost-disable-desc = Això impedirà que qualsevol lloc web que no estigui a la llista anterior sol·liciti accés a aplicacions i serveis en aquest dispositiu. Si ho feu, és possible que algunes funcions de llocs web no funcionin correctament.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Paràmetres - Dispositius de la xarxa local
permissions-site-local-network-desc = Aquests llocs web han sol·licitat accés a aplicacions i serveis en dispositius connectats a la vostra xarxa Wi-Fi o xarxa local. Podeu optar per permetre o bloquejar quins llocs web ho fan.
permissions-site-local-network-disable-label =
    .label = Bloca les noves sol·licituds per accedir a aplicacions i serveis en dispositius connectats a la vostra xarxa Wi-Fi o xarxa local.
permissions-site-local-network-disable-desc = Això impedirà que qualsevol lloc web que no estigui a la llista anterior sol·liciti accés a aplicacions i serveis en dispositius connectats a la vostra xarxa Wi-Fi o xarxa local. Si ho feu, és possible que algunes funcions de llocs web no funcionin correctament.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos del micròfon
permissions-site-microphone-desc = Els llocs web següents han sol·licitat accés al micròfon. Podeu indicar quins llocs web tenen permís per accedir al micròfon. També podeu blocar les noves sol·licituds d'accedir al micròfon.
permissions-site-microphone-disable-label =
    .label = Bloca les noves sol·licituds d'accés al micròfon
permissions-site-microphone-disable-desc = Això impedirà que els llocs web que no estiguin en aquesta llista us sol·licitin permís per accedir al micròfon. Blocar l'accés al micròfon podria fer que algunes funcions dels llocs web no funcionin correctament.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Paràmetres - Permisos d'altaveu
permissions-site-speaker-desc = Els llocs web següents han sol·licitat accés per a seleccionar un dispositiu de sortida d'àudio. Podeu indicar quins llocs web tenen permís per a seleccionar un dispositiu de sortida d'àudio.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Excepcions de llocs web per a DNS sobre HTTPS
permissions-exceptions-manage-doh-desc = El { -brand-short-name } no utilitzarà el DNS segur en aquests llocs ni en llurs subdominis.
permissions-doh-entry-field = Introduïu el nom de domini del lloc web
    .accesskey = d
permissions-doh-add-exception =
    .label = Afegeix
    .accesskey = A
permissions-doh-col =
    .label = Domini
permissions-doh-remove =
    .label = Elimina
    .accesskey = m
permissions-doh-remove-all =
    .label = Elimina-ho tot
    .accesskey = t


