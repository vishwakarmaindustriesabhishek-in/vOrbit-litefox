# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.



translations-panel-disable-translations =
    .label = অনুবাদ সম্পূর্ণভাবে নিষ্ক্রিয় করো
translations-manage-enable =
    .label = পূর্ণপৃষ্ঠা অনুবাদ চালু করো
translations-manage-autopopup =
    .label = ব্রাউজারের নির্বাচিত ভাষার বাইরের ভাষা অনুবাদের জন্য জিজ্ঞেস করো
