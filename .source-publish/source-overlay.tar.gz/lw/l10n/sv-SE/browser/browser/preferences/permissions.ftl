# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = Undantag
permissions-close-key =
    .key = w
permissions-address = Webbplatsens adress
    .accesskey = d
permissions-block =
    .label = Blockera
    .accesskey = B
permissions-disable-etp =
    .label = Lägg till undantag
    .accesskey = u
permissions-session =
    .label = Tillåt för sessionen
    .accesskey = s
permissions-allow =
    .label = Tillåt
    .accesskey = å
permissions-add =
    .label = Lägg till
    .accesskey = L
permissions-button-off =
    .label = Stäng av
    .accesskey = a
permissions-button-off-temporarily =
    .label = Stäng av tillfälligt
    .accesskey = t
permissions-site-name =
    .label = Webbplats
permissions-status =
    .label = Status
permissions-remove =
    .label = Ta bort webbplats
    .accesskey = T
permissions-remove-all =
    .label = Ta bort alla webbplatser
    .accesskey = a
permissions-save-changes-2 =
    .buttonlabelaccept = Spara ändringar
    .buttonaccesskeyaccept = S
permission-dialog =
    .buttonlabelaccept = Spara ändringar
    .buttonaccesskeyaccept = S
permissions-autoplay-menu = Standard för alla webbplatser:
permissions-searchbox =
    .placeholder = Sök webbplats
permissions-capabilities-autoplay-allow =
    .label = Tillåt ljud och video
permissions-capabilities-autoplay-block =
    .label = Blockera ljud
permissions-capabilities-autoplay-blockall =
    .label = Blockera ljud och video
permissions-capabilities-allow =
    .label = Tillåt
permissions-capabilities-block =
    .label = Blockera
permissions-capabilities-prompt =
    .label = Fråga alltid
permissions-capabilities-listitem-allow =
    .value = Tillåt
permissions-capabilities-listitem-block =
    .value = Blockera
permissions-capabilities-listitem-allow-session =
    .value = Tillåten för session
permissions-capabilities-listitem-off =
    .value = Av
permissions-capabilities-listitem-off-temporarily =
    .value = Tillfälligt av

## Invalid Hostname Dialog

permissions-invalid-uri-title = Ogiltigt värdnamn
permissions-invalid-uri-label = Skriv in ett giltigt värdnamn

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Undantag för förbättrat spårningsskydd
permissions-exceptions-manage-etp-desc = Du kan ange vilka webbplatser som har Förbättrat spårningsskydd avstängt. Skriv in den exakta adressen till webbplatsen du vill hantera och klicka sedan på Lägg till undantag.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Undantag - Kakor och webbplatsdata
permissions-exceptions-cookie-desc = Du kan ange vilka webbplatser som alltid eller aldrig får använda kakor och webbplatsdata.  Skriv den exakta adressen till den webbplats du vill hantera och klicka sedan på Blockera, Tillåt för sessionen eller Tillåt.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Undantag - Rensa historik vid avstängning
permissions-exceptions-shutdown-clearing-desc = Du kan ange vilka webbplatser som ska behålla sina data när { -brand-short-name } rensar historiken vid stängning. Skriv in den exakta adressen till webbplatsen du vill hantera och klicka sedan på Tillåt.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Undantag - Endast HTTPS-läge
permissions-exceptions-https-only-desc2 = Du kan stänga av endast HTTPS-läge för specifika webbplatser. { -brand-short-name } kommer inte att försöka uppgradera anslutningen till säker HTTPS för dessa webbplatser.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Tillåtna webbplatser - Popup-fönster och omdirigeringar från tredje part
permissions-exceptions-popup-desc2 = Du kan ange vilka webbplatser som får öppna popup-fönster och omdirigeras av ramar från tredje part.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Undantag - Sparade lösenord
permissions-exceptions-saved-passwords-desc = { -brand-short-name } sparar inte lösenord för webbplatser som listas här.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Tillåtna webbplatser - Installation av tillägg
permissions-exceptions-addons-desc = Du kan ange vilka webbplatser som får installera tillägg. Skriv in adressen till platsen du vill godkänna och klicka på Tillåt.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Automatisk uppspelning
permissions-site-autoplay-desc = Du kan hantera de webbplatser som inte följer dina standardinställningar för automatisk uppspelning här.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Behörigheter för aviseringar
permissions-site-notification-desc = Följande webbplatser har begärt att skicka meddelanden. Du kan ange vilka webbplatser som får skicka aviseringar. Du kan också blockera nya förfrågningar om att tillåta meddelanden.
permissions-site-notification-disable-label =
    .label = Blockera nya förfrågningar om att tillåta meddelanden
permissions-site-notification-disable-desc = Detta kommer att förhindra att webbplatser som inte listas ovan från att begära tillstånd att skicka meddelanden. Blockering av meddelanden kan störa vissa webbplatsfunktioner.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Tillåt aviseringar från webbplatser när { -brand-short-name } är stängd
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Dina aviseringsinställningar för operativsystemet gäller också.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Behörigheter för plats
permissions-site-location-desc = Följande webbplatser har begärt att komma åt din position. Du kan ange vilka webbplatser som får komma åt din position. Du kan också blockera nya förfrågningar om att få tillgång till din position.
permissions-site-location-disable-label =
    .label = Blockera nya förfrågningar om att få tillgång till din position
permissions-site-location-disable-desc = Detta kommer att förhindra att webbplatser som inte listas ovan från att begära tillstånd att komma åt din position. Om du blockerar åtkomst till din position kan det störa vissa webbplatsfunktioner.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Rättigheter för virtuell verklighet
permissions-site-xr-desc = Följande webbplatser har begärt att få tillgång till dina enheter för virtuell verklighet. Du kan ange vilka webbplatser som får åtkomst till dina enheter för virtuell verklighet. Du kan också blockera nya förfrågningar som ber om åtkomst till dina enheter för virtuell verklighet.
permissions-site-xr-disable-label =
    .label = Blockera nya förfrågningar som ber om åtkomst till dina enheter för virtuell verklighet
permissions-site-xr-disable-desc = Detta förhindrar alla webbplatser som inte listas ovan från att begära tillåtelse att få tillgång till dina enheter för virtuell verklighet. Om du blockerar åtkomst till dina enheter för virtuell verklighet kan vissa webbplatsfunktioner sluta att fungera.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Inställningar - Blockerade webbplatser för applänkar
permissions-site-app-links-desc = Dessa webbplatser blockeras från att be om att öppna applänkar, som e-post (mailto:). Ta bort en webbplats för att tillåta den att fråga igen.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Behörigheter för kamera
permissions-site-camera-desc = Följande webbplatser har begärt att du ska komma åt din kamera. Du kan ange vilka webbplatser som får komma åt din kamera. Du kan också blockera nya förfrågningar om att komma åt din kamera.
permissions-site-camera-disable-label =
    .label = Blockera nya förfrågningar om att få tillgång till din kamera
permissions-site-camera-disable-desc = Detta kommer att förhindra att webbplatser som inte listas ovan från att begära tillstånd att komma åt din kamera. Att blockera åtkomst till din kamera kan störa vissa webbplatsfunktioner.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Inställningar - Enhetens appar och tjänster
permissions-site-localhost-desc = Dessa webbplatser har begärt åtkomst till appar och tjänster på den här enheten. Du kan välja att tillåta eller blockera webbplatser från att göra detta.
permissions-site-localhost-disable-label =
    .label = Blockera nya förfrågningar om åtkomst till appar och tjänster på den här enheten
permissions-site-localhost-disable-desc = Detta stoppar alla webbplatser som inte listas ovan från att begära åtkomst till appar och tjänster på den här enheten. Att göra detta kan störa vissa webbplatsfunktioner.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Inställningar - Lokala nätverksenheter
permissions-site-local-network-desc = Dessa webbplatser har begärt åtkomst till appar och tjänster på enheter anslutna till ditt Wi-Fi eller lokala nätverk. Du kan välja att tillåta eller blockera webbplatser från att göra detta.
permissions-site-local-network-disable-label =
    .label = Blockera nya förfrågningar om att komma åt appar och tjänster på enheter anslutna till ditt Wi-Fi eller lokala nätverk.
permissions-site-local-network-disable-desc = Detta stoppar alla webbplatser som inte listas ovan från att begära åtkomst till appar och tjänster på enheter anslutna till ditt Wi-Fi eller lokala nätverksenheter. Att göra detta kan störa vissa webbplatsfunktioner.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Inställningar - Behörigheter för mikrofon
permissions-site-microphone-desc = Följande webbplatser har begärt att du ska komma åt din mikrofon. Du kan ange vilka webbplatser som får komma åt din mikrofon. Du kan också blockera nya förfrågningar om att komma åt din mikrofon.
permissions-site-microphone-disable-label =
    .label = Blockera nya förfrågningar om att få tillgång till din mikrofon
permissions-site-microphone-disable-desc = Detta kommer att förhindra att webbplatser som inte listas ovan från att begära tillstånd att komma åt din mikrofon. Om du blockerar åtkomst till din mikrofon kan det störa vissa webbplatsfunktioner.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Inställningar - Högtalarbehörigheter
permissions-site-speaker-desc = Följande webbplatser har begärt att få välja en ljudutgångsenhet. Du kan ange vilka webbplatser som får välja en ljudutgångsenhet.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Webbplatsundantag för DNS över HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } kommer inte att använda säker DNS på dessa webbplatser och deras underdomäner.
permissions-doh-entry-field = Ange webbplatsens domännamn
    .accesskey = d
permissions-doh-add-exception =
    .label = Lägg till
    .accesskey = L
permissions-doh-col =
    .label = Domän
permissions-doh-remove =
    .label = Ta bort
    .accesskey = T
permissions-doh-remove-all =
    .label = Ta bort alla
    .accesskey = a


permissions-site-webgl-window2 =
    .title = Inställningar WebGL behörigheter
    .style = { permissions-window2.style }
permissions-site-webgl-desc = Följande webbplatser har begärt att få skapa ett WebGL kontext. Du kan ange vilka webbplatser som får skapa ett WebGL kontext. Du kan också blockera nya förfrågningar som ber om att få skapa ett WebGL kontext.
