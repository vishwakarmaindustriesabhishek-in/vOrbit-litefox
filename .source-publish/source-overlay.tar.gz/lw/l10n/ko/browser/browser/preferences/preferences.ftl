# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = 웹 사이트에 내 정보 판매 또는 공유 금지 요청
    .accesskey = s
non-technical-privacy-group =
    .label = 웹 사이트 개인 정보 보호 설정
do-not-track-removal3 =
    .message = “추적 안 함” 기능은 더 이상 지원하지 않습니다.
non-technical-privacy-heading =
    .label = 추가 보호
preferences-privacy-relay-available =
    .description = 받은편지함을 스팸으로부터 보호하기 위해 실제 이메일 주소를 숨깁니다.
    .label = { -relay-brand-name } 이메일 가리기 제안
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = 설정
category-nav-heading =
    .heading = 설정
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = 설정에서 찾기
    .style = width: 15.4em
managed-notice = 이 브라우저는 조직에서 관리하고 있습니다.
managed-notice-info-icon =
    .alt = 정보
managed-notice-nav =
    .label = 이 브라우저는 조직에서 관리하고 있습니다.
tls-key-logging-notice-nav =
    .label = 앱이나 서비스가 암호화된 트래픽을 볼 수 있습니다.
category-list =
    .aria-label = 카테고리
pane-general-title = 일반
pane-home-title = 홈
pane-home-startup-title2 = 홈 및 시작
    .title = 홈 및 시작
pane-search-title2 = 검색
    .title = 검색
pane-privacy-title3 = 개인 정보 및 보안
    .title = 개인 정보 및 보안
pane-privacy-section =
    .heading = 개인 정보 및 보안
pane-sync-title3 = Sync
pane-ai-controls-title2 = AI 제어
    .title = AI 제어
pane-about-firefox-title = { -brand-short-name } 정보
    .title = { pane-about-firefox-title }
pane-appearance-title = 모양
    .title = { pane-appearance-title }
pane-downloads-title2 = 다운로드
    .title = 다운로드
pane-downloads3 =
    .heading = 다운로드
pane-accessibility-title = 접근성
    .title = { pane-accessibility-title }
pane-languages-title2 = 언어
    .title = 언어
preferences-languages-header3 =
    .heading = 언어
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = 실험 기능을 사용해 보세요! 개발 및 진화 중이므로 { -brand-short-name } 작동 방식에 영향을 미칠 수 있습니다. 해당 기능 사용에 관한 데이터는 <a data-l10n-name="data-collection">기술 및 상호 작용 데이터</a>가 켜져 있는 경우에만 수집됩니다.
pane-experimental-reset =
    .label = 기본값으로 복원
    .accesskey = R
help-button-label2 = { -brand-short-name } 도움말
    .title = { -brand-short-name } 도움말
addons-button-label2 = 확장 기능 및 테마
    .title = 확장 기능 및 테마
focus-search =
    .key = f
close-button =
    .aria-label = 닫기
do-not-track-removal2 =
    .label = "추적 안 함" 신호를 더 이상 지원하지 않음
applications-setting-new-file-types =
    .label = { -brand-short-name }로 다른 파일 형식은 어떤 작업을 하시겠습니까?

## Browser Restart Dialog

feature-enable-requires-restart = 이 기능을 사용하려면 { -brand-short-name }를 반드시 다시 시작해야 합니다.
feature-disable-requires-restart = 이 기능을 끄려면 { -brand-short-name }를 반드시 다시 시작해야 합니다.
should-restart-title = { -brand-short-name } 다시 시작
should-restart-ok = 지금 { -brand-short-name } 다시 시작
cancel-no-restart-button = 취소
restart-later = 나중에 다시 시작

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> 확장 기능이 이 설정을 제어합니다.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> 확장 기능이 이 설정을 제어합니다.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong>에 컨테이너 탭 필요.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> 확장 기능이 이 설정을 제어합니다.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> 확장 기능은 { -brand-short-name }가 인터넷에 연결하는 방법을 제어합니다.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = 확장 기능을 사용하려면 <img data-l10n-name="menu-icon"/> 메뉴에서 <img data-l10n-name="addons-icon"/> 부가 기능으로 이동하세요.
extension-controlled-enable-2 = 이 확장 기능을 다시 활성화하려면 <a data-l10n-name="addons-link">확장 기능 및 테마</a>를 방문하세요.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } 확장 기능이 일부 홈페이지 설정을 제어합니다.

## Preferences UI Search Results

search-results-header = 검색 결과
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = 죄송합니다! 설정에서 “<span data-l10n-name="query"></span>”에 대한 결과가 없습니다.
search-results-help-link = 도움이 필요하세요? <a data-l10n-name="url">{ -brand-short-name } 지원</a>에 방문하세요.

## General Section

always-check-default =
    .label = { -brand-short-name }가 기본 브라우저인지 항상 확인
    .accesskey = w
startup-restore-windows-and-tabs =
    .label = 이전 창 및 탭 열기
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = “사용자 프로필 선택” 창에서 “{ profile-manager-use-selected.label }”에 체크하여 이 설정을 활성화하세요.
windows-launch-on-login =
    .label = 컴퓨터가 시작될 때 자동으로 { -brand-short-name } 열기
    .accesskey = O
windows-launch-on-login-disabled = 이 설정은 Windows에서 비활성화되었습니다. 변경하려면, 시스템 설정에서 <a data-l10n-name="startup-link">시작 프로그램</a>을 방문하세요.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = 새 탭도 열기
    .accesskey = n
disable-extension =
    .label = 확장 기능 사용 안 함
preferences-data-migration-group =
    .description = 다른 브라우저에서 북마크, 비밀번호, 기록, 확장 기능 및 자동 채우기 데이터를 가져오세요.
    .label = 브라우저 데이터 가져오기
preferences-data-migration-button =
    .label = 데이터 가져오기
    .accesskey = m
preferences-profiles-group-header =
    .heading = 프로필
preferences-profiles-subpane-description =
    .description = 각 프로필은 기록, 비밀번호 등을 포함한 별도의 탐색 데이터와 설정을 가집니다.
preferences-profiles-section-header =
    .description = 각 프로필에는 기록, 비밀번호 등을 포함한 별도의 탐색 데이터와 설정이 있습니다.
    .label = 프로필
preferences-manage-profiles-button =
    .label = 프로필 관리
preferences-profiles-settings-button =
    .label = 설정
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = 새 프로필은 설정, 부가 기능, 기록, 북마크 및 비밀번호와 같은 저장된 데이터를 복사하지만 계정이나 동기화 정보는 복사하지 않습니다.
    .label = 기존 프로필 복사
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = 복사할 프로필
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = 프로필 선택
preferences-copy-profile-button = 복사
tabs-browsing-section =
    .heading = 탭 및 탐색
pane-tabs-browsing-title2 = 탭 및 탐색
    .title = 탭 및 탐색
tabs-group-header2 =
    .label = 탭
tabs-opening-heading =
    .label = 열기
tabs-interaction-heading =
    .label = 상호작용
tabs-containers-heading =
    .label = 컨테이너
tabs-closing-heading =
    .label = 닫기
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab 단축키로 최근 사용한 순서대로 탭 순환
    .accesskey = T
open-new-link-as-tabs =
    .label = 링크를 새 창 대신 새 탭에서 열기
    .accesskey = w
open-external-link-next-to-active-tab =
    .label = 외부 앱의 링크를 활성 탭 옆에 열기
ask-on-close-multiple-tabs =
    .label = 여러 탭을 닫기 전에 묻기
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = { $quitKey } 단축키로 종료하기 전에 묻기
    .accesskey = b
warn-on-open-many-tabs =
    .label = 여러개의 탭을 열어서 { -brand-short-name }가 느려질 수 있으면 알려주기
    .accesskey = d
switch-to-new-tabs-2 =
    .label = 링크나 미디어를 새 탭에서 열면 해당 탭으로 즉시 전환
    .accesskey = h
show-tabs-in-taskbar =
    .label = Windows 작업 표시줄에 탭 미리 보기 표시
    .accesskey = k
browser-containers-enabled-2 =
    .label = 컨테이너 탭 사용
    .accesskey = n
browser-containers-learn-more = 더 알아보기
browser-containers-settings-2 =
    .label = 설정 관리
    .accesskey = i
containers-disable-alert-title = 모든 컨테이너 탭을 닫으시겠습니까?
startup-group =
    .label = 시작 페이지

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc = 지금 컨테이너 탭을 비활성화하면 { $tabCount }개의 컨테이너 탭이 닫히게 됩니다. 컨테이너 탭을 비활성화하시겠습니까?
containers-disable-alert-ok-button = 컨테이너 탭 { $tabCount }개 닫기

##

containers-disable-alert-cancel-button = 활성화 하기
containers-remove-alert-title = 이 컨테이너를 삭제하시겠습니까?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg = 이 컨테이너를 삭제하면 { $count } 컨테이너 탭이 닫힙니다. 이 컨테이너를 정말로 삭제하시겠습니까?
containers-remove-ok-button = 이 컨테이너 삭제
containers-remove-cancel-button = 이 컨테이너 삭제하지 않음
settings-tabs-show-image-in-preview =
    .label = 탭 위로 마우스를 올리면 이미지 미리 보기 표시
    .accessKey = h
settings-tabs-drag-to-create-tab-groups =
    .label = 탭을 서로 끌어다 놓아 탭 그룹 만들기
browser-layout-header2 =
    .label = 브라우저 레이아웃
browser-layout-horizontal-tabs2 =
    .description = 상단에 탭 표시
    .label = 가로 탭
    .title = 상단에 탭 표시
browser-layout-vertical-tabs2 =
    .description = 사이드바의 측면에 표시
    .label = 세로 탭
    .title = 사이드바의 측면에 표시
browser-layout-show-sidebar2 =
    .description = 주 화면을 떠나지 않고 북마크, 휴대폰의 탭, AI 챗봇 등에 빠르게 접근하세요.
    .label = 사이드바 표시
page-navigation-group =
    .label = 페이지 탐색

## General Section - Language & Appearance

language-and-appearance-header = 언어 및 모양
appearance-group2 =
    .description = 일부 웹사이트는 사용자의 선호도에 맞춰 색상을 변경합니다. 원하는 색상 테마를 선택하세요.
    .label = 웹 사이트 모양
preferences-web-appearance-choice-auto3 =
    .label = 시스템
    .title = 시스템 설정과 { -brand-short-name } 테마에 따라 웹 사이트 배경과 콘텐츠를 자동으로 변경합니다.
preferences-web-appearance-choice-light2 =
    .label = 밝게
    .title = 웹 사이트 배경 및 콘텐츠에 밝은 화면 배색을 사용합니다.
preferences-web-appearance-choice-dark2 =
    .label = 어둡게
    .title = 웹 사이트 배경 및 콘텐츠에 어두운 화면 배색을 사용합니다.
web-appearance-group =
    .aria-label = 웹 사이트 모양
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = 대비 제어 설정이 웹 사이트 화면 배색보다 우선합니다.
preferences-web-appearance-link =
    .label = 확장 기능 및 테마에서 { -brand-short-name } 테마 관리
preferences-contrast-control-group =
    .description = 웹 사이트는 다양한 전경색과 배경색을 사용합니다. 일관된 대비를 위해 웹 사이트 전체에 동일한 색상을 사용할 수 있습니다.
    .label = 웹 사이트 대비
preferences-contrast-control-radio-group =
    .label = 색상 재정의
preferences-contrast-control-use-platform-settings =
    .label = 자동 (시스템 설정 사용)
    .accesskey = A
preferences-contrast-control-off =
    .label = 끄기
    .accesskey = O
preferences-contrast-control-custom =
    .label = 사용자 지정
    .accesskey = C
preferences-colors-manage-button2 =
    .label = 색상 관리
    .accesskey = C
preferences-colors-manage-button =
    .label = 색상 관리…
    .accesskey = C
preferences-fonts-header2 =
    .label = 글꼴
preferences-default-zoom-label =
    .label = 기본 확대/축소
    .accesskey = z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = 글자 크기만 조정
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = "글자 크기만 조정" 옵션이 켜져 있고 기본 확대/축소가 100%가 아닌 경우, 일부 사이트에서는 콘텐츠가 제대로 표시되지 않을 수 있습니다.
language-header = 언어
choose-language-description = 웹 페이지를 표시할 기본 언어 선택
website-language-heading =
    .description = 일부 웹 페이지는 여러 언어로 표시됩니다. 선호하는 순서대로 언어를 선택하세요.
    .label = 웹 사이트 언어
website-preferred-language =
    .label = 선호 언어
website-language-list =
    .aria-label = 선호 언어
website-add-language =
    .label = 언어 추가
website-add-language-button =
    .aria-label = 선택한 언어 추가
    .title = 선택한 언어 추가
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = { $locale } 제거
    .title = { $locale } 제거
choose-button =
    .label = 선택…
    .accesskey = o
choose-browser-language-description = { -brand-short-name }가 메뉴, 메시지 및 알림을 표시하는 데 사용할 언어를 선택하세요.
manage-browser-languages-button =
    .label = 대체 설정…
    .accesskey = I
confirm-browser-language-change-description = 변경 내용 적용을 위해 { -brand-short-name } 다시 시작
confirm-browser-language-change-button = 적용하고 다시 시작
browser-language-heading =
    .description = { -brand-short-name }에서 메뉴, 메시지 및 알림을 표시하는 데 사용할 언어를 선택하세요.
    .label = 브라우저 언어
browser-language-preferred-label =
    .label = 선호 언어
browser-language-fallback-label =
    .description = 선호하는 언어의 현지화가 완료되지 않은 경우에 사용됩니다.
    .label = 대체 언어
browser-language-install-error =
    .message = { -brand-short-name }가 지금 언어를 업데이트할 수 없습니다. 인터넷에 연결되어 있는지 확인하거나 다시 시도하세요.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = 예외…
    .accesskey = x
settings-translations-header =
    .aria-label = 번역
    .description = 페이지 또는 선택한 텍스트를 번역합니다. 개인 정보를 보호하기 위해 번역은 기기에 유지됩니다.
    .label = 번역
settings-translations-offer-to-translate-label =
    .label = 전체 페이지 번역 제공
settings-translations-more-settings-button =
    .description = 언어, 웹 사이트, 오프라인 번역에 대한 설정을 하세요.
    .label = 추가 번역 설정
settings-translations-subpage-header =
    .heading = 추가 번역 설정
settings-translations-subpage-speed-up-translation-header =
    .description = 더 빠른 번역과 오프라인 번역을 위해 전체 언어를 다운로드하세요.
    .label = 번역 속도 높이기
settings-translations-subpage-automatic-translation-header =
    .label = 자동 번역
settings-translations-subpage-always-translate-header =
    .label = 이 언어는 항상 번역
settings-translations-subpage-never-translate-header =
    .label = 이 언어는 항상 번역 안 함
settings-translations-subpage-never-translate-sites-header =
    .label = 이 사이트는 항상 번역 안 함
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = 사이트를 추가하려면, <img data-l10n-name="translations-icon"/> 번역 패널을 열고, <img data-l10n-name="settings-icon"/> 번역 설정을 선택한 다음, "이 사이트는 항상 번역 안 함"을 선택하세요.
settings-translations-subpage-language-select-option =
    .label = 언어 추가
settings-translations-subpage-language-add-button =
    .aria-label = 언어 추가
    .title = 언어 추가
settings-translations-subpage-download-languages-header =
    .label = 언어 다운로드
settings-translations-subpage-download-languages-select-option =
    .label = 언어 선택
settings-translations-subpage-download-languages-button =
    .aria-label = 언어 다운로드
    .title = 언어 다운로드
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size }MB)
    .label = { $language } ({ $size }MB)
settings-translations-subpage-no-languages-downloaded =
    .label = 다운로드한 언어 없음
settings-translations-subpage-no-languages-added =
    .label = 추가된 언어 없음
settings-translations-subpage-download-progress = 다운로드 진행 중…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = { $language } ({ $size }MB)를 다운로드할 수 없음
settings-translations-subpage-download-retry-button =
    .label = 다시 시도
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = { $language } ({ $size }MB)를 삭제하시겠습니까?
settings-translations-subpage-download-delete-button =
    .label = 삭제
settings-translations-subpage-download-cancel-button =
    .label = 취소
settings-translations-subpage-no-sites-added =
    .label = 추가된 사이트 없음
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = 날짜, 시간, 숫자 및 측정 단위에 운영 체제의 “{ $localeName }” 형식 사용
settings-spellcheck-header =
    .label = 맞춤법 검사
check-user-spelling =
    .label = 입력할 때 맞춤법 검사
    .accesskey = t
spellcheck-download-dictionaries =
    .label = 사전 다운로드
spellcheck-promo =
    .heading = 맞춤법 검사 사용법
    .message = 맞춤법 검사를 켜거나 끄거나 언어를 변경하려면 텍스트 필드를 마우스 오른쪽 버튼으로 누르세요. 모든 필드가 맞춤법 검사를 지원하는 것은 아닙니다.

## Downloads - Files and applications

files-and-applications-title = 파일 및 애플리케이션
download-save-files-header =
    .label = 저장 위치
download-save-where-3 =
    .aria-label = 저장 위치
download-always-ask-where2 =
    .label = 다운로드하기 전에 파일 저장 위치 묻기
    .accesskey = A
download-private-browsing-delete2 =
    .label = 닫을 때 사생활 보호 창 다운로드를 삭제
    .accesskey = D
applications-header = 애플리케이션
applications-description = { -brand-short-name }가 웹에서 다운로드한 파일이나 탐색하는 동안에 사용하는 애플리케이션을 처리하는 방법을 선택하세요.
applications-setting2 =
    .description = { -brand-short-name }가 다운로드한 파일과 콘텐츠를 처리하는 방식을 선택하세요.
    .label = 파일 및 애플리케이션
applications-filter =
    .placeholder = 파일 형식 또는 애플리케이션 검색
applications-type-column =
    .label = 콘텐츠 유형
    .accesskey = T
applications-type-heading = 콘텐츠 유형
applications-action-column =
    .label = 동작
    .accesskey = A
applications-action-heading = 동작
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } 파일
applications-action-save =
    .label = 파일 저장
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = { $app-name } 사용
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = { $app-name } 사용 (기본값)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] macOS 기본 애플리케이션 사용
            [windows] Windows 기본 애플리케이션 사용
           *[other] 시스템 기본 애플리케이션 사용
        }
applications-use-other =
    .label = 다른 애플리케이션 사용…
applications-select-helper = 도우미 애플리케이션 선택
applications-manage-app =
    .label = 애플리케이션 상세 정보…
applications-always-ask =
    .label = 항상 묻기
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = { -brand-short-name }에서 열기

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = { -brand-short-name }로 다른 파일 형식은 어떤 작업을 하시겠습니까?
applications-save-for-new-types =
    .label = 파일 저장
    .accesskey = S
applications-save-for-new-types2 =
    .label = 자동으로 파일 저장
    .accesskey = S
applications-ask-before-handling =
    .label = 파일을 열지 저장할지 묻기
    .accesskey = A
applications-ask-before-handling2 =
    .label = 파일을 열지 저장할지 묻기
    .accesskey = A
drm-group =
    .label = 디지털 권한 관리 (DRM) 콘텐츠
play-drm-content =
    .label = DRM 제어 콘텐츠 재생
    .accesskey = P
play-drm-content-learn-more = 더 알아보기
# Variables:
# $version (string) - Firefox version
update-application-version = { $version } 버전 <a data-l10n-name="learn-more">새 기능</a>
update-history-2 =
    .label = 업데이트 기록 보기
    .accesskey = p
update-application-installation =
    .label = 설치
update-application-radio-group =
    .aria-label = 설치
update-application-auto-2 =
    .label = 자동으로 업데이트 설치 (권장)
    .accesskey = A
update-application-check-choose-2 =
    .label = 업데이트를 확인하지만, 설치할 때를 선택
    .accesskey = C
update-application-background-enabled =
    .label = { -brand-short-name }가 실행 중이 아닐 때
    .accesskey = W
update-application-warning-cross-user-setting-2 =
    .message = 이 설정은 이 { -brand-short-name } 설치를 사용하는 모든 Windows 계정 및 { -brand-short-name } 프로필에 적용됩니다.
update-application-suppress-prompts-2 =
    .label = 업데이트 알림 줄이기
    .accesskey = n
update-setting-write-failure-title2 = 업데이트 설정 저장 중 오류 발생
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    오류가 발생하여 { -brand-short-name }가 이 변경 내용을 저장하지 않았습니다. 이 업데이트 설정을 변경하려면 아래 파일에 쓰기 권한이 필요합니다. 사용자나 시스템 관리자가 사용자 그룹에 이 파일에 대한 모든 권한을 부여하여 오류를 해결할 수 있습니다.
    
    파일에 쓸 수 없음: { $path }
update-in-progress-title = 업데이트 진행 중
update-in-progress-message = { -brand-short-name }가 이 업데이트를 계속하길 원하십니까?
update-in-progress-ok-button = 버리기(&D)
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = 계속(&C)

## About Firefox

about-firefox-header =
    .heading = { -brand-short-name } 정보

## Firefox updates

update-application-heading =
    .description = 업데이트를 통해 { -brand-short-name }의 속도, 안정성 및 보안이 향상됩니다.
    .label = { -brand-short-name } 업데이트
update-application-suppress-prompts-heading =
    .label = 알림
update-application-updates-managed-by-os =
    .message = 운영 체제에서 업데이트를 관리합니다.

## Firefox support

support-application-heading =
    .description = 문제를 해결하거나 커뮤니티와 아이디어를 공유하세요.
    .label = { -brand-short-name } 지원
support-get-help =
    .label = 도움 받기
support-share-ideas =
    .label = 아이디어 및 의견 공유

## Firefox newsletter

newsletter-settings-heading =
    .description = { -brand-product-name } 경험을 가장 잘 할 수 있도록 방법, 조언, 뉴스를 받아보세요.
    .label = { -brand-product-name } 뉴스레터
newsletter-sign-up-link =
    .label = 가입

## General Section - Performance

performance-settings-learn-more = 더 알아보기
performance-allow-hw-accel =
    .label = 하드웨어 가속이 가능하면 사용
    .accesskey = r
performance-limit-content-process-option = 콘텐츠 프로세스 제한
    .accesskey = L
performance-limit-content-process-enabled-desc = 추가 콘텐츠 프로세스는 여러 탭을 사용할 때 성능을 향상시킬 수 있지만 더 많은 메모리를 사용합니다.
performance-limit-content-process-blocked-desc = 콘텐츠 프로세스 갯수 변경은 다중 프로세스 { -brand-short-name }에서만 가능합니다. <a data-l10n-name="learn-more">다중 프로세스가 활성화되었는지 확인하는 방법</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (기본값)
performance-group =
    .label = 성능
performance-use-recommended-settings-checkbox-2 =
    .description = 이 설정은 사용자의 하드웨어 및 운영 체제에 맞게 조정됩니다.
    .label = 권장 성능 설정을 사용
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = 자동 스크롤 사용
    .accesskey = a
keyboard-and-scrolling-group =
    .label = 키보드 탐색 및 스크롤
motion-and-link-group =
    .label = 동작 및 링크 스타일
browsing-use-smooth-scrolling =
    .label = 부드러운 스크롤 사용
    .accesskey = m
browsing-gtk-use-non-overlay-scrollbars =
    .label = 스크롤 막대 항상 표시
    .accesskey = o
browsing-always-underline-links =
    .label = 링크에 항상 밑줄 표시
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = 필요한 경우 터치 키보드 표시
    .accesskey = c
browsing-use-cursor-navigation =
    .label = 커서 키를 항상 페이지 내에서 사용
    .accesskey = c
browsing-use-full-keyboard-navigation =
    .label = Tab 키를 사용하여 양식 컨트롤과 링크 간에 포커스를 이동
    .accesskey = t
browsing-search-on-start-typing =
    .label = 입력을 시작할 때 텍스트 찾기
    .accesskey = x
settings-keyboard-shortcuts-group =
    .description = { -brand-short-name }의 탐색 및 상호작용 방식을 제어합니다.
    .label = 키보드 단축키
settings-keyboard-shortcuts-customkeys-link =
    .label = 키보드 단축키 사용자 지정
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = 검색의 주소 표시줄 설정 사용자 지정
settings-media-group =
    .label = 미디어
browsing-picture-in-picture-toggle-enabled-2 =
    .label = 화면 속 화면 사용
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = 탭을 전환할 때 화면 속 화면에서 동영상을 계속 재생
    .accesskey = s
browsing-media-control =
    .label = 키보드, 헤드셋 또는 가상 인터페이스를 통해 미디어 제어
    .accesskey = v
recommendations-group =
    .label = 추천
browsing-cfr-recommendations =
    .label = 탐색할 때 확장 기능 추천
    .accesskey = R
browsing-cfr-features =
    .label = 탐색할 때 기능 추천
    .accesskey = f
browsing-group =
    .label = 탐색
preferences-accessibility-header =
    .heading = 접근성
preferences-default-zoom-select =
    .aria-label = 기본 확대/축소
preferences-fonts-family =
    .label = 글꼴 집합
    .accesskey = D
preferences-fonts-size =
    .label = 글꼴 크기
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = 고급 설정
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .description = { -brand-short-name }가 인터넷에 연결되는 방법을 구성합니다.
    .label = 프록시 설정
network-proxy-connection-settings2 =
    .description = 이 설정을 변경하면 연결 문제가 발생할 수 있음
    .label = 프록시 구성
    .accesskey = p

## Home Section

home-new-windows-tabs-header = 새 창과 탭
home-new-windows-tabs-description2 = 홈페이지, 새 창 및 새 탭을 열 때 표시되는 것을 선택하세요.
home-section =
    .heading = 홈 및 시작

## Home Section - Default Browser

home-default-browser-title =
    .label = 기본 브라우저
is-default-browser-2 =
    .message = { -brand-short-name }가 기본 브라우저입니다. 좋은 선택입니다.
is-not-default-browser-2 =
    .message = 잠시만요! { -brand-short-name }가 기본 브라우저가 아닙니다.
set-as-my-default-browser-2 =
    .label = 기본 브라우저로
    .accesskey = D

## Custom Homepage subpage

home-homepage-mode-label = 홈페이지와 새 창
home-newtabs-mode-label = 새 탭
home-restore-defaults =
    .label = 기본값으로 복원
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (기본값)
home-mode-choice-custom =
    .label = 사용자 지정 URL…
home-mode-choice-blank =
    .label = 빈 페이지
home-homepage-custom-url =
    .placeholder = URL 붙여넣기…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = 확장 기능 관리
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] 현재 페이지
           *[other] 현재 탭
        }
    .accesskey = C
choose-bookmark =
    .label = 북마크 사용…
    .accesskey = B
home-homepage-title =
    .label = 홈페이지
home-homepage-new-windows =
    .label = 새 창
home-homepage-new-tabs =
    .label = 새 탭
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = 특정 사이트 선택
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = 웹 사이트 주소
home-custom-homepage-list =
    .aria-label = 웹 사이트 주소
home-custom-homepage-address =
    .placeholder = 주소 입력
home-custom-homepage-address-button =
    .label = 주소 추가
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = 아직 추가된 웹 사이트가 없습니다.
home-custom-homepage-delete-address-button =
    .aria-label = 주소 삭제
    .title = 주소 삭제
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = 대체:
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = 현재 열려있는 페이지
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = 북마크…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = 확장 기능 ({ $extension })
home-custom-homepage-header = 사용자 지정 홈페이지
home-custom-homepage-subpage =
    .heading = 사용자 지정 홈페이지

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name } 콘텐츠
home-prefs-content-description2 = { -firefox-home-brand-name } 화면에서 원하는 콘텐츠를 선택하세요.
home-prefs-search-header =
    .label = 웹 검색
home-prefs-shortcuts-header =
    .label = 바로 가기
home-prefs-shortcuts-description = 저장하거나 방문한 사이트
home-prefs-shortcuts-by-option-sponsored =
    .label = 스폰서 바로 가기
home-prefs-recommended-by-header-generic =
    .label = 추천 이야기
home-prefs-recommended-by-description-generic = { -brand-product-name } 제품군이 선별한 뛰어난 콘텐츠
home-prefs-stories-header =
    .label = 이야기
home-prefs-stories-description = 활동에 기반한 개인화된 이야기

##

home-prefs-recommended-by-learn-more = 사용 방법
home-prefs-recommended-by-option-sponsored-stories =
    .label = 스폰서 소식
home-prefs-highlights-option-visited-pages =
    .label = 방문한 페이지
home-prefs-highlights-options-bookmarks =
    .label = 북마크
home-prefs-highlights-option-most-recent-download =
    .label = 가장 최근 다운로드
home-prefs-recent-activity-header =
    .label = 최근 활동
home-prefs-recent-activity-description = 최근 사이트 및 콘텐츠 선택
home-prefs-weather-header =
    .label = 날씨
home-prefs-weather-description = 오늘의 일기예보를 한눈에
home-prefs-weather-learn-more-link = 더 알아보기
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = { -brand-product-name } 지원
home-prefs-mission-message = 스폰서는 더 나은 웹을 만들려는 저희를 지원합니다
home-prefs-mission-message-learn-more-link = 방법 알아보기
home-prefs-manage-topics-link = 주제 관리
home-prefs-choose-wallpaper-link = 배경 화면 선택
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label = { $num } 행

## Search Section

search-show-suggestions-option =
    .label = 검색 제안 표시
    .accesskey = S
search-show-suggestions-url-bar-option =
    .label = 주소 표시줄 결과에 검색 제안 표시
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = 주소 표시줄 결과에서 방문 기록 보다 검색 제안을 먼저 표시
search-show-suggestions-private-windows-2 =
    .label = 사생활 보호 창에서 검색 제안
search-suggestions-cant-show-2 =
    .message = 방문 기록을 저장하지 않도록 { -brand-short-name }를 설정했기 때문에 검색 제안이 주소 표시 줄 결과에 표시되지 않습니다.
addressbar-header-1 =
    .description = 주소 표시줄에 표시할 제안 선택
    .label = 주소 표시줄
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = 주소 표시줄에 { -brand-short-name } 및 파트너사의 제안이 표시됩니다.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = 결과 페이지의 주소 표시줄에 검색어 표시
search-separate-default-engine-2 =
    .label = 사생활 보호 창에서 다른 기본 검색 엔진 사용
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = 사생활 보호 창의 기본 검색 엔진
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = 주소 표시줄 탐색
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Tab 키로 포커스 이동 시 결과 메뉴 건너뛰기
search-suggestions-header-2 =
    .label = 검색 엔진 제안
search-one-click-header2 = 검색 바로 가기
search-one-click-desc = 키워드 입력을 시작했을 때 주소 표시줄과 검색 표시줄 아래에 나타날 대체 검색 엔진을 선택하세요.
search-one-click-header-3 =
    .description = 주소 표시줄에 표시할 검색 엔진과 바로 가기를 선택하세요.
    .label = 추가 검색 엔진
search-engine-list =
    .aria-label = 검색 엔진 및 바로 가기
update-search-engine-success =
    .message = 검색 엔진 업데이트 완료
search-edit-engine-2 =
    .title = 검색 엔진 편집
search-delete-engine =
    .title = 검색 엔진 삭제
search-enable-engine =
    .title = 검색 엔진 사용
search-outlink-to-extensions-page =
    .title = 확장 기능 및 테마에서 관리
search-choose-engine-column =
    .label = 검색 엔진
search-choose-keyword-column =
    .label = 키워드
search-restore-default =
    .label = 기본 검색 엔진 복원
    .accesskey = D
search-remove-engine =
    .label = 삭제
    .accesskey = R
search-add-engine =
    .label = 추가
    .accesskey = A
search-add-engine-2 =
    .label = 검색 엔진 추가
    .accesskey = A
search-edit-engine =
    .label = 편집
    .accesskey = E
search-find-more-link = 검색 엔진 더 찾기
search-filtering-for-add-engine = 엔진 추가
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = 키워드 복사
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = "{ $name }"에서 이미 사용 중인 키워드를 선택했습니다. 다른 것을 선택하세요.
search-keyword-warning-bookmark = 북마크에서 이미 사용 중인 키워드를 선택했습니다. 다른 것을 선택하세요.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = 이미 “{ $name }” 이름의 검색 엔진이 있습니다. 다른 이름을 선택해 주세요.
remove-engine-confirmation = 이 검색 엔진을 제거하시겠습니까?
remove-engine-remove = 제거
remove-addon-engine-alert = 이 검색 엔진을 제거하려면 관련 부가 기능도 삭제하세요.
search-engine-group =
    .label = 기본 검색 엔진
search-default-engine =
    .aria-label = 기본 검색 엔진
# Header for the search section ("search" is a noun).
search-section =
    .heading = 검색

## Containers Section

containers-section-header2 =
    .heading = 컨테이너 설정
containers-card-header2 =
    .description = 쿠키를 컨테이너별로 분리하여 동일한 사이트에서 여러 계정을 사용할 수 있도록 하고 사이트 간 추적을 제한하세요.
    .label = 컨테이너
containers-add-button2 =
    .label = 새 컨테이너 추가
    .accesskey = A
containers-list =
    .aria-label = 컨테이너
containers-new-tab-check3 =
    .label = 새 탭마다 컨테이너 선택
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = 외부 앱에서 연 링크에 컨테이너 사용 안 함
    .accesskey = D
containers-new-tab-check2 =
    .description = 새 탭 열기 버튼을 누를 때마다 컨테이너 메뉴가 열립니다.
    .label = 새 탭마다 컨테이너 선택
    .accesskey = S
containers-settings-button2 =
    .title = 설정
containers-remove-button3 =
    .title = 삭제
containers-sites-card-header =
    .description = 사이트의 컨테이너를 선택하면 { -brand-short-name }에서 해당 사이트를 열 때마다 이 컨테이너를 항상 사용합니다.
    .label = 사이트별 컨테이너
containers-sites-add-button =
    .label = 웹 사이트 추가
    .accesskey = w
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = { $site }의 컨테이너
containers-site-remove-button =
    .title = 삭제
containers-remove-button2 =
    .title = 제거

## Account and sync

sync-group-label =
    .label = Sync
account-group-label2 =
    .label = 계정
account-disabled-group =
    .description = 계정 설정을 사용할 수 없습니다.
    .label = 계정
account-placeholder2 =
    .description = 로그인하여 { -brand-short-name }를 사용하는 모든 곳에서 데이터를 안전하게 보호하고, 암호화하며, 언제 어디서나 즉시 사용할 수 있도록 하세요.
    .label = 로그인되어 있지 않음
account-sync-section =
    .heading = 계정 및 동기화
pane-account-sync-title2 = 계정 및 동기화
    .title = 계정 및 동기화

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = 웹과 함께 하세요.
sync-signedout-description2 = 북마크, 기록, 탭, 비밀번호, 부가 기능, 설정을 모든 기기에 걸쳐 동기화하세요.
sync-signedout-account-signin3 =
    .label = Sync에 로그인…
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = 계정에 로그인하여 동기화를 시작하세요
    .accesskey = i
sync-signedout-account-short =
    .label = 로그인
    .accesskey = i
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = 모바일 기기와 동기화하려면 <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> 또는 <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a>용 Firefox를 다운로드하세요.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = 프로필 사진 변경
    .tooltiptext = 프로필 사진 변경
sync-profile-picture-account-problem =
    .alt = 계정 프로필 사진
fxa-login-rejected-warning =
    .alt = 경고
sync-sign-out =
    .label = 로그아웃…
    .accesskey = g
sync-sign-out2 =
    .label = 로그아웃
    .accesskey = g
sync-manage-account = 계정 관리
    .accesskey = o
sync-manage-account2 =
    .label = 계정 관리
    .accesskey = o

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } 은 아직 인증되지 않았습니다.
sync-signedin-unverified2 =
    .description = 계정을 확인하고 공식화하려면 받은 편지함을 확인하세요.
    .label = { $email } 이메일이 아직 확인되지 않음
sync-signedin-login-failure = { $email }으로 다시 연결하려면 로그인하세요
sync-signedin-login-failure2 =
    .description = 다시 연결하고 데이터 동기화를 시작하려면 다시 로그인하세요.
    .label = { $email }에서 로그아웃됨
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = 계정 확인
    .accesskey = V
sync-remove-account =
    .label = 계정 삭제
    .accesskey = R
sync-sign-in =
    .label = 로그인
    .accesskey = g

## Sync section - enabling or disabling sync.

prefs-syncing-on = 동기화: 켜짐
prefs-syncing-on-2 =
    .label = 동기화 켜짐
prefs-syncing-off = 동기화: 꺼짐
prefs-syncing-off-2 =
    .description = 동기화를 켜면 북마크, 비밀번호, 기록 등을 모든 기기에서 사용할 수 있습니다.
    .label = 동기화 꺼짐
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = 이 기기에서 북마크, 비밀번호, 기록 등을 가져오려면 동기화를 켜세요.
    .label = 동기화 꺼짐
prefs-sync-turn-on-syncing =
    .label = 동기화 켜기…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = 동기화 켜기
    .accesskey = s
prefs-sync-offer-setup-label2 = 북마크, 기록, 탭, 비밀번호, 부가 기능, 설정을 모든 기기에 걸쳐 동기화하세요.
prefs-sync-now-button =
    .label = 지금 동기화
    .accesskey = N
prefs-sync-now-button-2 =
    .label = 지금 동기화
    .accesskey = N
prefs-syncing-button =
    .label = 동기화중…
prefs-syncing-button-2 =
    .label = 동기화중…
    .title = 지금 동기화
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = 동기화 선택이 이제 이 기기에만 적용됩니다.

## The list of things currently syncing.

sync-syncing-across-devices-heading = 연결된 모든 기기에서 다음 항목을 동기화하고 있습니다:
sync-syncing-across-devices-heading-2 = 여러 기기에서 데이터 동기화됨
sync-syncing-across-devices-heading-3 = 이 기기의 데이터 동기화 항목
sync-syncing-across-devices-empty-state2 =
    .description = 아직 아무것도 동기화하고 있지 않습니다. 지금 동기화를 시작하여 모든 기기에서 데이터를 확인해 보세요.
    .label = 동기화된 데이터 관리
sync-syncing-across-devices-empty-state3 =
    .description = 아직 아무것도 동기화하고 있지 않습니다. 이 기기에서 동기화할 항목을 선택하세요.
    .label = 동기화된 데이터 관리
sync-currently-syncing-bookmarks = 북마크
sync-currently-syncing-history = 기록
sync-currently-syncing-tabs = 열린 탭
sync-currently-syncing-passwords = 비밀번호
sync-currently-syncing-addresses = 주소
sync-currently-syncing-payment-methods = 결제 수단
sync-currently-syncing-addons = 부가 기능
sync-currently-syncing-settings = 설정
sync-manage-options =
    .label = 동기화 관리…
    .accesskey = M
sync-manage-options-2 =
    .label = 동기화된 데이터 관리
    .accesskey = M
settings-sync-disconnect-button =
    .label = 연결 끊기

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = 북마크
    .accesskey = m
sync-engine-history =
    .label = 기록
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = 열린 탭
    .tooltiptext = 다른 기기에서 열린 탭
    .accesskey = t
sync-engine-tabs =
    .label = 열린 탭
    .tooltiptext = 모든 동기화된 기기에서 열린 탭의 목록
    .accesskey = T
sync-engine-passwords =
    .label = 비밀번호
    .tooltiptext = 저장한 비밀번호
    .accesskey = P
sync-engine-addresses2 =
    .label = 주소
    .tooltiptext = { -brand-short-name }에 저장한 주소
    .accesskey = e
sync-engine-payment-methods3 =
    .label = 결제 수단
    .tooltiptext = 저장한 결제 수단
    .accesskey = n
sync-engine-addons2 =
    .label = 부가 기능
    .tooltiptext = 데스크톱용 { -brand-short-name }에 추가한 확장 기능 및 테마
    .accesskey = a
sync-engine-settings2 =
    .label = 설정
    .tooltiptext = 해당되는 { -brand-short-name } 설정
    .accesskey = s
sync-engine-addresses =
    .label = 주소
    .tooltiptext = 저장한 우편 주소(데스크탑)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = 결제 수단
    .tooltiptext = 이름, 카드 번호, 만료일
    .accesskey = n
sync-engine-addons =
    .label = 부가 기능
    .tooltiptext = Firefox 데스크톱 용 확장 기능 및 테마
    .accesskey = A
sync-engine-settings =
    .label = 설정
    .tooltiptext = 변경한 일반, 개인 정보 및 보안 설정
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = 저장
    .buttonlabelextra2 = 연결끊기…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = 연결된 모든 기기에서 동기화 할 항목 관리
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = 저장
    .buttonlabelextra2 = 연결 끊기…
    .buttonaccesskeyaccept = S
    .buttonaccesskeyextra2 = D
    .style = min-width: 36em;
    .title = 이 기기에 동기화할 항목 관리

## The device name controls.

sync-device-name-header = 기기 이름
sync-device-name-header-2 =
    .label = 기기 이름
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = 기기 이름
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = 기기 이름 변경
    .accesskey = h
sync-device-name-change =
    .label = 기기 이름 변경…
    .accesskey = h
sync-device-name-cancel =
    .label = 취소
    .accesskey = n
sync-device-name-save =
    .label = 저장
    .accesskey = v
sync-connect-another-device = 다른 기기 연결
sync-connect-another-device-2 =
    .label = 다른 기기 연결

## Privacy Section

privacy-header = 브라우저 개인 정보

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = 비밀번호
    .searchkeywords = 로그인
forms-passwords-header =
    .aria-label = 비밀번호
    .label = 비밀번호
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = 비밀번호 저장 요청
    .accesskey = A
forms-manage-password-exceptions =
    .label = 비밀번호 예외 관리
    .accesskey = M
forms-exceptions =
    .label = 예외…
    .accesskey = x
forms-suggest-passwords =
    .label = 강력한 비밀번호 제안
    .accesskey = S
forms-breach-alerts =
    .label = 유출된 웹 사이트의 비밀번호에 대한 경고 표시
    .accesskey = b
forms-breach-alerts-learn-more-link = 더 알아보기
preferences-relay-integration-checkbox2 =
    .label = 이메일 주소를 보호하기 위해 { -relay-brand-name } 이메일 가리기 제안
    .accesskey = r
relay-integration-learn-more-link = 더 알아보기
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = 사용자 이름과 비밀번호를 자동으로 채우기
    .accesskey = F
forms-fill-usernames-and-passwords-2 =
    .label = 사용자 이름과 비밀번호 저장 및 자동 채우기
    .accesskey = f
forms-saved-passwords =
    .label = 저장된 비밀번호
    .accesskey = d
forms-saved-passwords-2 =
    .label = 저장된 비밀번호 관리
    .accesskey = d
forms-saved-passwords-searchkeywords = 다음 사이트에 대한 로그인 정보가 컴퓨터에 저장됨
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = 추가 보호
forms-primary-pw-use =
    .label = 기본 비밀번호 사용
    .accesskey = U
forms-primary-pw-use-2 =
    .description = 저장된 비밀번호를 보호하기 위한 추가 보안 계층을 제공합니다.
    .label = 기본 비밀번호 사용
    .accesskey = U
forms-primary-pw-set =
    .label = 기본 비밀번호 설정
forms-primary-pw-on-2 = 기본 비밀번호가 <strong>켜짐</strong>
forms-primary-pw-on =
    .label = 기본 비밀번호가 켜짐
forms-primary-pw-change-2 =
    .label = 기본 비밀번호 변경
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = 끄기
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = 비밀번호 채우기 및 관리에 기기 로그인 요구
forms-os-reauth-2 =
    .label = 비밀번호를 관리하기 위해 기기 로그인 요구
forms-primary-pw-learn-more-link = 더 알아보기
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = 기본 비밀번호 변경…
    .accesskey = M
forms-primary-pw-change =
    .label = 기본 비밀번호 변경…
    .accesskey = P
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = 현재 FIPS 모드입니다. FIPS는 기본 비밀번호가 설정되어야 합니다.
forms-master-pw-fips-desc = 비밀번호 변경 실패
forms-windows-sso =
    .label = Microsoft, 회사 및 학교 계정에 Windows 단일 로그인 (SSO) 허용
forms-windows-sso-learn-more-link = 더 알아보기
forms-windows-sso-desc = 기기 설정에서 계정 관리를 합니다.
windows-passkey-settings-label = 시스템 설정에서 패스키 관리
privacy-panel-settings-header =
    .description = { -brand-short-name }에서 온라인 개인 정보 보호에 대한 도움을 받으세요.
    .label = 개인 정보 패널 설정
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = 유출 메시지 보기
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = 기본 비밀번호를 만들려면, Windows 로그인 자격 증명을 입력하세요. 이는 계정의 보안을 보호하는 데 도움이 됩니다.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = 기본 비밀번호 만들기
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] 결제 수단 설정 변경
       *[other] { -brand-short-name }가 결제 수단 설정을 변경하려고 합니다. 이를 허용하려면 기기 로그인을 사용하세요.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = 결제 수단
autofill-payment-methods-checkbox-message-2 =
    .label = 결제 정보 저장 및 자동 채우기
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = 결제 수단 관리
autofill-payment-methods-manage-payments-button =
    .label = 결제 수단 관리
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = 자동 채우기를 위해 기기 로그인 필요
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = 자동 채우기 및 결제 수단 관리에 기기 로그인 요구
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = 보안 코드 저장
    .accesskey = c
autofill-payment-methods-add-button = 새 결제 수단 추가
payments-list-header =
    .label = 결제 수단
payments-delete-payment-prompt-title = 이 결제 수단을 삭제하시겠습니까?
payments-delete-payment-prompt-confirm-button = 삭제
payments-delete-payment-prompt-cancel-button = 취소
payments-delete-payment-button-label =
    .aria-label = 삭제
payments-edit-payment-button-label =
    .aria-label = 편집
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = 추가된 결제 수단 없음
autofill-addresses-checkbox-message =
    .label = 주소 저장 및 자동 채우기
    .accesskey = S
autofill-addresses-manage-addresses-button =
    .label = 주소 및 기타 관리
    .accesskey = M
addresses-list-header =
    .label = 주소
addreses-delete-address-button-label =
    .aria-label = 삭제
addreses-edit-address-button-label =
    .aria-label = 편집
addresses-delete-address-prompt-title = 이 주소를 삭제하시겠습니까?
addresses-delete-address-prompt-confirm-button = 삭제
addresses-delete-address-prompt-cancel-button = 취소
autofill-addresses-add-button = 새 주소 추가
autofill-addresses-manage-addresses-title =
    .heading = 주소 및 기타 관리
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = 추가된 주소 없음
personal-info-group =
    .label = 개인 정보
autofill-personal-info-checkbox-message =
    .label = 개인 정보 저장 및 자동 채우기
autofill-personal-info-manage-button =
    .label = 개인 정보 관리
passports-list-header =
    .label = 여권
passports-delete-passport-button-label =
    .aria-label = 삭제
passports-edit-passport-button-label =
    .aria-label = 편집
passports-delete-passport-prompt-title = 이 여권을 삭제하시겠습니까?
passports-delete-passport-prompt-confirm-button = 삭제
passports-delete-passport-prompt-cancel-button = 취소
autofill-passports-add-button = 새 여권 추가
autofill-personal-info-manage-title =
    .heading = 개인 정보 관리
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = 추가된 여권 없음
pane-passwords-autofill-title2 = 비밀번호 및 자동 채우기
    .title = 비밀번호 및 자동 채우기
preferences-passwords-autofill-header =
    .heading = 비밀번호 및 자동 채우기
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } 저장됨
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } 저장됨
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = 주소 및 기타
payments-group =
    .label = 결제 수단

## Privacy Section - History

history-remember-option-never2 =
    .description = 모든 창은 사생활 보호 창처럼 작동합니다. 켜져 있으면 확장 기능을 허용해야 합니다.
    .label = 기록을 기억 안 함
history-remember-option-custom2 =
    .label = 기록 사용자 지정
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name }가 방문, 다운로드, 양식 및 검색 기록을 기억합니다.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name }는 사생활 보호 모드와 같은 설정을 가지며, 웹 사이트 방문 중 어떤 기록도 기억하지 않습니다.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name }가 탐색, 다운로드, 양식 및 검색 기록에 대해 사용자 지정 설정을 사용합니다.
history-private-browsing-permanent =
    .label = 항상 사생활 보호 모드 사용
    .accesskey = p
history-remember-browser-option =
    .label = 방문 및 다운로드 기록 기억
    .accesskey = b
history-remember-search-option =
    .label = 검색 및 양식 기록 기억
    .accesskey = f
history-clear-on-close-option =
    .label = { -brand-short-name }를 닫을 때 기록 지우기
    .accesskey = r
history-clear-on-close-settings =
    .label = 설정…
    .accesskey = t
history-shutdown-exceptions =
    .label = 예외 관리
    .accesskey = x
history-clear-button =
    .label = 기록 지우기…
    .accesskey = s
history-header2 =
    .heading = 기록
history-section-header =
    .description = 브라우저를 닫을 때 { -brand-short-name }가 기억할 항목을 선택하세요.
    .label = 기록
history-custom-section-header =
    .description = 브라우저를 닫을 때 { -brand-short-name }가 기억할 항목을 사용자 지정하세요.
    .label = 고급 설정
history-custom-button =
    .label = { -brand-short-name }가 기억할 항목을 선택하세요
history-group =
    .label = 기록
history-mode-radio-group =
    .aria-label = 기록
history-remember-option-all2 =
    .label = 기록 기억

## Privacy Section - Site Data

sitedata-total-size-calculating = 사이트 데이터와 캐시 크기 계산 중…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = 웹 사이트가 현재 <strong>{ $value } { $unit }</strong>의 디스크 공간을 사용하고 있습니다.
sitedata-learn-more = 더 알아보기
sitedata-delete-on-close2 =
    .label = { -brand-short-name }를 닫을 때마다 쿠키와 사이트 데이터를 지움
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = 기록 설정에 따라 { -brand-short-name }는 브라우저를 닫을 때 세션에서 쿠키와 사이트 데이터를 삭제합니다.
sitedata-delete-on-close-private-browsing4 =
    .heading = 기록이 저장되지 않습니다.
    .message = { -brand-short-name }는 브라우저를 닫을 때 세션에서 쿠키와 사이트 데이터를 지웁니다.
sitedata-option-block-cross-site-trackers =
    .label = 교차 사이트 추적기
sitedata-option-block-cross-site-tracking-cookies =
    .label = 교차 사이트 추적 쿠키
sitedata-option-block-cross-site-cookies2 =
    .label = 교차 사이트 쿠키 격리
sitedata-option-block-unvisited =
    .label = 방문하지 않은 웹 사이트의 쿠키
sitedata-option-block-all-cross-site-cookies =
    .label = 모든 교차 사이트 쿠키 (웹 사이트가 제대로 작동 안 할 수 있음)
sitedata-option-block-all =
    .label = 모든 쿠키 (웹 사이트가 깨질 수 있음)
sitedata-clear2 =
    .label = 탐색 데이터 지우기
    .accesskey = l
sitedata-settings2 =
    .label = 탐색 데이터 관리
    .accesskey = M
sitedata-cookies-exceptions =
    .label = 예외 관리…
    .accesskey = x
sitedata-cookies-exceptions2 =
    .description = 쿠키 및 사이트 데이터 사용을 항상 허용하거나 허용하지 않을 웹 사이트를 지정할 수 있습니다.
    .label = 예외 관리
    .accesskey = x
sitedata-heading =
    .description = 쿠키, 기록, 캐시, 웹사이트 데이터 등을 관리합니다.
    .label = 탐색 데이터
sitedata-settings3 =
    .label = 특정 사이트에 대한 데이터 지우기
    .accesskey = s
sitedata-cookies-exceptions3 =
    .description = 특정 사이트에서 쿠키 및 사이트 데이터를 처리하는 방법을 선택합니다.
    .label = 예외 관리
    .accesskey = x
cookies-site-data-group =
    .label = 쿠키 및 사이트 데이터

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = 쿠키 배너 차단기
cookie-banner-blocker-description = 사생활 보호 모드에서 사이트가 쿠키를 사용할 수 있는지 묻는 경우 { -brand-short-name }는 자동으로 거부합니다. 단, 지원되는 사이트에서만 가능합니다.
cookie-banner-learn-more = 더 알아보기
cookie-banner-blocker-checkbox-label =
    .label = 쿠키 배너 자동 거부

## Search Section

addressbar-locbar-history-option =
    .label = 방문 기록
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = 북마크
    .accesskey = k
addressbar-locbar-clipboard-option =
    .label = 클립보드
    .accesskey = C
addressbar-locbar-openpage-option =
    .label = 열린 탭
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = 바로 가기
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = 상위 사이트
    .accesskey = T
addressbar-locbar-engines-option-1 =
    .label = 사용할 검색 엔진 제안
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = 빠른 작업
    .accesskey = Q
addressbar-locbar-showrecentsearches-option-2 =
    .label = 최근 검색
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = 인기 검색어 제안
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = 검색어와 관련된 웹 제안을 받습니다.
    .label = { -brand-short-name }의 제안
addressbar-locbar-suggest-sponsored-option-2 =
    .description = 가끔씩 스폰서 제안으로 { -brand-short-name }를 지원합니다.
    .label = 스폰서 제안
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = 입력할 때 Mozilla에서 제안을 가져옴
addressbar-dismissed-suggestions-label-2 =
    .description = 거절한 스폰서와 { -brand-short-name }의 제안을 복원합니다.
    .label = 거절한 제안
addressbar-restore-dismissed-suggestions-button-2 =
    .label = 제안 복원

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = 향상된 추적 방지 기능
content-blocking-section-top-level-description = 추적기는 온라인에서 사용자를 따라다니며 탐색 습관과 관심사에 대한 정보를 수집합니다. { -brand-short-name }는 이러한 많은 추적기 및 기타 악성 스크립트를 차단합니다.
content-blocking-learn-more = 더 알아보기
content-blocking-fpi-incompatibility-warning = { -brand-short-name }의 일부 쿠키 설정을 재정의하는 자사 격리 (FPI)를 사용 중입니다.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = { -brand-short-name }의 디지털 지문 보호 설정 중 일부를 대체하는 RFP (Resist Fingerprinting)를 사용하고 있습니다. 이로 인해 일부 사이트가 제대로 작동 안 할 수 있습니다.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = 표준
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = 엄격
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = 사용자 지정
    .accesskey = C

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = 보호와 성능 사이의 균형이 잡혀 있습니다. 페이지가 정상적으로 로드됩니다.
content-blocking-etp-strict-desc = 더 강력한 보호 기능을 제공하지만, 일부 사이트나 콘텐츠가 손상될 수 있습니다.
content-blocking-etp-custom-desc = 차단할 추적기와 스크립트를 선택하세요.
content-blocking-etp-blocking-desc = { -brand-short-name }가 다음 항목을 차단함:
content-blocking-private-windows = 사생활 보호 창의 추적 콘텐츠
content-blocking-cross-site-cookies-in-all-windows2 = 모든 창에서 교차 사이트 쿠키
content-blocking-cross-site-tracking-cookies = 교차 사이트 추적 쿠키
content-blocking-all-cross-site-cookies-private-windows = 사생활 보호 창에서 교차 사이트 쿠키
content-blocking-isolate-cross-site-cookies = 교차 사이트 쿠키 격리
content-blocking-social-media-trackers = 소셜 미디어 추적기
content-blocking-all-cookies = 모든 쿠키
content-blocking-unvisited-cookies = 방문하지 않은 사이트의 쿠키
content-blocking-all-windows-tracking-content = 모든 창의 추적 콘텐츠
content-blocking-all-cross-site-cookies = 모든 교차 사이트 쿠키
content-blocking-cryptominers = 암호화폐 채굴기
content-blocking-fingerprinters = 디지털 지문
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = 알려지거나 의심되는 디지털 지문
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = 전체 쿠키 보호는 사용자가 있는 사이트에 대한 쿠키가 포함되어 있으므로, 추적기가 사이트 간에 사용자를 팔로우하는 데 쿠키를 사용할 수 없습니다.
content-blocking-etp-standard-tcp-rollout-learn-more = 더 알아보기
content-blocking-etp-standard-tcp-title = 가장 강력한 개인 정보 보호 기능인 전체 쿠키 보호 포함
content-blocking-warning-title-2 = 일부 사이트는 엄격한 추적 방지 기능으로 인해 손상될 수 있음
content-blocking-warning-title-custom = 일부 사이트는 사용자 지정 추적 방지 기능으로 인해 손상될 수 있음
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name }는 손상된 사이트 기능 및 콘텐츠를 줄이기 위해 "사이트 문제 해결" 설정을 사용할 것을 권장합니다. 사이트가 손상된 것 같으면 해당 사이트에 대한 추적 방지 기능을 해제하여 모든 콘텐츠를 로드해 보세요.
content-blocking-warning-learn-how = 방법 알아보기
content-blocking-baseline-exceptions-3 =
    .description = 추적기가 포함되어 있을 수 있는 필수 요소만 차단 해제하여 사이트와 기능을 로드하는 데 도움을 줍니다. 대부분의 일반적인 문제를 해결합니다.
    .label = 주요 사이트 문제 해결 (권장)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = 추적기가 포함되어 있을 수 있는 요소를 차단 해제하여 글이나 댓글란의 동영상 등을 복원합니다. 이는 사이트 문제를 줄일 수 있지만 보호 수준은 낮아집니다. 주요 사이트 문제 해결과 함께 사용해야 합니다.
    .label = 사소한 사이트 문제 해결
content-blocking-baseline-uncheck-warning-dialog-title = 정말로 사이트 문제 해결을 끄시겠습니까?
content-blocking-baseline-uncheck-warning-dialog-body = 이 설정은 가장 일반적인 사이트 문제를 해결하는 데 도움이 됩니다. 이 기능을 끄면 일부 사이트가 작동하지 않을 수 있으며 { -brand-short-name }가 이러한 문제 해결을 돕지 못할 수 있습니다.
content-blocking-baseline-uncheck-warning-dialog-ok-button = 끄기
content-blocking-baseline-uncheck-warning-dialog-cancel-button = 계속 켜기
content-blocking-reload-description = 변경 사항을 적용하려면 탭을 다시 로드해야 합니다.
content-blocking-reload-tabs-button =
    .label = 모든 탭 새로 고침
    .accesskey = R
content-blocking-tracking-content-label =
    .label = 추적 콘텐츠
    .accesskey = T
content-blocking-tracking-protection-option-all-windows =
    .label = 모든 창에서
    .accesskey = A
content-blocking-option-private =
    .label = 사생활 보호 창에서만
    .accesskey = P
content-blocking-cookies-label =
    .label = 쿠키
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = 추가 정보
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = 암호화폐 채굴기
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = 알려진 디지털 지문
    .accesskey = K
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = 의심되는 디지털 지문
    .accesskey = S

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = 예외 관리…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = { -brand-short-name }가 다시 시작될 때까지 알림을 일시 중지
    .accesskey = n
permissions-autoplay2 =
    .label = 자동 재생
permissions-block-popups2 =
    .label = 팝업 및 제3자 리디렉션 차단
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = 팝업을 열고 제3자 리디렉션을 사용할 수 있는 웹 사이트를 추가하세요.
    .label = 예외 관리
    .searchkeywords = 팝업
    .accesskey = E
permissions-addon-install-warning3 =
    .label = 웹 사이트가 확장 기능을 설치하려고 할 때 경고 표시
    .accesskey = W
permissions-addon-exceptions2 =
    .label = 확장 기능을 설치할 수 있는 웹 사이트 선택
    .accesskey = E
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = 사이트의 앱 링크 열기 요청 허용
    .accesskey = A
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = 차단된 사이트 관리
    .accesskey = M
permissions-location2 =
    .label = 위치
permissions-localhost2 =
    .label = 기기 앱과 서비스
permissions-local-network2 =
    .label = 로컬 네트워크 기기
permissions-xr2 =
    .label = 가상 현실
permissions-camera2 =
    .label = 카메라
permissions-microphone2 =
    .label = 마이크
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = 스피커
permissions-notification2 =
    .label = 알림
permissions-header3 =
    .description = 어떤 웹 사이트가 접근, 제어 또는 실행할 수 있는지 관리합니다.
    .label = 권한
permissions-data-section =
    .heading = 권한 및 데이터
pane-permissions-data-title2 = 권한 및 데이터
    .title = 권한 및 데이터
notifications-section-header =
    .heading = 알림
notifications-entry-card-header =
    .description = 알림을 보낼 수 있는 웹 사이트와 알림 메시지 표시 방법을 선택하세요.
    .label = 알림
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
           *[other] 웹 사이트 { $count }개
        }
    .label = 알림 설정 관리
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = 웹 사이트 알림 설정 관리
notifications-website-card-header =
    .description = 웹 사이트가 알림을 보낼 수 있는 방법을 선택하세요.
    .label = 웹 사이트 알림
notifications-filter =
    .placeholder = 웹 사이트 검색
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = 웹 사이트
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = 알림 허용
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = 웹 사이트
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = 항상
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = 허용
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = 안 함
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = 추가된 웹 사이트 알림이 없습니다.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = 검색어와 일치하는 웹 사이트 알림이 없습니다.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = 이 변경 사항을 백업에 적용하려면, 각 프로필을 열고 설정에서 “지금 백업”을 선택하세요.
nimbus-rollouts =
    .description = 변경사항은 원격으로 적용됩니다.
    .label = 업데이트 간에 { -brand-short-name }가 기능, 성능 및 안정성을 개선할 수 있도록 허용
addon-recommendations3 =
    .description = 탐색 경험을 향상시키기 위한 확장 기능 추천을 받으세요.
    .label = 개인화된 확장 기능 추천 허용
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = 이 빌드 구성에서는 데이터 보고를 하지 않습니다.
collection-backlogged-crash-reports2 =
    .label = 자동으로 충돌 보고서 보내기
    .accesskey = c
collection-backlogged-crash-reports-description = { -vendor-short-name }가 브라우저의 문제를 진단하고 해결하는 데 도움이 됩니다. 보고서에는 개인 정보나 민감한 정보가 포함되어 있을 수 있습니다.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = 동일한 설정, 새로운 모습!
    .message = 더 쉽게 스캔하고 탐색할 수 있도록 이 페이지를 재구성했습니다. 개인 설정은 변경되지 않았으며 모든 것이 그대로 유지됩니다. 팁: 검색을 사용하여 필요한 항목으로 바로 이동하세요.
settings-redesign-promo-dismiss-button =
    .label = 확인
privacy-segmentation-section-header = 탐색을 향상시키는 새로운 기능
privacy-segmentation-section-description = 더 개인적인 경험을 제공하기 위해 사용자의 데이터를 사용하는 기능을 제공하는 경우:
privacy-segmentation-radio-off =
    .label = { -brand-product-name } 추천 사용
privacy-segmentation-radio-on =
    .label = 자세한 정보 표시
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = 우리는 사용자에게 선택권을 제공하고 모두를 위해 { -brand-product-name }를 개선하는 데 필요한 최소한의 데이터만 수집하기 위해 노력합니다.
    .label = { -brand-short-name } 데이터 수집과 사용
    .searchkeywords = 원격 분석
data-collection-link = 개인정보처리방침 보기
data-collection-preferences-across-profiles =
    .message = 이 설정은 이 기기의 모든 { -brand-product-name } 프로필에 적용됩니다.
data-collection-profiles-link = 모든 프로필 보기
data-collection-health-report-telemetry-disabled =
    .message = 더 이상 { -vendor-short-name }에서 기술 및 상호 작용 데이터를 수집하도록 허용하지 않습니다. 모든 기존 데이터는 30일 이내에 삭제됩니다.
data-collection-health-report =
    .description = { -brand-product-name }의 기능, 성능, 안정성을 개선하는 데 도움이 됩니다.
    .label = { -vendor-short-name }로 기술 및 상호 작용 데이터 보내기
    .accesskey = r
data-collection-health-report-disabled =
    .description = 이 빌드 구성에서는 데이터 보고가 비활성화되었습니다.
    .label = { -vendor-short-name }로 기술 및 상호 작용 데이터 보내기
    .accesskey = r
data-collection-run-studies =
    .description = { -brand-short-name }가 사용자를 무작위로 선택하여 기능을 테스트하므로 모든 사람의 품질을 향상시키는 데 도움이 됩니다.
    .label = { -brand-short-name }가 기능 연구를 실행하도록 허용
data-collection-studies-link =
    .label = { -brand-short-name } 연구 보기
data-collection-backlogged-crash-reports =
    .description = { -vendor-short-name }가 브라우저 문제를 진단하고 해결하는 데 도움이 됩니다. 보고서에는 개인 또는 민감한 데이터가 포함될 수 있습니다.
    .label = 자동으로 충돌 보고서 보내기
    .accesskey = c
data-collection-usage-ping =
    .description = { -vendor-short-name }가 활성 사용자를 예측하는 데 도움이 됩니다.
    .label = { -vendor-short-name }에 일일 사용량 핑 보내기
    .accesskey = U

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = 보안
browsing-protection-group2 =
    .description = 위험한 사이트와 다운로드로 인해 데이터와 기기가 위험해질 수 있습니다. { -brand-short-name }는 이를 자동으로 차단하고 위험하거나 원치 않는 소프트웨어에 대해 경고합니다.
    .label = 사기성 콘텐츠 및 위험한 소프트웨어 보호
security-enable-safe-browsing =
    .label = 위험하고 사기성 있는 콘텐츠 차단
    .accesskey = B
security-enable-safe-browsing-link = 더 알아보기
security-safe-browsing-warning =
    .message = 이 옵션을 끄면 사기, 악성 사이트 및 위험한 다운로드에 대한 보호 기능이 저하됩니다.
security-block-downloads =
    .label = 위험한 다운로드 차단
    .accesskey = D
security-block-uncommon-software =
    .label = 원치 않거나 흔하지 않은 소프트웨어에 대해 경고
    .accesskey = C

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = 사용자가 설치한 제3자 루트 인증서를 { -brand-short-name }가 자동으로 신뢰하도록 허용
    .accesskey = t
certs-devices-enable-fips = FIPS 사용
space-alert-over-5gb-settings-button =
    .label = 설정 열기
    .accesskey = O
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } 디스크 용량이 부족합니다.</strong> 웹 사이트 내용이 제대로 표시되지 않을 수 있습니다. 설정 > 개인 정보 및 보안 > 쿠키 및 사이트 데이터에서 저장된 데이터를 지울 수 있습니다.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } 디스크 용량이 부족합니다.</strong> 웹 사이트 내용이 제대로 표시되지 않을 수 있습니다. 더 나은 인터넷 경험을 위해 디스크 용량을 최적화하는 방법을 알아보려면 “더 알아보기”를 방문하세요.
certs-description3 =
    .description = 보안 연결을 확인하기 위해 { -brand-short-name }가 사용하는 인증서를 구성합니다.
    .label = 인증서
certs-view2 =
    .label = 인증서 관리
    .accesskey = C
certs-devices2 =
    .label = 보안 기기 관리
    .accesskey = D

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = HTTPS 전용 모드 작동 방식
httpsonly-radio-enabled =
    .label = 모든 창에서 HTTPS 전용 모드 사용
httpsonly-radio-enabled-pbm =
    .label = 사생활 보호 창에서만 HTTPS 전용 모드 사용
httpsonly-radio-disabled3 =
    .description = { -brand-short-name }는 여전히 ​​일부 연결을 업그레이드 할 수 있음
    .label = HTTPS 전용 모드 사용 안 함
httpsonly-group =
    .description = 웹 사이트에 보안 연결만 허용합니다. { -brand-short-name }는 안전하지 않은 연결을 하기 전에 묻습니다.
    .label = HTTPS 전용 모드
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS over HTTPS
dns-over-https-group2 =
    .description = DNS over HTTPS (DoH)는 사이트 조회를 암호화하므로 인터넷 공급자나 다른 사람이 사용자가 방문하려는 웹 사이트를 확인하기가 더 어렵습니다.
    .label = DNS over HTTPS
preferences-doh-description2 = DNS over HTTPS는 암호화된 연결을 통해 도메인 이름에 대한 요청을 전송하여 보안 DNS를 제공하고 다른 사람들이 사용자가 액세스하려는 웹 사이트를 보기 어렵게 만듭니다.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = 상태: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = 공급자: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = 잘못된 URL
preferences-doh-steering-status = 로컬 공급자 사용 중
preferences-doh-status-active = 활성
preferences-doh-status-disabled = 꺼짐
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = 활성 안 됨 ({ $reason })
preferences-doh-group-message2 = DNS over HTTPS 보호 수준:
preferences-doh-radio-group =
    .aria-label = DNS over HTTPS 보호 수준:
preferences-doh-expand-section =
    .tooltiptext = 추가 정보
preferences-doh-setting-default =
    .label = 기본 보호
    .accesskey = D
preferences-doh-default-desc = { -brand-short-name }가 보안 DNS를 사용하여 개인 정보를 보호할 때를 결정합니다.
preferences-doh-default-detailed-desc-1 = 사용 가능한 지역에서 보안 DNS 사용
preferences-doh-default-detailed-desc-2 = 보안 DNS 공급자에 문제가 있는 경우 기본 DNS 해석기 사용
preferences-doh-default-detailed-desc-3 = 가능하면 로컬 공급자를 사용
preferences-doh-default-detailed-desc-4 = VPN, 자녀 보호 또는 엔터프라이즈 정책이 활성화되면 끄기
preferences-doh-default-detailed-desc-5 = 네트워크에서 { -brand-short-name }에 보안 DNS를 사용하지 말라고 하면 끄기
preferences-doh-setting-enabled =
    .label = 향상된 보호
    .accesskey = I
preferences-doh-enabled-desc = 보안 DNS를 사용할 때를 제어하고 공급자를 선택합니다.
preferences-doh-enabled-detailed-desc-1 = 선택한 공급자 사용
preferences-doh-enabled-detailed-desc-2 = 보안 DNS에 문제가 있는 경우에만 기본 DNS 해석기 사용
preferences-doh-setting-strict =
    .label = 최대 보호
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name }가 항상 보안 DNS를 사용합니다. 시스템 DNS를 사용하기 전에 보안 위험 경고가 표시됩니다.
preferences-doh-strict-detailed-desc-1 = 선택한 공급자만 사용
preferences-doh-strict-detailed-desc-2 = 보안 DNS를 사용할 수 없는 경우 항상 경고
preferences-doh-strict-detailed-desc-3 = 보안 DNS를 사용할 수 없으면 사이트가 제대로 로드되지 않거나 작동하지 않음
preferences-doh-setting-off =
    .label = 끄기
    .accesskey = O
preferences-doh-off-desc = 기본 DNS 해석기 사용
preferences-doh-select-resolver = 공급자 선택:
preferences-doh-manage-exceptions =
    .label = 예외 관리…
    .accesskey = x
preferences-doh-overview-default =
    .description = 가능한 지역에서는 보안 DNS를 사용합니다.
    .label = 기본 보호
preferences-doh-overview-custom =
    .description = 항상 공급자와 대체 동작을 제어할 수 있는 보안 DNS를 사용합니다.
    .label = 사용자 지정
preferences-doh-overview-off =
    .description = 기본 DNS 해석기를 사용합니다.
    .label = 끄기
preferences-doh-advanced-button =
    .label = 고급 설정
preferences-doh-advanced-section =
    .description = DNS over HTTPS (DoH)는 사이트 조회를 암호화하므로 인터넷 공급자나 다른 사람이 사용자가 방문하려는 웹 사이트를 확인하기가 더 어렵습니다.
    .label = 고급 설정
preferences-doh-manage-exceptions2 =
    .label = 예외 관리
    .accesskey = x
preferences-doh-radio-default =
    .description = 사용 가능한 지역에서 보안 DNS를 사용함
    .label = 기본
preferences-doh-radio-custom =
    .description = 항상 공급자와 대체 동작을 제어할 수 있는 보안 DNS를 사용함
    .label = 사용자 지정
preferences-doh-radio-off =
    .description = 기본 DNS 해석기를 사용함
    .label = 끄기
preferences-doh-fallback-label =
    .label = 보안 DNS를 사용할 수 없는 경우 항상 경고
preferences-doh-status-item-off =
    .message = DNS over HTTPS가 꺼짐
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = { $name } 공급자를 사용하는 동안 오류({ $reason })가 발생하여 DNS over HTTPS가 작동하지 않습니다.
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = 잘못된 URL({ $reason })을 받아 DNS over HTTPS가 작동하지 않음
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS over HTTPS가 { $name } 공급자를 사용 중
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = 로컬 공급자 { $name }를 사용하는 동안 오류({ $reason })가 발생하여 DNS over HTTPS가 작동하지 않습니다.
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS over HTTPS가 { $name } 로컬 공급자를 사용하고 있습니다.
preferences-doh-select-resolver-label =
    .label = 공급자 선택:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = DNS over HTTPS 해석에 이 공급자를 사용
preferences-doh-custom-provider-label =
    .aria-label = 사용자 지정 공급자 URL 입력
preferences-doh-header2 =
    .heading = DNS over HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = 연결 및 소프트웨어 보안
preferences-connection-link-section =
    .description = 연결이 어떻게 안전하게 유지되고, 유해한 소프트웨어가 차단되며, 웹사이트가 어떻게 검증되는지 확인해 보세요.
    .label = 연결 및 소프트웨어 보안
preferences-connection-link-button =
    .label = 고급 설정

## The following strings are used in the Download section of settings

desktop-folder-name = 바탕 화면
downloads-folder-name = 다운로드

## Appearance page

preferences-appearance-header =
    .heading = 모양
browser-theme-group =
    .description = { -brand-short-name } 스타일을 원하는 대로 지정하세요. 테마 색상은 도구 모음, 메뉴 및 메시지에 적용됩니다.
    .label = 브라우저 테마
browser-theme-manage-link =
    .label = { -brand-short-name } 테마 관리
appearance-window-density-group =
    .description = 도구 모음, 탭, 사이드바와 같은 창 요소 주변의 간격을 조정하세요.
    .label = 창 밀도
appearance-window-density-radio-group =
    .aria-label = 창 밀도
appearance-window-density-automatic =
    .description = 보통, 좁게, 또는 터치 간격을 자동으로 적용
    .label = 자동 (기본값)
appearance-window-density-automatic-no-touch =
    .description = 보통 또는 좁게 간격을 자동으로 적용
    .label = 자동 (기본값)
appearance-window-density-standard =
    .description = 대부분의 화면에 적합한 균형 잡힌 간격
    .label = 보통
appearance-window-density-auto-touch-mode =
    .label = 태블릿 모드에서 터치 간격 사용
appearance-window-density-compact =
    .description = 작은 화면에 적합한 조밀한 간격
    .label = 좁게
appearance-window-density-touch =
    .description = 터치 스크린에 최적화된 더 넓은 창 요소 및 클릭 영역
    .label = 터치
related-settings-group =
    .label = 관련 설정
related-settings-accessibility-link =
    .label = 접근성에서 확대/축소 및 글꼴 설정 사용자 지정
related-settings-home-link =
    .label = { -firefox-home-brand-name } 사용자 지정
related-settings-tabs-browsing-link =
    .label = 브라우저 레이아웃 사용자 지정

## AI controls page

preferences-ai-controls-description = AI로 향상된 기능을 사용할지 여부를 포함하여 항상 { -brand-short-name }에서 선택할 수 있습니다. 더 많은 제어 옵션이 곧 제공될 예정입니다.
preferences-ai-controls-block-ai-label = AI 향상 기능 차단
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = 차단은 { -brand-short-name }의 신규 또는 현재의 AI 향상 기능이나 관련 팝업을 보지 않음을 의미합니다. 포함된 내용과 검색 제안 및 추천과 같은 기존의 기계 학습 기능을 제어하는 방법에 대한 <a data-l10n-name="link">자세한 내용</a>을 확인하세요.
preferences-ai-controls-blocked-message =
    .message = 신규 및 현재의 AI 향상 기능은 기본적으로 차단됩니다. 특정 기능을 차단 해제하려면 아래 컨트롤을 사용하세요.
preferences-ai-controls-on-device-group =
    .description = 이 기능을 사용하면 기기에 다운로드되는 작은 AI 모델을 사용합니다. 이 접근 방식은 개인 정보를 보호하는 데 도움이 됩니다.
    .label = 온디바이스 AI
preferences-ai-controls-translations-control =
    .description = 원하는 언어로 웹을 원활하게 탐색하세요.
    .label = 번역
preferences-ai-controls-translations-more-link = 기타 번역 설정
preferences-ai-controls-pdfjs-control =
    .description = PDF에 이미지를 추가하면 접근성을 위해 설명이 추가됩니다.
    .label = { -brand-short-name } PDF 뷰어의 이미지 대체 텍스트
preferences-ai-controls-tab-group-suggestions-control =
    .description = 탭 이름과 탭 정리를 위한 제안을 받아보세요.
    .label = 탭 그룹 제안
preferences-ai-controls-key-points-control =
    .description = 링크를 열기 전에 간략한 요약을 확인하세요.
    .label = 링크 미리보기의 요점
preferences-ai-controls-speech-recognition-control =
    .description = 로컬에서 음성을 텍스트로 변환합니다.
    .label = 음성 인식
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = 탐색하는 동안 챗봇을 시야에 두세요. 여러 공급자 중에서 선택하고 언제든지 전환할 수 있습니다.
    .label = 사이드바의 AI 챗봇 공급자
preferences-ai-controls-sidebar-chatbot-group =
    .description = 탐색하는 동안 챗봇을 시야에 두세요. Anthropic Claude, ChatGPT, Copilot, Google Gemini 및 Le Chat Mistral 중에서 선택하세요.
    .label = 사이드바의 AI 챗봇 공급자
preferences-ai-controls-sidebar-chatbot-control =
    .label = 사이드바의 챗봇
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = 사용 가능
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = 사용함
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = 차단됨
preferences-ai-controls-state-description-before = 옵션의 의미:
preferences-ai-controls-state-description-available = <strong>사용 가능:</strong> 기능을 확인하고 사용할 수 있습니다.
preferences-ai-controls-state-description-enabled = <strong>사용함:</strong> 이 기능을 사용하기로 했습니다.
preferences-ai-controls-state-description-blocked = <strong>차단됨:</strong> 기능을 볼 수 없으며 사용할 수 없습니다. 온디바이스 AI의 경우 이미 다운로드된 모델은 제거됩니다.
preferences-ai-controls-block-confirmation-heading = AI 향상 기능을 차단하시겠습니까?
preferences-ai-controls-block-confirmation-description = { -brand-short-name }에서 신규 또는 현재의 AI 향상 기능이나 관련 팝업이 표시되지 않습니다. 나중에 계속 사용하고 싶은 항목을 차단 해제할 수 있습니다.
preferences-ai-controls-block-confirmation-features-start = 차단할 항목:
preferences-ai-controls-block-confirmation-translations = 번역
preferences-ai-controls-block-confirmation-pdfjs = { -brand-short-name } PDF 뷰어의 이미지 대체 텍스트
preferences-ai-controls-block-confirmation-tab-group-suggestions = 탭 그룹 제안
preferences-ai-controls-block-confirmation-key-points = 링크 미리보기의 요점
preferences-ai-controls-block-confirmation-sidebar-chatbot = 사이드바의 챗봇 공급자
preferences-ai-controls-block-confirmation-speech-recognition = 음성 인식
preferences-ai-controls-block-confirmation-features-after = 차단은 { -brand-short-name }에서 제공하는 AI를 사용하는 확장 기능에도 영향을 줍니다.
preferences-ai-controls-block-confirmation-cancel =
    .label = 취소
preferences-ai-controls-block-confirmation-confirm =
    .label = 차단
preferences-ai-controls-header3 =
    .heading = AI 제어

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name }가 경계 중
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name }가 몇 가지 보안 개선 사항을 권장함
security-privacy-status-ok-label = 향상된 추적 방지 기능이 켜짐
security-privacy-status-problem-label = 보호 기능에 영향을 미치는 설정을 찾음
security-privacy-status-problem-helper-label = 이슈 보기
security-privacy-status-pending-trackers-label = 지난 한 달 동안 { -brand-short-name }가 차단한 추적기 수를 조회 중
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label = 지난 한 달 동안 추적기 { $trackerCount }개가 차단됨
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = <a data-l10n-name="strict-tracking-protection">엄격한 보호</a> 중
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = <a data-l10n-name="custom-tracking-protection">사용자 지정 보호</a> 중
security-privacy-status-up-to-date-label = 가장 안전한 { -brand-short-name } 최신 버전을 사용 중
security-privacy-status-update-needed-label = 새 { -brand-short-name } 버전이 있습니다.
security-privacy-status-update-error-label = { -brand-short-name }가 자체 업데이트를 하는 데 문제가 있음
security-privacy-status-update-checking-label = { -brand-short-name }가 업데이트를 확인 중
security-privacy-status-update-needed-description = 최신 속도, 안정성 및 보안 업데이트를 위해 업데이트하세요.
security-privacy-status-update-button-label =
    .label = { -brand-short-name } 업데이트
security-privacy-image-warning =
    .alt = 보안 경고에 대한 우려를 나타내는 느낌표가 있는 방패
security-privacy-image-ok =
    .alt = 해결되지 않은 보안 문제가 없음을 나타내는 체크 표시가 있는 방패
security-privacy-issue-card =
    .heading = 보안 경고
issue-card-reset-button =
    .label = 재설정
issue-card-dismiss-button =
    .aria-label = 닫기
    .tooltiptext = 닫기

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = 사이트에서는 추적기를 사용하여 온라인에서 사용자를 추적하고 불쾌한 광고를 표시합니다. { -brand-short-name }는 탐색하는 동안 사용자를 보호하고 추적기를 자동으로 차단하여 디지털 흔적을 제어할 수 있도록 합니다.
    .label = 향상된 추적 방지 기능
preferences-etp-level-radio-group =
    .aria-label = 향상된 추적 방지 기능
preferences-etp-level-standard =
    .description = 대부분의 웹 사이트에서 원활하게 작동하는 강력하고 안정적인 보호 기능입니다.
    .label = 표준 (기본값)
preferences-etp-level-strict =
    .description = 더 많은 추적기를 차단하는 강력한 보호 기능이 있지만 일부 사이트가 깨질 수 있습니다.
    .label = 엄격
preferences-etp-level-custom =
    .description = 어떤 보호 기능을 켜거나 끌지 선택합니다.
    .label = 사용자 지정
preferences-etp-status-advanced-button =
    .label = 고급 설정
preferences-etp-tracker-count-enabled =
    .label = 주소 표시줄에 차단된 추적기 수 표시
preferences-etp-status-protections-dashboard-link =
    .description = { -brand-short-name }가 소셜 미디어 추적기, 디지털 지문, 암호화폐 채굴기를 포함하여 얼마나 많은 은밀한 추적기를 차단했는지 확인하세요.
    .label = 개인화된 보호 대시보드 보기
preferences-etp-header =
    .heading = 향상된 추적 방지 기능
preferences-etp-advanced-settings-group =
    .description = 사이트에서는 추적기를 사용하여 온라인에서 사용자를 추적하고 불쾌한 광고를 표시합니다. { -brand-short-name }는 탐색하는 동안 사용자를 보호하고 대부분의 추적기를 자동으로 차단하여 디지털 흔적을 제어할 수 있도록 합니다.
    .label = 고급 설정
preferences-etp-customize-button =
    .label = 추적 방지 기능 사용자 지정
preferences-etp-reload-tabs-hint =
    .message = 변경 사항을 적용하려면 탭을 새로 고침하세요.
preferences-etp-reload-tabs-hint-button =
    .label = 모든 탭 새로 고침
preferences-etp-rfp-warning-message =
    .message = { -brand-short-name }의 디지털 지문 보호 설정 중 일부를 대체하는 RFP (Resist Fingerprinting)를 사용하고 있습니다. 이로 인해 일부 사이트가 깨질 수 있습니다.
preferences-etp-level-warning-message =
    .heading = 주의하세요! 일부 사이트가 올바르게 작동하지 않을 수 있습니다.
    .message = 일부 사이트는 기능이나 콘텐츠에 추적기를 포함하고 있습니다. { -brand-short-name }가 이를 차단하면 사이트가 손상된 것처럼 보일 수 있습니다. "사이트 문제 해결" 기능을 사용하거나 해당 사이트에서 추적 방지 기능을 꺼보세요.
preferences-etp-manage-exceptions-button =
    .description = 향상된 추적 방지 기능이 비활성화된 웹 사이트를 관리합니다.
    .label = 예외 관리
preferences-etp-customize-header =
    .heading = 추적 방지 기능 사용자 지정
preferences-etp-reset =
    .description = 설정을 사전 설정된 보호 수준으로 복원합니다.
    .label = 사용자 지정 초기화
preferences-etp-reset-standard-button =
    .label = 표준으로 재설정
preferences-etp-reset-strict-button =
    .label = 엄격으로 재설정
preferences-etp-custom-control-group =
    .description = 어떤 보호 기능을 켜거나 끌지 선택하세요.
    .label = 추적 방지 기능
preferences-etp-custom-cookies-enabled =
    .label = 쿠키
preferences-etp-custom-cookie-behavior =
    .aria-label = 쿠키
preferences-etp-custom-cookie-behavior-accept-all =
    .label = 모든 쿠키 허용
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = 교차 사이트 추적 쿠키 차단
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = 교차 사이트 쿠키 차단
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = 교차 사이트 쿠키 격리
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = 방문하지 않은 웹 사이트의 쿠키 차단
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = 모든 교차 사이트 쿠키 차단 (웹 사이트가 제대로 작동 안 할 수 있음)
preferences-etp-custom-cookie-behavior-block-all =
    .label = 모든 쿠키 차단 (웹 사이트가 깨질 수 있음)
preferences-etp-custom-tracking-protection-enabled =
    .label = 추적 콘텐츠
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = 추적 콘텐츠
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = 암호화폐 채굴기
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = 알려진 디지털 지문
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = 의심되는 디지털 지문
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = 의심되는 디지털 지문

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = 이로 인해 일부 추적기가 쿠키 없이 사용자를 따라갈 수 있습니다.
    .label = 알려진 디지털 지문은 차단되지 않습니다.
security-privacy-issue-warning-third-party-cookies =
    .description = 제3자 쿠키는 여러 웹 사이트에서 사용자를 추적하는 데 사용됩니다.
    .label = 제3자 쿠키가 활성화됨
security-privacy-issue-warning-password-manager =
    .description = 비밀번호 관리자는 계정에 대한 강력한 비밀번호를 저장하는 데 도움이 됩니다.
    .label = 비밀번호 관리자가 비활성화됨
security-privacy-issue-warning-popup-blocker =
    .description = 팝업은 방해가 되며 잠재적으로 해로울 수 있습니다.
    .label = 팝업 차단기가 비활성화됨
security-privacy-issue-warning-extension-install =
    .description = 웹 사이트에서 묻지 않고도 { -brand-short-name }에 확장 기능을 설치할 수 있습니다.
    .label = 웹 사이트에서 확장 기능을 설치할 수 있음
security-privacy-issue-warning-safe-browsing =
    .description = 웹 사이트의 사기 및 악성 코드에 대한 노출이 증가합니다.
    .label = 위험하고 사기성 콘텐츠가 차단되지 않음
security-privacy-issue-warning-doh2 =
    .description = DNS over HTTPS는 사용자가 방문하는 사이트를 네트워크 공급자로부터 숨깁니다.
    .label = DNS over HTTPS가 비활성화됨
security-privacy-issue-warning-ech2 =
    .description = Encrypted Client Hello는 사용자가 방문하는 사이트를 네트워크 공급자로부터 숨깁니다.
    .label = Encrypted Client Hello가 비활성화됨
security-privacy-issue-warning-doh =
    .description = DNS over HTTPS는 사용자가 방문하는 사이트를 네트워크 공급자로부터 숨깁니다.
    .label = DNS over HTTPS가 꺼짐
security-privacy-issue-warning-ech =
    .description = Encrypted Client Hello는 사용자가 방문하는 사이트를 네트워크 공급자로부터 숨깁니다.
    .label = Encrypted Client Hello가 비활성화됨
security-privacy-issue-warning-proxy-autodetection =
    .description = 프록시 자동 구성을 사용하면 신뢰할 수 없는 네트워크가 사용자의 활동을 모니터링할 수 있습니다.
    .label = 프록시 자동 구성이 활성화됨

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = 개인 정보 보호를 최우선으로 하는 브라우저를 선택하도록 누군가를 초대하세요.
    .label = { -brand-product-name } 공유하기
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = { -brand-product-name } 공유하기


pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = 논리적으로 그룹화되어 쉽게 접근할 수 있는 about:config 설정
vorbit-header = vOrbit-lite 설정
vorbit-warning-title = 주의!
vorbit-warning-description = 우리는 개인정보 보호와 보안을 최우선으로 고려하여 기본 설정을 신중하게 선택합니다. 이러한 설정을 변경할 때는 설정 변경의 영향을 이해하기 위해 설명을 읽어보십시오.
vorbit-general-heading = 브라우저 동작
vorbit-extension-update-checkbox =
    .label = 애드온 자동 업데이트
vorbit-sync-checkbox =
    .label = Firefox Sync 활성화
vorbit-autocopy-checkbox =
    .label = 미들 클릭 붙여넣기 활성화
vorbit-styling-checkbox =
    .label = userChrome.css 커스텀 활성화
vorbit-network-heading = 네트워크
vorbit-ipv6-checkbox =
    .label = IPv6 활성화
vorbit-privacy-heading = 프라이버시 설정
vorbit-xorigin-ref-checkbox =
    .label = 교차 출처 리퍼러 제한
vorbit-broken-heading = 핑거프린팅
vorbit-webgl-checkbox =
    .label = 사이트별 WebGL 권한 활성화
vorbit-rfp-checkbox =
    .label = ResistFingerprinting 활성화
vorbit-letterboxing-checkbox =
    .label = 레터박스 활성화
vorbit-security-heading = 보안
vorbit-ocsp-checkbox =
    .label = OCSP hard-fail 강제
vorbit-goog-safe-checkbox =
    .label = Google 세이프 브라우징 활성화
vorbit-goog-safe-download-checkbox =
    .label = 다운로드 스캔
vorbit-extension-update-description = 수동 개입 없이 확장 프로그램을 최신 상태로 유지합니다. 보안을 위한 좋은 선택입니다.
vorbit-extension-update-warning1 = 업데이트 전마다 확장 프로그램의 코드를 검토하지 않는다면, 이 옵션을 활성화해야 합니다.
vorbit-ipv6-description = { -brand-short-name }를 IPv6 접속 사용하도록 허용.
vorbit-ipv6-warning1 = 브라우저에서 IPv6를 차단하는 대신, 운영체제에서 IPv6 프라이버시 확장 기능을 활성화할 것을 권장합니다.
vorbit-ocsp-description = OCSP 체크를 수행할 수 없는 경우 웹사이트 연결을 차단합니다.
vorbit-ocsp-warning1 = 이는 보안을 강화하지만, OCSP 서버가 다운될 경우 서비스 중단을 초래할 수 있습니다.
vorbit-sync-description = 다른 브라우저와 데이터를 동기화합니다. 재시작이 필요합니다.
vorbit-sync-warning1 = Firefox Sync는 데이터를 서버로 전송하기 전에 로컬에서 암호화합니다.
vorbit-autocopy-description = 복사할 텍스트를 선택한 후, 마우스 중간 버튼 클릭으로 붙여넣습니다.
vorbit-styling-description = 수동으로 불러온 테마로 UI를 커스텀하려면 이 옵션을 활성화하십시오.
vorbit-styling-warning1 = 테마 제공자를 신뢰할 수 있는지 반드시 확인하십시오.
vorbit-xorigin-ref-description = 동일한 출처에서만 리퍼러를 전송합니다.
vorbit-xorigin-ref-warning1 = 웹사이트가 깨질 수 있습니다. 또한 전송된 리퍼러 또한 잘리게 됩니다.
vorbit-webgl-description = 사이트별 WebGL 권한 프롬프트를 활성화합니다.
vorbit-webgl-warning1 = 사이트에서 WebGL 컨텍스트 생성을 시도할 경우, 사용자에게 먼저 권한을 요청합니다.
vorbit-rfp-description = ResistFingerprinting은 최고 수준의 핑거프린팅 방지 도구입니다.
vorbit-rfp-warning1 = 이 옵션을 비활성화해야 하는 경우, Canvas Blocker 같은 확장 프로그램 사용을 고려하십시오.
vorbit-letterboxing-description = 레터박스 옵션은 제한된 범위의 둥근 해상도를 반환하기 위해 창 주변에 여백을 적용합니다.
vorbit-goog-safe-description = 악성코드와 피싱 공격이 걱정된다면, 활성화하는 것을 고려하십시오.
vorbit-goog-safe-warning1 = 검열 문제로 인해 비활성화되었으나 숙련되지 않은 사용자에게는 권장됩니다. 모든 검사는 로컬에서 수행됩니다.
vorbit-goog-safe-download-description = 세이프 브라우징이 다운로드 파일을 검사해 의심스러운 파일을 식별하도록 허용합니다.
vorbit-goog-safe-download-warning1 = 모든 검사는 로컬에서 이루어집니다.
vorbit-footer = 유용한 링크
vorbit-config-link = 모든 고급 설정 (about:config)
vorbit-open-profile = 사용자 프로필 경로 열기
content-blocking-section-top-level-description = vOrbit-lite는 강화된 추적 방지 기능을 엄격 모드로 지원하며, 기본적으로 활성화되어 있습니다. 이는 상태 분할, 엄격한 차단 목록 및 기타 유용한 개인정보 보호 기능을 제공하므로 브라우저에서 가장 중요한 설정 중 하나입니다. 다른 모드로 변경하는 것은 권장하지 않습니다.
vorbit-webgl-prompt-checkbox =
    .label = 사이트별 WebGL 권한 팝업 숨기기
vorbit-webgl-prompt-description = 사이트에서 WebGL 컨텍스트 생성을 시도할 때 표시되는 팝업을 숨깁니다. 검색창에서 아이콘을 클릭하여 프롬프트를 수동으로 표시할 수 있습니다.
permissions-webgl2 =
    .label = WebGL
vorbit-general-heading2 =
    .label = 브라우저 동작
vorbit-extension-update-checkbox2 =
    .label = 확장 기능 자동 업데이트
    .description = 확장 기능을 수동 조작 없이 최신 상태로 유지합니다. 보안을 위한 권장 설정입니다.
vorbit-sync-checkbox2 =
    .label = Firefox Sync 활성화
    .description = 다른 브라우저와 데이터를 동기화합니다. 재시작이 필요합니다.
vorbit-autocopy-checkbox2 =
    .label = 미들 클릭 붙여넣기 활성화
    .description = 복사할 텍스트를 선택한 후, 마우스 중간 버튼 클릭으로 붙여넣습니다.
vorbit-styling-checkbox2 =
    .label = userChrome.css 커스텀 허용
    .description = 수동으로 불러온 테마로 UI를 커스텀하려면 이 옵션을 활성화하십시오.
vorbit-network-heading2 =
    .label = 네트워킹
vorbit-ipv6-checkbox2 =
    .label = IPv6 활성화
    .description = { -brand-short-name }에 IPv6 연결을 허용합니다.
vorbit-privacy-heading2 =
    .label = 프라이버시
vorbit-xorigin-ref-checkbox2 =
    .label = 교차 출처 리퍼러 제한
    .description = 동일 출처에서만 리퍼러를 전송합니다.
vorbit-broken-heading2 =
    .label = 핑거프린팅
vorbit-webgl-checkbox2 =
    .label = 항상 WebGL 허용
    .description = 권한 부여 없이 항상 WebGL을 활성화합니다.
vorbit-webgl-prompt-checkbox2 =
    .label = 사이트별 WebGL 팝업 숨기기
    .description = 사이트에서 WebGL 컨텍스트를 생성하려 할 때 나타나는 팝업을 숨깁니다. 검색창에서 아이콘을 클릭하여 프롬프트를 수동으로 표시할 수 있습니다.
vorbit-rfp-checkbox2 =
    .label = ResistFingerprinting 활성화
    .description = 가능한 모든 핑거프린트 완화를 활성화하지만, 일부 웹사이트가 정상 작동하지 않을 수 있습니다.
vorbit-letterboxing-checkbox2 =
    .label = 레터박스 활성화
    .description = 창 주변에 여백을 적용하여 라운드 해상도 반환값을 제한합니다.
vorbit-security-heading2 =
    .label = 보안
