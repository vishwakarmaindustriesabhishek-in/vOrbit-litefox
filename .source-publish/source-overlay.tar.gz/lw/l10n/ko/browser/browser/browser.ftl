# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } 사생활 보호 모드
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = 빠르고 사생활을 보호하는 웹 탐색
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — 사생활 보호 모드
       *[other] { -brand-full-name } 사생활 보호 모드
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = 사생활 보호 모드
popups-infobar-dont-show-message2 =
    .label = 팝업이나 제3자 리디렉션이 차단될 때 이 메시지를 표시하지 않음
    .accesskey = D
edit-popup-settings2 =
    .label = 팝업 및 제3자 리디렉션 설정 관리…
    .accesskey = M
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] 사이트 정보 보기
            [1] 사이트 정보 보기 (추적기 1개 차단됨)
           *[other] 사이트 정보 보기 (추적기 { $count }개 차단됨)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = 링크 { $count }개
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = 에어드롭, 메시지 등…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = 메시지, 메일 등…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = 공유…
    .accesskey = h
urlbar-identity-button =
    .aria-label = 사이트 정보 보기

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = 설치 메시지 패널 열기
urlbar-web-notification-anchor =
    .tooltiptext = 사이트의 알림을 받을지 여부 변경
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI 패널 열기
urlbar-serial-notification-anchor =
    .tooltiptext = 직렬 패널 열기
urlbar-eme-notification-anchor =
    .tooltiptext = DRM 소프트웨어 사용 관리
urlbar-web-authn-anchor =
    .tooltiptext = 웹 인증 패널 열기
urlbar-canvas-notification-anchor =
    .tooltiptext = 캔버스 추출 권한 관리
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = 사이트의 마이크 공유 관리
urlbar-default-notification-anchor =
    .tooltiptext = 메시지 패널 열기
urlbar-geolocation-notification-anchor =
    .tooltiptext = 위치 요청 패널 열기
urlbar-localhost-notification-anchor =
    .tooltiptext = 이 사이트에 대한 로컬 기기 접근 관리
urlbar-local-network-notification-anchor =
    .tooltiptext = 이 사이트에 대한 로컬 네트워크 접근 공유 관리
urlbar-xr-notification-anchor =
    .tooltiptext = 가상 현실 권한 패널 열기
urlbar-storage-access-anchor =
    .tooltiptext = 탐색 활동 권한 패널 열기
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = 사이트의 창 또는 화면 공유 관리
urlbar-indexed-db-notification-anchor =
    .tooltiptext = 오프라인 저장소 메시지 패널 열기
urlbar-password-notification-anchor =
    .tooltiptext = 저장된 비밀번호 메시지 패널 열기
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = 사이트의 카메라와 마이크 공유 관리
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = 사이트의 다른 스피커 공유 관리
urlbar-autoplay-notification-anchor =
    .tooltiptext = 자동 재생 패널 열기
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = 영구 저장소에 데이터를 저장
urlbar-addons-notification-anchor =
    .tooltiptext = 부가 기능 설치 메시지 패널 열기
urlbar-search-tips-confirm = 확인
urlbar-search-tips-confirm-short = 확인
urlbar-result-menu-button =
    .title = 메뉴 열기
urlbar-result-menu-button-feedback = 의견 보내기
    .title = 메뉴 열기
urlbar-result-menu-learn-more2 = 더 알아보기
    .accesskey = L
urlbar-result-menu-remove-from-history2 = 기록에서 삭제
    .accesskey = R
urlbar-result-menu-tip-get-help2 = 도움 받기
    .accesskey = h
urlbar-result-menu-dismiss-suggestion2 = 이 제안 거절
    .accesskey = D
urlbar-result-menu-remove-top-site = 이 상위 사이트 제거
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = { -firefox-suggest-brand-name } 관리
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = 부정확한 위치 신고
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = 덜 자주 보기
    .accesskey = f
urlbar-result-menu-dont-show-weather-suggestions3 = 날씨 제안을 표시하지 않음
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = 부정확한 위치 신고
urlbar-result-menu-show-less-frequently2 = 덜 자주 보기
urlbar-result-menu-dont-show-weather-suggestions2 = 날씨 제안을 표시하지 않음
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = 이 제안 닫기
    .accesskey = i
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = 기록에서 제거
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = 더 알아보기
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = 기록에서 삭제
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = 도움 받기
    .accesskey = h
urlbar-result-menu-dismiss-suggestion =
    .label = 이 제안 거절
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = { -firefox-suggest-brand-name } 관리
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = 부정확한 위치 신고
urlbar-result-menu-show-less-frequently =
    .label = 덜 자주 보기
urlbar-result-menu-dont-show-weather-suggestions =
    .label = 날씨 제안을 표시하지 않음
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = 메뉴 열기
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = 의견을 보내 주셔서 감사합니다
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = 의견을 보내 주셔서 감사합니다. 날씨 제안이 더 이상 표시되지 않습니다.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = 입력은 더 적게하고 더 많이 찾기: 주소 표시줄에서 바로 { $engineName } 검색해 보세요.
urlbar-search-tips-redirect-2 = 주소 표시줄에서 검색을 시작하여 { $engineName }의 제안 및 방문 기록을 확인하세요.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = 더 빨리 찾으려면 여기에서 하세요.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = 북마크
urlbar-search-mode-tabs = 탭
urlbar-search-mode-history = 기록
urlbar-search-mode-actions = 작업

##

urlbar-geolocation-blocked =
    .tooltiptext = 이 사이트의 위치 정보 사용을 차단했습니다.
urlbar-localhost-blocked =
    .tooltiptext = 이 사이트의 로컬 기기 연결을 차단했습니다.
urlbar-local-network-blocked =
    .tooltiptext = 이 사이트의 로컬 네트워크 연결을 차단했습니다.
urlbar-xr-blocked =
    .tooltiptext = 이 웹 사이트에 대한 가상 현실 기기 접근을 차단했습니다.
urlbar-web-notifications-blocked =
    .tooltiptext = 이 사이트의 알림 사용을 차단했습니다.
urlbar-camera-blocked =
    .tooltiptext = 이 사이트의 카메라 사용을 차단했습니다.
urlbar-microphone-blocked =
    .tooltiptext = 이 사이트의 마이크 사용을 차단했습니다.
urlbar-screen-blocked =
    .tooltiptext = 이 사이트의 화면 공유를 차단했습니다.
urlbar-persistent-storage-blocked =
    .tooltiptext = 이 사이트의 영구 저장소 사용을 차단했습니다.
urlbar-popup-blocked2 =
    .tooltiptext = 이 사이트의 팝업과 제3자 리디렉션을 차단했습니다.
urlbar-autoplay-media-blocked =
    .tooltiptext = 이 사이트의 소리있는 미디어 자동 재생을 차단했습니다.
urlbar-canvas-blocked =
    .tooltiptext = 이 사이트의 캔버스 데이터 추출을 차단했습니다.
urlbar-midi-blocked =
    .tooltiptext = 이 사이트의 MIDI 접근을 차단했습니다.
urlbar-serial-blocked =
    .tooltiptext = 이 사이트의 직렬 포트 접근을 차단했습니다.
urlbar-install-blocked =
    .tooltiptext = 이 사이트의 부가 기능 설치를 차단했습니다.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = 북마크 편집 ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = 이 페이지 북마크 ({ $shortcut })
urlbar-split-view-button =
    .aria-label = 분할 화면
    .tooltiptext = 분할 화면

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = 붙여넣고 바로 가기
    .accesskey = G
urlbar-menuitem-paste-and-search =
    .label = 붙여넣고 바로 검색
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = 검색 기록 지우기
    .accesskey = C

## Page Action Context Menu

page-action-manage-extension2 =
    .label = 확장 기능 관리…
    .accesskey = E
page-action-remove-extension2 =
    .label = 확장 기능 제거
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = 도구 모음 닫기
    .accesskey = H
full-screen-exit =
    .label = 전체 화면 종료
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = 이번만 검색:
search-one-offs-change-settings-compact-button =
    .tooltiptext = 검색 설정 변경
search-one-offs-context-open-new-tab =
    .label = 새 탭에서 검색
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = 기본 검색 엔진으로 설정
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = 사생활 보호 창의 기본 검색 엔진으로 설정
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = “{ $engineName }” 검색 엔진 추가
    .label = “{ $engineName }” 추가
    .tooltiptext = “{ $engineName }” 검색 엔진 추가
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = 검색 엔진 추가
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = 검색 엔진 추가

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = 북마크 ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = 탭 ({ $restrict })
search-one-offs-history =
    .tooltiptext = 기록 ({ $restrict })
search-one-offs-actions =
    .tooltiptext = 작업 ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = 부가 기능 보기
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = extensions, themes, addons, add-ons, 확장 기능, 테마, 부가 기능
# Opens preferences page at AI controls
quickactions-manageai = AI 제어 관리
quickactions-cmd-manageai = disable ai, off ai, manage ai, AI 비활성화, AI 끄기, AI 관리
# Opens the bookmarks library window
quickactions-bookmarks2 = 북마크 관리
quickactions-cmd-bookmarks = 북마크, bookmarks
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = 최근 기록 지우기
quickactions-cmd-clearrecenthistory2 = cookies, clear cookies, cache, clear cache, browsing data, clear browsing data, history, clear recent history, 쿠키, 쿠키 지우기, 캐시, 캐시 지우기, 탐색 데이터, 탐색 데이터 지우기, 기록, 최근 기록 지우기
# Opens about:downloads page
quickactions-downloads2 = 다운로드 보기
quickactions-cmd-downloads = 다운로드, downloads
# Opens about:addons page in the extensions section
quickactions-extensions = 확장 기능 관리
quickactions-cmd-extensions2 = extensions, addons, add-ons, 확장 기능, 부가 기능
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name } 열기
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = { -firefoxview-brand-name } 열기, { -firefoxview-brand-name }, View 열기, View
# Opens SUMO home page
quickactions-help = { -brand-product-name } 도움말
quickactions-cmd-help = 도움, 지원, help, support
# Opens the devtools web inspector
quickactions-inspector2 = 개발자 도구 열기
quickactions-cmd-inspector2 = inspector, devtools, dev tools, 검사기, 개발자 도구, 개발자
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = 색상 선택
quickactions-cmd-colorpicker = color picker, eyedropper, pick color, 색상 선택기, 스포이드, 색상 선택
# Opens Firefox Library
quickactions-cmd-library = 라이브러리
quickactions-library = 라이브러리 열기
# Opens about:logins
quickactions-logins2 = 비밀번호 관리
quickactions-cmd-logins = 로그인, 비밀번호, logins, passwords
# Mutes all tabs playing audio
quickactions-mute = 오디오를 재생하는 탭 음소거
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = mute, shush, sssssh, 음소거
# Opens the print dialog
quickactions-print2 = 페이지 인쇄
quickactions-cmd-print = 인쇄, print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = 페이지를 PDF로 저장
quickactions-cmd-savepdf2 = pdf, save page, 페이지 저장
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF 편집기 열기
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = 사생활 보호 창 열기
quickactions-cmd-private = 사생활 보호 모드, private browsing
# Opens a SUMO article explaining how to refresh
quickactions-refresh = { -brand-short-name } 새로 고침
quickactions-cmd-refresh = 새로 고침, refresh
# Restarts the browser
quickactions-restart = { -brand-short-name } 다시 시작
quickactions-cmd-restart = 다시 시작, restart
# Opens the screenshot tool
quickactions-screenshot3 = 스크린샷
quickactions-cmd-screenshot2 = screenshot, take a screenshot, 스크린샷
# Opens about:translations
quickactions-translate = 번역
quickactions-cmd-translate = 번역
# Opens about:preferences
quickactions-settings2 = 설정 관리
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = settings, preferences, options, manage, 설정, 옵션, 관리
# Opens about:addons page in the themes section
quickactions-themes = 테마 관리
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = themes, add-ons, addons, 테마, 부가 기능
# Opens a SUMO article explaining how to update the browser
quickactions-update = { -brand-short-name } 업데이트
quickactions-cmd-update = 업데이트, update
# Opens the view-source UI with current pages source
quickactions-viewsource2 = 페이지 소스 보기
quickactions-cmd-viewsource2 = view source, source, page source, 소스 보기, 소스, 페이지 소스
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = { -firefoxlabs-brand-name } 열기
quickactions-cmd-labs = labs, experiment, 랩, 실험
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = 빠른 작업 더 알아보기
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = 탭 키를 눌러서 선택:

## Bookmark Panel

bookmarks-add-bookmark = 북마크 추가
bookmarks-edit-bookmark = 북마크 편집
bookmark-panel-cancel =
    .label = 취소
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label = 북마크 { $count }개 삭제
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = 저장할 때 편집기 표시
    .accesskey = S
bookmark-panel-save-button2 =
    .label = 저장
    .accesskey = a
bookmark-panel-save-button =
    .label = 저장
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = { $host } 사이트 정보
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = { $host }에 대한 연결 보안
identity-connection-not-secure = 안전하지 않은 연결
identity-connection-secure = 안전한 연결
identity-connection-failure = 연결 실패
identity-connection-internal = 안전한 { -brand-short-name } 페이지입니다.
identity-connection-file = 이 페이지는 컴퓨터에 저장되어 있습니다.
identity-connection-associated = 이 페이지는 다른 페이지가 로드했습니다.
identity-extension-page = 이 페이지는 확장 기능이 로드했습니다.
identity-active-blocked = { -brand-short-name }가 안전하지 않은 페이지의 일부를 차단했습니다.
identity-custom-root = Mozilla에서 인식하지 못하는 인증서 발급자가 연결을 확인했습니다.
identity-passive-loaded = 페이지의 일부(이미지 등)가 안전하지 않습니다.
identity-active-loaded = 이 페이지에서 보호를 비활성화하셨습니다.
identity-weak-encryption = 이 페이지는 약한 암호화를 사용합니다.
identity-https-only-connection-upgraded = (HTTPS로 업그레이드됨)
identity-https-only-label2 = 이 사이트를 보안 연결로 자동 업그레이드
identity-https-only-dropdown-on =
    .label = 켜기
identity-https-only-dropdown-off =
    .label = 끄기
identity-https-only-dropdown-off-temporarily =
    .label = 일시적으로 끄기
identity-https-only-info-turn-on3 = { -brand-short-name }가 가능한 경우 연결을 업그레이드하도록 하려면 이 사이트에 HTTPS 업그레이드를 켜세요.
identity-https-only-info-turn-off3 = 페이지가 손상된 것 같으면 이 사이트가 안전하지 않은 HTTP를 사용하여 다시 로드되도록 HTTPS 업그레이드를 끌 수 있습니다.
identity-https-only-info-no-upgrade = HTTP에서 연결을 업그레이드할 수 없습니다.
identity-permissions-storage-access-header = 교차 사이트 쿠키
identity-permissions-storage-access-hint = 이 당사자는 사용자가 이 사이트에 있는 동안 교차 사이트 쿠키 및 사이트 데이터를 사용할 수 있습니다.
identity-permissions-storage-access-learn-more = 더 알아보기
identity-permissions-reload-hint = 변경 사항을 적용하려면 페이지를 다시 로드해야할 수도 있습니다.
identity-clear-site-data =
    .label = 쿠키 및 사이트 데이터 지우기…
identity-connection-not-secure-security-view = 이 사이트에 안전하게 연결되어 있지 않습니다.
identity-connection-verified = 이 사이트에 안전하게 연결되어 있습니다.
identity-ev-owner-label2 = 인증서 발급 대상:
identity-verifier-label2 = 인증 기관:
identity-ev-owner-label = 인증서 발급 대상:
identity-verifier-label = 인증 기관:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = 규정 (EU) 2024/1183에 명시된 대로 자격 요건을 충족합니다.
identity-description-custom-root2 = Mozilla는 이 인증서 발급자를 인식하지 못합니다. 운영 체제 또는 관리자가 추가한 것일 수 있습니다.
identity-cert-exception-overridden = 이 사이트를 보안 예외로 추가했습니다.
identity-remove-cert-exception =
    .label = 예외 제거
    .accesskey = R
identity-description-insecure = 이 사이트의 연결은 비공개가 아닙니다. 전송하는 정보(예: 비밀번호, 메시지, 신용 카드 등)를 다른 사람이 볼 수 있습니다.
identity-description-weak-cipher-intro = 이 사이트의 연결은 약한 암호화를 사용하며 비공개가 아닙니다.
identity-description-weak-cipher-risk = 다른 사람이 정보를 보거나 웹 사이트의 동작을 바꿀 수 있습니다.
identity-description-active-blocked2 = { -brand-short-name }가 안전하지 않은 페이지의 일부분을 차단했습니다.
identity-description-passive-loaded = 이 사이트의 연결은 비공개가 아니므로 사용자가 공유하는 정보를 다른 사람들이 볼 수 있습니다.
identity-description-passive-loaded-insecure2 = 이 웹 사이트는 안전하지 않은 콘텐츠(이미지 등)을 포함하고 있습니다.
identity-description-passive-loaded-mixed2 = { -brand-short-name }가 일부 콘텐츠를 차단했지만 아직 안전하지 않은 콘텐츠(이미지 등)가 있습니다.
identity-description-active-loaded = 이 웹 사이트는 안전하지 않은 콘텐츠(스크립트 등)가 포함되어 있으며 이 사이트의 연결은 비공개가 아닙니다.
identity-description-active-loaded-insecure = 이 사이트에 공유하는 정보(예: 비밀번호, 메시지, 신용 카드 등)를 다른 사람이 볼 수 있습니다.
identity-description-tls-key-logging-heading = 연결의 보안이 유지되지 않을 수 있습니다
identity-description-tls-key-logging-message = 앱이나 서비스가 이 사이트에서 들어오는 암호화된 트래픽을 볼 수 있습니다.
identity-more-info-link-text =
    .label = 자세한 정보

## Window controls

browser-window-minimize-button =
    .tooltiptext = 최소화
browser-window-maximize-button =
    .tooltiptext = 최대화
browser-window-restore-down-button =
    .tooltiptext = 이전 크기로 복원
browser-window-close-button =
    .tooltiptext = 닫기
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = 돌아가기

## Bookmarks toolbar items

browser-import-button2 =
    .label = 북마크 가져오기…
    .tooltiptext = 다른 브라우저에서 { -brand-short-name }로 북마크를 가져옵니다.
bookmarks-toolbar-empty-message = 빠르게 접근하려면, 여기 북마크 도구 모음에 북마크를 놓으세요. <a data-l10n-name="manage-bookmarks">북마크 관리…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = 카메라:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = 카메라
popup-select-microphone-device =
    .value = 마이크:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = 마이크
popup-select-speaker-icon =
    .tooltiptext = 스피커
popup-select-window-or-screen =
    .label = 창 또는 화면:
    .accesskey = W
popup-all-windows-shared = 화면에 표시되어 있는 모든 창을 공유합니다.

## WebRTC window or screen share tab switch warning

sharing-warning-window = { -brand-short-name }를 공유하고 있습니다. 새 탭으로 전환하면 다른 사람들이 볼 수 있습니다.
sharing-warning-screen = 전체 화면을 공유하고 있습니다. 새 탭으로 전환하면 다른 사람들이 볼 수 있습니다.
sharing-warning-proceed-to-tab =
    .label = 탭으로 진행
sharing-warning-disable-for-session =
    .label = 이 세션의 공유 보호 사용 안 함

## WebSerial "select a port" popup

webserial-select-port-label = 직렬 포트를 선택하세요:
webserial-no-ports-available = 직렬 포트 없음

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = 닫기
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = 검색어 또는 주소 입력
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = 주소 입력
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = { $name } 검색
    .placeholder = 웹 검색
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = { $name } 검색
    .placeholder = 검색어 입력
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = 북마크 검색
    .placeholder = 검색어 입력
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = 기록 검색
    .placeholder = 검색어 입력
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = 탭 검색
    .placeholder = 검색어 입력
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = 작업 검색
    .placeholder = 검색어 입력
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = { $name } 검색 또는 주소 입력
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = 브라우저가 원격 제어 중입니다 (이유: { $component })
urlbar-permissions-granted =
    .tooltiptext = 이 웹 사이트에 추가 권한을 부여했습니다.
urlbar-switch-to-tab =
    .value = 탭 전환:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = 확장 기능:
urlbar-go-button2 =
    .title = 주소 표시줄의 주소로 이동
urlbar-page-action-button =
    .tooltiptext = 페이지 작업
urlbar-revert-button =
    .tooltiptext = 주소 표시줄에 주소 표시

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = 사생활 보호 창에서 { $engine } 검색
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = 사생활 보호 창에서 검색
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine } 검색
urlbar-result-action-sponsored = 스폰서
urlbar-result-action-switch-tab = 탭 전환
urlbar-result-action-move-tab-to-split-view = 탭을 분할 화면으로 이동
urlbar-result-action-visit = 방문
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = 탭 전환 · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = 이름없는 그룹
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = 클립보드에서 방문
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = { $engine } 검색하려면 Tab 키를 누르세요
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = { $engine } 검색하려면 Tab 키를 누르세요
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = 주소 표시줄에서 직접 { $engine } 검색
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = 주소 표시줄에서 직접 { $engine } 검색
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = 복사
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = 정의되지 않음
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } 확장 기능
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = 추천
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> - { $region }, { $city }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> - { $country }, { $region }, { $city }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> - { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · 스폰서
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = 묻기
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = 최근 방문: { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days = 최근 방문: { $daysAgo }일 전
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks = 최근 방문: { $weeksAgo }주 전
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months = 최근 방문: { $monthsAgo }달 전
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = 최근 방문: { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = { $date }에 북마크됨
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = 최근 방문: { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = 최근 방문: { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = 최근 방문: { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = 검색 표시줄에서 바로 주식 시장 데이터를 확인하세요
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = { -vendor-short-name }와 검색 쿼리 데이터를 공유하면 파트너사로부터 시장 동향 및 추가 정보를 확인할 수 있습니다. <a data-l10n-name="learn-more-link">더 알아보기</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = 제안 표시
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = 나중에
urlbar-result-realtime-opt-in-dismiss = 닫기
urlbar-result-realtime-opt-in-dismiss-all2 = 이 제안을 표시하지 않음
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = 시장 제안을 표시하지 않음
    .accesskey = n
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = 시장 제안을 표시하지 않음
urlbar-result-realtime-opt-in-dismiss-all =
    .label = 이 제안을 표시하지 않음
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = 시장 제안을 표시하지 않음
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = 의견을 보내 주셔서 감사합니다. 시장 제안이 더 이상 표시되지 않습니다.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = 주식 시장 제안
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = 의견을 보내 주셔서 감사합니다. 이 제안이 더 이상 표시되지 않습니다.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown = { $name } · { $daysUntilStart }일 후
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range = { $name } · { $daysUntilStart }일 후 시작
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing = { $name } · { $daysUntilEnd }일 후 종료
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · 오늘
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · 오늘 종료

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine } 검색
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - { $localSearchMode } 검색
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - { $engine } 검색
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, 검색 엔진 선택
urlbar-searchmode-button-no-engine2 =
    .title = 선택된 바로 가기 없음, 바로 가기를 선택하세요
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = 키워드 검색이 비활성화됨
urlbar-searchmode-dropmarker2 =
    .title = 검색 엔진 선택
urlbar-searchmode-bookmarks4 = 북마크
urlbar-searchmode-tabs4 = 탭
urlbar-searchmode-history4 = 기록
urlbar-searchmode-actions4 = 작업
urlbar-searchmode-bookmarks3 = 북마크
    .accesskey = B
urlbar-searchmode-tabs3 = 탭
    .accesskey = T
urlbar-searchmode-history3 = 기록
    .accesskey = H
urlbar-searchmode-actions3 = 작업
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = 닫기
urlbar-searchmode-default2 =
    .title = 기본 검색 엔진
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = “{ $engineName }” 추가
    .title = “{ $engineName }” 검색 엔진 추가
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = 이번만 검색:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = 검색:
urlbar-searchmode-popup-search-settings2 = 검색 설정
urlbar-searchmode-popup-settings2 = 설정
urlbar-searchmode-popup-search-settings = 검색 설정
    .accesskey = S
urlbar-searchmode-popup-settings = 설정
    .accesskey = S

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = 북마크 검색
urlbar-result-action-search-history = 기록 검색
urlbar-result-action-search-tabs = 탭 검색
urlbar-result-action-search-actions = 작업 검색
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = { $group } 그룹으로 전환
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } 열기

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = 새 탭에서 열기
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = 새 컨테이너 탭에서 열기
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = 새 창에서 열기
    .accesskey = N
urlbar-view-context-menu-open-in-private-window =
    .label = 새 사생활 보호 창에서 열기
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = 새 탭에서 열기
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = 새 컨테이너 탭에서 열기
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = 새 창에서 열기
    .accesskey = N
urlbar-view-context-menu-open-in-private-window2 = 새 사생활 보호 창에서 열기
    .accesskey = P
urlbar-view-context-menu-search-in-tab = 새 탭에서 검색
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = 새 컨테이너 탭에서 검색
    .accesskey = i
urlbar-view-context-menu-search-in-window = 새 창에서 검색
    .accesskey = N
urlbar-view-context-menu-search-in-private-window = 새 사생활 보호 창에서 검색
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Tab 키를 사용할 때 이 메뉴 건너뛰기
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } 제안
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = 빠른 작업
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = 최근 검색
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } 인기
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = 인기 검색어를 표시하지 않음
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = 인기 검색어를 표시하지 않음
    .accesskey = D
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = 인기 검색어를 표시하지 않음
    .accesskey = D
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = 의견을 보내주셔서 감사합니다. 더 이상 인기 검색어가 표시되지 않습니다.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = 읽기 모드
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = 읽기 모드 닫기

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = 화면 속 화면 열기 ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = 화면 속 화면 닫기 ({ $shortcut })
picture-in-picture-panel-header = 화면 속 화면
picture-in-picture-panel-headline = 이 웹 사이트는 화면 속 화면을 권장하지 않음
picture-in-picture-panel-body = 화면 속 화면을 사용하는 동안 동영상이 개발자가 의도한 대로 표시되지 않을 수 있습니다.
picture-in-picture-enable-toggle =
    .label = 그래도 사용

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 사이트가 전체 화면 모드입니다
fullscreen-warning-no-domain = 이 문서는 전체 화면 모드입니다
fullscreen-exit-button = 전체 화면 종료 (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = 전체 화면 종료 (esc)
fullscreen-keyboardlock-exit-button = 전체 화면 종료 (Esc 키 길게 누르기)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = 전체 화면 종료 (esc 키 길게 누르기)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> 사이트가 포인터를 제어하려 합니다. 다시 제어하려면 ESC 키를 누르세요.
pointerlock-warning-no-domain = 이 문서가 포인터를 제어하려 합니다. 다시 제어하려면 ESC 키를 누르세요.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = 북마크 관리
bookmarks-recent-bookmarks-panel-subheader = 최근 북마크
bookmarks-toolbar-chevron =
    .tooltiptext = 북마크 더보기
bookmarks-sidebar-content =
    .aria-label = 북마크
bookmarks-menu-button =
    .label = 북마크 메뉴
bookmarks-other-bookmarks-menu =
    .label = 기타 북마크
bookmarks-mobile-bookmarks-menu =
    .label = 모바일 북마크

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] 북마크 사이드바 숨기기
           *[other] 북마크 사이드바 표시
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] 북마크 도구 모음 숨기기
           *[other] 북마크 도구 모음 표시
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] 북마크 도구 모음 숨기기
           *[other] 북마크 도구 모음 표시
        }

##

bookmarks-search =
    .label = 북마크 검색
bookmarks-tools =
    .label = 북마크 도구
bookmarks-subview-edit-bookmark =
    .label = 이 북마크 편집…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = 북마크
    .toolbarname = 북마크 도구 모음
    .accesskey = B
bookmarks-toolbar-menu =
    .label = 북마크 도구 모음
bookmarks-toolbar-placeholder =
    .title = 북마크 도구 모음 항목
bookmarks-toolbar-placeholder-button =
    .label = 북마크 도구 모음 항목
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = 현재 탭 북마크…

## Library Panel items

library-bookmarks-menu =
    .label = 북마크

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = 텍스트 인코딩 복구
    .tooltiptext = 페이지 콘텐츠에서 올바른 텍스트 인코딩 추측

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = 설정
    .tooltiptext =
        { PLATFORM() ->
            [macos] 설정 열기 ({ $shortcut })
           *[other] 설정 열기
        }
toolbar-overflow-customize-button =
    .label = 도구 모음 사용자 지정…
    .accesskey = C
toolbar-button-email-link =
    .label = 메일로 링크 보내기
    .tooltiptext = 메일로 이 페이지의 링크 보내기
toolbar-button-logins =
    .label = 비밀번호
    .tooltiptext = 저장된 비밀번호 보기 및 관리
qrcode-panel-error =
    .message = QR 코드 생성에 실패했습니다. 다시 시도하세요.
qrcode-copy-button =
    .label = 복사
qrcode-copy-success =
    .message = QR 코드가 클립보드에 복사되었습니다.
qrcode-copy-error =
    .message = QR 코드를 복사하지 못했습니다.
qrcode-save-button =
    .label = 저장
qrcode-window-title = QR 코드
qrcode-dialog-title = QR 코드
qrcode-image =
    .aria-label = QR 코드
qrcode-close-button =
    .aria-label = 닫기
toolbar-button-save-page =
    .label = 페이지 저장
    .tooltiptext = 이 페이지 저장 ({ $shortcut })
toolbar-button-open-file =
    .label = 파일 열기
    .tooltiptext = 파일 열기 ({ $shortcut })
toolbar-button-synced-tabs =
    .label = 동기화된 탭
    .tooltiptext = 다른 기기의 탭 보기
toolbar-button-send-tab =
    .label = 탭 보내기
    .tooltiptext = 현재 탭을 다른 기기로 보내기
toolbar-button-new-private-window =
    .label = 새 사생활 보호 창
    .tooltiptext = 새 사생활 보호 창 열기 ({ $shortcut })
toolbar-button-share-tab =
    .label = 공유
    .tooltiptext = 이 페이지 공유
toolbar-button-tab-groups =
    .label = 탭 그룹
    .tooltiptext = 탭 그룹 표시
toolbar-button-history =
    .label = 기록
    .tooltiptext = 기록 보기 ({ $shortcut })
toolbar-button-find =
    .label = 찾기
    .tooltiptext = 이 페이지에서 찾기 ({ $shortcut })
toolbar-button-developer =
    .label = 개발자
    .tooltiptext = 웹 개발자 도구 열기 ({ $shortcut })
toolbar-button-forget =
    .label = 삭제
    .tooltiptext = 최근 방문 기록 삭제
toolbar-zoom-controls =
    .label = 확대/축소 컨트롤
    .title = 확대/축소 컨트롤
toolbar-button-zoom-out =
    .label = 축소
    .tooltiptext = 축소 ({ $shortcut })
toolbar-button-zoom-reset-tooltip = 확대/축소 초기화 ({ $shortcut })
toolbar-button-zoom-in =
    .label = 확대
    .tooltiptext = 확대 ({ $shortcut })
toolbar-edit-controls =
    .label = 편집 컨트롤
    .title = 편집 컨트롤
toolbar-button-cut =
    .label = 잘라내기
    .tooltiptext = 잘라내기 ({ $shortcut })
toolbar-button-copy =
    .label = 복사
    .tooltiptext = 복사 ({ $shortcut })
toolbar-button-paste =
    .label = 붙여넣기
    .tooltiptext = 붙여넣기 ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = 이 사이트의 일부 오디오 또는 비디오는 DRM 소프트웨어를 사용하므로 { -brand-short-name }에서 수행할 수 있는 작업이 제한될 수 있습니다.
eme-notifications-drm-content-playing-manage = 설정 관리
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = 닫기
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = 이 페이지에서 일부 오디오 또는 비디오를 재생하려면 DRM을 활성화해야 합니다.
eme-notifications-drm-content-disabled-button =
    .label = DRM 활성화
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name }가 이 페이지에서 오디오나 비디오를 재생하는 데 필요한 구성 요소를 설치하고 있습니다. 나중에 다시 시도하세요.
decoder-doctor-no-codecs-linux-message = 동영상을 재생하기 위해 동영상 코덱을 설치해야 합니다.
decoder-doctor-no-hw-acceleration-message = 동영상 재생 품질을 높이기 위해 Microsoft의 Media Feature Pack을 설치해야 합니다.
decoder-doctor-no-pulse-audio-message = 소리를 재생하기 위해서는 PulseAudio 소프트웨어가 필요합니다.
decoder-doctor-unsupported-libavcodec-message = libavcodec은 취약하거나 지원되지 않을 수 있으므로 동영상을 재생하기 위해서 업데이트되어야 합니다.
decoder-doctor-decode-error-message = 미디어 리소스를 디코딩하는 동안 오류가 발생했습니다.
decoder-doctor-decode-warning-message = 미디어 리소스를 디코딩하는 동안 복구 가능한 오류가 발생했습니다.
decoder-doctor-learn-how-link = 방법 알아보기
decoder-doctor-report-issue-button =
    .label = 이 사이트 문제 보고하기
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = { $pluginName } 플러그인이 충돌했습니다.
plugin-crashed-notification-reload-button =
    .label = 페이지 새로 고침
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = 충돌 보고서 제출
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = 사기 사이트!
safebrowsing-reported-attack-site-message = 보고된 공격 사이트!
safebrowsing-reported-unwanted-site-message = 사용자 동의 없이 설치하는 소프트웨어 사이트로 신고되었습니다!
safebrowsing-reported-harmful-site-message = 유해한 사이트로 신고됨!
safebrowsing-get-me-out-of-here-button =
    .label = 밖으로 나가기!
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = 이 사이트는 사기 사이트가 아닙니다…
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = 공격 사이트 아님…
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = 인터넷을 사용하기 위해선 반드시 이 네트워크에 로그인해야 합니다.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = 네트워크 로그인 페이지 열기

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = { $hostName }로 이동하시겠습니까?
keyword-uri-fixup-go-to-button =
    .label = 예, { $hostName }로 이동합니다
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = 사용자 이름
panel-save-update-password-2 =
    .label = 비밀번호

##

# "More" item in macOS share menu
menu-share-more =
    .label = 더보기…
menu-share-windows =
    .label = 추가 옵션
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label = 링크 { $count }개 복사
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = 닫기

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = { $uriHost }에 대한 팝업 및 제3자 리디렉션 허용
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = 화면 속 화면 전환 버튼 숨기기
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = 화면 속 화면 전환 버튼을 오른쪽으로 이동
    .accesskey = R
picture-in-picture-move-toggle-left =
    .label = 화면 속 화면 전환 버튼을 왼쪽으로 이동
    .accesskey = L

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = 탐색
navbar-downloads =
    .label = 다운로드
navbar-overflow-2 =
    .tooltiptext = 도구 더보기
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = 인쇄
    .tooltiptext = 이 페이지 인쇄… ({ $shortcut })
navbar-home =
    .label = 홈
    .tooltiptext = { -brand-short-name } 홈 페이지
navbar-library =
    .label = 라이브러리
    .tooltiptext = 기록, 저장된 북마크 등 보기
navbar-search =
    .title = 검색
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = 브라우저 탭
tabs-toolbar-new-tab =
    .label = 새 탭
tabs-toolbar-list-all-tabs-2 =
    .label = 탭 검색 및 관리
    .tooltiptext = 탭 검색 및 관리
tabs-toolbar-list-all-tabs =
    .label = 탭 전체 목록
    .tooltiptext = 탭 전체 목록

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = 탭을 고정하려면 여기에 놓으세요

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>이전 탭을 여시겠습니까?</strong> { -brand-short-name } 애플리케이션 메뉴 <img data-l10n-name="icon"/>의 기록 아래에서 이전 세션을 복원할 수 있습니다.
restore-session-startup-suggestion-button = 사용법 보기

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = 조직에서 이 컴퓨터의 로컬 파일에 대한 액세스를 차단했습니다.

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut }는 이제 탭을 검색합니다
urlbar-addons-shortcut-moved-description = 확장 기능 및 테마를 열려면 { $addonsShortcut }를 사용하세요.
urlbar-addons-shortcut-moved-change-shortcuts = 바로 가기 관리
urlbar-addons-shortcut-moved-dismiss = 확인

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = 여러분이 보다 나은 경험을 할 수 있도록 { -brand-short-name }는 { -vendor-short-name }에 자동으로 일부 데이터를 전송합니다.
data-reporting-notification-button =
    .label = 공유할 데이터 선택
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = 사생활 보호 모드
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = 사생활 보호 모드
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = 사생활 보호 모드 정보
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = 현재 사생활 보호 창을 사용 중입니다
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = 이 기기를 함께 사용하는 다른 사람에게는 내 탐색 기록을 숨길 수 있지만, 온라인에서 내 신원을 완전히 감출 수는 없습니다. <a data-l10n-name="learn-more">남이 내 활동을 볼 수 있나요?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = { $agentName }의 데이터 손실 방지(DLP)입니다. 자세한 내용을 보려면 누르세요.
content-analysis-panel-title2 = 데이터 손실 방지
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = 사용자의 조직은 <b>{ $agentName }</b>를 사용하여 민감한 정보가 공유되는 방식을 제어합니다. <a data-l10n-name="info">더 알아보기</a>
content-analysis-panel-title = 데이터 보호
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = 사용자의 조직은 데이터 손실을 막기 위해 <b>{ $agentName }</b> 에이전트를 사용합니다. <a data-l10n-name="info">더 알아보기</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = 확장 기능
    .tooltiptext = 확장 기능

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = 확장 기능
    .tooltiptext =
        확장 기능
        권한 필요

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = 확장 기능
    .tooltiptext =
        확장 기능
        일부 확장 기능은 허용되지 않음

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = 확장 기능
    .tooltiptext =
        확장 기능
        일부 확장 기능이 비활성화됨

## Private browsing reset button

reset-pbm-panel-heading2 = 데이터를 지우고 사생활 보호 세션을 새로 시작하시겠습니까?
reset-pbm-panel-description3 = 기록과 쿠키를 지우고 사이트에서 로그아웃됩니다. 사생활 보호 창이 닫히고 새 창이 열립니다.
reset-pbm-panel-description2 = 사생활 보호 창을 닫지 않고, 기록, 쿠키 및 기타 모든 사이트 데이터를 삭제합니다.
reset-pbm-panel-always-ask-checkbox =
    .label = 항상 묻기
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = 취소
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = 사생활 보호 세션 지우기
    .accesskey = l
reset-pbm-panel-complete = 사생활 보호 데이터 삭제됨
reset-pbm-toolbar-button2 =
    .label = 사생활 보호 세션 지우기
    .tooltiptext = 사생활 보호 세션 지우기

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = 탐색 데이터를 모두 삭제하시겠습니까?
fire-button-panel-description = 기록, 쿠키 및 사이트 데이터를 삭제합니다. 사이트에서 로그아웃됩니다. 이 창은 닫히고 { -brand-short-name }가 새 창을 엽니다.
fire-button-panel-choose-description = 모두 삭제하지 않으려면 특정 데이터를 선택하세요.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = 선택…
fire-button-panel-cancel-button =
    .label = 취소
    .accesskey = C
fire-button-panel-confirm-button =
    .label = 모두 삭제
    .accesskey = D
fire-button-panel-complete = 탐색 데이터 삭제됨
fire-button-toolbar-button2 =
    .label = 데이터 일부 또는 모두 삭제
    .tooltiptext = 탐색 데이터의 일부 또는 모두를 삭제합니다

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name }가 이 페이지를 자동으로 다시 로드하지 못하도록 차단했습니다.
refresh-blocked-redirect-label = { -brand-short-name }가 이 페이지에서 다른 페이지로 자동으로 바뀌는 것을 차단했습니다.
refresh-blocked-allow =
    .label = 허용
    .accesskey = A

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = 안전하고 사용하기 쉬운 가리기는 이메일 주소를 숨김으로써 신원을 보호하고 스팸을 방지합니다.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = 이메일 가리기로 전송된 모든 이메일은 차단하지 않는 한 <strong>{ $useremail }</strong>(으)로 전달됩니다.
firefox-relay-offer-legal-notice = "이메일 가리기 사용"을 클릭하면, <label data-l10n-name="tos-url">이용 약관</label>및 <label data-l10n-name="privacy-url">개인정보처리방침</label>에 동의하는 것입니다.
firefox-relay-offer-legal-notice-1 = 가입하고 이메일 가리기를 생성하면, <label data-l10n-name="tos-url">이용 약관</label>및 <label data-l10n-name="privacy-url">개인정보처리방침</label>에 동의하는 것입니다.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (확인되지 않음)
popup-notification-xpinstall-prompt-learn-more = 부가 기능을 안전하게 설치하는 방법에 대해 더 알아보기
popup-notification-xpinstall-prompt-block-url = 상세 보기
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = 확장 기능이 사생활 보호 창에서 실행되도록 허용
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = 확장 기능 개발자와 기술 및 상호 작용 데이터 공유
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message = { -brand-short-name }가 이 사이트에서 팝업 창 { $popupCount }개를 차단했습니다.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name }가 이 사이트에서 리디렉션을 차단했습니다.
        [1] { -brand-short-name }가 이 사이트에서 팝업 창을 열고 리디렉션하는 것을 차단했습니다.
       *[other] { -brand-short-name }가 이 사이트에서 팝업 창 { $popupCount }개를 열고 리디렉션하는 것을 차단했습니다.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name }가 이 사이트에서 팝업 창 { $popupCount }개 이상을 차단했습니다.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message = { -brand-short-name }가 이 사이트에서 팝업 창 { $popupCount }개 이상을 열고 리디렉션하는 것을 차단했습니다.
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] 옵션
           *[other] 환경 설정
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = 표시: “{ $popupURI }”
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = 표시: “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Windows 파일 대화 상자를 열 수 없습니다. 파일이나 폴더를 선택할 수 없습니다.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Windows 파일 대화 상자를 열 수 없습니다. 파일은 { $path }에 저장됩니다.
file-picker-failed-save-nowhere = Windows 파일 대화 상자를 열 수 없습니다. 기본 폴더를 찾을 수 없습니다. 파일은 저장되지 않습니다.
file-picker-crashed-open = Windows 파일 대화 상자가 충돌했습니다. 파일이나 폴더를 선택할 수 없습니다.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows 파일 대화 상자가 충돌했습니다. 파일은 { $path }에 저장됩니다.
file-picker-crashed-save-nowhere = Windows 파일 대화 상자가 충돌했습니다. 기본 폴더를 찾을 수 없습니다. 파일은 저장되지 않습니다.
file-picker-crashed-show-in-folder =
    .label = 폴더에서 보기
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = 설치된 하나 이상의 부가 기능을 확인할 수 없어 비활성화되었습니다.
unsigned-addons-disabled-learn-more =
    .label = 더 알아보기
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = 이 페이지가 { -brand-short-name }를 느리게 하고 있습니다. 브라우저를 빠르게 하려면 이 페이지를 중지하세요.
process-hang-nonspecific-tab-message = 웹 페이지가 { -brand-short-name }를 느리게 하고 있습니다. 브라우저를 빠르게 하려면 해당 페이지를 중지하세요.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” 탭이 { -brand-short-name }를 느리게 하고 있습니다. 브라우저를 빠르게 하려면 해당 페이지를 중지하세요.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” 확장 기능이 { -brand-short-name }를 느리게 하고 있습니다. 브라우저를 빠르게 하려면 해당 확장 기능을 중지하세요.
process-hang-addon-learn-more =
    .value = 더 알아보기
process-hang-stop-button =
    .label = 중지
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = 설정 완료
onboarding-aw-finish-setup-button =
    .label = 설정 완료
    .tooltiptext = { -brand-short-name } 설정 완료

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = 향상된 추적 방지 기능 켜짐
trustpanel-etp-label-disabled = 향상된 추적 방지 기능 꺼짐
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = 향상된 추적 방지 기능: { $host }에 대해 켜짐
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = 향상된 추적 방지 기능: { $host }에 대해 꺼짐
trustpanel-etp-description-enabled = 이 사이트가 손상되어 보이면 보호 기능을 꺼보세요.
trustpanel-etp-description-disabled = { -brand-product-name }는 기업들이 사용자를 덜 추적해야 한다고 생각합니다. 보호 기능을 켜면 가능한 한 많은 추적기를 차단합니다.
trustpanel-trackercount-label = 주소 표시줄에 차단된 추적기 수 표시
trustpanel-trackercount-toggle =
    .aria-label = 주소 표시줄에 차단된 추적기 수 표시
trustpanel-connection-label-secure = 안전한 연결
trustpanel-connection-label-insecure = 안전하지 않은 연결
trustpanel-header-enabled = { -brand-product-name }가 감시 중
trustpanel-description-enabled2 = 보호 중입니다. 문제가 발견되면 알려드리겠습니다.
trustpanel-header-enabled-insecure = 이 사이트를 조심하세요
trustpanel-description-enabled-insecure = { -brand-product-name }가 수상한 것을 발견했습니다.
trustpanel-header-disabled = 보호 기능을 사용 중지함
trustpanel-description-disabled = { -brand-product-name }가 비번 상태입니다. 보호 기능을 다시 켜는 것이 좋습니다.
trustpanel-clear-cookies-button = 쿠키 및 사이트 데이터 지우기
trustpanel-privacy-link = 개인 정보 설정
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = { $host }의 쿠키 및 사이트 데이터 지우기
trustpanel-clear-cookies-description = 쿠키와 사이트 데이터를 제거하면 웹사이트에서 로그아웃되고 장바구니가 비워질 수 있습니다.
trustpanel-clear-cookies-subview-button-clear = 지우기
trustpanel-clear-cookies-subview-button-cancel = 취소
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = { $host }에 대한 연결 보호
trustpanel-siteinformation-morelink = 사이트 정보 더보기
trustpanel-blocker-see-all = 모두 보기
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = { $host }에 대한 추적 방지
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = 안전하지 않음
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label = 추적기 { $count }개 차단됨

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name }는 기업들이 사용자를 덜 추적해야 한다고 생각합니다. 그래서 저희는 가능한 한 많이 차단합니다.
trustpanel-blocked-header = { -brand-product-name }가 다음 항목을 차단했습니다:
trustpanel-tracking-header = { -brand-product-name }가 사이트가 깨지지 않도록 다음 항목을 허용했습니다:
trustpanel-tracking-description = 추적기가 없으면 일부 버튼, 양식 및 로그인 필드가 작동하지 않을 수 있습니다.
trustpanel-insecure-section-header = 연결이 안전하지 않음
trustpanel-insecure-description = 사용자가 이 사이트에 보내는 데이터는 암호화되지 않습니다. 이 데이터는 열람, 도난 또는 변조될 수 있습니다.
trustpanel-list-label-tracking-cookies = { $count }개의 교차 사이트 추적 쿠키
trustpanel-list-label-tracking-content = 추적 콘텐츠
trustpanel-list-label-fingerprinter = { $count }개의 디지털 지문
trustpanel-list-label-social-tracking = { $count }개의 소셜 미디어 추적기
trustpanel-list-label-cryptominer = { $count }개의 암호화폐 채굴기
trustpanel-social-tracking-blocking-tab-header = { -brand-product-name }가 소셜 미디어 추적기 { $count }개를 차단함
trustpanel-social-tracking-not-blocking-tab-header = { -brand-product-name }가 소셜 미디어 추적기 { $count }개를 허용함
trustpanel-tracking-cookies-blocking-tab-header = { -brand-product-name }가 교차 사이트 추적 쿠키 { $count }개를 차단함
trustpanel-tracking-cookies-not-blocking-tab-header = { -brand-product-name }가 교차 사이트 추적 쿠키 { $count }개를 허용함
trustpanel-tracking-content-blocking-tab-header = { -brand-product-name }가 추적기 { $count }개를 차단함
trustpanel-tracking-content-not-blocking-tab-header = { -brand-product-name }가 추적기 { $count }개를 허용함
trustpanel-tracking-content-tab-list-header = 다음 사이트가 사용자를 추적하고 있습니다:
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name }가 디지털 지문 { $count }개를 차단함
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name }가 디지털 지문 { $count }개를 허용함
trustpanel-fingerprinter-list-header = 다음 사이트가 디지털 지문을 수집하려고 합니다:
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name }가 암호화폐 채굴기 { $count }개를 차단함
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name }가 암호화폐 채굴기 { $count }개를 허용함
trustpanel-cryptominer-tab-list-header = 다음 사이트는 암호화폐 채굴을 시도합니다:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = 이 사이트의 계정을 가지고 계십니까?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name }가 최근 12개월 동안 이 사이트에서 데이터 유출이 발생했음을 확인했습니다. 사용자가 영향을 받았는지 확인해 보세요.
trustpanel-breachalerts-anonymous-breached-button-dismiss = 닫기
trustpanel-breachalerts-anonymous-breached-button-check-monitor = 무료 스캔 시작
trustpanel-blocker-section-header2 = 이 사이트에서 추적기 <span data-l10n-name="count">{ $count }</span>개 차단됨

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>사이트가 손상된 것 같나요?</strong> 추적 방지 기능을 일시적으로 낮추려면 페이지를 새로 고침하세요.
reduced-protection-infobar-reload-button = 새로 고침
    .accesskey = R
reduced-protection-infobar-never-show-button = 다시 표시 안 함
    .accesskey = D


identity-allow-site-data = 이 사이트의 쿠키/데이터를 항상 저장
urlbar-webgl-notification-anchor =
    .tooltiptext = WebGL 컨텍스트 생성 권한 관리
urlbar-webgl-blocked =
    .tooltiptext = 이 웹사이트에 대한 WebGL 컨텍스트 생성을 차단했습니다.
