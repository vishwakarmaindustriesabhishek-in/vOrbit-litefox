# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

global-privacy-control-description =
    .label = ウェブサイトにユーザーデータの販売や共有の拒否を通知する
    .accesskey = s
non-technical-privacy-group =
    .label = ウェブサイトのプライバシー設定
do-not-track-removal3 =
    .message = “Do Not Track” 機能のサポートは終了しました。
non-technical-privacy-heading =
    .label = 追加の保護
preferences-privacy-relay-available =
    .label = { -relay-brand-name } メールマスクのご提案
    .description = 受信トレイをスパムから守るため、本当のメールアドレスを隠します。
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = 設定
category-nav-heading =
    .heading = 設定
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .style = width: 15.4em
    .placeholder = 設定を検索
managed-notice = ご使用のブラウザーはあなたの所属組織に管理されています。
managed-notice-info-icon =
    .alt = 情報
managed-notice-nav =
    .label = ご使用のブラウザーはあなたの所属組織に管理されています。
tls-key-logging-notice-nav =
    .label = 使用中のアプリまたはサービスは暗号化された通信を見ることができます。
category-list =
    .aria-label = カテゴリー
pane-general-title = 一般
pane-home-title = ホーム
pane-home-startup-title2 = ホームと起動
    .title = ホームと起動
pane-search-title2 = 検索
    .title = 検索
pane-privacy-title3 = プライバシーとセキュリティ
    .title = プライバシーとセキュリティ
pane-privacy-section =
    .heading = プライバシーとセキュリティ
pane-sync-title3 = 同期
pane-ai-controls-title2 = AI 制御
    .title = AI 制御
pane-about-firefox-title = { -brand-short-name } について
    .title = { pane-about-firefox-title }
pane-appearance-title = 外観
    .title = { pane-appearance-title }
pane-downloads-title2 = ダウンロード
    .title = ダウンロード
pane-downloads3 =
    .heading = ダウンロード
pane-accessibility-title = アクセシビリティ
    .title = { pane-accessibility-title }
pane-languages-title2 = 言語
    .title = 言語
preferences-languages-header3 =
    .heading = 言語
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = 実験的な機能をお試しください！ 現在開発中ですが、{ -brand-short-name } の動作にインパクトを与えることでしょう。私たちは <a data-l10n-name="data-collection">技術データと対話データの送信</a> をオンにしている場合のみ、これらの機能の使用データを受け取ります。
pane-experimental-reset =
    .label = 既定値に戻す
    .accesskey = R
help-button-label2 = { -brand-short-name } サポート
    .title = { -brand-short-name } サポート
addons-button-label2 = 拡張機能とテーマ
    .title = 拡張機能とテーマ
focus-search =
    .key = f
close-button =
    .aria-label = 閉じる
do-not-track-removal2 =
    .label = “Do Not Track” 信号のサポートは終了しました
applications-setting-new-file-types =
    .label = 他のファイルは { -brand-short-name } でどのように扱いますか？

## Browser Restart Dialog

feature-enable-requires-restart = この機能を有効にするには、{ -brand-short-name } の再起動が必要です
feature-disable-requires-restart = この機能を無効にするには、{ -brand-short-name } の再起動が必要です
should-restart-title = { -brand-short-name } を再起動
should-restart-ok = { -brand-short-name } を今すぐ再起動
cancel-no-restart-button = キャンセル
restart-later = 後で再起動

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> がこの設定を制御しています。
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> がこの設定を制御しています。
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> がコンテナータブを必要としています。
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> がこの設定を制御しています。
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name="icon"/> <strong>{ $name }</strong> が { -brand-short-name } のインターネット接続方法を制御しています。
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = 拡張機能を有効にするには、<img data-l10n-name="menu-icon"/> メニューから <img data-l10n-name="addons-icon"/> アドオンを開いてください。
extension-controlled-enable-2 = 拡張機能を再び有効にするには、<a data-l10n-name="addons-link">拡張機能とテーマ</a> を開いてください。
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } がホームページ設定の一部を制御しています。

## Preferences UI Search Results

search-results-header = 検索結果
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = 申し訳ありません。“<span data-l10n-name="query"></span>” の設定についての検索結果はありません。
search-results-help-link = ヘルプが必要な方は、<a data-l10n-name="url">{ -brand-short-name } サポート</a> をご利用ください

## General Section

always-check-default =
    .label = { -brand-short-name } が既定のブラウザーか確認する
    .accesskey = y
startup-restore-windows-and-tabs =
    .label = 前回のウィンドウとタブを開く
    .accesskey = s
startup-windows-launch-on-login-profile-disabled =
    .message = この設定を有効にするには、[ユーザープロファイルの選択] ウィンドウで [{ profile-manager-use-selected.label }] にチェックを入れてください。
windows-launch-on-login =
    .label = コンピューターの起動時に { -brand-short-name } を自動的に開く
    .accesskey = O
windows-launch-on-login-disabled = この設定は Windows で無効化されています。変更するには、システム設定の <a data-l10n-name="startup-link">スタートアップ アプリ</a> から設定してください。
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = 新しいタブも開く
    .accesskey = n
disable-extension =
    .label = 拡張機能を無効化
preferences-data-migration-group =
    .label = ブラウザーデータのインポート
    .description = 別のブラウザーからブックマークやパスワード、履歴、拡張機能、自動入力データを移行します。
preferences-data-migration-button =
    .label = データをインポート
    .accesskey = m
preferences-profiles-group-header =
    .heading = プロファイル
preferences-profiles-subpane-description =
    .description = 各プロファイルには、閲覧履歴やパスワードなど個別の閲覧データと設定が保持されています。
preferences-profiles-section-header =
    .label = プロファイル
    .description = 各プロファイルには、閲覧履歴やパスワードなど個別の閲覧データと設定が保持されています。
preferences-manage-profiles-button =
    .label = プロファイルを管理
preferences-profiles-settings-button =
    .label = 設定
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .label = 既存のプロファイルをコピー
    .description = 新しいプロファイルにブックマークやパスワードなどの保存しているデータと設定、アドオン、閲覧履歴をコピーします。アカウントや同期情報はコピーしません。
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = コピーするプロファイル
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = プロファイルを選択
preferences-copy-profile-button = コピー
tabs-browsing-section =
    .heading = タブとブラウジング
pane-tabs-browsing-title2 = タブとブラウジング
    .title = タブとブラウジング
tabs-group-header2 =
    .label = タブグループ
tabs-opening-heading =
    .label = 開き方
tabs-interaction-heading =
    .label = 操作
tabs-containers-heading =
    .label = コンテナー
tabs-closing-heading =
    .label = 閉じ方
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab で最近使用した順にタブを切り替える
    .accesskey = T
open-new-link-as-tabs =
    .label = 新しいウィンドウではなく新しいタブに開く
    .accesskey = w
open-external-link-next-to-active-tab =
    .label = アプリからのリンクを使用中のタブの隣に開く
ask-on-close-multiple-tabs =
    .label = 同時に複数のタブを閉じる前に確認する
    .accesskey = m
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = { $quitKey } キーで終了する前に確認する
    .accesskey = b
warn-on-open-many-tabs =
    .label = 同時に複数のタブを開いて { -brand-short-name } の動作が遅くなるときは確認する
    .accesskey = d
switch-to-new-tabs-2 =
    .label = 新しいタブでリンクやメディアを開いた時、すぐにそのタブに切り替える
    .accesskey = h
show-tabs-in-taskbar =
    .label = タスクバーにタブのプレビューを表示する
    .accesskey = k
browser-containers-enabled-2 =
    .label = コンテナータブを使用する
    .accesskey = n
browser-containers-learn-more = 詳細情報
browser-containers-settings-2 =
    .label = 設定を管理
    .accesskey = i
containers-disable-alert-title = すべてのコンテナータブを閉じますか？
startup-group =
    .label = 起動

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc = コンテナータブを無効にすると、{ $tabCount } 個のコンテナータブが閉じられます。コンテナータブを無効にしますか？
containers-disable-alert-ok-button = { $tabCount } 個のコンテナータブを閉じる

##

containers-disable-alert-cancel-button = このままにする
containers-remove-alert-title = このコンテナーを削除しますか？
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg = このコンテナーを削除すると { $count } 個のコンテナータブが閉じられます。このコンテナーを削除してもよろしいですか？
containers-remove-ok-button = このコンテナーを削除する
containers-remove-cancel-button = 削除しない
settings-tabs-show-image-in-preview =
    .label = タブにカーソルを合わせた時にプレビュー画像を表示する
    .accessKey = h
settings-tabs-drag-to-create-tab-groups =
    .label = まとめてドラッグしたタブでタブグループを作成する
browser-layout-header2 =
    .label = ブラウザーレイアウト
browser-layout-horizontal-tabs2 =
    .label = 水平タブ
    .title = タブを上部に配置します
    .description = タブを上部に配置します
browser-layout-vertical-tabs2 =
    .label = 垂直タブ
    .title = タブをサイドバー内に配置します
    .description = タブをサイドバー内に配置します
browser-layout-show-sidebar2 =
    .label = サイドバーを表示
    .description = ブックマーク、同期したタブ、AI チャットボットなど、メインビューを切り替えずにすばやくアクセスできます。
page-navigation-group =
    .label = ページナビゲーション

## General Section - Language & Appearance

language-and-appearance-header = 言語と外観
appearance-group2 =
    .label = ウェブサイトの外観
    .description = 一部のウェブサイトはユーザー設定に合わせて配色を変更します。カラースキームを選んでください。
preferences-web-appearance-choice-auto3 =
    .label = システム
    .title = システムの設定と { -brand-short-name } のテーマをもとに、ウェブサイトの背景と内容を自動的に設定する。
preferences-web-appearance-choice-light2 =
    .label = ライト
    .title = 明るい外観をウェブサイトの背景と内容に使用します。
preferences-web-appearance-choice-dark2 =
    .label = ダーク
    .title = 暗い外観をウェブサイトの背景と内容に使用します。
web-appearance-group =
    .aria-label = ウェブサイトの外観
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = コントラスト制御の設定でウェブサイトの外観を上書きします。
preferences-web-appearance-link =
    .label = 拡張機能とテーマで { -brand-short-name } のテーマを管理する
preferences-contrast-control-group =
    .label = ウェブサイトのコントラスト
    .description = ウェブサイトは様々な前景色と背景色を使用しています。コントラストを均一にするため、ウェブサイトが同じ配色を使用するように設定します。
preferences-contrast-control-radio-group =
    .label = 配色を上書き
preferences-contrast-control-use-platform-settings =
    .label = 自動 (システム設定を使用)
    .accesskey = A
preferences-contrast-control-off =
    .label = オフ
    .accesskey = O
preferences-contrast-control-custom =
    .label = カスタム
    .accesskey = C
preferences-colors-manage-button2 =
    .label = 配色の管理
    .accesskey = C
preferences-colors-manage-button =
    .label = 配色の管理...
    .accesskey = C
preferences-fonts-header2 =
    .label = フォント
preferences-default-zoom-label =
    .label = 既定のズーム
    .accesskey = z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = 文字サイズのみ変更する
    .accesskey = t
preferences-text-zoom-override-warning2 =
    .message = [文字サイズのみ変更] がオンで既定のズームが 100% でない場合、一部のサイトがコンテンツを正しく表示できない可能性があります。
language-header = 言語
choose-language-description = ウェブページの表示に使用する言語の優先順位を設定できます。
website-language-heading =
    .label = ウェブサイトの言語
    .description = 一部のウェブサイトは複数の言語で表示されています。優先的に表示する言語の順序を指定してください。
website-preferred-language =
    .label = 優先言語
website-language-list =
    .aria-label = 優先言語
website-add-language =
    .label = 言語を追加
website-add-language-button =
    .aria-label = 選択した言語を追加します
    .title = 選択した言語を追加します
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = { $locale } を削除
    .title = { $locale } を削除します
choose-button =
    .label = 言語設定...
    .accesskey = o
choose-browser-language-description = メニュー、メッセージ、{ -brand-short-name } からの通知に表示される言語を選択します。
manage-browser-languages-button =
    .label = 代替言語を設定...
    .accesskey = l
confirm-browser-language-change-description = 変更を適用するには、{ -brand-short-name } の再起動が必要です
confirm-browser-language-change-button = 適用して再起動
browser-language-heading =
    .label = ブラウザーの言語
    .description = メニューやメッセージ、{ -brand-short-name } からの通知の表示に使用される言語を選んでください。
browser-language-preferred-label =
    .label = 優先言語
browser-language-fallback-label =
    .label = 代替言語
    .description = 優先言語のローカライズが不完全な場合に使用されます。
browser-language-install-error =
    .message = { -brand-short-name } は現在、言語を更新できません。インターネット接続を確認して、もう一度試してください。
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = 例外...
    .accesskey = x
settings-translations-header =
    .label = 翻訳
    .aria-label = 翻訳
    .description = ページまたは選択したテキストを翻訳します。ユーザーのプライバシーを保護するため、翻訳は端末上で処理されます。
settings-translations-offer-to-translate-label =
    .label = ページ全体の翻訳を使用する
settings-translations-more-settings-button =
    .label = 他の翻訳設定
    .description = 言語、ウェブサイト、オフライン翻訳の設定。
settings-translations-subpage-header =
    .heading = 他の翻訳設定
settings-translations-subpage-speed-up-translation-header =
    .label = 翻訳速度を向上
    .description = 高速な翻訳とオフライン翻訳のために言語ファイルをダウンロードします。
settings-translations-subpage-automatic-translation-header =
    .label = 自動翻訳
settings-translations-subpage-always-translate-header =
    .label = 以下の言語は常に翻訳します
settings-translations-subpage-never-translate-header =
    .label = 以下の言語は翻訳しません
settings-translations-subpage-never-translate-sites-header =
    .label = 以下のサイトは翻訳しません
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = サイトを追加するには <img data-l10n-name="translations-icon"/> 翻訳パネルを開いて <img data-l10n-name="settings-icon"/> 翻訳設定を選択し、[このサイトを翻訳しない] を選択してください。
settings-translations-subpage-language-select-option =
    .label = 言語を追加
settings-translations-subpage-language-add-button =
    .aria-label = 言語を追加
    .title = 言語を追加します
settings-translations-subpage-download-languages-header =
    .label = 言語ファイルをダウンロード
settings-translations-subpage-download-languages-select-option =
    .label = 言語を選択
settings-translations-subpage-download-languages-button =
    .aria-label = 言語ファイルをダウンロード
    .title = 言語ファイルをダウンロードします
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = ダウンロードした言語ファイルはありません
settings-translations-subpage-no-languages-added =
    .label = 追加した言語はありません
settings-translations-subpage-download-progress = ダウンロードしています...
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = { $language } ({ $size } MB) をダウンロードできませんでした
settings-translations-subpage-download-retry-button =
    .label = 再試行
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = { $language } ({ $size } MB) を削除しますか？
settings-translations-subpage-download-delete-button =
    .label = 削除
settings-translations-subpage-download-cancel-button =
    .label = キャンセル
settings-translations-subpage-no-sites-added =
    .label = 追加したサイトはありません
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = 日付、時刻、数値、寸法の書式に、OS の “{ $localeName }” の設定を使う
settings-spellcheck-header =
    .label = スペルチェック
check-user-spelling =
    .label = 自動スペルチェック機能を使用する
    .accesskey = t
spellcheck-download-dictionaries =
    .label = 辞書をダウンロード
spellcheck-promo =
    .heading = スペルチェック機能の使い方
    .message = テキストフィールドで右クリックしてスペルチェックのオンとオフを切り替えるか、言語を変更します。テキストフィールドの種類によってスペルチェックが利用できない場合があります。

## General Section - Files and Applications

files-and-applications-title = ファイルとプログラム
download-save-files-header =
    .label = 次のフォルダーに保存する
download-save-where-3 =
    .aria-label = 次のフォルダーに保存する
download-always-ask-where2 =
    .label = ダウンロードする前にファイルの保存先を尋ねる
    .accesskey = A
download-private-browsing-delete2 =
    .label = プライベートウィンドウを閉じるとき、ダウンロードしたファイルを削除する
    .accesskey = D
applications-header = プログラム
applications-description = ウェブからダウンロードしたファイルを { -brand-short-name } が取り扱う方法と閲覧中に使用するプログラムを選んでください。
applications-setting2 =
    .label = ファイルとプログラム
    .description = ダウンロードしたファイルとコンテンツを { -brand-short-name } が取り扱う方法を選んでください。
applications-filter =
    .placeholder = ファイルの種類とプログラムを検索します
applications-type-column =
    .label = ファイルの種類 (Content Type)
    .accesskey = T
applications-type-heading = ファイルの種類
applications-action-column =
    .label = 取り扱い方法
    .accesskey = A
applications-action-heading = 取り扱い方法
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = { $extension } ファイル
applications-action-save =
    .label = ファイルを保存
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = { $app-name } を使用
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = { $app-name } を使用 (標準設定)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] macOS の既定のプログラムを使用
            [windows] Windows の既定のプログラムを使用
           *[other] システムの既定のプログラムを使用
        }
applications-use-other =
    .label = 他のプログラムを選択...
applications-select-helper = プログラムの選択
applications-manage-app =
    .label = プログラムの管理...
applications-always-ask =
    .label = 毎回確認する
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = { -brand-short-name } で開く

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = 他のファイルは { -brand-short-name } でどのように扱いますか？
applications-save-for-new-types =
    .label = ファイルを保存する
    .accesskey = S
applications-save-for-new-types2 =
    .label = 自動的にファイルを保存する
    .accesskey = S
applications-ask-before-handling =
    .label = ファイルを開くか保存するかを確認する
    .accesskey = A
applications-ask-before-handling2 =
    .label = ファイルを開くか保存するかを確認する
    .accesskey = A
drm-group =
    .label = デジタル著作権管理 (DRM) コンテンツ
play-drm-content =
    .label = DRM 制御のコンテンツを再生する
    .accesskey = P
play-drm-content-learn-more = 詳細情報
# Variables:
# $version (string) - Firefox version
update-application-version = バージョン { $version } <a data-l10n-name="learn-more">更新情報</a>
update-history-2 =
    .label = 更新履歴を表示
    .accesskey = p
update-application-installation =
    .label = インストール
update-application-radio-group =
    .aria-label = インストール
update-application-auto-2 =
    .label = 更新を自動的にインストールする (推奨)
    .accesskey = A
update-application-check-choose-2 =
    .label = 更新を確認するが、いつインストールするか選択する
    .accesskey = C
update-application-background-enabled =
    .label = { -brand-short-name } を実行していない時に更新する
    .accesskey = W
update-application-warning-cross-user-setting-2 =
    .message = この設定はこの端末のすべての Windows アカウントと、この { -brand-short-name } のインストール先を使用するすべての { -brand-short-name } プロファイルに適用されます。
update-application-suppress-prompts-2 =
    .label = 更新の通知を減らす
    .accesskey = n
update-setting-write-failure-title2 = 設定変更の保存エラー
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } がエラーに遭遇したため変更を保存できませんでした。この設定変更を保存するには、以下のファイルの書き込み権限が必要なことに注意してください。あなたかシステム管理者が、このファイルにユーザーグループのフルコントロール権限を与えると、エラーを解決できる可能性があります。
    
    ファイルに書き込めません: { $path }
update-in-progress-title = 更新中
update-in-progress-message = { -brand-short-name } の更新を続行しますか？
update-in-progress-ok-button = 破棄(&D)
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = 続行(&C)

## About Firefox

about-firefox-header =
    .heading = { -brand-short-name } について

## Firefox updates

update-application-heading =
    .label = { -brand-short-name } の更新
    .description = 更新により { -brand-short-name } の速度、安定性、安全性が向上します。
update-application-suppress-prompts-heading =
    .label = 通知
update-application-updates-managed-by-os =
    .message = 更新はご使用のオペレーティングシステムにより管理されています

## Firefox support

support-application-heading =
    .label = { -brand-short-name } サポート
    .description = 問題の解決やコミュニティとアイデアの共有ができます。
support-get-help =
    .label = ヘルプを表示
support-share-ideas =
    .label = アイデアとフィードバックを共有

## General Section - Performance

performance-settings-learn-more = 詳細情報
performance-allow-hw-accel =
    .label = ハードウェアアクセラレーション機能を使用する (可能な場合)
    .accesskey = r
performance-limit-content-process-option = コンテンツプロセス数の制限
    .accesskey = l
performance-limit-content-process-enabled-desc = コンテンツプロセスを増やすと、複数タブの使用時にパフォーマンスが向上しますが、メモリーを多く消費します。
performance-limit-content-process-blocked-desc = コンテンツプロセスの数はマルチプロセスの { -brand-short-name } でしか変更できません。 <a data-l10n-name="learn-more">マルチプロセスが有効になっているか確認してください</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (既定)
performance-group =
    .label = パフォーマンス
performance-use-recommended-settings-checkbox-2 =
    .label = 推奨のパフォーマンス設定を使用する
    .description = これらはご使用のハードウェアとオペレーティングシステムに合わせて設定されます。
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = 自動スクロール機能を使用する
    .accesskey = a
keyboard-and-scrolling-group =
    .label = キーボード移動とスクロール
motion-and-link-group =
    .label = 動きとリンクのスタイル
browsing-use-smooth-scrolling =
    .label = スムーズスクロール機能を使用する
    .accesskey = m
browsing-gtk-use-non-overlay-scrollbars =
    .label = 常にスクロールバーを表示する
    .accesskey = o
browsing-always-underline-links =
    .label = 常にリンクに下線を付ける
    .accesskey = u
browsing-use-onscreen-keyboard =
    .label = 必要であればタッチキーボードを表示する
    .accesskey = c
browsing-use-cursor-navigation =
    .label = ページ中の移動にカーソルを使用する (キャレットブラウジングモード)
    .accesskey = k
browsing-use-full-keyboard-navigation =
    .label = タブキーでフォームコントロールおよびリンク間のフォーカスを移動する
    .accesskey = t
browsing-search-on-start-typing =
    .label = キー入力時に検索を開始する
    .accesskey = x
settings-keyboard-shortcuts-group =
    .label = キーボードショートカット
    .description = { -brand-short-name } を操作するキーを制御します。
settings-keyboard-shortcuts-customkeys-link =
    .label = キーボードショートカットをカスタマイズ
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = 検索時のアドレスバーの設定をカスタマイズ
settings-media-group =
    .label = メディア
browsing-picture-in-picture-toggle-enabled-2 =
    .label = ピクチャーインピクチャーモードを使用する
    .accesskey = e
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = タブを切り替えた時、再生中の動画をピクチャーインピクチャーモードにする
    .accesskey = s
browsing-media-control =
    .label = メディアをキーボード、ヘッドセット、仮想インターフェイスで操作する
    .accesskey = v
recommendations-group =
    .label = おすすめ
browsing-cfr-recommendations =
    .label = おすすめの拡張機能を紹介する
    .accesskey = R
browsing-cfr-features =
    .label = おすすめの機能を紹介する
    .accesskey = f
browsing-group =
    .label = ブラウジング

## Accessibility page

preferences-accessibility-header =
    .heading = アクセシビリティ
preferences-default-zoom-select =
    .aria-label = 既定のズーム
preferences-fonts-family =
    .label = フォントファミリー
    .accesskey = D
preferences-fonts-size =
    .label = フォントサイズ
    .accesskey = s
preferences-fonts-advanced-settings =
    .label = 詳細設定
    .accesskey = A

## General Section - Proxy

network-proxy-group2 =
    .label = プロキシー設定
    .description = { -brand-short-name } のインターネットへの接続方法を設定します。
network-proxy-connection-settings2 =
    .label = プロキシーを設定
    .description = これらの設定を変更すると接続の問題の原因となることがあります
    .accesskey = p

## Home Section

home-new-windows-tabs-header = 新しいウィンドウとタブ
home-new-windows-tabs-description2 = ホームページ、新しいウィンドウ、新しいタブを開くときに表示するものを選択してください。
home-section =
    .heading = ホームと起動

## Home Section - Default Browser

home-default-browser-title =
    .label = 既定のブラウザー
is-default-browser-2 =
    .message = { -brand-short-name } が既定のブラウザーに設定されています。😊
is-not-default-browser-2 =
    .message = { -brand-short-name } が既定に設定されていないようです。
set-as-my-default-browser-2 =
    .label = 既定のブラウザーにする
    .accesskey = D

## Custom Homepage subpage

home-homepage-mode-label = ホームページと新しいウィンドウ
home-newtabs-mode-label = 新しいタブ
home-restore-defaults =
    .label = 既定値に戻す
    .accesskey = R
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (既定)
home-mode-choice-custom =
    .label = カスタム URL...
home-mode-choice-blank =
    .label = 空白ページ
home-homepage-custom-url =
    .placeholder = URL を貼り付け...
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = 拡張機能を管理
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] 現在のページを使用
           *[other] 現在のすべてのページを使用
        }
    .accesskey = C
choose-bookmark =
    .label = ブックマークを使用...
    .accesskey = B
home-homepage-title =
    .label = ホームページ
home-homepage-new-windows =
    .label = 新しいウィンドウ
home-homepage-new-tabs =
    .label = 新しいタブ
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = 特定のサイトを選択
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = ウェブサイトのアドレス
home-custom-homepage-list =
    .aria-label = ウェブサイトのアドレス
home-custom-homepage-address =
    .placeholder = アドレスを入力してください
home-custom-homepage-address-button =
    .label = アドレスを追加
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = ウェブサイトがまだ追加されていません。
home-custom-homepage-delete-address-button =
    .aria-label = アドレスを削除
    .title = アドレスを削除します
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = 置き換え:
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = 現在開いているページ
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = ブックマーク...
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = 拡張機能 ({ $extension })

## Custom Homepage subpage

home-custom-homepage-header = カスタムホームページ
home-custom-homepage-subpage =
    .heading = カスタムホームページ

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name } コンテンツ
home-prefs-content-description2 = { -firefox-home-brand-name } に表示するコンテンツを選んでください。
home-prefs-search-header =
    .label = ウェブ検索
home-prefs-shortcuts-header =
    .label = ショートカット
home-prefs-shortcuts-description = 保存または訪問したサイト
home-prefs-shortcuts-by-option-sponsored =
    .label = 広告ショートカット

## Home Section - Firefox Home Content Customization

home-prefs-recommended-by-header-generic =
    .label = おすすめのストーリー
home-prefs-recommended-by-description-generic = { -brand-product-name } ファミリーに選ばれた優良コンテンツ
home-prefs-stories-header =
    .label = ストーリー
home-prefs-stories-description = ユーザーの行動に基づいてパーソナライズされたストーリー

##

home-prefs-recommended-by-learn-more = 使い方
home-prefs-recommended-by-option-sponsored-stories =
    .label = 広告記事
home-prefs-highlights-option-visited-pages =
    .label = 訪れたページ
home-prefs-highlights-options-bookmarks =
    .label = ブックマーク
home-prefs-highlights-option-most-recent-download =
    .label = 最近のダウンロード
home-prefs-recent-activity-header =
    .label = 最近のアクティビティ
home-prefs-recent-activity-description = 最近のサイトとコンテンツの抜粋
home-prefs-weather-header =
    .label = 天気予報
home-prefs-weather-description = 一目でわかる今日の天気
home-prefs-weather-learn-more-link = 詳細情報
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = { -brand-product-name } を支援
home-prefs-mission-message = スポンサーは、より良いウェブを構築するという私たちの使命を支援しています。
home-prefs-mission-message-learn-more-link = 支援の詳細情報
home-prefs-manage-topics-link = トピックを管理
home-prefs-choose-wallpaper-link = 壁紙を選択
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label = { $num } 行

## Search Section

search-show-suggestions-option =
    .label = 検索候補を表示する
    .accesskey = S
search-show-suggestions-url-bar-option =
    .label = アドレスバーに検索候補を表示する
    .accesskey = l
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = アドレスバーの検索結果で閲覧履歴の前に検索候補を表示する
search-show-suggestions-private-windows-2 =
    .label = プライベートウィンドウで検索候補を表示する
search-suggestions-cant-show-2 =
    .message = { -brand-short-name } に履歴を保存しないよう設定されているため、ロケーションバーに検索候補が表示されません。
addressbar-header-1 =
    .label = アドレスバー
    .description = アドレスバーに表示する候補を選択してください。
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .label = { -firefox-suggest-brand-name }
    .description = { -brand-short-name } とパートナー企業からの候補をアドレスバーに表示します。
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = 検索結果ページでアドレスバーに検索語句を表示する
search-separate-default-engine-2 =
    .label = プライベートウィンドウでは別の既定の検索エンジンを使用する
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = プライベートウィンドウの既定の検索エンジン
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = アドレスバー内の移動
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Tab キーでフォーカスを移動する場合に検索結果メニューをスキップする
search-suggestions-header-2 =
    .label = 検索エンジンの候補
search-one-click-header2 = 検索ショートカット
search-one-click-desc = キーワードの入力開始時にアドレスバーや検索バーの下に現れる代替検索エンジンを選んでください。
search-one-click-header-3 =
    .label = 追加の検索エンジン
    .description = アドレスバーに表示する検索エンジンまたはショートカットを選んでください。
search-engine-list =
    .aria-label = 検索エンジンとショートカット
update-search-engine-success =
    .message = 検索エンジンの更新が完了しました
search-edit-engine-2 =
    .title = 検索エンジンを編集
search-delete-engine =
    .title = 検索エンジンを削除
search-enable-engine =
    .title = 検索エンジンを有効化
search-outlink-to-extensions-page =
    .title = 拡張機能とテーマで管理
search-choose-engine-column =
    .label = 検索エンジン
search-choose-keyword-column =
    .label = キーワード
search-restore-default =
    .label = 既定の検索エンジンを復元
    .accesskey = D
search-remove-engine =
    .label = 削除
    .accesskey = R
search-add-engine =
    .label = 追加
    .accesskey = A
search-add-engine-2 =
    .label = 検索エンジンを追加
    .accesskey = A
search-edit-engine =
    .label = 編集
    .accesskey = E
search-find-more-link = 他の検索エンジンを追加
search-filtering-for-add-engine = 検索エンジンを追加
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = キーワードが重複しています
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = “{ $name }” で使用されているキーワードを指定しました。他のものを指定してください。
search-keyword-warning-bookmark = ブックマークで使用されているキーワードを指定しました。他のものを指定してください。
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = “{ $name }” という名前の検索エンジンがすでにあります。別の名前を指定してください。
remove-engine-confirmation = 本当にこの検索エンジンを削除しますか？
remove-engine-remove = 削除
remove-addon-engine-alert = この検索エンジンを削除するには、関連付けられたアドオンを削除してください。
search-engine-group =
    .label = 既定の検索エンジン
search-default-engine =
    .aria-label = 既定の検索エンジン
# Header for the search section ("search" is a noun).
search-section =
    .heading = 検索

## Containers Section

containers-section-header2 =
    .heading = コンテナーの設定
containers-card-header2 =
    .label = コンテナー
    .description = コンテナーごとに Cookie を分けているため、同じサイトで別のアカウントを使用できます。クロスサイトトラッキングも制限します。
containers-add-button2 =
    .label = 新しいコンテナーを追加
    .accesskey = A
containers-list =
    .aria-label = コンテナー
containers-new-tab-check3 =
    .label = 新しいタブを開くコンテナーを毎回選択する
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = 外部アプリから開いたリンクにはコンテナーを使用しない
    .accesskey = D
containers-new-tab-check2 =
    .label = 新しいタブを開くコンテナーを毎回選択する
    .accesskey = S
    .description = 新しいタブを開くボタンを押すと、毎回コンテナーメニューを開きます。
containers-settings-button2 =
    .title = 設定
containers-remove-button3 =
    .title = 削除
containers-sites-card-header =
    .label = サイト専用のコンテナー
    .description = 専用コンテナーを選ぶと、{ -brand-short-name } でこのサイトを開く時に毎回このコンテナーが使用されます。
containers-sites-add-button =
    .label = ウェブサイトを追加
    .accesskey = w
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = { $site } 用のコンテナー
containers-site-remove-button =
    .title = 削除
containers-remove-button2 =
    .title = 削除

## Account and sync

sync-group-label =
    .label = 同期
account-group-label2 =
    .label = アカウント
account-disabled-group =
    .label = アカウント
    .description = アカウント設定は利用できません。
account-placeholder2 =
    .label = ログインしていません
    .description = ログインしてユーザーデータをプライベートで暗号化し、{ -brand-short-name } を使用しているどの端末からでもすぐにアクセスできるようにしましょう。
account-sync-section =
    .heading = アカウントと同期
pane-account-sync-title2 = アカウントと同期
    .title = アカウントと同期

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = ウェブを持ち歩こう
sync-signedout-description2 = ブックマークやページの表示履歴、タブ、パスワード、アドオン、設定を、お持ちのすべての端末間で同期できます。
sync-signedout-account-signin3 =
    .label = ログインして同期...
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = アカウントにログインして同期を開始
    .accesskey = i
sync-signedout-account-short =
    .label = ログイン
    .accesskey = i
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Firefox for <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> または <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> をダウンロードしてモバイル端末と同期しましょう。

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .tooltiptext = プロファイル写真を変更します
    .alt = プロファイル写真を変更します
sync-profile-picture-account-problem =
    .alt = アカウントのプロファイル写真
fxa-login-rejected-warning =
    .alt = 警告
sync-sign-out =
    .label = ログアウト...
    .accesskey = g
sync-sign-out2 =
    .label = ログアウト
    .accesskey = g
sync-manage-account = アカウントの管理
    .accesskey = o
sync-manage-account2 =
    .label = アカウントの管理
    .accesskey = o

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } は認証されていません。
sync-signedin-unverified2 =
    .label = { $email } はまだ認証を確認していません
    .description = 登録したメールアドレスの受信トレイを確認してアカウントを有効にしてください。
sync-signedin-login-failure = { $email } に再接続するにはログインしてください。
sync-signedin-login-failure2 =
    .label = { $email } からログアウトしました
    .description = ログインして再接続し、ユーザーデータの同期を開始してください。

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .label = { $name }
    .description = { $email }

##

sync-verify-account =
    .label = アカウントを認証
    .accesskey = V
sync-remove-account =
    .label = アカウントを解除
    .accesskey = R
sync-sign-in =
    .label = ログイン
    .accesskey = g

## Sync section - enabling or disabling sync.

prefs-syncing-on = 同期: オン
prefs-syncing-on-2 =
    .label = 同期はオンです
prefs-syncing-off = 同期: オフ
prefs-syncing-off-2 =
    .label = 同期はオフです
    .description = 同期をオンにするとブックマーク、パスワード、履歴、他のデータを同期した端末上で使用できます。
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .label = 同期はオフです
    .description = 同期をオンにするとこの端末上のブックマーク、パスワード、履歴、他のデータを使用できます。
prefs-sync-turn-on-syncing =
    .label = 同期をオンにする...
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = 同期をオンにする
    .accesskey = s
prefs-sync-offer-setup-label2 = ブックマーク、履歴、タブ、パスワード、アドオン、設定をあなたのすべての端末に対して同期させます。
prefs-sync-now-button =
    .label = 今すぐ同期
    .accesskey = N
prefs-sync-now-button-2 =
    .label = 今すぐ同期
    .accesskey = N
prefs-syncing-button =
    .label = 同期中...
prefs-syncing-button-2 =
    .label = 同期中...
    .title = 今すぐ同期
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = 選択した同期項目は現在、この端末にのみ適用されています。

## The list of things currently syncing.

sync-syncing-across-devices-heading = アカウントに接続されたすべての端末でこれらの項目を同期しています:
sync-syncing-across-devices-heading-2 = 端末間で同期したデータ
sync-syncing-across-devices-heading-3 = この端末の同期したデータ
sync-syncing-across-devices-empty-state2 =
    .label = 同期したデータの管理
    .description = まだ何も同期していません。同期を開始してすべての端末上でユーザーデータを使用できるようにしましょう。
sync-syncing-across-devices-empty-state3 =
    .label = 同期したデータを管理
    .description = まだ何も同期していません。この端末上の同期するデータを選んでください。
sync-currently-syncing-bookmarks = ブックマーク
sync-currently-syncing-history = 表示履歴
sync-currently-syncing-tabs = 開いているタブ
sync-currently-syncing-passwords = パスワード
sync-currently-syncing-addresses = 住所フォーム
sync-currently-syncing-payment-methods = 支払い方法
sync-currently-syncing-addons = アドオン
sync-currently-syncing-settings = 個人設定
sync-manage-options =
    .label = 同期の管理...
    .accesskey = M
sync-manage-options-2 =
    .label = 同期データの管理
    .accesskey = M
settings-sync-disconnect-button =
    .label = 接続を解除

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = ブックマーク
    .accesskey = m
sync-engine-history =
    .label = 履歴
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = 開いているタブ
    .tooltiptext = 同期した他の端末で開いているタブです
    .accesskey = t
sync-engine-tabs =
    .label = 開いているタブ
    .tooltiptext = 同期した端末で開いているすべてのタブの一覧です
    .accesskey = t
sync-engine-passwords =
    .label = パスワード
    .tooltiptext = 保存したパスワードです
    .accesskey = P
sync-engine-addresses2 =
    .label = 住所フォーム
    .tooltiptext = { -brand-short-name } に保存した住所です
    .accesskey = e
sync-engine-payment-methods3 =
    .label = 支払い方法
    .tooltiptext = 保存した支払い方法です
    .accesskey = n
sync-engine-addons2 =
    .label = アドオン
    .tooltiptext = デスクトップ版 { -brand-short-name } に追加した拡張機能とテーマです
    .accesskey = A
sync-engine-settings2 =
    .label = 設定
    .tooltiptext = 適用可能な { -brand-short-name } の設定です
    .accesskey = s
sync-engine-addresses =
    .label = 住所フォーム
    .tooltiptext = 保存した住所です (デスクトップのみ)
    .accesskey = e
sync-engine-payment-methods2 =
    .label = 支払い方法
    .tooltiptext = 氏名とカード番号、有効期限
    .accesskey = n
sync-engine-addons =
    .label = アドオン
    .tooltiptext = デスクトップ版 Firefox の拡張機能とテーマです
    .accesskey = A
sync-engine-settings =
    .label = 個人設定
    .tooltiptext = 変更した一般設定、プライバシー設定、セキュリティ設定です
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .title = 接続したすべての端末で同期するものを管理します
    .style = min-width: 36em;
    .buttonlabelaccept = 保存
    .buttonaccesskeyaccept = S
    .buttonlabelextra2 = 接続を解除...
    .buttonaccesskeyextra2 = D
sync-choose-what-to-sync-dialog5 =
    .title = この端末上の同期するデータを管理します
    .style = min-width: 36em;
    .buttonlabelaccept = 保存
    .buttonaccesskeyaccept = S
    .buttonlabelextra2 = 接続を解除...
    .buttonaccesskeyextra2 = D

## The device name controls.

sync-device-name-header = 端末名
sync-device-name-header-2 =
    .label = 端末名
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = 端末名
    .placeholder = { $placeholder }
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-change-2 =
    .label = 端末名を変更
    .accesskey = h
sync-device-name-change =
    .label = 端末名を変更...
    .accesskey = h
sync-device-name-cancel =
    .label = キャンセル
    .accesskey = n
sync-device-name-save =
    .label = 保存
    .accesskey = v
sync-connect-another-device = 別の端末を接続
sync-connect-another-device-2 =
    .label = 別の端末を接続

## Privacy Section

privacy-header = ブラウザープライバシー

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = パスワード
    .searchkeywords = ログイン情報
forms-passwords-header =
    .label = パスワード
    .aria-label = パスワード
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = パスワードを保存するか確認する
    .accesskey = A
forms-manage-password-exceptions =
    .label = パスワードの例外サイトを管理
    .accesskey = M
forms-exceptions =
    .label = 例外サイト...
    .accesskey = x
forms-suggest-passwords =
    .label = 強固なパスワードを提案する
    .accesskey = S
forms-breach-alerts =
    .label = 漏洩したウェブサイトのパスワードの警告を表示する
    .accesskey = b
forms-breach-alerts-learn-more-link = 詳細情報
preferences-relay-integration-checkbox2 =
    .label = { -relay-brand-name } メールマスクによるメールアドレスの保護を提案する
    .accesskey = r
relay-integration-learn-more-link = 詳細情報
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = ユーザー名とパスワードを自動的に入力する
    .accesskey = F
forms-fill-usernames-and-passwords-2 =
    .label = ユーザー名とパスワードを自動的に保存して入力する
    .accesskey = f
forms-saved-passwords =
    .label = 保存されたパスワード
    .accesskey = d
forms-saved-passwords-2 =
    .label = 保存されたパスワードを管理
    .accesskey = d
forms-saved-passwords-searchkeywords = 以下のサイトのログイン情報がコンピューターに保存されています。
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = 追加の保護
forms-primary-pw-use =
    .label = マスターパスワードを使用する
    .accesskey = U
forms-primary-pw-use-2 =
    .label = マスターパスワードを使用する
    .description = 保存されたパスワードを保護するセキュリティのレイヤーを追加します。
    .accesskey = U
forms-primary-pw-set =
    .label = マスターパスワードを設定
forms-primary-pw-on-2 = マスターパスワードは <strong>オン</strong> です
forms-primary-pw-on =
    .label = マスターパスワードはオンです
forms-primary-pw-change-2 =
    .label = マスターパスワードを変更
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = オフにする
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = パスワードの入力と管理に端末のログイン情報を要求する
forms-os-reauth-2 =
    .label = パスワードの管理に端末のログイン情報を要求する
forms-primary-pw-learn-more-link = 詳細情報
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = マスターパスワードを変更...
    .accesskey = M
forms-primary-pw-change =
    .label = マスターパスワードを変更...
    .accesskey = P
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = 現在 FIPS モードです。FIPS モードではマスターパスワードを空には設定できません。
forms-master-pw-fips-desc = パスワードを変更できませんでした
forms-windows-sso =
    .label = Microsoft アカウント、職場または学校アカウントで Windows のシングルサインオンを許可する
forms-windows-sso-learn-more-link = 詳細情報
forms-windows-sso-desc = 端末の設定でアカウントを管理します
windows-passkey-settings-label = システム設定で Passkey を管理します

## Privacy Panel Settings

privacy-panel-settings-header =
    .label = プライバシーパネル設定
    .description = { -brand-short-name } がオンラインでユーザー情報を保護します。
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = 情報漏洩メッセージを表示
    .accesskey = s

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = マスターパスワードを作成するには、Windows のログイン資格情報を入力してください。これはあなたのアカウントのセキュリティを保護します。
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = マスターパスワードを作成
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
# (^m^) [macos] Firefox が...しようとしています。
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] 支払い方法の設定を変更
       *[other] { -brand-short-name } が支払い方法の設定を変更しようとしています。許可するには端末のログイン情報を使用してください。
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = 支払い方法
autofill-payment-methods-checkbox-message-2 =
    .label = 支払い情報を保存して自動入力する
    .accesskey = p
autofill-payment-methods-manage-payments-title =
    .heading = 支払い方法の管理
autofill-payment-methods-manage-payments-button =
    .label = 支払い方法を管理
    .accesskey = m
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = 自動入力時に端末のログイン情報を要求する
    .accesskey = o
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = 支払い方法の自動入力と管理に端末のログイン情報を要求する
    .accesskey = o
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = セキュリティコードを保存する
    .accesskey = c
autofill-payment-methods-add-button = 新しい支払い方法を追加
payments-list-header =
    .label = 支払い方法
payments-delete-payment-prompt-title = この支払い方法を削除しますか？
payments-delete-payment-prompt-confirm-button = 削除
payments-delete-payment-prompt-cancel-button = キャンセル
payments-delete-payment-button-label =
    .aria-label = 削除
payments-edit-payment-button-label =
    .aria-label = 編集
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = 追加した支払い方法はありません
autofill-addresses-checkbox-message =
    .label = 住所を保存して自動入力する
    .accesskey = S
autofill-addresses-manage-addresses-button =
    .label = 住所などを管理
    .accesskey = M
addresses-list-header =
    .label = 住所
addreses-delete-address-button-label =
    .aria-label = 削除
addreses-edit-address-button-label =
    .aria-label = 編集
addresses-delete-address-prompt-title = この住所を削除しますか？
addresses-delete-address-prompt-confirm-button = 削除
addresses-delete-address-prompt-cancel-button = キャンセル
autofill-addresses-add-button = 新しい住所を追加
autofill-addresses-manage-addresses-title =
    .heading = 住所などの管理
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = 追加した住所はありません
personal-info-group =
    .label = 個人情報
autofill-personal-info-checkbox-message =
    .label = 保存して個人情報を自動入力する
autofill-personal-info-manage-button =
    .label = 個人情報を管理
passports-list-header =
    .label = パスポート
passports-delete-passport-button-label =
    .aria-label = 削除
passports-edit-passport-button-label =
    .aria-label = 編集
passports-delete-passport-prompt-title = このパスポート情報を削除しますか？
passports-delete-passport-prompt-confirm-button = 削除
passports-delete-passport-prompt-cancel-button = キャンセル
autofill-passports-add-button = 新しいパスポートを追加
autofill-personal-info-manage-title =
    .heading = 個人情報の管理
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = 追加したパスポートはありません
pane-passwords-autofill-title2 = パスワードと自動入力
    .title = パスワードと自動入力
preferences-passwords-autofill-header =
    .heading = パスワードと自動入力
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .label = { $cardNumber }
    .description = { $expDate }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .label = { $cardNumber }
    .description = { $expDate } | { $securityCode } •••
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .label = { $cardNumber }
    .description = { $securityCode } •••
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself. "CVV" is a common abbreviation for the security code printed on a
# payment card; use whichever abbreviation is most familiar in your locale.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item-with-security-code =
    .label = { $cardNumber }
    .description = { $expDate } | CVV を保存しました
# Used in place of payment-moz-box-item-with-security-code for a card that has a
# saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
payment-moz-box-item-security-code-only =
    .label = { $cardNumber }
    .description = CVV を保存しました
addresses-group =
    .label = 住所など
payments-group =
    .label = 支払い方法

## Privacy Section - History

history-remember-option-never2 =
    .label = 履歴を一切記憶させない
    .description = すべてのウィンドウがプライベートウィンドウのようになります。オンにした場合は必要な拡張機能を許可してください。
history-remember-option-custom2 =
    .label = 記憶させる履歴を詳細設定する
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } は表示したページの履歴、ファイルのダウンロード履歴、検索やフォームの入力履歴を保存します。
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } はプライベートブラウジング中と同様に、表示したページの履歴などのプライバシーデータを一切保存しません。
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } は表示したページの履歴、ファイルのダウンロード履歴、検索やフォームの入力履歴をカスタム設定で保存します。
history-private-browsing-permanent =
    .label = 常にプライベートブラウジングモード
    .accesskey = p
history-remember-browser-option =
    .label = 表示したページとファイルのダウンロードの履歴を残す
    .accesskey = b
history-remember-search-option =
    .label = 検索やフォームの入力履歴を記憶させる
    .accesskey = f
history-clear-on-close-option =
    .label = { -brand-short-name } の終了時に履歴を消去する
    .accesskey = r
history-clear-on-close-settings =
    .label = 設定...
    .accesskey = t
history-shutdown-exceptions =
    .label = 例外を管理
    .accesskey = x
history-clear-button =
    .label = 履歴を消去...
    .accesskey = s
history-header2 =
    .heading = 履歴
history-section-header =
    .label = 履歴
    .description = ブラウザーを閉じた時に { -brand-short-name } に記憶させるアイテムを選んでください。
history-custom-section-header =
    .label = 詳細設定
    .description = ブラウザーを閉じた時に { -brand-short-name } に記憶させるアイテムをカスタマイズします。
history-custom-button =
    .label = { -brand-short-name } に記憶させるアイテムを選んでください
history-group =
    .label = 履歴
history-mode-radio-group =
    .aria-label = 履歴
history-remember-option-all2 =
    .label = 履歴を記憶する

## Privacy Section - Site Data

sitedata-total-size-calculating = サイトデータとキャッシュのサイズを計算しています...
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = ウェブサイトのディスク使用量は現在 <strong>{ $value } { $unit }</strong> です。
sitedata-learn-more = 詳細情報
sitedata-delete-on-close2 =
    .label = { -brand-short-name } を閉じる度に Cookie とサイトデータを削除する
    .accesskey = c
sitedata-delete-on-close-private-browsing3 =
    .message = ブラウザーを閉じると、履歴の設定に従って { -brand-short-name } がセッションの Cookie とサイトデータを削除します。
sitedata-delete-on-close-private-browsing4 =
    .heading = 履歴は保存されません。
    .message = ブラウザーを閉じるときに { -brand-short-name } が Cookie とサイトデータをセッションから消去します。
sitedata-option-block-cross-site-trackers =
    .label = クロスサイトトラッカー
sitedata-option-block-cross-site-tracking-cookies =
    .label = クロスサイトトラッキング Cookie
sitedata-option-block-cross-site-cookies2 =
    .label = クロスサイト Cookie の隔離
sitedata-option-block-unvisited =
    .label = 未訪問のウェブサイトの Cookie
sitedata-option-block-all-cross-site-cookies =
    .label = すべてのクロスサイト Cookie (ウェブサイトが動作しない可能性があります)
sitedata-option-block-all =
    .label = すべての Cookie (ウェブサイトが動作しなくなります)
sitedata-clear2 =
    .label = 閲覧データを消去
    .accesskey = l
sitedata-settings2 =
    .label = 閲覧データを管理
    .accesskey = M
sitedata-cookies-exceptions =
    .label = 例外を管理...
    .accesskey = x
sitedata-cookies-exceptions2 =
    .label = 例外を管理
    .accesskey = x
    .description = Cookie とサイトデータの使用を常に許可するウェブサイトと今後許可しないウェブサイトを指定できます。
sitedata-heading =
    .label = 閲覧データ
    .description = Cookie および履歴、キャッシュ、ウェブサイトデータ、その他の情報を管理します。
sitedata-settings3 =
    .label = 特定のサイトのデータを消去
    .accesskey = s
sitedata-cookies-exceptions3 =
    .label = 例外を管理
    .accesskey = x
    .description = 特定のサイトが Cookie とサイトデータをどのように扱うかを選んでください。
cookies-site-data-group =
    .label = Cookie とサイトデータ

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Cookie バナーブロッカー
cookie-banner-blocker-description = プライベートブラウジングモードでウェブサイトが Cookie の使用を求めてきた場合、{ -brand-short-name } が自動的に拒否します。これはサポートされたサイトのみ有効です。
cookie-banner-learn-more = 詳細情報
cookie-banner-blocker-checkbox-label =
    .label = 自動的に Cookie バナーを拒否する

## Search Section

addressbar-locbar-history-option =
    .label = 閲覧履歴
    .accesskey = h
addressbar-locbar-bookmarks-option =
    .label = ブックマーク
    .accesskey = k
addressbar-locbar-clipboard-option =
    .label = クリップボード
    .accesskey = C
addressbar-locbar-openpage-option =
    .label = 開いているタブ
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = ショートカット
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = トップサイト
    .accesskey = T
addressbar-locbar-engines-option-1 =
    .label = 使用する検索エンジンの候補
    .accesskey = a
addressbar-locbar-quickactions-option =
    .label = クイックアクション
    .accesskey = Q
addressbar-locbar-showrecentsearches-option-2 =
    .label = 最近の検索
    .accesskey = r
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = トレンド検索候補
    .accesskey = t
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .label = { -brand-short-name } からの検索候補
    .description = 検索語句に関連する候補をウェブから取得します
addressbar-locbar-suggest-sponsored-option-2 =
    .label = スポンサーからの提案
    .description = スポンサーからの提案を随時表示して { -brand-short-name } を支援します
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = 入力に応じて Mozilla からの提案を取得する
addressbar-dismissed-suggestions-label-2 =
    .label = 閉じた提案
    .description = スポンサーと { -brand-short-name } からの閉じてしまった提案を復元します。
addressbar-restore-dismissed-suggestions-button-2 =
    .label = 提案を復元

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = 強化型トラッキング防止機能
content-blocking-section-top-level-description = トラッカーはあなたの習慣や興味に関する情報を収集するために、オンラインであなたを追跡します。{ -brand-short-name } はこれらのトラッカーや悪意のあるスクリプトの多くをブロックします。
content-blocking-learn-more = 詳細情報
content-blocking-fpi-incompatibility-warning = { -brand-short-name } の Cookie の設定の一部を上書きするファーストパーティ分離 (FPI) を使用しています。
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = { -brand-short-name } のフィンガープリント採取防止の設定の一部を上書きする Resist Fingerprinting (RFP) を使用しています。この機能により一部のサイトが動作しない可能性があります。

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = 標準
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = 厳格
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = カスタム
    .accesskey = C

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = 保護と性能をバランスよく。ページが正しく機能するように読み込みます。
content-blocking-etp-strict-desc = より強固な保護ですが、一部のサイトやコンテンツが機能しなくなる可能性があります。
content-blocking-etp-custom-desc = ブロックするトラッカーとスクリプトを選択します。
content-blocking-etp-blocking-desc = { -brand-short-name } は以下のものをブロックします:
content-blocking-private-windows = プライベートウィンドウのトラッキングコンテンツ
content-blocking-cross-site-cookies-in-all-windows2 = すべてのウィンドウのクロスサイト Cookie
content-blocking-cross-site-tracking-cookies = クロスサイトトラッキング Cookie
content-blocking-all-cross-site-cookies-private-windows = プライベートウィンドウのクロスサイト Cookie
content-blocking-isolate-cross-site-cookies = クロスサイト Cookie の隔離
content-blocking-social-media-trackers = ソーシャルメディアトラッカー
content-blocking-all-cookies = すべての Cookie
content-blocking-unvisited-cookies = 未訪問のサイトの Cookie
content-blocking-all-windows-tracking-content = すべてのウィンドウのトラッキングコンテンツ
content-blocking-all-cross-site-cookies = すべてのクロスサイト Cookie
content-blocking-cryptominers = 暗号通貨マイニング
content-blocking-fingerprinters = フィンガープリント採取
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = 既知および疑わしいフィンガープリント採取

# The tcp-rollout strings are no longer used for the rollout but for tcp-by-default in the standard section

# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = 包括的 Cookie 保護機能により現在のサイトへの Cookie が制限されているため、トラッカーはサイトを横断してあなたを追跡する Cookie を利用できません。
content-blocking-etp-standard-tcp-rollout-learn-more = 詳細情報
content-blocking-etp-standard-tcp-title = 包括的 Cookie 保護機能が含まれます。これまでで最も強力なプライバシー保護機能です
content-blocking-warning-title-2 = 厳格なトラッキング防止で一部のウェブサイトが動作しない可能性があります
content-blocking-warning-title-custom = カスタム設定のトラッキング防止で一部のウェブサイトが動作しない可能性があります
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } の “サイトの問題を修正” 設定でサイトの機能やコンテンツが正しく表示されない問題を軽減することをおすすめします。サイトが動作しないときは、このサイトでトラッキング防止をオフにしてすべてのコンテンツを読み込んでみてください。
content-blocking-warning-learn-how = 詳細情報
content-blocking-baseline-exceptions-3 =
    .label = サイトの主要な問題を修正 (推奨)
    .description = トラッカーを含む主要な要素だけブロックを解除してサイトの読み込みと機能の動作を助けます。数多くの問題をカバーしています。
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .label = サイトの軽微な問題を修正
    .description = トラッカーを含む要素のブロックを解除して記事内の動画やコメントセクションなどのコンテンツを復元します。これはサイトの問題を軽減しますが、提供される保護が少なくなります。必ず、主要な問題を修正する設定と併用してください。
content-blocking-baseline-uncheck-warning-dialog-title = 修正をオフにしてもよろしいですか？
content-blocking-baseline-uncheck-warning-dialog-body = この設定は数多くのサイトの問題の修正を助けます。オフにすると、一部のサイトが動作しない可能性があり、これらの問題を { -brand-short-name } が解決できなくなります。
content-blocking-baseline-uncheck-warning-dialog-ok-button = 修正をオフにする
content-blocking-baseline-uncheck-warning-dialog-cancel-button = 修正を維持する
content-blocking-reload-description = これらの変更を適用するには、タブを再読み込みする必要があります。
content-blocking-reload-tabs-button =
    .label = すべてのタブを再読み込み
    .accesskey = R
content-blocking-tracking-content-label =
    .label = トラッキングコンテンツ
    .accesskey = T
content-blocking-tracking-protection-option-all-windows =
    .label = すべてのウィンドウ
    .accesskey = A
content-blocking-option-private =
    .label = プライベートウィンドウのみ
    .accesskey = p
content-blocking-cookies-label =
    .label = Cookie
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = 詳細情報
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = 暗号通貨マイニング
    .accesskey = y
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = 既知のフィンガープリント採取
    .accesskey = K
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = 疑わしいフィンガープリント採取
    .accesskey = S

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = 例外を管理...
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = { -brand-short-name } を再起動するまで通知を一時停止
    .accesskey = n
permissions-autoplay2 =
    .label = 自動再生
permissions-block-popups2 =
    .label = ポップアップとサードパーティによるリダイレクトをブロックする
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .label = 例外を管理
    .description = ポップアップとサードパーティによるリダイレクトを許可するサイトを追加してください。
    .accesskey = E
    .searchkeywords = popups
permissions-addon-install-warning3 =
    .label = ウェブサイトが拡張機能をインストールしようとした時に警告する
    .accesskey = W
permissions-addon-exceptions2 =
    .label = 拡張機能のインストールを許可するウェブサイトを指定
    .accesskey = E
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = アプリを開くリンクを許可するサイト。
    .accesskey = A
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = ブロックしたサイトを管理
    .accesskey = M
permissions-location2 =
    .label = 位置情報
permissions-localhost2 =
    .label = 端末のアプリとサービス
permissions-local-network2 =
    .label = ローカルネットワークの端末
permissions-xr2 =
    .label = VR デバイス
permissions-camera2 =
    .label = カメラ
permissions-microphone2 =
    .label = マイク
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = スピーカー
permissions-notification2 =
    .label = 通知
permissions-header3 =
    .label = 許可設定
    .description = ウェブサイトからのアクセス、制御、トリガーを管理します。
permissions-data-section =
    .heading = 許可設定とデータ
pane-permissions-data-title2 = 許可設定とデータ
    .title = 許可設定とデータ
notifications-section-header =
    .heading = 通知
notifications-entry-card-header =
    .label = 通知
    .description = 通知を送信できるウェブサイトを選択し、その通知をどのように表示するかを選んでください。
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .label = 通知の設定を管理
    .description = { $count } サイト
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = ウェブサイト通知の設定を管理
notifications-website-card-header =
    .label = ウェブサイト通知
    .description = ウェブサイトが通知をどのように送信できるか選んでください。
notifications-filter =
    .placeholder = ウェブサイトを検索します
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = ウェブサイト
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = 通知を許可
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = ウェブサイト
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = 常に許可する
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = 許可する
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = 許可しない
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = ウェブサイト通知が追加されていません。
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = 検索と一致するウェブサイト通知はありません。

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = この変更をバックアップに含めるには、各プロファイルを開き、設定で [今すぐバックアップ] を選んでください。
nimbus-rollouts =
    .label = 更新間で { -brand-short-name } の機能、パフォーマンス、安定性の向上を許可する
    .description = 変更はリモートでロールアウトされます。
addon-recommendations3 =
    .label = パーソナライズされた拡張機能のおすすめを許可する
    .description = おすすめの拡張機能を試してブラウジング体験を向上させましょう。
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = このビルド設定ではデータ報告が無効化されています。
collection-backlogged-crash-reports2 =
    .label = クラッシュレポートを自動的に送信する
    .accesskey = c
collection-backlogged-crash-reports-description = これは { -vendor-short-name } がブラウザーの問題を診断し修正するのに役立てられます。レポートには個人情報や機密性の高い情報が含まれる場合があります。
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = 同じ設定、新しい外観！
    .message = 私たちはこのページを整理して簡単に設定が見つけられるようにしました。ユーザーの個人設定はすべて元のまま変更していません。ヒント: 検索すると目当ての設定へまっすぐジャンプできます。
settings-redesign-promo-dismiss-button =
    .label = 了解
privacy-segmentation-section-header = ブラウジング体験を向上させる新機能
privacy-segmentation-section-description = より良いユーザー体験のために、あなたのデータを使用する機能を提案されたとき:
privacy-segmentation-radio-off =
    .label = { -brand-product-name } のおすすめを利用する
privacy-segmentation-radio-on =
    .label = 詳細情報を表示する
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .label = { -brand-short-name } のデータ収集と利用について
    .description = 私たちはユーザーに選択肢を提供し、{ -brand-product-name } の改善に必要な最小限のデータだけを収集するよう努力しています。
    .searchkeywords = テレメトリー
data-collection-link = プライバシー通知を表示
data-collection-preferences-across-profiles =
    .message = これらの設定は、この端末上のすべての { -brand-product-name } プロファイルに適用されます。
data-collection-profiles-link = すべてのプロファイルを表示
data-collection-health-report-telemetry-disabled =
    .message = { -vendor-short-name } への技術データと対話データの送信の許可を取り消しました。過去のデータは 30 日以内にすべて削除されます。
data-collection-health-report =
    .label = 技術データと対話データを { -vendor-short-name } に送信する
    .accesskey = r
    .description = これは { -brand-product-name } の機能やパフォーマンス、安定性の向上に役立てられます。
data-collection-health-report-disabled =
    .label = 技術データと対話データを { -vendor-short-name } に送信する
    .accesskey = r
    .description = このビルド設定ではデータ報告が無効化されています。
data-collection-run-studies =
    .label = { -brand-short-name } に機能の調査を許可する
    .description = { -brand-short-name } がユーザーをランダムに選択して機能をテストし、全体の品質を向上させます。
data-collection-studies-link =
    .label = { -brand-short-name } 調査を確認する
data-collection-backlogged-crash-reports =
    .label = クラッシュレポートを自動的に送信する
    .description = これは { -vendor-short-name } がブラウザーの問題を診断し修正するのに役立てられます。レポートには個人情報や機密性の高い情報が含まれる場合があります。
    .accesskey = c
data-collection-usage-ping =
    .label = 毎日の使用頻度を { -vendor-short-name } に送信する
    .description = これは { -vendor-short-name } がアクティブユーザー数を推定するのに役立てられます。
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = セキュリティ
browsing-protection-group2 =
    .label = 詐欺コンテンツと危険なソフトウェアからの保護
    .description = 危険なサイトとダウンロードはユーザーのデータと端末を危険に晒すおそれがあります。{ -brand-short-name } は自動的にこれらをブロックし、危険性や望ましくないソフトウェアについて警告します。
security-enable-safe-browsing =
    .label = 危険なコンテンツと詐欺コンテンツをブロックする
    .accesskey = B
security-enable-safe-browsing-link = 詳細情報
security-safe-browsing-warning =
    .message = これをオフにすると、詐欺サイトや悪意のあるサイト、危険なダウンロードに対する保護が低下します。
security-block-downloads =
    .label = 危険なファイルのダウンロードをブロックする
    .accesskey = d
security-block-uncommon-software =
    .label = 不要で一般的でないソフトウェアを警告する
    .accesskey = c

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = ユーザーがインストールしたサードパーティのルート証明書を自動的に信頼することを { -brand-short-name } に許可する
    .accesskey = t
certs-devices-enable-fips = FIPS を有効にする
space-alert-over-5gb-settings-button =
    .label = 設定を開く
    .accesskey = O
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } を実行するためのディスク領域が足りません。</strong>ウェブサイトが正しく表示されない可能性があります。[設定] > [プライバシーとセキュリティ] > [Cookie とサイトデータ] から、保存されたデータを削除してください。
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } を実行するためのディスク領域が足りません。</strong>ウェブサイトが正しく表示されない可能性があります。快適なブラウジングのために、[詳細情報] のリンク先を読み、ディスク使用量を最適化してください。
certs-description3 =
    .label = 証明書
    .description = { -brand-short-name } が安全な接続の検証に使用する証明書を設定します。
certs-view2 =
    .label = 証明書を管理
    .accesskey = C
certs-devices2 =
    .label = セキュリティデバイスを管理
    .accesskey = D

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = HTTPS-Only モードの動作について
httpsonly-radio-enabled =
    .label = すべてのウィンドウで HTTPS-Only モードを有効にする
httpsonly-radio-enabled-pbm =
    .label = プライベートウィンドウのみ HTTPS-Only モードを有効にする
httpsonly-radio-disabled3 =
    .label = HTTPS-Only モードを有効にしない
    .description = 設定に関わらず { -brand-short-name } は一部の通信を安全な接続にアップグレードすることがあります。
httpsonly-group =
    .label = HTTPS-Only モード
    .description = 安全な接続だけをウェブサイトに許可します。接続が安全でない場合は { -brand-short-name } に確認を求められます。
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS over HTTPS
dns-over-https-group2 =
    .label = DNS over HTTPS
    .description = Domain Name System over HTTPS (DoH) はサイト検索を暗号化して、あなたがアクセスしようとしているウェブサイトをインターネットプロバイダーや他者に知られないようにします。
preferences-doh-description2 = Domain Name System (DNS) over HTTPS は暗号化された接続を通してドメイン名の要求を送信します。この安全な DNS によって、あなたがアクセスしようとしているウェブサイトを他者に知られないようにします。
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = 状態: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = プロバイダー: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = 不正な URL
preferences-doh-steering-status = ローカルプロバイダーを使用中
preferences-doh-status-active = 使用中
preferences-doh-status-disabled = オフ
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = 未使用 ({ $reason })
preferences-doh-group-message2 = DNS over HTTPS を次のレベルで有効にします:
preferences-doh-radio-group =
    .aria-label = DNS over HTTPS を次のレベルで有効にします
preferences-doh-expand-section =
    .tooltiptext = 詳細情報
preferences-doh-setting-default =
    .label = 既定の保護
    .accesskey = D
preferences-doh-default-desc = いつ安全な DNS を使用してユーザーのプライバシーを保護するかを { -brand-short-name } が決定します。
preferences-doh-default-detailed-desc-1 = 利用可能な地域で安全な DNS を使用します
preferences-doh-default-detailed-desc-2 = 安全な DNS プロバイダーで問題がある場合、既定の DNS リゾルバーを使用します
preferences-doh-default-detailed-desc-3 = 可能であればローカルプロバイダーを使用します
preferences-doh-default-detailed-desc-4 = VPN やペアレンタルコントロール、エンタープライズポリシーが有効な場合はオフにします
preferences-doh-default-detailed-desc-5 = ネットワークが { -brand-short-name } に安全な DNS を使用させない場合はオフにします
preferences-doh-setting-enabled =
    .label = 強力な保護
    .accesskey = I
preferences-doh-enabled-desc = いつ安全な DNS を使用するかをユーザーが制御し、DNS プロバイダーを指定できます
preferences-doh-enabled-detailed-desc-1 = 選択された DNS プロバイダーを使用します
preferences-doh-enabled-detailed-desc-2 = 安全な DNS で問題がある場合のみ、既定の DNS リゾルバーを使用します
preferences-doh-setting-strict =
    .label = 最大限の保護
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } は常に安全な DNS を使用します。ご使用のシステムの DNS が使用される前にセキュリティの危険性があることが警告されます。
preferences-doh-strict-detailed-desc-1 = 選択された DNS プロバイダーのみを使用します
preferences-doh-strict-detailed-desc-2 = 安全な DNS が利用できない場合、常に警告されます
preferences-doh-strict-detailed-desc-3 = 安全な DNS が利用できない場合、サイトが読み込まれず正しく機能しません
preferences-doh-setting-off =
    .label = オフ
    .accesskey = O
preferences-doh-off-desc = 既定の DNS リゾルバーを使用します
preferences-doh-select-resolver = プロバイダーを選択:
preferences-doh-manage-exceptions =
    .label = 例外を管理...
    .accesskey = x
preferences-doh-overview-default =
    .label = 既定の保護
    .description = 利用可能な地域で安全な DNS を使用します。
preferences-doh-overview-custom =
    .label = カスタム
    .description = ユーザーによる制御とフォールバック動作を備えた安全な DNS を常に利用します。
preferences-doh-overview-off =
    .label = オフ
    .description = 既定の DNS リゾルバーを利用します。
preferences-doh-advanced-button =
    .label = 詳細設定
preferences-doh-advanced-section =
    .label = 詳細設定
    .description = Domain Name System over HTTPS (DoH) はサイト検索を暗号化して、あなたがアクセスしようとしているウェブサイトをインターネットプロバイダーや他者に知られないようにします。
preferences-doh-manage-exceptions2 =
    .label = 例外を管理
    .accesskey = x
preferences-doh-radio-default =
    .label = 既定
    .description = 地域で利用できる安全な DNS を使用します
preferences-doh-radio-custom =
    .label = カスタム
    .description = 常にプロバイダー制御とフォールバック動作を備えた安全な DNS を利用します
preferences-doh-radio-off =
    .label = オフ
    .description = 既定の DNS リゾルバーを利用します
preferences-doh-fallback-label =
    .label = 安全な DNS が利用できない場合は常に警告する
preferences-doh-status-item-off =
    .message = DNS over HTTPS はオフです
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = プロバイダー { $name } の利用の試行中にエラーが発生したため DNS over HTTPS が動作していません ({ $reason })
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = 不正な URL を受信したため DNS over HTTPS が動作していません ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS over HTTPS はプロバイダーに { $name } を利用します
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = ローカルプロバイダー { $name } の利用の試行中にエラーが発生したため DNS over HTTPS が動作していません ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS over HTTPS はローカルプロバイダーに { $name } を利用します
preferences-doh-select-resolver-label =
    .label = プロバイダーを選択:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = DNS over HTTPS の解決にこのプロバイダーを利用します
preferences-doh-custom-provider-label =
    .aria-label = カスタムプロバイダーの URL を入力してください
preferences-doh-header2 =
    .heading = DNS over HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = 接続とソフトウェアのセキュリティ
preferences-connection-link-section =
    .label = 接続とソフトウェアのセキュリティ
    .description = 接続をどのように安全に保ち、危険なソフトウェアをブロックし、ウェブサイトを検証しているかをご覧ください。
preferences-connection-link-button =
    .label = 詳細設定

## The following strings are used in the Download section of settings

desktop-folder-name = デスクトップ
downloads-folder-name = ダウンロード

## Appearance page

preferences-appearance-header =
    .heading = 外観
browser-theme-group =
    .label = ブラウザーのテーマ
    .description = { -brand-short-name } をあなたのスタイルに。テーマ配色は、ツールバー、メニュー、メッセージに適用されます。
browser-theme-manage-link =
    .label = { -brand-short-name } テーマを管理
appearance-window-density-group =
    .label = ウィンドウの密度
    .description = ツールバーやタブ、サイドバーなどのウィンドウ要素の周りのスペースを調整します。
appearance-window-density-radio-group =
    .aria-label = ウィンドウの密度
appearance-window-density-automatic =
    .label = 自動 (既定)
    .description = 標準、コンパクト、タッチスペースのいずれかが自動的に適用されます
appearance-window-density-automatic-no-touch =
    .label = 自動 (既定)
    .description = 標準またはコンパクトのどちらかが自動的に適用されます
appearance-window-density-standard =
    .label = 標準
    .description = ほとんどの画面でバランスの取れたスペースに設定されます
appearance-window-density-auto-touch-mode =
    .label = タブレットモード用のタッチスペースを適用する
appearance-window-density-compact =
    .label = コンパクト
    .description = 小さな画面用にスペースを減らします
appearance-window-density-touch =
    .label = タッチ
    .description = 大きなウィンドウ要素とクリック対象でタッチ画面用に最適化されます
related-settings-group =
    .label = 関連設定
related-settings-accessibility-link =
    .label = アクセシビリティでズームとフォント設定をカスタマイズ
related-settings-home-link =
    .label = { -firefox-home-brand-name } をカスタマイズ
related-settings-tabs-browsing-link =
    .label = ブラウザーのレイアウトをカスタマイズ

## AI controls page

preferences-ai-controls-description = AI 支援の機能を含め、{ -brand-short-name } の機能はいつでも変更できます。さらに多くの制御が間もなく追加されます。
preferences-ai-controls-block-ai-label = AI 支援をブロックする
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = ブロックすると { -brand-short-name } の現在の AI 支援が無効になり、AI のポップアップも表示されなくなります。この制御に含まれるものや、従来の検索候補とおすすめなど機械学習機能の制御については <a data-l10n-name="link">こちらをご覧ください</a>。
preferences-ai-controls-blocked-message =
    .message = 現在の AI 支援が既定でブロックされます。特定の機能のブロック解除は、以下から設定してください。
preferences-ai-controls-on-device-group =
    .label = 端末上の AI
    .description = AI 支援を利用する場合、これらの機能は端末にダウンロードされる小さな AI モデルを使用します。このアプローチはユーザーのプライバシー保護に役立ちます。
preferences-ai-controls-translations-control =
    .label = 翻訳
    .description = あなたの優先言語でシームレスにウェブブラウジングができます。
preferences-ai-controls-translations-more-link = 他の翻訳設定
preferences-ai-controls-pdfjs-control =
    .label = { -brand-short-name } PDF ビューアの画像の代替テキスト生成
    .description = PDF に画像を追加する際、画像をアクセシブルにする説明を追加します。
preferences-ai-controls-tab-group-suggestions-control =
    .label = タブグループの提案
    .description = グループ名を提案してタブを整理します。
preferences-ai-controls-key-points-control =
    .label = リンクプレビュー時の要点生成
    .description = リンクを開く前にリンク先の簡易な要約を表示します。
preferences-ai-controls-speech-recognition-control =
    .label = 音声認識
    .description = 音声をローカルで文字に変換します
preferences-ai-controls-sidebar-chatbot-group-3 =
    .label = サイドバーの AI チャットボットプロバイダー
    .description = ブラウジング中にチャットボットを利用できます。複数のプロバイダーから選んで、いつでも切り替えられます。
preferences-ai-controls-sidebar-chatbot-group =
    .label = サイドバーの AI チャットボットプロバイダー
    .description = ブラウジング中にチャットボットを利用できます。Anthropic Claude、ChatGPT、Copilot、Google Gemini、Le Chat Mistral のいずれかを選んでください。
preferences-ai-controls-sidebar-chatbot-control =
    .label = サイドバーのチャットボット
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = 利用可能
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = 有効
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = ブロック
preferences-ai-controls-state-description-before = 選択肢の説明:
preferences-ai-controls-state-description-available = <strong>利用可能:</strong> 機能が表示され使用できます。
preferences-ai-controls-state-description-enabled = <strong>有効:</strong> 機能の使用を許可しています。
preferences-ai-controls-state-description-blocked = <strong>ブロック:</strong> 機能が表示されず使用できません。ダウンロードされた端末上の AI のモデルは削除されます。
preferences-ai-controls-block-confirmation-heading = AI 支援をブロックしますか？
preferences-ai-controls-block-confirmation-description = { -brand-short-name } の現在の AI 支援や AI についてのポップアップが表示されなくなります。引き続き使用したい機能はブロックを解除してください。
preferences-ai-controls-block-confirmation-features-start = ブロックされる機能:
preferences-ai-controls-block-confirmation-translations = 翻訳
preferences-ai-controls-block-confirmation-pdfjs = { -brand-short-name } PDF ビューアの画像の代替テキスト生成
preferences-ai-controls-block-confirmation-tab-group-suggestions = タブグループの提案
preferences-ai-controls-block-confirmation-key-points = リンクプレビュー時の要点生成
preferences-ai-controls-block-confirmation-sidebar-chatbot = サイドバーのチャットボット
preferences-ai-controls-block-confirmation-speech-recognition = 音声認識
preferences-ai-controls-block-confirmation-features-after = 機能のブロックは { -brand-short-name } により提供された AI を利用する拡張機能にも影響します。
preferences-ai-controls-block-confirmation-cancel =
    .label = キャンセル
preferences-ai-controls-block-confirmation-confirm =
    .label = ブロック
preferences-ai-controls-header3 =
    .heading = AI 制御

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } が防護しています
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } が推奨するセキュリティ向上
security-privacy-status-ok-label = 強化型トラッキング防止がオンです
security-privacy-status-problem-label = ユーザー保護に影響する設定が見つかりました
security-privacy-status-problem-helper-label = 問題を表示する
security-privacy-status-pending-trackers-label = 先月 { -brand-short-name } がブロックしたトラッカーの数を確認しています
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label = 先月 { $trackerCount } 個のトラッカーをブロックしました
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = 現在の保護は <a data-l10n-name="strict-tracking-protection">厳格モード</a> です
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = 現在の保護は <a data-l10n-name="custom-tracking-protection">カスタム</a> です
security-privacy-status-up-to-date-label = 最新の最も安全なバージョンの { -brand-short-name } を使用しています。
security-privacy-status-update-needed-label = { -brand-short-name } の新しいバージョンが利用可能です。
security-privacy-status-update-error-label = { -brand-short-name } の更新時に問題が発生しました
security-privacy-status-update-checking-label = { -brand-short-name } が更新を確認しています
security-privacy-status-update-needed-description = 最新のスピード、安定性、セキュリティ向上のために更新してください。
security-privacy-status-update-button-label =
    .label = { -brand-short-name } を更新
security-privacy-image-warning =
    .alt = 感嘆符付きの盾、重要なセキュリティ警告があることを表しています
security-privacy-image-ok =
    .alt = チェックマーク付きの盾、未解決のセキュリティ問題が無いことを示しています
security-privacy-issue-card =
    .heading = セキュリティ警告
issue-card-reset-button =
    .label = リセット
issue-card-dismiss-button =
    .tooltiptext = 閉じる
    .aria-label = 閉じる

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .label = 強化型トラッキング防止
    .description = サイトはトラッカーを使用してオンラインであなたを追跡し、気味の悪い広告を表示します。{ -brand-short-name } があなたのブラウジングの盾となってトラッカーを自動的にブロックするため、デジタルの足跡を残しません。
preferences-etp-level-radio-group =
    .aria-label = 強化型トラッキング防止
preferences-etp-level-standard =
    .label = 標準モード (既定)
    .description = ほとんどのウェブサイトでスムーズに動作する、強力な信頼できる保護です。
preferences-etp-level-strict =
    .label = 厳格モード
    .description = さらに多くのトラッカーをブロックする強力な保護ですが、一部のサイトが動作しない原因となる可能性があります。
preferences-etp-level-custom =
    .label = カスタム
    .description = オンまたはオフにする保護を選んでください。
preferences-etp-status-advanced-button =
    .label = 詳細設定
preferences-etp-tracker-count-enabled =
    .label = ブロックしたトラッカーをアドレスバーに表示する
preferences-etp-status-protections-dashboard-link =
    .label = パーソナライズされた保護ダッシュボードを見る
    .description = ソーシャルメディアトラッカーやフィンガープリント採取、暗号通貨マイニングを含め、どれだけ多くの隠れたトラッカーを { -brand-short-name } がブロックしているかを表示します。
preferences-etp-header =
    .heading = 強化型トラッキング防止
preferences-etp-advanced-settings-group =
    .label = 詳細設定
    .description = サイトはトラッカーを使用してオンラインであなたを追跡し、気味の悪い広告を表示します。{ -brand-short-name } があなたのブラウジングの盾となってほとんどのトラッカーを自動的にブロックするため、デジタルの足跡を残しません。
preferences-etp-customize-button =
    .label = トラッキング防止をカスタマイズ
preferences-etp-reload-tabs-hint =
    .message = これらの変更を適用するにはタブを再読み込みしてください。
preferences-etp-reload-tabs-hint-button =
    .label = すべてのタブを再読み込み
preferences-etp-rfp-warning-message =
    .message = Resist Fingerprinting (RFP) を使用しています。これは { -brand-short-name } のフィンガープリント採取防止設定の一部を置き換えるものです。この設定により一部のサイトが動作しない原因となる可能性があります。
preferences-etp-level-warning-message =
    .heading = 注意！ 一部のサイトが期待通りに動作しない可能性があります。
    .message = 一部のサイトはその機能やコンテンツにトラッカーを仕組んでいます。{ -brand-short-name } がそれらをブロックするとサイトが壊れたように見えます。[サイトの問題を修正] するか、そのサイトでトラッキング防止機能をオフにしてみてください。
preferences-etp-manage-exceptions-button =
    .label = 例外を管理
    .description = 強化型トラッキング防止を無効にするウェブサイトを管理します。
preferences-etp-customize-header =
    .heading = トラッキング防止のカスタマイズ
preferences-etp-reset =
    .label = カスタマイズをリセット
    .description = 設定を初期の保護レベルに戻します。
preferences-etp-reset-standard-button =
    .label = 標準モードにリセット
preferences-etp-reset-strict-button =
    .label = 厳格モードにリセット
preferences-etp-custom-control-group =
    .label = トラッキング防止
    .description = オンまたはオフにする保護を選んでください。
preferences-etp-custom-cookies-enabled =
    .label = Cookie
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookie
preferences-etp-custom-cookie-behavior-accept-all =
    .label = すべての Cookie を許可
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = クロスサイトトラッキング Cookie をブロック
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = クロスサイト Cookie をブロック
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = クロスサイト Cookie を隔離
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = 未訪問のウェブサイトからの Cookie をブロック
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = すべてのクロスサイト Cookie をブロック (ウェブサイトが動作しない原因になります)
preferences-etp-custom-cookie-behavior-block-all =
    .label = すべての Cookie をブロック (ウェブサイトが動作しない原因になります)
preferences-etp-custom-tracking-protection-enabled =
    .label = トラッキングコンテンツ
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = トラッキングコンテンツ
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = 暗号通貨マイニング
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = 既知のフィンガープリント採取
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = 疑わしいフィンガープリント採取
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = 疑わしいフィンガープリント採取

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .label = 既知のフィンガープリント採取がブロックされません
    .description = これは Cookie 無しでユーザーを追跡する一部のトラッカーを許可します。
security-privacy-issue-warning-third-party-cookies =
    .label = サードパーティ Cookie が有効です
    .description = サードパーティ Cookie はウェブサイトを横断してユーザーを追跡するのに使われます。
security-privacy-issue-warning-password-manager =
    .label = パスワードマネージャーが無効です
    .description = パスワードマネージャーはユーザーアカウントの強力なパスワードを格納する助けになります。
security-privacy-issue-warning-popup-blocker =
    .label = ポップアップブロッカーが無効です
    .description = ポップアップは操作に割り込むため潜在的に有害です。
security-privacy-issue-warning-extension-install =
    .label = ウェブサイトが拡張機能をインストールできます
    .description = ユーザーに尋ねることなく、ウェブサイトが拡張機能を { -brand-short-name } にインストールできます。
security-privacy-issue-warning-safe-browsing =
    .label = 危険な詐欺コンテンツがブロックされません
    .description = ウェブサイトからの詐欺やマルウェアへの露出が増加します。
security-privacy-issue-warning-doh2 =
    .label = DNS over HTTPS が無効です
    .description = DNS over HTTPS はあなたがアクセスするサイトをネットワークプロバイダーから隠します。
security-privacy-issue-warning-ech2 =
    .label = Encrypted Client Hello 機能が無効です
    .description = Encrypted Client Hello はあなたがアクセスするサイトをネットワークプロバイダーから隠します。
security-privacy-issue-warning-doh =
    .label = DNS over HTTPS が無効です
    .description = DNS over HTTPS はあなたがアクセスするサイトをネットワークプロバイダーから隠します。
security-privacy-issue-warning-ech =
    .label = Encrypted Client Hello 機能が無効です
    .description = Encrypted Client Hello はあなたがアクセスするサイトをネットワークプロバイダーから隠します。
security-privacy-issue-warning-proxy-autodetection =
    .label = プロキシー自動設定が有効です
    .description = プロキシー自動設定により、信頼できないネットワークがユーザーの行動をモニターできます。

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .label = { -brand-product-name } を宣伝
    .description = プライバシー優先のブラウザーを選んでもらえるように宣伝してください。
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = { -brand-product-name } を宣伝


vorbit-header = vOrbit-lite の設定
vorbit-warning-title = 注意！
vorbit-general-heading = ブラウザーの動作
vorbit-extension-update-checkbox =
    .label = アドオンを自動的にアップデート
vorbit-sync-checkbox =
    .label = Firefox Sync を有効にする
vorbit-autocopy-checkbox =
    .label = 中クリックでペーストを有効にする
vorbit-styling-checkbox =
    .label = userChrome.css のカスタマイズを許可する
vorbit-network-heading = ネットワーク
vorbit-ipv6-checkbox =
    .label = IPv6 を有効にする
vorbit-privacy-heading = プライバシー
vorbit-xorigin-ref-checkbox =
    .label = クロスオリジンリファラを制限する
vorbit-webgl-checkbox =
    .label = WebGL を有効にする
vorbit-rfp-checkbox =
    .label = ResistFingerprinting を有効にする
vorbit-letterboxing-checkbox =
    .label = Letterboxing を有効にする
vorbit-security-heading = セキュリティ
vorbit-goog-safe-download-checkbox =
    .label = ダウンロードをスキャンする
vorbit-broken-heading = フィンガープリント採取
vorbit-goog-safe-checkbox =
    .label = Google セーフブラウジングを有効にする
vorbit-extension-update-warning1 = アップデートごとに拡張機能のコードを確認しないのであれば、このオプションを有効にすべきです。
vorbit-ipv6-description = { -brand-short-name } が IPv6 を使用して接続することを許可します。
vorbit-ipv6-warning1 = ブラウザーで IPv6 をブロックする代わりに、OS の IPv6 プライバシー機能を有効にすることを推奨します。
vorbit-ocsp-description = OCSP チェックが行えない場合のウェブサイトへの接続を防止します。
vorbit-ocsp-warning1 = これにより、セキュリティーは向上しますが、OCSP サーバーがダウンした際に不具合を引き起こす可能性があります。
vorbit-sync-description = 他のブラウザーとデータを同期します。再起動が必要です。
vorbit-sync-warning1 = Firefox Sync はサーバーにデータを送信する前にローカルでデータを暗号化します。
vorbit-autocopy-description = コピーするテキストを選択し、中クリックでペーストします。
vorbit-styling-description = 手動でロードされたテーマで UI をカスタマイズしたい場合は、これを有効にして下さい。
vorbit-styling-warning1 = テーマの提供元が信頼できることを確認して下さい。
vorbit-xorigin-ref-description = 同一オリジンにのみリファラを送信します。
vorbit-xorigin-ref-warning1 = これにより不具合を引き起こす可能性があります。さらに、送信されたリファラであってもトリミングされます。
vorbit-webgl-description = WebGL は強力なフィンガープリントベクターです。
vorbit-webgl-warning1 = 有効にする必要がある場合、Canvas Blocker などの拡張機能の使用を検討して下さい。
vorbit-rfp-warning1 = 無効にする必要がある場合、Canvas Blocker などの拡張機能の使用を検討して下さい。
vorbit-goog-safe-description = マルウェアやフィッシング詐欺が心配な場合、有効にすることを検討して下さい。
pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = about:config の設定が合理的にグループ化され、簡単にアクセスできます
vorbit-ocsp-checkbox =
    .label = OCSP hard-fail を強制する
vorbit-extension-update-description = 手動の操作なしで拡張機能の最新の状態を保ちます。セキュリティのために良い選択です。
vorbit-rfp-description = ResistFingerprinting は、最高級のフィンガープリント採取対策ツールです。
vorbit-warning-description = 私たちは、プライバシーとセキュリティーを重視してデフォルト設定を厳選しています。これらの設定を変更する場合は、設定の説明を読んで、変更による影響を確認して下さい。
vorbit-letterboxing-description = Letterboxing は、制限された丸めた解像度を返すために、ウィンドウの周りに余白を追加します。
vorbit-goog-safe-warning1 = 検閲の懸念があるため無効にされていますが、初心者のユーザーにはおすすめです。チェックはすべてローカルで行われます。
vorbit-goog-safe-download-description = セーフブラウジングを有効にすることで、ダウンロードをスキャンして疑わしいファイルを識別できます。
vorbit-goog-safe-download-warning1 = チェックはすべてローカルで行われます。
vorbit-footer = 関連リンク
vorbit-config-link = 詳細な設定 (about:config)
vorbit-open-profile = ユーザープロファイルのディレクトリを開く
content-blocking-section-top-level-description = vOrbit-liteは、厳格モードでの強化されたトラッキング保護（Enhanced Tracking Protection）をサポートし、デフォルトで有効にしています。これはブラウザの最も重要な設定の一つであり、状態の分離、厳格なブロックリスト、およびその他の優れたプライバシー機能を提供します。他のモードへの変更は推奨しません。
