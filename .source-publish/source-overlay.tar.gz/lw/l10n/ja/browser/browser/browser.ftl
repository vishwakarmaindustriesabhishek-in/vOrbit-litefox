# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } プライベートブラウジング
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = 高速でプライベートなウェブブラウジング
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — プライベートブラウジング
       *[other] { -brand-full-name } プライベートブラウジング
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = プライベートブラウジング
popups-infobar-dont-show-message2 =
    .label = ポップアップまたはサードパーティによるリダイレクトがブロックされた場合は、このメッセージを表示しない
    .accesskey = D
edit-popup-settings2 =
    .label = ポップアップおよびサードパーティによるリダイレクトの設定...
    .accesskey = M
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] サイトの情報を表示
            [1] サイトの情報を表示 (トラッカーを 1 個ブロック)
           *[other] サイトの情報を表示 (トラッカーを { $count } 個ブロック)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = { $count } 個のリンク
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop、メッセージ、他...
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = メッセージ、Mail、他...
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = 共有...
    .accesskey = h

##

urlbar-identity-button =
    .aria-label = サイトの情報を表示

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = インストールメッセージパネルを開きます
urlbar-web-notification-anchor =
    .tooltiptext = サイトからの通知の設定を変更します
urlbar-midi-notification-anchor =
    .tooltiptext = MIDI パネルを開きます
urlbar-serial-notification-anchor =
    .tooltiptext = シリアルパネルを開きます
urlbar-eme-notification-anchor =
    .tooltiptext = DRM ソフトウェアを管理します
urlbar-web-authn-anchor =
    .tooltiptext = Web Authentication パネルを開きます
urlbar-canvas-notification-anchor =
    .tooltiptext = canvas 要素抽出の許可設定を管理します
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = マイクの共有を管理します
urlbar-default-notification-anchor =
    .tooltiptext = メッセージパネルを開きます
urlbar-geolocation-notification-anchor =
    .tooltiptext = 位置情報の要求パネルを開きます
urlbar-localhost-notification-anchor =
    .tooltiptext = このサイトのローカル端末へのアクセスを管理します
urlbar-local-network-notification-anchor =
    .tooltiptext = このサイトとローカルネットワークのアクセス共有を管理します
urlbar-xr-notification-anchor =
    .tooltiptext = VR の許可設定パネルを開きます
urlbar-storage-access-anchor =
    .tooltiptext = 行動追跡の許可設定パネルを開きます
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = ウィンドウと画面の共有を管理します
urlbar-indexed-db-notification-anchor =
    .tooltiptext = オフラインストレージのメッセージパネルを開きます
urlbar-password-notification-anchor =
    .tooltiptext = パスワードの保存メッセージパネルを開きます
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = カメラとマイクの共有を管理します
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = その他のスピーカーの共有を管理します
urlbar-autoplay-notification-anchor =
    .tooltiptext = 自動再生パネルを開きます
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = データを永続ストレージに格納します
urlbar-addons-notification-anchor =
    .tooltiptext = アドオンのインストールのメッセージパネルを開きます
urlbar-search-tips-confirm = 了解しました
urlbar-search-tips-confirm-short = 了解
urlbar-result-menu-button =
    .title = メニューを開く
urlbar-result-menu-button-feedback = フィードバック
    .title = メニューを開く
urlbar-result-menu-learn-more2 = 詳細情報
    .accesskey = L
urlbar-result-menu-remove-from-history2 = 履歴から削除
    .accesskey = R
urlbar-result-menu-tip-get-help2 = ヘルプを表示
    .accesskey = h
urlbar-result-menu-dismiss-suggestion2 = この検索候補を閉じる
    .accesskey = D
urlbar-result-menu-remove-top-site = このトップサイトを削除
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = { -firefox-suggest-brand-name } を管理
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = 位置情報の誤りを報告
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = 表示頻度を減らす
    .accesskey = f
urlbar-result-menu-dont-show-weather-suggestions3 = 天気予報の提案を表示しない
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = 位置情報の誤りを報告
urlbar-result-menu-show-less-frequently2 = 表示頻度を減らす
urlbar-result-menu-dont-show-weather-suggestions2 = 天気予報の提案を表示しない
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = この提案を閉じる
    .accesskey = i
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = 履歴から削除
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = 詳細情報
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = 履歴から削除
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = ヘルプを表示
    .accesskey = h
urlbar-result-menu-dismiss-suggestion =
    .label = この検索候補を閉じる
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = { -firefox-suggest-brand-name } を管理
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = 位置情報の誤りを報告
urlbar-result-menu-show-less-frequently =
    .label = 表示頻度を減らす
urlbar-result-menu-dont-show-weather-suggestions =
    .label = 天気予報の提案を表示しない
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = メニューを開く
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = フィードバックありがとうございます
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = フィードバックありがとうございます。今後は天気予報の提案が表示されなくなります。

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = 少ない入力でたくさん見つかる: アドレスバーから { $engineName } ですぐ検索します。
urlbar-search-tips-redirect-2 = アドレスバーで検索を始めると、{ $engineName } からの検索候補と閲覧履歴が表示されます。
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = このショートカットを選択すると、必要なものを早く見つけられます。

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = ブックマーク
urlbar-search-mode-tabs = タブ
urlbar-search-mode-history = 履歴
urlbar-search-mode-actions = アクション

##

urlbar-geolocation-blocked =
    .tooltiptext = このウェブサイトでの位置情報の共有をブロックしました。
urlbar-localhost-blocked =
    .tooltiptext = このウェブサイトのローカル端末への接続をブロックしました。
urlbar-local-network-blocked =
    .tooltiptext = このウェブサイトのローカルネットワークへの接続をブロックしました。
urlbar-xr-blocked =
    .tooltiptext = このウェブサイトの VR デバイスへのアクセスをブロックしました。
urlbar-web-notifications-blocked =
    .tooltiptext = このウェブサイトからの通知をブロックしました。
urlbar-camera-blocked =
    .tooltiptext = このウェブサイトでのカメラの共有をブロックしました。
urlbar-microphone-blocked =
    .tooltiptext = このウェブサイトでのマイクの共有をブロックしました。
urlbar-screen-blocked =
    .tooltiptext = このウェブサイトでの画面の共有をブロックしました。
urlbar-persistent-storage-blocked =
    .tooltiptext = このウェブサイトの永続ストレージの使用をブロックしました。
urlbar-popup-blocked2 =
    .tooltiptext = このウェブサイトのポップアップとサードパーティによるリダイレクトをブロックしました。
urlbar-autoplay-media-blocked =
    .tooltiptext = このウェブサイトの音声付きメディアの自動再生をブロックしました。
urlbar-canvas-blocked =
    .tooltiptext = このウェブサイトの Canvas データの抽出をブロックしました。
urlbar-midi-blocked =
    .tooltiptext = このウェブサイトの MIDI へのアクセスをブロックしました。
urlbar-serial-blocked =
    .tooltiptext = このウェブサイトのシリアルポートへのアクセスをブロックしました。
urlbar-install-blocked =
    .tooltiptext = このウェブサイトのアドオンのインストールをブロックしました。
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = このページのブックマークを編集します ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = このページをブックマークに追加します ({ $shortcut })
urlbar-split-view-button =
    .tooltiptext = 分割ビュー
    .aria-label = 分割ビュー

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = 貼り付けて移動
    .accesskey = G
urlbar-menuitem-paste-and-search =
    .label = 貼り付けて検索
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = 検索履歴を消去
    .accesskey = H

## Page Action Context Menu

page-action-manage-extension2 =
    .label = 拡張機能を管理...
    .accesskey = E
page-action-remove-extension2 =
    .label = 拡張機能を削除
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = ツールバーを隠す
    .accesskey = H
full-screen-exit =
    .label = 全画面表示モードを終了
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = 今回だけ使う検索エンジン:
search-one-offs-change-settings-compact-button =
    .tooltiptext = 検索設定を変更します
search-one-offs-context-open-new-tab =
    .label = 新しいタブで検索
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = 既定の検索エンジンに設定
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = プライベートウィンドウの既定の検索エンジンに設定
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .label = “{ $engineName }” を追加
    .tooltiptext = 検索エンジン “{ $engineName }” を追加します
    .aria-label = 検索エンジン “{ $engineName }” を追加
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = 検索エンジンを追加
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = 検索エンジンを追加

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = ブックマーク ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = タブ ({ $restrict })
search-one-offs-history =
    .tooltiptext = 履歴 ({ $restrict })
search-one-offs-actions =
    .tooltiptext = アクション ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = アドオンを表示
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = extensions, themes, addons, add-ons
# Opens preferences page at AI controls
quickactions-manageai = AI 制御の管理
quickactions-cmd-manageai = disable ai, off ai, manage ai
# Opens the bookmarks library window
quickactions-bookmarks2 = ブックマークを管理
quickactions-cmd-bookmarks = bookmarks
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = 最近の履歴を消去
quickactions-cmd-clearrecenthistory2 = cookies, clear cookies, cache, clear cache, browsing data, clear browsing data, history, clear recent history
# Opens about:downloads page
quickactions-downloads2 = ダウンロードを表示
quickactions-cmd-downloads = downloads
# Opens about:addons page in the extensions section
quickactions-extensions = 拡張機能を管理
quickactions-cmd-extensions2 = extensions, addons, add-ons
# Opens Firefox View
quickactions-firefoxview = { -firefoxview-brand-name } を開く
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = open { -firefoxview-brand-name }, { -firefoxview-brand-name }, open view, view
# Opens SUMO home page
quickactions-help = { -brand-product-name } ヘルプ
quickactions-cmd-help = help, support
# Opens the devtools web inspector
quickactions-inspector2 = 開発ツールを開く
quickactions-cmd-inspector2 = inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Pick a color
quickactions-cmd-colorpicker = color picker, eyedropper, pick color
quickactions-cmd-library = library
# Opens Firefox Library
quickactions-library = ライブラリーを開く
# Opens about:logins
quickactions-logins2 = パスワードを管理
quickactions-cmd-logins = logins, passwords
# Mutes all tabs playing audio
quickactions-mute = 音声再生中のタブをミュート
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = mute, shush, sssssh
# Opens the print dialog
quickactions-print2 = ページを印刷
quickactions-cmd-print = print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = ページを PDF 形式で保存
quickactions-cmd-savepdf2 = pdf, save page
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = PDF エディターを開く
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = プライベートウィンドウを開く
quickactions-cmd-private = private browsing
# Opens a SUMO article explaining how to refresh
quickactions-refresh = { -brand-short-name } をリフレッシュ
quickactions-cmd-refresh = refresh
# Restarts the browser
quickactions-restart = { -brand-short-name } を再起動
quickactions-cmd-restart = restart
# Opens the screenshot tool
quickactions-screenshot3 = スクリーンショットを撮影
quickactions-cmd-screenshot2 = screenshot, take a screenshot
# Opens about:translations
quickactions-translate = 翻訳
quickactions-cmd-translate = translate
# Opens about:preferences
quickactions-settings2 = 設定を管理
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = settings, preferences, options, manage
# Opens about:addons page in the themes section
quickactions-themes = テーマを管理
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = themes, add-ons, addons
# Opens a SUMO article explaining how to update the browser
quickactions-update = { -brand-short-name } を更新
quickactions-cmd-update = update
# Opens the view-source UI with current pages source
quickactions-viewsource2 = ページのソースを表示
quickactions-cmd-viewsource2 = view source, source, page source
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = { -firefoxlabs-brand-name } を開く
quickactions-cmd-labs = labs, experiment
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = クイックアクションについての詳細
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = タブキーを押して選択:

## Bookmark Panel

bookmarks-add-bookmark = ブックマークを追加
bookmarks-edit-bookmark = ブックマークを編集
bookmark-panel-cancel =
    .label = キャンセル
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [1] ブックマークを削除
           *[other] { $count } 個のブックマークを削除
        }
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = 追加時にエディターを表示する
    .accesskey = S
bookmark-panel-save-button2 =
    .label = 保存
    .accesskey = a
bookmark-panel-save-button =
    .label = 保存
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = { $host } のサイト情報
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = { $host } への接続の安全性
identity-connection-not-secure = 安全でない接続
identity-connection-secure = 安全な接続
identity-connection-failure = 接続失敗
identity-connection-internal = このページは { -brand-short-name } の安全な内部ページです。
identity-connection-file = これはあなたのコンピューターに保存されているページです。
identity-connection-associated = このページは別のページから読み込まれています。
identity-extension-page = このページは拡張機能から読み込まれています。
identity-active-blocked = このページの一部が安全でないため { -brand-short-name } がブロックしました。
identity-custom-root = Mozilla が承認していない発行者の証明書で検証された接続です。
identity-passive-loaded = このページの一部 (画像など) は安全ではありません。
identity-active-loaded = このページでの保護は無効に設定されています。
identity-weak-encryption = このページは脆弱な暗号を使用しています。
identity-https-only-connection-upgraded = (安全な HTTPS で接続中)
identity-https-only-label2 = このサイトを自動的に安全な接続にアップグレードします
identity-https-only-dropdown-on =
    .label = オン
identity-https-only-dropdown-off =
    .label = オフ
identity-https-only-dropdown-off-temporarily =
    .label = 一時的にオフ
identity-https-only-info-turn-on3 = このサイトで { -brand-short-name } に可能な限り接続をアップグレードさせたい場合は、HTTPS アップグレードをオンにしてください。
identity-https-only-info-turn-off3 = ページが動作しない場合は HTTPS アップグレードをオフにして、安全でない HTTP 接続でこのサイトを再読み込みするとよいでしょう。
identity-https-only-info-no-upgrade = 接続を HTTP からアップグレードできません。
identity-permissions-storage-access-header = クロスサイト Cookie
identity-permissions-storage-access-hint = 以下のサイトが、あなたがこのサイトにいる間、クロスサイト Cookie とサイトデータにアクセスできます。
identity-permissions-storage-access-learn-more = 詳細情報
identity-permissions-reload-hint = 変更内容を適用するには、ページの再読み込みが必要です。
identity-clear-site-data =
    .label = Cookie とサイトデータを消去...
identity-connection-not-secure-security-view = このサイトとの接続は安全ではありません。
identity-connection-verified = このサイトとの接続は安全です。
identity-ev-owner-label2 = 証明書の発行先
identity-verifier-label2 = 認証局
identity-ev-owner-label = 証明書の発行先:
identity-verifier-label = 認証局:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Regulation (EU) 2024/1183 に規定された要件を満たしています。
identity-description-custom-root2 = Mozilla はこの証明書の発行者を承認していません。OS またはシステム管理者により追加された可能性があります。
identity-cert-exception-overridden = このサイトはセキュリティ例外として追加されました。
identity-remove-cert-exception =
    .label = 例外から削除
    .accesskey = R
identity-description-insecure = このサイトへの接続は秘密が保たれません。このサイトに送信した情報 (パスワードやメッセージ、クレジットカード情報など) が第三者に盗み見られる可能性があります。
identity-description-weak-cipher-intro = このウェブサイトとの接続には脆弱な暗号が使用されており、秘密が保たれません。
identity-description-weak-cipher-risk = 第三者にあなたの情報を盗み見られたりウェブサイトの動作を不正に改変される可能性があります。
identity-description-active-blocked2 = { -brand-short-name } がこのページ上の安全でないコンテンツをブロックしました。
identity-description-passive-loaded = この接続は安全でないため、サイトと共有したあなたの情報が第三者に盗み見られる可能性があります。
identity-description-passive-loaded-insecure2 = このウェブサイトには安全でないコンテンツ (画像など) が含まれています。
identity-description-passive-loaded-mixed2 = { -brand-short-name } が一部のコンテンツをブロックしていますが、ページ上には安全でないコンテンツ (画像など) が含まれています。
identity-description-active-loaded = このウェブサイトには安全でないコンテンツ (スクリプトなど) が含まれており、サイトとの接続は秘密が保たれません。
identity-description-active-loaded-insecure = このサイトと共有したあなたの情報 (パスワードやメッセージ、クレジットカード情報など) が第三者に盗み見られる可能性があります。
identity-description-tls-key-logging-heading = 現在の接続はプライベートになりません
identity-description-tls-key-logging-message = アプリまたはサービスがこのサイトから暗号化された通信を読み取ることができます。
identity-more-info-link-text =
    .label = 詳細を表示

## Window controls

browser-window-minimize-button =
    .tooltiptext = 最小化
browser-window-maximize-button =
    .tooltiptext = 最大化
browser-window-restore-down-button =
    .tooltiptext = 元に戻す (縮小)
browser-window-close-button =
    .tooltiptext = 閉じる
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = 戻る

## Bookmarks toolbar items

browser-import-button2 =
    .label = ブックマークをインポートする...
    .tooltiptext = ブックマークを他のブラウザーから { -brand-short-name } にインポートします。
bookmarks-toolbar-empty-message = ブックマークをこのブックマークツールバーに配置すると、すばやくアクセスできます。<a data-l10n-name="manage-bookmarks">ブックマークを管理...</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = カメラ:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = カメラ
popup-select-microphone-device =
    .value = マイク:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = マイク
popup-select-speaker-icon =
    .tooltiptext = スピーカー
popup-select-window-or-screen =
    .label = ウィンドウまたは画面:
    .accesskey = W
popup-all-windows-shared = 画面に表示されているすべてのウィンドウを共有します。

## WebRTC window or screen share tab switch warning

sharing-warning-window = { -brand-short-name } を共有しています。新しいタブに切り替えると、他の人にも見えます。
sharing-warning-screen = 全画面を共有しています。新しいタブに切り替えると、他の人にも見えます。
sharing-warning-proceed-to-tab =
    .label = タブに移動
sharing-warning-disable-for-session =
    .label = このセッションでは共有保護を無効にする

## WebSerial "select a port" popup

webserial-select-port-label = シリアルポートを選択:
webserial-no-ports-available = 利用可能なシリアルポートがありません

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = 閉じる
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = URL または検索語句を入力します
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = URL を入力します
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .placeholder = ウェブを検索します
    .aria-label = { $name } で検索
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .placeholder = 検索語句を入力します
    .aria-label = { $name } を検索
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .placeholder = 検索語句を入力します
    .aria-label = ブックマークを検索
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .placeholder = 検索語句を入力します
    .aria-label = 履歴を検索
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .placeholder = 検索語句を入力します
    .aria-label = タブを検索
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .placeholder = 検索語句を入力します
    .aria-label = アクションを検索
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = { $name } で検索、または URL を入力します
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = ブラウザーがリモート制御下にあります (制御元: { $component })
urlbar-permissions-granted =
    .tooltiptext = このウェブサイトで追加の権限を許可しました。
urlbar-switch-to-tab =
    .value = タブを表示:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = 拡張機能:
urlbar-go-button2 =
    .title = アドレスバーに入力された URL へ移動します
urlbar-page-action-button =
    .tooltiptext = ページ操作
urlbar-revert-button =
    .tooltiptext = ロケーションバーにアドレスを表示します

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = プライベートウィンドウの { $engine } で検索
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = プライベートウィンドウで検索
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = { $engine } で検索
urlbar-result-action-sponsored = 広告
urlbar-result-action-switch-tab = タブを表示
urlbar-result-action-move-tab-to-split-view = タブを分割ビューへ移動
urlbar-result-action-visit = 開く
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = タブを表示 · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = 無名のグループ
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = クリップボードから開く
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Tab キーを押すと { $engine } でウェブを検索します
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Tab キーを押すと { $engine } を検索します
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = アドレスバーから直接 { $engine } で検索
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = アドレスバーから直接 { $engine } を検索
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = コピー
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = 未定義
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = { -brand-product-name } 拡張
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = おすすめ
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> { $region } { $city }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> { $region } { $city }、{ $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · 広告
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = 尋ねる

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = 最後に訪れたのは { $date } です
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days = 最後に訪れたのは { $daysAgo } 日前です
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks = 最後に訪れたのは { $weeksAgo } 週間前です
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months = 最後に訪れたのは { $monthsAgo } か月前です
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = 最後に訪れたのは { $date } です
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = { $date } にブックマーク済み
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = 最終訪問日: { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = 最終訪問日: { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = 最終訪問日: { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = 株式市場のデータを検索バーで取得
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = 検索クエリーデータを { -vendor-short-name } と共有すると、市場の更新情報にパートナー企業からの情報を加えて表示します。<a data-l10n-name="learn-more-link">詳細情報</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = 検索候補を表示する
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = 後で
urlbar-result-realtime-opt-in-dismiss = 閉じる
urlbar-result-realtime-opt-in-dismiss-all2 = これらの候補を表示しない
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = 市場データの候補を表示しない
    .accesskey = n
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = 市場データの候補を表示しない
urlbar-result-realtime-opt-in-dismiss-all =
    .label = これらの候補を表示しない
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = 市場データの候補を表示しない
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = フィードバックありがとうございます。今後は市場データの検索候補を表示しません。
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = 株式市場の候補
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = フィードバックありがとうございます。今後はこれらの検索候補を表示しません。

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown = { $name } · あと { $daysUntilStart } 日
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range = { $name } · 開始まであと { $daysUntilStart } 日
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing = { $name } · あと { $daysUntilEnd } 日で終了
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · 今日
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · 今日まで

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = { $engine } で検索
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - { $localSearchMode } を検索
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - { $engine } で検索
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = 検索エンジン: { $engine }、別の検索エンジンを選択します
urlbar-searchmode-button-no-engine2 =
    .title = ショートカットが選択されていません。ショートカットを選択します
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = キーワード検索が無効です
urlbar-searchmode-dropmarker2 =
    .title = 検索エンジンを選択します
urlbar-searchmode-bookmarks4 = ブックマーク
urlbar-searchmode-tabs4 = タブ
urlbar-searchmode-history4 = 履歴
urlbar-searchmode-actions4 = アクション
urlbar-searchmode-bookmarks3 = ブックマーク
    .accesskey = B
urlbar-searchmode-tabs3 = タブ
    .accesskey = T
urlbar-searchmode-history3 = 履歴
    .accesskey = H
urlbar-searchmode-actions3 = アクション
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = 閉じる
urlbar-searchmode-default2 =
    .title = 既定の検索エンジン
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = “{ $engineName }” を追加
    .title = 検索エンジン “{ $engineName }” を追加します
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = 今回だけ使う検索エンジン:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = 検索エンジン:
urlbar-searchmode-popup-search-settings2 = 検索設定
urlbar-searchmode-popup-settings2 = 設定
urlbar-searchmode-popup-search-settings = 検索設定
    .accesskey = S
urlbar-searchmode-popup-settings = 設定
    .accesskey = S

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = ブックマークを検索
urlbar-result-action-search-history = 履歴を検索
urlbar-result-action-search-tabs = タブを検索
urlbar-result-action-search-actions = アクションを検索
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = { $group } に切り替え
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = { $group } を開く

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = 新しいタブで開く
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = 新しいコンテナータブで開く
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = 新しいウィンドウで開く
    .accesskey = N
urlbar-view-context-menu-open-in-private-window =
    .label = 新しいプライベートウィンドウで開く
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = 新しいタブで開く
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = 新しいコンテナータブで開く
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = 新しいウィンドウで開く
    .accesskey = N
urlbar-view-context-menu-open-in-private-window2 = 新しいプライベートウィンドウで開く
    .accesskey = P
urlbar-view-context-menu-search-in-tab = 新しいタブで検索
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = 新しいコンテナータブで検索
    .accesskey = i
urlbar-view-context-menu-search-in-window = 新しいウィンドウで検索
    .accesskey = N
urlbar-view-context-menu-search-in-private-window = 新しいプライベートウィンドウで検索
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Tab キーでこのメニューをスキップする
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = { $engine } の検索候補
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = クイックアクション
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = 最近の検索
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = { $engine } の検索トレンド
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = 検索トレンドを表示しない
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = 検索トレンドを表示しない
    .accesskey = D
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = 検索トレンドを表示しない
    .accesskey = D
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = フィードバックありがとうございます。今後は検索トレンドが表示されなくなります。

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = リーダービューで開く
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = リーダービューを閉じる

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = ピクチャーインピクチャーを開きます ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = ピクチャーインピクチャーを閉じます ({ $shortcut })
picture-in-picture-panel-header = ピクチャーインピクチャー
picture-in-picture-panel-headline = このウェブサイトでのピクチャーインピクチャーはおすすめしません
picture-in-picture-panel-body = ピクチャーインピクチャーを有効にした場合、動画が開発者の意図したように表示されない可能性があります。
picture-in-picture-enable-toggle =
    .label = とにかく有効化

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> は現在全画面表示モードです。
fullscreen-warning-no-domain = このページは現在全画面表示モードです。
fullscreen-exit-button = 全画面表示モードを終了 (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = 全画面表示モードを終了 (esc)
fullscreen-keyboardlock-exit-button = 全画面表示モードを終了 (Esc を長押し)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = 全画面表示モードを終了 (esc を長押し)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = マウスポインターは現在、 <span data-l10n-name="domain">{ $domain }</span> が制御しています。制御を取り戻すには、ESC キーを押してください。
pointerlock-warning-no-domain = マウスポインターは現在、このページが制御しています。制御を取り戻すには、ESC キーを押してください。

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = ブックマークを管理
bookmarks-recent-bookmarks-panel-subheader = 最近のブックマーク
bookmarks-toolbar-chevron =
    .tooltiptext = 残りのブックマークを表示します
bookmarks-sidebar-content =
    .aria-label = ブックマーク
bookmarks-menu-button =
    .label = ブックマークメニュー
bookmarks-other-bookmarks-menu =
    .label = 他のブックマーク
bookmarks-mobile-bookmarks-menu =
    .label = モバイルのブックマーク

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] ブックマークサイドバーを隠す
           *[other] ブックマークサイドバーを表示
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] ブックマークツールバーを隠す
           *[other] ブックマークツールバーを表示
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] ブックマークツールバーを隠す
           *[other] ブックマークツールバーを表示
        }

##

bookmarks-search =
    .label = ブックマークを検索
bookmarks-tools =
    .label = ブックマークツール
bookmarks-subview-edit-bookmark =
    .label = このブックマークを編集...
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .toolbarname = ブックマークツールバー
    .accesskey = B
    .aria-label = ブックマーク
bookmarks-toolbar-menu =
    .label = ブックマークツールバー
bookmarks-toolbar-placeholder =
    .title = ブックマークツールバーの項目
bookmarks-toolbar-placeholder-button =
    .label = ブックマークツールバーの項目
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = 現在のタブをブックマークに追加...

## Library Panel items

library-bookmarks-menu =
    .label = ブックマーク

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = テキストエンコーディングを修復
    .tooltiptext = ページの内容から正しいテキストエンコーディングを推測します

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = 設定
    .tooltiptext =
        { PLATFORM() ->
            [macos] 設定を開きます ({ $shortcut })
           *[other] 設定を開きます
        }
toolbar-overflow-customize-button =
    .label = ツールバーをカスタマイズ...
    .accesskey = C
toolbar-button-email-link =
    .label = ページの URL をメールで送信
    .tooltiptext = このページの URL をメールで送信します
toolbar-button-logins =
    .label = パスワード
    .tooltiptext = 保存されているパスワードを表示、管理します
qrcode-panel-error =
    .message = QR コードの生成に失敗しました。もう一度試してください。
qrcode-copy-button =
    .label = コピー
qrcode-copy-success =
    .message = QR コードをクリップボードにコピーしました。
qrcode-copy-error =
    .message = QR コードのコピーに失敗しました。
qrcode-save-button =
    .label = 保存
qrcode-window-title = QR コード
qrcode-dialog-title = QR コード
qrcode-image =
    .aria-label = QR コード
qrcode-close-button =
    .aria-label = 閉じる
toolbar-button-save-page =
    .label = ページを保存
    .tooltiptext = このページを保存します ({ $shortcut })
toolbar-button-open-file =
    .label = ファイルを開く
    .tooltiptext = ファイルを開きます ({ $shortcut })
toolbar-button-synced-tabs =
    .label = 同期タブ
    .tooltiptext = 他の端末のタブを表示します
toolbar-button-send-tab =
    .label = タブを送信
    .tooltiptext = 現在のタブを別の端末へ送信します
toolbar-button-new-private-window =
    .label = 新しいプライベートウィンドウ
    .tooltiptext = 新しいプライベートブラウジングウィンドウを開きます ({ $shortcut })
toolbar-button-share-tab =
    .label = 共有
    .tooltiptext = このページを共有します
toolbar-button-tab-groups =
    .label = タブグループ
    .tooltiptext = タブグループを表示します
toolbar-button-history =
    .label = 履歴
    .tooltiptext = 履歴を表示します ({ $shortcut })
toolbar-button-find =
    .label = 検索
    .tooltiptext = このページを検索します ({ $shortcut })
toolbar-button-developer =
    .label = 開発ツール
    .tooltiptext = ウェブ開発ツールを開きます ({ $shortcut })
toolbar-button-forget =
    .label = 忘れる
    .tooltiptext = 直前の閲覧履歴を消去します
toolbar-zoom-controls =
    .label = 拡大/縮小
    .title = 拡大/縮小
toolbar-button-zoom-out =
    .label = 縮小
    .tooltiptext = 表示を縮小します ({ $shortcut })
toolbar-button-zoom-reset-tooltip = 拡大/縮小をリセットします ({ $shortcut })
toolbar-button-zoom-in =
    .label = 拡大
    .tooltiptext = 表示を拡大します ({ $shortcut })
toolbar-edit-controls =
    .label = 編集メニュー
    .title = 編集メニュー
toolbar-button-cut =
    .label = 切り取り
    .tooltiptext = 切り取り ({ $shortcut })
toolbar-button-copy =
    .label = コピー
    .tooltiptext = コピー ({ $shortcut })
toolbar-button-paste =
    .label = 貼り付け
    .tooltiptext = 貼り付け ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = このサイトの音声や映像には DRM ソフトウェアが使われており、{ -brand-short-name } での視聴が制限される可能性があります。
eme-notifications-drm-content-playing-manage = 設定を管理
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = 閉じる
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = このページの音声や動画を再生するには DRM を有効にする必要があります。
eme-notifications-drm-content-disabled-button =
    .label = DRM を有効にする
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } がこのページの音声や映像の再生に必要なコンポーネントをインストールしています。後でもう一度試してください。
decoder-doctor-no-codecs-linux-message = 動画を再生するには、対応する動画コーデックをインストールしてください。
decoder-doctor-no-hw-acceleration-message = Microsoft Media Feature Pack をインストールすると、動画の再生品質が向上します。
decoder-doctor-no-pulse-audio-message = 音声を再生するには、PulseAudio をインストールしてください。
decoder-doctor-unsupported-libavcodec-message = libavcodec に脆弱性があるかサポートされていません。動画を再生するには libavcodec を更新してください。
decoder-doctor-decode-error-message = メディアリソースのデコード中にエラーが発生しました。
decoder-doctor-decode-warning-message = メディアリソースのデコード中に復旧可能なエラーが発生しました。
decoder-doctor-learn-how-link = 利用方法
decoder-doctor-report-issue-button =
    .label = サイトの問題を報告
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = { $pluginName } プラグインがクラッシュしました。
plugin-crashed-notification-reload-button =
    .label = ページを再読み込み
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = クラッシュレポートを送信
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = 詐欺サイトとして報告されています！
safebrowsing-reported-attack-site-message = 攻撃サイトとして報告されています！
safebrowsing-reported-unwanted-site-message = 望ましくないソフトウェアサイトとして報告されています！
safebrowsing-reported-harmful-site-message = 有害サイトとして報告されています！
safebrowsing-get-me-out-of-here-button =
    .label = スタートページに戻る
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = 詐欺サイトの誤報告を指摘...
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = 攻撃サイトの誤報告を指摘...
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = インターネットへ接続するには、このネットワークにログインする必要があります。
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = ネットワークのログインページを開く

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = { $hostName } へ移動しようとしましたか？
keyword-uri-fixup-go-to-button =
    .label = はい、{ $hostName } へ移動します
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = ユーザー名
panel-save-update-password-2 =
    .label = パスワード

##

# "More" item in macOS share menu
menu-share-more =
    .label = その他...
menu-share-windows =
    .label = 他のオプション
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [one] リンクをコピー
           *[other] { $count } 個のリンクをコピー
        }
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = 閉じる

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = このサイト ({ $uriHost }) によるポップアップおよびサードパーティによるリダイレクトを許可する
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = ピクチャーインピクチャーの切り替えボタンを隠す
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = ピクチャーインピクチャーの切り替えボタンを右側に移動
    .accesskey = R
picture-in-picture-move-toggle-left =
    .label = ピクチャーインピクチャーの切り替えボタンを左側に移動
    .accesskey = L

##


# Navigator Toolbox

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = ナビゲーション
navbar-downloads =
    .label = ダウンロード
navbar-overflow-2 =
    .tooltiptext = その他のツール
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = 印刷
    .tooltiptext = このページを印刷します... ({ $shortcut })
navbar-home =
    .label = ホーム
    .tooltiptext = { -brand-short-name } のホームページです
navbar-library =
    .label = ブラウジングライブラリー
    .tooltiptext = 履歴や保存したブックマークなどを表示します
navbar-search =
    .title = 検索
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = ブラウザータブ
tabs-toolbar-new-tab =
    .label = 新しいタブ
tabs-toolbar-list-all-tabs-2 =
    .label = タブの検索と管理
    .tooltiptext = タブを検索および管理します
tabs-toolbar-list-all-tabs =
    .label = タブを一覧表示
    .tooltiptext = タブを一覧表示します

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = タブをここにドロップしてピン留めします

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>前回のタブを開きますか？</strong> { -brand-short-name } アプリケーションメニュー<img data-l10n-name="icon"/>の履歴から前回のセッションを復元できます。
restore-session-startup-suggestion-button = 方法を確認

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = 所属組織がこのコンピューター上のローカルファイルへのアクセスをブロックしています

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } はタブ検索になりました
urlbar-addons-shortcut-moved-description = 拡張機能とテーマを開くには { $addonsShortcut } を押します。
urlbar-addons-shortcut-moved-change-shortcuts = ショートカットを管理
urlbar-addons-shortcut-moved-dismiss = 了解

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = ユーザー体験の向上のため、{ -brand-short-name } は自動的にいくつかのデータを { -vendor-short-name } に送信します。
data-reporting-notification-button =
    .label = 共有するデータを選択
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = プライベートブラウジング
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = プライベートブラウジング
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = プライベートブラウジング情報
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = 現在プライベートウィンドウです
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = これは、この端末の他のユーザーからブラウジングを隠すのに役立ちますが、オンラインの行動を隠すものではありません。<a data-l10n-name="learn-more">プライベートブラウジングによくある誤解</a> をお読みください。
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = { $agentName } によるデータ損失防止 (DLP)。詳細情報はクリックしてください。
content-analysis-panel-title2 = Data loss prevention
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = 取り扱いに注意が必要な情報の共有を制御するため所属組織が <b>{ $agentName }</b> を利用しています。<a data-l10n-name="info">詳細情報</a>
content-analysis-panel-title = データ保護
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = データ損失から保護するため所属組織が <b>{ $agentName }</b> を利用しています。<a data-l10n-name="info">詳細情報</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = 拡張機能
    .tooltiptext = 拡張機能

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = 拡張機能
    .tooltiptext =
        拡張機能
        権限が必要です

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = 拡張機能
    .tooltiptext =
        拡張機能
        一部の拡張機能は許可されていません

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = 拡張機能
    .tooltiptext =
        拡張機能
        一部の拡張機能が無効になっています

## Private browsing reset button

reset-pbm-panel-heading2 = データを消去して新しいプライベートセッションを開始しますか？
reset-pbm-panel-description3 = これは履歴と Cookie を消去し、ウェブサイトからログアウトします。プライベートウィンドウを一旦閉じて開き直します。
reset-pbm-panel-description2 = これはプライベートウィンドウを閉じずに、履歴、Cookie、その他すべてのサイトデータを削除します。
reset-pbm-panel-always-ask-checkbox =
    .label = 常に確認する
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = キャンセル
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = プライベートセッションを消去
    .accesskey = l
reset-pbm-panel-complete = プライベートセッションのデータを削除しました
reset-pbm-toolbar-button2 =
    .label = プライベートセッションを消去
    .tooltiptext = プライベートセッションを消去します

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = すべての閲覧データを削除しますか？
fire-button-panel-description = この操作は履歴、Cookie、サイトデータを削除し、ウェブサイトからログアウトします。このウィンドウが閉じられ、{ -brand-short-name } が新しいウィンドウを開きます。
fire-button-panel-choose-description = 削除したくないデータがある場合は、そのデータの種類を選んでください。
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = 選択...
fire-button-panel-cancel-button =
    .label = キャンセル
    .accesskey = C
fire-button-panel-confirm-button =
    .label = すべて削除
    .accesskey = D
fire-button-panel-complete = 閲覧データを削除しました
fire-button-toolbar-button2 =
    .label = 閲覧データの一部またはすべてを削除
    .tooltiptext = 閲覧データの一部またはすべてを削除します

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } がこのページの自動再読み込みをブロックしました。
refresh-blocked-redirect-label = { -brand-short-name } がこのページから他のページへの自動転送をブロックしました。
refresh-blocked-allow =
    .label = 許可
    .accesskey = A

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = 安全で簡単に使えるメールマスクがあなたのメールアドレスを隠して個人情報を守り、迷惑メールを防ぎます。
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = メールマスクに送信されたすべてのメールは (これらをブロックしない限り) <strong>{ $useremail }</strong> に転送されます。
firefox-relay-offer-legal-notice = [メールマスクを使用] をクリックすることにより、<label data-l10n-name="tos-url">サービス利用規約</label> および <label data-l10n-name="privacy-url">プライバシー通知</label> に同意したものとみなされます。
firefox-relay-offer-legal-notice-1 = アカウント登録してメールマスクを作成することにより、<label data-l10n-name="tos-url">サービス利用規約</label> および <label data-l10n-name="privacy-url">プライバシー通知</label> に同意したものとみなされます。

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (未検証)
popup-notification-xpinstall-prompt-learn-more = アドオンの安全なインストールの詳細
popup-notification-xpinstall-prompt-block-url = 詳細を見る
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = プライベートウィンドウで拡張機能の実行を許可する
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = 技術データと対話データを拡張機能の開発者と共有する
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [1] { -brand-short-name } がこのサイトでポップアップウィンドウをブロックしました。
       *[other] { -brand-short-name } がこのサイトで { $popupCount } 個のポップアップウィンドウをブロックしました。
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } がこのサイトでリダイレクトをブロックしました。
        [1] { -brand-short-name } がこのサイトでポップアップウィンドウとリダイレクトをブロックしました。
       *[other] { -brand-short-name } がこのサイトで { $popupCount } 個のポップアップウィンドウとリダイレクトをブロックしました。
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message =
    { $popupCount ->
       *[other] { -brand-short-name } がこのサイトで { $popupCount } 個以上のポップアップウィンドウをブロックしました。
    }
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
       *[other] { -brand-short-name } がこのサイトで { $popupCount } 個以上のポップアップウィンドウとリダイレクトをブロックしました。
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] 設定
           *[other] 設定
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = “{ $popupURI }” を表示
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = “{ $redirectURI }” を表示

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Windows のファイルダイアログを開けませんでした。ファイルまたはフォルダーを選択できません。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Windows のファイルダイアログを開けませんでした。ファイルは { $path } に保存されます。
file-picker-failed-save-nowhere = Windows のファイルダイアログを開けませんでした。既定のフォルダーが見つからないためファイルは保存されません。
file-picker-crashed-open = Windows のファイルダイアログがクラッシュしました。ファイルまたはフォルダーを選択できません。
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Windows のファイルダイアログがクラッシュしました。ファイルは { $path } に保存されます。
file-picker-crashed-save-nowhere = Windows のファイルダイアログがクラッシュしました。既定のフォルダーが見つからないためファイルは保存されません。

# Button used with file-picker-crashed-save-default. Opens the folder in Windows
# Explorer, with the saved file selected and in focus.
#
# The wording here should be consistent with the Windows variant of
# `downloads-cmd-show-menuitem-2` and similar messages.

file-picker-crashed-show-in-folder =
    .label = フォルダーを開く
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = 未検証のため、無効になっているアドオンがあります。
unsigned-addons-disabled-learn-more =
    .label = 詳細
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = このページが { -brand-short-name } の動作を遅くしています。このページを停止して、ブラウザーの動作を速くします。
process-hang-nonspecific-tab-message = ウェブページが { -brand-short-name } の動作を遅くしています。ページを停止して、ブラウザーの動作を速くします。
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” が { -brand-short-name } の動作を遅くしています。ページを停止して、ブラウザーの動作を速くします。
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” が { -brand-short-name } の動作を遅くしています。拡張機能を停止して、ブラウザーの動作を速くします。
process-hang-addon-learn-more =
    .value = 詳細情報
process-hang-stop-button =
    .label = 停止
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = セットアップを完了
onboarding-aw-finish-setup-button =
    .label = セットアップ完了
    .tooltiptext = { -brand-short-name } のセットアップを完了します

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = 強化型トラッキング防止はオンです
trustpanel-etp-label-disabled = 強化型トラッキング防止はオフです
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = 強化型トラッキング防止: { $host } でオン
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = 強化型トラッキング防止: { $host } でオフ
trustpanel-etp-description-enabled = このサイトでの動作に問題があるときはトラッキング防止をオフにしてみてください。
trustpanel-etp-description-disabled = { -brand-product-name } は企業によるユーザー追跡を減らします。トラッキング防止をオンにすると、できるだけ多くのトラッカーをブロックします。
trustpanel-connection-label-secure = 接続は安全です
trustpanel-connection-label-insecure = 接続は安全ではありません
trustpanel-header-enabled = { -brand-product-name } が保護しています
trustpanel-description-enabled2 = あなたは追跡から保護されています。何か見つけたらお知らせします。
trustpanel-header-enabled-insecure = このサイトでは注意してください
trustpanel-description-enabled-insecure = { -brand-product-name } が不審な動作を検出しました。
trustpanel-header-disabled = 保護がオフになっています
trustpanel-description-disabled = { -brand-product-name } によるトラッキング防止が動作していません。オンに戻すことをおすすめします。
trustpanel-clear-cookies-button = Cookie とサイトデータを消去
trustpanel-privacy-link = プライバシー設定
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = { $host } の Cookie とサイトデータを消去します
trustpanel-clear-cookies-description = Cookie とサイトデータを消去するとウェブサイトからログアウトし、買い物カゴが空になります。
trustpanel-clear-cookies-subview-button-clear = 消去
trustpanel-clear-cookies-subview-button-cancel = キャンセル
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = { $host } への接続の保護
trustpanel-siteinformation-morelink = サイトの詳細情報
trustpanel-blocker-see-all = すべて表示
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = { $host } におけるトラッキング防止

## The urlbar trust icon & panel

# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = 安全でない
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label = { $count } 個のトラッカーをブロックしました

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } は企業によるユーザー追跡を減らします。トラッキング防止をオンにすると、できるだけ多くのトラッカーをブロックします。
trustpanel-blocked-header = { -brand-product-name } が以下のトラッカーをブロックしています:
trustpanel-tracking-header = { -brand-product-name } はサイトが動作するように以下のトラッカーを許可しています:
trustpanel-tracking-description = トラッカーがブロックされると、一部のボタンやフォーム、ログインフィールドがうまく動作しない場合があります。
trustpanel-insecure-section-header = 接続が安全ではありません
trustpanel-insecure-description = このサイトに送信するデータは暗号化されません。第三者によるデータの盗聴や窃取、改竄のおそれがあります。
trustpanel-list-label-tracking-cookies = { $count } 個のクロスサイトトラッキング Cookie
trustpanel-list-label-tracking-content = トラッキングコンテンツ
trustpanel-list-label-fingerprinter = { $count } 個のフィンガープリント採取
trustpanel-list-label-social-tracking = { $count } 個のソーシャルメディアトラッカー
trustpanel-list-label-cryptominer = { $count } 個の暗号通貨マイニング
trustpanel-social-tracking-blocking-tab-header = { -brand-product-name } が { $count } 個のソーシャルメディアトラッカーをブロックしました
trustpanel-social-tracking-not-blocking-tab-header = { -brand-product-name } が { $count } 個のソーシャルメディアトラッカーを許可しました
trustpanel-tracking-cookies-blocking-tab-header = { -brand-product-name } が { $count } 個のクロスサイトトラッキング Cookie をブロックしました
trustpanel-tracking-cookies-not-blocking-tab-header = { -brand-product-name } が { $count } 個のクロスサイトトラッキング Cookie を許可しました
trustpanel-tracking-content-blocking-tab-header = { -brand-product-name } が { $count } 個のトラッカーをブロックしました
trustpanel-tracking-content-not-blocking-tab-header = { -brand-product-name } が { $count } 個のトラッカーを許可しました
trustpanel-tracking-content-tab-list-header = 以下のサイトがあなたを追跡しようとしています:
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name } が { $count } 個のフィンガープリント採取をブロックしました
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name } が { $count } 個のフィンガープリント採取を許可しました
trustpanel-fingerprinter-list-header = 以下のサイトがあなたのフィンガープリントを採取しようとしています:
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name } が { $count } 個の暗号通貨マイニングをブロックしました
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name } が { $count } 個の暗号通貨マイニングを許可しました
trustpanel-cryptominer-tab-list-header = 以下のサイトがあなたのコンピューターを暗号通貨マイニングに利用しようとしています:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = このサイトのアカウントをお持ちですか？
trustpanel-breachalerts-anonymous-breached-description = 過去 12 か月以内にこのサイトのデータが漏洩していたことを { -brand-product-name } が確認しました。あなたのアカウントが含まれていないか調べてください。
trustpanel-breachalerts-anonymous-breached-button-dismiss = 閉じる
trustpanel-breachalerts-anonymous-breached-button-check-monitor = 無料のスキャンを開始
trustpanel-blocker-section-header2 = このサイトで <span data-l10n-name="count">{ $count }</span> 個のトラッカーをブロックしました

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>サイトが動作しない？</strong> ページを再度読み込んで一時的にトラッキング防止を弱めます。
reduced-protection-infobar-reload-button = 再読み込み
    .accesskey = R
reduced-protection-infobar-never-show-button = 今後は表示しない
    .accesskey = D


identity-allow-site-data = vOrbit-lite: 常にこのサイトのクッキーとデータを保存する
