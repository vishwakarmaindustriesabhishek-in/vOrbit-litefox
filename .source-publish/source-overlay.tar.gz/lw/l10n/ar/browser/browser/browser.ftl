# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } التصفح الخفي
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = تصفح الوِب بسرعة وخصوصية
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — التصفح الخاص
       *[other] { -brand-full-name } التصفح الخاص
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = التصفح الخاص
popups-infobar-dont-show-message2 =
    .label = لا تعرض هذه الرسالة عند حظر النوافذ المنبثقة أو عمليات إعادة التوجيه من جهات خارجية
    .accesskey = ر
edit-popup-settings2 =
    .label = أدر إعدادات إعادة التوجيه المنبثقة والجهات الخارجية…
    .accesskey = د
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = الرسائل والبريد والمزيد...
    .accesskey = ل
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = شارك…
    .accesskey = ر
urlbar-identity-button =
    .aria-label = اعرض معلومات الموقع

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = افتح لوحة رسائل التثبيت
urlbar-web-notification-anchor =
    .tooltiptext = غيّر ما إذا ما كنت تسمح باستلام إشعارات من الموقع
urlbar-midi-notification-anchor =
    .tooltiptext = افتح لوحة MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = افتح لوحة التسلسل
urlbar-eme-notification-anchor =
    .tooltiptext = أدِر استخدام برمجيات إدارة الحقوق الرقمية
urlbar-web-authn-anchor =
    .tooltiptext = افتح لوحة استيثاق الوِب
urlbar-canvas-notification-anchor =
    .tooltiptext = أدِر تصاريح استخراج ألواح الرسم
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = أدر مشاركة ميكروفونك مع هذا الموقع
urlbar-default-notification-anchor =
    .tooltiptext = افتح لوحة الرسائل
urlbar-geolocation-notification-anchor =
    .tooltiptext = افتح لوحة طلب المكان
urlbar-localhost-notification-anchor =
    .tooltiptext = أدر وصول الجهاز المحلي لهذا الموقع
urlbar-local-network-notification-anchor =
    .tooltiptext = أدر مشاركة الوصول إلى الشبكة المحلية مع هذا الموقع
urlbar-xr-notification-anchor =
    .tooltiptext = افتح لوحة تصاريح الواقع الافتراضي
urlbar-storage-access-anchor =
    .tooltiptext = افتح لوحة تصاريح نشاط التصفّح
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = أدر مشاركة نوافذك أو شاشتك مع هذا الموقع
urlbar-indexed-db-notification-anchor =
    .tooltiptext = افتح لوحة رسائل مساحة التخزين دون اتصال
urlbar-password-notification-anchor =
    .tooltiptext = افتح لوحة رسائل حفظ كلمة السر
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = أدر مشاركة كمرتك و ميكروفونك مع هذا الموقع
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = أدِر مشاركة السماعات الأخرى مع هذا الموقع
urlbar-autoplay-notification-anchor =
    .tooltiptext = افتح لوحة التشغيل التلقائي
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = حفظ البيانات في مساحة تخزين دائمة
urlbar-addons-notification-anchor =
    .tooltiptext = افتح لوحة رسائل تثبيت الإضافات
urlbar-search-tips-confirm = حسنًا، فهمت
urlbar-search-tips-confirm-short = فهمت
urlbar-result-menu-button =
    .title = افتح القائمة
urlbar-result-menu-button-feedback = الانطباع
    .title = افتح القائمة
urlbar-result-menu-learn-more2 = اطّلع على المزيد
    .accesskey = ط
urlbar-result-menu-remove-from-history2 = احذف من التأريخ
    .accesskey = خ
urlbar-result-menu-tip-get-help2 = احصل على مساعدة
    .accesskey = ص
urlbar-result-menu-dismiss-suggestion2 = أهمل هذا الاقتراح
    .accesskey = م
urlbar-result-menu-manage-firefox-suggest2 = أدر { -firefox-suggest-brand-name }
    .accesskey = د
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = بلّغ عن موقع غير دقيق
    .accesskey = ب
urlbar-result-menu-show-less-frequently3 = اعرض أقل تواترا
    .accesskey = ا
urlbar-result-menu-dont-show-weather-suggestions3 = لا تعرض اقتراحات الطقس
    .accesskey = ل
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = بلّغ عن موقع غير دقيق
urlbar-result-menu-show-less-frequently2 = اعرض أقل تواترا
urlbar-result-menu-dont-show-weather-suggestions2 = لا تعرض اقتراحات الطقس
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = أهمل هذا الاقتراح
    .accesskey = م
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = احذف من التأريخ
    .accesskey = ذ
urlbar-result-menu-learn-more =
    .label = اطّلع على المزيد
    .accesskey = ز
urlbar-result-menu-remove-from-history =
    .label = احذف من التأريخ
    .accesskey = خ
urlbar-result-menu-tip-get-help =
    .label = احصل على مساعدة
    .accesskey = ص
urlbar-result-menu-dismiss-suggestion =
    .label = أهمل هذا الاقتراح
    .accesskey = م
urlbar-result-menu-manage-firefox-suggest =
    .label = أدر { -firefox-suggest-brand-name }
    .accesskey = د
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = بلّغ عن موقع غير دقيق
urlbar-result-menu-show-less-frequently =
    .label = اعرض أقل تواترا
urlbar-result-menu-dont-show-weather-suggestions =
    .label = لا تعرض اقتراحات الطقس
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = افتح القائمة
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = شكرًا على تعليقك
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = شكرًا على تعليقك. لن ترى اقتراحات الطقس بعد الآن.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = اكتب بحروف أقل، و جِد نتائج أكثر: ابحث مستخدمًا { $engineName } مباشرة من شريط العنوان.
urlbar-search-tips-redirect-2 = ابدأ البحث من شريط العنوان لترى الاقتراحات من { $engineName } و من تأريخ التصفح.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = اختر هذا الاختصار لتجد ما تريد بسرعة أكبر.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = العلامات
urlbar-search-mode-tabs = الألسنة
urlbar-search-mode-history = التأريخ
urlbar-search-mode-actions = الإجراءات

##

urlbar-geolocation-blocked =
    .tooltiptext = لقد حجبت معلومات مكانك عن هذا الموقع.
urlbar-localhost-blocked =
    .tooltiptext = لقد حجبت اتصالات الجهاز المحلي لهذا الموقع.
urlbar-local-network-blocked =
    .tooltiptext = لقد حجبت اتصالات الشبكة المحلية لهذا الموقع.
urlbar-xr-blocked =
    .tooltiptext = لقد حجبت الوصول إلى جهاز الواقع الافتراضي عن هذا الموقع.
urlbar-web-notifications-blocked =
    .tooltiptext = لقد حجبت الإشعارات عن هذا الموقع.
urlbar-camera-blocked =
    .tooltiptext = لقد حجبت كمرتك عن هذا الموقع.
urlbar-microphone-blocked =
    .tooltiptext = لقد حجبت ميكروفونك عن هذا الموقع.
urlbar-screen-blocked =
    .tooltiptext = لقد حجبت هذا الموقع من مشاركة شاشتك.
urlbar-persistent-storage-blocked =
    .tooltiptext = لقد حجبت الحفظ الدائم للبيانات عن هذا الموقع.
urlbar-popup-blocked2 =
    .tooltiptext = لقد حظرت النوافذ المنبثقة وعمليات إعادة التوجيه من جهات خارجية لهذا الموقع الإلكتروني.
urlbar-autoplay-media-blocked =
    .tooltiptext = لقد حجبت تشغيل الوسائط التي تحتوي صوتا تلقائيا في هذا الموقع.
urlbar-canvas-blocked =
    .tooltiptext = لقد منعت استخراج بيانات رقعة الرسم في هذا الموقع.
urlbar-midi-blocked =
    .tooltiptext = لقد حجبنا عن هذا الموقع الوصول إلى MIDI.
urlbar-serial-blocked =
    .tooltiptext = لقد حجبت الوصول إلى منفذ التسلسل لهذا الموقع.
urlbar-install-blocked =
    .tooltiptext = حجبت تثبيت الإضافات في هذا الموقع.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = حرّر هذه العلامة ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = علّم هذه الصفحة ({ $shortcut })
urlbar-split-view-button =
    .aria-label = عرض منقسم
    .tooltiptext = عرض منقسم

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = ألصق وانتقل
    .accesskey = أ
urlbar-menuitem-paste-and-search =
    .label = ألصق وابحث
    .accesskey = ص

## Searchbar context menu

clear-search-history =
    .label = امسح تأريخ البحث
    .accesskey = م

## Page Action Context Menu

page-action-manage-extension2 =
    .label = أدِر الامتدادات…
    .accesskey = د
page-action-remove-extension2 =
    .label = أزِل الامتداد
    .accesskey = ز

## Auto-hide Context Menu

full-screen-autohide =
    .label = أخفِ شريط الأدوات
    .accesskey = خ
full-screen-exit =
    .label = اخرج من وضع ملء الشاشة
    .accesskey = و

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = ابحث هذه المرة بـ:
search-one-offs-change-settings-compact-button =
    .tooltiptext = غيّر إعدادات البحث
search-one-offs-context-open-new-tab =
    .label = ابحث في لسان جديد
    .accesskey = س
search-one-offs-context-set-as-default =
    .label = اجعله محرك البحث الافتراضي
    .accesskey = ف
search-one-offs-context-set-as-default-private =
    .label = اضبطه ليكون محرّك البحث المبدئي في النوافذ الخاصة
    .accesskey = ن
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = ‏{ $engineName } ‏({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = أضِف محرك البحث ”{ $engineName }“
    .label = أضِف ”{ $engineName }“
    .tooltiptext = أضِف محرك البحث ”{ $engineName }“
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = أضف محرك بحث
    .accesskey = أ
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = أضف محرك بحث

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = العلامات ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = الألسنة ({ $restrict })
search-one-offs-history =
    .tooltiptext = التأريخ ({ $restrict })
search-one-offs-actions =
    .tooltiptext = الإجراءات ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = اعرض الإضافات
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = الإضافات, اﻹمتدادات, إمتداد, extensions, themes, addons, add-ons
# Opens preferences page at AI controls
quickactions-manageai = أدِر عناصر التحكم في الذكاء الاصطناعي
quickactions-cmd-manageai = عطّل الذكاء الاصطناعي أو أوقِف تشغيل الذكاء الاصطناعي أو أدِر الذكاء الاصطناعي
# Opens the bookmarks library window
quickactions-bookmarks2 = أدِر العلامات
quickactions-cmd-bookmarks = العلامات
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = امسح التأريخ الحالي
quickactions-cmd-clearrecenthistory2 = ملفات تعريف الارتباط، مسح ملفات تعريف الارتباط، ذاكرة التخزين المؤقت، مسح ذاكرة التخزين المؤقت، بيانات التصفح، مسح بيانات التصفح، تأريخ التصفح، مسح سجل التصفح الأخير
# Opens about:downloads page
quickactions-downloads2 = اعرض التنزيلات
quickactions-cmd-downloads = التنزيلات
# Opens about:addons page in the extensions section
quickactions-extensions = أدِر الامتدادات
quickactions-cmd-extensions2 = امتدادات, ملحقات, إضافات
# Opens Firefox View
quickactions-firefoxview = افتح { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = افتح { -firefoxview-brand-name }، { -firefoxview-brand-name }، افتح العرض، عرض
# Opens SUMO home page
quickactions-help = مساعدة { -brand-product-name }
quickactions-cmd-help = المساعدة والدعم
# Opens the devtools web inspector
quickactions-inspector2 = افتح أدوات المطورين
quickactions-cmd-inspector2 = المفتش, أدوات التطوير, أدوات التطوير, inspector, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = اختر لونًا
quickactions-cmd-colorpicker = منتقي الألوان، قطارة الألوان، اختر لونًا
# Opens Firefox Library
quickactions-cmd-library = المكتبة
quickactions-library = افتح المكتبة
# Opens about:logins
quickactions-logins2 = أدِر كلمات السر
quickactions-cmd-logins = جلسات الولوج، كلمات السر
# Mutes all tabs playing audio
quickactions-mute = اكتم صوت الألسنة التي تشغل الصوت
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = اكتم, كتم الصوت, ششش, سكوت
# Opens the print dialog
quickactions-print2 = اطبع الصفحة
quickactions-cmd-print = اطبع
# Opens the print dialog at the save to PDF option
quickactions-savepdf = احفظ الصفحة بصيغة PDF
quickactions-cmd-savepdf2 = pdf, احفظ الصفحة, save page
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = افتح محرِّر PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = افتح نافذة خاصة
quickactions-cmd-private = التصفّح الخاص
# Opens a SUMO article explaining how to refresh
quickactions-refresh = أعد تحميل { -brand-short-name }
quickactions-cmd-refresh = حدّث
# Restarts the browser
quickactions-restart = أعِد تشغيل { -brand-short-name }
quickactions-cmd-restart = أعِد التشغيل
# Opens the screenshot tool
quickactions-screenshot3 = خذ لقطة شاشة
quickactions-cmd-screenshot2 = لقطة الشاشة, خذ لقطة شاشة, screenshot, take a screenshot
# Opens about:translations
quickactions-translate = ترجم
quickactions-cmd-translate = ترجم
# Opens about:preferences
quickactions-settings2 = أدِر الإعدادات
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = الإعدادات, التفضيلات, الخيارات, الإدارة, settings, preferences, options, manage
# Opens about:addons page in the themes section
quickactions-themes = أدِر السمات
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = سمات, ملحقات, إضافات
# Opens a SUMO article explaining how to update the browser
quickactions-update = حدِّث { -brand-short-name }
quickactions-cmd-update = حدّث
# Opens the view-source UI with current pages source
quickactions-viewsource2 = اعرض مصدر هذه الصفحة
quickactions-cmd-viewsource2 = عرض المصدر, المصدر, مصدر الصفحة, view source, source, page source
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = افتح { -firefoxlabs-brand-name }
quickactions-cmd-labs = المختبرات، التجارب
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = تعرف على المزيد حول الإجراءات السريعة
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = اضغط على tab لتحديد:

## Bookmark Panel

bookmarks-add-bookmark = أضِف علامة
bookmarks-edit-bookmark = حرّر العلامة
bookmark-panel-cancel =
    .label = ألغِ
    .accesskey = ل
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label =
        { $count ->
            [zero] لا تزل أي علامات
            [one] أزِل العلامة
            [two] أزِل العلامتان
            [few] أزِل { $count } علامات
            [many] أزِل { $count } علامة
           *[other] أزل { $count } علامة
        }
    .accesskey = ع
bookmark-panel-show-editor-checkbox =
    .label = اعرض المحرر عند الحفظ
    .accesskey = ظ
bookmark-panel-save-button2 =
    .label = احفظ
    .accesskey = ا
bookmark-panel-save-button =
    .label = احفظ
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = معلومات الموقع { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = أمن اتصال { $host }
identity-connection-not-secure = الاتصال غير آمن
identity-connection-secure = الاتصال آمن
identity-connection-failure = فشل الاتصال
identity-connection-internal = هذه صفحة { -brand-short-name } آمنة.
identity-connection-file = هذه الصفحة مخزنة على حاسوبك.
identity-connection-associated = حمِّلت هذه الصفحة من صفحة أخرى.
identity-extension-page = حمِّلت هذه الصفحة من امتداد.
identity-active-blocked = حجب { -brand-short-name } الأجزاء غير الآمنة في هذه الصفحة.
identity-custom-root = تحققَ من هذا الاتصال مُصْدِر شهادات لا تعرفه Mozilla.
identity-passive-loaded = بعض أجزاء هذه الصفحة غير آمنة (مثل الصور).
identity-active-loaded = لقد أوقفت الحماية على هذه الصفحة.
identity-weak-encryption = تستخدم هذه الصفحة تعمية ضعيفة.
identity-https-only-connection-upgraded = (ترقّى إلى HTTPS)
identity-https-only-label2 = ترقية هذا الموقع تلقائيًا إلى اتصال آمن
identity-https-only-dropdown-on =
    .label = مفعّل
identity-https-only-dropdown-off =
    .label = معطّل
identity-https-only-dropdown-off-temporarily =
    .label = معطّل مؤقتًا
identity-https-only-info-turn-on3 = فعل ترقية HTTPS لهذا الموقع إذا كنت تريد { -brand-short-name } ترقية الاتصال إن أمكن.
identity-https-only-info-turn-off3 = إن شككت أن الصفحة مُعطلة، فقد تحتاج إلى إيقاف تشغيل ترقيات HTTPS لهذا الموقع لإعادة التحميل باستخدام HTTP الغير آمن.
identity-https-only-info-no-upgrade = تعذرت ترقية الاتصال من HTTP.
identity-permissions-storage-access-header = الكعكات بين المواقع
identity-permissions-storage-access-hint = يمكن لهذه الأطراف استعمال الكعكات وبيانات المواقع المشتركة أثناء وجودك في هذا الموقع.
identity-permissions-storage-access-learn-more = اطّلع على المزيد
identity-permissions-reload-hint = قد تحتاج إعادة تحميل الصفحة لتطبيق التغييرات.
identity-clear-site-data =
    .label = امسح الكعكات و بيانات المواقع…
identity-connection-not-secure-security-view = لست متصلاً مع هذا الموقع بأمان.
identity-connection-verified = أنت متصل مع هذا الموقع بأمان.
identity-ev-owner-label2 = أُصدرت الشّهادة إلى
identity-verifier-label2 = تحققَ منها
identity-ev-owner-label = أُصدرت الشّهادة إلى:
identity-verifier-label = تحقق منها:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = مؤهل وفقًا لما هو محدد في اللائحة (الاتحاد الأوروبي) 2024/1183.
identity-description-custom-root2 = لم تتعرّف Mozilla على مُصْدِر الشهادات هذا. لربّما أضافه نظام التشغيل أو أحد المدراء.
identity-cert-exception-overridden = لقد أضفت استثناء آمن لهذا الموقع.
identity-remove-cert-exception =
    .label = أزِل الاستثناء
    .accesskey = س
identity-description-insecure = اتصالك بهذا الموقع ليس خاصًّا. يمكن للآخرين مطالعة المعلومات التي ترسلها (مثل كلمات السر، و الرسائل، و بطاقات الائتمان و غيرها).
identity-description-weak-cipher-intro = اتصالك بهذا الموقع يستخدم تعمية ضعيفة وليس خاصًّا أيضًا.
identity-description-weak-cipher-risk = يمكن للآخرين الاطلاع على معلوماتك أو تغيير سلوك الموقع.
identity-description-active-blocked2 = حجب { -brand-short-name } الأجزاء غير الآمنة في هذه الصفحة.
identity-description-passive-loaded = اتصالك ليس خاصًا و يمكن للآخرين مطالعة المعلومات التي تشاركها مع الموقع.
identity-description-passive-loaded-insecure2 = يحوي هذا الموقع محتوى غير آمن (مثل الصور).
identity-description-passive-loaded-mixed2 = مع أنّ { -brand-short-name } حجب بعض المحتويات، إلا أن هناك أخرى غير آمنة ما زالت في الصفحة (مثل الصور).
identity-description-active-loaded = يحوي هذا الموقع محتوى غير آمن (مثل السكربتات) و اتصالك به ليس خاصا.
identity-description-active-loaded-insecure = يمكن للآخرين مطالعة المعلومات التي تشاركها مع الموقع (مثل كلمات السر، و الرسائل، و بطاقات الائتمان و غيرها).
identity-description-tls-key-logging-heading = قد لا يكون اتصالك خاصًا
identity-description-tls-key-logging-message = قد يتمكن تطبيق أو خدمة ما من رؤية حركة البيانات المُعمّاة الخاصة بك من هذا الموقع.
identity-more-info-link-text =
    .label = المزيد من المعلومات

## Window controls

browser-window-minimize-button =
    .tooltiptext = صغّر
browser-window-maximize-button =
    .tooltiptext = كبِّر
browser-window-restore-down-button =
    .tooltiptext = أنزِله
browser-window-close-button =
    .tooltiptext = أغلِق
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = ارجع

## Bookmarks toolbar items

browser-import-button2 =
    .label = استورِد العلامات…
    .tooltiptext = استورِد العلامات من متصفّح آخر إلى { -brand-short-name }.
bookmarks-toolbar-empty-message = ضَع علاماتك هنا في شريط العلامات لتصل إليها بسرعة. <a data-l10n-name="manage-bookmarks">أدِر العلامات…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = الكمرة:
    .accesskey = ك
popup-select-camera-icon =
    .tooltiptext = الكمرة
popup-select-microphone-device =
    .value = الميكروفون
    .accesskey = م
popup-select-microphone-icon =
    .tooltiptext = الميكروفون
popup-select-speaker-icon =
    .tooltiptext = السماعات
popup-select-window-or-screen =
    .label = النافذة أو الشاشة:
    .accesskey = ن
popup-all-windows-shared = ستُشارك كل النوافذ الظاهرة على شاشتك.

## WebRTC window or screen share tab switch warning

sharing-warning-window = أنت تُشارك { -brand-short-name }. يقدر الآخرين على رؤيتك حين تنتقل إلى لسان جديد.
sharing-warning-screen = أنت تُشارك شاشتك كلها. يقدر الآخرين على رؤيتك حين تنتقل إلى لسان جديد.
sharing-warning-proceed-to-tab =
    .label = واصِل إلى اللسان
sharing-warning-disable-for-session =
    .label = أوقِف حماية المشاركة لهذه الجلسة

## WebSerial "select a port" popup

webserial-select-port-label = حدّد منفذًا تسلسليًا:
webserial-no-ports-available = لا توجد منافذ تسلسلية متاحة

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = أغلق
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = ابحث أو أدخل عنوانا
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = أدخل العنوان
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = ابحث مستعملًا { $name }
    .placeholder = ابحث في الوِب
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = ابحث عن { $name }
    .placeholder = أدخِل نص البحث
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = ابحث في العلامات
    .placeholder = أدخِل نص البحث
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = ابحث في التأريخ
    .placeholder = أدخِل نص البحث
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = ابحث في الألسنة
    .placeholder = أدخِل نص البحث
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = إجراءات البحث
    .placeholder = أدخِل نص البحث
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = ‫ابحث بـ { $name } أو أدخِل عنوانا
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = المتصفح في وضع التحكم عن بعد (السبب: { $component })
urlbar-permissions-granted =
    .tooltiptext = منحت هذا الموقع صلاحيات أخرى.
urlbar-switch-to-tab =
    .value = انتقل إلى اللسان:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = الامتداد:
urlbar-go-button2 =
    .title = انتقل للعنوان في شريط الموقع
urlbar-page-action-button =
    .tooltiptext = إجراءات الصفحة
urlbar-revert-button =
    .tooltiptext = أظهِر العنوان في شريط الموقع

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = ابحث بـ { $engine } في نافذة خاصة
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = ابحث في نافذةٍ خاصة
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = ابحث بـ { $engine }
urlbar-result-action-sponsored = نتيجة مموّلة
urlbar-result-action-switch-tab = انتقل إلى اللسان
urlbar-result-action-move-tab-to-split-view = انقل اللسان إلى عرض منقسم
urlbar-result-action-visit = زُر
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = انتقل للسان · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = مجموعة غير مسمّاة
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = زر من الحافظة
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = اضغط Tab للبحث بـ { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = اضغط Tab للبحث عبر { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = ابحث بـ { $engine } مباشرة من شريط العنوان
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = ابحث مستعملًا { $engine } مباشرة من شريط العنوان
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = انسخ
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = غير محدد
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = امتداد { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = يُنصح به
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> في { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> في { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> في { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · مموّل
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = اسأل
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = آخر زيارة لك { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = آخر زيارة لك كانت { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = مُعلّمة { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = آخر زيارة { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = احصل على بيانات سوق الأسهم مباشرة في شريط البحث
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = اعرض آخر مستجدات السوق والمزيد من شركائنا عند مشاركة بيانات استعلام البحث مع { -vendor-short-name }. <a data-l10n-name="learn-more-link">اطّلع على المزيد</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = اعرض الاقتراحات
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = ليس الآن
urlbar-result-realtime-opt-in-dismiss = أهمِل
urlbar-result-realtime-opt-in-dismiss-all2 = لا تعرض هذه الاقتراحات
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = لا تعرض اقتراحات السوق
    .accesskey = ل
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = لا تعرض اقتراحات السوق
urlbar-result-realtime-opt-in-dismiss-all =
    .label = لا تعرض هذه الاقتراحات
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = لا تعرض اقتراحات السوق
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = شكرًا لملاحظاتك. لن ترى اقتراحات السوق بعد الآن.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = اقتراحات حول سوق الأسهم
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = شكرًا لملاحظاتك. لن ترى هذه الاقتراحات بعد الآن.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown =
    { $daysUntilStart ->
        [zero] { $name } · خلال { $daysUntilStart } يوم
        [one] { $name } · خلال يوم
        [two] { $name } · خلال يومين
        [few] { $name } · خلال { $daysUntilStart } أيام
        [many] { $name } · خلال { $daysUntilStart } يومًا
       *[other] { $name } · خلال { $daysUntilStart } يوم
    }
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range =
    { $daysUntilStart ->
        [zero] { $name } · يبدأ خلال { $daysUntilStart } يوم
        [one] { $name } · يبدأ خلال يوم
        [two] { $name } · يبدأ خلال يومين
        [few] { $name } · يبدأ خلال { $daysUntilStart } أيام
        [many] { $name } · يبدأ خلال { $daysUntilStart } يومًا
       *[other] { $name } · يبدأ خلال { $daysUntilStart } يوم
    }
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing =
    { $daysUntilEnd ->
        [zero] { $name } · ينتهي خلال { $daysUntilEnd } يوم
        [one] { $name } · ينتهي خلال يوم
        [two] { $name } · ينتهي خلال يومين
        [few] { $name } · ينتهي خلال { $daysUntilEnd } أيام
        [many] { $name } · ينتهي خلال { $daysUntilEnd } يومًا
       *[other] { $name } · ينتهي خلال { $daysUntilEnd } يوم
    }
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · اليوم
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · ينتهي اليوم

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = ابحث بـ { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - بحث { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - ابحث بـ { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }، اختر محرك بحث
urlbar-searchmode-button-no-engine2 =
    .title = لم تحدد اختصار، اختر اختصارًا
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = عُطّل البحث بالكلمات المفتاحية
urlbar-searchmode-dropmarker2 =
    .title = اختر محرك بحث
urlbar-searchmode-bookmarks4 = العلامات
urlbar-searchmode-tabs4 = الألسنة
urlbar-searchmode-history4 = التأريخ
urlbar-searchmode-actions4 = الإجراءات
urlbar-searchmode-bookmarks3 = العلامات
    .accesskey = م
urlbar-searchmode-tabs3 = الألسنة
    .accesskey = ا
urlbar-searchmode-history3 = التأريخ
    .accesskey = ا
urlbar-searchmode-actions3 = الإجراءات
    .accesskey = ء
urlbar-searchmode-exit-button2 =
    .title = أغلق
urlbar-searchmode-default2 =
    .title = محرّك البحث المبدئي
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = أضِف ”{ $engineName }“
    .title = أضِف محرك البحث ”{ $engineName }“
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = ابحث هذه المرة بـ:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = ابحث بـ:
urlbar-searchmode-popup-search-settings2 = إعدادات البحث
urlbar-searchmode-popup-settings2 = الإعدادات
urlbar-searchmode-popup-search-settings = إعدادات البحث
    .accesskey = ع
urlbar-searchmode-popup-settings = الإعدادات
    .accesskey = د

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = ابحث في العلامات
urlbar-result-action-search-history = ابحث في التأريخ
urlbar-result-action-search-tabs = ابحث في الألسنة
urlbar-result-action-search-actions = إجراءات البحث
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = تبديل إلى { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = افتح { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = افتح في لسان جديد
    .accesskey = ف
urlbar-view-context-menu-open-in-container-tab =
    .label = افتح في لسانٍ حاوٍ جديد
    .accesskey = ف
urlbar-view-context-menu-open-in-window =
    .label = افتح في نافذة جديدة
    .accesskey = ف
urlbar-view-context-menu-open-in-private-window =
    .label = افتح في نافذة خاصة جديدة
    .accesskey = ف
urlbar-view-context-menu-open-in-tab2 = افتح في لسان جديد
    .accesskey = ف
urlbar-view-context-menu-open-in-container-tab2 = افتح في لسانٍ حاوٍ جديد
    .accesskey = ف
urlbar-view-context-menu-open-in-window2 = افتح في نافذة جديدة
    .accesskey = ف
urlbar-view-context-menu-open-in-private-window2 = افتح في نافذة خاصة جديدة
    .accesskey = ف
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = تخطَّ هذه القائمة عند استخدام مفتاح Tab
    .accesskey = ط

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = اقتراحات { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = إجراءات سريعة
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = عمليات البحث الأخيرة
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = مُتداول في { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = لا تعرض عمليات البحث المُتداولة
    .accesskey = ل
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = لا تعرض عمليات البحث المُتداولة
    .accesskey = م
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = لا تعرض عمليات البحث المُتداولة
    .accesskey = م
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = شكرًا على تعليقك. لن ترى عمليات البحث المُتداولة بعد الآن.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = ادخل منظور القارئ
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = أغلق منظور القارئ

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = فتح فديو معترِض ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = أغلِق فديو معترِض ({ $shortcut })
picture-in-picture-panel-header = فديو معترِض
picture-in-picture-panel-headline = لا يوصي موقع الويب هذا باستخدام ميزة "فديو معترِض".
picture-in-picture-panel-body = قد لا يُعرض مقاطع الفيديو بالشكل الذي أراده المطور أثناء تمكين ميزة الفديو المعترِض.
picture-in-picture-enable-toggle =
    .label = فعّل على أية حال

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> يملأ الشاشة الآن
fullscreen-warning-no-domain = يملأ هذا المستند الشاشة الآن
fullscreen-exit-button = غادر ملء الشاشة (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = غادر ملء الشاشة (esc)
fullscreen-keyboardlock-exit-button = اخرِج من وضع ملء الشاشة (اضغط مع الاستمرار على زر Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = اخرِج من وضع ملء الشاشة (اضغط مع الاستمرار على زر esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = يتحكم <span data-l10n-name="domain">{ $domain }</span> في مؤشرك. اضغط Esc لتستعيد التحكم.
pointerlock-warning-no-domain = يتحكم هذا المستند في مؤشرك. اضغط Esc لتستعيد التحكم.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = أدِر العلامات
bookmarks-recent-bookmarks-panel-subheader = أحدث العلامات
bookmarks-toolbar-chevron =
    .tooltiptext = أظهِر المزيد من العلامات
bookmarks-sidebar-content =
    .aria-label = العلامات
bookmarks-menu-button =
    .label = قائمة العلامات
bookmarks-other-bookmarks-menu =
    .label = العلامات الأخرى
bookmarks-mobile-bookmarks-menu =
    .label = علامات المحمول

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] أخفِ شريط العلامات الجانبي
           *[other] أظهِر شريط العلامات الجانبي
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] أخفِ شريط أدوات العلامات
           *[other] أظهِر شريط أدوات العلامات
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] أخفِ شريط أدوات العلامات
           *[other] أظهِر شريط أدوات العلامات
        }

##

bookmarks-search =
    .label = ابحث في العلامات
bookmarks-tools =
    .label = أدوات العلامات
bookmarks-subview-edit-bookmark =
    .label = حرّر هذه العلامة…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = العلامات
    .toolbarname = شريط العلامات
    .accesskey = ش
bookmarks-toolbar-menu =
    .label = شريط العلامات
bookmarks-toolbar-placeholder =
    .title = عناصر شريط العلامات
bookmarks-toolbar-placeholder-button =
    .label = عناصر شريط العلامات
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = علّم اللسان الحالي…

## Library Panel items

library-bookmarks-menu =
    .label = العلامات

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = أصلِح ترميز النص
    .tooltiptext = خمّن ترميز النص الصحيح من محتوى الصفحة

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = الإعدادات
    .tooltiptext =
        { PLATFORM() ->
            [macos] افتح الإعدادات ({ $shortcut })
           *[other] الإعدادات
        }
toolbar-overflow-customize-button =
    .label = خصّص شريط الأدوات…
    .accesskey = ش
toolbar-button-email-link =
    .label = أرسل الرابط بالبريد
    .tooltiptext = أرسل رابط لهذه الصفحة بالبريد
toolbar-button-logins =
    .label = كلمات السر
    .tooltiptext = اعرض و أدِر كلماتي السرية المحفوظة
qrcode-panel-error =
    .message = فشل توليد رمز QR. يُرجى المحاولة مجددًا.
qrcode-copy-button =
    .label = انسخ
qrcode-copy-success =
    .message = نُسخ رمز QR إلى الحافظة.
qrcode-copy-error =
    .message = فشل نسخ رمز QR.
qrcode-save-button =
    .label = احفظ
qrcode-window-title = رمز QR
qrcode-dialog-title = رمز QR
qrcode-image =
    .aria-label = رمز QR
qrcode-close-button =
    .aria-label = أغلق
toolbar-button-save-page =
    .label = احفظ الصفحة
    .tooltiptext = احفظ هذه الصفحة ({ $shortcut })
toolbar-button-open-file =
    .label = افتح ملفًا
    .tooltiptext = افتح ملفًا ({ $shortcut })
toolbar-button-synced-tabs =
    .label = الألسنة المُزامنة
    .tooltiptext = اعرض الألسنة من الأجهزة الأخرى
toolbar-button-send-tab =
    .label = أرسل لسان
    .tooltiptext = أرسل اللسان الحالي إلى جهاز أخر
toolbar-button-new-private-window =
    .label = نافذة خاصة جديدة
    .tooltiptext = افتح نافذة تصفح خاصة جديدة ({ $shortcut })
toolbar-button-share-tab =
    .label = شارِك
    .tooltiptext = شارك هذه الصفحة
toolbar-button-tab-groups =
    .label = مجموعات الألسنة
    .tooltiptext = أظهر مجموعات ألسنتك
toolbar-button-history =
    .label = التأريخ
    .tooltiptext = أظهر التأريخ ({ $shortcut })
toolbar-button-find =
    .label = ابحث
    .tooltiptext = ابحث في هذه الصفحة ({ $shortcut })
toolbar-button-developer =
    .label = المطوّرين
    .tooltiptext = أدوات مطوري الوب ({ $shortcut })
toolbar-button-forget =
    .label = انسَ
    .tooltiptext = انسَ بعضًا من تأريخ التصفح
toolbar-zoom-controls =
    .label = عناصر التقريب
    .title = عناصر التقريب
toolbar-button-zoom-out =
    .label = بعّد
    .tooltiptext = بعّد ({ $shortcut })
toolbar-button-zoom-reset-tooltip = صفّر مستوى التقريب ({ $shortcut })
toolbar-button-zoom-in =
    .label = قرّب
    .tooltiptext = قرّب ({ $shortcut })
toolbar-edit-controls =
    .label = عناصر التحرير
    .title = عناصر التحرير
toolbar-button-cut =
    .label = قصّ
    .tooltiptext = قص ({ $shortcut })
toolbar-button-copy =
    .label = انسخ
    .tooltiptext = انسخ ({ $shortcut })
toolbar-button-paste =
    .label = ألصق
    .tooltiptext = ألصق ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = تستخدم بعض الملفات الصوتية أو الفيديو على هذا الموقع برمجيات لإدارة الحقوق الرقمية، والتي قد تحد ما يستطيع { -brand-short-name } أن يسمح لك بفعله مع هذه الملفات.
eme-notifications-drm-content-playing-manage = أدِر الإعدادات
eme-notifications-drm-content-playing-manage-accesskey = د
eme-notifications-drm-content-playing-dismiss = أهمِل
eme-notifications-drm-content-playing-dismiss-accesskey = ه

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = يجب تفعيل إدارة الحقوق الرقمية لتشغيل بعض ملفات الصوت أو الفيديو على هذه الصفحة.
eme-notifications-drm-content-disabled-button =
    .label = فعّل إدارة الحقوق الرقمية
    .accesskey = ف
eme-notifications-drm-content-cdm-installing-message = يُنصّب { -brand-short-name } المكونات اللازمة لتشغيل ملفات الصوت أو الفيديو على هذه الصفحة. يرجى إعادة المحاولة لاحقًا.
decoder-doctor-no-codecs-linux-message = لتشغيل الڤديو قد تحتاج لتثبيت مرمزات الڤديو المطلوبة.
decoder-doctor-no-hw-acceleration-message = لتحسين جودة الڤديو قد تحتاج لتثبيت حزمة ميكروسوفت للوسائط.
decoder-doctor-no-pulse-audio-message = لتشغيل الصوت قد تحتاج لتثبيت PulseAudio.
decoder-doctor-unsupported-libavcodec-message = برمجية libavcodec قد تكون ضعيفة أمنيًا أو غير مدعومة، و يجب تحديثها لتشغيل الڤديو.
decoder-doctor-decode-error-message = حدث خطأ أثناء فك ترميز مورِد الوسائط.
decoder-doctor-decode-warning-message = حدث خطأ غير خطير أثناء فك ترميز مورِد الوسائط.
decoder-doctor-learn-how-link = اطّلع على المزيد
decoder-doctor-report-issue-button =
    .label = أبلغ عن مشكلة بالموقع
    .accesskey = س
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = انهارت الملحقة { $pluginName }.
plugin-crashed-notification-reload-button =
    .label = أعد تحميل الصفحة
    .accesskey = ع
plugin-crashed-notification-submit-button =
    .label = بلّغ عن الانهيار
    .accesskey = ن

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = موقع مخادع!
safebrowsing-reported-attack-site-message = موقع هجمات مُبلغ عنه!
safebrowsing-reported-unwanted-site-message = موقع غير مرغوب فيه مبلّغ عنه!
safebrowsing-reported-harmful-site-message = موقع ضار مُبلّغ عنه!
safebrowsing-get-me-out-of-here-button =
    .label = أخرجني من هنا!
    .accesskey = ه
safebrowsing-not-a-deceptive-site-button =
    .label = هذا ليس موقعًا مخادعًا…
    .accesskey = م
safebrowsing-not-an-attack-site-button =
    .label = هذا ليس موقع هجمات…
    .accesskey = م

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = تحتاج الولوج إلى هذه الشبكة أولا لتستطيع الوصول إلى الإنترنت.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = افتح صفحة الولوج إلى الشبكة

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = هل كنت تريد الذهاب إلى { $hostName }؟
keyword-uri-fixup-go-to-button =
    .label = نعم، خذني إلى { $hostName }
    .accesskey = ن

## Password save/update panel

panel-save-update-username-2 =
    .label = اسم المستخدم
panel-save-update-password-2 =
    .label = كلمة السر

##

# "More" item in macOS share menu
menu-share-more =
    .label = أكثر…
menu-share-windows =
    .label = المزيد من الخيارات
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label =
        { $count ->
            [zero] لا رابط للنسخ
            [one] انسخ رابط
            [two] انسخ رابطين
            [few] انسخ { $count } روابط
            [many] انسخ { $count } رابطًا
           *[other] انسخ { $count } رابط
        }
    .accesskey = ن
ui-tour-info-panel-close =
    .tooltiptext = أغلق

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = اسمح بالنوافذ المنبثقة وإعادة التوجيه إلى جهات خارجية لـ { $uriHost }
    .accesskey = م

##

picture-in-picture-hide-toggle =
    .label = أخفِ زر تفعيل/تعطيل الفديوهات المعترِضة
    .accesskey = خ

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = انقل زر تبديل وضع ”الفديوهات المعترِضة“ إلى اليمين
    .accesskey = ن
picture-in-picture-move-toggle-left =
    .label = انقل زر تبديل وضع ”الفديوهات المعترِضة“ إلى اليسار
    .accesskey = س

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = التنقل
navbar-downloads =
    .label = التنزيلات
navbar-overflow-2 =
    .tooltiptext = المزيد من الأدوات
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = اطبع
    .tooltiptext = اطبع هذه الصّفحة… ({ $shortcut })
navbar-home =
    .label = البداية
    .tooltiptext = صفحة بداية { -brand-short-name }
navbar-library =
    .label = المكتبة
    .tooltiptext = اعرض التأريخ، والعلامات المحفوظة وغيرها
navbar-search =
    .title = ابحث
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = ألسنة المتصفح
tabs-toolbar-new-tab =
    .label = لسان جديد
tabs-toolbar-list-all-tabs-2 =
    .label = ابحث وأدِر الألسنة
    .tooltiptext = ابحث وأدِر الألسنة
tabs-toolbar-list-all-tabs =
    .label = اسرد كل الألسنة
    .tooltiptext = اسرد كل الألسنة

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = أسقِط اللسان هنا لتثبيته

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>أتريد فتح الألسنة الأخيرة؟</strong> يمكنك استعادة الجلسة السابقة من قائمة تطبيق { -brand-short-name } <img data-l10n-name="icon"/>، ضمن قائمة التأريخ.
restore-session-startup-suggestion-button = ما الطريقة؟

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = حجبت منظّمتك الوصول إلى الملفات المحلية الموجودة على هذا الحاسوب

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } يبحث الآن في ألسنتك
urlbar-addons-shortcut-moved-description = لفتح الإضافات والسمات، استخدم { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = إدارة الاختصارات
urlbar-addons-shortcut-moved-dismiss = فهمت

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = يُرسل { -brand-short-name } بعض البيانات تلقائيا إلى { -vendor-short-name } لمساعدتنا في تحسين متصفّحك.
data-reporting-notification-button =
    .label = اختر ما الذي أشاركه
    .accesskey = خ
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = التصفح الخاص
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = التصفح الخاص
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = معلومات التصفح الخاص
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = أنت في نافذة خاصة
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = يساعد هذا في إخفاء تصفحك عن الآخرين على هذا الجهاز، ولكنه لا يجعلك غير مرئي على الإنترنت. <a data-l10n-name="learn-more">مَن قد يتمكن من رؤية نشاطي؟</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = منع فقدان البيانات (DLP) بواسطة { $agentName }. انقر للحصول على مزيد من المعلومات.
content-analysis-panel-title2 = منع فقدان البيانات
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = تستخدم مؤسستك <b>{ $agentName }</b> للتحكم في طرق مشاركة البيانات الحسّاسة. <a data-l10n-name="info">اطّلع على المزيد</a>
content-analysis-panel-title = حماية البيانات
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = تستخدم منظّمتك <b>{ $agentName }</b> لحماية من فقدان البيانات. <a data-l10n-name="info"> اطّلع على المزيد</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = الامتدادات
    .tooltiptext = الامتدادات

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = الامتدادات
    .tooltiptext =
        الامتدادات
        الأذونات لازمة

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = الامتدادات
    .tooltiptext =
        الامتدادات
        بعض الامتدادات غير مسموح بها

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = الامتدادات
    .tooltiptext =
        الامتدادات
        بعض الامتدادات مُعطَّلة

## Private browsing reset button

reset-pbm-panel-heading2 = امحُ البيانات وبدء جلسة خاصة جديدة؟
reset-pbm-panel-description2 = يؤدي هذا إلى حذف التأريخ وملفات تعريف الارتباط وجميع بيانات الموقع الأخرى دون إغلاق نافذتك الخاصة.
reset-pbm-panel-always-ask-checkbox =
    .label = اسألني دائمًا
    .accesskey = م
reset-pbm-panel-cancel-button =
    .label = ألغِ
    .accesskey = غ
reset-pbm-panel-confirm-button2 =
    .label = امحُ الجلسة الخاصة
    .accesskey = م
reset-pbm-panel-complete = حُذفت بيانات الجلسة الخاصة
reset-pbm-toolbar-button2 =
    .label = امحُ الجلسة الخاصة
    .tooltiptext = امحُ الجلسة الخاصة

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = حذف جميع بيانات التصفح؟
fire-button-panel-description = سيؤدي هذا إلى حذف سجل التصفح وملفات تعريف الارتباط وبيانات الموقع. سيتم تسجيل خروجك من المواقع. ستُغلق هذه النافذة، وسيتم فتح نافذة جديدة باستخدام { -brand-short-name }.
fire-button-panel-choose-description = إذا كنت لا ترغب في حذف كل شيء، فاختر بيانات محددة بدلاً من ذلك.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = اختر…
fire-button-panel-cancel-button =
    .label = ألغِ
    .accesskey = غ
fire-button-panel-confirm-button =
    .label = احذف الكل
    .accesskey = ك
fire-button-panel-complete = حُذفت بيانات التصفح

## Autorefresh blocker

refresh-blocked-refresh-label = منع { -brand-short-name } هذه الصفحة من إعادة التحميل تلقائيًا.
refresh-blocked-redirect-label = منع { -brand-short-name } هذه الصفحة من إعادة التوجيه تلقائيًا إلى صفحة أخرى.
refresh-blocked-allow =
    .label = اسمح
    .accesskey = س

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = تحمي أقنعتنا الآمنة وسهلة الاستخدام هويتك وتمنع السبام عن طريق إخفاء عنوان بريدك الإلكتروني.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = ستمرر كل رسائل البريد الإلكتروني المرسلة إلى أقنعة بريدك إلى <strong>{ $useremail }</strong> (ما لم تقرر حجبها).
firefox-relay-offer-legal-notice = بالنقر على"أستخدم قناع البريد"، أنت توافق على شروط <label data-l10n-name="tos-url"> للخدمة </label> و <label data-l10n-name="privacy-url">تنويه الخصوصية </label>.
firefox-relay-offer-legal-notice-1 = من خلال التسجيل وإنشاء قناع بريد إلكتروني، فإنك توافق على <label data-l10n-name="tos-url">شروط الخدمة</label> و <label data-l10n-name="privacy-url">تنويه الخصوصية</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (لم يُتحقق منها)
popup-notification-xpinstall-prompt-learn-more = اطّلع على المزيد حول طريقة تثبيت الإضافات بأمان تام
popup-notification-xpinstall-prompt-block-url = اعرض التفاصيل
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = اسمح لامتداد بأن يعمل في النوافذ الخاصة
    .accesskey = م
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = شارك البيانات التقنية والتفاعلية مع مطوِّر الامتدادة
    .accesskey = ر

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message =
    { $popupCount ->
        [one] منع { -brand-short-name } هذا الموقع من فتح نافذة منبثقة.
        [two] منع { -brand-short-name } هذا الموقع من فتح نافذتين منبثقتين.
        [few] منع { -brand-short-name } هذا الموقع من فتح { $popupCount } نوافذ منبثقة.
        [many] منع { -brand-short-name } هذا الموقع من فتح { $popupCount } نافذة منبثقة.
       *[other] منع { -brand-short-name } هذا الموقع من فتح { $popupCount } نافذة منبثقة.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message =
    { $popupCount ->
        [two] منع { -brand-short-name } هذا الموقع من فتح ما يزيد عن نافذتين منبثقتين.
        [few] منع { -brand-short-name } هذا الموقع من فتح ما يزيد عن { $popupCount } نوافذ منبثقة.
        [many] منع { -brand-short-name } هذا الموقع من فتح ما يزيد عن { $popupCount } نافذة منبثقة.
       *[other] منع { -brand-short-name } هذا الموقع من فتح ما يزيد عن { $popupCount } نافذة منبثقة.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] الخيارات
           *[other] التفضيلات
        }
    .accesskey =
        { PLATFORM() ->
            [windows] خ
           *[other] ت
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = أظهر ”{ $popupURI }“
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = أظهر "{ $redirectURI }"

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = لم يتمكن من فتح مربع حوار الملفات في ويندوز. لم يتمكن من تحديد أي ملف أو مجلد.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = لم يتمكن من فتح مربع حوار ملف ويندوز. سيتم حفظ الملف في { $path }.
file-picker-failed-save-nowhere = لم يتمكن من فتح مربع حوار ملف ويندوز. لم يُعثر على المجلد المبدئي؛ ولن يُحفظ الملف.
file-picker-crashed-open = انهار مربع حوار ملف ويندوز. لم يتم تحديد أي ملف أو مجلد.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = انهار مربع حوار ملف ويندوز. سيتم حفظ الملف في { $path }.
file-picker-crashed-save-nowhere = انهار مربع حوار ملف ويندوز. لم يتم العثور على المجلد المبدئي؛ ولن يُحفظ الملف.
file-picker-crashed-show-in-folder =
    .label = اعرض في المجلد
    .accessKey = م

## Unsigned add-ons notification

unsigned-addons-disabled-message = تعذّر التحقق من أحد الإضافات المثبتة لذا عُطّلت.
unsigned-addons-disabled-learn-more =
    .label = اطّلع على المزيد
    .accesskey = ط

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = تتسبّب هذه الصفحة بإبطاء عمل { -brand-short-name }. أوقِفها لتسريع المتصفّح.
process-hang-nonspecific-tab-message = تتسبّب إحدى الصفحات بإبطاء عمل { -brand-short-name }. أوقِفها لتسريع المتصفّح.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = يتسبّب اللسان ”{ $title }“ بإبطاء عمل { -brand-short-name }. أوقِفه لتسريع المتصفّح.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = يتسبّب الامتداد ”{ $addonName }“ بإبطاء عمل { -brand-short-name }. أوقِفه لتسريع المتصفّح.
process-hang-addon-learn-more =
    .value = اطّلع على المزيد
process-hang-stop-button =
    .label = أوقِف
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = أنهِ الإعداد
onboarding-aw-finish-setup-button =
    .label = أنهِ الإعداد
    .tooltiptext = أنهِ إعداد { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = الحماية الموسّعة من التعقب مفعّلة
trustpanel-etp-label-disabled = الحماية الموسّعة من التعقب معطّلة
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = الحماية الموسّعة من التعقب مفعّلة ل { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = الحماية الموسّعة من التعقب معطّلة ل { $host }
trustpanel-etp-description-enabled = إذا كان هناك شيء يبدو معطوبًا في هذا الموقع، فحاول إيقاف تشغيل الحماية.
trustpanel-etp-description-disabled = ترى { -brand-product-name } أن على الشركات تقليل تتبعها لك. نقوم بحظر أكبر عدد ممكن من المتعقّبات عند تفعيلك لخيارات الحماية.
trustpanel-connection-label-secure = الاتصال آمن
trustpanel-connection-label-insecure = الاتصال غير آمن
trustpanel-header-enabled = { -brand-product-name } على الحراسة
trustpanel-description-enabled2 = أنت محمي. إذا لاحظنا أي شيء، سنُعلمك.
trustpanel-header-enabled-insecure = كن حذرًا على هذا الموقع
trustpanel-description-enabled-insecure = { -brand-product-name } لاحظ شيئًا مريبًا.
trustpanel-header-disabled = لقد أوقفت الحماية
trustpanel-description-disabled = { -brand-product-name } خارج الخدمة. نقترح إعادة تفعيل الحماية.
trustpanel-clear-cookies-button = امسح الكعكات و بيانات المواقع
trustpanel-privacy-link = إعدادات الخصوصية
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = امحُ ملفات تعريف الارتباط وبيانات الموقع لـ { $host }
trustpanel-clear-cookies-description = قد يؤدي إزالة ملفات تعريف الارتباط وبيانات المواقع إلى تسجيل خروجك من مواقع الوِب ومحُ عربات التسوق.
trustpanel-clear-cookies-subview-button-clear = امسح
trustpanel-clear-cookies-subview-button-cancel = ألغِ
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = حماية الاتصال لـ { $host }
trustpanel-siteinformation-morelink = مزيد من المعلومات حول الموقع
trustpanel-blocker-see-all = اعرض الكل
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = حماية التتبع لـ { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = غير آمن

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } يرى أن على الشركات تقليل متابعتك. لذلك نحظر أكبر عدد ممكن منها.
trustpanel-blocked-header = قام { -brand-product-name } بحظر هذه الأشياء من أجلك:
trustpanel-tracking-header = سمح { -brand-product-name } بهذه الأشياء حتى لا تتعطل المواقع:
trustpanel-tracking-description = دون المتعقّبات، قد لا تعمل بعض الأزرار والنماذج وحقول الولوج.
trustpanel-insecure-section-header = اتّصالك غير آمن
trustpanel-insecure-description = البيانات التي ترسلها إلى هذا الموقع غير مُعمّاة، مما قد يعرضها للعرض أو السرقة أو التعديل.
trustpanel-list-label-tracking-content = المحتوى الذي يتعقّبك
trustpanel-list-label-social-tracking =
    { $count ->
        [zero] { $count } متعقّب وسائل التواصل الاجتماعي
        [one] { $count } متعقّب وسائل التواصل الاجتماعي
        [two] { $count } متعقّبي وسائل التواصل الاجتماعي
        [few] { $count } متعقبات وسائل التواصل الاجتماعي
        [many] { $count } متعقبًا وسائل التواصل الاجتماعي
       *[other] { $count } متتبع وسائل التواصل الاجتماعي
    }
trustpanel-social-tracking-blocking-tab-header =
    { $count ->
        [zero] { -brand-product-name } حظر { $count } متعقِّب وسائط
        [one] { -brand-product-name } حظر { $count } متعقِّب وسائط
        [two] { -brand-product-name } حظر { $count } متعقِّب وسائط
        [few] { -brand-product-name } حظر { $count } متعقِّب وسائط
        [many] { -brand-product-name } حظر { $count } متعقِّب وسائط
       *[other] { -brand-product-name } حظر { $count } متعقِّب وسائط
    }
trustpanel-social-tracking-not-blocking-tab-header =
    { $count ->
        [zero] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
        [one] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
        [two] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
        [few] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
        [many] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
       *[other] { -brand-product-name } سمح ب{ $count } متعقِّب وسائط
    }
trustpanel-tracking-content-not-blocking-tab-header =
    { $count ->
        [zero] { -brand-product-name } سمح { $count } متعقِّب
        [one] { -brand-product-name } سمح { $count } متعقِّب
        [two] { -brand-product-name } سمح { $count } متعقِّب
        [few] { -brand-product-name } سمح { $count } متعقِّب
        [many] { -brand-product-name } سمح { $count } متعقِّب
       *[other] { -brand-product-name } سمح { $count } متعقِّب
    }
trustpanel-tracking-content-tab-list-header = تحاول هذه المواقع تتبعك:
trustpanel-fingerprinter-list-header = تحاول هذه المواقع تبصيمك:
trustpanel-cryptominer-blocking-tab-header =
    { $count ->
        [zero] { -brand-product-name } حظر { $count } مُعدِّن عملة رقمية
        [one] { -brand-product-name } حظر { $count } مُعدِّن عملة رقمية
        [two] { -brand-product-name } حظر { $count } مُعدِّن عملة رقمية
        [few] { -brand-product-name } حظر { $count } مُعدِّن عملة رقمية
        [many] { -brand-product-name } منع { $count } مُعدِّن عملة رقمية
       *[other] { -brand-product-name } حظر { $count } مُعدِّن عملة رقمية
    }
trustpanel-cryptominer-not-blocking-tab-header =
    { $count ->
        [zero] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
        [one] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
        [two] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
        [few] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
        [many] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
       *[other] { -brand-product-name } سمح ب{ $count } مُعدِّن عملة رقمية
    }
trustpanel-cryptominer-tab-list-header = تحاول هذه المواقع تعدين العُملات الرقمية:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = ألديك حساب على هذا الموقع؟
trustpanel-breachalerts-anonymous-breached-description = لقد وجد { -brand-product-name } أن هذا الموقع تعرض لاختراق بيانات خلال الـ 12 شهرًا الماضية. اكتشف ما إذا كنت قد تأثرت بذلك.
trustpanel-breachalerts-anonymous-breached-button-dismiss = أهمِل
trustpanel-breachalerts-anonymous-breached-button-check-monitor = ابدأ الفحص المجاني
trustpanel-blocker-section-header2 =
    { $count ->
        [zero] حُظر <span data-l10n-name="count">{ $count }</span> متعقِّبات على هذا الموقع
        [one] حُظر <span data-l10n-name="count">{ $count }</span> متعقِّب على هذا الموقع
        [two] حُظر <span data-l10n-name="count">{ $count }</span> متعقّبان على هذا الموقع
        [few] حُظر <span data-l10n-name="count">{ $count }</span> متعقِّبات على هذا الموقع
        [many] حُظر <span data-l10n-name="count">{ $count }</span> متعقِّبات على هذا الموقع
       *[other] حُظر <span data-l10n-name="count">{ $count }</span> متعقِّبات على هذا الموقع
    }

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>يبدو الموقع معطوبًا؟</strong> أعِد تحميل الصفحة لتقليل مستوى حماية التتبع مؤقتًا.
reduced-protection-infobar-reload-button = أعد التحميل
    .accesskey = ع
reduced-protection-infobar-never-show-button = لا تُظهر مجددًا
    .accesskey = ظ


identity-allow-site-data = vOrbit-lite: قم دائمًا بحفظ ملفات تعريف الارتباط/البيانات لهذا الموقع
