# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = أخبر مواقع الويب بعدم بيع بياناتي أو مشاركتها
    .accesskey = ش
non-technical-privacy-group =
    .label = تفضيلات خصوصية الموقع
do-not-track-removal3 =
    .message = لم نعد ندعم ميزة "لا تتعقبني".
non-technical-privacy-heading =
    .label = حمايات إضافية
preferences-privacy-relay-available =
    .description = يخفي عنوان بريدك الإلكتروني الحقيقي لحماية صندوق الوارد الخاص بك من الرسائل المزعجة.
    .label = اقتراح أقنعة البريد الإلكتروني { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = التحكم العالمي في الخصوصية (GPC)
settings-page-title = الإعدادات
category-nav-heading =
    .heading = الإعدادات
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = ابحث في الإعدادات
    .style = width: 15.4em
managed-notice = متصفحك يُدار من قِبل منظّمتك.
managed-notice-info-icon =
    .alt = معلومة
managed-notice-nav =
    .label = تُدير منظّمتك المتصفح الذي تستخدم الآن.
tls-key-logging-notice-nav =
    .label = قد يتمكن تطبيق أو خدمة ما من رؤية حركة بياناتك المُعمّاة.
category-list =
    .aria-label = الفئات
pane-general-title = عام
pane-home-title = المنزل
pane-home-startup-title2 = الصفحة الرئيسية والبدء
    .title = الصفحة الرئيسية والبدء
pane-search-title2 = البحث
    .title = البحث
pane-privacy-title3 = الخصوصية و الأمان
    .title = الخصوصية و الأمان
pane-privacy-section =
    .heading = الخصوصية و الأمان
pane-sync-title3 = المزامنة
pane-ai-controls-title2 = أنظمة التحكم بالذكاء الاصطناعي
    .title = أنظمة التحكم بالذكاء الاصطناعي
pane-about-firefox-title = عن { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = المظهر
    .title = { pane-appearance-title }
pane-downloads-title2 = التنزيلات
    .title = التنزيلات
pane-downloads3 =
    .heading = التنزيلات
pane-accessibility-title = الإتاحة
    .title = { pane-accessibility-title }
pane-languages-title2 = اللغات
    .title = اللغات
preferences-languages-header3 =
    .heading = اللغات
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = جرّب ميزاتنا التجريبية! إنها قيد التطوير والتحديث، مما قد يؤثر على طريقة عمل { -brand-short-name } . لا نتلقى بيانات حول استخدامك لهذه الميزات إلا إذا كنت قد فعّلت <a data-l10n-name="data-collection">البيانات التقنية والتفاعلية</a>.
pane-experimental-reset =
    .label = استعد المبدئيات
    .accesskey = س
help-button-label2 = دعم { -brand-short-name }
    .title = دعم { -brand-short-name }
addons-button-label2 = الامتدادات والسمات
    .title = الامتدادات والسمات
focus-search =
    .key = f
close-button =
    .aria-label = أغلق
do-not-track-removal2 =
    .label = لم نعد ندعم إشارة "لا تتعقبني"
applications-setting-new-file-types =
    .label = ما الذي يجب أن يفعله { -brand-short-name } مع الملفات الأخرى؟

## Browser Restart Dialog

feature-enable-requires-restart = يجب إعادة تشغيل { -brand-short-name } لتفعيل هذه الخاصية.
feature-disable-requires-restart = يجب إعادة تشغيل { -brand-short-name } لتعطيل هذه الخاصية.
should-restart-title = أعِد تشغيل { -brand-short-name }
should-restart-ok = أعد تشغيل { -brand-short-name } الآن
cancel-no-restart-button = ألغِ
restart-later = أعِد التشغيل لاحقًا

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = يتحكم <img data-l10n-name="icon"/><strong>{ $name }</strong> في هذا الإعداد.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = يتحكم <img data-l10n-name="icon"/><strong>{ $name }</strong> في هذا الإعداد.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = يتطلب <img data-l10n-name="icon"/><strong>{ $name }</strong> ألسنة الحاوية.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = يتحكم <img data-l10n-name="icon"/><strong>{ $name }</strong> في هذا الإعداد.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = يتحكم <img data-l10n-name ="icon"/> <strong>{ $name }</strong> في كيفية اتصال { -brand-short-name } بالإنترنت.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = لتفعيل الامتداد انتقل إلى <img data-l10n-name="addons-icon"/> الإضافات في <img data-l10n-name="menu-icon"/> القائمة.
extension-controlled-enable-2 = لإعادة تفعيل هذه الامتدادة، تفضل بزيارة <a data-l10n-name="addons-link">الامتدادات والسمات</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = يتحكم { $name } في بعض إعدادات صفحتك الرئيسية.

## Preferences UI Search Results

search-results-header = نتائج البحث
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = للأسف لا نتائج في الإعدادات عن ”<span data-l10n-name="query"></span>“.
search-results-help-link = أتحتاج للمساعدة؟ زُر <a data-l10n-name="url">دعم { -brand-short-name }</a>

## General Section

always-check-default =
    .label = تحقق دائمًا من كون { -brand-short-name } متصفّحك المبدئي
    .accesskey = د
startup-restore-windows-and-tabs =
    .label = افتح النوافذ والألسنة السابقة
    .accesskey = ن
windows-launch-on-login =
    .label = افتح { -brand-short-name } تلقائيًا عند بدء تشغيل حاسوبك
    .accesskey = ع
windows-launch-on-login-disabled = عُطّل هذا الخيار في نظام التشغيل ويندوز. لتغييره، انتقل إلى <a data-l10n-name="startup-link">تطبيقات بدء التشغيل</a> في إعدادات النظام.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = افتح أيضًا لسان جديد
    .accesskey = ف
disable-extension =
    .label = عطّل الامتداد
preferences-data-migration-group =
    .description = استورد العلامات وكلمات السر والسجل والامتدادات وبيانات التعبئة التلقائية من متصفح آخر.
    .label = استورِد بيانات المتصفح
preferences-data-migration-button =
    .label = استورد البيانات
    .accesskey = د
preferences-profiles-group-header =
    .heading = ملفات الإعدادات
preferences-profiles-subpane-description =
    .description = يحتوي كل ملف شخصي على بيانات وإعدادات تصفح منفصلة، بما في ذلك السجل وكلمات السر والمزيد.
preferences-profiles-section-header =
    .description = لكل ملف شخصي بيانات تصفح وإعدادات منفصلة، بما في ذلك التأريخ وكلمات السر وغيرها.
    .label = ملفات شخصية
preferences-manage-profiles-button =
    .label = أدِر ملفات الإعدادات
preferences-profiles-settings-button =
    .label = الإعدادات
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = سيقوم الملف الشخصي الجديد بنسخ إعداداتك وإضافاتك وتأريخك وبياناتك المحفوظة مثل العلامات وكلمات السر - ولكن ليس حسابك أو معلومات المزامنة.
    .label = انسخ ملف شخصي موجود بالفعل
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = الملف الشخصي المراد نسخه
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = اختر الملف الشخصيّ
preferences-copy-profile-button = انسخ
tabs-browsing-section =
    .heading = الألسنة والتصفح
pane-tabs-browsing-title2 = الألسنة والتصفح
    .title = الألسنة والتصفح
tabs-group-header2 =
    .label = الألسنة
tabs-opening-heading =
    .label = فتح
tabs-interaction-heading =
    .label = تفاعل
tabs-containers-heading =
    .label = الحاويات
tabs-closing-heading =
    .label = إغلاق
ctrl-tab-recently-used-order =
    .label = ‏Ctrl+Tab يتنقّل عبر الألسنة حسب ترتيب آخر استخدام
    .accesskey = T
open-new-link-as-tabs =
    .label = افتح الروابط في ألسنة بدل فتح نوافذ جديدة
    .accesskey = ن
open-external-link-next-to-active-tab =
    .label = افتح الروابط من التطبيقات الموجودة بجوار اللسان النشط
ask-on-close-multiple-tabs =
    .label = اسأل قبل محاولة إغلاق عدّة ألسنة
    .accesskey = د
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = اسأل قبل المغادرة باستعمال { $quitKey }
    .accesskey = ت
warn-on-open-many-tabs =
    .label = نبّهني عند فتح عدة ألسنة أن هذا قد يبطئ { -brand-short-name }
    .accesskey = ف
switch-to-new-tabs-2 =
    .label = عند فتح الروابط أو الوسائط في ألسنة جديدة، انتقل إليها فورًا.
    .accesskey = ف
show-tabs-in-taskbar =
    .label = أظهِر معاينات للألسنة في شريط مهام ويندوز
    .accesskey = و
browser-containers-enabled-2 =
    .label = استخدم الألسنة الحاوية
    .accesskey = د
browser-containers-learn-more = اطّلع على المزيد
browser-containers-settings-2 =
    .label = أدر الإعدادات
    .accesskey = د
containers-disable-alert-title = أأغلق كل الألسنة الحاوية؟
startup-group =
    .label = البدء

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] إذا عطلت الألسنة الحاوية الآن فسيغلق لسان حاو. أمتأكد أنك تريد تعطيل الألسنة الحاوية؟
        [two] إذا عطلت الألسنة الحاوية الآن فسيغلق لسانين حاويين. أمتأكد أنك تريد تعطيل الألسنة الحاوية؟
        [few] إذا عطلت الألسنة الحاوية الآن فستغلق { $tabCount } ألسنة حاوية. أمتأكد أنك تريد تعطيل الألسنة الحاوية؟
        [many] إذا عطلت الألسنة الحاوية الآن فسيغلق { $tabCount } لسانًا حاويًا. أمتأكد أنك تريد تعطيل الألسنة الحاوية؟
       *[other] إذا عطلت الألسنة الحاوية الآن فسيغلق { $tabCount } لسان حاو. أمتأكد أنك تريد تعطيل الألسنة الحاوية؟
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] أغلق اللسان الحاوي
        [two] أغلق اللسانين الحاويين
        [few] أغلق { $tabCount } ألسنة حاوية
        [many] أغلق { $tabCount } لسانًا حاويًا
       *[other] أغلق { $tabCount } لسان حاو
    }

##

containers-disable-alert-cancel-button = أبقها مفعلّة
containers-remove-alert-title = أتريد إزالة هذه الحاوية؟
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] إذا أزلت هذه الحاوية الآن فسيغلق لسان حاو. أمتأكد أنك تريد إزالة هذه الحاوية؟
        [two] إذا أزلت هذه الحاوية الآن فسيغلق لسانين حاويين. أمتأكد أنك تريد إزالة هذه الحاوية؟
        [few] إذا أزلت هذه الحاوية الآن فستغلق { $count } ألسنة حاوية. أمتأكد أنك تريد إزالة هذه الحاوية؟
        [many] إذا أزلت هذه الحاوية الآن فسيغلق { $count } لسانًا حاويًا. أمتأكد أنك تريد إزالة هذه الحاوية؟
       *[other] إذا أزلت هذه الحاوية الآن فسيغلق { $count } لسان حاو. أمتأكد أنك تريد إزالة هذه الحاوية؟
    }
containers-remove-ok-button = أزل الحاوية
containers-remove-cancel-button = لا تزِل هذه الحاوية
settings-tabs-show-image-in-preview =
    .label = أظهِر معاينة الصورة عند التحويم فوق اللسان
    .accessKey = ع
settings-tabs-drag-to-create-tab-groups =
    .label = اسحب الألسنة معًا لإنشاء مجموعات الألسنة
browser-layout-header2 =
    .label = تخطيط المتصفح
browser-layout-horizontal-tabs2 =
    .description = ألسنة في الأعلى
    .label = ألسنة أفقية
    .title = ألسنة في الأعلى
browser-layout-vertical-tabs2 =
    .description = ألسنة جانبية، في الشريط الجانبي
    .label = ألسنة رأسية
    .title = ألسنة جانبية، في الشريط الجانبي
browser-layout-show-sidebar2 =
    .description = الوصول بسرعة إلى العلامات، والألسنة من هاتفك، ودردشة الذكاء الاصطناعي، والمزيد دون مغادرة واجهتك الرئيسية.
    .label = أظهِر الشريط الجانبي
page-navigation-group =
    .label = التنقل بين الصفحات

## General Section - Language & Appearance

language-and-appearance-header = اللغة و المظهر
appearance-group2 =
    .description = تغيّر بعض المواقع الإلكترونية ألوانها لتناسب تفضيلاتك. اختر مخطّط ألوانك.
    .label = مظهر الموقع
preferences-web-appearance-choice-auto3 =
    .label = النظام
    .title = تغيير خلفيات ومحتوى المواقع الإلكترونية تلقائيًا بناءً على إعدادات نظامك وسمة { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = فاتح
    .title = استخدم مظهرًا فاتحً لخلفيات موقع الويب ومحتواه.
preferences-web-appearance-choice-dark2 =
    .label = داكن
    .title = استخدم مظهرًا داكنًا لخلفيات موقع الويب ومحتواه.
web-appearance-group =
    .aria-label = مظهر الموقع
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = إعدادات التحكم في التباين لديك تتغلب على مظهر موقع الوِب.
preferences-web-appearance-link =
    .label = أدِر سمات { -brand-short-name } في الامتدادات والسمات
preferences-contrast-control-group =
    .description = تستخدم المواقع الإلكترونية مجموعة متنوعة من ألوان الخلفية والنصوص. لضمان تباين ثابت، يمكنك استخدام نفس الألوان عبر جميع المواقع.
    .label = تباين الموقع
preferences-contrast-control-radio-group =
    .label = تجاوز الألوان
preferences-contrast-control-use-platform-settings =
    .label = تلقائي (استخدام إعدادات النظام)
    .accesskey = ع
preferences-contrast-control-off =
    .label = معطّل
    .accesskey = ط
preferences-contrast-control-custom =
    .label = مخصّص
    .accesskey = ص
preferences-colors-manage-button2 =
    .label = أدِر الألوان
    .accesskey = ر
preferences-colors-manage-button =
    .label = أدِر الألوان…
    .accesskey = ر
preferences-fonts-header2 =
    .label = الخطوط
preferences-default-zoom-label =
    .label = التقريب المبدئي
    .accesskey = ق
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }٪
preferences-zoom-text-only =
    .label = قرّب النص فقط
    .accesskey = ن
preferences-text-zoom-override-warning2 =
    .message = إذا كان خيار "قرّب النص فقط" مفعّلاً ولم يكن مستوى التقريب المبدئي لديك 100٪، فقد لا تعرض بعض المواقع المحتوى بشكل صحيح.
language-header = اللّغات
choose-language-description = اختر لغتك المفضلة لعرض الصفحات
website-language-heading =
    .description = تُعرض بعض صفحات الوِب بلغات متعدّدة. اختر اللغات حسب ترتيبك المفضل.
    .label = لغة الموقع الإلكتروني
website-preferred-language =
    .label = اللغات المفضلة
website-add-language =
    .label = أضِف لغة
website-add-language-button =
    .aria-label = أضف اللغة المحدّدة
    .title = أضف اللغة المحدّدة
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = أزِل { $locale }
    .title = أزِل { $locale }
choose-button =
    .label = اختر…
    .accesskey = خ
choose-browser-language-description = اختر اللغات التي ستُستخدم لعرض القوائم والرسائل والإشعارات من { -brand-short-name }.
manage-browser-languages-button =
    .label = اضبط البديلة
    .accesskey = د
confirm-browser-language-change-description = أعِد تشغيل { -brand-short-name } لتطبيق التغييرات
confirm-browser-language-change-button = طبِّق وأعِد التشغيل
browser-language-heading =
    .description = اختر اللغة المستخدمة لعرض القوائم والرسائل والإشعارات من { -brand-short-name }.
    .label = لغة المتصفّح
browser-language-preferred-label =
    .label = اللغة المفضلة
browser-language-fallback-label =
    .description = يُستخدم عندما تكون ترجمة اللغة المفضلة غير مكتملة.
    .label = اللغة الاحتياطية
browser-language-install-error =
    .message = تعذّر على { -brand-short-name } تحديث لغاتك حاليا. تحقق من اتصالك بالإنترنت أو أعِد المحاولة.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = الاستثناءات…
    .accesskey = ث
settings-translations-header =
    .aria-label = الترجمات
    .description = ترجم صفحات أو نصوصًا محدّدة. لحماية خصوصيتك، تظل الترجمات على جهازك.
    .label = الترجمات
settings-translations-offer-to-translate-label =
    .label = قدّم ترجمة الصفحة الكاملة
settings-translations-more-settings-button =
    .description = عيّن التفضيلات للغات والمواقع الإلكترونية والترجمة دون اتصال بالإنترنت.
    .label = المزيد من إعدادات الترجمة
settings-translations-subpage-header =
    .heading = المزيد من إعدادات الترجمة
settings-translations-subpage-speed-up-translation-header =
    .description = نزّل اللغات الكاملة لترجمة أسرع وللترجمة دون اتصال بالإنترنت.
    .label = تسريع الترجمة
settings-translations-subpage-automatic-translation-header =
    .label = الترجمة التلقائية
settings-translations-subpage-always-translate-header =
    .label = ترجم هذه اللغات دائمًا
settings-translations-subpage-never-translate-header =
    .label = لا تترجم هذه اللغات أبدًا
settings-translations-subpage-never-translate-sites-header =
    .label = لا تترجم هذه المواقع أبدًا
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = لإضافة موقع، افتح لوحة الترجمة <img data-l10n-name="translations-icon"/>، وحدّد إعدادات الترجمة <img data-l10n-name="settings-icon"/>، ثم اختر "لا تترجم هذا الموقع أبدًا".
settings-translations-subpage-language-select-option =
    .label = أضِف لغة
settings-translations-subpage-language-add-button =
    .aria-label = أضِف لغة
    .title = أضِف لغة
settings-translations-subpage-download-languages-header =
    .label = نزّل اللغات
settings-translations-subpage-download-languages-select-option =
    .label = اختر لغة
settings-translations-subpage-download-languages-button =
    .aria-label = نزّل اللغة
    .title = نزّل اللغة
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } م.بايت)
    .label = { $language } ({ $size } م.بايت)
settings-translations-subpage-no-languages-downloaded =
    .label = لم تُنزل أي لغات
settings-translations-subpage-no-languages-added =
    .label = لم تُضيف أي لغات
settings-translations-subpage-download-progress = جارِ التنزيل…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = تعذّر تنزيل { $language } ({ $size }م.بايت)
settings-translations-subpage-download-retry-button =
    .label = حاول مجددًا
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = احذف { $language } ({ $size }م.بايت)؟
settings-translations-subpage-download-delete-button =
    .label = احذف
settings-translations-subpage-download-cancel-button =
    .label = ألغِ
settings-translations-subpage-no-sites-added =
    .label = لم يُضاف أي مواقع
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = استعمل إعدادات نظام التشغيل لتنسيق التواريخ والأوقات والأرقام والمقاييس في ”{ $localeName }“.
settings-spellcheck-header =
    .label = التدقيق الإملائي
check-user-spelling =
    .label = دقق الإملاء أثناء الكتابة
    .accesskey = ك
spellcheck-download-dictionaries =
    .label = نزّل القواميس
spellcheck-promo =
    .heading = كيفية استخدام التدقيق الإملائي
    .message = انقر بزر الفأرة الأيمن فوق أي حقل نصي لتشغيل التدقيق الإملائي أو إيقافه، أو لتغيير اللغة. لا تدعم جميع الحقول التدقيق الإملائي.

## Downloads - Files and applications

files-and-applications-title = الملفات و التطبيقات
download-save-files-header =
    .label = احفظ الملفّات في
download-save-where-3 =
    .aria-label = احفظ الملفّات في
download-always-ask-where2 =
    .label = اسأل عن مكان حفظ الملفات قبل تنزيلها
    .accesskey = أ
download-private-browsing-delete2 =
    .label = احذف التنزيلات من النوافذ الخاصة عند الإغلاق
    .accesskey = ذ
applications-header = التطبيقات
applications-description = اختر كيف يتعامل { -brand-short-name } مع الملفات التي تنزلها من الوب أو التطبيقات التي تستخدمها أثناء التصفح.
applications-setting2 =
    .description = اختر كيف يتعامل { -brand-short-name } مع الملفات والمحتوى المُنزّل.
    .label = الملفات و التطبيقات
applications-filter =
    .placeholder = ابحث عن أنواع الملفات أو التطبيقات
applications-type-column =
    .label = نوع المحتوى
    .accesskey = ن
applications-type-heading = نوع المحتوى
applications-action-column =
    .label = الإجراء
    .accesskey = ج
applications-action-heading = الإجراء
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = ملف { $extension }
applications-action-save =
    .label = احفظ الملف
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = استخدم { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = استخدم { $app-name } (المبدئي)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] استعمل التطبيق المبدئي لنظام ماك‎أوإس
            [windows] استعمل التطبيق المبدئي لنظام وِندوز
           *[other] استعمل التطبيق المبدئي للنظام
        }
applications-use-other =
    .label = استخدم تطبيقًا آخر…
applications-select-helper = اختر التّطبيق المساعد
applications-manage-app =
    .label = تفاصيل التطبيق…
applications-always-ask =
    .label = اسأل دائمًا
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = افتح في { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = ما الذي يجب أن يفعله { -brand-short-name } مع الملفات الأخرى؟
applications-save-for-new-types =
    .label = احفظ الملفات
    .accesskey = ح
applications-save-for-new-types2 =
    .label = حفظ الملفات تلقائيًا
    .accesskey = ف
applications-ask-before-handling =
    .label = اسأل إذا كنت تريد فتح الملفات أو حفظها
    .accesskey = ك
applications-ask-before-handling2 =
    .label = اسأل لفتح الملفات أو حفظها
    .accesskey = أ
drm-group =
    .label = محتوى إدارة الحقوق الرقمية (DRM)
play-drm-content =
    .label = شغّل المحتوى الخاضع لإدارة الحقوق الرقمية
    .accesskey = ش
play-drm-content-learn-more = اطّلع على المزيد
# Variables:
# $version (string) - Firefox version
update-application-version = الإصدارة { $version } <a data-l10n-name="learn-more">ما الجديد</a>
update-history-2 =
    .label = أظهر تأريخ التحديث
    .accesskey = ظ
update-application-installation =
    .label = التنصيب
update-application-radio-group =
    .aria-label = التنصيب
update-application-auto-2 =
    .label = نزّل التحديثات تلقائيا (مستحسن)
    .accesskey = ز
update-application-check-choose-2 =
    .label = تحقق من وجود تحديثات، ولكن اختر وقت التثبيت.
    .accesskey = ق
update-application-background-enabled =
    .label = حين لا يعمل { -brand-short-name }
    .accesskey = ح
update-application-warning-cross-user-setting-2 =
    .message = سيُطبّق هذا الإعداد على كل حسابات وِندوز وملفات { -brand-short-name } الشخصية التي تستخدم هذه النسخة من { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = اعرض عدد أقل من تذكيرات التحديث
    .accesskey = ر
update-setting-write-failure-title2 = حدث عُطل أثناء تحديث الإعدادات
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    واجه { -brand-short-name } عُطلًا ولم يحفظ هذا التغيير. كي تغيّر إعداد التحديث هذا سيكون عليك تقديم تصريحك للكتابة في الملف أدناه. يمكنك أنت أو يمكن لمدير النظام أن يحلّ هذا العُطل بمنح مجموعة ”المستخدمين/Users“ التصريح الكامل للتحكّم بهذا الملف.
    
    تعذّرت الكتابة في الملف: { $path }
update-in-progress-title = يجري الآن التحديث
update-in-progress-message = أتريد من { -brand-short-name } مواصلة العمل على هذا التحديث؟
update-in-progress-ok-button = أ&همِل
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = وا&صِل

## About Firefox

about-firefox-header =
    .heading = عن { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = تعمل التحديثات على تحسين سرعة { -brand-short-name } واستقراره وأمانه.
    .label = تحديثات { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = الإشعارات
update-application-updates-managed-by-os =
    .message = تُدار التحديثات بواسطة نظام تشغيلك

## Firefox support

support-application-heading =
    .description = حل المشكلات أو شارك الأفكار مع المجتمع.
    .label = دعم { -brand-short-name }
support-get-help =
    .label = احصل على مُساعدة
support-share-ideas =
    .label = شارك الأفكار والتعليقات

## General Section - Performance

performance-settings-learn-more = اطّلع على المزيد
performance-allow-hw-accel =
    .label = استخدم تسريع العتاد إن كان متاحًا
    .accesskey = ع
performance-limit-content-process-option = حد سيرورة المحتوى
    .accesskey = ح
performance-limit-content-process-enabled-desc = يمكن أن تساهم زيادة سيرورات المحتوى في تحسين الأداء عند استعمال عدة ألسنة، و لكن ذلك يستهلك ذاكرة أكثر.
performance-limit-content-process-blocked-desc = لا يمكن تعديل عدد سيرورات المحتوى إلا في { -brand-short-name } متعدد السيرورات. <a data-l10n-name="learn-more">اطلع على كيفية التحقق من تفعيل تعدد السيرورات</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = ‏{ $num } (المبدئي)
performance-group =
    .label = الأداء
performance-use-recommended-settings-checkbox-2 =
    .description = خُصّصت هذه الإعدادات لتتناسب مع عتادك ونظام تشغيلك.
    .label = استعمل إعدادات الأداء المستحسنة
    .accesskey = م

## Accessibility page

browsing-use-autoscroll =
    .label = استخدم اللّف الآلي
    .accesskey = ف
keyboard-and-scrolling-group =
    .label = التنقل والتمرير باستخدام لوحة المفاتيح
motion-and-link-group =
    .label = تصميم الحركة والربط
browsing-use-smooth-scrolling =
    .label = استخدم اللّف السلس
    .accesskey = خ
browsing-gtk-use-non-overlay-scrollbars =
    .label = أظهِر أشرطة التمرير دائمًا
    .accesskey = ش
browsing-always-underline-links =
    .label = سطّر دائمًا الروابط
    .accesskey = ط
browsing-use-onscreen-keyboard =
    .label = اعرض لوحة مفاتيح باللمس عند الضرورة
    .accesskey = م
browsing-use-cursor-navigation =
    .label = استعمل دائمًا مفاتيح الأسهم للتنقل داخل الصفحات
    .accesskey = س
browsing-use-full-keyboard-navigation =
    .label = استخدم مفتاح اللسان لنقل التركيز بين متحكمات النماذج والروابط
    .accesskey = ج
browsing-search-on-start-typing =
    .label = ابحث عن النص مع بداية الكتابة
    .accesskey = ح
settings-keyboard-shortcuts-group =
    .description = تحكم في طريقة تنقلك وتفاعلك مع { -brand-short-name }.
    .label = اختصارات لوحة المفاتيح
settings-keyboard-shortcuts-customkeys-link =
    .label = خصّص اختصارات لوحة المفاتيح
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = خصّص إعدادات شريط العناوين في البحث
settings-media-group =
    .label = الوسائط
browsing-picture-in-picture-toggle-enabled-2 =
    .label = استخدم فديو معترِض
    .accesskey = د
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = استمر في تشغيل مقاطع الفيديو في وضع فديو معترِض عند التبديل بين الألسنة
    .accesskey = م
browsing-media-control =
    .label = تحكّم بالوسائط عبر لوحة المفاتيح أو سماعة الرأس أو الواجهة الافتراضية
    .accesskey = ك
recommendations-group =
    .label = التوصيات
browsing-cfr-recommendations =
    .label = امتدادات موصى بها وأنت تتصفّح
    .accesskey = ص
browsing-cfr-features =
    .label = مزايا مستحسنة وأنت تتصفّح أرجاء الوِب
    .accesskey = س
browsing-group =
    .label = التّصفّح
preferences-accessibility-header =
    .heading = الإتاحة
preferences-default-zoom-select =
    .aria-label = التقريب المبدئي
preferences-fonts-family =
    .label = عائلة الخط
    .accesskey = ئ
preferences-fonts-size =
    .label = حجم الخط
    .accesskey = م
preferences-fonts-advanced-settings =
    .label = إعدادات متقدّمة
    .accesskey = ع

## General Section - Proxy

network-proxy-group2 =
    .description = أعدّ كيفية اتصال { -brand-short-name } بالإنترنت.
    .label = إعدادات الوسيط
network-proxy-connection-settings2 =
    .description = تغيير هذه الإعدادات قد يتسبب في مشاكل في الاتصال
    .label = أعدّ الوسيط
    .accesskey = ع

## Home Section

home-new-windows-tabs-header = النوافذ و الألسنة الجديدة
home-new-windows-tabs-description2 = اختر ما تراه عندما تفتح صفحة البداية و النوافذ و الألسنة الجديدة.
home-section =
    .heading = الصفحة الرئيسية والبدء

## Home Section - Default Browser

home-default-browser-title =
    .label = المتصفّح المبدئي
is-default-browser-2 =
    .message = { -brand-short-name } هو متصفحك المبدئي. اختيار موفق.
is-not-default-browser-2 =
    .message = همم، { -brand-short-name } ليس خيارك المبدئي.
set-as-my-default-browser-2 =
    .label = اجعله المبدئي
    .accesskey = م

## Custom Homepage subpage

home-homepage-mode-label = صفحة البداية و النوافذ الجديدة
home-newtabs-mode-label = الألسنة الجديدة
home-restore-defaults =
    .label = استعد المبدئيات
    .accesskey = س
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (افتراضي)
home-mode-choice-custom =
    .label = عناوين مخصصة…
home-mode-choice-blank =
    .label = صفحة فارغة
home-homepage-custom-url =
    .placeholder = ألصِق عنوانا…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = أدِر الامتداد
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] استخدم الصفحة الحالية
           *[other] استخدم الصفحات الحالية
        }
    .accesskey = ح
choose-bookmark =
    .label = استخدم علامة…
    .accesskey = ع
home-homepage-title =
    .label = صفحة البداية
home-homepage-new-windows =
    .label = نوافذ جديدة
home-homepage-new-tabs =
    .label = الألسنة الجديدة
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = اختر موقعًا محددًا
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = عنوان(عناوين) الموقع الإلكتروني
home-custom-homepage-address =
    .placeholder = أدخل العنوان
home-custom-homepage-address-button =
    .label = أضف عنوانًا
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = لم تُضاف أي مواقع إلكترونية حتى الآن.
home-custom-homepage-delete-address-button =
    .aria-label = احذف العنوان
    .title = احذف العنوان
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = استبدل ب
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = الصفحات المفتوحة حاليًا
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = العلامات…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = الامتداد ({ $extension })
home-custom-homepage-header = صفحة بداية مخصّصة
home-custom-homepage-subpage =
    .heading = صفحة بداية مخصّصة

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = محتوى { -firefox-home-brand-name }
home-prefs-content-description2 = اختر المحتوى الذي تريد عرضه في شاشة { -firefox-home-brand-name }.
home-prefs-search-header =
    .label = ابحث في الوِب
home-prefs-shortcuts-header =
    .label = الاختصارات
home-prefs-shortcuts-description = المواقع التي حفظتها أو زُرتها
home-prefs-shortcuts-by-option-sponsored =
    .label = الاختصارات المموّلة
home-prefs-recommended-by-header-generic =
    .label = القصص المُقترحة
home-prefs-recommended-by-description-generic = محتوى استثنائي منتقى بعناية من قبل عائلة { -brand-product-name }
home-prefs-stories-header =
    .label = قصص
home-prefs-stories-description = قصص مخصّصة بناءً على نشاطك

##

home-prefs-recommended-by-learn-more = آلية العمل
home-prefs-recommended-by-option-sponsored-stories =
    .label = الأخبار الممولة
home-prefs-highlights-option-visited-pages =
    .label = الصفحات المزارة
home-prefs-highlights-options-bookmarks =
    .label = العلامات
home-prefs-highlights-option-most-recent-download =
    .label = آخر ما نُزّل
home-prefs-recent-activity-header =
    .label = أحدث الأنشطة
home-prefs-recent-activity-description = مختارات من المواقع والمحتويات الحديثة
home-prefs-weather-header =
    .label = الطقس
home-prefs-weather-description = لمحة عامة عن توقعات الطقس اليوم
home-prefs-weather-learn-more-link = اطّلع على المزيد
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = ادعم { -brand-product-name }
home-prefs-mission-message = يدعم رعاتنا مهمتنا في بناء شبكة إنترنت أفضل
home-prefs-mission-message-learn-more-link = اكتشف كيف
home-prefs-manage-topics-link = أدِر المواضيع
home-prefs-choose-wallpaper-link = اختر خلفية
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [zero] لا صفوف
            [one] صف واحد
            [two] صفان
            [few] { $num } صفوف
            [many] { $num } صفا
           *[other] { $num } صف
        }

## Search Section

search-show-suggestions-option =
    .label = اعرض اقتراحات البحث
    .accesskey = ت
search-show-suggestions-url-bar-option =
    .label = أظهر اقتراحات البحث في نتائج شريط العناوين
    .accesskey = ت
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = اعرض اقتراحات البحث قبل عرض تأريخ التصفح في نتائج شريط العناوين
search-show-suggestions-private-windows-2 =
    .label = اقتراحات البحث في النوافذ الخاصة
search-suggestions-cant-show-2 =
    .message = لن تظهر اقتراحات البحث في نتائج شريط الموقع لأنّك أعددت { -brand-short-name } على ألّا يتذكر التأريخ.
addressbar-header-1 =
    .description = اختر الاقتراحات التي تظهر في شريط عنوانك
    .label = شريط العناوين
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = اقتراحات من { -brand-short-name } وشركائنا في شريط عنوانك.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = أظهِر مصطلحات البحث في شريط العناوين على صفحات النتائج
search-separate-default-engine-2 =
    .label = استخدم محرك بحث مبدئي مختلف في النوافذ الخاصة
    .accesskey = د
search-separate-default-engine-dropdown =
    .aria-label = محرك البحث المبدئي في النوافذ الخاصة
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = التنقل داخل شريط العناوين
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = تخطَّ قائمة النتائج عند استخدام مفتاح Tab لنقل التركيز
search-suggestions-header-2 =
    .label = اقتراحات محركات البحث
search-one-click-header2 = اختصارات البحث
search-one-click-desc = اختر محركات البحث البديلة التي تظهر تحت شريطي العناوين و البحث عندما تكتب كلمة بحث.
search-one-click-header-3 =
    .description = اختر محركات البحث والاختصارات التي تظهر في شريط العنوان لديك.
    .label = محركات بحث إضافية
update-search-engine-success =
    .message = حُدِّث محرك البحث بنجاح
search-edit-engine-2 =
    .title = تعديل محرك البحث
search-delete-engine =
    .title = احذف محرك البحث
search-enable-engine =
    .title = فعِّل محرك البحث
search-outlink-to-extensions-page =
    .title = أدِر في الامتدادات والسمات
search-choose-engine-column =
    .label = محرك البحث
search-choose-keyword-column =
    .label = كلمة مفتاحية
search-restore-default =
    .label = استعد محركات البحث المبدئية
    .accesskey = د
search-remove-engine =
    .label = احذف
    .accesskey = ح
search-add-engine =
    .label = أضِف
    .accesskey = ض
search-add-engine-2 =
    .label = أضف محرك بحث
    .accesskey = ض
search-edit-engine =
    .label = حرّر
    .accesskey = ر
search-find-more-link = اعثر على المزيد من محركات البحث
search-filtering-for-add-engine = أضِف محركًا
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = كرر الكلمة المفتاحية
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = لقد اخترت كلمة مفتاحية يستخدمها ”{ $name }“ حاليا. من فضلك اختر واحدة أخرى.
search-keyword-warning-bookmark = لقد اخترت كلمة مفتاحية تستخدمها علامة حاليا. من فضلك اختر واحدة أخرى.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = يوجد بالفعل محرك بحث يحمل الاسم "{ $name }". يُرجى اختيار اسم آخر.
remove-engine-confirmation = أمتأكد من رغبتك في إزالة محرك البحث هذا؟
remove-engine-remove = أزِل
remove-addon-engine-alert = لإزالة محرك البحث هذا،أزِل الإضافة المرتبطة به.
search-engine-group =
    .label = محرك البحث المبدئي
search-default-engine =
    .aria-label = محرك البحث المبدئي
# Header for the search section ("search" is a noun).
search-section =
    .heading = ابحث

## Containers Section

containers-section-header2 =
    .heading = إعدادات الحاوية
containers-card-header2 =
    .description = افصل ملفات تعريف الارتباط حسب الحاوية حتى تتمكن من استخدام حسابات مختلفة على نفس الموقع والحد من التعقّب عبر المواقع.
    .label = الحاويات
containers-add-button2 =
    .label = أضف حاوية جديدة
    .accesskey = ض
containers-new-tab-check3 =
    .label = حدّد حاويًا لكلّ لسان جديد
    .accesskey = د
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = لا تستخدم الحاويات للروابط التي يتم فتحها من تطبيقات خارجية
    .accesskey = ت
containers-new-tab-check2 =
    .description = سيؤدي ذلك إلى فتح قائمة الحاويات في كل مرة تضغط فيها على زر ”افتح في لسان جديد“.
    .label = حدّد حاويًا لكلّ لسان جديد
    .accesskey = د
containers-settings-button2 =
    .title = الإعدادات
containers-remove-button3 =
    .title = احذف
containers-sites-card-header =
    .description = اختر حاوية للموقع وسيستخدمها { -brand-short-name } في كل مرة يتم فيها فتح الموقع.
    .label = حاويات خاصة بالموقع
containers-sites-add-button =
    .label = أضف موقع وب
    .accesskey = ض
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = حاوية لـ { $site }
containers-site-remove-button =
    .title = احذف
containers-remove-button2 =
    .title = أزِل

## Account and sync

sync-group-label =
    .label = المزامنة
account-group-label2 =
    .label = الحساب
account-disabled-group =
    .description = إعدادات الحساب غير متاحة.
    .label = الحساب
account-placeholder2 =
    .description = لِج وحافظ على خصوصية بياناتك وتعميتها، مع إمكانية الوصول إليها فورًا في كل مكان تستخدم فيه { -brand-short-name }.
    .label = لست والجًا
account-sync-section =
    .heading = الحساب والمزامنة
pane-account-sync-title2 = الحساب والمزامنة
    .title = الحساب والمزامنة

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = خُذ الوِب معك
sync-signedout-description2 = زامن علاماتك وتأريخك وألسنتك وكلمات سرك وإضافاتك و الإعدادات بين كل أجهزتك.
sync-signedout-account-signin3 =
    .label = لِج كي تبدأ المزامنة…
    .accesskey = ل
sync-signedout-account-signin-4 =
    .label = لج إلى حسابك لبدء المزامنة
    .accesskey = ل
sync-signedout-account-short =
    .label = لج
    .accesskey = ل
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = نزّل Firefox لنظامي <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">أندرويد</a> أو <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">آي أو إس</a> للمزامنة مع هاتفك المحمول.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = غيّر صورة الحساب
    .tooltiptext = غيّر صورة الحساب
sync-profile-picture-account-problem =
    .alt = صورة الملف الشخصي للحساب
fxa-login-rejected-warning =
    .alt = تحذير
sync-sign-out =
    .label = اخرج…
    .accesskey = خ
sync-sign-out2 =
    .label = اخرج
    .accesskey = خ
sync-manage-account = أدِر الحساب
    .accesskey = س
sync-manage-account2 =
    .label = أدِر الحساب
    .accesskey = س

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } ليس مؤكّدًا.
sync-signedin-unverified2 =
    .description = تحقق من بريدك الوارد لتأكيد حسابك وجعله رسميًا.
    .label = لم يُأكّد { $email } بعد
sync-signedin-login-failure = من فضلك لج لإعادة التوصيل { $email }
sync-signedin-login-failure2 =
    .description = لِج مرة أخرى لإعادة الاتصال وبدء مزامنة بياناتك.
    .label = لقد سُجّل خروجك من { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = أكّد الحساب
    .accesskey = س
sync-remove-account =
    .label = أزِل الحساب
    .accesskey = ز
sync-sign-in =
    .label = لِج
    .accesskey = ل

## Sync section - enabling or disabling sync.

prefs-syncing-on = المزامنة: مفعلة
prefs-syncing-on-2 =
    .label = المزامنة مفعّلة
prefs-syncing-off = المزامنة: معطلة
prefs-syncing-off-2 =
    .description = فعّل المزامنة للحصول على علاماتك وكلمات مرورك وتأريخك والمزيد على أي جهاز.
    .label = المزامنة معطّلة
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = شغّل المزامنة للحصول على علاماتك وكلمات سرك والتأريخ والمزيد على هذا الجهاز.
    .label = المزامنة معطّلة
prefs-sync-turn-on-syncing =
    .label = فعّل المزامنة…
    .accesskey = ف
prefs-sync-turn-on-syncing-2 =
    .label = فعّل المزامنة
    .accesskey = ف
prefs-sync-offer-setup-label2 = زامن علاماتك وتأريخك وألسنتك وكلمات سرك وإضافاتك و الإعدادات بين كل أجهزتك.
prefs-sync-now-button =
    .label = زامِن الآن
    .accesskey = م
prefs-sync-now-button-2 =
    .label = زامِن الآن
    .accesskey = م
prefs-syncing-button =
    .label = يُزامن…
prefs-syncing-button-2 =
    .label = يُزامن…
    .title = زامِن الآن

## The list of things currently syncing.

sync-syncing-across-devices-heading = أنت تُزامن هذه العناصر عبر جميع أجهزتك المتصلة:
sync-syncing-across-devices-heading-2 = البيانات المزامنة عبر الأجهزة
sync-syncing-across-devices-heading-3 = مزامنة البيانات على هذا الجهاز
sync-syncing-across-devices-empty-state2 =
    .description = أنت لا تُزامن أي شيء... حتى الآن. ابدأ المزامنة للحصول على جميع بياناتك على جميع أجهزتك.
    .label = أدر البيانات المتزامنة
sync-syncing-across-devices-empty-state3 =
    .description = لم تُزامِن أي شيء... حتى الآن. اختر ما تريد مُزامنته على هذا الجهاز.
    .label = أدِر البيانات المتزامنة
sync-currently-syncing-bookmarks = العلامات
sync-currently-syncing-history = التأريخ
sync-currently-syncing-tabs = الألسنة المفتوحة
sync-currently-syncing-passwords = كلمات السر
sync-currently-syncing-addresses = العناوين
sync-currently-syncing-payment-methods = طرق الدفع
sync-currently-syncing-addons = الإضافات
sync-currently-syncing-settings = الإعدادات
sync-manage-options =
    .label = أدر المزامنة…
    .accesskey = د
sync-manage-options-2 =
    .label = أدر البيانات المتزامنة
    .accesskey = د
settings-sync-disconnect-button =
    .label = اقطع الاتصال

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = علاماتي
    .accesskey = م
sync-engine-history =
    .label = تأريخي
    .accesskey = خ
sync-engine-tabs =
    .label = الألسنة المفتوحة
    .tooltiptext = قائمة بالألسنة المفتوحة على كل الأجهزة
    .accesskey = س
sync-engine-passwords =
    .label = كلمات السر
    .tooltiptext = كلمات السر التي حفظتها
    .accesskey = ك
sync-engine-addresses =
    .label = العناوين
    .tooltiptext = العناوين البريدية التي حفظتها (لسطح المكتب فقط)
    .accesskey = ع
sync-engine-payment-methods2 =
    .label = طرق الدفع
    .tooltiptext = الأسماء وأرقام البطاقات وتواريخ انتهاء الصلاحية
    .accesskey = n
sync-engine-addons =
    .label = الإضافات
    .tooltiptext = امتدادات و سمات لنسخة سطح المكتب من فَيَرفُكس
    .accesskey = ت
sync-engine-settings =
    .label = الإعدادات
    .tooltiptext = الإعدادات العامة وإعدادات الخصوصية والأمن التي غيّرتها
    .accesskey = ع
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = احفظ
    .buttonlabelextra2 = اقطع الاتصال…
    .buttonaccesskeyaccept = ح
    .buttonaccesskeyextra2 = ق
    .style = min-width: 36em;
    .title = إدارة ما يُزامِن على جميع أجهزتك المتصلة
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = احفظ
    .buttonlabelextra2 = اقطع الاتصال…
    .buttonaccesskeyaccept = ح
    .buttonaccesskeyextra2 = ق
    .style = min-width: 36em;
    .title = أدِر ما تتم مُزامنته على هذا الجهاز

## The device name controls.

sync-device-name-header = اسم الجهاز
sync-device-name-header-2 =
    .label = اسم الجهاز
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = اسم الجهاز
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = غيّر اسم الجهاز
    .accesskey = ه
sync-device-name-change =
    .label = غيّر اسم الجهاز…
    .accesskey = ه
sync-device-name-cancel =
    .label = ألغِ
    .accesskey = ل
sync-device-name-save =
    .label = احفظ
    .accesskey = ح
sync-connect-another-device = صِلْ جهازا آخر
sync-connect-another-device-2 =
    .label = صِلْ جهازا آخر

## Privacy Section

privacy-header = خصوصية المتصفح

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = كلمات السر
    .searchkeywords = س
forms-passwords-header =
    .aria-label = كلمات السر
    .label = كلمات السر
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = اسأل لحفظ كلمات السر
    .accesskey = ت
forms-manage-password-exceptions =
    .label = أدر استثناءات كلمات السر
    .accesskey = د
forms-exceptions =
    .label = الاستثناءات…
    .accesskey = س
forms-suggest-passwords =
    .label = اقترِح كلمات سر قوية
    .accesskey = ر
forms-breach-alerts =
    .label = اعرض تنبيهات بكلمات السر المتسرّبة من المواقع
    .accesskey = ت
forms-breach-alerts-learn-more-link = اطّلع على المزيد
preferences-relay-integration-checkbox2 =
    .label = اقترح استخدام أقنعة البريد الإلكتروني { -relay-brand-name } لحماية عنوان بريدك الإلكتروني
    .accesskey = ر
relay-integration-learn-more-link = اطّلع على المزيد
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = املأ أسماء المستخدمين وكلمات السر تلقائيًا
    .accesskey = ر
forms-fill-usernames-and-passwords-2 =
    .label = احفظ أسماء المستخدمين وكلمات المرور واملأها تلقائيًا
    .accesskey = ف
forms-saved-passwords =
    .label = كلمات السر المحفوظة
    .accesskey = ت
forms-saved-passwords-2 =
    .label = أدر كلمات السر المحفوظة
    .accesskey = د
forms-saved-passwords-searchkeywords = حُفظت جلسات الولوج للمواقع التالية على حاسوبك
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = حماية إضافية
forms-primary-pw-use =
    .label = استعمل كلمة سر رئيسيّة
    .accesskey = س
forms-primary-pw-use-2 =
    .description = يضيف طبقة حماية إضافية لتأمين كلمات سرك المحفوظة.
    .label = استعمل كلمة سر رئيسية
    .accesskey = م
forms-primary-pw-set =
    .label = عيِّن كلمة سر رئيسية
forms-primary-pw-on-2 = كلمة السر الأساسية <strong>مفعّلة</strong>
forms-primary-pw-on =
    .label = كلمة السر الأساسية مُفعّلة
forms-primary-pw-change-2 =
    .label = غيّر كلمة السر الرئيسية
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = عطّله
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = يتطلب الولوج إلى الجهاز لملء كلمات السر وإدارتها
forms-os-reauth-2 =
    .label = تطلب الولوج إلى الجهاز لإدارة كلمات السر
forms-primary-pw-learn-more-link = اطّلع على المزيد
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = غيّر كلمة السر الرئيسيّة…
    .accesskey = ر
forms-primary-pw-change =
    .label = غيّر كلمة السر الرئيسيّة…
    .accesskey = غ
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = أنت حاليًّا في وضع FIPS. يتطلّب FIPS كلمة سر رئيسية غير فارغة.
forms-master-pw-fips-desc = فشل تغيير كلمة السر
forms-windows-sso =
    .label = اسمح بالولوج الموحّد من وِندوز إلى حسابات ميكروسوفت وحسابات العمل والحسابات المدرسية.
forms-windows-sso-learn-more-link = اطّلع على المزيد
forms-windows-sso-desc = أدِر الحسابات في إعدادات الجهاز
windows-passkey-settings-label = أدر مفاتيح السر (passkeys) في إعدادات النظام
privacy-panel-settings-header =
    .description = احصل على المساعدة لحماية معلوماتك عبر الإنترنت في { -brand-short-name }.
    .label = إعدادات لوحة الخصوصية
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = اعرض رسائل الاختراق
    .accesskey = ع

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = أدخِل معلومات ولوج وِندوز لتصنع كلمة سر رئيسية. يساعد هذا الأمر على حماية أمن حساباتك.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = أنشِئ كلمة سر رئيسية
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] تغيير إعدادات طرق الدفع
       *[other] يحاول { -brand-short-name } تغيير إعدادات طرق الدفع. استخدم بيانات الولوج الخاصة بجهازك للسماح بذلك.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = طُرق الدفع
autofill-payment-methods-checkbox-message-2 =
    .label = احفظ معلومات الدفع واملأها تلقائيًا
    .accesskey = ف
autofill-payment-methods-manage-payments-title =
    .heading = أدر طرق الدفع
autofill-payment-methods-manage-payments-button =
    .label = أدر طرق الدفع
    .accesskey = د
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = يتطلب الأمر الولوج إلى الجهاز للملء الآلي وإدارة طُرق الدفع
    .accesskey = ط
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = احفظ رموز الأمان
    .accesskey = ح
autofill-payment-methods-add-button = أضف طريقة دفع جديدة
payments-list-header =
    .label = طرق الدفع
payments-delete-payment-prompt-title = حذف طريقة الدفع هذه؟
payments-delete-payment-prompt-confirm-button = احذف
payments-delete-payment-prompt-cancel-button = ألغِ
payments-delete-payment-button-label =
    .aria-label = احذف
payments-edit-payment-button-label =
    .aria-label = حرّر
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = لم تُضاف أي طُرق دفع
autofill-addresses-checkbox-message =
    .label = احفظ واملء آليًا العناوين
    .accesskey = ح
autofill-addresses-manage-addresses-button =
    .label = أدر العناوين والمزيد
    .accesskey = د
addresses-list-header =
    .label = العناوين
addreses-delete-address-button-label =
    .aria-label = احذف
addreses-edit-address-button-label =
    .aria-label = حرّر
addresses-delete-address-prompt-title = حذف هذا العنوان؟
addresses-delete-address-prompt-confirm-button = احذف
addresses-delete-address-prompt-cancel-button = ألغِ
autofill-addresses-add-button = أضِف عنوانًا جديدًا
autofill-addresses-manage-addresses-title =
    .heading = أدر العناوين والمزيد
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = لم تُضاف أي عناوين
personal-info-group =
    .label = المعلومات الشخصية
autofill-personal-info-checkbox-message =
    .label = احفظ المعلومات الشخصية واملأها تلقائيًا
autofill-personal-info-manage-button =
    .label = إدارة المعلومات الشخصية
passports-list-header =
    .label = جوازات السفر
passports-delete-passport-button-label =
    .aria-label = احذف
passports-edit-passport-button-label =
    .aria-label = حرّر
passports-delete-passport-prompt-title = حذف جواز السفر هذا؟
passports-delete-passport-prompt-confirm-button = احذف
passports-delete-passport-prompt-cancel-button = ألغِ
autofill-passports-add-button = أضف جواز سفر جديد
autofill-personal-info-manage-title =
    .heading = إدارة المعلومات الشخصية
pane-passwords-autofill-title2 = كلمات السر والملء الآلي
    .title = كلمات السر والملء الآلي
preferences-passwords-autofill-header =
    .heading = كلمات السر والملء الآلي
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
addresses-group =
    .label = العناوين والمزيد
payments-group =
    .label = طرق الدفع

## Privacy Section - History

history-remember-option-never2 =
    .description = تعمل كل نافذة كأنها نافذة خاصة. عند تفعيل هذا الخيار، ستحتاج الامتدادات إلى الحصول على إذن للعمل.
    .label = لا تتذكر التأريخ أبدًا
history-remember-option-custom2 =
    .label = خصّص التأريخ
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = سيتذكر { -brand-short-name } تأريخ التصفح، و التنزيلات، و الاستمارات، و البحث.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = سيستخدم { -brand-short-name } نفس إعدادات التصفح الخاص، بحيث لن يحتفظ بأيّ تأريخ لتصفحك للوب.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = سيستخدم { -brand-short-name } إعدادات مخصّصة لتأريخ التصفح والتنزيل والنماذج والبحث.
history-private-browsing-permanent =
    .label = استخدم نمط التصفح الخاص دائمًا
    .accesskey = د
history-remember-browser-option =
    .label = تذكر تأريخ التصفح و التنزيل
    .accesskey = ت
history-remember-search-option =
    .label = تذكّر تأريخ النماذج والبحث
    .accesskey = ث
history-clear-on-close-option =
    .label = امسح التأريخ عند إغلاق { -brand-short-name }
    .accesskey = غ
history-clear-on-close-settings =
    .label = إعدادات…
    .accesskey = د
history-shutdown-exceptions =
    .label = أدر الاستثناءات
    .accesskey = د
history-clear-button =
    .label = امسح التأريخ…
    .accesskey = ت
history-header2 =
    .heading = التأريخ
history-section-header =
    .description = اختر ما تريد أن يتذكره { -brand-short-name } عند إغلاق المتصفح.
    .label = التأريخ
history-custom-section-header =
    .description = خصّص ما تريد أن يتذكره { -brand-short-name } عند إغلاق المتصفح.
    .label = إعدادات متقدّمة
history-custom-button =
    .label = اختر ما تريد أن يتذكره { -brand-short-name }
history-group =
    .label = التأريخ
history-mode-radio-group =
    .aria-label = التأريخ
history-remember-option-all2 =
    .label = تذكر التأريخ

## Privacy Section - Site Data

sitedata-total-size-calculating = يحسب حجم بيانات الموقع و الخبيئة…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = تستخدم مواقع الوِب حاليًا <strong>{ $value } { $unit }</strong> من مساحة القرص.
sitedata-learn-more = اطّلع على المزيد
sitedata-delete-on-close2 =
    .label = امحُ ملفات تعريف الارتباط وبيانات الموقع في كل مرة تغلق فيها { -brand-short-name }
    .accesskey = ت
sitedata-delete-on-close-private-browsing3 =
    .message = استنادًا إلى إعدادات التأريخ لديك، يحذف { -brand-short-name } الكعكات وبيانات الموقع من جلستك عند إغلاق المتصفح.
sitedata-delete-on-close-private-browsing4 =
    .heading = لن يُحفظ التأريخ.
    .message = { -brand-short-name } يمحو ملفات تعريف الارتباط وبيانات الموقع من جلستك عند إغلاق المتصفح.
sitedata-option-block-cross-site-trackers =
    .label = المتعقّبات بين المواقع
sitedata-option-block-cross-site-tracking-cookies =
    .label = الكعكات التي تتعقّبك بين المواقع
sitedata-option-block-cross-site-cookies2 =
    .label = اعزل ملفات تعريف الارتباط بين المواقع
sitedata-option-block-unvisited =
    .label = الكعكات من المواقع غير المُزارة
sitedata-option-block-all-cross-site-cookies =
    .label = كل الكعكات بين المواقع (قد تتسبب بتعطُل المواقع)
sitedata-option-block-all =
    .label = كل الكعكات (يمكن أن تعطب المواقع هكذا)
sitedata-clear2 =
    .label = امحُ بيانات التصفح
    .accesskey = م
sitedata-settings2 =
    .label = أدر بيانات التصفح
    .accesskey = د
sitedata-cookies-exceptions =
    .label = أدِر الاستثناءات…
    .accesskey = ت
sitedata-cookies-exceptions2 =
    .description = يمكنك تحديد المواقع الإلكترونية المسموح لها دائمًا أو غير المسموح لها مطلقًا باستخدام ملفات تعريف الارتباط وبيانات الموقع.
    .label = أدر الاستثناءات
    .accesskey = د
sitedata-heading =
    .description = أدِر ملفات تعريف الارتباط، والسجل وذاكرة التخزين المؤقت وبيانات موقع الوِب، والمزيد.
    .label = بيانات التصفح
sitedata-settings3 =
    .label = امحُ بيانات مواقع معينة
    .accesskey = م
sitedata-cookies-exceptions3 =
    .description = يمكنك تحديد المواقع الإلكترونية المسموح لها دائمًا أو غير المسموح لها مطلقًا باستخدام ملفات تعريف الارتباط وبيانات الموقع.
    .label = أدر الاستثناءات
    .accesskey = د
cookies-site-data-group =
    .label = الكعكات و بيانات المواقع

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = مانع لافتة ملفات تعريف الارتباط
cookie-banner-blocker-description = عندما يطلب منك موقع ما الإذن باستخدام ملفات تعريف الارتباط في وضع التصفح الخاص، فإن { -brand-short-name } يرفض ذلك تلقائيًا. هذا متاح فقط على المواقع المدعومة.
cookie-banner-learn-more = اطّلع على المزيد
cookie-banner-blocker-checkbox-label =
    .label = رفض لافتات ملفات تعريف الارتباط تلقائيًا

## Search Section

addressbar-locbar-history-option =
    .label = تأريخ التصفح
    .accesskey = ص
addressbar-locbar-bookmarks-option =
    .label = العلامات
    .accesskey = ع
addressbar-locbar-clipboard-option =
    .label = الحافظة
    .accesskey = ظ
addressbar-locbar-openpage-option =
    .label = الألسنة المفتوحة
    .accesskey = ف
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = اختصارات
    .accesskey = خ
addressbar-locbar-topsites-option =
    .label = المواقع الأكثر زيارة
    .accesskey = ك
addressbar-locbar-engines-option-1 =
    .label = اقترح محركات البحث التي يجب استخدامها
    .accesskey = ر
addressbar-locbar-quickactions-option =
    .label = إجراءات سريعة
    .accesskey = س
addressbar-locbar-showrecentsearches-option-2 =
    .label = عمليات البحث الأخيرة
    .accesskey = ل
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = اقتراحات البحث المُتداولة
    .accesskey = ت
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = احصل على اقتراحات من الوِب تتعلق ببحثك.
    .label = اقتراحات من { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = ادعم { -brand-short-name } باقتراحات برعاية عرضية.
    .label = اقتراحات من الرعاة
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = احصل على اقتراحات من Mozilla أثناء الكتابة
addressbar-dismissed-suggestions-label-2 =
    .description = استعِد الاقتراحات المرفوضة من الرعاة و{ -brand-short-name }.
    .label = الاقتراحات المهملة
addressbar-restore-dismissed-suggestions-button-2 =
    .label = استعِد الاقتراحات

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = الحماية الموسّعة من التعقب
content-blocking-section-top-level-description = تحاول المتعقّبات معرفة ما تفعل على الشبكة دومًا وجمع المعلومات التي تخصّ عاداتك في التصفّح كما واهتماماتك. يحجب { -brand-short-name } أكثر هذه المتعقّبات وغيرها من سكربتات ضارة.
content-blocking-learn-more = اطّلع على المزيد
content-blocking-fpi-incompatibility-warning = أنت تستخدم عزل الطرف الأول (FPI)، والذي يتخطى بعض إعدادات كعكات { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = أنت تستخدم ميزة Resist Fingerprinting (RFP)، والتي تحل محل بعض إعدادات حماية التبصيم في { -brand-short-name }. قد يتسبب هذا في تعطل بعض المواقع.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = قياسي
    .accesskey = ق
enhanced-tracking-protection-setting-strict =
    .label = صارم
    .accesskey = ص
enhanced-tracking-protection-setting-custom =
    .label = مخصّص
    .accesskey = خ

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = يوازن بين الحماية والأداء. ستتحمّل الصفحات كالعادة.
content-blocking-etp-strict-desc = حماية أقوى وأعتى، لكنها قد تعطب محتويات بعض المواقع أو المواقع نفسها.
content-blocking-etp-custom-desc = اختر المتعقّبات والسكربتات التي تريد حجبها.
content-blocking-etp-blocking-desc = يحجب { -brand-short-name } الآتي:
content-blocking-private-windows = المحتوى الذي يتعقّبك في النوافذ الخاصة
content-blocking-cross-site-cookies-in-all-windows2 = ملفات تعريف الارتباط عبر المواقع في جميع النوافذ
content-blocking-cross-site-tracking-cookies = كعكات تتعقّبك بين المواقع
content-blocking-all-cross-site-cookies-private-windows = الكعكات بين المواقع في النوافذ الخاصة
content-blocking-isolate-cross-site-cookies = اعزل الكعكات بين المواقع
content-blocking-social-media-trackers = متعقبات مواقع التواصل الاجتماعي
content-blocking-all-cookies = كل الكعكات
content-blocking-unvisited-cookies = الكعكات من المواقع غير المُزارة
content-blocking-all-windows-tracking-content = المحتوى الذي يتعقّبك في كل النوافذ
content-blocking-all-cross-site-cookies = جميع ملفات تعريف الارتباط عبر المواقع
content-blocking-cryptominers = المُعدّنات المعمّاة
content-blocking-fingerprinters = مسجّلات البصمات
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = المسجّلات المشتبه بها والمعروفة
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = يحتوي حماية كاملة لملفات تعريف الارتباط على ملفات تعريف الارتباط الخاصة بالموقع الذي تتصفحه، لذلك لا يمكن لبرامج التتبع استخدامها لمتابعتك بين المواقع.
content-blocking-etp-standard-tcp-rollout-learn-more = اطّلع على المزيد
content-blocking-etp-standard-tcp-title = يتضمن حماية كاملة لملفات تعريف الارتباط، وهي أقوى ميزة خصوصية لدينا على الإطلاق
content-blocking-warning-title-2 = قد تتعطل بعض المواقع بسبب الحماية الصارمة من التتبع.
content-blocking-warning-title-custom = قد تتعطل بعض المواقع بسبب حماية التتبع المخصّصة
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = يُوصي { -brand-short-name } باستخدام إعدادات "أصلح مشاكل الموقع" لتقليل مشاكل الموقع والمحتوى. إذا بدا الموقع معطّلاً، فحاول إيقاف حماية التتبع لهذا الموقع لتحميل جميع المحتويات.
content-blocking-warning-learn-how = اطّلع على المزيد
content-blocking-baseline-exceptions-3 =
    .description = يساعد في تحميل المواقع والميزات من خلال إلغاء حظر العناصر الأساسية فقط التي قد تحتوي على أدوات تتبع. يغطي معظم المشكلات الشائعة.
    .label = أصلح المشاكل الرئيسية في الموقع (موصى به)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = يستعيد عناصر مثل مقاطع الفيديو في المقالات أو أقسام التعليقات من خلال إلغاء حظر العناصر التي قد تحتوي على أدوات تتبع. قد يقلل هذا من مشاكل الموقع ولكنه يوفر حماية أقل. يجب استخدامه مع إصلاحات للمشاكل الرئيسية.
    .label = أصلح المشاكل البسيطة في الموقع
content-blocking-baseline-uncheck-warning-dialog-title = هل أنت متأكد من أنك تريد  تعطيل الإصلاحات؟
content-blocking-baseline-uncheck-warning-dialog-body = يساعد هذا الإعداد في حلّ معظم مشاكل المواقع الشائعة. إذا أوقفت تشغيله، فقد لا تعمل بعض المواقع، ولن يتمكن { -brand-short-name } من المساعدة في حلّ هذه المشاكل.
content-blocking-baseline-uncheck-warning-dialog-ok-button = تعطيل الإصلاحات
content-blocking-baseline-uncheck-warning-dialog-cancel-button = إبقاء الإصلاحات مُشغّلة
content-blocking-reload-description = عليك إعادة تحميل الألسنة لتأخذ هذه التغييرات مفعولها.
content-blocking-reload-tabs-button =
    .label = أعِد تحميل كل الألسنة
    .accesskey = ع
content-blocking-tracking-content-label =
    .label = المحتوى الذي يتعقّبك
    .accesskey = ح
content-blocking-tracking-protection-option-all-windows =
    .label = في كل النوافذ
    .accesskey = ك
content-blocking-option-private =
    .label = في النوافذ الخاصة فقط
    .accesskey = خ
content-blocking-cookies-label =
    .label = الكعكات
    .accesskey = ك
content-blocking-expand-section =
    .tooltiptext = معلومات أكثر
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = المُعدّنات المعمّاة
    .accesskey = ن
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = المسجّلات المعروفة
    .accesskey = ف
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = المسجّلات المشتبه بها
    .accesskey = س

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = أدر الاستثناءات…
    .accesskey = د

## Privacy Section - Permissions

permissions-notification-pause =
    .label = ألبِث الإشعارات حتى يُعاد تشغيل { -brand-short-name }
    .accesskey = ث
permissions-autoplay2 =
    .label = التشغيل التلقائي
permissions-block-popups2 =
    .label = احجب النوافذ المنبثقة وعمليات إعادة التوجيه من جهات خارجية
    .accesskey = ظ
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = إضافة مواقع إلكترونية يمكنها فتح نوافذ منبثقة واستخدام عمليات إعادة توجيه من جهات خارجية.
    .label = أدر الاستثناءات
    .searchkeywords = نوافذ منبثقة
    .accesskey = د
permissions-addon-install-warning3 =
    .label = أظهر تحذير عند محاولة المواقع الإلكترونية تثبيت امتدادات
    .accesskey = ه
permissions-addon-exceptions2 =
    .label = اختر المواقع الإلكترونية التي يمكنها تثبيت الامتدادات.
    .accesskey = ت
permissions-location2 =
    .label = المكان
permissions-localhost2 =
    .label = تطبيقات وخدمات الأجهزة
permissions-local-network2 =
    .label = أجهزة الشبكة المحلية
permissions-xr2 =
    .label = الواقع الافتراضي
permissions-camera2 =
    .label = الكاميرا
permissions-microphone2 =
    .label = الميكروفون
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = السماعة
permissions-notification2 =
    .label = الإشعارات
permissions-header3 =
    .description = أدِر ما يمكن للمواقع الإلكترونية الوصول إليه أو التحكم فيه أو تفعيله.
    .label = الأذونات
permissions-data-section =
    .heading = الأذونات والبيانات
pane-permissions-data-title2 = الأذونات والبيانات
    .title = الأذونات والبيانات
notifications-section-header =
    .heading = الإشعارات
notifications-entry-card-header =
    .description = اختر المواقع الإلكترونية التي يمكنها إرسال الإشعارات، وكيف تظهر هذه التنبيهات.
    .label = الإشعارات
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = أدر إعدادات إشعارات الموقع الإلكتروني
notifications-website-card-header =
    .description = اختر الطريقة التي يمكن للمواقع الإلكترونية من خلالها إرسال الإشعارات.
    .label = إشعارات الموقع الإلكتروني
notifications-filter =
    .placeholder = ابحث في المواقع
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = الموقع
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = اسمح بالإشعارات
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = مواقع وِب
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = دائمًا
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = اسمح
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = أبدًا
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = لم تتم إضافة أي إشعارات للموقع الإلكتروني.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = لا توجد إشعارات من مواقع الوِب تتطابق مع بحثك.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = للتأكد من تضمين هذا التغيير في النسخ الاحتياطية، افتح كل ملف تعريف واختر "انسخ احتياطيًا الآن" في الإعدادات.
nimbus-rollouts =
    .description = ستطُرح التغييرات عن بُعد.
    .label = اسمح لـ { -brand-short-name } بتحسين الميزات والأداء والاستقرار بين التحديثات
addon-recommendations3 =
    .description = احصل على توصيات لامتدادات تحسّن من تجربة التصفح لديك.
    .label = اسمح بتوصيات امتداد مخصّصة
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = الإبلاغ عن البيانات معطّل في إعدادات البناء.
collection-backlogged-crash-reports2 =
    .label = أرسل تقارير الإنهيار تلقائيًا
    .accesskey = س
collection-backlogged-crash-reports-description = يساعد هذا { -vendor-short-name } في تشخيص المشكلات وإصلاحها بالمتصفح. قد تتضمن التقارير بيانات شخصية أو حساسة.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = نفس الإعدادات، مظهر جديد!
    .message = لقد أعدنا تنظيم هذه الصفحة لتسهيل تصفحها واستكشافها. لم تتغير إعداداتك الشخصية، وكل شيء لا يزال موجودًا هنا. نصيحة: استخدم البحث للانتقال مباشرة إلى ما تحتاجه.
settings-redesign-promo-dismiss-button =
    .label = فهمت
privacy-segmentation-section-header = خصائص جديدة تعزز تصفحك
privacy-segmentation-section-description = عندما نقدم ميزات تستخدم بياناتك لمنحك تجربة أكثر تخصيصًا:
privacy-segmentation-radio-off =
    .label = استخدم توصيات { -brand-product-name }
privacy-segmentation-radio-on =
    .label = أظهِر المعلومات المفصلة
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = نحن نسعى جاهدين لتزويدك بالخيارات، ولا نجمع سوى الحد الأدنى من البيانات اللازمة لتحسين { -brand-product-name } للجميع.
    .label = جمع واستخدام بيانات { -brand-short-name }
    .searchkeywords = قياس عن بعد
data-collection-link = اعرض تنويه الخصوصية
data-collection-preferences-across-profiles =
    .message = تنطبق هذه الإعدادات على كل ملف تعريف { -brand-product-name } على هذا الجهاز.
data-collection-profiles-link = اعرض جميع الملفات الشخصية
data-collection-health-report-telemetry-disabled =
    .message = لم تعد تسمح بأن يلتقط { -vendor-short-name } البيانات التقنية والتفاعلية. ستُحذف البيانات القديمة كلها خلال 30 يومًا.
data-collection-health-report =
    .description = يساعدنا هذا في تحسين ميزات { -brand-product-name } وأدائه واستقراره.
    .label = أرسل البيانات التقنية والتفاعلية إلى { -vendor-short-name }
    .accesskey = س
data-collection-health-report-disabled =
    .description = عُطِّل إرسال تقارير البيانات لتضبيط هذا الإصدار.
    .label = أرسل البيانات التقنية والتفاعلية إلى { -vendor-short-name }
    .accesskey = س
data-collection-run-studies =
    .description = يختار { -brand-short-name } مستخدمين بشكل عشوائي لاختبار الميزات، مما يساعد في تحسين الجودة للجميع.
    .label = اسمح لـ { -brand-short-name } بتشغيل دراسات الميزات
data-collection-studies-link =
    .label = اعرض دراسات { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = يساعد هذا { -vendor-short-name } في تشخيص وإصلاح المشكلات في المتصفح. قد تتضمن التقارير بيانات شخصية أو حساسة.
    .label = إرسال تقارير الإنهيار تلقائيًا
    .accesskey = إ
data-collection-usage-ping =
    .description = يساعد هذا { -vendor-short-name } في تقدير عدد المستخدمين النشطين.
    .label = أرسل إشعار الاستخدام اليومي إلى { -vendor-short-name }
    .accesskey = س

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = الأمان
browsing-protection-group2 =
    .description = يمكن للمواقع وعمليات التنزيل الخطيرة أن تعرض بياناتك وجهازك للخطر. يقوم { -brand-short-name } بحظرها تلقائيًا، ويحذرك من البرامج الخطيرة أو غير المرغوب فيها.
    .label = الحماية من المحتوى المخادع والبرمجيات الخبيثة
security-enable-safe-browsing =
    .label = احجب المحتوى الخطير والمخادع
    .accesskey = ح
security-enable-safe-browsing-link = اطّلع على المزيد
security-safe-browsing-warning =
    .message = يؤدي إيقاف تشغيل هذا الخيار إلى تقليل الحماية ضد عمليات الاحتيال والمواقع الضارة والتنزيلات الخطيرة.
security-block-downloads =
    .label = احجب التنزيلات الخطيرة
    .accesskey = ت
security-block-uncommon-software =
    .label = حذرني من البرمجيات غير المرغوب فيها و غير الشائعة
    .accesskey = غ

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = اسمح بأن يثق { -brand-short-name } تلقائيا بشهادات جذر من أطراف خارجية تقوم بتثبيتها
    .accesskey = ه
certs-devices-enable-fips = مكّن FIPS
space-alert-over-5gb-settings-button =
    .label = افتح الإعدادات
    .accesskey = ف
space-alert-over-5gb-message2 = <strong>مساحة القرص قاربت على النفاذ من { -brand-short-name }</strong>. قد لا يُعرض محتوى المواقع كما ينبغي. يمكنك مسح البيانات المحفوظة من ”الإعدادات ← الخصوصية والأمان ← الكعكات وبيانات المواقع“.
space-alert-under-5gb-message2 = <strong>مساحة القرص قاربت على النفاذ من { -brand-short-name }</strong>. قد لا يُعرض محتوى المواقع كما ينبغي. انتقل إلى ”اطّلع على المزيد“ لتحسين استخدام القرص لتصفح أحسن.
certs-description3 =
    .description = اضبط الشهادات التي يستخدمها { -brand-short-name } للتحقق من الاتصالات الآمنة.
    .label = الشهادات
certs-view2 =
    .label = أدر الشهادات
    .accesskey = د
certs-devices2 =
    .label = أدر أجهزة الأمان
    .accesskey = د

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = كيف يعمل HTTPS-Only
httpsonly-radio-enabled =
    .label = فعّل وضع HTTPS فقط في كل النوافذ
httpsonly-radio-enabled-pbm =
    .label = فعّل وضع HTTPS فقط في النوافذ الخاصة فقط
httpsonly-radio-disabled3 =
    .description = قد لا يزال { -brand-short-name } يرقي بعض الاتصالات
    .label = لا تفعّل وضع HTTPS فقط
httpsonly-group =
    .description = يسمح فقط بالاتصالات الآمنة بمواقع الوب. سيسأل { -brand-short-name } قبل الاتصال بشكل غير آمن.
    .label = وضع HTTPS فقط
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS عبر HTTPS
dns-over-https-group2 =
    .description = يقوم نظام أسماء النطاقات عبر بروتوكول HTTPS (DoH) بتعمية عمليات البحث عن المواقع، مما يجعل من الصعب على مزود خدمة الإنترنت الخاص بك أو غيره معرفة المواقع التي تنوي زيارتها.
    .label = DNS عبر HTTPS
preferences-doh-description2 = يرسل نظام اسم المجال (DNS) عبر HTTPS طلبك للحصول على اسم مجال من خلال اتصال مُعمّى، مما يوفر DNS آمنًا ويجعل من الصعب على الآخرين رؤية موقع الوب الذي أنت على وشك الوصول إليه.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = الحالة: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = المزود: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = مسار غير صحيح
preferences-doh-steering-status = استخدام مزود محلي
preferences-doh-status-active = نشط
preferences-doh-status-disabled = معطّل
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = غير نشط ({ $reason })
preferences-doh-group-message2 = فعّل DNS عبر HTTPS باستخدام:
preferences-doh-radio-group =
    .aria-label = فعّل DNS عبر HTTPS باستخدام:
preferences-doh-expand-section =
    .tooltiptext = مزيد من المعلومات
preferences-doh-setting-default =
    .label = الحماية المبدئية
    .accesskey = ي
preferences-doh-default-desc = يقرر { -brand-short-name } متى يستخدم DNS آمن لحماية خصوصيتك.
preferences-doh-default-detailed-desc-1 = أستخدم DNS آمن في المناطق التي تكون فيها متاحة
preferences-doh-default-detailed-desc-2 = أستخدم محلل DNS المبدئي إذا كان هناك مشكلة مع مزود DNS الآمن
preferences-doh-default-detailed-desc-3 = استخدم مزودًا محليًا، إن أمكن
preferences-doh-default-detailed-desc-4 = أوقف التشغيل عند تفعيل VPN أو الرقابة الأبوية أو سياسات المؤسسة
preferences-doh-default-detailed-desc-5 = عطله عندما تخبر الشبكة { -brand-short-name } بأنه لا يجب أن تستخدم DNS آمن
preferences-doh-setting-enabled =
    .label = حماية متزايدة
    .accesskey = ة
preferences-doh-enabled-desc = يمكنك التحكم في الوقت الذي تستخدم فيه DNS آمن و إختيار مزودك.
preferences-doh-enabled-detailed-desc-1 = استخدم المزود الذي تحدده
preferences-doh-enabled-detailed-desc-2 = أستخدم فقط محلل DNS المبدئي إذا كانت هناك مشكلة مع DNS آمن
preferences-doh-setting-strict =
    .label = أقصى حماية
    .accesskey = ح
preferences-doh-strict-desc = سيستخدم { -brand-short-name } دائمًا DNS آمن. سترى تحذير خطر أمني قبل أن نستخدم نظام DNS الخاص بك.
preferences-doh-strict-detailed-desc-1 = استخدم فقط المزود الذي تحدده
preferences-doh-strict-detailed-desc-2 = حذّر دائمًا إذا كان DNS الآمن غير متاح
preferences-doh-strict-detailed-desc-3 = إذا لم يكن DNS الآمن متاحًا، فلن تتحمل المواقع أو تعمل كما ينبغي
preferences-doh-setting-off =
    .label = معطّل
    .accesskey = ط
preferences-doh-off-desc = استخدم محلّل DNS المبدئي الخاص بك
preferences-doh-select-resolver = اختر المزود:
preferences-doh-manage-exceptions =
    .label = أدر الاستثناءات…
    .accesskey = د
preferences-doh-overview-default =
    .description = استخدم DNS الآمن في المناطق التي يتوفر فيها.
    .label = الحماية المبدئية
preferences-doh-overview-custom =
    .description = استخدم دائمًا DNS آمنًا مع التحكم في مزود الخدمة وسلوك التراجع.
    .label = مخصّص
preferences-doh-overview-off =
    .description = استخدم مُحلّل DNS المبدئي الخاص بك.
    .label = معطّل
preferences-doh-advanced-button =
    .label = إعدادات متقدّمة
preferences-doh-advanced-section =
    .description = يقوم نظام أسماء النطاقات عبر بروتوكول HTTPS (DoH) بتعمية عمليات البحث عن المواقع، مما يجعل من الصعب على مزود خدمة الإنترنت الخاص بك أو غيره معرفة المواقع التي تنوي زيارتها.
    .label = إعدادات متقدّمة
preferences-doh-manage-exceptions2 =
    .label = أدر الاستثناءات
    .accesskey = د
preferences-doh-radio-default =
    .description = استخدم DNS الآمن في المناطق التي يتوفر فيها.
    .label = المبدئي
preferences-doh-radio-custom =
    .description = استخدم DNS الآمن في المناطق التي يتوفر فيها.
    .label = مخصّص
preferences-doh-radio-off =
    .description = استخدم مُحلّل DNS المبدئي الخاص بك
    .label = معطّل
preferences-doh-fallback-label =
    .label = أبلغني دائمًا إذا لم يكن DNS الآمن متاحًا
preferences-doh-status-item-off =
    .message = DNS عبر HTTPS مُعطّل
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = لا يعمل DNS عبر HTTPS بسبب حدوث خطأ ({ $reason }) أثناء محاولة استخدام المزود { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = لا يعمل DNS عبر HTTPS لأننا تلقينا عنوان URL غير صالح ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = يستخدم DNS عبر HTTPS المزود { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = لا يعمل DNS عبر HTTPS بسبب حدوث خطأ ({ $reason }) أثناء محاولة استخدام المزود المحلي { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = يستخدم DNS عبر HTTPS المزود المحلي { $name }
preferences-doh-select-resolver-label =
    .label = اختر المزود:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = استخدم هذا المزود لتحليل DNS عبر HTTPS
preferences-doh-custom-provider-label =
    .aria-label = أدخل عنوان URL مخصصًا لمزود الخدمة
preferences-doh-header2 =
    .heading = DNS عبر HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = أمان الاتصال والبرمجيات
preferences-connection-link-section =
    .description = تعرّف على كيفية الحفاظ على أمان الاتصالات وحظر البرامج الضارة والتحقق من صحة المواقع الإلكترونية.
    .label = أمان الاتصال والبرمجيات
preferences-connection-link-button =
    .label = إعدادات متقدّمة

## The following strings are used in the Download section of settings

desktop-folder-name = سطح المكتب
downloads-folder-name = التّنزيلات

## Appearance page

preferences-appearance-header =
    .heading = المظهر
browser-theme-group =
    .description = صمّم { -brand-short-name } بأسلوبك الخاص. تُطبّق ألوان السمة على أشرطة الأدوات والقوائم والرسائل.
    .label = سمة المتصفح
browser-theme-manage-link =
    .label = أدِر سمات { -brand-short-name }
appearance-window-density-group =
    .description = اضبط التباعد حول عناصر النافذة مثل شريط الأدوات والعلامات والشريط الجانبي.
    .label = كثافة النوافذ
appearance-window-density-radio-group =
    .aria-label = كثافة النوافذ
appearance-window-density-automatic =
    .description = يُطبّق التباعد القياسي أو المضغوط أو التباعد باللمس تلقائيًا
    .label = تلقائي (المبدئي)
appearance-window-density-automatic-no-touch =
    .description = يُطبّق التباعد القياسي أو المضغوط تلقائيًا
    .label = تلقائي (المبدئي)
appearance-window-density-standard =
    .description = تباعد متوازن لمعظم الشاشات
    .label = قياسي
appearance-window-density-auto-touch-mode =
    .label = استخدم تباعد اللمس لوضع الجهاز اللوحي
appearance-window-density-compact =
    .description = تقليل المسافات بين الأحرف لتناسب الشاشات الأصغر حجمًا
    .label = مضغوط
appearance-window-density-touch =
    .description = عناصر النوافذ وأهداف النقر الأكبر حجمًا، المُحسَّنة للاستخدام مع الشاشات التي تعمل باللمس
    .label = لمس
related-settings-group =
    .label = الإعدادات ذات الصلة
related-settings-accessibility-link =
    .label = خصّص إعدادات التقريب وتبعيد والخط في قسم الإتاحة
related-settings-home-link =
    .label = خصّص { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = خصّص تخطيط المتصفح

## AI controls page

preferences-ai-controls-description = لديك دائمًا خيار في { -brand-short-name }، بما في ذلك ما إذا كنت ترغب في استخدام الميزات المحسّنة بالذكاء الاصطناعي. المزيد من عناصر التحكم قادمة قريبًا.
preferences-ai-controls-block-ai-label = احظر تحسينات الذكاء الاصطناعي
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = يعني الحظر أنك لن ترى تحسينات الذكاء الاصطناعي الجديدة أو الحالية في { -brand-short-name }، أو النوافذ المنبثقة المتعلقة بها. <a data-l10n-name="link">للحصول على مزيد من التفاصيل</a> حول ما هو مُضمّن وكيفية التحكم في ميزات التعلّم الآلي التقليدية، مثل اقتراحات البحث والتوصيات.
preferences-ai-controls-blocked-message =
    .message = تُحظر التحسينات الجديدة والحالية للذكاء الاصطناعي مبدئيًا. لإلغاء حظر ميزة معينة، استخدم عناصر التحكم أدناه.
preferences-ai-controls-on-device-group =
    .description = تستخدم هذه الميزات نماذج ذكاء اصطناعي صغيرة تُنزّل على جهازك عند استخدامها. ويساعد هذا النهج في حماية خصوصيتك.
    .label = الذكاء الاصطناعي على الجهاز
preferences-ai-controls-translations-control =
    .description = تصفح الوِب بسهولة في لغتك المفضلة.
    .label = الترجمات
preferences-ai-controls-translations-more-link = المزيد من إعدادات الترجمة
preferences-ai-controls-pdfjs-control =
    .description = عند إضافة صور إلى PDF، يضيف هذا أوصافًا لجعلها ميسرة للوصول.
    .label = نص بديل للصورة في عارض PDF { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = احصل على اقتراحات لتسمية ألسنتك وتنظيمها.
    .label = اقتراحات مجموعة اللسان
preferences-ai-controls-key-points-control =
    .description = اطّلع على ملخص سريع قبل فتح أي رابط.
    .label = أهم النقاط في معاينات الروابط
preferences-ai-controls-speech-recognition-control =
    .description = حوِّل الكلام لنص محليًا.
    .label = التعرُف على الكلام
preferences-ai-controls-sidebar-chatbot-group =
    .description = أبقِ روبوت الدردشة أمامك أثناء التصفح. اختر من بين Anthropic Claude وChatGPT وCopilot وGoogle Gemini وLe Chat Mistral.
    .label = مزودي برامج الدردشة الآلية المدعومة بالذكاء الاصطناعي في الشريط الجانبي
preferences-ai-controls-sidebar-chatbot-control =
    .label = آلي الدردشة في الشريط الجانبي
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = متاح
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = مفعّل
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = محجوب
preferences-ai-controls-state-description-before = معنى الخيارات:
preferences-ai-controls-state-description-available = <strong>متاح:</strong> سترى الميزة ويمكنك استخدامها.
preferences-ai-controls-state-description-enabled = <strong>مفعّل:</strong> لقد اخترت استخدام هذه الميزة.
preferences-ai-controls-state-description-blocked = <strong>محجوب:</strong> لن تتمكن من رؤية هذه الميزة أو استخدامها. بالنسبة للذكاء الاصطناعي المُثبّت على الجهاز، ستتم إزالة أي نماذج نُزلت مسبقًا.
preferences-ai-controls-block-confirmation-heading = احظر تحسينات الذكاء الاصطناعي؟
preferences-ai-controls-block-confirmation-description = لن ترى أي تحسينات جديدة أو حالية للذكاء الاصطناعي في { -brand-short-name }، أو أي نوافذ منبثقة بشأنها. بعد ذلك، يمكنك إلغاء حظر أي شيء ترغب في الاستمرار باستخدامه.
preferences-ai-controls-block-confirmation-features-start = ما الذي سيُحظر:
preferences-ai-controls-block-confirmation-translations = الترجمات
preferences-ai-controls-block-confirmation-pdfjs = نص بديل للصورة في عارض ملفات PDF { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = اقتراحات مجموعات اللسان
preferences-ai-controls-block-confirmation-key-points = أهم النقاط في معاينات الروابط
preferences-ai-controls-block-confirmation-sidebar-chatbot = مزودي برامج الدردشة الآلية في الشريط الجانبي
preferences-ai-controls-block-confirmation-speech-recognition = التعرُف على الكلام
preferences-ai-controls-block-confirmation-features-after = يؤثر الحظر أيضًا على الإمتدادات التي تستخدم الذكاء الاصطناعي المقدم من { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = ألغِ
preferences-ai-controls-block-confirmation-confirm =
    .label = احجب
preferences-ai-controls-header3 =
    .heading = أنظمة التحكم بالذكاء الاصطناعي

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } على الحراسة
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } يوصي ببعض التحسينات الأمنية
security-privacy-status-ok-label = الحماية الموسّعة من التعقب مفعّلة
security-privacy-status-problem-label = لقد وجدنا إعدادات تؤثر على حمايتك
security-privacy-status-problem-helper-label = اعرض المشكلات
security-privacy-status-pending-trackers-label = البحث عن عدد المتعقبات التي حظرتها { -brand-short-name } خلال الشهر الماضي
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = لديك <a data-l10n-name="strict-tracking-protection">حماية صارمة</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = لديك <a data-l10n-name="custom-tracking-protection">حماية مخصّصة</a>
security-privacy-status-up-to-date-label = لديك أحدث وأكثر إصدارات { -brand-short-name } أمانًا
security-privacy-status-update-needed-label = يتوفر إصدار جديد من { -brand-short-name } .
security-privacy-status-update-error-label = { -brand-short-name } يواجه مشكلة في تحديث نفسه
security-privacy-status-update-checking-label = { -brand-short-name } يتحقق من وجود تحديثات
security-privacy-status-update-needed-description = حدِّث للحصول على أحدث التحديثات المتعلقة بالسرعة والاستقرار والأمان.
security-privacy-status-update-button-label =
    .label = حدِّث { -brand-short-name }
security-privacy-image-warning =
    .alt = درع عليه علامة تعجب، يعبر عن القلق بشأن تحذيراتك الأمنية
security-privacy-image-ok =
    .alt = درع عليه علامة صح، مما يدل على عدم وجود أي مشكلات أمنية عالقة.
security-privacy-issue-card =
    .heading = تحذيرات أمنية
issue-card-reset-button =
    .label = صفّر
issue-card-dismiss-button =
    .aria-label = أهمِل
    .tooltiptext = أهمِل

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = تستخدم المواقع الإلكترونية متعقبات لملاحقتك عبر الإنترنت وعرض إعلانات مزعجة. يحميك { -brand-short-name } أثناء التصفح، حيث يحظر المتعقبات تلقائيًا لتظل أنت المتحكم في أثرك الرقمي.
    .label = الحماية الموسّعة من التعقب
preferences-etp-level-radio-group =
    .aria-label = الحماية الموسّعة من التعقب
preferences-etp-level-standard =
    .description = حماية قوية وموثوقة تعمل بسلاسة مع معظم المواقع الإلكترونية.
    .label = قياسي (المبدئي)
preferences-etp-level-strict =
    .description = حماية أقوى تحظر المزيد من أدوات التتبع، ولكنها قد تؤدي إلى تعطّل بعض المواقع.
    .label = صارم
preferences-etp-level-custom =
    .description = اختر الحمايات التي تريد تفعيلها أو إيقافها.
    .label = مخصّص
preferences-etp-status-advanced-button =
    .label = إعدادات متقدّمة
preferences-etp-tracker-count-enabled =
    .label = اعرض عدد المتعقّبات المحظورة في شريط العناوين
preferences-etp-status-protections-dashboard-link =
    .description = اكتشف عدد أدوات التتبع الخفية التي حظرها { -brand-short-name } من أجلك، بما في ذلك أدوات تتبع وسائل التواصل الاجتماعي وأدوات البصمة الرقمية وبرمجيات تعدين العملات الرقمية.
    .label = اطّلع على لوحة معلومات الحماية الشخصية الخاصة بك
preferences-etp-header =
    .heading = الحماية الموسّعة من التعقب
preferences-etp-advanced-settings-group =
    .description = تستخدم المواقع الإلكترونية أدوات تتبع لملاحقتك عبر الإنترنت وعرض إعلانات مزعجة. يحميك { -brand-short-name } أثناء التصفح، حيث يحجب معظم أدوات التتبع تلقائيًا لتظل أنت المتحكم في أثرك الرقمي.
    .label = إعدادات متقدّمة
preferences-etp-customize-button =
    .label = خصّص حماية التعقب
preferences-etp-reload-tabs-hint =
    .message = أعد تحميل ألسنتك لتطبيق هذه التغييرات.
preferences-etp-reload-tabs-hint-button =
    .label = أعِد تحميل كل الألسنة
preferences-etp-rfp-warning-message =
    .message = أنت تستخدم ميزة Resist Fingerprinting (RFP)، والتي تحل محل بعض إعدادات حماية التبصيم في { -brand-short-name }. قد يتسبب هذا في تعطل بعض المواقع.
preferences-etp-level-warning-message =
    .heading = تنبيه! قد لا تعمل بعض المواقع كما هو متوقع.
    .message = تدمج بعض المواقع أدوات تتبع في ميزاتها أو محتواها. وعندما يحظرها { -brand-short-name }، قد يبدو الموقع معطوبًا. جرّب استخدام "أصلح مشاكل الموقع" أو أوقِف تشغيل الحماية من التتبع في ذلك الموقع.
preferences-etp-manage-exceptions-button =
    .description = إدارة المواقع الإلكترونية التي تم تعطيل "الحماية الموسّعة من التعقب" فيها.
    .label = أدر الاستثناءات
preferences-etp-customize-header =
    .heading = خصّص حماية التعقب
preferences-etp-reset =
    .description = استعادة الإعدادات إلى مستوى حماية مسبق الضبط.
    .label = صفّر ضبط التخصيصات
preferences-etp-reset-standard-button =
    .label = صفّر إلى قياسي
preferences-etp-reset-strict-button =
    .label = صفّر إلى صارم
preferences-etp-custom-control-group =
    .description = اختر الحمايات التي تريد تفعيلها أو إيقافها.
    .label = حماية التعقب
preferences-etp-custom-cookies-enabled =
    .label = ملفات تعريف الارتباط
preferences-etp-custom-cookie-behavior =
    .aria-label = ملفات تعريف الارتباط
preferences-etp-custom-cookie-behavior-accept-all =
    .label = اسمح بجميع ملفات تعريف الارتباط
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = احظر الكعكات التي تتعقّبك بين المواقع
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = احجب ملفات تعريف الإرتباط بين المواقع
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = اعزل ملفات تعريف الارتباط بين المواقع
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = احظر ملفات تعريف الارتباط من المواقع الإلكترونية التي لم تزورها
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = احظر جميع ملفات تعريف الارتباط عبر المواقع (قد يؤدي ذلك إلى تعطل المواقع الإلكترونية)
preferences-etp-custom-cookie-behavior-block-all =
    .label = احجب كل الكعكات (قد يتسبب بعطب المواقع)
preferences-etp-custom-tracking-protection-enabled =
    .label = محتوى التعقّب
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = محتوى التعقّب
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = المُعدّنات المعمّاة
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = المسجّلات المعروفة
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = المسجّلات المشتبه بها
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = المسجّلات المشتبه بها

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = قد يسمح هذا لبعض المتقعبات بملاحقتك دون استخدام ملفات تعريف الارتباط.
    .label = لا يُحظر المسجّلات المعروفة
security-privacy-issue-warning-third-party-cookies =
    .description = تُستخدم ملفات تعريف الارتباط التابعة لجهات خارجية لتتبعك عبر المواقع الإلكترونية.
    .label = ملفات تعريف الارتباط الخاصة بالجهات الخارجية مُفعّلة
security-privacy-issue-warning-password-manager =
    .description = تُساعدك برامج إدارة كلمات السر على تخزين كلمات سر قوية لحساباتك.
    .label = مدير كلمات السر مُعطّل
security-privacy-issue-warning-popup-blocker =
    .description = النوافذ المنبثقة مزعجة وقد تكون ضارة.
    .label = مانع النوافذ المنبثقة مُعطّل
security-privacy-issue-warning-extension-install =
    .description = يمكن للمواقع الإلكترونية تثبيت امتدادات إلى { -brand-short-name } دون سؤال.
    .label = يمكن للمواقع الإلكترونية تثبيت امتدادات.
security-privacy-issue-warning-safe-browsing =
    .description = تزداد احتمالية تعرضك لعمليات الاحتيال والبرمجيات الخبيثة من المواقع الإلكترونية.
    .label = لا يُحظر المحتوى الخطير والمضلل
security-privacy-issue-warning-doh2 =
    .description = تساعد تقنية DNS عبر HTTPS على إخفاء المواقع التي ستزورها عن مزود خدمة الإنترنت الخاص بك.
    .label = DNS عبر HTTPS مُعطّل
security-privacy-issue-warning-ech2 =
    .description = تساعد خدمة "Encrypted Client Hello" في إخفاء المواقع التي ستزورها عن مزود خدمة شبكتك.
    .label = Encrypted Client Hello مُعطّل
security-privacy-issue-warning-doh =
    .description = تخفي DNS عبر HTTPS المواقع التي تزورها عن مزود خدمة الشبكة الخاص بك.
    .label = DNS عبر HTTPS مُعطّل
security-privacy-issue-warning-ech =
    .description = تعمل ميزة Encrypted Client Hello على إخفاء المواقع التي تزورها عن مزود خدمة الشبكة الخاص بك.
    .label = Encrypted Client Hello مُعطّل
security-privacy-issue-warning-proxy-autodetection =
    .description = قد التضيبط التلقائي للوسيط للشبكات غير الموثوقة بمراقبة نشاطك.
    .label = فُعِّل التضيبط التلقائي للوسيط

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = ادعُ شخصًا ما لاختيار المتصفح الذي يضع الخصوصية في المقام الأول.
    .label = شارك { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = شارك { -brand-product-name }


pane-vorbit-title = vOrbit-lite
vorbit-warning-description = قمنا باختيار الإعدادات الافتراضية بعناية للتركيز على الخصوصية والأمان. عندما تقوم بتغيير هذه الإعدادات، يرجى قراءة وصف كل إعداد بدقة لتفهم تَبِعات تغييراتك.
vorbit-header = تفضيلات vOrbit-lite
vorbit-warning-title = انتبه!
vorbit-general-heading = سلوك المتصفح
vorbit-extension-update-checkbox =
    .label = قم بتحديث الإضافات تلقائيًا
vorbit-sync-checkbox =
    .label = فعِّل مزامنة FireFox
vorbit-autocopy-checkbox =
    .label = فعِّل لصق النص باستخدام زر الفأرة الأوسط
vorbit-styling-checkbox =
    .label = السماح بالتخصيص باستخدام userChrome.css
vorbit-network-heading = الشبكة
vorbit-ipv6-checkbox =
    .label = تفعيل IPv6
vorbit-privacy-heading = الخصوصية
vorbit-xorigin-ref-checkbox =
    .label = تقييد الإحالة من مواقع أخرى (cross-origin referrers)
vorbit-broken-heading = بصمة المتصفح
vorbit-webgl-checkbox =
    .label = فعِّل WebGL
vorbit-rfp-checkbox =
    .label = فعِّل ResistFingerprinting
vorbit-security-heading = اﻷمان
vorbit-ocsp-checkbox =
    .label = قم برفض الاتصال إذا تعذر التحقق من صلاحية الشهادة (OCSP hard-fail)
vorbit-goog-safe-checkbox =
    .label = فعِّل التصفح الآمن من Google
vorbit-extension-update-warning1 = إن كنت لا تقوم بمراجعة الكود البرمجي للإضافات الخاصة بك قبل كل تحديث، يُستحسن تفعيل هذا الخيار.
vorbit-ipv6-description = السماح لـ{ -brand-short-name } بالاتصال بالإنترنت باستخدام IPv6.
vorbit-ipv6-warning1 = عوضًا عن تعطيل IPv6 في المتصفح، ننصح بتفعيل خاصية الخصوصية لـIPv6 في إعدادات نظام التشغيل الخاص بك.
vorbit-ocsp-warning1 = يعززهذا الخيار الأمان بشكل كبير، لكن سيتسبب في أعطال إذا تعذر الوصول لخادم التحقق (OCSP).
vorbit-sync-description = زامِن بياناتك مع متصفحات أخرى. يتطلب إعادة التشغيل.
vorbit-autocopy-description = حدّد جزءً من النص لنسخه، ومن ثم استخدم زر الفأرة الأوسط للصق النص.
vorbit-styling-description = فعِّل هذا الخيار إذا كنت ترغب في تخصيص واجهة المستخدم باستخدام مظهر مُحَمّل يدويًا.
category-vorbit =
    .tooltiptext = تغييرات about:config، منظمة بشكل منطقي وسهلة الوصول
vorbit-extension-update-description = دع المتصفح يحدّث الإضافات تلقائيًا دون الحاجة إلى أي إجراء منك. خيار مناسب لتعزيز أمانك.
vorbit-ocsp-description = َيمنع الاتصال بموقعٍ ما إذا تعذر التحقق من صلاحية شهادته باستخدام OCSP.
vorbit-goog-safe-download-checkbox =
    .label = افحص التنزيلات
vorbit-letterboxing-checkbox =
    .label = فعِّل تقنية إخفاء أبعاد المتصفح (letterboxing)
vorbit-styling-warning1 = تأكد من أنك تثق بمصدر المظهر الذي قمت بتحميله.
vorbit-sync-warning1 = تُشفّر مزامنة FireFox بياناتك محليًا قبل إرسالها إلى الخادم.
vorbit-xorigin-ref-description = إرسال المُحِيل فقط عند الاتصال من نفس المصدر (same-origin).
vorbit-webgl-description = WebGL يُعد وسيلة قوية لجمع بصمات المتصفح، التي قد تُستخدم في تحديد هويتك.
vorbit-rfp-description = ResistFingerprinting هي الأداة الأفضل من نوعها للحد من تتبع بصمات المتصفح.
vorbit-rfp-warning1 = إن كنت تحتاج لتعطيلها، يوصى باستخدام إضافة متصفح مثل Canvas Blocker للحد من تتبع بصمة المتصفح.
vorbit-goog-safe-description = إن كنت قلقًا بشأن البرمجيات الخبيثة او التصيّد الإلكتروني، يُوصى بتفعيل هذا الخيار.
vorbit-goog-safe-warning1 = هذا الخيار مُعطّل بشكل افتراضي لتجنب الرقابة، لكن يُنصح بتفعيله للمستخدمين غير المتمرسين. جميع الفحوصأت تُجرى محليًّا.
vorbit-goog-safe-download-warning1 = جميع الفحوصات تُجرى محليًّا.
vorbit-footer = روابط مفيدة
vorbit-config-link = جميع الإعدادات المتقدمة (about:config)
vorbit-open-profile = افتح مجلد الملف التعريفي للمستخدم
content-blocking-section-top-level-description = يدعم vOrbit-lite -و يُفعِّل بشكل افتراضي- ميزة الحماية المعززة من التتبع في الوضع الصارم. والذي يعتبر واحدًا من أهم الإعدادات في المتصفح، كونه يوفر تقسيم الحالة (state partitioning)، وقوائم حظر صارمة، وميِّزات أخرى لتعزيز الخصوصية. لا ننصح بتغيير هذا الوضع إلى أي من الأوضاع الأخرى.
vorbit-webgl-warning1 = إن كنت تحتاج لتفعليها، يوصى باستخدام إضافة متصفح مثل Canvas Blocker للحد من تتبع بصمة المتصفح.
vorbit-letterboxing-description = تقوم تقنية الـLetterboxing بإضافة هوامش حول نافذة المتصفح لتغيير أبعادها وجعلها تبدو ضمن مجموعة محدودة من القياسات الموحَّدة، مما يُصَعِّب على المواقع التعرف عليك بناءً على حجم شاشتك.
vorbit-goog-safe-download-description = السماح لخدمة التصفح الآمن من Google بفحص تنزيلاتك لكشف الملفات المشبوهة أو الضارة.
vorbit-xorigin-ref-warning1 = قد يتسبب في أعطال. بالإضافة إلى أنه سيتم تقليم الإحالات عند الإرسال على أي حال.
