# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 45em
    .title = Ngoại lệ
permissions-close-key =
    .key = w
permissions-address = Địa chỉ của trang web
    .accesskey = d
permissions-block =
    .label = Chặn
    .accesskey = C
permissions-disable-etp =
    .label = Thêm ngoại lệ
    .accesskey = E
permissions-session =
    .label = Cho phép theo phiên
    .accesskey = S
permissions-allow =
    .label = Cho phép
    .accesskey = h
permissions-add =
    .label = Thêm
    .accesskey = A
permissions-button-off =
    .label = Tắt
    .accesskey = O
permissions-button-off-temporarily =
    .label = Tắt tạm thời
    .accesskey = T
permissions-site-name =
    .label = Trang web
permissions-status =
    .label = Trạng thái
permissions-remove =
    .label = Xóa trang web
    .accesskey = R
permissions-remove-all =
    .label = Xóa tất cả các trang web
    .accesskey = e
permissions-save-changes-2 =
    .buttonlabelaccept = Lưu thay đổi
    .buttonaccesskeyaccept = L
permission-dialog =
    .buttonlabelaccept = Lưu thay đổi
    .buttonaccesskeyaccept = L
permissions-autoplay-menu = Mặc định cho tất cả các trang web:
permissions-searchbox =
    .placeholder = Tìm kiếm trang web
permissions-capabilities-autoplay-allow =
    .label = Cho phép âm thanh và video
permissions-capabilities-autoplay-block =
    .label = Chặn âm thanh
permissions-capabilities-autoplay-blockall =
    .label = Chặn âm thanh và video
permissions-capabilities-allow =
    .label = Cho phép
permissions-capabilities-block =
    .label = Chặn
permissions-capabilities-prompt =
    .label = Luôn hỏi
permissions-capabilities-listitem-allow =
    .value = Cho phép
permissions-capabilities-listitem-block =
    .value = Chặn
permissions-capabilities-listitem-allow-session =
    .value = Cho phép theo phiên
permissions-capabilities-listitem-off =
    .value = Tắt
permissions-capabilities-listitem-off-temporarily =
    .value = Tắt tạm thời

## Invalid Hostname Dialog

permissions-invalid-uri-title = Nhập sai tên máy chủ
permissions-invalid-uri-label = Hãy nhập một tên máy chủ có thực

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Các ngoại lệ cho trình chống theo dõi nâng cao
permissions-exceptions-manage-etp-desc = Bạn có thể chỉ định các trang web nào sẽ tắt Trình chống theo dõi nâng cao. Nhập địa chỉ chính xác của trang web mà bạn muốn quản lý, sau đó nhấp vào "Thêm ngoại lệ".

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Ngoại lệ - Cookie và dữ liệu trang web
permissions-exceptions-cookie-desc = Bạn có thể chỉ định trang web nào luôn hoặc không bao giờ được phép sử dụng cookie và dữ liệu trang web. Nhập địa chỉ chính xác của trang web bạn muốn quản lý và sau đó nhấp vào Chặn, Chỉ cho phép với phiên này hoặc Cho phép.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Ngoại lệ - Xóa lịch sử khi tắt trình duyệt
permissions-exceptions-shutdown-clearing-desc = Bạn có thể chỉ định những trang web nào sẽ giữ lại dữ liệu khi { -brand-short-name } xóa lịch sử lúc đóng ứng dụng. Nhập địa chỉ chính xác của trang web bạn muốn quản lý rồi nhấp vào Cho phép.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Ngoại lệ - Chế độ chỉ HTTPS
permissions-exceptions-https-only-desc2 = Bạn có thể tắt Chế độ chỉ HTTPS cho các trang web cụ thể. { -brand-short-name } sẽ không nâng cấp kết nối để bảo mật HTTPS cho các trang web đó.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Các trang web được phép - Cửa sổ bật lên và chuyển hướng của bên thứ ba
permissions-exceptions-popup-desc2 = Bạn có thể chỉ định trang web nào được phép mở cửa sổ bật lên và được chuyển hướng bởi frame của bên thứ ba.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Ngoại lệ - Mật khẩu đã lưu
permissions-exceptions-saved-passwords-desc = { -brand-short-name } sẽ không lưu mật khẩu cho các trang được liệt kê ở đây.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Những trang được cho phép - Cài đặt tiện ích
permissions-exceptions-addons-desc = Bạn có thể chỉ định trang web nào được phép cài tiện ích. Gõ chính xác địa chỉ trang bạn muốn cho phép và sau đó nhấp Cho phép.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Tự động phát
permissions-site-autoplay-desc = Bạn có thể quản lý các trang web không tuân theo cài đặt tự động phát mặc định của bạn tại đây.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền thông báo
permissions-site-notification-desc = Các trang web dưới đây đã yêu cầu để gửi thông báo tới bạn. Bạn có thể chỉ định những trang web nào được phép gửi bạn thông báo. Bạn cũng có thể chặn những yêu cầu mà bạn không muốn cho phép.
permissions-site-notification-disable-label =
    .label = Chặn các yêu cầu mới về việc cho phép gửi thông báo
permissions-site-notification-disable-desc = Điều này sẽ ngăn chặn bất cứ trang web nào không được liệt kê ở trên gửi yêu cầu cho phép việc gửi thông báo. Chặn thông báo có thể ảnh hưởng đến một số tính năng trang web.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Cho phép nhận thông báo trên trang web khi đóng { -brand-short-name }
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Các cài đặt thông báo của hệ điều hành của bạn cũng được áp dụng.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền truy cập vị trí
permissions-site-location-desc = Các trang web dưới đây đã yêu cầu quyền truy cập vị trí của bạn. Bạn có thể chỉ định những trang web nào được phép truy cập vị trí của bạn. Bạn cũng có thể chặn các yêu cầu mới về việc xin cấp quyền truy cập vị trí.
permissions-site-location-disable-label =
    .label = Chặn các yêu cầu mới về việc cho phép tru cập vị trí của bạn
permissions-site-location-disable-desc = Điều này sẽ ngăn chặn bất cứ trang web nào không được liệt kê ở trên gửi yêu cầu cho phép việc truy cập vị trí của bạn. Chặn thông báo có thể ảnh hưởng đến một số tính năng trang web.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền thực tế ảo
permissions-site-xr-desc = Các trang web sau đây đã yêu cầu truy cập các thiết bị thực tế ảo của bạn. Bạn có thể chỉ định trang web nào được phép truy cập các thiết bị thực tế ảo của mình. Bạn cũng có thể chặn các yêu cầu mới mà nó yêu cầu truy cập các thiết bị thực tế ảo của mình.
permissions-site-xr-disable-label =
    .label = Chặn các yêu cầu mới mà nó yêu cầu truy cập các thiết bị thực tế ảo của bạn
permissions-site-xr-disable-desc = Điều này sẽ ngăn mọi trang web không được liệt kê ở trên yêu cầu quyền truy cập vào các thiết bị thực tế ảo của bạn. Chặn quyền truy cập vào các thiết bị thực tế ảo của bạn có thể phá vỡ một số tính năng của trang web.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Cài đặt - Các trang web bị chặn đối với liên kết trong ứng dụng
permissions-site-app-links-desc = Các trang web này bị chặn không cho yêu cầu mở liên kết trong ứng dụng, chẳng hạn như email (mailto:). Hãy xoá một trang web để cho phép nó yêu cầu lại.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền sử dụng máy quay
permissions-site-camera-desc = Các trang web dưới đây đã yêu cầu quyền truy cập máy ảnh của bạn. Bạn có thể chỉ định những trang web nào được phép truy cập máy ảnh của bạn. Bạn cũng có thể chặn các yêu cầu mới về việc xin cấp quyền truy cập máy ảnh của bạn.
permissions-site-camera-disable-label =
    .label = Chặn các yêu cầu mới về việc cho phép tru cập máy ảnh của bạn
permissions-site-camera-disable-desc = Điều này sẽ ngăn chặn bất cứ trang web nào không được liệt kê ở trên gửi yêu cầu cho phép việc truy cập máy ảnh của bạn. Chặn thông báo có thể ảnh hưởng đến một số tính năng trang web.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Cài đặt - Ứng dụng và dịch vụ thiết bị
permissions-site-localhost-desc = Các trang web này đã yêu cầu quyền truy cập vào các ứng dụng và dịch vụ trên thiết bị này. Bạn có thể chọn cho phép hoặc chặn các trang web thực hiện việc này.
permissions-site-localhost-disable-label =
    .label = Chặn các yêu cầu mới truy cập vào ứng dụng và dịch vụ trên thiết bị này
permissions-site-localhost-disable-desc = Thao tác này sẽ ngăn bất kỳ trang web nào không được liệt kê ở trên yêu cầu quyền truy cập vào các ứng dụng và dịch vụ trên thiết bị này. Thao tác này có thể làm hỏng một số tính năng của trang web.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Cài đặt - Thiết bị mạng cục bộ
permissions-site-local-network-desc = Các trang web này đã yêu cầu quyền truy cập vào các ứng dụng và dịch vụ trên thiết bị được kết nối với Wi-Fi hoặc mạng cục bộ của bạn. Bạn có thể chọn cho phép hoặc chặn các trang web thực hiện việc này.
permissions-site-local-network-disable-label =
    .label = Chặn các yêu cầu mới truy cập ứng dụng và dịch vụ trên các thiết bị được kết nối với Wi-Fi hoặc mạng cục bộ của bạn.
permissions-site-local-network-disable-desc = Thao tác này sẽ ngăn bất kỳ trang web nào không được liệt kê ở trên yêu cầu quyền truy cập vào các ứng dụng và dịch vụ trên các thiết bị được kết nối với Wi-Fi hoặc thiết bị mạng cục bộ của bạn. Thao tác này có thể làm hỏng một số tính năng của trang web.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền micrô
permissions-site-microphone-desc = Các trang web dưới đây đã yêu cầu quyền truy cập micrô của bạn. Bạn có thể chỉ định những trang web nào được phép truy cập micrô của bạn. Bạn cũng có thể chặn các yêu cầu mới về việc xin cấp quyền truy cập micrô của bạn.
permissions-site-microphone-disable-label =
    .label = Chặn các yêu cầu mới về việc cho phép tru cập micrô của bạn
permissions-site-microphone-disable-desc = Điều này sẽ ngăn chặn bất cứ trang web nào không được liệt kê ở trên gửi yêu cầu cho phép việc truy cập micrô của bạn. Chặn thông báo có thể ảnh hưởng đến một số tính năng trang web.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Cài đặt - Quyền thiết bị loa
permissions-site-speaker-desc = Các trang web sau đã yêu cầu chọn thiết bị đầu ra âm thanh. Bạn có thể chỉ định trang web nào được phép chọn thiết bị đầu ra âm thanh.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Ngoại lệ trang web cho DNS qua HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } sẽ không sử dụng DNS bảo mật trên các trang web này và tên miền phụ của chúng.
permissions-doh-entry-field = Nhập tên miền trang web
    .accesskey = d
permissions-doh-add-exception =
    .label = Thêm
    .accesskey = A
permissions-doh-col =
    .label = Tên miền
permissions-doh-remove =
    .label = Xóa
    .accesskey = R
permissions-doh-remove-all =
    .label = Xóa tất cả
    .accesskey = e


