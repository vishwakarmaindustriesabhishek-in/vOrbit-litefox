# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# The non-variable portion of this MUST match the translation of
# "PRIVATE_BROWSING_SHORTCUT_TITLE" in custom.properties
private-browsing-shortcut-text-2 = { -brand-shortcut-name } duyệt web riêng tư
# This MUST match the translation of "BRIEF_APP_DESC" in custom.properties
browser-shortcut-description = Duyệt web nhanh và riêng tư
# This is the initial default title for the browser window.
# It gets updated based on loaded tabs or private browsing state.
browser-main-window-default-title = { -brand-full-name }
# Note: only on macOS do we use a `-` separator between the brand name and the
# "Private Browsing" suffix.
browser-main-private-window-title =
    { PLATFORM() ->
        [macos] { -brand-full-name } — Duyệt web riêng tư
       *[other] { -brand-full-name } duyệt web riêng tư
    }
# This is only used on macOS; on other OSes we use the full private window
# title (so including the brand name) as a suffix
browser-main-private-suffix-for-content = Duyệt web riêng tư
popups-infobar-dont-show-message2 =
    .label = Không hiển thị thông báo này khi cửa sổ bật lên hoặc chuyển hướng của bên thứ ba bị chặn
    .accesskey = D
edit-popup-settings2 =
    .label = Quản lý cài đặt cửa sổ bật lên và chuyển hướng của bên thứ ba…
    .accesskey = M
# Variables
#   $count (number) - The number of blocked trackers on this page. Please leave the mention of blocked trackers out when there are none.
urlbar-identity-button2 =
    .aria-label =
        { $count ->
            [0] Xem thông tin trang web
            [1] Xem thông tin trang web (1 trình theo dõi bị chặn)
           *[other] Xem thông tin trang web ({ $count } trình theo dõi bị chặn)
        }
# Caption shown in the native macOS share picker for the items being shared.
# Variables:
#   $count (Number) - The number of links being shared.
menu-share-links =
    .label = { $count } liên kết
# macOS-only item that opens the system share picker, used when a single link
# is shared. "AirDrop" and "Messages" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-single =
    .label = AirDrop, Tin nhắn, và tuỳ chọn khác…
    .accesskey = M
# macOS-only item that opens the system share picker, used when more than one
# link is shared. AirDrop is not mentioned here because it can only share a
# single URL. "Messages" and "Mail" are names of macOS apps, so they should
# match the macOS translation of those names where possible.
menu-share-mac-picker-multiple =
    .label = Tin nhắn, Thư, và tuỳ chọn khác…
    .accesskey = M
# Share entry in the addressbar context menu. Opens the macOS share picker
# directly, hence the ellipsis.
urlbar-share-url =
    .label = Chia sẻ…
    .accesskey = h
urlbar-identity-button =
    .aria-label = Xem thông tin trang

## Tooltips for images appearing in the address bar

urlbar-services-notification-anchor =
    .tooltiptext = Mở bảng thông báo cài đặt
urlbar-web-notification-anchor =
    .tooltiptext = Thay đổi liệu bạn có thể nhận thông báo từ trang web hay không
urlbar-midi-notification-anchor =
    .tooltiptext = Mở bảng MIDI
urlbar-serial-notification-anchor =
    .tooltiptext = Mở bảng Cổng nối tiếp
urlbar-eme-notification-anchor =
    .tooltiptext = Quản lý sử dụng phần mềm DRM
urlbar-web-authn-anchor =
    .tooltiptext = Mở bảng điều khiển xác thực web
urlbar-canvas-notification-anchor =
    .tooltiptext = Quản lý quyền khai thác canvas
urlbar-web-rtc-share-microphone-notification-anchor =
    .tooltiptext = Quản lý chia sẻ micrô của bạn với trang
urlbar-default-notification-anchor =
    .tooltiptext = Mở bảng thông báo
urlbar-geolocation-notification-anchor =
    .tooltiptext = Mở bảng yêu cầu vị trí
urlbar-localhost-notification-anchor =
    .tooltiptext = Quản lý quyền truy cập thiết bị cục bộ cho trang web này
urlbar-local-network-notification-anchor =
    .tooltiptext = Quản lý việc chia sẻ quyền truy cập mạng cục bộ của bạn với trang web này
urlbar-xr-notification-anchor =
    .tooltiptext = Mở bảng điều khiển thực tế ảo
urlbar-storage-access-anchor =
    .tooltiptext = Mở bảng điều khiển quyền hoạt động duyệt web
urlbar-web-rtc-share-screen-notification-anchor =
    .tooltiptext = Quản lý chia sẻ cửa sổ hay màn hình của bạn với trang
urlbar-indexed-db-notification-anchor =
    .tooltiptext = Mở bảng thông báo lưu trữ ngoại tuyến
urlbar-password-notification-anchor =
    .tooltiptext = Mở bảng thông báo lưu mật khẩu
urlbar-web-rtc-share-devices-notification-anchor =
    .tooltiptext = Quản lý chia sẻ máy ảnh và/hoặc micrô với trang
# "Speakers" is used in a general sense that might include headphones or
# another audio output connection.
urlbar-web-rtc-share-speaker-notification-anchor =
    .tooltiptext = Quản lý việc chia sẻ các thiết bị âm thanh khác với trang web
urlbar-autoplay-notification-anchor =
    .tooltiptext = Mở bảng điều khiển tự động phát
urlbar-persistent-storage-notification-anchor =
    .tooltiptext = Lưu dữ liệu vào bộ nhớ lâu dài
urlbar-addons-notification-anchor =
    .tooltiptext = Mở bảng thông báo cài đặt tiện ích
urlbar-search-tips-confirm = OK, đã hiểu
urlbar-search-tips-confirm-short = Đã hiểu
urlbar-result-menu-button =
    .title = Mở menu
urlbar-result-menu-button-feedback = Phản hồi
    .title = Mở menu
urlbar-result-menu-learn-more2 = Tìm hiểu thêm
    .accesskey = L
urlbar-result-menu-remove-from-history2 = Xóa khỏi lịch sử
    .accesskey = R
urlbar-result-menu-tip-get-help2 = Nhận trợ giúp
    .accesskey = h
urlbar-result-menu-dismiss-suggestion2 = Bỏ qua đề xuất này
    .accesskey = D
urlbar-result-menu-remove-top-site = Xóa trang web hàng đầu này
    .accesskey = T
urlbar-result-menu-manage-firefox-suggest2 = Quản lý { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location3 = Báo cáo vị trí không chính xác
    .accesskey = R
urlbar-result-menu-show-less-frequently3 = Hiển thị ít thường xuyên hơn
    .accesskey = f
urlbar-result-menu-dont-show-weather-suggestions3 = Không hiển thị đề xuất về thời tiết
    .accesskey = n
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location2 = Báo cáo vị trí không chính xác
urlbar-result-menu-show-less-frequently2 = Hiển thị ít thường xuyên hơn
urlbar-result-menu-dont-show-weather-suggestions2 = Không hiển thị đề xuất về thời tiết
# Shown in the urlbar input field context menu to dismiss an adaptive autofill
# suggestion.
urlbar-input-dismiss-autofill =
    .label = Bỏ qua đề xuất này
    .accesskey = i
# Shown in the urlbar input field context menu to remove an adaptive autofill
# URL from history.
urlbar-input-remove-from-history =
    .label = Xóa khỏi lịch sử
    .accesskey = e
urlbar-result-menu-learn-more =
    .label = Tìm hiểu thêm
    .accesskey = L
urlbar-result-menu-remove-from-history =
    .label = Xóa khỏi lịch sử
    .accesskey = R
urlbar-result-menu-tip-get-help =
    .label = Nhận trợ giúp
    .accesskey = h
urlbar-result-menu-dismiss-suggestion =
    .label = Bỏ qua đề xuất này
    .accesskey = D
urlbar-result-menu-manage-firefox-suggest =
    .label = Quản lý { -firefox-suggest-brand-name }
    .accesskey = M
# Some urlbar suggestions show the user's approximate location as automatically
# detected by Firefox (e.g., weather suggestions), and this menu item lets the
# user tell Firefox that the location is not accurate. Typically the location
# will be a city name, or a city name combined with the name of its parent
# administrative division (e.g., a province, prefecture, or state).
urlbar-result-menu-report-inaccurate-location =
    .label = Báo cáo vị trí không chính xác
urlbar-result-menu-show-less-frequently =
    .label = Hiển thị ít thường xuyên hơn
urlbar-result-menu-dont-show-weather-suggestions =
    .label = Không hiển thị đề xuất về thời tiết
# Used for Split Button.
urlbar-splitbutton-dropmarker =
    .title = Mở menu
# A message shown in the urlbar when the user submits feedback on a suggestion
# (e.g., it shows an inaccurate location, it's shown too often, etc.).
urlbar-feedback-acknowledgment = Cảm ơn phản hồi của bạn
# A message shown in the urlbar when the user dismisses weather suggestions.
# Weather suggestions won't be shown at all anymore.
urlbar-dismissal-acknowledgment-weather = Cảm ơn phản hồi của bạn. Bạn sẽ không thấy đề xuất về thời tiết nữa.

## Prompts users to use the Urlbar when they open a new tab or visit the
## homepage of their default search engine.
## Variables:
##  $engineName (String): The name of the user's default search engine. e.g. "Google" or "DuckDuckGo".

urlbar-search-tips-onboard = Nhập ít hơn, tìm thêm: Tìm kiếm { $engineName } ngay từ thanh địa chỉ của bạn.
urlbar-search-tips-redirect-2 = Bắt đầu tìm kiếm của bạn trong thanh địa chỉ để xem các đề xuất từ { $engineName } và lịch sử duyệt web của bạn.
# Prompts users to use the Urlbar when they are typing in the domain of a
# search engine, e.g. google.com or amazon.com.
urlbar-tabtosearch-onboard = Chọn phím tắt này để tìm những gì bạn cần nhanh hơn.

## Local search mode indicator labels in the urlbar

urlbar-search-mode-bookmarks = Dấu trang
urlbar-search-mode-tabs = Thẻ
urlbar-search-mode-history = Lịch sử
urlbar-search-mode-actions = Hành động

##

urlbar-geolocation-blocked =
    .tooltiptext = Bạn đã chặn thông tin địa điểm ở trang này.
urlbar-localhost-blocked =
    .tooltiptext = Bạn đã chặn kết nối thiết bị cục bộ cho trang web này.
urlbar-local-network-blocked =
    .tooltiptext = Bạn đã chặn kết nối mạng cục bộ cho trang web này.
urlbar-xr-blocked =
    .tooltiptext = Bạn đã chặn truy cập thiết bị thực tế ảo cho trang web này.
urlbar-web-notifications-blocked =
    .tooltiptext = Bạn đã chặn thông báo ở trang này.
urlbar-camera-blocked =
    .tooltiptext = Bạn đã chặn camera của mình ở trang này
urlbar-microphone-blocked =
    .tooltiptext = Bạn đã chặn micro của mình ở trang này
urlbar-screen-blocked =
    .tooltiptext = Bạn đã chặn việc chia sẻ màn hình của mình với trang web này.
urlbar-persistent-storage-blocked =
    .tooltiptext = Bạn đã chặn lưu dữ liệu vào bộ nhớ lâu dài ở trang này.
urlbar-popup-blocked2 =
    .tooltiptext = Bạn đã chặn cửa sổ bật lên và chuyển hướng của bên thứ ba cho trang web này.
urlbar-autoplay-media-blocked =
    .tooltiptext = Bạn đã chặn phương tiện tự động phát có âm thanh cho trang web này.
urlbar-canvas-blocked =
    .tooltiptext = Bạn đã chặn khai thác dữ liệu canvas đối với trang web này.
urlbar-midi-blocked =
    .tooltiptext = Bạn đã chặn quyền truy cập MIDI của trang web này.
urlbar-serial-blocked =
    .tooltiptext = Bạn đã chặn quyền truy cập cổng nối tiếp cho trang web này.
urlbar-install-blocked =
    .tooltiptext = Bạn đã chặn cài đặt tiện ích cho trang web này.
# Variables
#   $shortcut (String) - A keyboard shortcut for the edit bookmark command.
urlbar-star-edit-bookmark =
    .tooltiptext = Chỉnh sửa dấu trang này ({ $shortcut })
# Variables
#   $shortcut (String) - A keyboard shortcut for the add bookmark command.
urlbar-star-add-bookmark =
    .tooltiptext = Đánh dấu trang này ({ $shortcut })
urlbar-split-view-button =
    .aria-label = Chế độ chia cửa sổ
    .tooltiptext = Chế độ chia cửa sổ

## URLbar context menu

urlbar-menuitem-paste-and-go =
    .label = Dán & mở đường dẫn
    .accesskey = G
urlbar-menuitem-paste-and-search =
    .label = Dán và tìm kiếm
    .accesskey = S

## Searchbar context menu

clear-search-history =
    .label = Xóa lịch sử tìm kiếm
    .accesskey = X

## Page Action Context Menu

page-action-manage-extension2 =
    .label = Quản lý tiện ích mở rộng…
    .accesskey = E
page-action-remove-extension2 =
    .label = Xóa tiện ích mở rộng
    .accesskey = v

## Auto-hide Context Menu

full-screen-autohide =
    .label = Ẩn thanh công cụ
    .accesskey = H
full-screen-exit =
    .label = Thoát chế độ toàn màn hình
    .accesskey = F

## Search Engine selection buttons (one-offs)

# This string prompts the user to use the list of search shortcuts in
# the Urlbar and searchbar.
search-one-offs-with-title = Lần này, tìm kiếm với:
search-one-offs-change-settings-compact-button =
    .tooltiptext = Thay đổi cài đặt tìm kiếm
search-one-offs-context-open-new-tab =
    .label = Tìm trong thẻ mới
    .accesskey = T
search-one-offs-context-set-as-default =
    .label = Đặt làm công cụ tìm kiếm mặc định
    .accesskey = D
search-one-offs-context-set-as-default-private =
    .label = Đặt làm công cụ tìm kiếm mặc định cho cửa sổ riêng tư
    .accesskey = P
# Search engine one-off buttons with an @alias shortcut/keyword.
# Variables:
#  $engineName (String): The name of the engine.
#  $alias (String): The @alias shortcut/keyword.
search-one-offs-engine-with-alias =
    .tooltiptext = { $engineName } ({ $alias })
# Shown when adding new engines from the address bar shortcut buttons or context
# menu, or from the search bar shortcut buttons.
# Variables:
#  $engineName (String): The name of the engine.
search-one-offs-add-engine =
    .aria-label = Thêm công cụ tìm kiếm “{ $engineName }”
    .label = Thêm “{ $engineName }”
    .tooltiptext = Thêm công cụ tìm kiếm “{ $engineName }”
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu2 =
    .label = Thêm dịch vụ tìm kiếm
    .accesskey = h
# When more than 5 engines are offered by a web page, they are grouped in a
# submenu using this as its label.
search-one-offs-add-engine-menu =
    .label = Thêm dịch vụ tìm kiếm

## Local search mode one-off buttons
## Variables:
##  $restrict (String): The restriction token corresponding to the search mode.
##    Restriction tokens are special characters users can type in the urlbar to
##    restrict their searches to certain sources (e.g., "*" to search only
##    bookmarks).

search-one-offs-bookmarks =
    .tooltiptext = Dấu trang ({ $restrict })
search-one-offs-tabs =
    .tooltiptext = Thẻ ({ $restrict })
search-one-offs-history =
    .tooltiptext = Lịch sử ({ $restrict })
search-one-offs-actions =
    .tooltiptext = Hành động ({ $restrict })

## QuickActions are shown in the urlbar as the user types a matching string
## The -cmd- strings are comma separated list of keywords that will match
## the action. English commas should be used, i.e. ,

# Opens the about:addons page in the home / recommendations section
quickactions-addons = Xem tiện tích
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-addons3 = tiện ích, chủ đề, tien ich, chu de, tiện ích mở rộng, tien ich mo rong
# Opens preferences page at AI controls
quickactions-manageai = Quản lý kiểm soát trí tuệ nhân tạo
quickactions-cmd-manageai = vô hiệu hóa ai, tắt ai, quản lý ai, vo hieu hoa ai, tat ai, quan ly ai, disable ai, off ai, manage ai
# Opens the bookmarks library window
quickactions-bookmarks2 = Quản lý dấu trang
quickactions-cmd-bookmarks = quản lý dấu trang, quan ly dau trang, quản lí dấu trang, quan li dau trang, dấu trang, dau trang, bookmarks
# Opens a SUMO article explaining how to clear history
quickactions-clearrecenthistory = Xoá lịch sử gần đây
quickactions-cmd-clearrecenthistory2 = cookie, xoá cookie, xóa cookie, cache, xoá bộ nhớ đệm, xóa bộ nhớ đệm, xoa bo nho dem, dữ liệu duyệt web, du lieu duyet web, xoá dữ liệu duyệt web, xóa dữ liệu duyệt web, xoa du lieu duyet web, lịch sử, lich su, xoá lịch sử gần đây, xóa lịch sử gần đây, xoa lich su gan day
# Opens about:downloads page
quickactions-downloads2 = Xem tải xuống
quickactions-cmd-downloads = xem tải xuống, xem tai xuong, tải xuống, tai xuong, downloads
# Opens about:addons page in the extensions section
quickactions-extensions = Quản lý tiện ích
quickactions-cmd-extensions2 = tien ich, tiện ích, tien ich mo rong, tiện ích mở rộng, extensions
# Opens Firefox View
quickactions-firefoxview = Mở { -firefoxview-brand-name }
# English is using "view" and "open view", since the feature name is
# "Firefox View". If you have translated the name in your language, you
# should use a word related to the existing translation.
quickactions-cmd-firefoxview = mở { -firefoxview-brand-name }, { -firefoxview-brand-name }, mở view, view, mo { -firefoxview-brand-name }, mo view,
# Opens SUMO home page
quickactions-help = Trợ giúp về { -brand-product-name }
quickactions-cmd-help = trợ giúp, hỗ trợ, tro giup, ho tro
# Opens the devtools web inspector
quickactions-inspector2 = Mở Công cụ dành cho nhà phát triển
quickactions-cmd-inspector2 = trình kiểm tra, trinh kiem tra, devtools, dev tools
# Opens the devtools eyedropper to pick a color from the page
quickactions-colorpicker = Chọn một màu
quickactions-cmd-colorpicker = chọn màu, eyedropper, chon mau, pick color, color picker
# Opens Firefox Library
quickactions-cmd-library = mo thu vien, thu vien, mở thư viện, thư viện, library
quickactions-library = Mở thư viện
# Opens about:logins
quickactions-logins2 = Quản lý mật khẩu
quickactions-cmd-logins = đăng nhập, thông tin đăng nhập, mật khẩu, dang nhap, thong tin dang nhap, mat khau
# Mutes all tabs playing audio
quickactions-mute = Tắt tiếng thẻ đang phát âm thanh
# List of words that would trigger the "mute tabs" action from the address bar.
# Replace with idiomatic expressions in your language to silence something or
# someone.
quickactions-cmd-mute = tắt tiếng, tat tieng, shush, mute, sssssh
# Opens the print dialog
quickactions-print2 = In trang
quickactions-cmd-print = in, in trang, print
# Opens the print dialog at the save to PDF option
quickactions-savepdf = Lưu trang dưới dạng PDF
quickactions-cmd-savepdf2 = pdf, lưu trang, luu trang
# Opens about:pdf, the PDF editor landing page
quickactions-editpdf = Mở trình chỉnh sửa PDF
quickactions-cmd-editpdf = pdf
# Opens a new private browsing window
quickactions-private2 = Mở cửa sổ riêng tư
quickactions-cmd-private = duyệt web riêng tư, duyet web rieng tu, cửa sổ riêng tư, cua so rieng tu
# Opens a SUMO article explaining how to refresh
quickactions-refresh = Làm mới { -brand-short-name }
quickactions-cmd-refresh = làm mới, lam moi
# Restarts the browser
quickactions-restart = Khởi động lại { -brand-short-name }
quickactions-cmd-restart = khởi động lại, khoi dong lai
# Opens the screenshot tool
quickactions-screenshot3 = Chụp ảnh màn hình
quickactions-cmd-screenshot2 = chụp màn hình, chup man hinh, ảnh chụp màn hình, anh chup man hinh, screenshot
# Opens about:translations
quickactions-translate = Dịch
quickactions-cmd-translate = dịch
# Opens about:preferences
quickactions-settings2 = Quản lý cài đặt
# "manage" should match the corresponding command, which is “Manage settings” in English.
quickactions-cmd-settings2 = cài đặt, tùy chọn, tùy chỉnh, quản lý, quản lí, cai dat, tuy chon, tuy chinh, quan ly, quan li
# Opens about:addons page in the themes section
quickactions-themes = Quản lý chủ đề
# In English we provide multiple spellings for "add-ons". If that's not
# applicable to your language, only use the correct spelling (don't repeat the
# same word).
quickactions-cmd-themes2 = tien ich, tiện ích, chu de, chủ đề, themes
# Opens a SUMO article explaining how to update the browser
quickactions-update = Cập nhật { -brand-short-name }
quickactions-cmd-update = cập nhật, cap nhat, update
# Opens the view-source UI with current pages source
quickactions-viewsource2 = Xem mã nguồn trang
quickactions-cmd-viewsource2 = xem mã nguồn trang, xem ma nguon trang, trang, source, mã nguồn trang, ma nguon trang
# Opens about:preferences:experimental (Firefox Labs)
quickactions-labs = Mở { -firefoxlabs-brand-name }
quickactions-cmd-labs = lab, labs, thử nghiệm, thu nghiem
# Tooltip text for the help button shown in the result.
quickactions-learn-more =
    .title = Tìm hiểu thêm về Hành động nhanh
# Will be shown to users the first configurable number of times
# they experience actions giving them instructions on how to
# select the action shown by pressing the tab key.
press-tab-label = Nhấn phím tab để chọn:

## Bookmark Panel

bookmarks-add-bookmark = Thêm dấu trang
bookmarks-edit-bookmark = Chỉnh sửa dấu trang
bookmark-panel-cancel =
    .label = Hủy bỏ
    .accesskey = C
# Variables:
#  $count (number): number of bookmarks that will be removed
bookmark-panel-remove =
    .label = Xóa { $count } dấu trang
    .accesskey = R
bookmark-panel-show-editor-checkbox =
    .label = Hiển thị trình chỉnh sửa khi lưu
    .accesskey = S
bookmark-panel-save-button2 =
    .label = Lưu
    .accesskey = a
bookmark-panel-save-button =
    .label = Lưu
# Width of the bookmark panel.
# Should be large enough to fully display the Done and
# Cancel/Remove Bookmark buttons.
bookmark-panel =
    .style = min-width: 23em

## Identity Panel

# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-site-information = Thông tin trang web { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
identity-header-security-with-host =
    .title = Bảo mật kết nối cho { $host }
identity-connection-not-secure = Kết nối không an toàn
identity-connection-secure = Kết nối an toàn
identity-connection-failure = Kết nối thất bại
identity-connection-internal = Đây là một trang an toàn của { -brand-short-name }
identity-connection-file = Trang này đã được lưu ở máy tính của bạn.
identity-connection-associated = Trang này được tải từ một trang khác.
identity-extension-page = Trang này được tải từ một tiện ích mở rộng.
identity-active-blocked = { -brand-short-name } đã chặn những phần không an toàn của trang này.
identity-custom-root = Kết nối được xác minh bởi nhà phát hành chứng chỉ không được Mozilla công nhận.
identity-passive-loaded = Có nhiều thành phân của trang không an toàn (ví dụ như ảnh).
identity-active-loaded = Bạn đã tắt tính năng bảo vệ trên trang này.
identity-weak-encryption = Trang này sử dụng mã hóa yếu.
identity-https-only-connection-upgraded = (đã nâng cấp lên HTTPS)
identity-https-only-label2 = Tự động nâng cấp trang web này lên kết nối an toàn
identity-https-only-dropdown-on =
    .label = Bật
identity-https-only-dropdown-off =
    .label = Tắt
identity-https-only-dropdown-off-temporarily =
    .label = Tắt tạm thời
identity-https-only-info-turn-on3 = Bật nâng cấp HTTPS cho trang web này nếu bạn muốn { -brand-short-name } nâng cấp kết nối khi có thể.
identity-https-only-info-turn-off3 = Nếu trang có vẻ bị hỏng, bạn có thể muốn tắt nâng cấp HTTPS cho trang web này để tải lại bằng HTTP không an toàn.
identity-https-only-info-no-upgrade = Không thể nâng cấp kết nối từ HTTP.
identity-permissions-storage-access-header = Cookie liên trang web
identity-permissions-storage-access-hint = Khi bạn mở trang web này, các trang web này có thể sử dụng cookie liên trang web và lấy thông tin của bạn trên trang web này.
identity-permissions-storage-access-learn-more = Tìm hiểu thêm
identity-permissions-reload-hint = Bạn có thể cần phải tải lại trang để các thay đổi được áp dụng.
identity-clear-site-data =
    .label = Xóa cookie và dữ liệu trang web…
identity-connection-not-secure-security-view = Bạn không được kết nối an toàn với trang web này.
identity-connection-verified = Bạn đang kết nối an toàn tới trang này.
identity-ev-owner-label2 = Chứng chỉ được cấp cho
identity-verifier-label2 = Xác minh bởi
identity-ev-owner-label = Chứng nhận được cấp cho:
identity-verifier-label = Xác minh bởi:
# "qualified" here refers to the qualified website authentication certificate presented by the site.
identity-etsi = Được chứng nhận/đủ điều kiện theo quy định tại Quy định (EU) 2024/1183.
identity-description-custom-root2 = Mozilla không công nhận nhà phát hành chứng nhận này. Nó có thể đã được thêm từ hệ điều hành của bạn hoặc bởi quản trị viên.
identity-cert-exception-overridden = Bạn đã thêm ngoại lệ bảo mật cho trang này.
identity-remove-cert-exception =
    .label = Loại bỏ ngoại lệ
    .accesskey = R
identity-description-insecure = Kết nối của bạn đến trang này không được bảo mật. Thông tin bạn gửi có thể bị thấy bởi người khác (ví dụ như mật khẩu, tin nhắn, thẻ tín dụng).
identity-description-weak-cipher-intro = Kết nối đến trang này sử dụng mã hóa yếu và không bảo mật.
identity-description-weak-cipher-risk = Người khác có thể thấy thông tin của bạn hoặc thay đổi hành vi của trang.
identity-description-active-blocked2 = { -brand-short-name } đã chặn những phần không an toàn của trang này.
identity-description-passive-loaded = Kết nối không được bảo mật và thông tin bạn chia sẻ với trang này có thể bị thấy bởi người khác.
identity-description-passive-loaded-insecure2 = Trang web này chứa nội dung không an toàn (ví dụ: ảnh).
identity-description-passive-loaded-mixed2 = Dù { -brand-short-name } đã chặn một số nội dung, vẫn có những nội dung trên trang không an toàn (ví dụ: ảnh).
identity-description-active-loaded = Trang web này chứa nội dung không an toàn (ví dụ: các đoạn mã) và kết nối tới nội dung này không bảo mật.
identity-description-active-loaded-insecure = Thông tin bạn chia sẻ với trang này có thể bị thấy bởi người khác (ví dụ: mật khẩu, tin nhắn, thẻ tín dụng, vâng vâng).
identity-description-tls-key-logging-heading = Kết nối của bạn có thể không riêng tư
identity-description-tls-key-logging-message = Một ứng dụng hoặc dịch vụ nào đó có thể xem lưu lượng truy cập được mã hóa của bạn từ trang web này.
identity-more-info-link-text =
    .label = Thông tin thêm

## Window controls

browser-window-minimize-button =
    .tooltiptext = Thu nhỏ
browser-window-maximize-button =
    .tooltiptext = Cực đại hoá
browser-window-restore-down-button =
    .tooltiptext = Khôi phục kích thước
browser-window-close-button =
    .tooltiptext = Đóng
# Clicking this button closes the window and returns to the tab where it was opened from
browser-window-return-to-opener =
    .tooltiptext = Quay lại

## Bookmarks toolbar items

browser-import-button2 =
    .label = Nhập dấu trang…
    .tooltiptext = Nhập dấu trang từ trình duyệt khác sang { -brand-short-name }.
bookmarks-toolbar-empty-message = Để truy cập nhanh, hãy đặt dấu trang của bạn tại đây trên thanh công cụ dấu trang. <a data-l10n-name="manage-bookmarks">Quản lý dấu trang…</a>

## WebRTC Pop-up notifications

popup-select-camera-device =
    .value = Máy ảnh:
    .accesskey = C
popup-select-camera-icon =
    .tooltiptext = Máy ảnh
popup-select-microphone-device =
    .value = Micrô:
    .accesskey = M
popup-select-microphone-icon =
    .tooltiptext = Micrô
popup-select-speaker-icon =
    .tooltiptext = Loa
popup-select-window-or-screen =
    .label = Cửa sổ hoặc màn hình:
    .accesskey = W
popup-all-windows-shared = Tất cả các cửa sổ trên màn hình sẽ được chia sẻ.

## WebRTC window or screen share tab switch warning

sharing-warning-window = Bạn đang chia sẻ { -brand-short-name }. Người khác có thể thấy khi bạn chuyển sang một thẻ mới.
sharing-warning-screen = Bạn đang chia sẻ toàn bộ màn hình của bạn. Người khác có thể thấy khi bạn chuyển sang một thẻ mới.
sharing-warning-proceed-to-tab =
    .label = Tiếp tục với thẻ
sharing-warning-disable-for-session =
    .label = Vô hiệu hóa bảo vệ chia sẻ cho phiên này

## WebSerial "select a port" popup

webserial-select-port-label = Chọn một cổng nối tiếp:
webserial-no-ports-available = Không có cổng nối tiếp có sẵn

## URL Bar

# This string is used as an accessible name to the "X" button that cancels a custom search mode (i.e. exits the Amazon.com search mode).
urlbar-search-mode-indicator-close =
    .aria-label = Đóng
# This placeholder is used when not in search mode and the user's default search
# engine is unknown.
urlbar-placeholder =
    .placeholder = Nhập địa chỉ hoặc từ khóa tìm kiếm
# This placeholder is used when not in search mode and searching in the urlbar
# is disabled via the keyword.enabled pref.
urlbar-placeholder-keyword-disabled =
    .placeholder = Nhập địa chỉ
# This placeholder is used in search mode with search engines that search the
# entire web.
# Variables
#  $name (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-placeholder-search-mode-web-2 =
    .aria-label = Tìm kiếm với { $name }
    .placeholder = Tìm kiếm trên mạng
# This placeholder is used in search mode with search engines that search a
# specific site (e.g., Amazon).
# Variables
#  $name (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-placeholder-search-mode-other-engine =
    .aria-label = Tìm kiếm { $name }
    .placeholder = Nhập từ tìm kiếm
# This placeholder is used when searching bookmarks.
urlbar-placeholder-search-mode-other-bookmarks =
    .aria-label = Tìm kiếm dấu trang
    .placeholder = Nhập từ tìm kiếm
# This placeholder is used when searching history.
urlbar-placeholder-search-mode-other-history =
    .aria-label = Tìm kiếm lịch sử
    .placeholder = Nhập từ tìm kiếm
# This placeholder is used when searching open tabs.
urlbar-placeholder-search-mode-other-tabs =
    .aria-label = Tìm kiếm thẻ
    .placeholder = Nhập từ tìm kiếm
# This placeholder is used when searching quick actions.
urlbar-placeholder-search-mode-other-actions =
    .aria-label = Tìm kiếm hành động
    .placeholder = Nhập từ tìm kiếm
# Variables
#  $name (String): the name of the user's default search engine
urlbar-placeholder-with-name =
    .placeholder = Tìm kiếm với { $name } hoặc nhập địa chỉ
# Variables
#  $component (String): the name of the component which forces remote control.
#    Example: "DevTools", "Marionette", "RemoteAgent".
urlbar-remote-control-notification-anchor2 =
    .tooltiptext = Trình duyệt đang được điều khiển từ xa (lý do: { $component })
urlbar-permissions-granted =
    .tooltiptext = Bạn đã cấp cho trang web này các quyền bổ sung.
urlbar-switch-to-tab =
    .value = Chuyển qua thẻ:
# Used to indicate that a selected autocomplete entry is provided by an extension.
urlbar-extension =
    .value = Tiện ích mở rộng:
urlbar-go-button2 =
    .title = Mở trang trong thanh địa chỉ
urlbar-page-action-button =
    .tooltiptext = Hành động trên trang
urlbar-revert-button =
    .tooltiptext = Hiển thị địa chỉ trong thanh địa chỉ

## "Last visited" and "bookmarked" explanation strings. For bookmarks and urlbar
## results with last-visited dates like history and top sites, these strings
## explain why the result is shown.

# Used when the private browsing engine differs from the default engine.
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-in-private-w-engine = Tìm kiếm với { $engine } trong cửa sổ riêng tư
# Used when the private browsing engine is the same as the default engine.
urlbar-result-action-search-in-private = Tìm kiếm trong cửa sổ riêng tư
# The "with" format was chosen because the search engine name can end with
# "Search", and we would like to avoid strings like "Search MSN Search".
# Variables
#  $engine (String): the name of a search engine
urlbar-result-action-search-w-engine = Tìm với { $engine }
urlbar-result-action-sponsored = Được tài trợ
urlbar-result-action-switch-tab = Chuyển sang thẻ
urlbar-result-action-move-tab-to-split-view = Di chuyển thẻ sang chế độ chia cửa sổ
urlbar-result-action-visit = Truy cập
# "Switch to tab with container" is used when the target tab is located in a
# different container.
# Variables
# $container (String): the name of the target container
urlbar-result-action-switch-tab-with-container = Chuyển sang thẻ · <span>{ $container }</span>
# Used when the target tab is in a tab group that doesn't have a label.
urlbar-result-action-tab-group-unnamed = Nhóm không tên
# Allows the user to visit a URL that was previously copied to the clipboard.
urlbar-result-action-visit-from-clipboard = Truy cập từ bộ nhớ tạm
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-before-tabtosearch-web = Nhấn Tab để tìm kiếm bằng { $engine }
# Directs a user to press the Tab key to perform a search with the specified
# engine.
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-before-tabtosearch-other = Nhấn Tab để tìm kiếm { $engine }
# Variables
#  $engine (String): the name of a search engine that searches the entire Web
#  (e.g. Google).
urlbar-result-action-tabtosearch-web = Tìm kiếm với { $engine } trực tiếp từ thanh địa chỉ
# Variables
#  $engine (String): the name of a search engine that searches a specific site
#  (e.g. Amazon).
urlbar-result-action-tabtosearch-other-engine = Tìm kiếm { $engine } trực tiếp từ thanh địa chỉ
# Action text for copying to clipboard.
urlbar-result-action-copy-to-clipboard = Sao chép
# The string returned for an undefined calculator result such as when dividing by 0
urlbar-result-action-undefined-calculator-result = không xác định
# The sub title of an add-on suggestion in the urlbar.
urlbar-result-addons-subtitle = Tiện ích { -brand-product-name }
# The sub title of a mdn suggestion in the urlbar.
urlbar-result-mdn-subtitle = { -mdn-brand-name }
# The sub title of a Yelp suggestion in the urlbar.
urlbar-result-yelp-subtitle = { -yelp-brand-name }
# This string explaining that the suggestion is a recommendation.
urlbar-result-suggestion-recommended = Được đề xuất
# The title of a weather suggestion in the urlbar. The temperature and unit
# substring should be inside a <strong> tag. If the temperature and unit are not
# adjacent in the localization, it's OK to include only the temperature in the
# tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name of the city's region or country. Depending on
#       the user's location in relation to the city, this may be the name or
#       abbreviation of one of the city's administrative divisions like a
#       province or state, or it may be the name of the city's country.
urlbar-result-weather-title = <strong>{ $temperature }°{ $unit }</strong> tại { $city }, { $region }
# The title of a weather suggestion in the urlbar including a region and
# country. The temperature and unit substring should be inside a <strong> tag.
# If the temperature and unit are not adjacent in the localization, it's OK to
# include only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
#   $region (String) - The name or abbreviation of one of the city's
#       administrative divisions like a province or state.
#   $country (String) - The name of the city's country.
urlbar-result-weather-title-with-country = <strong>{ $temperature }°{ $unit }</strong> tại { $city }, { $region }, { $country }
# The title of a weather suggestion in the urlbar only including the city. The
# temperature and unit substring should be inside a <strong> tag. If the
# temperature and unit are not adjacent in the localization, it's OK to include
# only the temperature in the tag.
# Variables:
#   $temperature (number) - The temperature value
#   $unit (String) - The unit for the temperature, either "C" or "F"
#   $city (String) - The name of the city the weather data is for
urlbar-result-weather-title-city-only = <strong>{ $temperature }°{ $unit }</strong> tại { $city }
# Shows the name of the provider of weather data in a weather suggestion in the
# urlbar.
# Variables:
#   $provider (String) - The name of the weather-data provider. It will be the
#       name of a company, organization, or service.
urlbar-result-weather-provider-sponsored = { $provider } · Được tài trợ
# Used for asking AI assistant chat.
urlbar-result-action-ai-chat = Hỏi
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative = Lần cuối bạn truy cập vào { $date }
# This explanation is used when the last-visited date is a small number of days
# in the past.
# Variables:
#   $daysAgo (number) - The number of days ago
urlbar-result-explanation-last-visited-days = Lần cuối bạn truy cập vào { $daysAgo } ngày trước
# This explanation is used when the last-visited date is a small number of weeks
# in the past.
# Variables:
#   $weeksAgo (number) - The number of weeks ago
urlbar-result-explanation-last-visited-weeks = Lần cuối bạn truy cập vào { $weeksAgo } tuần trước
# This explanation is used when the last-visited date is a small number of
# months in the past.
# Variables:
#   $monthsAgo (number) - The number of months ago
urlbar-result-explanation-last-visited-months = Lần cuối bạn truy cập vào { $monthsAgo } tháng trước
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute = Lần cuối bạn truy cập vào { $date }
# This explanation is used when the result is bookmarked. The date will be
# formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-bookmarked = Đã đánh dấu { $date }
# This explanation is used when the last-visited date is formatted as one of the
# following relative dates: "yesterday", "today"
# Variables:
#   $date (string) - A localized relative date string
urlbar-result-explanation-last-visited-relative-2 = Lần truy cập cuối { $date }
# This explanation is used when the last-visited date is a small number of days,
# weeks, or months in the past.
# Variables:
#   $date (string) - A localized relative date string like one of the following:
#                    "6 days ago", "1 week ago", "4 weeks ago", "1 month ago",
#                    "11 months ago"
urlbar-result-explanation-last-visited-days-weeks-months-ago = Lần truy cập cuối { $date }
# This explanation is used when the last-visited date is further in the past.
# The date will be formatted as an absolute date like: "11 May", "11 May 2026"
# Variables:
#   $date (string) - A localized absolute date string
urlbar-result-explanation-last-visited-absolute-2 = Lần truy cập cuối { $date }

## These strings are used for Realtime suggestions in the urlbar.
## Market refers to stocks, indexes, and funds.

# This string is shown as title when Market suggestion are disabled.
urlbar-result-market-opt-in-title = Nhận dữ liệu thị trường chứng khoán ngay trong thanh tìm kiếm của bạn
# This string is shown as description when Market suggestion are disabled.
urlbar-result-market-opt-in-description = Hiển thị thông tin cập nhật thị trường và nhiều hơn nữa từ các đối tác của chúng tôi khi bạn chia sẻ dữ liệu truy vấn tìm kiếm với { -vendor-short-name }. <a data-l10n-name="learn-more-link">Tìm hiểu thêm</a>
# This string is shown as button to activate online when realtime suggestion are disabled.
urlbar-result-realtime-opt-in-allow = Hiển thị đề xuất
# This string is shown in split button to dismiss activation the Realtime suggestion.
urlbar-result-realtime-opt-in-not-now = Để sau
urlbar-result-realtime-opt-in-dismiss = Bỏ qua
urlbar-result-realtime-opt-in-dismiss-all2 = Không hiển thị những đề xuất này
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market3 = Không hiển thị đề xuất thị trường
    .accesskey = n
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market2 = Không hiển thị đề xuất thị trường
urlbar-result-realtime-opt-in-dismiss-all =
    .label = Không hiển thị những đề xuất này
# This string is shown in the result menu.
urlbar-result-menu-dont-show-market =
    .label = Không hiển thị đề xuất thị trường
# A message that replaces a result when the user dismisses Market suggestions.
urlbar-result-dismissal-acknowledgment-market = Cảm ơn phản hồi của bạn. Bạn sẽ không thấy đề xuất về thị trường nữa.
# This a11y label is read by screen readers when an item in the row is selected.
urlbar-result-aria-group-market =
    .aria-label = Gợi ý về thị trường chứng khoán
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-result-dismissal-acknowledgment-all = Cảm ơn phản hồi của bạn. Bạn sẽ không thấy những đề xuất này nữa.

## These strings are used for suggestions of important dates in the urlbar.

# The name of an event and the number of days until it starts separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown = { $name } · Trong { $daysUntilStart } ngày
# The name of a multiple day long event and the number of days until it starts
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilStart (integer) - The number of days until the event starts.
urlbar-result-dates-countdown-range = { $name } · Bắt đầu sau { $daysUntilStart } ngày
# The name of a multiple day long event and the number of days until it ends
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
#   $daysUntilEnd (integer) - The number of days until the event ends.
urlbar-result-dates-ongoing = { $name } · Kết thúc sau { $daysUntilEnd } ngày
# The name of an event and a note that it is happening today separated by a
# middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-today = { $name } · Hôm nay
# The name of multiple day long event and a note that it is ends today
# separated by a middot.
# Variables:
#   $name (string) - The name of the event.
urlbar-result-dates-ends-today = { $name } · Kết thúc hôm nay

## Strings used for buttons in the urlbar

# Label prompting user to search with a particular search engine.
#  $engine (String): the name of a search engine that searches a specific site
urlbar-result-search-with = Tìm với { $engine }
# Label for the urlbar result row, prompting the user to use a local keyword to enter search mode.
#  $keywords (String): the restrict keyword to enter search mode.
#  $localSearchMode (String): the local search mode (history, tabs, bookmarks,
#  or actions) to search with.
urlbar-result-search-with-local-search-mode = { $keywords } - Tìm kiếm { $localSearchMode }
# Label for the urlbar result row, prompting the user to use engine keywords to enter search mode.
#  $keywords (String): the default keyword and user's set keyword if available
#  $engine (String): the name of a search engine
urlbar-result-search-with-engine-keywords = { $keywords } - Tìm kiếm với { $engine }
# Searchmode Switcher button
# Variables:
#   $engine (String): the current default search engine.
urlbar-searchmode-button3 =
    .title = { $engine }, chọn một công cụ tìm kiếm
urlbar-searchmode-button-no-engine2 =
    .title = Không có lối tắt được chọn, hãy chọn một lối tắt
# Refers to the ability to search using keywords in the address bar
urlbar-searchmode-no-keyword2 =
    .title = Từ khoá tìm kiếm bị vô hiệu hoá
urlbar-searchmode-dropmarker2 =
    .title = Chọn công cụ tìm kiếm
urlbar-searchmode-bookmarks4 = Dấu trang
urlbar-searchmode-tabs4 = Thẻ
urlbar-searchmode-history4 = Lịch sử
urlbar-searchmode-actions4 = Hành động
urlbar-searchmode-bookmarks3 = Dấu trang
    .accesskey = B
urlbar-searchmode-tabs3 = Thẻ
    .accesskey = T
urlbar-searchmode-history3 = Lịch sử
    .accesskey = H
urlbar-searchmode-actions3 = Hành động
    .accesskey = A
urlbar-searchmode-exit-button2 =
    .title = Đóng
urlbar-searchmode-default2 =
    .title = Công cụ tìm kiếm mặc định
# Shown when adding new search engines from the search mode switcher.
# Variables:
#  $engineName (String): The name of the search engine.
urlbar-searchmode-popup-add-engine = Thêm “{ $engineName }”
    .title = Thêm công cụ tìm kiếm “{ $engineName }”
# Label shown on the top of Searchmode Switcher popup. After this label, the
# available search engines will be listed.
urlbar-searchmode-popup-one-off-header = Lần này, tìm kiếm với:
# Label shown on the top of Searchmode Switcher popup when the search engine won't automatically
# reset after submitting.
urlbar-searchmode-popup-header = Tìm kiếm với:
urlbar-searchmode-popup-search-settings2 = Cài đặt tìm kiếm
urlbar-searchmode-popup-settings2 = Cài đặt
urlbar-searchmode-popup-search-settings = Cài đặt tìm kiếm
    .accesskey = S
urlbar-searchmode-popup-settings = Cài đặt
    .accesskey = S

## Action text shown in urlbar results, usually appended after the search
## string or the url, like "result value - action text".
## In these actions "Search" is a verb, followed by where the search is performed.

urlbar-result-action-search-bookmarks = Tìm kiếm dấu trang
urlbar-result-action-search-history = Tìm kiếm lịch sử
urlbar-result-action-search-tabs = Tìm kiếm thẻ
urlbar-result-action-search-actions = Tìm kiếm hành động
# Label for a quickaction result used to switch to an open tab group.
#  $group (String): the name of the tab group to switch to
urlbar-result-action-switch-to-tabgroup = Chuyển đến { $group }
# Label for a quickaction result used to re-opan a saved tab group.
#  $group (String): the name of the tab group to re-open
urlbar-result-action-open-saved-tabgroup = Mở { $group }

## Used in the menu of a urlbar result.

urlbar-view-context-menu-open-in-tab =
    .label = Mở trong thẻ mới
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab =
    .label = Mở trong thẻ ngăn chứa mới
    .accesskey = i
urlbar-view-context-menu-open-in-window =
    .label = Mở trong cửa sổ mới
    .accesskey = N
urlbar-view-context-menu-open-in-private-window =
    .label = Mở trong cửa sổ riêng tư mới
    .accesskey = P
urlbar-view-context-menu-open-in-tab2 = Mở trong thẻ mới
    .accesskey = w
urlbar-view-context-menu-open-in-container-tab2 = Mở trong thẻ ngăn chứa mới
    .accesskey = i
urlbar-view-context-menu-open-in-window2 = Mở trong cửa sổ mới
    .accesskey = N
urlbar-view-context-menu-open-in-private-window2 = Mở trong cửa sổ riêng tư mới
    .accesskey = P
urlbar-view-context-menu-search-in-tab = Tìm trong thẻ mới
    .accesskey = w
urlbar-view-context-menu-search-in-container-tab = Tìm kiếm trong thẻ ngăn chứa mới
    .accesskey = i
urlbar-view-context-menu-search-in-window = Tìm kiếm trong cửa sổ mới
    .accesskey = N
urlbar-view-context-menu-search-in-private-window = Tìm kiếm trong cửa sổ riêng tư mới
    .accesskey = P
# A checkable menu item that controls whether pressing the Tab key while
# navigating the address bar results stops on each result's menu button. When
# checked, the Tab key moves straight from one result to the next, skipping the
# menu button that opens this menu.
urlbar-view-context-menu-skip-menu-with-tab = Bỏ qua menu này khi sử dụng phím tab.
    .accesskey = S

## Labels shown above groups of urlbar results

# A label shown above the "Firefox Suggest" (bookmarks/history) group in the
# urlbar results.
urlbar-group-firefox-suggest =
    .label = { -firefox-suggest-brand-name }
# A label shown above the search suggestions group in the urlbar results. It
# should use sentence case.
# Variables
#  $engine (String): the name of the search engine providing the suggestions
urlbar-group-search-suggestions =
    .label = Đề xuất của { $engine }
# A label shown above Quick Actions in the urlbar results.
urlbar-group-quickactions =
    .label = Hành động nhanh
# A label shown above the recent searches group in the urlbar results.
# Variables
#  $engine (String): the name of the search engine used to search.
urlbar-group-recent-searches =
    .label = Tìm kiếm gần đây
# The header shown above trending results.
# Variables:
#  $engine (String): the name of the search engine providing the trending suggestions
urlbar-group-trending =
    .label = Đang thịnh hành trên { $engine }
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show3 = Không hiển thị các tìm kiếm thịnh hành
    .accesskey = n
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show2 = Không hiển thị các tìm kiếm thịnh hành
    .accesskey = K
# The result menu labels shown next to trending results.
urlbar-result-menu-trending-dont-show =
    .label = Không hiển thị các tìm kiếm thịnh hành
    .accesskey = K
# A message that replaces a result when the user dismisses all suggestions of a
# particular type.
urlbar-trending-dismissal-acknowledgment = Cảm ơn phản hồi của bạn. Bạn sẽ không thấy các tìm kiếm thịnh hành nữa.

## Reader View toolbar buttons

# This should match menu-view-enter-readerview in menubar.ftl
reader-view-enter-button =
    .aria-label = Vào chế độ đọc sách
# This should match menu-view-close-readerview in menubar.ftl
reader-view-close-button =
    .aria-label = Đóng chế độ đọc sách

## Picture-in-Picture urlbar button
## Variables:
##   $shortcut (String) - Keyboard shortcut to execute the command.

picture-in-picture-urlbar-button-open =
    .tooltiptext = Mở hình trong hình ({ $shortcut })
picture-in-picture-urlbar-button-close =
    .tooltiptext = Đóng hình trong hình ({ $shortcut })
picture-in-picture-panel-header = Hình trong hình
picture-in-picture-panel-headline = Trang web này không khuyến nghị hình trong hình
picture-in-picture-panel-body = Video có thể không hiển thị như ý định của nhà phát triển khi hình trong hình được bật.
picture-in-picture-enable-toggle =
    .label = Vẫn bật

## Full Screen and Pointer Lock UI

# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is full screen, e.g. "mozilla.org"
fullscreen-warning-domain = <span data-l10n-name="domain">{ $domain }</span> giờ đã hiển thị toàn màn hình
fullscreen-warning-no-domain = Trang này giờ đã hiển thị toàn màn hình
fullscreen-exit-button = Thoát toàn màn hình (Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-exit-mac-button = Thoát toàn màn hình (esc)
fullscreen-keyboardlock-exit-button = Thoát toàn màn hình (nhấn và giữ Esc)
# "esc" is lowercase on mac keyboards, but uppercase elsewhere.
fullscreen-keyboardlock-exit-mac-button = Thoát toàn màn hình (nhấn và giữ esc)
# Please ensure that the domain stays in the `<span data-l10n-name="domain">` markup.
# Variables
#  $domain (String): the domain that is using pointer-lock, e.g. "mozilla.org"
pointerlock-warning-domain = <span data-l10n-name="domain">{ $domain }</span> có quyền điều khiển con trỏ của bạn. Ấn Esc để lấy lại quyền điều khiển.
pointerlock-warning-no-domain = Trang này có quyền điều khiển con trỏ của bạn. Ấn Esc để lấy lại quyền điều khiển.

## Bookmarks panels, menus and toolbar

bookmarks-manage-bookmarks =
    .label = Quản lý dấu trang
bookmarks-recent-bookmarks-panel-subheader = Dấu trang gần đây
bookmarks-toolbar-chevron =
    .tooltiptext = Hiển thị thêm dấu trang
bookmarks-sidebar-content =
    .aria-label = Dấu trang
bookmarks-menu-button =
    .label = Trình đơn dấu trang
bookmarks-other-bookmarks-menu =
    .label = Dấu trang khác
bookmarks-mobile-bookmarks-menu =
    .label = Dấu trang trên di động

## Variables:
##   $isVisible (boolean): if the specific element (e.g. bookmarks sidebar,
##                         bookmarks toolbar, etc.) is visible or not.

bookmarks-tools-sidebar-visibility =
    .label =
        { $isVisible ->
            [true] Ẩn thanh lề dấu trang
           *[other] Hiển thị thanh lề dấu trang
        }
bookmarks-tools-toolbar-visibility-menuitem =
    .label =
        { $isVisible ->
            [true] Ẩn thanh công cụ dấu trang
           *[other] Hiển thị thanh công cụ dấu trang
        }
bookmarks-tools-toolbar-visibility-panel =
    .label =
        { $isVisible ->
            [true] Ẩn thanh dấu trang
           *[other] Hiển thị thanh dấu trang
        }

##

bookmarks-search =
    .label = Tìm kiếm dấu trang
bookmarks-tools =
    .label = Công cụ đánh dấu trang
bookmarks-subview-edit-bookmark =
    .label = Chỉnh sửa dấu trang này…
# The aria-label is a spoken label that should not include the word "toolbar" or
# such, because screen readers already know that this container is a toolbar.
# This avoids double-speaking.
bookmarks-toolbar =
    .aria-label = Dấu trang
    .toolbarname = Thanh dấu trang
    .accesskey = B
bookmarks-toolbar-menu =
    .label = Thanh dấu trang
bookmarks-toolbar-placeholder =
    .title = Các mục của thanh dấu trang
bookmarks-toolbar-placeholder-button =
    .label = Các mục của thanh dấu trang
# "Bookmark" is a verb, as in "Add current tab to bookmarks".
bookmarks-subview-bookmark-tab =
    .label = Đánh dấu thẻ hiện tại…

## Library Panel items

library-bookmarks-menu =
    .label = Dấu trang

## Repair text encoding toolbar button

repair-text-encoding-button =
    .label = Sửa chữa mã hóa văn bản
    .tooltiptext = Đoán mã hóa văn bản chính xác từ nội dung trang

## Variables:
##  $shortcut (String): keyboard shortcut to perform the action

# Variables:
#  $shortcut (String): keyboard shortcut to open settings (only on macOS)
toolbar-settings-button =
    .label = Cài đặt
    .tooltiptext =
        { PLATFORM() ->
            [macos] Mở cài đặt ({ $shortcut })
           *[other] Mở cài đặt
        }
toolbar-overflow-customize-button =
    .label = Tùy biến thanh công cụ…
    .accesskey = C
toolbar-button-email-link =
    .label = Gửi liên kết này qua email
    .tooltiptext = Gửi một thư điện tử chứa liên kết tới trang này
toolbar-button-logins =
    .label = Mật khẩu
    .tooltiptext = Xem và quản lý mật khẩu đã lưu của bạn
qrcode-panel-error =
    .message = Không thể tạo mã QR. Vui lòng thử lại.
qrcode-copy-button =
    .label = Sao chép
qrcode-copy-success =
    .message = Đã sao chép mã QR vào bộ nhớ tạm.
qrcode-copy-error =
    .message = Không thể sao chép mã QR.
qrcode-save-button =
    .label = Lưu
qrcode-window-title = Mã QR
qrcode-dialog-title = Mã QR
qrcode-image =
    .aria-label = Mã QR
qrcode-close-button =
    .aria-label = Đóng
toolbar-button-save-page =
    .label = Lưu trang
    .tooltiptext = Lưu trang này ({ $shortcut })
toolbar-button-open-file =
    .label = Mở tập tin
    .tooltiptext = Mở một tập tin ({ $shortcut })
toolbar-button-synced-tabs =
    .label = Các thẻ đã đồng bộ
    .tooltiptext = Hiện thẻ từ các thiết bị khác
toolbar-button-send-tab =
    .label = Gửi thẻ
    .tooltiptext = Gửi thẻ hiện tại sang thiết bị khác
toolbar-button-new-private-window =
    .label = Cửa sổ riêng tư mới
    .tooltiptext = Mở một cửa sổ duyệt web riêng tư mới ({ $shortcut })
toolbar-button-share-tab =
    .label = Chia sẻ
    .tooltiptext = Chia sẻ trang này
toolbar-button-tab-groups =
    .label = Nhóm thẻ
    .tooltiptext = Xem nhóm thẻ của bạn
toolbar-button-history =
    .label = Lịch sử
    .tooltiptext = Hiển thị lịch sử của bạn ({ $shortcut })
toolbar-button-find =
    .label = Tìm
    .tooltiptext = Tìm trong trang này ({ $shortcut })
toolbar-button-developer =
    .label = Nhà phát triển
    .tooltiptext = Mở công cụ nhà phát triển Web ({ $shortcut })
toolbar-button-forget =
    .label = Xóa
    .tooltiptext = Xóa một số lịch sử duyệt web
toolbar-zoom-controls =
    .label = Chỉnh kích thước
    .title = Chỉnh kích thước
toolbar-button-zoom-out =
    .label = Thu nhỏ
    .tooltiptext = Thu nhỏ ({ $shortcut })
toolbar-button-zoom-reset-tooltip = Đặt lại mức độ thu phóng ({ $shortcut })
toolbar-button-zoom-in =
    .label = Phóng to
    .tooltiptext = Phóng to ({ $shortcut })
toolbar-edit-controls =
    .label = Các nút chỉnh sửa nội dung
    .title = Các nút chỉnh sửa nội dung
toolbar-button-cut =
    .label = Cắt
    .tooltiptext = Cắt ({ $shortcut })
toolbar-button-copy =
    .label = Sao chép
    .tooltiptext = Sao chép ({ $shortcut })
toolbar-button-paste =
    .label = Dán
    .tooltiptext = Dán ({ $shortcut })

## Default filenames used when saving a QR code. The file extension (.png)
## is added automatically.

qrcode-save-filename-base = qrcode
# Variables:
#  $domain (String): The current page's domain used in the suggested filename.
qrcode-save-filename-with-domain-base = qrcode-{ $domain }

## EME notification panel

eme-notifications-drm-content-playing = Một số nguồn audio và video trên trang này có sử dụng phần mềm DRM bảo vệ bản quyền nên một số thao tác có thể bị giới hạn với { -brand-short-name }.
eme-notifications-drm-content-playing-manage = Quản lý cài đặt
eme-notifications-drm-content-playing-manage-accesskey = M
eme-notifications-drm-content-playing-dismiss = Bỏ qua
eme-notifications-drm-content-playing-dismiss-accesskey = D

## Notification bars for media playback issues

eme-notifications-drm-content-disabled-message = Bạn phải kích hoạt DRM để phát một số âm thanh hoặc video trên trang này.
eme-notifications-drm-content-disabled-button =
    .label = Kích hoạt DRM
    .accesskey = E
eme-notifications-drm-content-cdm-installing-message = { -brand-short-name } đang cài đặt các thành phần cần thiết để xem audio hay video trên trang này. Xin hãy thử lại sau.
decoder-doctor-no-codecs-linux-message = Để phát video, bạn có thể cần phải cài codec.
decoder-doctor-no-hw-acceleration-message = Để cải thiện chất lượng video, bạn có thể cần phải cài Media Feature Pack của Microsoft.
decoder-doctor-no-pulse-audio-message = Để phát âm thanh, bạn có thể cần phải cài phần mềm PulseAudio.
decoder-doctor-unsupported-libavcodec-message = libavcodec có thể bị tấn công hoặc không được hỗ trợ, và nên được cập nhật để phát video.
decoder-doctor-decode-error-message = Đã xảy ra lỗi khi mã hóa một tài nguyên phương tiện truyền thông.
decoder-doctor-decode-warning-message = Việc khôi phục đã xảy ra lỗi khi mã hóa một tài nguyên phương tiện truyền thông.
decoder-doctor-learn-how-link = Tìm hiểu làm thế nào
decoder-doctor-report-issue-button =
    .label = Báo cáo vấn đề về trang
    .accesskey = R
# Variables:
#   $pluginName (String) - The name of the media plugin that crashed (for example, “Widevine Content Decryption Module”).
plugin-crashed-notification-message = Phần bổ trợ { $pluginName } đã bị lỗi.
plugin-crashed-notification-reload-button =
    .label = Tải lại trang này
    .accesskey = R
plugin-crashed-notification-submit-button =
    .label = Gửi báo cáo lỗi
    .accesskey = S

## Notification bar shown after the user chooses to visit a site flagged by Safe Browsing

safebrowsing-deceptive-site-message = Trang web lừa đảo!
safebrowsing-reported-attack-site-message = Có người báo đây là trang web có ác ý!
safebrowsing-reported-unwanted-site-message = Trang này có nghi ngờ cài đặt phần mềm không mong muốn!
safebrowsing-reported-harmful-site-message = Báo cáo trang web độc hại!
safebrowsing-get-me-out-of-here-button =
    .label = Đưa tôi ra khỏi đây!
    .accesskey = G
safebrowsing-not-a-deceptive-site-button =
    .label = Đây không phải là một trang lừa đảo…
    .accesskey = D
safebrowsing-not-an-attack-site-button =
    .label = Trang này không có ác ý…
    .accesskey = A

## Notification bar shown when a captive portal is blocking network access
## and requires the user to log in before browsing.

captive-portal-info-message = Bạn phải đăng nhập vào hệ thống này trước khi bạn có thể truy cập Internet.
# Shown in all tabs except the login page tab. Clicking it shows the portal
# login page tab.
captive-portal-show-login-page-button =
    .label = Mở trang đăng nhập hệ thống

## Notification bar shown when the user tries to visit a local host, but a
## search page was already loaded for the given word by the time the DNS
## request recognized it.
## Variables:
##   $hostName (String) - The recognized host (for example, “http://example/”).

keyword-uri-fixup-message = Có phải bạn muốn truy cập { $hostName }?
keyword-uri-fixup-go-to-button =
    .label = Đúng, đưa tôi đến { $hostName }
    .accesskey = Y

## Password save/update panel

panel-save-update-username-2 =
    .label = Tên đăng nhập
panel-save-update-password-2 =
    .label = Mật khẩu

##

# "More" item in macOS share menu
menu-share-more =
    .label = Xem thêm…
menu-share-windows =
    .label = Tùy chọn khác
# Variables:
#   $count (Number) - The number of links that will be copied.
menu-share-copy-links =
    .label = Sao chép { $count } liên kết
    .accesskey = L
ui-tour-info-panel-close =
    .tooltiptext = Đóng

## Variables:
##  $uriHost (String): URI host for which the popup was allowed or blocked.

popups-infobar-allow2 =
    .label = Cho phép cửa sổ bật lên và chuyển hướng của bên thứ ba cho { $uriHost }
    .accesskey = p

##

picture-in-picture-hide-toggle =
    .label = Ẩn nút hình trong hình
    .accesskey = H

## Since the default position for PiP controls does not change for RTL layout,
## right-to-left languages should use "Left" and "Right" as in the English strings,

picture-in-picture-move-toggle-right =
    .label = Chuyển chế độ hình trong hình sang phải
    .accesskey = R
picture-in-picture-move-toggle-left =
    .label = Chuyển chế độ hình trong hình sang trái
    .accesskey = L

##

# This string is a spoken label that should not include
# the word "toolbar" or such, because screen readers already know that
# this container is a toolbar. This avoids double-speaking.
navbar-accessible =
    .aria-label = Điều hướng
navbar-downloads =
    .label = Tải xuống
navbar-overflow-2 =
    .tooltiptext = Công cụ khác
# Variables:
#   $shortcut (String): keyboard shortcut to print the page
navbar-print =
    .label = In
    .tooltiptext = In trang này… ({ $shortcut })
navbar-home =
    .label = Trang chủ
    .tooltiptext = { -brand-short-name } Trang Chủ
navbar-library =
    .label = Thư viện
    .tooltiptext = Xem lịch sử, dấu trang đã lưu và nhiều hơn nữa
navbar-search =
    .title = Tìm kiếm
# Name for the tabs toolbar as spoken by screen readers. The word
# "toolbar" is appended automatically and should not be included in
# in the string
tabs-toolbar =
    .aria-label = Thẻ trình duyệt
tabs-toolbar-new-tab =
    .label = Thẻ mới
tabs-toolbar-list-all-tabs-2 =
    .label = Tìm kiếm và quản lý thẻ
    .tooltiptext = Tìm kiếm và quản lý thẻ
tabs-toolbar-list-all-tabs =
    .label = Liệt kê tất cả các thẻ
    .tooltiptext = Liệt kê tất cả các thẻ

## Drop indicator text for pinned tabs when no tabs are pinned.

pinned-tabs-drop-indicator = Thả thẻ ở đây để ghim

## Infobar shown at startup to suggest session-restore

# <img data-l10n-name="icon"/> will be replaced by the application menu icon
restore-session-startup-suggestion-message = <strong>Đã mở các thẻ trước đó?</strong> Bạn có thể khôi phục phiên trước đó của mình từ menu ứng dụng { -brand-short-name } <img data-l10n-name="icon"/>, trong mục Lịch sử.
restore-session-startup-suggestion-button = Hướng dẫn cho tôi

## Infobar shown when the user tries to open a file picker and file pickers are blocked by enterprise policy

filepicker-blocked-infobar = Tổ chức của bạn đã chặn quyền truy cập vào các tập tin cục bộ trên máy tính này

## Address bar result shown when someone who used the Extensions and Themes
## keyboard shortcut presses that shortcut after it moved to Search Tabs.
## Variables:
##   $searchTabsShortcut (String) - The Search Tabs keyboard shortcut, e.g. "Ctrl+Shift+A".
##   $addonsShortcut (String) - The Extensions and Themes keyboard shortcut, e.g. "Ctrl+Shift+F".

urlbar-addons-shortcut-moved-title = { $searchTabsShortcut } hiện tìm kiếm các thẻ
urlbar-addons-shortcut-moved-description = Để mở tiện ích mở rộng và chủ đề, sử dụng { $addonsShortcut }.
urlbar-addons-shortcut-moved-change-shortcuts = Quản lý phím tắt
urlbar-addons-shortcut-moved-dismiss = Đã hiểu

## Mozilla data reporting notification (Telemetry, Firefox Health Report, etc)

data-reporting-notification-message = { -brand-short-name } tự động gửi dữ liệu về { -vendor-short-name } để chúng tôi có thể cải thiện trải nghiệm của bạn.
data-reporting-notification-button =
    .label = Chọn những thứ tôi muốn chia sẻ
    .accesskey = C
# Label for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-label = Duyệt web riêng tư
# Tooltip for the indicator shown in the private browsing window titlebar.
private-browsing-indicator-tooltip =
    .tooltiptext = Duyệt web riêng tư
# Tooltip for the private browsing indicator button that opens the info panel.
private-browsing-indicator-button =
    .tooltiptext = Thông tin duyệt web riêng tư
# Title shown in the private browsing info panel.
private-browsing-info-panel-title = Bạn đang ở cửa sổ riêng tư
# Body copy shown in the private browsing info panel. The learn-more link text
# is embedded in the sentence.
private-browsing-info-panel-description = Điều này giúp ẩn hoạt động duyệt web của bạn khỏi người khác trên thiết bị này, nhưng không làm cho bạn trở nên vô hình trên mạng. <a data-l10n-name="learn-more">Ai có thể xem được hoạt động của tôi?</a>
# Tooltip for the indicator shown in the window titlebar when content analysis is active.
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-indicator-tooltip =
    .tooltiptext = Ngăn ngừa mất dữ liệu (DLP) bởi { $agentName }. Nhấp vào đây để biết thêm thông tin.
content-analysis-panel-title2 = Ngăn ngừa mất dữ liệu
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled2 = Tổ chức của bạn sử dụng <b>{ $agentName }</b> để kiểm soát cách thức chia sẻ dữ liệu nhạy cảm. <a data-l10n-name="info">Tìm hiểu thêm</a>
content-analysis-panel-title = Bảo vệ dữ liệu
# Variables:
#   $agentName (String): The name of the DLP agent that is connected
content-analysis-panel-text-styled = Tổ chức của bạn sử dụng <b>{ $agentName }</b> để bảo vệ chống mất dữ liệu. <a data-l10n-name="info">Tìm hiểu thêm</a>

## Unified extensions (toolbar) button

unified-extensions-button =
    .label = Tiện ích mở rộng
    .tooltiptext = Tiện ích mở rộng

## Unified extensions button when permission(s) are needed.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-permissions-needed =
    .label = Tiện ích mở rộng
    .tooltiptext =
        Tiện ích mở rộng
        Cần yêu cầu quyền hạn

## Unified extensions button when some extensions are quarantined.
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-quarantined =
    .label = Tiện ích mở rộng
    .tooltiptext =
        Tiện ích mở rộng
        Vài tiện ích mở rộng không được phép

## Unified extensions button when some extensions are disabled (e.g. through add-ons blocklist).
## Note that the new line is intentionally part of the tooltip.

unified-extensions-button-blocklisted =
    .label = Tiện ích mở rộng
    .tooltiptext = Một số tiện ích mở rộng bị tắt

## Private browsing reset button

reset-pbm-panel-heading2 = Xoá dữ liệu và bắt đầu phiên riêng tư mới?
reset-pbm-panel-description3 = Thao tác này sẽ xoá lịch sử duyệt web và cookie, đồng thời đăng xuất bạn khỏi các trang web. Cửa sổ duyệt web riêng tư của bạn sẽ đóng lại và một cửa sổ mới sẽ mở ra.
reset-pbm-panel-description2 = Thao tác này sẽ xoá lịch sử, cookie và tất cả dữ liệu khác của trang web mà không đóng Cửa sổ riêng tư.
reset-pbm-panel-always-ask-checkbox =
    .label = Luôn hỏi tôi
    .accesskey = A
reset-pbm-panel-cancel-button =
    .label = Hủy bỏ
    .accesskey = C
reset-pbm-panel-confirm-button2 =
    .label = Xoá phiên riêng tư
    .accesskey = l
reset-pbm-panel-complete = Đã xóa dữ liệu phiên riêng tư
reset-pbm-toolbar-button2 =
    .label = Xoá phiên riêng tư
    .tooltiptext = Xoá phiên riêng tư

## Fire button. Clears the whole browsing session, then closes every window and
## opens a new one.

fire-button-panel-heading = Xoá toàn bộ dữ liệu duyệt web?
fire-button-panel-description = Thao tác này sẽ xóa lịch sử, cookie và dữ liệu trang web. Bạn sẽ bị đăng xuất khỏi trang web. Cửa sổ này sẽ đóng lại và { -brand-short-name } sẽ mở một cửa sổ mới.
fire-button-panel-choose-description = Nếu bạn không muốn xóa toàn bộ, hãy chọn xóa dữ liệu cụ thể.
# Opens the "Delete browsing data" dialog, where the user picks
# which kinds of data to delete. The trailing ellipsis marks that a dialog
# follows rather than the action happening immediately.
fire-button-panel-choose-link = Chọn…
fire-button-panel-cancel-button =
    .label = Huỷ bỏ
    .accesskey = H
fire-button-panel-confirm-button =
    .label = Xoá tất cả
    .accesskey = D
fire-button-panel-complete = Đã xoá dữ liệu duyệt web
fire-button-toolbar-button2 =
    .label = Xoá một phần hoặc toàn bộ dữ liệu
    .tooltiptext = Xoá một phần hoặc toàn bộ dữ liệu duyệt web của bạn

## Autorefresh blocker

refresh-blocked-refresh-label = { -brand-short-name } đã ngăn trang web này tự động tải lại.
refresh-blocked-redirect-label = { -brand-short-name } đã ngăn trang web này tự động chuyển đến trang khác.
refresh-blocked-allow =
    .label = Cho phép
    .accesskey = A

## Firefox Relay integration

firefox-relay-offer-why-to-use-relay = Mặt nạ an toàn, dễ sử dụng của chúng tôi bảo vệ danh tính của bạn và ngăn chặn thư rác bằng cách ẩn địa chỉ email của bạn.
# Variables:
#  $useremail (String): user email that will receive messages
firefox-relay-offer-what-relay-provides = Tất cả email gửi đến email ẩn danh của bạn sẽ được chuyển đến <strong>{ $useremail }</strong> (trừ khi bạn quyết định chặn chúng).
firefox-relay-offer-legal-notice = Bằng cách nhấp vào “Sử dụng email ẩn danh”, bạn đồng ý với <label data-l10n-name="tos-url">điều khoản sử dụng</label> và <label data-l10n-name="privacy-url">thông báo về quyền riêng tư</label>.
firefox-relay-offer-legal-notice-1 = Bằng cách đăng ký và tạo email ẩn danh, bạn đồng ý với <label data-l10n-name="tos-url">điều khoản sử dụng</label> và <label data-l10n-name="privacy-url">thông báo về quyền riêng tư</label>.

## Add-on Pop-up Notifications

popup-notification-addon-install-unsigned =
    .value = (Chưa xác thực)
popup-notification-xpinstall-prompt-learn-more = Tìm hiểu thêm về cách cài đặt tiện ích một cách an toàn
popup-notification-xpinstall-prompt-block-url = Xem chi tiết
# Note: Access key is set to p to match "private" in the corresponding localized label.
popup-notification-addon-privatebrowsing-checkbox2 =
    .label = Cho phép tiện ích chạy trong cửa sổ riêng tư
    .accesskey = p
# This string is similar to `webext-perms-description-data-long-technicalAndInteraction`
# but it is used in the install prompt, and it needs an access key.
popup-notification-addon-technical-and-interaction-checkbox =
    .label = Chia sẻ dữ liệu kỹ thuật và tương tác với nhà phát triển tiện ích mở rộng
    .accesskey = S

## Pop-up warning

# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-message = { -brand-short-name } đã chặn trang web này mở { $popupCount } cửa sổ bật lên.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
redirect-warning-with-popup-message =
    { $popupCount ->
        [0] { -brand-short-name } đã chặn trang web này chuyển hướng.
        [1] { -brand-short-name } đã chặn trang web này mở một cửa sổ bật lên và chuyển hướng.
       *[other] { -brand-short-name } đã chặn trang web này mở { $popupCount } cửa sổ bật lên và chuyển hướng.
    }
# The singular form is left out for English, since the number of blocked pop-ups is always greater than 1.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-message = { -brand-short-name } đã ngăn trang web này mở nhiều hơn { $popupCount } cửa sổ bật lên.
# Variables:
#   $popupCount (Number): the number of pop-ups blocked.
popup-warning-exceeded-with-redirect-message =
    { $popupCount ->
       *[other] { -brand-short-name } đã chặn trang web này mở nhiều hơn { $popupCount } cửa sổ bật lên và chuyển hướng.
    }
popup-warning-button =
    .label =
        { PLATFORM() ->
            [windows] Tùy chọn
           *[other] Tùy chỉnh
        }
    .accesskey =
        { PLATFORM() ->
            [windows] O
           *[other] P
        }
# Variables:
#   $popupURI (String): the URI for the pop-up window
popup-show-popup-menuitem =
    .label = Hiển thị '{ $popupURI }'
# Variables:
#   $redirectURI (String): the URI for the redirect
popup-trigger-redirect-menuitem =
    .label = Hiện “{ $redirectURI }”

## File-picker crash notification ("FilePickerCrashed.sys.mjs")

file-picker-failed-open = Không thể mở hộp thoại tập tin Windows. Không thể chọn tập tin hoặc thư mục.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-failed-save-somewhere = Không thể mở hộp thoại tập tin Windows. Tập tin sẽ được lưu vào { $path }.
file-picker-failed-save-nowhere = Không thể mở hộp thoại tập tin Windows. Không tìm thấy thư mục mặc định; tập tin sẽ không được lưu.
file-picker-crashed-open = Không thể mở hộp thoại tập tin Windows. Không thể chọn tập tin hoặc thư mục.
#   $path (string): The full path to which the file will be saved (e.g., 'C:\Users\Default User\Downloads\readme.txt').
file-picker-crashed-save-somewhere = Hộp thoại tập tin Windows đã bị lỗi. Tập tin sẽ được lưu vào { $path }.
file-picker-crashed-save-nowhere = Hộp thoại tập tin Windows đã bị lỗi. Không tìm thấy thư mục mặc định; tập tin sẽ không được lưu.
file-picker-crashed-show-in-folder =
    .label = Hiển thị trong thư mục
    .accessKey = F

## Unsigned add-ons notification

unsigned-addons-disabled-message = Một số tiện ích đã cài đặt không thể được kiểm định nên đã bị vô hiệu hóa.
unsigned-addons-disabled-learn-more =
    .label = Tìm hiểu thêm
    .accesskey = L

## Process hang notification ("ProcessHangMonitor.sys.mjs")

process-hang-selected-tab-message = Trang này đang làm chậm { -brand-short-name }. Để tăng tốc trình duyệt của bạn, hãy dừng trang này.
process-hang-nonspecific-tab-message = Một trang web đang làm chậm { -brand-short-name }. Để tăng tốc trình duyệt của bạn, hãy dừng trang này.
# Variables:
#   $title (String): the title of the tab.
process-hang-specific-tab-message = “{ $title }” đang làm chậm { -brand-short-name }. Để tăng tốc trình duyệt của bạn, hãy dừng trang đó lại.
# Variables:
#   $addonName (String): the name of the extension.
process-hang-addon-message = “{ $addonName }” đang làm chậm { -brand-short-name }. Để tăng tốc trình duyệt của bạn, hãy dừng tiện ích đó lại.
process-hang-addon-learn-more =
    .value = Tìm hiểu thêm
process-hang-stop-button =
    .label = Dừng
    .accesskey = S

## Onboarding Finish Setup checklist

onboarding-checklist-button-label = Hoàn tất thiết lập
onboarding-aw-finish-setup-button =
    .label = Hoàn tất thiết lập
    .tooltiptext = Hoàn tất thiết lập { -brand-short-name }

## The urlbar trust icon & panel

trustpanel-etp-label-enabled = Trình chống theo dõi nâng cao đang bật
trustpanel-etp-label-disabled = Trình chống theo dõi nâng cao đã tắt
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-on =
    .aria-label = Trình chống theo dõi nâng cao: Đang bật cho { $host }
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-etp-toggle-off =
    .aria-label = Trình chống theo dõi nâng cao: Đã tắt cho { $host }
trustpanel-etp-description-enabled = Nếu có gì đó bị hỏng trên trang web này, hãy thử tắt trình chống.
trustpanel-etp-description-disabled = { -brand-product-name } cho rằng các công ty nên theo dõi bạn ít hơn. Chúng tôi sẽ chặn càng nhiều trình theo dõi càng tốt khi bạn bật chế độ bảo vệ.
trustpanel-connection-label-secure = Kết nối an toàn
trustpanel-connection-label-insecure = Kết nối không an toàn
trustpanel-header-enabled = { -brand-product-name } đang bảo vệ
trustpanel-description-enabled2 = Bạn đã được bảo vệ. Nếu chúng tôi phát hiện ra điều gì đó, chúng tôi sẽ cho bạn biết.
trustpanel-header-enabled-insecure = Hãy cẩn thận trên trang web này
trustpanel-description-enabled-insecure = { -brand-product-name } nhận thấy điều gì đó đáng ngờ.
trustpanel-header-disabled = Bạn đã tắt trình chống
trustpanel-description-disabled = { -brand-product-name } không còn hoạt động. Chúng tôi khuyên bạn nên bật lại trình chống.
trustpanel-clear-cookies-button = Xóa cookie và dữ liệu trang web
trustpanel-privacy-link = Cài đặt quyền riêng tư
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-clear-cookies-header =
    .title = Xóa cookie và dữ liệu trang web cho { $host }
trustpanel-clear-cookies-description = Việc xóa cookie và dữ liệu trang web có thể khiến bạn đăng xuất khỏi các trang web và xóa giỏ hàng.
trustpanel-clear-cookies-subview-button-clear = Xóa
trustpanel-clear-cookies-subview-button-cancel = Hủy bỏ
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-site-information-header =
    .title = Bảo vệ kết nối cho { $host }
trustpanel-siteinformation-morelink = Thông tin thêm về trang web
trustpanel-blocker-see-all = Xem tất cả
# Variables
#  $host (String): the hostname of the site that is being displayed.
trustpanel-blocker-header =
    .title = Trình chống theo dõi cho { $host }
# LOCALIZATION NOTE (trustpanel-urlbar-notsecure-label):
# Keep this string as short as possible, this is displayed in the URL bar
# use a synonym for "safe" or "private" if "secure" is too long.
urlbar-trust-icon-notsecure-label = Không an toàn
# Keep this string as short as possible, this is displayed in the URL bar
# Variables
#  $count (number): the number of trackers blocked.
urlbar-trust-icon-trackers-blocked-longform-label = { $count } trình theo dõi bị chặn

## Variables
##  $count (String): the number of trackers blocked.

trustpanel-blocker-description = { -brand-product-name } cho rằng các công ty nên theo dõi bạn ít hơn. Vì vậy, chúng tôi chặn càng nhiều càng tốt.
trustpanel-blocked-header = { -brand-product-name } đã chặn những thứ này cho bạn:
trustpanel-tracking-header = { -brand-product-name } cho phép những điều này để các trang web không bị hỏng:
trustpanel-tracking-description = Nếu không có trình theo dõi, một số nút, biểu mẫu và trường đăng nhập có thể không hoạt động.
trustpanel-insecure-section-header = Kết nối của bạn không an toàn
trustpanel-insecure-description = Dữ liệu bạn gửi đến trang web này không được mã hóa. Dữ liệu có thể bị xem, đánh cắp hoặc thay đổi.
trustpanel-list-label-tracking-cookies = { $count } cookie theo dõi liên trang web
trustpanel-list-label-tracking-content = Trình theo dõi nội dung
trustpanel-list-label-fingerprinter = { $count } dấu vết
trustpanel-list-label-social-tracking = { $count } trình theo dõi truyền thông xã hội
trustpanel-list-label-cryptominer = { $count } trình đào tiền điện tử
trustpanel-social-tracking-blocking-tab-header = { -brand-product-name } đã chặn { $count } trình theo dõi truyền thông xã hội
trustpanel-social-tracking-not-blocking-tab-header = { -brand-product-name } đã cho phép { $count } trình theo dõi truyền thông xã hội
trustpanel-tracking-cookies-blocking-tab-header = { -brand-product-name } đã chặn { $count } cookie theo dõi liên trang web
trustpanel-tracking-cookies-not-blocking-tab-header = { -brand-product-name } đã cho phép { $count } cookie theo dõi liên trang web
trustpanel-tracking-content-blocking-tab-header = { -brand-product-name } đã chặn { $count } trình theo dõi
trustpanel-tracking-content-not-blocking-tab-header = { -brand-product-name } đã cho phép { $count } trình theo dõi
trustpanel-tracking-content-tab-list-header = Các trang web này đang cố gắng theo dõi bạn:
trustpanel-fingerprinter-blocking-tab-header = { -brand-product-name } đã chặn { $count } dấu vết
trustpanel-fingerprinter-not-blocking-tab-header = { -brand-product-name } đã cho phép { $count } dấu vết
trustpanel-fingerprinter-list-header = Những trang web này đang cố gắng lấy dấu vết của bạn:
trustpanel-cryptominer-blocking-tab-header = { -brand-product-name } đã chặn { $count } trình đào tiền điện tử
trustpanel-cryptominer-not-blocking-tab-header = { -brand-product-name } đã cho phép { $count } trình đào tiền điện tử
trustpanel-cryptominer-tab-list-header = Các trang web này đang cố gắng đào tiền điện tử:
# "account on this site" refers to the (breached) site the user is currently visiting, not a Mozilla Monitor account.
trustpanel-breachalerts-anonymous-breached-header = Đã có tài khoản trên trang web này?
trustpanel-breachalerts-anonymous-breached-description = { -brand-product-name } phát hiện trang web này đã bị rò rỉ dữ liệu trong vòng 12 tháng qua. Hãy tìm hiểu xem bạn có bị ảnh hưởng hay không.
trustpanel-breachalerts-anonymous-breached-button-dismiss = Bỏ qua
trustpanel-breachalerts-anonymous-breached-button-check-monitor = Bắt đầu quét miễn phí
trustpanel-blocker-section-header2 = <span data-l10n-name="count">{ $count }</span> trình theo dõi bị chặn trên trang web này

## Reduced Protection Infobar ("ReducedProtectionNotification.sys.mjs")

# "temporarily lower your tracking protection" refers to temporarily decreasing the amount of tracking protection.
reduced-protection-infobar-message = <strong>Trang web bị lỗi?</strong> Tải lại trang để tạm thời giảm mức độ trình chống theo dõi của bạn.
reduced-protection-infobar-reload-button = Tải lại
    .accesskey = R
reduced-protection-infobar-never-show-button = Đừng hiển thị lại
    .accesskey = D


identity-allow-site-data = vOrbit-lite: Luôn lưu cookie / dữ liệu cho trang web này
