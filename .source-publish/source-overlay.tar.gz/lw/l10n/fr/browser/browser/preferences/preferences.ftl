# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Demander aux sites web de ne pas vendre ni partager mes données
    .accesskey = D
non-technical-privacy-group =
    .label = Préférences de confidentialité des sites web
do-not-track-removal3 =
    .message = La fonctionnalité « Ne pas me pister » n’est plus prise en charge.
non-technical-privacy-heading =
    .label = Protections supplémentaires
preferences-privacy-relay-available =
    .description = Masque votre véritable adresse e-mail pour protéger votre boîte de réception du spam.
    .label = Suggérer des alias de messagerie { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Paramètres
category-nav-heading =
    .heading = Paramètres
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Rechercher dans les paramètres
    .style = width: 19.5em
managed-notice = Votre navigateur est géré par votre organisation.
managed-notice-info-icon =
    .alt = Informations
managed-notice-nav =
    .label = Votre navigateur est géré par votre organisation.
tls-key-logging-notice-nav =
    .label = Une application ou un service pourrait accéder à votre trafic chiffré.
category-list =
    .aria-label = Catégories
pane-general-title = Général
pane-home-title = Accueil
pane-home-startup-title2 = Accueil et démarrage
    .title = Accueil et démarrage
pane-search-title2 = Recherche
    .title = Recherche
pane-privacy-title3 = Vie privée et sécurité
    .title = Vie privée et sécurité
pane-privacy-section =
    .heading = Vie privée et sécurité
pane-sync-title3 = Synchronisation
pane-ai-controls-title2 = Contrôles de l’IA
    .title = Contrôles de l’IA
pane-about-firefox-title = À propos de { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Apparence
    .title = { pane-appearance-title }
pane-downloads-title2 = Téléchargements
    .title = Téléchargements
pane-downloads3 =
    .heading = Téléchargements
pane-accessibility-title = Accessibilité
    .title = { pane-accessibility-title }
pane-languages-title2 = Langues
    .title = Langues
preferences-languages-header3 =
    .heading = Langues
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Essayez nos fonctionnalités expérimentales ! Elles sont en cours de développement et évoluent, ce qui pourrait avoir un impact sur le fonctionnement de { -brand-short-name }. Nous ne recevons des données sur votre utilisation de ces fonctionnalités que si vous avez activé les <a data-l10n-name="data-collection">données techniques et d’interaction</a>.
pane-experimental-reset =
    .label = Configuration par défaut
    .accesskey = d
help-button-label2 = Assistance de { -brand-short-name }
    .title = Assistance de { -brand-short-name }
addons-button-label2 = Extensions et thèmes
    .title = Extensions et thèmes
focus-search =
    .key = f
close-button =
    .aria-label = Fermer
do-not-track-removal2 =
    .label = Le signal « Ne pas me pister » n’est plus pris en charge
applications-setting-new-file-types =
    .label = Que doit faire { -brand-short-name } des autres fichiers ?

## Browser Restart Dialog

feature-enable-requires-restart = { -brand-short-name } doit redémarrer pour activer cette fonctionnalité.
feature-disable-requires-restart = { -brand-short-name } doit redémarrer pour désactiver cette fonctionnalité.
should-restart-title = Redémarrer { -brand-short-name }
should-restart-ok = Redémarrer { -brand-short-name } maintenant
cancel-no-restart-button = Annuler
restart-later = Redémarrer plus tard

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = <img data-l10n-name="icon"/> <strong>{ $name }</strong> contrôle ce paramètre.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = <img data-l10n-name="icon"/> <strong>{ $name }</strong> contrôle ce paramètre.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> a besoin des onglets conteneurs.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = <img data-l10n-name="icon"/> <strong>{ $name }</strong> contrôle ce paramètre.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = <img data-l10n-name ="icon"/> <strong>{ $name }</strong> contrôle la manière dont { -brand-short-name } se connecte à Internet.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Pour activer l’extension, sélectionnez <img data-l10n-name="addons-icon"/> Modules complémentaires dans le menu <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Pour réactiver cette extension, consultez <a data-l10n-name="addons-link">Extensions et thèmes</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = { $name } contrôle certains des paramètres de votre page d’accueil.

## Preferences UI Search Results

search-results-header = Résultats de la recherche
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Désolé, il n’y a aucun résultat dans les paramètres pour « <span data-l10n-name="query"></span> ».
search-results-help-link = Besoin d’aide ? Consultez <a data-l10n-name="url">l’assistance de { -brand-short-name }</a>

## General Section

always-check-default =
    .label = Toujours vérifier que { -brand-short-name } est votre navigateur par défaut
    .accesskey = v
startup-restore-windows-and-tabs =
    .label = Ouvrir les fenêtres et onglets précédents
    .accesskey = O
startup-windows-launch-on-login-profile-disabled =
    .message = Activez cette préférence en cochant « { profile-manager-use-selected.label } » dans la fenêtre « Choisissez un profil utilisateur ».
windows-launch-on-login =
    .label = Ouvrir { -brand-short-name } automatiquement au démarrage de votre ordinateur
    .accesskey = O
windows-launch-on-login-disabled = Cette préférence a été désactivée dans Windows. Pour modifier ce paramètre, accédez aux <a data-l10n-name="startup-link">Applications de démarrage</a> dans les paramètres système.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Ouvrir également un nouvel onglet
    .accesskey = O
disable-extension =
    .label = Désactiver l’extension
preferences-data-migration-group =
    .description = Importez vos marque-pages, mots de passe, historique, extensions et données de remplissage automatique d’un autre navigateur.
    .label = Importer les données d’un navigateur
preferences-data-migration-button =
    .label = Importer des données
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profils
preferences-profiles-subpane-description =
    .description = Chaque profil dispose de données de navigation et de paramètres distincts, comme l’historique, les mots de passe, etc.
preferences-profiles-section-header =
    .description = Chaque profil dispose de données de navigation et de paramètres distincts, comme l’historique, les mots de passe, etc.
    .label = Profils
preferences-manage-profiles-button =
    .label = Gérer les profils
preferences-profiles-settings-button =
    .label = Paramètres
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Le nouveau profil copiera vos paramètres, vos modules complémentaires, votre historique et vos données enregistrées comme les marque-pages et les mots de passe, mais pas votre compte ni les informations de synchronisation.
    .label = Copier un profil existant
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Profil à copier
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Sélectionner un profil
preferences-copy-profile-button = Copier
tabs-browsing-section =
    .heading = Onglets et navigation
pane-tabs-browsing-title2 = Onglets et navigation
    .title = Onglets et navigation
tabs-group-header2 =
    .label = Onglets
tabs-opening-heading =
    .label = Ouverture
tabs-interaction-heading =
    .label = Interaction
tabs-containers-heading =
    .label = Conteneurs
tabs-closing-heading =
    .label = Fermeture
ctrl-tab-recently-used-order =
    .label = Ctrl+Tab fait défiler vos onglets en les classant selon leur dernière utilisation
    .accesskey = T
open-new-link-as-tabs =
    .label = Ouvrir les liens dans des onglets au lieu de nouvelles fenêtres
    .accesskey = f
open-external-link-next-to-active-tab =
    .label = Ouvrir les liens provenant d’applications à côté de l’onglet que vous consultez
ask-on-close-multiple-tabs =
    .label = Me demander avant de fermer plusieurs onglets
    .accesskey = M
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Me demander avant de quitter avec { $quitKey }
    .accesskey = e
warn-on-open-many-tabs =
    .label = Prévenir lors de l’ouverture de multiples onglets d’un ralentissement possible de { -brand-short-name }
    .accesskey = P
switch-to-new-tabs-2 =
    .label = Lors de l’ouverture de liens ou de médias dans un nouvel onglet, basculer vers celui-ci immédiatement
    .accesskey = L
show-tabs-in-taskbar =
    .label = Afficher les aperçus d’onglets dans la barre des tâches de Windows
    .accesskey = c
browser-containers-enabled-2 =
    .label = Utiliser les onglets conteneurs
    .accesskey = U
browser-containers-learn-more = En savoir plus
browser-containers-settings-2 =
    .label = Gérer les paramètres
    .accesskey = G
containers-disable-alert-title = Fermer tous les onglets conteneurs ?
startup-group =
    .label = Démarrage

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Si vous désactivez les onglets conteneurs maintenant, { $tabCount } onglet conteneur sera fermé. Voulez-vous vraiment désactiver les onglets conteneurs ?
       *[other] Si vous désactivez les onglets conteneurs maintenant, { $tabCount } onglets conteneurs seront fermés. Voulez-vous vraiment désactiver les onglets conteneurs ?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Fermer { $tabCount } onglet conteneur
       *[other] Fermer { $tabCount } onglets conteneurs
    }

##

containers-disable-alert-cancel-button = Garder activé
containers-remove-alert-title = Supprimer ce conteneur ?
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Si vous supprimez ce conteneur maintenant, { $count } onglet conteneur sera fermé. Voulez-vous vraiment supprimer ce conteneur ?
       *[other] Si vous supprimez ce conteneur maintenant, { $count } onglets conteneurs seront fermés. Voulez-vous vraiment supprimer ce conteneur ?
    }
containers-remove-ok-button = Supprimer ce conteneur
containers-remove-cancel-button = Ne pas supprimer ce conteneur
settings-tabs-show-image-in-preview =
    .label = Afficher un aperçu au survol des onglets
    .accessKey = A
settings-tabs-drag-to-create-tab-groups =
    .label = Rassembler des onglets pour créer des groupes d’onglets
browser-layout-header2 =
    .label = Disposition du navigateur
browser-layout-horizontal-tabs2 =
    .description = Onglets en haut
    .label = Onglets horizontaux
    .title = Onglets en haut
browser-layout-vertical-tabs2 =
    .description = Onglets sur le côté, dans le panneau latéral
    .label = Onglets verticaux
    .title = Onglets sur le côté, dans le panneau latéral
browser-layout-show-sidebar2 =
    .description = Accédez rapidement aux marque-pages, aux onglets de votre téléphone, aux chatbots IA et encore plus sans quitter l’affichage principal.
    .label = Afficher le panneau latéral
page-navigation-group =
    .label = Navigation dans les pages

## General Section - Language & Appearance

language-and-appearance-header = Langue et apparence
appearance-group2 =
    .description = Certains sites web modifient leurs couleurs pour correspondre à vos préférences. Choisissez votre jeu de couleurs.
    .label = Apparence des sites web
preferences-web-appearance-choice-auto3 =
    .label = Système
    .title = Modifiez automatiquement les arrière-plans et le contenu des sites web en fonction de vos paramètres système et du thème de { -brand-short-name }.
preferences-web-appearance-choice-light2 =
    .label = Clair
    .title = Utiliser un thème clair pour les arrière-plans et le contenu des sites web.
preferences-web-appearance-choice-dark2 =
    .label = Sombre
    .title = Utiliser un thème sombre pour les arrière-plans et le contenu des sites web.
web-appearance-group =
    .aria-label = Apparence des sites web
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Vos paramètres de contrôle du contraste modifient l’apparence des sites web.
preferences-web-appearance-link =
    .label = Gérez les thèmes de { -brand-short-name } depuis la section Extensions et thèmes
preferences-contrast-control-group =
    .description = Les sites web utilisent beaucoup de couleurs différentes pour le premier plan et l’arrière-plan. Pour un contraste cohérent, vous pouvez utiliser les mêmes couleurs d’un site à l’autre.
    .label = Contraste des sites web
preferences-contrast-control-radio-group =
    .label = Remplacer les couleurs
preferences-contrast-control-use-platform-settings =
    .label = Automatique (utiliser les paramètres système)
    .accesskey = A
preferences-contrast-control-off =
    .label = Désactivé
    .accesskey = D
preferences-contrast-control-custom =
    .label = Personnalisé
    .accesskey = P
preferences-colors-manage-button2 =
    .label = Gérer les couleurs
    .accesskey = c
preferences-colors-manage-button =
    .label = Gérer les couleurs…
    .accesskey = c
preferences-fonts-header2 =
    .label = Polices
preferences-default-zoom-label =
    .label = Zoom par défaut
    .accesskey = Z
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage } %
preferences-zoom-text-only =
    .label = Agrandir uniquement le texte
    .accesskey = A
preferences-text-zoom-override-warning2 =
    .message = Si « Agrandir uniquement le texte » est activé et que votre niveau de zoom par défaut n’est pas à 100 %, certains sites peuvent ne pas afficher correctement le contenu.
language-header = Langue
choose-language-description = Choix de la langue préférée pour l’affichage des pages
website-language-heading =
    .description = Certaines pages web sont disponibles en plusieurs langues. Choisissez les langues dans l’ordre de votre choix.
    .label = Langue des sites web
website-preferred-language =
    .label = Langues préférées
website-language-list =
    .aria-label = Langues préférées
website-add-language =
    .label = Ajouter une langue
website-add-language-button =
    .aria-label = Ajouter la langue sélectionnée
    .title = Ajouter la langue sélectionnée
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Supprimer { $locale }
    .title = Supprimer { $locale }
choose-button =
    .label = Choisir…
    .accesskey = o
choose-browser-language-description = Choisissez en quelle langue doivent s’afficher les menus, messages et notifications de { -brand-short-name }.
manage-browser-languages-button =
    .label = Choisir des alternatives…
    .accesskey = a
confirm-browser-language-change-description = Redémarrer { -brand-short-name } pour appliquer ces changements
confirm-browser-language-change-button = Appliquer et redémarrer
browser-language-heading =
    .description = Choisissez la langue utilisée pour afficher les menus, messages et notifications de { -brand-short-name }.
    .label = Langue du navigateur
browser-language-preferred-label =
    .label = Langue préférée
browser-language-fallback-label =
    .description = Utilisée lorsque la traduction dans la langue préférée est incomplète.
    .label = Langue de remplacement
browser-language-install-error =
    .message = { -brand-short-name } ne peut pas mettre à jour vos langues pour l’instant. Vérifiez votre connexion à Internet ou réessayez.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Exceptions…
    .accesskey = x
settings-translations-header =
    .aria-label = Traductions
    .description = Traduire des pages ou du texte sélectionné. Pour protéger votre vie privée, les traductions restent sur votre appareil.
    .label = Traductions
settings-translations-offer-to-translate-label =
    .label = Proposer une traduction complète de la page
settings-translations-more-settings-button =
    .description = Définissez des préférences de langue, de sites web et de traduction hors connexion.
    .label = Plus de paramètres de traduction
settings-translations-subpage-header =
    .heading = Plus de paramètres de traduction
settings-translations-subpage-speed-up-translation-header =
    .description = Télécharger les langues complètes pour des traductions plus rapides et pour traduire hors connexion.
    .label = Accélérer la traduction
settings-translations-subpage-automatic-translation-header =
    .label = Traduction automatique
settings-translations-subpage-always-translate-header =
    .label = Toujours traduire ces langues
settings-translations-subpage-never-translate-header =
    .label = Ne jamais traduire ces langues
settings-translations-subpage-never-translate-sites-header =
    .label = Ne jamais traduire ces sites
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Pour ajouter un site, ouvrez le panneau des traductions <img data-l10n-name="translations-icon"/>, sélectionnez les paramètres de traduction <img data-l10n-name="settings-icon"/>, puis choisissez « Ne jamais traduire ce site »
settings-translations-subpage-language-select-option =
    .label = Ajouter une langue
settings-translations-subpage-language-add-button =
    .aria-label = Ajouter une langue
    .title = Ajouter une langue
settings-translations-subpage-download-languages-header =
    .label = Télécharger des langues
settings-translations-subpage-download-languages-select-option =
    .label = Choisir la langue
settings-translations-subpage-download-languages-button =
    .aria-label = Télécharger la langue
    .title = Télécharger la langue
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } Mo)
    .label = { $language } ({ $size } Mo)
settings-translations-subpage-no-languages-downloaded =
    .label = Aucune langue téléchargée
settings-translations-subpage-no-languages-added =
    .label = Aucune langue ajoutée
settings-translations-subpage-download-progress = Téléchargement…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Impossible de télécharger { $language } ({ $size } Mo)
settings-translations-subpage-download-retry-button =
    .label = Réessayer
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Supprimer { $language } ({ $size } Mo) ?
settings-translations-subpage-download-delete-button =
    .label = Supprimer
settings-translations-subpage-download-cancel-button =
    .label = Annuler
settings-translations-subpage-no-sites-added =
    .label = Aucun site ajouté
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Utiliser les paramètres de votre système d’exploitation en « { $localeName } » pour formater les dates, les heures, les nombres et les mesures.
settings-spellcheck-header =
    .label = Vérification orthographique
check-user-spelling =
    .label = Vérifier l’orthographe pendant la saisie
    .accesskey = V
spellcheck-download-dictionaries =
    .label = Téléchargement de dictionnaires
spellcheck-promo =
    .heading = Comment utiliser la vérification orthographique
    .message = Effectuez un clic droit sur un champ de texte pour activer ou désactiver la vérification orthographique ou pour changer la langue. Certains champs ne prennent pas en charge la vérification orthographique.

## Downloads - Files and applications

files-and-applications-title = Fichiers et applications
download-save-files-header =
    .label = Enregistrer les fichiers dans le dossier
download-save-where-3 =
    .aria-label = Enregistrer les fichiers dans le dossier
download-always-ask-where2 =
    .label = Demander où sauvegarder les fichiers avant de les télécharger
    .accesskey = D
download-private-browsing-delete2 =
    .label = Supprimer les téléchargements des fenêtres privées à la fermeture
    .accesskey = S
applications-header = Applications
applications-description = Définissez le comportement de { -brand-short-name } avec les fichiers que vous téléchargez et les applications que vous utilisez lorsque vous naviguez.
applications-setting2 =
    .description = Choisir comment { -brand-short-name } gère les fichiers et contenus téléchargés.
    .label = Fichiers et applications
applications-filter =
    .placeholder = Rechercher des types de fichiers ou d’applications
applications-type-column =
    .label = Type de contenu
    .accesskey = T
applications-type-heading = Type de contenu
applications-action-column =
    .label = Action
    .accesskey = A
applications-action-heading = Action
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = fichier { $extension }
applications-action-save =
    .label = Enregistrer le fichier
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Utiliser { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Utiliser { $app-name } (par défaut)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Utiliser l’application par défaut de macOS
            [windows] Utiliser l’application par défaut de Windows
           *[other] Utiliser l’application par défaut du système
        }
applications-use-other =
    .label = Autre…
applications-select-helper = Choisir une application externe
applications-manage-app =
    .label = Détails des applications…
applications-always-ask =
    .label = Toujours demander
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Ouvrir dans { -brand-short-name }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Que doit faire { -brand-short-name } des autres fichiers ?
applications-save-for-new-types =
    .label = Enregistrer les fichiers
    .accesskey = E
applications-save-for-new-types2 =
    .label = Enregistrer automatiquement les fichiers
    .accesskey = E
applications-ask-before-handling =
    .label = Demander s’il faut ouvrir ou enregistrer les fichiers
    .accesskey = D
applications-ask-before-handling2 =
    .label = Demander s’il faut ouvrir ou enregistrer les fichiers
    .accesskey = D
drm-group =
    .label = Contenu protégé par des composants de gestion des droits numériques (DRM)
play-drm-content =
    .label = Lire le contenu protégé par des DRM
    .accesskey = L
play-drm-content-learn-more = En savoir plus
# Variables:
# $version (string) - Firefox version
update-application-version = Version { $version } <a data-l10n-name="learn-more">Notes de version</a>
update-history-2 =
    .label = Afficher l’historique des mises à jour
    .accesskey = h
update-application-installation =
    .label = Installation
update-application-radio-group =
    .aria-label = Installation
update-application-auto-2 =
    .label = Installer les mises à jour automatiquement (recommandé)
    .accesskey = I
update-application-check-choose-2 =
    .label = Vérifier l’existence de mises à jour, mais choisir quand les installer
    .accesskey = V
update-application-background-enabled =
    .label = Quand { -brand-short-name } n’est pas lancé
    .accesskey = Q
update-application-warning-cross-user-setting-2 =
    .message = Ce paramètre s’appliquera à tous les comptes Windows et profils { -brand-short-name } utilisant cette installation de { -brand-short-name }.
update-application-suppress-prompts-2 =
    .label = Afficher moins de rappels de mises à jour
    .accesskey = A
update-setting-write-failure-title2 = Erreur lors de l’enregistrement des paramètres de mise à jour
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    { -brand-short-name } a rencontré une erreur et n’a pas enregistré cette modification. Notez que modifier ce paramètre de mise à jour nécessite la permission d’écriture pour le fichier ci-dessous. Vous, ou un administrateur système, pouvez peut-être corriger l’erreur en accordant au groupe Users l’accès complet à ce fichier.
    
    Écriture impossible dans le fichier : { $path }
update-in-progress-title = Mise à jour en cours
update-in-progress-message = Voulez-vous que { -brand-short-name } continue cette mise à jour ?
update-in-progress-ok-button = &Abandonner
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Continuer

## About Firefox

about-firefox-header =
    .heading = À propos de { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Les mises à jour améliorent la vitesse, la stabilité et la sécurité de { -brand-short-name }.
    .label = Mises à jour de { -brand-short-name }
update-application-suppress-prompts-heading =
    .label = Notifications
update-application-updates-managed-by-os =
    .message = Les mises à jour sont gérées par votre système d’exploitation

## Firefox support

support-application-heading =
    .description = Résolvez des problèmes ou partagez des idées avec la communauté.
    .label = Assistance de { -brand-short-name }
support-get-help =
    .label = Obtenir de l’aide
support-share-ideas =
    .label = Partager des idées et des commentaires

## Firefox newsletter

newsletter-settings-heading =
    .description = Des guides, des conseils et des actualités pour vous offrir une utilisation de { -brand-product-name } sur mesure.
    .label = Newsletter de { -brand-product-name }
newsletter-sign-up-link =
    .label = S’inscrire

## General Section - Performance

performance-settings-learn-more = En savoir plus
performance-allow-hw-accel =
    .label = Utiliser l’accélération graphique matérielle si disponible
    .accesskey = n
performance-limit-content-process-option = Nombre maximum de processus de contenu
    .accesskey = N
performance-limit-content-process-enabled-desc = Davantage de processus de contenu peut améliorer les performances lors de l’utilisation de plusieurs onglets, cependant la consommation de mémoire sera plus importante.
performance-limit-content-process-blocked-desc = Modifier le nombre de processus de contenu est possible uniquement avec la version multiprocessus de { -brand-short-name }. <a data-l10n-name="learn-more">Apprendre à vérifier si le mode multiprocessus est activé</a>
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (par défaut)
performance-group =
    .label = Performances
performance-use-recommended-settings-checkbox-2 =
    .description = Ces paramètres sont adaptés à votre matériel et à votre système d’exploitation.
    .label = Utiliser les paramètres de performance recommandés
    .accesskey = U

## Accessibility page

browsing-use-autoscroll =
    .label = Utiliser le défilement automatique
    .accesskey = U
keyboard-and-scrolling-group =
    .label = Navigation et défilement au clavier
motion-and-link-group =
    .label = Style des animations et des liens
browsing-use-smooth-scrolling =
    .label = Utiliser le défilement doux
    .accesskey = s
browsing-gtk-use-non-overlay-scrollbars =
    .label = Toujours afficher les barres de défilement
    .accesskey = T
browsing-always-underline-links =
    .label = Toujours souligner les liens
    .accesskey = s
browsing-use-onscreen-keyboard =
    .label = Afficher un clavier virtuel lorsque nécessaire
    .accesskey = A
browsing-use-cursor-navigation =
    .label = Toujours utiliser les touches de navigation pour se déplacer à l’intérieur d’une page
    .accesskey = T
browsing-use-full-keyboard-navigation =
    .label = Utiliser la touche tabulation pour déplacer le focus entre les contrôles de formulaire et les liens
    .accesskey = U
browsing-search-on-start-typing =
    .label = Lancer la recherche lors de la saisie de texte
    .accesskey = c
settings-keyboard-shortcuts-group =
    .description = Contrôlez la manière dont vous naviguez et vos interactions avec { -brand-short-name }.
    .label = Raccourcis clavier
settings-keyboard-shortcuts-customkeys-link =
    .label = Personnaliser les raccourcis clavier
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Personnaliser les paramètres de la barre d’adresse dans Recherche
settings-media-group =
    .label = Multimédia
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Utiliser l’incrustation vidéo
    .accesskey = U
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Continuer à lire les vidéos en mode incrustation lorsque vous changez d’onglet
    .accesskey = C
browsing-media-control =
    .label = Contrôler la lecture des médias via le clavier, un casque ou l’interface virtuelle
    .accesskey = C
recommendations-group =
    .label = Recommandations
browsing-cfr-recommendations =
    .label = Recommander des extensions en cours de navigation
    .accesskey = R
browsing-cfr-features =
    .label = Recommander des fonctionnalités en cours de navigation
    .accesskey = f
browsing-group =
    .label = Navigation
preferences-accessibility-header =
    .heading = Accessibilité
preferences-default-zoom-select =
    .aria-label = Zoom par défaut
preferences-fonts-family =
    .label = Famille de police
    .accesskey = F
preferences-fonts-size =
    .label = Taille de police
    .accesskey = T
preferences-fonts-advanced-settings =
    .label = Paramètres avancés
    .accesskey = P

## General Section - Proxy

network-proxy-group2 =
    .description = Configurer la façon dont { -brand-short-name } se connecte à Internet.
    .label = Paramètres de proxy
network-proxy-connection-settings2 =
    .description = La modification de ces paramètres peut provoquer des problèmes de connexion
    .label = Configurer le proxy
    .accesskey = C

## Home Section

home-new-windows-tabs-header = Nouvelles fenêtres et nouveaux onglets
home-new-windows-tabs-description2 = Choisissez ce qui est affiché lorsque vous ouvrez votre page d’accueil, de nouvelles fenêtres ou de nouveaux onglets.
home-section =
    .heading = Accueil et démarrage

## Home Section - Default Browser

home-default-browser-title =
    .label = Navigateur par défaut
is-default-browser-2 =
    .message = { -brand-short-name } est votre navigateur par défaut. Très bon choix.
is-not-default-browser-2 =
    .message = Psst, { -brand-short-name } n’est pas votre navigateur par défaut.
set-as-my-default-browser-2 =
    .label = Définir par défaut
    .accesskey = D

## Custom Homepage subpage

home-homepage-mode-label = Page d’accueil et nouvelles fenêtres
home-newtabs-mode-label = Nouveaux onglets
home-restore-defaults =
    .label = Configuration par défaut
    .accesskey = C
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name } (par défaut)
home-mode-choice-custom =
    .label = Adresses web personnalisées…
home-mode-choice-blank =
    .label = Page vide
home-homepage-custom-url =
    .placeholder = Coller une adresse…
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Gérer l’extension
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Page courante
           *[other] Pages courantes
        }
    .accesskey = U
choose-bookmark =
    .label = Marque-page…
    .accesskey = m
home-homepage-title =
    .label = Page d’accueil
home-homepage-new-windows =
    .label = Nouvelles fenêtres
home-homepage-new-tabs =
    .label = Nouveaux onglets
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Choisir un site en particulier
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Adresse(s) de site web
home-custom-homepage-list =
    .aria-label = Adresses de sites web
home-custom-homepage-address =
    .placeholder = Saisissez une adresse
home-custom-homepage-address-button =
    .label = Ajouter une adresse
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Aucun site web ajouté pour l’instant.
home-custom-homepage-delete-address-button =
    .aria-label = Supprimer l’adresse
    .title = Supprimer l’adresse
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Remplacer par
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = Pages ouvertes actuellement
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = Marque-pages…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Extension ({ $extension })
home-custom-homepage-header = Page d’accueil personnalisée
home-custom-homepage-subpage =
    .heading = Page d’accueil personnalisée

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = Contenu de la { -firefox-home-brand-name }
home-prefs-content-description2 = Choisissez le contenu que vous souhaitez pour la { -firefox-home-brand-name }.
home-prefs-search-header =
    .label = Recherche web
home-prefs-shortcuts-header =
    .label = Raccourcis
home-prefs-shortcuts-description = Sites que vous enregistrez ou visitez
home-prefs-shortcuts-by-option-sponsored =
    .label = Raccourcis sponsorisés
home-prefs-recommended-by-header-generic =
    .label = Articles recommandés
home-prefs-recommended-by-description-generic = Contenu exceptionnel sélectionné par les membres de la gamme de produits { -brand-product-name }
home-prefs-stories-header =
    .label = Articles
home-prefs-stories-description = Articles personnalisés en fonction de votre activité

##

home-prefs-recommended-by-learn-more = Mode d’emploi
home-prefs-recommended-by-option-sponsored-stories =
    .label = Articles sponsorisés
home-prefs-highlights-option-visited-pages =
    .label = Pages visitées
home-prefs-highlights-options-bookmarks =
    .label = Marque-pages
home-prefs-highlights-option-most-recent-download =
    .label = Dernier téléchargement
home-prefs-recent-activity-header =
    .label = Activité récente
home-prefs-recent-activity-description = Une sélection de sites et de contenus récents
home-prefs-weather-header =
    .label = Météo
home-prefs-weather-description = Les prévisions du jour en un clin d’œil
home-prefs-weather-learn-more-link = En savoir plus
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Soutenir { -brand-product-name }
home-prefs-mission-message = Nos sponsors soutiennent notre mission de créer un meilleur Web
home-prefs-mission-message-learn-more-link = Découvrir comment
home-prefs-manage-topics-link = Gérer les sujets
home-prefs-choose-wallpaper-link = Choisir un fond d’écran
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } ligne
           *[other] { $num } lignes
        }

## Search Section

search-show-suggestions-option =
    .label = Afficher les suggestions de recherche
    .accesskey = A
search-show-suggestions-url-bar-option =
    .label = Afficher les suggestions de recherche parmi les résultats de la barre d’adresse
    .accesskey = c
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Afficher les suggestions de recherche avant l’historique de navigation dans les résultats de la barre d’adresse
search-show-suggestions-private-windows-2 =
    .label = Suggestions de recherche dans les fenêtres de navigation privée
search-suggestions-cant-show-2 =
    .message = Les suggestions de recherche ne seront pas affichées parmi les résultats de la barre d’adresse car vous avez configuré { -brand-short-name } de façon à ce qu’il ne conserve jamais l’historique.
addressbar-header-1 =
    .description = Choisissez les suggestions à afficher dans votre barre d’adresse
    .label = Barre d’adresse
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Des suggestions de { -brand-short-name } et de nos partenaires dans votre barre d’adresse.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Afficher les termes des recherches dans la barre d’adresse des pages de résultats
search-separate-default-engine-2 =
    .label = Utiliser un autre moteur de recherche par défaut dans les fenêtres de navigation privée
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = Moteur de recherche par défaut dans les fenêtres de navigation privée
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Navigation dans la barre d’adresse
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Ignorer le menu des résultats si vous utilisez la touche tabulation pour déplacer le focus
search-suggestions-header-2 =
    .label = Suggestions du moteur de recherche
search-one-click-header2 = Raccourcis de recherche
search-one-click-desc = Sélectionnez les moteurs de recherche alternatifs qui apparaissent sous la barre d’adresse et la barre de recherche lorsque vous commencez à saisir un mot-clé.
search-one-click-header-3 =
    .description = Choisissez les moteurs de recherche et les raccourcis qui apparaissent dans votre barre d’adresse.
    .label = Moteurs de recherche supplémentaires
search-engine-list =
    .aria-label = Moteurs de recherche et raccourcis
update-search-engine-success =
    .message = Moteur de recherche mis à jour
search-edit-engine-2 =
    .title = Modifier le moteur de recherche
search-delete-engine =
    .title = Supprimer le moteur de recherche
search-enable-engine =
    .title = Activer le moteur de recherche
search-outlink-to-extensions-page =
    .title = Gérer dans Extensions et thèmes
search-choose-engine-column =
    .label = Moteur de recherche
search-choose-keyword-column =
    .label = Mot-clé
search-restore-default =
    .label = Restaurer les moteurs de recherche par défaut
    .accesskey = R
search-remove-engine =
    .label = Supprimer
    .accesskey = S
search-add-engine =
    .label = Ajouter
    .accesskey = A
search-add-engine-2 =
    .label = Ajouter un moteur de recherche
    .accesskey = A
search-edit-engine =
    .label = Modifier
    .accesskey = M
search-find-more-link = Découvrir d’autres moteurs de recherche
search-filtering-for-add-engine = Ajouter un moteur
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Doublon de mot-clé
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Vous avez choisi un mot-clé qui est déjà utilisé par « { $name } ». Veuillez en choisir un autre.
search-keyword-warning-bookmark = Vous avez choisi un mot-clé qui est déjà utilisé par un marque-page. Veuillez en choisir un autre.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Un moteur de recherche nommé « { $name } » existe déjà. Choisissez un autre nom.
remove-engine-confirmation = Voulez-vous vraiment supprimer ce moteur de recherche ?
remove-engine-remove = Supprimer
remove-addon-engine-alert = Pour supprimer ce moteur de recherche, supprimez le module associé.
search-engine-group =
    .label = Moteur de recherche par défaut
search-default-engine =
    .aria-label = Moteur de recherche par défaut
# Header for the search section ("search" is a noun).
search-section =
    .heading = Recherche

## Containers Section

containers-section-header2 =
    .heading = Paramètres des conteneurs
containers-card-header2 =
    .description = Séparez les cookies par conteneur afin de pouvoir utiliser différents comptes sur le même site et de limiter le pistage entre les sites.
    .label = Conteneurs
containers-add-button2 =
    .label = Ajouter un nouveau conteneur
    .accesskey = A
containers-list =
    .aria-label = Conteneurs
containers-new-tab-check3 =
    .label = Sélectionner un conteneur pour chaque nouvel onglet
    .accesskey = S
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Ne pas utiliser de conteneurs pour les liens ouverts depuis des applications externes
    .accesskey = N
containers-new-tab-check2 =
    .description = Le menu des conteneurs s’ouvrira à chaque fois que vous cliquerez sur le bouton d’ouverture de nouvel onglet.
    .label = Sélectionner un conteneur pour chaque nouvel onglet
    .accesskey = S
containers-settings-button2 =
    .title = Paramètres
containers-remove-button3 =
    .title = Supprimer
containers-sites-card-header =
    .description = Choisissez un conteneur pour un site et { -brand-short-name } l’utilisera à chaque ouverture du site.
    .label = Conteneurs spécifiques à des sites
containers-sites-add-button =
    .label = Ajouter un site web
    .accesskey = A
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Conteneur pour { $site }
containers-site-remove-button =
    .title = Supprimer
containers-remove-button2 =
    .title = Supprimer

## Account and sync

sync-group-label =
    .label = Synchronisation
account-group-label2 =
    .label = Compte
account-disabled-group =
    .description = Les paramètres du compte ne sont pas disponibles.
    .label = Compte
account-placeholder2 =
    .description = Connectez-vous et gardez vos données privées, chiffrées et accessibles instantanément partout où vous utilisez { -brand-short-name }.
    .label = Votre compte n’est pas connecté
account-sync-section =
    .heading = Compte et synchronisation
pane-account-sync-title2 = Compte et synchronisation
    .title = Compte et synchronisation

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Emportez votre Web partout avec vous
sync-signedout-description2 = Synchronisez marque-pages, historique, onglets, mots de passe, modules complémentaires et paramètres entre tous vos appareils.
sync-signedout-account-signin3 =
    .label = Se connecter pour synchroniser…
    .accesskey = i
sync-signedout-account-signin-4 =
    .label = Connectez-vous à votre compte pour lancer la synchronisation
    .accesskey = C
sync-signedout-account-short =
    .label = Connexion
    .accesskey = C
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Téléchargez Firefox pour <img data-l10n-name="android-icon"/> <a data-l10n-name="android-link">Android</a> ou <img data-l10n-name="ios-icon"/> <a data-l10n-name="ios-link">iOS</a> afin de synchroniser vos données avec votre appareil mobile.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Changer la photo de profil
    .tooltiptext = Changer la photo de profil
sync-profile-picture-account-problem =
    .alt = Image de profil du compte
fxa-login-rejected-warning =
    .alt = Avertissement
sync-sign-out =
    .label = Se déconnecter…
    .accesskey = d
sync-sign-out2 =
    .label = Se déconnecter
    .accesskey = d
sync-manage-account = Gérer le compte
    .accesskey = G
sync-manage-account2 =
    .label = Gérer le compte
    .accesskey = G

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = { $email } n’est pas vérifié.
sync-signedin-unverified2 =
    .description = Vérifiez vos e-mails pour confirmer votre compte et le valider.
    .label = L’adresse { $email } n’est pas encore confirmée
sync-signedin-login-failure = Veuillez vous identifier pour vous reconnecter via { $email }
sync-signedin-login-failure2 =
    .description = Reconnectez-vous pour synchroniser vos données.
    .label = Vous êtes déconnecté·e de { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Confirmer le compte
    .accesskey = C
sync-remove-account =
    .label = Supprimer le compte
    .accesskey = t
sync-sign-in =
    .label = Connexion
    .accesskey = x

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synchronisation : ACTIVÉE
prefs-syncing-on-2 =
    .label = La synchronisation est ACTIVÉE
prefs-syncing-off = Synchronisation : DÉSACTIVÉE
prefs-syncing-off-2 =
    .description = Activez la synchronisation pour consulter vos marque-pages, vos mots de passe, votre historique et bien plus sur n’importe quel appareil.
    .label = La synchronisation est DÉSACTIVÉE
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Activez la synchronisation pour récupérer vos marque-pages, mots de passe, historique et plus encore sur cet appareil.
    .label = La synchronisation est DÉSACTIVÉE
prefs-sync-turn-on-syncing =
    .label = Activer la synchronisation…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Activer la synchronisation
    .accesskey = s
prefs-sync-offer-setup-label2 = Synchronisez marque-pages, historique, onglets, mots de passe, modules complémentaires et paramètres entre tous vos appareils.
prefs-sync-now-button =
    .label = Synchroniser maintenant
    .accesskey = m
prefs-sync-now-button-2 =
    .label = Synchroniser maintenant
    .accesskey = m
prefs-syncing-button =
    .label = Synchronisation…
prefs-syncing-button-2 =
    .label = Synchronisation…
    .title = Synchroniser maintenant
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Vos préférences de synchronisation ne s’appliquent désormais qu’à cet appareil.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Vous synchronisez ces éléments entre tous vos appareils connectés :
sync-syncing-across-devices-heading-2 = Données synchronisées entre les appareils
sync-syncing-across-devices-heading-3 = Données synchronisées sur cet appareil
sync-syncing-across-devices-empty-state2 =
    .description = Vous ne synchronisez rien… pour l’instant. Lancez la synchronisation pour accéder à toutes vos données sur l’ensemble de vos appareils.
    .label = Gérer les données synchronisées
sync-syncing-across-devices-empty-state3 =
    .description = Vous ne synchronisez rien… pour l’instant. Sélectionnez les éléments à synchroniser sur cet appareil.
    .label = Gérer les données synchronisées
sync-currently-syncing-bookmarks = Marque-pages
sync-currently-syncing-history = Historique
sync-currently-syncing-tabs = Onglets ouverts
sync-currently-syncing-passwords = Mots de passe
sync-currently-syncing-addresses = Adresses
sync-currently-syncing-payment-methods = Moyens de paiement
sync-currently-syncing-addons = Modules complémentaires
sync-currently-syncing-settings = Paramètres
sync-manage-options =
    .label = Gérer la synchronisation…
    .accesskey = G
sync-manage-options-2 =
    .label = Gérer les données synchronisées
    .accesskey = G
settings-sync-disconnect-button =
    .label = Se déconnecter

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Marque-pages
    .accesskey = M
sync-engine-history =
    .label = Historique
    .accesskey = r
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Onglets ouverts
    .tooltiptext = Onglets ouverts sur vos autres appareils
    .accesskey = O
sync-engine-tabs =
    .label = Onglets ouverts
    .tooltiptext = Une liste de ce qui est actuellement ouvert sur tous vos appareils synchronisés
    .accesskey = O
sync-engine-passwords =
    .label = Mots de passe
    .tooltiptext = Les mots de passe que vous avez enregistrés
    .accesskey = M
sync-engine-addresses2 =
    .label = Adresses
    .tooltiptext = Adresses enregistrées dans { -brand-short-name }
    .accesskey = A
sync-engine-payment-methods3 =
    .label = Moyens de paiement
    .tooltiptext = Moyens de paiement enregistrés
    .accesskey = d
sync-engine-addons2 =
    .label = Modules complémentaires
    .tooltiptext = Extensions et thèmes que vous avez ajoutés à { -brand-short-name } pour ordinateur
    .accesskey = c
sync-engine-settings2 =
    .label = Paramètres
    .tooltiptext = Paramètres de { -brand-short-name }, si applicables
    .accesskey = P
sync-engine-addresses =
    .label = Adresses
    .tooltiptext = Les adresses postales que vous avez enregistrées (uniquement sur ordinateur)
    .accesskey = A
sync-engine-payment-methods2 =
    .label = Moyens de paiement
    .tooltiptext = Noms, numéros de cartes et date d’expiration
    .accesskey = n
sync-engine-addons =
    .label = Modules complémentaires
    .tooltiptext = Extensions et thèmes pour Firefox sur ordinateur
    .accesskey = u
sync-engine-settings =
    .label = Paramètres
    .tooltiptext = Les paramètres que vous avez modifiés dans les sections Général, Vie privée et Sécurité
    .accesskey = s
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Enregistrer
    .buttonlabelextra2 = Se déconnecter…
    .buttonaccesskeyaccept = E
    .buttonaccesskeyextra2 = S
    .style = min-width: 40em;
    .title = Gérer les données à synchroniser sur tous vos appareils connectés
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Enregistrer
    .buttonlabelextra2 = Se déconnecter…
    .buttonaccesskeyaccept = E
    .buttonaccesskeyextra2 = D
    .style = min-width: 37em;
    .title = Gérer les éléments synchronisés sur cet appareil

## The device name controls.

sync-device-name-header = Nom de l’appareil
sync-device-name-header-2 =
    .label = Nom de l’appareil
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Nom de l’appareil
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Changer le nom de l’appareil
    .accesskey = h
sync-device-name-change =
    .label = Changer le nom de l’appareil…
    .accesskey = h
sync-device-name-cancel =
    .label = Annuler
    .accesskey = A
sync-device-name-save =
    .label = Enregistrer
    .accesskey = E
sync-connect-another-device = Connecter un autre appareil
sync-connect-another-device-2 =
    .label = Connecter un autre appareil

## Privacy Section

privacy-header = Vie privée

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Mots de passe
    .searchkeywords = identifiants
forms-passwords-header =
    .aria-label = Mots de passe
    .label = Mots de passe
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Proposer d’enregistrer les mots de passe
    .accesskey = P
forms-manage-password-exceptions =
    .label = Gérer les exceptions pour les mots de passe
    .accesskey = G
forms-exceptions =
    .label = Exceptions…
    .accesskey = x
forms-suggest-passwords =
    .label = Suggérer des mots de passe compliqués…
    .accesskey = S
forms-breach-alerts =
    .label = Afficher des alertes pour les mots de passe de sites concernés par des fuites de données
    .accesskey = A
forms-breach-alerts-learn-more-link = En savoir plus
preferences-relay-integration-checkbox2 =
    .label = Proposer des alias de messagerie { -relay-brand-name } pour protéger votre adresse e-mail
    .accesskey = r
relay-integration-learn-more-link = En savoir plus
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Remplir automatiquement les noms d’utilisateur et mots de passe
    .accesskey = R
forms-fill-usernames-and-passwords-2 =
    .label = Enregistrer et remplir automatiquement les noms d’utilisateur et les mots de passe
    .accesskey = E
forms-saved-passwords =
    .label = Mots de passe enregistrés
    .accesskey = e
forms-saved-passwords-2 =
    .label = Gérer les mots de passe enregistrés
    .accesskey = G
forms-saved-passwords-searchkeywords = Les identifiants pour les sites suivants sont enregistrés sur votre ordinateur
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Protections supplémentaires
forms-primary-pw-use =
    .label = Utiliser un mot de passe principal
    .accesskey = U
forms-primary-pw-use-2 =
    .description = Ajoute une couche de sécurité supplémentaire pour protéger vos mots de passe enregistrés.
    .label = Utiliser un mot de passe principal
    .accesskey = U
forms-primary-pw-set =
    .label = Définir le mot de passe principal
forms-primary-pw-on-2 = Le mot de passe principal est <strong>ACTIVÉ</strong>.
forms-primary-pw-on =
    .label = Le mot de passe principal est activé
forms-primary-pw-change-2 =
    .label = Changer le mot de passe principal
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Le désactiver
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Exiger la connexion à l’appareil pour renseigner et gérer les mots de passe
forms-os-reauth-2 =
    .label = Exiger la connexion à l’appareil pour gérer les mots de passe
forms-primary-pw-learn-more-link = En savoir plus
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Changer le mot de passe principal…
    .accesskey = C
forms-primary-pw-change =
    .label = Changer le mot de passe principal…
    .accesskey = C
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Vous êtes actuellement en mode FIPS. Ce mode nécessite un mot de passe principal non vide.
forms-master-pw-fips-desc = Échec de la modification du mot de passe principal
forms-windows-sso =
    .label = Autoriser l’authentification unique de Windows pour les comptes Microsoft, professionnels et scolaires.
forms-windows-sso-learn-more-link = En savoir plus
forms-windows-sso-desc = Gérez les comptes dans les paramètres de votre appareil
windows-passkey-settings-label = Gérer les clés d’accès dans les paramètres système
privacy-panel-settings-header =
    .description = Obtenez de l’aide pour protéger vos informations en ligne avec { -brand-short-name }.
    .label = Paramètres du panneau Vie privée
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Afficher les messages de fuite de données
    .accesskey = A

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Pour créer un mot de passe principal, saisissez vos informations de connexion Windows. Cela contribue à protéger la sécurité de vos comptes.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = créer un mot de passe principal
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] modifier les paramètres des moyens de paiement
       *[other] { -brand-short-name } tente de modifier les paramètres des moyens de paiement. Connectez-vous à l’aide de votre appareil pour autoriser cette action.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Moyens de paiement
autofill-payment-methods-checkbox-message-2 =
    .label = Enregistrer et renseigner automatiquement les informations de paiement
    .accesskey = E
autofill-payment-methods-manage-payments-title =
    .heading = Gérer les moyens de paiement
autofill-payment-methods-manage-payments-button =
    .label = Gérer les moyens de paiement
    .accesskey = G
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Exiger l’authentification sur l’appareil pour le remplissage automatique
    .accesskey = E
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Exiger la connexion à l’appareil pour renseigner automatiquement et gérer les moyens de paiement
    .accesskey = E
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Enregistrer les cryptogrammes visuels
    .accesskey = E
autofill-payment-methods-add-button = Ajouter un nouveau moyen de paiement
payments-list-header =
    .label = Moyens de paiement
payments-delete-payment-prompt-title = Supprimer ce moyen de paiement ?
payments-delete-payment-prompt-confirm-button = Supprimer
payments-delete-payment-prompt-cancel-button = Annuler
payments-delete-payment-button-label =
    .aria-label = Supprimer
payments-edit-payment-button-label =
    .aria-label = Modifier
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Aucun moyen de paiement ajouté
autofill-addresses-checkbox-message =
    .label = Enregistrer et remplir automatiquement les adresses
    .accesskey = E
autofill-addresses-manage-addresses-button =
    .label = Gérer les adresses et les autres informations
    .accesskey = G
addresses-list-header =
    .label = Adresses
addreses-delete-address-button-label =
    .aria-label = Supprimer
addreses-edit-address-button-label =
    .aria-label = Modifier
addresses-delete-address-prompt-title = Supprimer cette adresse ?
addresses-delete-address-prompt-confirm-button = Supprimer
addresses-delete-address-prompt-cancel-button = Annuler
autofill-addresses-add-button = Ajouter une nouvelle adresse
autofill-addresses-manage-addresses-title =
    .heading = Gérer les adresses et les autres informations
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Aucune adresse ajoutée
personal-info-group =
    .label = Informations personnelles
autofill-personal-info-checkbox-message =
    .label = Enregistrer et renseigner automatiquement vos informations personnelles
autofill-personal-info-manage-button =
    .label = Gérer les informations personnelles
passports-list-header =
    .label = Passeports
passports-delete-passport-button-label =
    .aria-label = Supprimer
passports-edit-passport-button-label =
    .aria-label = Modifier
passports-delete-passport-prompt-title = Supprimer ce passeport ?
passports-delete-passport-prompt-confirm-button = Supprimer
passports-delete-passport-prompt-cancel-button = Annuler
autofill-passports-add-button = Ajouter un nouveau passeport
autofill-personal-info-manage-title =
    .heading = Gérer les informations personnelles
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Aucun passeport ajouté
pane-passwords-autofill-title2 = Mots de passe et remplissage automatique
    .title = Mots de passe et remplissage automatique
preferences-passwords-autofill-header =
    .heading = Mots de passe et remplissage automatique
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-3 =
    .description = { $expDate } | { $securityCode } enregistré
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-3 for a card that has
# a saved security code but no expiry date to show alongside it.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-3 =
    .description = { $securityCode } d’économies
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adresses et autres informations
payments-group =
    .label = Moyens de paiement

## Privacy Section - History

history-remember-option-never2 =
    .description = Chaque fenêtre agit comme une fenêtre privée. Lorsque cette option est activée, les extensions doivent être autorisées.
    .label = Ne jamais conserver l’historique
history-remember-option-custom2 =
    .label = Personnaliser l’historique
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } conservera les données de navigation, les téléchargements, les formulaires et l’historique de recherche.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } utilisera les mêmes paramètres que pour la navigation privée et ne conservera aucun historique de votre navigation.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } utilisera les paramètres personnalisés pour votre navigation, l’historique des téléchargements, les formulaires et l’historique de recherche.
history-private-browsing-permanent =
    .label = Toujours utiliser le mode de navigation privée
    .accesskey = i
history-remember-browser-option =
    .label = Conserver l’historique de navigation et des téléchargements
    .accesskey = C
history-remember-search-option =
    .label = Conserver l’historique des recherches et des formulaires
    .accesskey = n
history-clear-on-close-option =
    .label = Vider l’historique lors de la fermeture de { -brand-short-name }
    .accesskey = V
history-clear-on-close-settings =
    .label = Paramètres…
    .accesskey = P
history-shutdown-exceptions =
    .label = Gérer les exceptions
    .accesskey = x
history-clear-button =
    .label = Effacer l’historique…
    .accesskey = h
history-header2 =
    .heading = Historique
history-section-header =
    .description = Choisissez ce que { -brand-short-name } doit mémoriser à la fermeture du navigateur.
    .label = Historique
history-custom-section-header =
    .description = Personnalisez ce que { -brand-short-name } doit mémoriser à la fermeture du navigateur.
    .label = Paramètres avancés
history-custom-button =
    .label = Choisir ce dont { -brand-short-name } doit se souvenir
history-group =
    .label = Historique
history-mode-radio-group =
    .aria-label = Historique
history-remember-option-all2 =
    .label = Conserver l’historique

## Privacy Section - Site Data

sitedata-total-size-calculating = Calcul du volume des données de sites et du cache…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Les sites web occupent actuellement <strong>{ $value } { $unit }</strong> d’espace disque.
sitedata-learn-more = En savoir plus
sitedata-delete-on-close2 =
    .label = Effacer les cookies et les données de sites à chaque fermeture de { -brand-short-name }
    .accesskey = E
sitedata-delete-on-close-private-browsing3 =
    .message = En fonction de vos paramètres d’historique, { -brand-short-name } supprime les cookies et les données de site de votre session lorsque vous fermez le navigateur.
sitedata-delete-on-close-private-browsing4 =
    .heading = L’historique ne sera pas conservé.
    .message = { -brand-short-name } efface les cookies et les données de sites de votre session lorsque vous fermez le navigateur.
sitedata-option-block-cross-site-trackers =
    .label = Traqueurs intersites
sitedata-option-block-cross-site-tracking-cookies =
    .label = Cookies de pistage intersites
sitedata-option-block-cross-site-cookies2 =
    .label = Isoler les cookies intersites
sitedata-option-block-unvisited =
    .label = Cookies de sites web non visités
sitedata-option-block-all-cross-site-cookies =
    .label = Tous les cookies intersites (peut provoquer des problèmes avec certains sites web)
sitedata-option-block-all =
    .label = Tous les cookies (empêche certains sites de fonctionner)
sitedata-clear2 =
    .label = Effacer les données de navigation
    .accesskey = E
sitedata-settings2 =
    .label = Gérer les données de navigation
    .accesskey = G
sitedata-cookies-exceptions =
    .label = Gérer les exceptions…
    .accesskey = x
sitedata-cookies-exceptions2 =
    .description = Vous pouvez spécifier quels sites web sont toujours ou jamais autorisés à utiliser des cookies et des données de site.
    .label = Gérer les exceptions
    .accesskey = G
sitedata-heading =
    .description = Gérez les cookies, l’historique, le cache, les données des sites web, etc.
    .label = Données de navigation
sitedata-settings3 =
    .label = Effacer les données pour des sites spécifiques
    .accesskey = E
sitedata-cookies-exceptions3 =
    .description = Choisissez comment des sites spécifiques gèrent les cookies et les données de sites.
    .label = Gérer les exceptions
    .accesskey = G
cookies-site-data-group =
    .label = Cookies et données de sites

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Bloqueur de bannières de cookies
cookie-banner-blocker-description = Lorsqu’un site demande s’il peut utiliser des cookies en navigation privée, { -brand-short-name } les refuse automatiquement pour vous. Uniquement sur les sites pris en charge.
cookie-banner-learn-more = En savoir plus
cookie-banner-blocker-checkbox-label =
    .label = Refuser automatiquement les bannières de cookies

## Search Section

addressbar-locbar-history-option =
    .label = Historique de navigation
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = Marque-pages
    .accesskey = M
addressbar-locbar-clipboard-option =
    .label = Presse-papiers
    .accesskey = P
addressbar-locbar-openpage-option =
    .label = Onglets ouverts
    .accesskey = O
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Raccourcis
    .accesskey = R
addressbar-locbar-topsites-option =
    .label = Sites les plus visités
    .accesskey = v
addressbar-locbar-engines-option-1 =
    .label = Suggérer des moteurs de recherche à utiliser
    .accesskey = S
addressbar-locbar-quickactions-option =
    .label = Actions rapides
    .accesskey = a
addressbar-locbar-showrecentsearches-option-2 =
    .label = Recherches récentes
    .accesskey = R
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Suggestions de recherche populaires
    .accesskey = S
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Obtenir des suggestions du Web en rapport avec votre recherche.
    .label = Suggestions de { -brand-short-name }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Soutenir { -brand-short-name } en affichant de temps en temps des suggestions sponsorisées.
    .label = Suggestions de sponsors
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Obtenir des suggestions de Mozilla pendant la saisie
addressbar-dismissed-suggestions-label-2 =
    .description = Restaurer les suggestions rejetées des sponsors et de { -brand-short-name }.
    .label = Suggestions rejetées
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Restaurer les suggestions

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Protection renforcée contre le pistage
content-blocking-section-top-level-description = Les traqueurs vous suivent en ligne pour collecter des informations sur vos habitudes de navigation et vos centres d’intérêt. { -brand-short-name } bloque un grand nombre de ces traqueurs et de scripts malveillants.
content-blocking-learn-more = En savoir plus
content-blocking-fpi-incompatibility-warning = Vous utilisez l’isolation First-Party (FPI) qui remplace certains paramètres des cookies de { -brand-short-name }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Vous utilisez Resist Fingerprinting (RFP) qui remplace quelques-uns des paramètres de protection contre les détecteurs d’empreinte numérique de { -brand-short-name }. De ce fait, certains sites peuvent dysfonctionner.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standard
    .accesskey = d
enhanced-tracking-protection-setting-strict =
    .label = Stricte
    .accesskey = r
enhanced-tracking-protection-setting-custom =
    .label = Personnalisée
    .accesskey = P

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Équilibré entre protection et performances. Les pages se chargeront normalement.
content-blocking-etp-strict-desc = Protection renforcée, mais certains sites ou contenus peuvent ne pas fonctionner correctement.
content-blocking-etp-custom-desc = Choisissez les traqueurs et les scripts à bloquer.
content-blocking-etp-blocking-desc = { -brand-short-name } bloque les éléments suivants :
content-blocking-private-windows = Contenu utilisé pour le pistage dans les fenêtres de navigation privée
content-blocking-cross-site-cookies-in-all-windows2 = Cookies intersites dans toutes les fenêtres
content-blocking-cross-site-tracking-cookies = Cookies de pistage intersites
content-blocking-all-cross-site-cookies-private-windows = Cookies intersites dans les fenêtres de navigation privée
content-blocking-isolate-cross-site-cookies = Isoler les cookies intersites
content-blocking-social-media-trackers = Traqueurs de réseaux sociaux
content-blocking-all-cookies = Tous les cookies
content-blocking-unvisited-cookies = Cookies de sites non visités
content-blocking-all-windows-tracking-content = Contenu utilisé pour le pistage dans toutes les fenêtres
content-blocking-all-cross-site-cookies = Tous les cookies intersites
content-blocking-cryptominers = Mineurs de cryptomonnaies
content-blocking-fingerprinters = Détecteurs d’empreinte numérique
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = Détecteurs d’empreinte numérique connus et suspectés
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = La protection totale contre les cookies restreint les cookies au site sur lequel vous vous trouvez et les traqueurs ne peuvent donc pas s’en servir pour vous pister de site en site.
content-blocking-etp-standard-tcp-rollout-learn-more = En savoir plus
content-blocking-etp-standard-tcp-title = Inclut la protection totale contre les cookies, notre fonctionnalité de protection de la vie privée la plus puissante
content-blocking-warning-title-2 = Il se peut que certains sites ne fonctionnent pas correctement lorsque la protection stricte contre le pistage est activée
content-blocking-warning-title-custom = Il se peut que certains sites ne fonctionnent pas correctement lorsque la protection personnalisée contre le pistage est activée
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } recommande d’utiliser les paramètres « Résoudre les problèmes des sites » pour réduire le nombre de fonctionnalités et de contenus défectueux. Si un site semble cassé, essayez de désactiver la protection contre le pistage pour ce site afin de charger tout le contenu.
content-blocking-warning-learn-how = Me montrer comment faire
content-blocking-baseline-exceptions-3 =
    .description = Aide à charger les sites et les fonctionnalités en débloquant uniquement les éléments essentiels pouvant contenir des traqueurs. Corrige les problèmes les plus courants.
    .label = Résoudre les problèmes majeurs des sites (recommandé)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Restaure des éléments tels que des vidéos dans un article ou des sections de commentaires en débloquant des éléments qui peuvent contenir des traqueurs. Cela peut réduire les problèmes des sites, mais offre une moins bonne protection. Doit être utilisé avec les correctifs pour les problèmes majeurs.
    .label = Résoudre les problèmes mineurs des sites
content-blocking-baseline-uncheck-warning-dialog-title = Voulez-vous vraiment désactiver les correctifs ?
content-blocking-baseline-uncheck-warning-dialog-body = Ce paramètre permet de résoudre les problèmes les plus courants sur les sites. Si vous le désactivez, certains sites peuvent ne pas fonctionner et { -brand-short-name } ne sera pas en mesure de vous aider à résoudre ces problèmes.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Désactiver les correctifs
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Conserver les correctifs
content-blocking-reload-description = Vous devrez actualiser vos onglets pour appliquer ces modifications.
content-blocking-reload-tabs-button =
    .label = Actualiser tous les onglets
    .accesskey = A
content-blocking-tracking-content-label =
    .label = Contenu utilisé pour le pistage
    .accesskey = o
content-blocking-tracking-protection-option-all-windows =
    .label = Dans toutes les fenêtres
    .accesskey = t
content-blocking-option-private =
    .label = Seulement dans les fenêtres de navigation privée
    .accesskey = p
content-blocking-cookies-label =
    .label = Cookies
    .accesskey = C
content-blocking-expand-section =
    .tooltiptext = Plus d’informations
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = Mineurs de cryptomonnaies
    .accesskey = M
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = Détecteurs d’empreinte numérique connus
    .accesskey = e
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = Détecteurs d’empreinte numérique suspectés
    .accesskey = s

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Gérer les exceptions…
    .accesskey = x

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Arrêter les notifications jusqu’au redémarrage de { -brand-short-name }
    .accesskey = n
permissions-autoplay2 =
    .label = Lecture automatique
permissions-block-popups2 =
    .label = Bloquer les popups et les redirections tierces
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Ajoutez des sites web pouvant ouvrir des popups et utiliser des redirections tierces.
    .label = Gérer les exceptions
    .searchkeywords = pop-ups
    .accesskey = G
permissions-addon-install-warning3 =
    .label = Afficher un avertissement lorsque des sites web essaient d’installer des extensions
    .accesskey = A
permissions-addon-exceptions2 =
    .label = Choisir quels sites web peuvent installer des extensions
    .accesskey = C
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Autoriser les sites à demander à ouvrir des liens vers des applications.
    .accesskey = A
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Gérer les sites bloqués
    .accesskey = G
permissions-location2 =
    .label = Localisation
permissions-localhost2 =
    .label = Applications et services de l’appareil
permissions-local-network2 =
    .label = Appareils du réseau local
permissions-xr2 =
    .label = Réalité virtuelle
permissions-camera2 =
    .label = Caméra
permissions-microphone2 =
    .label = Microphone
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Haut-parleur
permissions-notification2 =
    .label = Notifications
permissions-header3 =
    .description = Gérez les éléments que les sites web peuvent accéder, contrôler ou déclencher.
    .label = Permissions
permissions-data-section =
    .heading = Autorisations et données
pane-permissions-data-title2 = Autorisations et données
    .title = Autorisations et données
notifications-section-header =
    .heading = Notifications
notifications-entry-card-header =
    .description = Choisissez quels sites web peuvent envoyer des notifications et comment ces alertes apparaissent.
    .label = Notifications
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } site web
           *[other] { $count } sites web
        }
    .label = Gérer les paramètres des notifications
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Gérer les paramètres de notification des sites web
notifications-website-card-header =
    .description = Choisissez comment les sites web peuvent envoyer des notifications.
    .label = Notifications des sites web
notifications-filter =
    .placeholder = Rechercher des sites web
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Site web
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Autoriser les notifications
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Sites web
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Toujours
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Autoriser
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Jamais
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Aucune notification de site web ajoutée.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Aucune notification de site web ne correspond à votre recherche.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Pour vous assurer que cette modification est incluse dans vos sauvegardes, ouvrez chaque profil et choisissez « Sauvegarder maintenant » dans les paramètres.
nimbus-rollouts =
    .description = Les changements seront appliqués à distance.
    .label = Autoriser { -brand-short-name } à améliorer les fonctionnalités, les performances et la stabilité entre les mises à jour
addon-recommendations3 =
    .description = Recevez des recommandations d’extensions pour améliorer votre navigation.
    .label = Autoriser les recommandations personnalisées d’extensions
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = L’envoi de données est désactivé pour cette configuration de compilation.
collection-backlogged-crash-reports2 =
    .label = Envoyer automatiquement les rapports de plantage
    .accesskey = E
collection-backlogged-crash-reports-description = Les rapports de plantage permettent à { -vendor-short-name } de diagnostiquer et de corriger des problèmes avec le navigateur. Les rapports peuvent contenir des données personnelles ou sensibles.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Les mêmes paramètres, avec un tout nouveau design !
    .message = Nous avons réorganisé cette page pour qu’elle soit plus facile à lire et à explorer. Vos paramètres personnels n’ont pas changé et tout est toujours là. Astuce : utilisez la recherche pour trouver directement ce dont vous avez besoin.
settings-redesign-promo-dismiss-button =
    .label = J’ai compris
privacy-segmentation-section-header = De nouvelles fonctionnalités qui améliorent votre navigation
privacy-segmentation-section-description = Lorsque nous proposons des fonctionnalités qui utilisent vos données pour vous offrir une expérience plus personnelle :
privacy-segmentation-radio-off =
    .label = Utiliser les recommandations de { -brand-product-name }
privacy-segmentation-radio-on =
    .label = Afficher les informations détaillées
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Nous nous efforçons de vous laisser le choix et de ne recueillir que le minimum de données nécessaires à l’amélioration de { -brand-product-name } pour tout le monde.
    .label = Collecte de données par { -brand-short-name } et utilisation
    .searchkeywords = télémétrie
data-collection-link = Consulter la politique de confidentialité
data-collection-preferences-across-profiles =
    .message = Ces paramètres s’appliquent à tous les profils de { -brand-product-name } sur cet appareil.
data-collection-profiles-link = Afficher tous les profils
data-collection-health-report-telemetry-disabled =
    .message = Vous n’autorisez plus { -vendor-short-name } à capturer des données techniques et d’interaction. Toutes les données passées seront supprimées dans les 30 jours.
data-collection-health-report =
    .description = Ce partage nous aide à améliorer les fonctionnalités, les performances et la stabilité de { -brand-product-name }.
    .label = Envoyer des données techniques et d’interaction à { -vendor-short-name }
    .accesskey = d
data-collection-health-report-disabled =
    .description = L’envoi de données est désactivé pour cette configuration de compilation.
    .label = Envoyer des données techniques et d’interaction à { -vendor-short-name }
    .accesskey = E
data-collection-run-studies =
    .description = { -brand-short-name } sélectionne au hasard des utilisateurs pour tester des fonctionnalités, ce qui contribue à améliorer la qualité pour tout le monde.
    .label = Autoriser { -brand-short-name } à mener des études de fonctionnalités
data-collection-studies-link =
    .label = Consulter les études de { -brand-short-name }
data-collection-backlogged-crash-reports =
    .description = Les rapports de plantage permettent à { -vendor-short-name } de diagnostiquer et de corriger des problèmes avec le navigateur. Les rapports peuvent contenir des données personnelles ou sensibles.
    .label = Envoyer automatiquement les rapports de plantage
    .accesskey = E
data-collection-usage-ping =
    .description = Ce paramètre aide { -vendor-short-name } à évaluer le nombre d’utilisateurs actifs.
    .label = Envoyer un ping quotidien d’utilisation à { -vendor-short-name }
    .accesskey = u

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Sécurité
browsing-protection-group2 =
    .description = Les sites et téléchargements dangereux peuvent mettre en danger vos données et votre appareil. { -brand-short-name } les bloque automatiquement et vous avertit des logiciels dangereux ou indésirables.
    .label = Protection contre les contenus trompeurs et les logiciels dangereux
security-enable-safe-browsing =
    .label = Bloquer les contenus dangereux ou trompeurs
    .accesskey = B
security-enable-safe-browsing-link = En savoir plus
security-safe-browsing-warning =
    .message = Désactiver cette option réduit la protection contre les escroqueries, les sites malveillants et les téléchargements dangereux.
security-block-downloads =
    .label = Bloquer les téléchargements dangereux
    .accesskey = D
security-block-uncommon-software =
    .label = Signaler la présence de logiciels indésirables ou peu communs
    .accesskey = n

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = Autoriser { -brand-short-name } à faire automatiquement confiance aux certificats racines tiers que vous installez
    .accesskey = z
certs-devices-enable-fips = Activer FIPS
space-alert-over-5gb-settings-button =
    .label = Ouvrir les paramètres
    .accesskey = O
space-alert-over-5gb-message2 = <strong>{ -brand-short-name } n’a plus assez d’espace disque.</strong> Le contenu des sites web pourrait ne pas s’afficher correctement. Vous pouvez effacer les données de sites enregistrées depuis Paramètres > Vie privée et sécurité > Cookies et données de sites.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name } n’a plus assez d’espace disque.</strong> Le contenu des sites web pourrait ne pas s’afficher correctement. Cliquez sur « En savoir plus » pour optimiser l’utilisation de votre disque et ainsi améliorer votre navigation.
certs-description3 =
    .description = Configurer les certificats utilisés par { -brand-short-name } pour vérifier les connexions sécurisées.
    .label = Certificats
certs-view2 =
    .label = Gérer les certificats
    .accesskey = G
certs-devices2 =
    .label = Gérer les périphériques de sécurité
    .accesskey = G

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Fonctionnement du mode HTTPS uniquement
httpsonly-radio-enabled =
    .label = Activer le mode HTTPS uniquement dans toutes les fenêtres
httpsonly-radio-enabled-pbm =
    .label = Activer le mode HTTPS uniquement dans les fenêtres privées seulement
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } peut tout de même surclasser certaines connexions
    .label = Ne pas activer le mode HTTPS uniquement
httpsonly-group =
    .description = Ce mode autorise seulement les connexions sécurisées aux sites web. { -brand-short-name } demande avant d’établir une connexion non sécurisée.
    .label = Mode HTTPS uniquement
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS via HTTPS
dns-over-https-group2 =
    .description = Le système de noms de domaine via HTTPS (DoH) chiffre les recherches de sites, il est donc plus difficile pour votre fournisseur Internet ou pour des tiers de voir quels sites vous vous apprêtez à visiter.
    .label = DNS via HTTPS
preferences-doh-description2 = Le système de nom de domaine (DNS) via HTTPS envoie votre demande de résolution d’un nom de domaine à travers une connexion chiffrée, procurant un DNS sécurisé pour compliquer la tâche de tiers qui tenteraient de découvrir le site web sur lequel vous allez vous rendre.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = État : { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Fournisseur : { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Adresse invalide
preferences-doh-steering-status = Utiliser un fournisseur local
preferences-doh-status-active = actif
preferences-doh-status-disabled = désactivé
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = inactif ({ $reason })
preferences-doh-group-message2 = Activer le DNS via HTTPS en utilisant :
preferences-doh-radio-group =
    .aria-label = Activer le DNS via HTTPS en utilisant :
preferences-doh-expand-section =
    .tooltiptext = Plus d’informations
preferences-doh-setting-default =
    .label = Protection par défaut
    .accesskey = P
preferences-doh-default-desc = { -brand-short-name } décide quand utiliser le DNS sécurisé pour protéger votre vie privée.
preferences-doh-default-detailed-desc-1 = Utiliser le DNS sécurisé dans les régions où il est disponible
preferences-doh-default-detailed-desc-2 = Utiliser votre serveur DNS par défaut s’il y a un problème avec le fournisseur du DNS sécurisé
preferences-doh-default-detailed-desc-3 = Utiliser un fournisseur local, si possible
preferences-doh-default-detailed-desc-4 = Désactiver lorsqu’un VPN, un contrôle parental ou des stratégies d’entreprise sont actifs
preferences-doh-default-detailed-desc-5 = Désactiver lorsqu’un réseau indique à { -brand-short-name } de ne pas utiliser de DNS sécurisé
preferences-doh-setting-enabled =
    .label = Protection renforcée
    .accesskey = r
preferences-doh-enabled-desc = Vous contrôlez le recours au DNS sécurisé et choisissez votre fournisseur.
preferences-doh-enabled-detailed-desc-1 = Utiliser le fournisseur que vous avez sélectionné
preferences-doh-enabled-detailed-desc-2 = Utiliser votre serveur DNS par défaut uniquement s’il y a un problème avec le DNS sécurisé
preferences-doh-setting-strict =
    .label = Protection maximale
    .accesskey = m
preferences-doh-strict-desc = { -brand-short-name } utilisera toujours le DNS sécurisé. Vous recevrez un avertissement de risque de sécurité avant l’utilisation du DNS de votre système.
preferences-doh-strict-detailed-desc-1 = Utiliser uniquement le fournisseur que vous avez sélectionné
preferences-doh-strict-detailed-desc-2 = Toujours prévenir si le DNS sécurisé n’est pas disponible
preferences-doh-strict-detailed-desc-3 = Si le DNS sécurisé n’est pas disponible, les sites ne se chargeront pas ou ne fonctionneront pas correctement
preferences-doh-setting-off =
    .label = Désactivé
    .accesskey = D
preferences-doh-off-desc = Utiliser le serveur de résolution DNS par défaut
preferences-doh-select-resolver = Choisir le fournisseur :
preferences-doh-manage-exceptions =
    .label = Gérer les exceptions…
    .accesskey = x
preferences-doh-overview-default =
    .description = Utiliser un DNS sécurisé dans les régions où il est disponible.
    .label = Protection par défaut
preferences-doh-overview-custom =
    .description = Toujours utiliser un DNS sécurisé en contrôlant votre fournisseur et le comportement des solutions de secours.
    .label = Personnalisé
preferences-doh-overview-off =
    .description = Utiliser votre serveur DNS par défaut.
    .label = Désactivé
preferences-doh-advanced-button =
    .label = Paramètres avancés
preferences-doh-advanced-section =
    .description = Le système de noms de domaine via HTTPS (DoH) chiffre les recherches de sites, il est donc plus difficile pour votre fournisseur Internet ou pour des tiers de voir quels sites vous vous apprêtez à visiter.
    .label = Paramètres avancés
preferences-doh-manage-exceptions2 =
    .label = Gérer les exceptions
    .accesskey = x
preferences-doh-radio-default =
    .description = Utiliser un DNS sécurisé dans les régions où il est disponible
    .label = Par défaut
preferences-doh-radio-custom =
    .description = Utilisez toujours un DNS sécurisé en contrôlant votre fournisseur et le comportement des solutions de secours
    .label = Personnalisé
preferences-doh-radio-off =
    .description = Utiliser votre serveur DNS par défaut
    .label = Désactivé
preferences-doh-fallback-label =
    .label = Toujours m’avertir si le DNS sécurisé n’est pas disponible
preferences-doh-status-item-off =
    .message = Le DNS via HTTPS est désactivé
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = Le DNS via HTTPS ne fonctionne pas, car nous avons rencontré une erreur ({ $reason }) en essayant d’utiliser le fournisseur { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = Le DNS via HTTPS ne fonctionne pas car nous avons reçu une URL invalide ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = Le DNS via HTTPS utilise le fournisseur { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = Le DNS via HTTPS ne fonctionne pas, car nous avons rencontré une erreur ({ $reason }) en essayant d’utiliser le fournisseur local { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = Le DNS via HTTPS utilise le fournisseur local { $name }
preferences-doh-select-resolver-label =
    .label = Choisir le fournisseur :
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Utiliser ce fournisseur pour les résolutions DNS via HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Saisissez l’URL d’un fournisseur personnalisé
preferences-doh-header2 =
    .heading = DNS via HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Sécurité logicielle et des connexions
preferences-connection-link-section =
    .description = Découvrez comment les connexions restent sécurisées, les logiciels dangereux sont bloqués et les sites web sont vérifiés.
    .label = Sécurité logicielle et des connexions
preferences-connection-link-button =
    .label = Paramètres avancés

## The following strings are used in the Download section of settings

desktop-folder-name = Bureau
downloads-folder-name = Téléchargements

## Appearance page

preferences-appearance-header =
    .heading = Apparence
browser-theme-group =
    .description = Personnalisez { -brand-short-name } à votre façon. Les couleurs des thèmes s’appliquent aux barres d’outils, aux menus et aux messages.
    .label = Thème du navigateur
browser-theme-manage-link =
    .label = Gérer les thèmes de { -brand-short-name }
appearance-window-density-group =
    .description = Ajustez l’espacement autour des éléments de la fenêtre tels que la barre d’outils, les onglets et le panneau latéral.
    .label = Densité de la fenêtre
appearance-window-density-radio-group =
    .aria-label = Densité de la fenêtre
appearance-window-density-automatic =
    .description = L’espacement standard, compact ou tactile est appliqué automatiquement
    .label = Automatique (par défaut)
appearance-window-density-automatic-no-touch =
    .description = L’espacement standard ou compact est appliqué automatiquement
    .label = Automatique (par défaut)
appearance-window-density-standard =
    .description = Espacement équilibré pour la plupart des écrans
    .label = Standard
appearance-window-density-auto-touch-mode =
    .label = Utiliser un espacement adapté au tactile en mode tablette
appearance-window-density-compact =
    .description = Espacement réduit pour les petits écrans
    .label = Compact
appearance-window-density-touch =
    .description = Les éléments de fenêtre et les cibles de clic sont plus grands, optimisés pour les écrans tactiles
    .label = Tactile
related-settings-group =
    .label = Paramètres associés
related-settings-accessibility-link =
    .label = Personnaliser les paramètres de zoom et de police dans Accessibilité
related-settings-home-link =
    .label = Personnaliser la { -firefox-home-brand-name }
related-settings-tabs-browsing-link =
    .label = Personnaliser la mise en page du navigateur

## AI controls page

preferences-ai-controls-description = Vous avez toujours le choix avec { -brand-short-name }, y compris concernant l’utilisation des fonctionnalités améliorées avec l’IA. Plus de contrôles seront bientôt disponibles.
preferences-ai-controls-block-ai-label = Bloquer les améliorations ayant recours à l’IA
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Activer le blocage implique que vous ne verrez pas les améliorations par IA (nouvelles ou existantes) dans { -brand-short-name }, ni les popups qui s’y rapportent. <a data-l10n-name="link">Obtenez plus de détails</a> sur ce qui est inclus et sur la façon de gérer les fonctionnalités classiques d’apprentissage automatique, telles que les suggestions de recherche et les recommandations.
preferences-ai-controls-blocked-message =
    .message = Les améliorations par IA nouvelles et existantes sont bloquées par défaut. Pour débloquer une fonctionnalité spécifique, utilisez les contrôles ci-dessous.
preferences-ai-controls-on-device-group =
    .description = Ces fonctionnalités utilisent de petits modèles d’IA qui se téléchargent sur votre appareil si vous les utilisez. Cette approche contribue à protéger votre vie privée.
    .label = IA sur l’appareil
preferences-ai-controls-translations-control =
    .description = Naviguez sans effort sur le Web dans la langue de votre choix.
    .label = Traductions
preferences-ai-controls-translations-more-link = Plus de paramètres de traduction
preferences-ai-controls-pdfjs-control =
    .description = Lorsque vous ajoutez des images à des fichiers PDF, cette fonctionnalité ajoute des descriptions pour les rendre accessibles.
    .label = Texte alternatif des images dans la visionneuse PDF de { -brand-short-name }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Bénéficiez de suggestions pour nommer et organiser vos onglets.
    .label = Suggestions de groupes d’onglets
preferences-ai-controls-key-points-control =
    .description = Consultez un bref résumé avant d’ouvrir un lien.
    .label = Points clés dans l’aperçu des liens
preferences-ai-controls-speech-recognition-control =
    .description = Transcription vocale en local.
    .label = Reconnaissance vocale
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Gardez un chatbot sous les yeux pendant votre navigation. Choisissez parmi plusieurs fournisseurs et changez de fournisseur à tout moment.
    .label = Fournisseurs de chatbots IA dans le panneau latéral
preferences-ai-controls-sidebar-chatbot-group =
    .description = Gardez un œil sur un chatbot tout en naviguant. Faites votre choix parmi Anthropic Claude, ChatGPT, Copilot, Google Gemini et Le Chat Mistral.
    .label = Fournisseurs de chatbots IA dans le panneau latéral
preferences-ai-controls-sidebar-chatbot-control =
    .label = Chatbot dans le panneau latéral
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Disponible
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Activé
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Bloqué
preferences-ai-controls-state-description-before = Signification des options :
preferences-ai-controls-state-description-available = <strong>Disponible :</strong> vous pouvez voir la fonctionnalité et l’utiliser.
preferences-ai-controls-state-description-enabled = <strong>Activé :</strong> vous avez choisi d’activer cette fonctionnalité.
preferences-ai-controls-state-description-blocked = <strong>Bloqué :</strong> vous ne voyez pas et ne pouvez pas utiliser cette fonctionnalité. Pour l’IA sur l’appareil, tous les modèles déjà téléchargés sont supprimés.
preferences-ai-controls-block-confirmation-heading = Bloquer les améliorations ayant recours à l’IA ?
preferences-ai-controls-block-confirmation-description = Vous ne verrez pas les améliorations par IA (nouvelles ou existantes) dans { -brand-short-name }, ni les popups qui s’y rapportent. Par la suite, vous pourrez débloquer toute fonctionnalité que vous souhaitez continuer à utiliser.
preferences-ai-controls-block-confirmation-features-start = Ce qui sera bloqué :
preferences-ai-controls-block-confirmation-translations = Traductions
preferences-ai-controls-block-confirmation-pdfjs = Texte alternatif des images dans la visionneuse PDF de { -brand-short-name }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Suggestions de groupes d’onglets
preferences-ai-controls-block-confirmation-key-points = Points clés dans l’aperçu des liens
preferences-ai-controls-block-confirmation-sidebar-chatbot = Fournisseurs de chatbot dans le panneau latéral
preferences-ai-controls-block-confirmation-speech-recognition = Reconnaissance vocale
preferences-ai-controls-block-confirmation-features-after = Le blocage affecte également les extensions qui utilisent l’IA fournie par { -brand-short-name }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Annuler
preferences-ai-controls-block-confirmation-confirm =
    .label = Bloquer
preferences-ai-controls-header3 =
    .heading = Contrôles de l’IA

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } monte la garde
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } recommande des améliorations en matière de sécurité
security-privacy-status-ok-label = La protection renforcée contre le pistage est activée
security-privacy-status-problem-label = Nous avons identifié des paramètres qui affectent votre protection
security-privacy-status-problem-helper-label = Voir les problèmes
security-privacy-status-pending-trackers-label = Recherche du nombre de traqueurs bloqués par { -brand-short-name } au cours du mois dernier
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] { $trackerCount } traqueur bloqué le mois dernier
       *[other] { $trackerCount } traqueurs bloqués le mois dernier
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Vous utilisez <a data-l10n-name="strict-tracking-protection">la protection stricte</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Vous utilisez <a data-l10n-name="custom-tracking-protection">la protection personnalisée</a>
security-privacy-status-up-to-date-label = Vous disposez de la version la plus récente et la plus sûre de { -brand-short-name }
security-privacy-status-update-needed-label = Une nouvelle version de { -brand-short-name } est disponible.
security-privacy-status-update-error-label = { -brand-short-name } rencontre des difficultés pour se mettre à jour
security-privacy-status-update-checking-label = { -brand-short-name } recherche des mises à jour
security-privacy-status-update-needed-description = Effectuez la mise à jour afin de bénéficier des améliorations récentes en matière de vitesse, de stabilité et de sécurité.
security-privacy-status-update-button-label =
    .label = Mettre à jour { -brand-short-name }
security-privacy-image-warning =
    .alt = Un bouclier avec un point d’exclamation, exprimant une préoccupation concernant les avertissements de sécurité
security-privacy-image-ok =
    .alt = Un bouclier avec une coche, indiquant que vous n’avez aucun problème de sécurité en cours
security-privacy-issue-card =
    .heading = Avertissements de sécurité
issue-card-reset-button =
    .label = Réinitialiser
issue-card-dismiss-button =
    .aria-label = Ignorer
    .tooltiptext = Ignorer

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Les sites utilisent des traqueurs pour vous pister en ligne et pour afficher des publicités intrusives. { -brand-short-name } vous protège lorsque vous naviguez en bloquant automatiquement les traqueurs afin que vous gardiez le contrôle de votre vie numérique.
    .label = Protection renforcée contre le pistage
preferences-etp-level-radio-group =
    .aria-label = Protection renforcée contre le pistage
preferences-etp-level-standard =
    .description = Des protections robustes et fiables qui fonctionnent parfaitement avec la plupart des sites web.
    .label = Standard (par défaut)
preferences-etp-level-strict =
    .description = Des protections plus puissantes qui bloquent davantage de traqueurs, mais peuvent empêcher certains sites de fonctionner correctement.
    .label = Stricte
preferences-etp-level-custom =
    .description = Choisissez les protections à activer ou désactiver.
    .label = Personnalisée
preferences-etp-status-advanced-button =
    .label = Paramètres avancés
preferences-etp-tracker-count-enabled =
    .label = Afficher les traqueurs bloqués dans la barre d’adresse
preferences-etp-status-protections-dashboard-link =
    .description = Découvrez combien de traqueurs { -brand-short-name } a bloqué pour vous, y compris les traqueurs de réseaux sociaux, les détecteurs d’empreintes numériques et les mineurs de cryptomonnaies.
    .label = Afficher votre tableau de bord personnalisé des protections
preferences-etp-header =
    .heading = Protection renforcée contre le pistage
preferences-etp-advanced-settings-group =
    .description = Les sites utilisent des traqueurs pour vous pister en ligne et pour afficher des publicités intrusives. { -brand-short-name } vous protège lorsque vous naviguez, bloquant automatiquement la plupart des traqueurs afin que vous gardiez le contrôle de votre vie numérique.
    .label = Paramètres avancés
preferences-etp-customize-button =
    .label = Personnaliser la protection contre le pistage
preferences-etp-reload-tabs-hint =
    .message = Actualisez vos onglets pour appliquer ces modifications.
preferences-etp-reload-tabs-hint-button =
    .label = Actualiser tous les onglets
preferences-etp-rfp-warning-message =
    .message = Vous utilisez Resist Fingerprinting (RFP) qui remplace quelques-uns des paramètres de protection contre les détecteurs d’empreinte numérique de { -brand-short-name }. De ce fait, certains sites peuvent dysfonctionner.
preferences-etp-level-warning-message =
    .heading = Attention ! Certains sites peuvent ne pas fonctionner comme prévu.
    .message = Certains sites intègrent des traqueurs dans leurs fonctionnalités ou leur contenu. Quand { -brand-short-name } les bloque, le site semble cassé. Essayez d’utiliser « Résoudre les problèmes du site » ou de désactiver la protection contre le pistage sur ce site.
preferences-etp-manage-exceptions-button =
    .description = Gérer les sites web pour lesquels la protection renforcée contre le pistage est désactivée.
    .label = Gérer les exceptions
preferences-etp-customize-header =
    .heading = Personnaliser la protection contre le pistage
preferences-etp-reset =
    .description = Restaurez les paramètres à un niveau de protection prédéfini.
    .label = Réinitialiser les personnalisations
preferences-etp-reset-standard-button =
    .label = Réinitialiser au niveau standard
preferences-etp-reset-strict-button =
    .label = Réinitialiser au niveau strict
preferences-etp-custom-control-group =
    .description = Choisissez les protections à activer ou désactiver.
    .label = Protection contre le pistage
preferences-etp-custom-cookies-enabled =
    .label = Cookies
preferences-etp-custom-cookie-behavior =
    .aria-label = Cookies
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Autoriser tous les cookies
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Bloquer les cookies de pistage intersites
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Bloquer les cookies intersites
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Isoler les cookies intersites
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Bloquer les cookies des sites web non visités
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Bloquer tous les cookies intersites (peut empêcher certains sites de fonctionner)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Bloquer tous les cookies (empêchera des sites de fonctionner)
preferences-etp-custom-tracking-protection-enabled =
    .label = Contenu utilisé pour le pistage
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Contenu utilisé pour le pistage
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Mineurs de cryptomonnaies
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Détecteurs d’empreinte numérique connus
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Détecteurs d’empreinte numérique suspectés
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Détecteurs d’empreinte numérique suspectés

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Cela peut permettre à certains traqueurs de vous pister sans cookies.
    .label = Les détecteurs d’empreinte numérique connus ne sont pas bloqués
security-privacy-issue-warning-third-party-cookies =
    .description = Les cookies tiers sont utilisés pour vous pister sur des sites web.
    .label = Les cookies tiers sont activés
security-privacy-issue-warning-password-manager =
    .description = Les gestionnaires de mots de passe vous aident à stocker des mots de passe compliqués pour vos comptes.
    .label = Le gestionnaire de mots de passe est désactivé
security-privacy-issue-warning-popup-blocker =
    .description = Les popups sont distrayants et potentiellement dangereux.
    .label = Le bloqueur de popups est désactivé
security-privacy-issue-warning-extension-install =
    .description = Les sites web peuvent installer des extensions sur { -brand-short-name } sans demander.
    .label = Les sites web peuvent installer des extensions
security-privacy-issue-warning-safe-browsing =
    .description = Vous êtes davantage vulnérable aux arnaques et aux logiciels malveillants provenant de sites web.
    .label = Les contenus dangereux ou trompeurs ne sont pas bloqués
security-privacy-issue-warning-doh2 =
    .description = Le DNS via HTTPS empêche votre fournisseur d’accès de connaître les sites que vous vous apprêtez à visiter.
    .label = Le DNS via HTTPS est désactivé
security-privacy-issue-warning-ech2 =
    .description = Le client chiffré Hello empêche votre fournisseur d’accès de connaître les sites que vous vous apprêtez à visiter.
    .label = Le client chiffré Hello est désactivé
security-privacy-issue-warning-doh =
    .description = Le DNS via HTTPS empêche votre fournisseur d’accès réseau de savoir quels sites vous visitez.
    .label = Le DNS via HTTPS est désactivé
security-privacy-issue-warning-ech =
    .description = Le client chiffré Hello empêche votre fournisseur d’accès réseau de savoir quels sites vous visitez.
    .label = Le client chiffré Hello est désactivé
security-privacy-issue-warning-proxy-autodetection =
    .description = La configuration automatique du proxy pourrait permettre à des réseaux non fiables de surveiller votre activité.
    .label = La configuration automatique du proxy est activée

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Inviter quelqu’un à choisir le navigateur qui respecte la vie privée.
    .label = Recommander { -brand-product-name }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Recommander { -brand-product-name }


## Préférences de vorbit

# Barre latérale
pane-vorbit-title = vOrbit-lite
category-vorbit =
    .tooltiptext = changements dans about:config, regroupés logiquement et facilement accessibles
# Contenu principal
vorbit-header = Préférences de vOrbit-lite
vorbit-warning-title = Attention !
vorbit-warning-description = Nous choisissons avec soin les paramètres par défaut pour privilégier la confidentialité et la sécurité. Lorsque vous modifiez ces paramètres, lisez les descriptions pour comprendre les implications de ces changements.
# Mise en page
vorbit-general-heading = Comportement du navigateur
vorbit-extension-update-checkbox =
    .label = Mettre à jour les modules automatiquement
vorbit-sync-checkbox =
    .label = Activer Firefox Sync
vorbit-autocopy-checkbox =
    .label = Activer le collage par clic du milieu
vorbit-styling-checkbox =
    .label = Autoriser la personnalisation avec userChrome.css
vorbit-network-heading = Réseau
vorbit-ipv6-checkbox =
    .label = Activer IPv6
vorbit-privacy-heading = Confidentialité
vorbit-xorigin-ref-checkbox =
    .label = Limiter les referers inter-origine
vorbit-broken-heading = Empreinte numérique
vorbit-webgl-checkbox =
    .label = Activer WebGL
vorbit-rfp-checkbox =
    .label = Activer ResistFingerprinting
vorbit-letterboxing-checkbox =
    .label = Activer le letterboxing
vorbit-security-heading = Sécurité
vorbit-ocsp-checkbox =
    .label = Appliquer l'échec strict OCSP
vorbit-goog-safe-checkbox =
    .label = Activer la navigation sécurisée de Google
vorbit-goog-safe-download-checkbox =
    .label = Scanner les téléchargements
# Descriptions détaillées
vorbit-extension-update-description = Gardez les extensions à jour sans intervention manuelle. Un bon choix pour votre sécurité.
vorbit-extension-update-warning1 = Si vous ne révisez pas le code de vos extensions avant chaque mise à jour, vous devriez activer cette option.
vorbit-ipv6-description = Autoriser { -brand-short-name } à se connecter via IPv6.
vorbit-ipv6-warning1 = Au lieu de bloquer IPv6 dans le navigateur, nous vous suggérons d'activer l'extension de confidentialité IPv6 dans votre système d'exploitation.
vorbit-ocsp-description = Empêcher la connexion à un site web si la vérification OCSP ne peut pas être effectuée.
vorbit-ocsp-warning1 = Cela augmente la sécurité, mais cela entraînera des dysfonctionnements si un serveur OCSP est hors service.
vorbit-sync-description = Synchronisez vos données avec d'autres navigateurs. Nécessite un redémarrage.
vorbit-sync-warning1 = Firefox Sync chiffre les données localement avant de les transmettre au serveur.
vorbit-autocopy-description = Sélectionnez du texte pour le copier, puis collez-le avec un clic du milieu.
vorbit-styling-description = Activez ceci si vous souhaitez personnaliser l'interface utilisateur avec un thème chargé manuellement.
vorbit-styling-warning1 = Assurez-vous de faire confiance au fournisseur du thème.
vorbit-xorigin-ref-description = Envoyer un referrer uniquement pour les mêmes origines.
vorbit-xorigin-ref-warning1 = Cela peut entraîner des dysfonctionnements. De plus, même lorsqu'ils sont envoyés, les referrers seront toujours tronqués.
vorbit-webgl-description = WebGL est un vecteur puissant pour l'empreinte numérique.
vorbit-webgl-warning1 = Si vous devez l'activer, envisagez d'utiliser une extension comme Canvas Blocker.
vorbit-rfp-description = ResistFingerprinting est le meilleur outil anti-empreinte numérique de sa catégorie.
vorbit-rfp-warning1 = Si vous devez le désactiver, envisagez d'utiliser une extension comme Canvas Blocker.
vorbit-letterboxing-description = Le letterboxing applique des marges autour de vos fenêtres, afin de retourner un ensemble limité de résolutions arrondies.
vorbit-goog-safe-description = Si vous craignez les logiciels malveillants et le phishing, envisagez de l'activer.
vorbit-goog-safe-warning1 = Désactivé pour des raisons de censure mais recommandé pour les utilisateurs moins avancés. Toutes les vérifications se font localement.
vorbit-goog-safe-download-description = Autoriser la navigation sécurisée à scanner vos téléchargements pour identifier les fichiers suspects.
vorbit-goog-safe-download-warning1 = Toutes les vérifications se font localement.
# Pied de page
vorbit-footer = Liens utiles
vorbit-config-link = Tous les paramètres avancés (about:config)
vorbit-open-profile = Ouvrir le répertoire du profil utilisateur
content-blocking-section-top-level-description = vOrbit-lite prend en charge, et active par défaut, la protection renforcée contre le pistage en mode strict. Ce paramètre est essentiel, car il permet le partitionnement de l'état du navigateur, fournit des listes de blocage strictes et d'autres fonctionnalités de confidentialité. Nous déconseillons de passer à un autre mode.
vorbit-extension-update-checkbox2 =
    .label = Mettre à jour les extensions automatiquement
    .description = Maintenir les extensions à jour sans action de votre part. Une bonne décision pour votre sécurité.
vorbit-sync-checkbox2 =
    .label = Activer la synchronisation Firefox
    .description = Synchroniser vos données avec d'autres navigateurs. Nécessite un redémarrage.
vorbit-styling-checkbox2 =
    .label = Autoriser la personnalisation de userChrome.css
    .description = Activez ceci si vous souhaitez personnaliser l'interface utilisateur·rice avec un thème chargé manuellement.
vorbit-network-heading2 =
    .label = Réseau
vorbit-ipv6-checkbox2 =
    .label = Activer l'IPv6
    .description = Autoriser { -brand-short-name } à se connecter en utilisant l'IPv6.
vorbit-privacy-heading2 =
    .label = Vie privée
vorbit-webgl-checkbox2 =
    .label = Toujours autoriser le WebGL
    .description = Ceci autorisera toujours le WebGL sans demander la permission pour.
vorbit-webgl-prompt-checkbox2 =
    .label = Cacher le popup WebGL par site
    .description = Ceci cache le popup qui apparaît quand un site essaie de créer un context WebGL. Vous pouvez toujours manuellement faire apparaître l'invite en cliquant l'icône associée dans la barre de recherche.
vorbit-rfp-checkbox2 =
    .label = Activer ResistFingerprinting
    .description = Active toutes les atténuations de la détection d'empreinte numérique, mais peut perturber le fonctionnement de certains sites web.
vorbit-security-heading2 =
    .label = Sécurité
permissions-webgl2 =
    .label = WebGL
