# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 50em
    .title = Exceptions
permissions-close-key =
    .key = w
permissions-address = Adresse du site web
    .accesskey = d
permissions-block =
    .label = Bloquer
    .accesskey = B
permissions-disable-etp =
    .label = Ajouter une exception
    .accesskey = A
permissions-session =
    .label = Autoriser pour la session
    .accesskey = o
permissions-allow =
    .label = Autoriser
    .accesskey = A
permissions-add =
    .label = Ajouter
    .accesskey = A
permissions-button-off =
    .label = Désactiver
    .accesskey = D
permissions-button-off-temporarily =
    .label = Désactiver temporairement
    .accesskey = t
permissions-site-name =
    .label = Site web
permissions-status =
    .label = État
permissions-remove =
    .label = Supprimer le site
    .accesskey = S
permissions-remove-all =
    .label = Supprimer tous les sites
    .accesskey = u
permissions-save-changes-2 =
    .buttonlabelaccept = Enregistrer les modifications
    .buttonaccesskeyaccept = E
permission-dialog =
    .buttonlabelaccept = Enregistrer les modifications
    .buttonaccesskeyaccept = E
permissions-autoplay-menu = Par défaut pour tous les sites web :
permissions-searchbox =
    .placeholder = Rechercher un site web
permissions-capabilities-autoplay-allow =
    .label = Autoriser l’audio et la vidéo
permissions-capabilities-autoplay-block =
    .label = Bloquer l’audio
permissions-capabilities-autoplay-blockall =
    .label = Bloquer l’audio et la vidéo
permissions-capabilities-allow =
    .label = Autoriser
permissions-capabilities-block =
    .label = Bloquer
permissions-capabilities-prompt =
    .label = Toujours demander
permissions-capabilities-listitem-allow =
    .value = Autoriser
permissions-capabilities-listitem-block =
    .value = Bloquer
permissions-capabilities-listitem-allow-session =
    .value = Autoriser pour la session
permissions-capabilities-listitem-off =
    .value = Désactivé
permissions-capabilities-listitem-off-temporarily =
    .value = Désactivé temporairement

## Invalid Hostname Dialog

permissions-invalid-uri-title = Nom d’hôte invalide
permissions-invalid-uri-label = Veuillez saisir un nom d’hôte valide

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Exceptions pour la protection renforcée contre le pistage
permissions-exceptions-manage-etp-desc = Vous pouvez indiquer les sites web pour lesquels la Protection renforcée contre le pistage sera désactivée. Saisissez l’adresse exacte du site que vous souhaitez gérer et cliquez sur Ajouter une exception.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Exceptions - Cookies et données de sites
permissions-exceptions-cookie-desc = Vous pouvez indiquer les sites web qui sont toujours ou ne sont jamais autorisés à utiliser des cookies ou des données de sites. Saisissez l’adresse exacte du site et cliquez sur Bloquer, Autoriser pour la session, ou Autoriser.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Exceptions - Effacer l’historique à la fermeture
permissions-exceptions-shutdown-clearing-desc = Vous pouvez spécifier quels sites web conserveront leurs données lorsque { -brand-short-name } efface l’historique à la fermeture. Saisissez l’adresse exacte du site que vous souhaitez gérer puis cliquez sur Autoriser.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Exceptions - Mode HTTPS uniquement
permissions-exceptions-https-only-desc2 = Vous pouvez désactiver le mode HTTPS uniquement pour des sites web spécifiques. { -brand-short-name } n’essaiera pas de mettre à niveau vers une connexion HTTPS sécurisée pour ces sites.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Sites autorisés - Popups et redirections tierces
permissions-exceptions-popup-desc2 = Vous pouvez spécifier quels sites web sont autorisés à ouvrir des fenêtres popup et être redirigés par des cadres tiers.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Exceptions - Mots de passe enregistrés
permissions-exceptions-saved-passwords-desc = { -brand-short-name } n’enregistre pas les mots de passe pour les sites listés ici.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Sites autorisés - Modules complémentaires
permissions-exceptions-addons-desc = Vous pouvez indiquer les sites web autorisés à installer des modules complémentaires. Saisissez l’adresse exacte du site que vous souhaitez autoriser et cliquez sur Autoriser.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Lecture automatique
permissions-site-autoplay-desc = Vous pouvez gérer ici les sites qui ne suivent pas vos paramètres de lecture automatique par défaut.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Permissions pour les notifications
permissions-site-notification-desc = Les sites web suivants ont demandé à vous envoyer des notifications. Vous pouvez spécifier quels sites web sont autorisés à vous envoyer des notifications. Vous pouvez également bloquer les nouvelles demandes d’activation des notifications.
permissions-site-notification-disable-label =
    .label = Bloquer les nouvelles demandes d’activation des notifications
permissions-site-notification-disable-desc = Cela empêchera tous les sites web non listés ci-dessus de demander l’autorisation d’envoyer des notifications. Le blocage des notifications peut invalider les fonctionnalités de certains sites web.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Autoriser les notifications de sites web lorsque { -brand-short-name } est fermé
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Les paramètres de notification de votre système d’exploitation s’appliquent également.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Permissions pour la localisation
permissions-site-location-desc = Les sites web suivants ont demandé l’accès à votre localisation. Vous pouvez spécifier quels sites web sont autorisés à accéder à votre localisation. Vous pouvez également bloquer les nouvelles demandes d’accès à votre localisation.
permissions-site-location-disable-label =
    .label = Bloquer les nouvelles demandes d’accès à votre localisation
permissions-site-location-disable-desc = Cela empêchera tous les sites web non listés ci-dessus de demander l’autorisation d’accéder à votre localisation. Bloquer l’accès à votre localisation peut invalider les fonctionnalités de certains sites web.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Autorisations de réalité virtuelle
permissions-site-xr-desc = Les sites web suivants ont demandé l’accès à vos appareils de réalité virtuelle. Vous pouvez spécifier quels sites web sont autorisés à accéder à vos appareils de réalité virtuelle. Vous pouvez également bloquer les nouvelles demandes d’accès à vos appareils de réalité virtuelle.
permissions-site-xr-disable-label =
    .label = Bloquer les nouvelles demandes d’accès à vos appareils de réalité virtuelle
permissions-site-xr-disable-desc = Cela empêchera tous les sites web non listés ci-dessus de demander l’autorisation d’accéder à vos appareils de réalité virtuelle. Bloquer l’accès à vos appareils de réalité virtuelle peut restreindre les fonctionnalités de certains sites web.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Paramètres - Sites bloqués pour les liens vers des applications
permissions-site-app-links-desc = Ces sites ne sont pas autorisés à demander l’ouverture de liens vers des applications, comme les liens d’adresse e-mail (mailto:). Supprimez un site pour lui permettre de demander à nouveau cette autorisation.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Permissions pour la caméra
permissions-site-camera-desc = Les sites web suivants ont demandé l’accès à votre caméra. Vous pouvez spécifier quels sites web sont autorisés à accéder à votre caméra. Vous pouvez également bloquer les nouvelles demandes d’accès à votre caméra.
permissions-site-camera-disable-label =
    .label = Bloquer les nouvelles demandes d’accès à votre caméra
permissions-site-camera-disable-desc = Cela empêchera tous les sites web non listés ci-dessus de demander l’autorisation d’accéder à votre caméra. Bloquer l’accès à votre caméra peut invalider les fonctionnalités de certains sites web.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Paramètres - Applications et services de l’appareil
permissions-site-localhost-desc = Ces sites web ont demandé à accéder aux applications et services de cet appareil. Vous avez la possibilité d’autoriser ou de bloquer l’accès à certains sites.
permissions-site-localhost-disable-label =
    .label = Bloquer les nouvelles demandes d’accès aux applications et services sur cet appareil
permissions-site-localhost-disable-desc = Activer ce paramètre empêchera tous les sites web non listés ci-dessus de demander l’accès aux applications et services sur cet appareil. Certaines fonctionnalités de sites web pourraient ne plus fonctionner.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Paramètres - Appareils du réseau local
permissions-site-local-network-desc = Ces sites web ont demandé à accéder aux applications et services sur les appareils connectés à votre Wi-Fi ou à votre réseau local. Vous avez la possibilité d’autoriser ou de bloquer l’accès à certains sites.
permissions-site-local-network-disable-label =
    .label = Bloquer les nouvelles demandes d’accès aux applications et services sur les appareils connectés à votre réseau Wi-Fi ou à votre réseau local.
permissions-site-local-network-disable-desc = Activer ce paramètre empêchera tous les sites web non listés ci-dessus de demander l’accès aux applications et aux services sur les appareils connectés à votre Wi-Fi ou à votre réseau local. Certaines fonctionnalités de sites web pourraient ne plus fonctionner.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Paramètres - Permissions pour le microphone
permissions-site-microphone-desc = Les sites web suivants ont demandé l’accès à votre microphone. Vous pouvez spécifier quels sites web sont autorisés à accéder à votre microphone. Vous pouvez également bloquer les nouvelles demandes d’accès à votre microphone.
permissions-site-microphone-disable-label =
    .label = Bloquer les nouvelles demandes d’accès à votre microphone
permissions-site-microphone-disable-desc = Cela empêchera tous les sites web non listés ci-dessus de demander l’autorisation d’accéder à votre microphone. Bloquer l’accès à votre microphone peut invalider les fonctionnalités de certains sites web.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Paramètres - Permissions pour les haut-parleurs
permissions-site-speaker-desc = Les sites web suivants ont demandé à sélectionner un périphérique de sortie audio. Vous pouvez décider quels sites web sont autorisés à sélectionner un périphérique de sortie audio.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = Exceptions au DNS via HTTPS
permissions-exceptions-manage-doh-desc = { -brand-short-name } n’utilisera pas le DNS sécurisé sur ces sites et leurs sous-domaines.
permissions-doh-entry-field = Saisissez le nom de domaine du site web
    .accesskey = d
permissions-doh-add-exception =
    .label = Ajouter
    .accesskey = A
permissions-doh-col =
    .label = Domaine
permissions-doh-remove =
    .label = Supprimer
    .accesskey = S
permissions-doh-remove-all =
    .label = Tout supprimer
    .accesskey = T


permissions-site-webgl-desc = Les sites web suivants ont demandé à créer un contexte WebGL. Vous pouvez spécifier quels sites web sont autorisés à créer un contexte WebGL. Vous pouvez également bloquer les nouvelles demandes de création de contexte WebGL.
permissions-site-webgl-window2 =
    .title = Paramètres - Permissions WebGL
    .style = { permissions-window2.style }
