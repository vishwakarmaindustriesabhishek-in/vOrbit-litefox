# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Downloads - Files and applications

global-privacy-control-description =
    .label = Informuj witryny, że mają nie sprzedawać ani nie udostępniać moich danych.
    .accesskey = n
non-technical-privacy-group =
    .label = Preferencje dotyczące prywatności na witrynach
do-not-track-removal3 =
    .message = Funkcja „Do Not Track” (prośba o nieśledzenie) nie jest już obsługiwana.
non-technical-privacy-heading =
    .label = Dodatkowa ochrona
preferences-privacy-relay-available =
    .description = Ukrywa prawdziwy adres e-mail, aby chronić skrzynkę odbiorczą przed spamem.
    .label = Proponuj maski dla adresu e-mail { -relay-brand-name }
# Do not translate.
# "Global Privacy Control" or "GPC" are a web platform feature name and abbreviation
# included to facilitate power-user search of the about:preferences page.
global-privacy-control-search = Global Privacy Control (GPC)
settings-page-title = Ustawienia
category-nav-heading =
    .heading = Ustawienia
# This is used to determine the width of the search field in about:preferences,
# in order to make the entire placeholder string visible
#
# Please keep the placeholder string short to avoid truncation.
#
# Notice: The value of the `.style` attribute is a CSS string, and the `width`
# is the name of the CSS property. It is intended only to adjust the element's width.
# Do not translate.
search-input-box2 =
    .placeholder = Szukaj w ustawieniach
    .style = width: 15.4em
managed-notice = Przeglądarka jest zarządzana przez Twoją organizację
managed-notice-info-icon =
    .alt = Informacje
managed-notice-nav =
    .label = Przeglądarka jest zarządzana przez Twoją organizację
tls-key-logging-notice-nav =
    .label = Aplikacja lub usługa może podejrzeć zaszyfrowany ruch.
category-list =
    .aria-label = Kategorie
pane-general-title = Ogólne
pane-home-title = Uruchamianie
pane-home-startup-title2 = Strona startowa i uruchamianie
    .title = Strona startowa i uruchamianie
pane-search-title2 = Wyszukiwanie
    .title = Wyszukiwanie
pane-privacy-title3 = Prywatność i bezpieczeństwo
    .title = Prywatność i bezpieczeństwo
pane-privacy-section =
    .heading = Prywatność i bezpieczeństwo
pane-sync-title3 = Synchronizacja
pane-ai-controls-title2 = Sterowanie SI
    .title = Sterowanie SI
pane-about-firefox-title = O programie { -brand-short-name }
    .title = { pane-about-firefox-title }
pane-appearance-title = Wygląd
    .title = { pane-appearance-title }
pane-downloads-title2 = Pobieranie
    .title = Pobieranie
pane-downloads3 =
    .heading = Pobieranie
pane-accessibility-title = Ułatwienia dostępu
    .title = { pane-accessibility-title }
pane-languages-title2 = Języki
    .title = Języki
preferences-languages-header3 =
    .heading = Języki
settings-pane-labs-title2 = { -firefoxlabs-brand-name }
    .title = { -firefoxlabs-brand-name }
settings-pane-labs-header =
    .heading = { -firefoxlabs-brand-name }
pane-experimental-description4 = Wypróbuj nasze funkcje eksperymentalne! Są w fazie rozwoju i ciągłej zmiany, co może mieć wpływ na działanie { -brand-short-name(case: "gen") }. Otrzymujemy dane o tym, jak użytkownik korzysta z tych funkcji wyłącznie wtedy, gdy opcja <a data-l10n-name="data-collection">wysyłania danych technicznych i o interakcjach</a> jest włączona.
pane-experimental-reset =
    .label = Przywróć domyślne
    .accesskey = P
help-button-label2 = Pomoc { -brand-short-name(case: "gen") }
    .title = Pomoc { -brand-short-name(case: "gen") }
addons-button-label2 = Rozszerzenia i motywy
    .title = Rozszerzenia i motywy
focus-search =
    .key = f
close-button =
    .aria-label = Zamknij
do-not-track-removal2 =
    .label = Nagłówek „Do Not Track” (prośba o nieśledzenie) nie jest już obsługiwany
applications-setting-new-file-types =
    .label = Co { -brand-short-name } ma robić z innymi plikami?

## Browser Restart Dialog

feature-enable-requires-restart = Konieczne jest ponowne uruchomienie { -brand-short-name(case: "gen") }, aby włączyć tę funkcję.
feature-disable-requires-restart = Konieczne jest ponowne uruchomienie { -brand-short-name(case: "gen") }, aby wyłączyć tę funkcję.
should-restart-title = Ponowne uruchomienie { -brand-short-name(case: "gen") }
should-restart-ok = Uruchom { -brand-short-name(case: "acc") } ponownie
cancel-no-restart-button = Anuluj
restart-later = Później

## Extension Control Notifications
##
## These strings are used to inform the user
## about changes made by extensions to browser settings.
##
## <img data-l10n-name="icon"/> is going to be replaced by the extension icon.
##
## Variables:
##   $name (string) - Name of the extension

# This string is shown to notify the user that the password manager setting
# is being controlled by an extension
extension-controlling-password-saving = Rozszerzenie <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontroluje to ustawienie.
# This string is shown to notify the user that their notifications permission
# is being controlled by an extension.
extension-controlling-web-notifications = Rozszerzenie <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontroluje to ustawienie.
# This string is shown to notify the user that Container Tabs
# are being enabled by an extension.
extension-controlling-privacy-containers = Rozszerzenie <img data-l10n-name="icon"/> <strong>{ $name }</strong> wymaga włączonych „Kart w kontenerach”.
# This string is shown to notify the user that their content blocking "All Detected Trackers"
# preferences are being controlled by an extension.
extension-controlling-websites-content-blocking-all-trackers = Rozszerzenie <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontroluje to ustawienie.
# This string is shown to notify the user that their proxy configuration preferences
# are being controlled by an extension.
extension-controlling-proxy-config = Rozszerzenie <img data-l10n-name="icon"/> <strong>{ $name }</strong> kontroluje, jak { -brand-short-name } łączy się z Internetem.
# This string is shown after the user disables an extension to notify the user
# how to enable an extension that they disabled.
#
# <img data-l10n-name="addons-icon"/> will be replaced with Add-ons icon
# <img data-l10n-name="menu-icon"/> will be replaced with Menu icon
extension-controlled-enable = Aby włączyć rozszerzenie, przejdź do sekcji dodatki <img data-l10n-name="addons-icon"/> w menu <img data-l10n-name="menu-icon"/>.
extension-controlled-enable-2 = Aby ponownie włączyć to rozszerzenie, otwórz <a data-l10n-name="addons-link">Rozszerzenia i motywy</a>.
# This string is shown to notify the user that their home page or new tab preferences
# are being controlled by an extension.
extension-controlling-homepage = Rozszerzenie „{ $name }” kontroluje część ustawień strony startowej.

## Preferences UI Search Results

search-results-header = Wyniki wyszukiwania
# `<span data-l10n-name="query"></span>` will be replaced by the search term.
search-results-empty-message2 = Niestety! W ustawieniach niczego nie odnaleziono dla wyszukiwania „<span data-l10n-name="query"></span>”.
search-results-help-link = Potrzebujesz pomocy? Odwiedź <a data-l10n-name="url">pomoc { -brand-short-name(case: "gen") }</a>.

## General Section

always-check-default =
    .label = Sprawdzaj, czy { -brand-short-name } jest domyślną przeglądarką
    .accesskey = e
startup-restore-windows-and-tabs =
    .label = Otwieraj poprzednie okna i karty
    .accesskey = w
startup-windows-launch-on-login-profile-disabled =
    .message = Włącz tę preferencję, zaznaczając opcję „{ profile-manager-use-selected.label }” w oknie „Wybierz profil użytkownika”.
windows-launch-on-login =
    .label = Automatycznie otwieraj { -brand-short-name(case: "acc") } po włączeniu komputera
    .accesskey = A
windows-launch-on-login-disabled = Ta preferencja została wyłączona w systemie Windows. Aby ją zmienić, przejdź do <a data-l10n-name="startup-link">Autostartu</a> w ustawieniach systemu.
# Option to also opens a new tab, in addition to restoring previous tabs and windows
windows-launch-on-login-open-new-tab =
    .label = Otwieraj także nową kartę
    .accesskey = O
disable-extension =
    .label = Wyłącz rozszerzenie
preferences-data-migration-group =
    .description = Przenieś zakładki, hasła, historię, rozszerzenia i dane automatycznego wypełniania z innej przeglądarki.
    .label = Importowanie danych z innych przeglądarek
preferences-data-migration-button =
    .label = Importuj dane
    .accesskey = m
preferences-profiles-group-header =
    .heading = Profile
preferences-profiles-subpane-description =
    .description = Każdy profil ma osobne dane przeglądania i ustawienia, w tym historię, hasła i nie tylko.
preferences-profiles-section-header =
    .description = Każdy profil ma osobne dane przeglądania i ustawienia, w tym historię, hasła i nie tylko.
    .label = Profile
preferences-manage-profiles-button =
    .label = Zarządzaj profilami
preferences-profiles-settings-button =
    .label = Ustawienia
# This string labels the entire copy profile section in the profiles sub-pane.
preferences-copy-profile-header =
    .description = Nowy profil skopiuje ustawienia, dodatki, historię i zachowane dane, takie jak zakładki i hasła — ale nie skopiuje konta ani informacji o synchronizacji.
    .label = Kopiowanie istniejącego profilu
# This string sits next to the copy controls, both the copy-profile-select
# drop-down and the copy-profile-button, so that the user understands they
# need to first pick a profile to copy, and then click the copy button.
preferences-profile-to-copy =
    .label = Profil do skopiowania
# This string is a placeholder that will be shown in a drop-down list of
# profiles. The user will select a profile, then click the copy button
# to make a copy of that profile.
preferences-copy-profile-select = Wybierz profil
preferences-copy-profile-button = Kopiuj
tabs-browsing-section =
    .heading = Karty i przeglądanie
pane-tabs-browsing-title2 = Karty i przeglądanie
    .title = Karty i przeglądanie
tabs-group-header2 =
    .label = Karty
tabs-opening-heading =
    .label = Otwieranie
tabs-interaction-heading =
    .label = Interakcje
tabs-containers-heading =
    .label = Kontenery
tabs-closing-heading =
    .label = Zamykanie
ctrl-tab-recently-used-order =
    .label = Przełączaj karty za pomocą Ctrl+Tab w kolejności ostatnich wyświetleń
    .accesskey = T
open-new-link-as-tabs =
    .label = Otwieraj odnośniki w kartach zamiast w nowych oknach
    .accesskey = O
open-external-link-next-to-active-tab =
    .label = Otwieraj odnośniki z aplikacji obok aktywnej karty
ask-on-close-multiple-tabs =
    .label = Pytaj o potwierdzenie przed zamknięciem wielu kart
    .accesskey = a
# This string is used for the confirm before quitting preference.
# Variables:
#   $quitKey (string) - the quit keyboard shortcut, and formatted
#                       in the same manner as it would appear,
#                       for example, in the File menu.
ask-on-quit-with-key =
    .label = Pytaj o potwierdzenie przed zamknięciem programu za pomocą { $quitKey }
    .accesskey = P
warn-on-open-many-tabs =
    .label = Ostrzegaj o otwarciu zbyt wielu kart mogących spowolnić { -brand-short-name(case: "acc") }
    .accesskey = m
switch-to-new-tabs-2 =
    .label = Automatycznie przechodź do stron i multimediów otwieranych w nowej karcie
    .accesskey = c
show-tabs-in-taskbar =
    .label = Podgląd kart na pasku zadań Windows
    .accesskey = W
browser-containers-enabled-2 =
    .label = Karty w kontenerach.
    .accesskey = K
browser-containers-learn-more = Więcej informacji
browser-containers-settings-2 =
    .label = Zarządzaj kontenerami
    .accesskey = d
containers-disable-alert-title = Czy zamknąć wszystkie karty w kontenerach?
startup-group =
    .label = Uruchamianie

## Variables:
##   $tabCount (number) - Number of tabs

containers-disable-alert-desc =
    { $tabCount ->
        [one] Jeśli wyłączysz funkcję kart w kontenerach, jedna taka karta zostanie zamknięta. Czy na pewno wyłączyć karty w kontenerach?
        [few] Jeśli wyłączysz funkcję kart w kontenerach, { $tabCount } takie karty zostaną zamknięte. Czy na pewno wyłączyć karty w kontenerach?
       *[many] Jeśli wyłączysz funkcję kart w kontenerach, { $tabCount } takich kart zostanie zamkniętych. Czy na pewno wyłączyć karty w kontenerach?
    }
containers-disable-alert-ok-button =
    { $tabCount ->
        [one] Zamknij kartę w kontenerze
        [few] Zamknij { $tabCount } karty w kontenerach
       *[many] Zamknij { $tabCount } kart w kontenerach
    }

##

containers-disable-alert-cancel-button = Anuluj
containers-remove-alert-title = Usuwanie kontenera
# Variables:
#   $count (number) - Number of tabs that will be closed.
containers-remove-alert-msg =
    { $count ->
        [one] Jeśli usuniesz teraz ten kontener, { $count } karta zostanie zamknięta. Czy na pewno usunąć ten kontener?
        [few] Jeśli usuniesz teraz ten kontener, { $count } karty zostaną zamknięte. Czy na pewno usunąć ten kontener?
       *[many] Jeśli usuniesz teraz ten kontener, { $count } kart zostanie zamkniętych. Czy na pewno usunąć ten kontener?
    }
containers-remove-ok-button = Usuń
containers-remove-cancel-button = Nie usuwaj
settings-tabs-show-image-in-preview =
    .label = Podgląd po najechaniu kursorem na kartę
    .accessKey = P
settings-tabs-drag-to-create-tab-groups =
    .label = Przeciąganie kart na siebie tworzy grupy
browser-layout-header2 =
    .label = Układ przeglądarki
browser-layout-horizontal-tabs2 =
    .description = Karty na górze
    .label = Karty poziome
    .title = Karty na górze
browser-layout-vertical-tabs2 =
    .description = Karty z boku w panelu bocznym
    .label = Karty pionowe
    .title = Karty z boku w panelu bocznym
browser-layout-show-sidebar2 =
    .description = Szybki dostęp do zakładek, kart z telefonu, czatbotów opartych na sztucznej inteligencji i nie tylko bez wychodzenia z głównego okna
    .label = Panel boczny
page-navigation-group =
    .label = Poruszanie się po stronach

## General Section - Language & Appearance

language-and-appearance-header = Język i wygląd
appearance-group2 =
    .description = Niektóre witryny zmieniają swoje kolory, aby pasować do preferencji użytkownika. Wybierz swój schemat kolorów.
    .label = Wygląd witryn internetowych
preferences-web-appearance-choice-auto3 =
    .label = Motyw systemu
    .title = Automatycznie zmieniaj tła i treści witryn na podstawie ustawień systemu i motywu { -brand-short-name(case: "gen") }.
preferences-web-appearance-choice-light2 =
    .label = Jasny
    .title = Używaj jasnego wyglądu teł i treści witryn.
preferences-web-appearance-choice-dark2 =
    .label = Ciemny
    .title = Używaj ciemnego wyglądu teł i treści witryn.
web-appearance-group =
    .aria-label = Wygląd witryn internetowych
# This can appear when using windows HCM or "Override colors: always" without
# system colors.
preferences-web-appearance-override-warning3 =
    .message = Ustawienia sterowania kontrastem mają pierwszeństwo przed ustawieniami wyglądu witryn.
preferences-web-appearance-link =
    .label = Zarządzaj motywami { -brand-short-name(case: "gen") } w Rozszerzenia i motywy
preferences-contrast-control-group =
    .description = Witryny wykorzystują różnorodne kolory tekstu i tła. Aby uzyskać spójny kontrast, można ustawić te same kolory dla wszystkich witryn.
    .label = Kontrast witryn
preferences-contrast-control-radio-group =
    .label = Zastępowanie kolorów
preferences-contrast-control-use-platform-settings =
    .label = Automatyczne (ustawienia systemu)
    .accesskey = A
preferences-contrast-control-off =
    .label = Wyłączone
    .accesskey = W
preferences-contrast-control-custom =
    .label = Inne
    .accesskey = I
preferences-colors-manage-button2 =
    .label = Zarządzaj kolorami
    .accesskey = k
preferences-colors-manage-button =
    .label = Zarządzaj kolorami…
    .accesskey = k
preferences-fonts-header2 =
    .label = Czcionki
preferences-default-zoom-label =
    .label = Domyślne powiększenie:
    .accesskey = D
# Variables:
#   $percentage (number) - Zoom percentage value
preferences-default-zoom-value =
    .label = { $percentage }%
preferences-zoom-text-only =
    .label = Powiększaj tylko tekst
    .accesskey = P
preferences-text-zoom-override-warning2 =
    .message = Włączenie opcji „Powiększaj tylko tekst” i ustawienie domyślnego powiększenia na inną wartość niż 100% może spowodować niepoprawne wyświetlanie niektórych stron.
language-header = Język
choose-language-description = Wybierz preferowany język, w jakim mają być wyświetlane strony
website-language-heading =
    .description = Część witryn jest dostępna w wielu językach. Wybierz języki w preferowanej kolejności.
    .label = Język witryn
website-preferred-language =
    .label = Preferowane języki
website-language-list =
    .aria-label = Preferowane języki
website-add-language =
    .label = Dodaj język
website-add-language-button =
    .aria-label = Dodaj wybrany język
    .title = Dodaj wybrany język
# The pattern used to generate strings presented to the user in the
# website languages selection list.
#
# Example:
#   Icelandic
#   Spanish (Chile)
#
# Variables:
#   $locale (String) - A name of the locale (for example: "Icelandic", "Spanish (Chile)")
website-remove-language-button =
    .aria-label = Usuń { $locale }
    .title = Usuń { $locale }
choose-button =
    .label = Wybierz…
    .accesskey = e
choose-browser-language-description = Wybierz język używany do wyświetlania interfejsu użytkownika { -brand-short-name(case: "gen") } (menu, komunikaty, powiadomienia itp.).
manage-browser-languages-button =
    .label = Wybierz alternatywne…
    .accesskey = W
confirm-browser-language-change-description = Uruchom { -brand-short-name(case: "acc") } ponownie, aby zastosować zmiany.
confirm-browser-language-change-button = Uruchom ponownie
browser-language-heading =
    .description = Wybierz język używany do wyświetlania interfejsu użytkownika { -brand-short-name(case: "gen") } (menu, komunikaty, powiadomienia itp.).
    .label = Język przeglądarki
browser-language-preferred-label =
    .label = Preferowany język
browser-language-fallback-label =
    .description = Używany, kiedy tłumaczenie na preferowany język jest niepełne.
    .label = Język zapasowy
browser-language-install-error =
    .message = { -brand-short-name } obecnie nie może uaktualnić listy języków. Sprawdź połączenie z Internetem lub spróbuj ponownie.
fx-translate-web-pages = { -translations-brand-name }
translate-exceptions =
    .label = Wyjątki…
    .accesskey = i
settings-translations-header =
    .aria-label = Tłumaczenia
    .description = Tłumacz strony lub zaznaczony tekst. Aby chronić Twoją prywatność, tłumaczenia nie opuszczają tego urządzenia.
    .label = Tłumaczenia
settings-translations-offer-to-translate-label =
    .label = Proponuj tłumaczenie całych stron
settings-translations-more-settings-button =
    .description = Ustaw preferencje języków, witryn i tłumaczenia bez połączenia z Internetem.
    .label = Więcej ustawień tłumaczenia
settings-translations-subpage-header =
    .heading = Więcej ustawień tłumaczenia
settings-translations-subpage-speed-up-translation-header =
    .description = Pobierz pełne języki, aby tłumaczyć szybciej i bez połączenia z Internetem.
    .label = Przyspiesz tłumaczenie
settings-translations-subpage-automatic-translation-header =
    .label = Automatyczne tłumaczenie
settings-translations-subpage-always-translate-header =
    .label = Zawsze tłumacz te języki
settings-translations-subpage-never-translate-header =
    .label = Nigdy nie tłumacz tych języków
settings-translations-subpage-never-translate-sites-header =
    .label = Nigdy nie tłumacz tych witryn
# The icon placeholders show the translations button and the settings gear in the urlbar panel.
settings-translations-subpage-never-translate-sites-description = Aby dodać witrynę, otwórz <img data-l10n-name="translations-icon"/> panel tłumaczenia, wybierz <img data-l10n-name="settings-icon"/> ustawienia tłumaczenia, a następnie „Nigdy nie tłumacz tej witryny”
settings-translations-subpage-language-select-option =
    .label = Dodaj język
settings-translations-subpage-language-add-button =
    .aria-label = Dodaj język
    .title = Dodaj język
settings-translations-subpage-download-languages-header =
    .label = Pobierz języki
settings-translations-subpage-download-languages-select-option =
    .label = Wybierz język
settings-translations-subpage-download-languages-button =
    .aria-label = Pobierz język
    .title = Pobierz język
# Variables:
#   $language (string) - Localized name of the language to download.
#   $size (string) - Download size in megabytes, formatted for the locale.
settings-translations-subpage-download-language-option = { $language } ({ $size } MB)
    .label = { $language } ({ $size } MB)
settings-translations-subpage-no-languages-downloaded =
    .label = Nie pobrano żadnych języków
settings-translations-subpage-no-languages-added =
    .label = Nie dodano żadnych języków
settings-translations-subpage-download-progress = Pobieranie…
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-error = Nie można pobrać języka ({ $language }, { $size } MB)
settings-translations-subpage-download-retry-button =
    .label = Spróbuj ponownie
# Variables:
#   $language (string) - The localized display name of the language.
#   $size (string) - The download size of the language in megabytes.
settings-translations-subpage-download-delete-confirm = Czy usunąć { $language } ({ $size } MB)?
settings-translations-subpage-download-delete-button =
    .label = Usuń
settings-translations-subpage-download-cancel-button =
    .label = Anuluj
settings-translations-subpage-no-sites-added =
    .label = Nie dodano żadnych witryn
# Variables:
#    $localeName (string) - Localized name of the locale to be used.
use-system-locale =
    .label = Używaj ustawień systemu operacyjnego dla języka „{ $localeName }” do formatowania dat, czasu, liczb i miar
settings-spellcheck-header =
    .label = Sprawdzanie pisowni
check-user-spelling =
    .label = Sprawdzaj pisownię podczas wprowadzania tekstu.
    .accesskey = S
spellcheck-download-dictionaries =
    .label = Pobierz słowniki
spellcheck-promo =
    .heading = Jak korzystać ze sprawdzania pisowni
    .message = Kliknij pole tekstowe prawym przyciskiem, aby włączyć lub wyłączyć sprawdzanie pisowni albo zmienić język. Nie wszystkie pola obsługują sprawdzanie pisowni.

## Downloads - Files and applications

files-and-applications-title = Pliki i aplikacje
download-save-files-header =
    .label = Pobierane pliki zapisuj do:
download-save-where-3 =
    .aria-label = Pobierane pliki zapisuj do:
download-always-ask-where2 =
    .label = Pytaj, gdzie zapisać plik przed pobraniem
    .accesskey = t
download-private-browsing-delete2 =
    .label = Usuwaj pliki pobrane w oknie prywatnym po zamknięciu
    .accesskey = U
applications-header = Aplikacje
applications-description = Wybierz, jak { -brand-short-name } będzie obsługiwać pobierane z sieci pliki i aplikacje używane podczas przeglądania.
applications-setting2 =
    .description = Wybierz, jak { -brand-short-name } będzie obsługiwać pobierane pliki i treści.
    .label = Pliki i aplikacje
applications-filter =
    .placeholder = Typ pliku lub nazwa aplikacji
applications-type-column =
    .label = Typ zawartości
    .accesskey = T
applications-type-heading = Typ zawartości
applications-action-column =
    .label = Czynność
    .accesskey = C
applications-action-heading = Czynność
# Variables:
#   $extension (String) - file extension (e.g .TXT)
applications-file-ending = plik { $extension }
applications-action-save =
    .label = Zapisz plik
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app =
    .label = Użyj aplikacji { $app-name }
# Variables:
#   $app-name (String) - Name of an application (e.g Adobe Acrobat)
applications-use-app-default =
    .label = Użyj aplikacji { $app-name } (domyślnej)
applications-use-os-default =
    .label =
        { PLATFORM() ->
            [macos] Użyj domyślnej aplikacji systemu macOS
            [windows] Użyj domyślnej aplikacji systemu Windows
           *[other] Użyj domyślnej aplikacji systemu
        }
applications-use-other =
    .label = Użyj innej aplikacji…
applications-select-helper = Wybierz aplikację pomocniczą
applications-manage-app =
    .label = Szczegóły aplikacji…
applications-always-ask =
    .label = Zawsze pytaj
# Variables:
#   $type-description (string) - Description of the type (e.g "Portable Document Format")
#   $type (string) - The MIME type (e.g application/binary)
applications-type-description-with-type = { $type-description } ({ $type })
# Variables:
#   $extension (string) - File extension (e.g .TXT)
#   $type (string) - The MIME type (e.g application/binary)
applications-file-ending-with-type = { applications-file-ending } ({ $type })
applications-open-inapp =
    .label = Otwórz w { -brand-short-name(case: "loc") }

## The strings in this group are used to populate
## selected label element based on the string from
## the selected menu item.

applications-action-save-label =
    .value = { applications-action-save.label }
applications-use-app-label =
    .value = { applications-use-app.label }
applications-open-inapp-label =
    .value = { applications-open-inapp.label }
applications-always-ask-label =
    .value = { applications-always-ask.label }
applications-use-app-default-label =
    .value = { applications-use-app-default.label }
applications-use-other-label =
    .value = { applications-use-other.label }
applications-use-os-default-label =
    .value = { applications-use-os-default.label }

## Firefox updates

applications-handle-new-file-types-description = Co { -brand-short-name } ma robić z innymi plikami?
applications-save-for-new-types =
    .label = Zapisuj pliki
    .accesskey = s
applications-save-for-new-types2 =
    .label = Automatycznie zapisuj pliki
    .accesskey = s
applications-ask-before-handling =
    .label = Pytaj, czy otworzyć lub zapisać pliki
    .accesskey = P
applications-ask-before-handling2 =
    .label = Pytaj, czy otworzyć lub zapisać plik
    .accesskey = P
drm-group =
    .label = Treści DRM (Digital Rights Management)
play-drm-content =
    .label = Odtwarzaj treści chronione przez DRM.
    .accesskey = O
play-drm-content-learn-more = Więcej informacji
# Variables:
# $version (string) - Firefox version
update-application-version = Wersja: { $version }. <a data-l10n-name="learn-more">Co nowego</a>
update-history-2 =
    .label = Wyświetl historię aktualizacji
    .accesskey = W
update-application-installation =
    .label = Instalacja
update-application-radio-group =
    .aria-label = Instalacja
update-application-auto-2 =
    .label = Automatycznie instaluj aktualizacje (zalecane)
    .accesskey = A
update-application-check-choose-2 =
    .label = Sprawdzaj dostępność aktualizacji i pytaj o ich instalację
    .accesskey = S
update-application-background-enabled =
    .label = Kiedy { -brand-short-name } nie jest włączony
    .accesskey = K
update-application-warning-cross-user-setting-2 =
    .message = To ustawienie będzie obowiązywać dla wszystkich kont systemu Windows i profilów { -brand-short-name(case: "gen") } używających tej instalacji.
update-application-suppress-prompts-2 =
    .label = Pokazuj mniej przypomnień o aktualizacjach
    .accesskey = P
update-setting-write-failure-title2 = Błąd podczas zachowywania ustawień aktualizacji
# Variables:
#   $path (string) - Path to the configuration file
# The newlines between the main text and the line containing the path is
# intentional so the path is easier to identify.
update-setting-write-failure-message2 =
    W { -brand-short-name(case: "loc") } wystąpił błąd i nie zachowano tej zmiany. Zauważ, że zmiana tego ustawienia aktualizacji wymaga uprawnienia do zapisu do poniższego pliku. Ty lub administrator komputera może rozwiązać błąd przez udzielenie grupie „Użytkownicy” pełnej kontroli nad tym plikiem.
    
    Nie można zapisać do pliku: { $path }
update-in-progress-title = Trwa aktualizacja
update-in-progress-message = Czy { -brand-short-name } ma kontynuować tę aktualizację?
update-in-progress-ok-button = &Odrzuć
# Continue is the cancel button so pressing escape or using a platform standard
# method of closing the UI will not discard the update.
update-in-progress-cancel-button = &Kontynuuj

## About Firefox

about-firefox-header =
    .heading = O programie { -brand-short-name }

## Firefox updates

update-application-heading =
    .description = Aktualizacje zwiększają szybkość, stabilność i bezpieczeństwo { -brand-short-name(case: "gen") }.
    .label = Aktualizacje { -brand-short-name(case: "gen") }
update-application-suppress-prompts-heading =
    .label = Powiadomienia
update-application-updates-managed-by-os =
    .message = Aktualizacje są zarządzane przez system operacyjny

## Firefox support

support-application-heading =
    .description = Rozwiązuj problemy lub dziel się pomysłami ze społecznością.
    .label = Pomoc { -brand-short-name(case: "gen") }
support-get-help =
    .label = Pomoc
support-share-ideas =
    .label = Podziel się pomysłami i opiniami

## Firefox newsletter

newsletter-settings-heading =
    .description = Aktualności, instrukcje i porady, jak najlepiej wykorzystać { -brand-product-name(case: "acc") }.
    .label = Biuletyn { -brand-product-name(case: "gen") }
newsletter-sign-up-link =
    .label = Subskrybuj

## General Section - Performance

performance-settings-learn-more = Więcej informacji
performance-allow-hw-accel =
    .label = Korzystaj ze sprzętowego przyspieszania, jeśli jest dostępne
    .accesskey = s
performance-limit-content-process-option = Limit liczby procesów treści:
    .accesskey = o
performance-limit-content-process-enabled-desc = Więcej procesów treści może poprawić wydajność przy wielu otwartych kartach, ale zwiększy też zapotrzebowanie na pamięć.
performance-limit-content-process-blocked-desc = Zmiana liczby procesów jest możliwa, jeśli { -brand-short-name } został uruchomiony z obsługą wielu procesów. <a data-l10n-name="learn-more">Jak sprawdzić, czy obsługa wielu procesów jest włączona</a>?
# Variables:
#   $num (number) - Default value of the `dom.ipc.processCount` pref.
performance-default-content-process-count =
    .label = { $num } (domyślnie)
performance-group =
    .label = Wydajność
performance-use-recommended-settings-checkbox-2 =
    .description = Ustawienia te są specjalnie dostosowane do tego sprzętu i systemu operacyjnego.
    .label = Zalecane ustawienia wydajności
    .accesskey = w

## Accessibility page

browsing-use-autoscroll =
    .label = Używaj automatycznego przewijania
    .accesskey = y
keyboard-and-scrolling-group =
    .label = Nawigacja i przewijanie za pomocą klawiatury
motion-and-link-group =
    .label = Ruch i wygląd odnośników
browsing-use-smooth-scrolling =
    .label = Używaj płynnego przewijania
    .accesskey = n
browsing-gtk-use-non-overlay-scrollbars =
    .label = Zawsze widoczne paski przewijania
    .accesskey = w
browsing-always-underline-links =
    .label = Podkreślaj wszystkie odnośniki
    .accesskey = k
browsing-use-onscreen-keyboard =
    .label = Wyświetlaj klawiaturę ekranową, gdy zachodzi taka potrzeba
    .accesskey = e
browsing-use-cursor-navigation =
    .label = Zawsze używaj klawiszy kursora do nawigacji po stronach
    .accesskey = g
browsing-use-full-keyboard-navigation =
    .label = Używaj klawisza Tab do przechodzenia między elementami formularzy a odnośnikami
    .accesskey = T
browsing-search-on-start-typing =
    .label = Rozpoczynaj wyszukiwanie podczas wpisywania tekstu
    .accesskey = R
settings-keyboard-shortcuts-group =
    .description = Można zmieniać sposób poruszania się po { -brand-short-name(case: "loc") }.
    .label = Skróty klawiaturowe
settings-keyboard-shortcuts-customkeys-link =
    .label = Dostosuj skróty klawiaturowe
# Link that takes the user to the Search category of settings, where the
# address bar options live.
settings-keyboard-shortcuts-addressbar-link =
    .label = Dostosuj ustawienia paska adresu w sekcji Wyszukiwanie
settings-media-group =
    .label = Multimedia
browsing-picture-in-picture-toggle-enabled-2 =
    .label = Obraz w obrazie.
    .accesskey = O
browsing-picture-in-picture-enable-when-switching-tabs =
    .label = Kontynuuj odtwarzanie w trybie „Obraz w obrazie” po przełączeniu karty
    .accesskey = K
browsing-media-control =
    .label = Steruj multimediami za pomocą klawiatury, zestawu słuchawkowego lub interfejsu wirtualnego.
    .accesskey = m
recommendations-group =
    .label = Polecane
browsing-cfr-recommendations =
    .label = Polecaj rozszerzenia podczas przeglądania.
    .accesskey = P
browsing-cfr-features =
    .label = Polecaj funkcje podczas przeglądania.
    .accesskey = u
browsing-group =
    .label = Przeglądanie
preferences-accessibility-header =
    .heading = Ułatwienia dostępu
preferences-default-zoom-select =
    .aria-label = Domyślne powiększenie
preferences-fonts-family =
    .label = Czcionka
    .accesskey = C
preferences-fonts-size =
    .label = Rozmiar czcionki
    .accesskey = R
preferences-fonts-advanced-settings =
    .label = Ustawienia zaawansowane
    .accesskey = z

## General Section - Proxy

network-proxy-group2 =
    .description = Konfiguruj, jak { -brand-short-name } ma się łączyć z Internetem.
    .label = Ustawienia serwerów proxy
network-proxy-connection-settings2 =
    .description = Zmiana tych ustawień może spowodować problemy z połączeniem
    .label = Konfiguruj serwery proxy
    .accesskey = p

## Home Section

home-new-windows-tabs-header = Nowe okna i karty
home-new-windows-tabs-description2 = Wybierz, co ma być wyświetlane przy otwieraniu strony startowej, nowych okien i kart.
home-section =
    .heading = Strona startowa i uruchamianie

## Home Section - Default Browser

home-default-browser-title =
    .label = Domyślna przeglądarka
is-default-browser-2 =
    .message = { -brand-short-name } jest domyślną przeglądarką. Dobry wybór.
is-not-default-browser-2 =
    .message = Hej, { -brand-short-name } nie jest domyślną przeglądarką.
set-as-my-default-browser-2 =
    .label = Ustaw jako domyślną
    .accesskey = U

## Custom Homepage subpage

home-homepage-mode-label = Strona startowa i nowe okna:
home-newtabs-mode-label = Nowa karta:
home-restore-defaults =
    .label = Przywróć domyślne
    .accesskey = P
home-mode-choice-default-fx =
    .label = { -firefox-home-brand-name(capitalization: "lower", case: "nom") } (domyślnie)
home-mode-choice-custom =
    .label = inne strony
home-mode-choice-blank =
    .label = pusta strona
home-homepage-custom-url =
    .placeholder = Adres URL
# This button is shown when the homepage is managed by an extension and is placed below extension-controlling-homepage.
home-homepage-manage-extension-button =
    .label = Zarządzaj rozszerzeniem
# This string has a special case for '1' and [other] (default). If necessary for
# your language, you can add {$tabCount} to your translations and use the
# standard CLDR forms, or only use the form for [other] if both strings should
# be identical.
use-current-pages =
    .label =
        { $tabCount ->
            [1] Użyj bieżącej strony
           *[other] Użyj bieżących stron
        }
    .accesskey = b
choose-bookmark =
    .label = Użyj zakładki…
    .accesskey = z
home-homepage-title =
    .label = Strona startowa
home-homepage-new-windows =
    .label = Nowe okna:
home-homepage-new-tabs =
    .label = Nowa karta:
# This option leads to the "Custom Homepage" subpage
home-homepage-custom-homepage-button =
    .label = Wybierz inną stronę
# Subheader on the Custom Homepage subpage. Followed by a form to enter URLs and a list of URLs already saved, if any.
home-custom-homepage-card-header =
    .label = Adresy stron
home-custom-homepage-list =
    .aria-label = Adresy stron
home-custom-homepage-address =
    .placeholder = Wpisz adres
home-custom-homepage-address-button =
    .label = Dodaj adres
# Shown when no custom websites/URLs to use as a homepage have been added yet
home-custom-homepage-no-results =
    .label = Nie dodano jeszcze żadnych stron.
home-custom-homepage-delete-address-button =
    .aria-label = Usuń adres
    .title = Usuń adres
# Further options to use when setting the home page. Two action buttons are placed in line with this prompt
# to replace the current home page with a currently open page or bookmark.
home-custom-homepage-replace-with-prompt =
    .label = Zastąp przez
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-current-pages-button =
    .label = obecnie otwarte strony
# Button that appears in-line after text "Replace with" (home-custom-homepage-replace-with-prompt)
home-custom-homepage-bookmarks-button =
    .label = zakładki…
# Dropdown option shown when an extension replaces the contents of new windows or tabs.
# Variables:
#   $extension (string) - Name of the extension
home-prefs-homepage-extension-option =
    .label = Rozszerzenie ({ $extension })
home-custom-homepage-header = Inna strona startowa
home-custom-homepage-subpage =
    .heading = Inna strona startowa

## Home Section - Firefox Home Content Customization

home-prefs-content-header2 = { -firefox-home-brand-name }
home-prefs-content-description2 = Wybierz, co wyświetlać na { -firefox-home-brand-name(capitalization: "lower", case: "loc") }.
home-prefs-search-header =
    .label = Pasek wyszukiwania
home-prefs-shortcuts-header =
    .label = Skróty
home-prefs-shortcuts-description = Zachowane i odwiedzane strony.
home-prefs-shortcuts-by-option-sponsored =
    .label = Sponsorowane skróty
home-prefs-recommended-by-header-generic =
    .label = Polecane artykuły
home-prefs-recommended-by-description-generic = Wyjątkowe rzeczy wybrane przez rodzinę { -brand-product-name(case: "gen") }
home-prefs-stories-header =
    .label = Artykuły
home-prefs-stories-description = Spersonalizowane artykuły na podstawie działań użytkownika

##

home-prefs-recommended-by-learn-more = Jak to działa?
home-prefs-recommended-by-option-sponsored-stories =
    .label = Sponsorowane artykuły
home-prefs-highlights-option-visited-pages =
    .label = Historia
home-prefs-highlights-options-bookmarks =
    .label = Zakładki
home-prefs-highlights-option-most-recent-download =
    .label = Ostatnio pobrane pliki
home-prefs-recent-activity-header =
    .label = Ostatnia aktywność
home-prefs-recent-activity-description = Wybierane z ostatnio odwiedzanych stron i treści.
home-prefs-weather-header =
    .label = Pogoda
home-prefs-weather-description = Dzisiejsza prognoza w skrócie
home-prefs-weather-learn-more-link = Więcej informacji
# "Support" here means to help sustain or contribute to something, especially through funding or sponsorship.
home-prefs-support-firefox-header =
    .label = Wspieraj { -brand-product-name(case: "acc") }
home-prefs-mission-message = Nasi sponsorzy wspierają naszą misję budowania lepszej sieci.
home-prefs-mission-message-learn-more-link = Więcej informacji
home-prefs-manage-topics-link = Zarządzaj tematami
home-prefs-choose-wallpaper-link = Wybierz tapetę
# Variables:
#   $num (number) - Number of rows displayed
home-prefs-sections-rows-option =
    .label =
        { $num ->
            [one] { $num } wiersz
            [few] { $num } wiersze
           *[many] { $num } wierszy
        }

## Search Section

search-show-suggestions-option =
    .label = Podpowiedzi wyszukiwania
    .accesskey = P
search-show-suggestions-url-bar-option =
    .label = Podpowiedzi wyszukiwania w wynikach paska adresu
    .accesskey = e
# This string describes what the user will observe when the system
# prioritizes search suggestions over browsing history in the results
# that extend down from the address bar. In the original English string,
# "before" refers to location (appearing most proximate to), not time
# (appearing before).
search-show-suggestions-above-history-option-2 =
    .label = Podpowiedzi wyszukiwania przed historią przeglądania w wynikach paska adresu
search-show-suggestions-private-windows-2 =
    .label = Podpowiedzi wyszukiwania w prywatnych oknach
search-suggestions-cant-show-2 =
    .message = Podpowiedzi wyszukiwania nie będą wyświetlane w wynikach paska adresu, ponieważ wyłączono zachowywanie historii przeglądania { -brand-short-name(case: "gen") }.
addressbar-header-1 =
    .description = Wybierz, które podpowiedzi będą wyświetlane na pasku adresu.
    .label = Pasek adresu
# When Firefox Suggest is enabled, this replaces `addressbar-header-1`.
addressbar-header-firefox-suggest-2 =
    .description = Podpowiedzi od { -brand-short-name(case: "gen") } i naszych partnerów na pasku adresu.
    .label = { -firefox-suggest-brand-name }
# With this option enabled, while on a SERP, the URL normally displayed in the
# address bar will be replaced with the search term used to generate that SERP.
search-show-search-term-option-2 =
    .label = Na stronie wyników pasek adresu wyświetla wyszukiwane słowa
search-separate-default-engine-2 =
    .label = Używaj innej domyślnej wyszukiwarki w oknach prywatnych
    .accesskey = U
search-separate-default-engine-dropdown =
    .aria-label = Domyślna wyszukiwarka w oknach prywatnych
# "Navigation" here means moving around within the address bar and its results
# list, not navigation to the address bar.
addressbar-navigation-group =
    .label = Poruszanie się po pasku adresu
# "Results menu" refers to the menu available on each row of the address bar
# results list, which offers actions such as dismissing the result.
addressbar-skip-result-menu-on-tab =
    .label = Pomijaj menu wyników podczas poruszania się za pomocą klawisza Tab
search-suggestions-header-2 =
    .label = Podpowiedzi wyszukiwarki
search-one-click-header2 = Skróty wyszukiwania
search-one-click-desc = Wybierz dodatkowe wyszukiwarki wyświetlane na dole wyników wyszukiwania w pasku adresu i pasku wyszukiwania.
search-one-click-header-3 =
    .description = Wybierz, które wyszukiwarki i skróty są wyświetlane na pasku adresu.
    .label = Dodatkowe wyszukiwarki
search-engine-list =
    .aria-label = Wyszukiwarki i skróty
update-search-engine-success =
    .message = Pomyślnie zaktualizowano wyszukiwarkę
search-edit-engine-2 =
    .title = Edytuj wyszukiwarkę
search-delete-engine =
    .title = Usuń wyszukiwarkę
search-enable-engine =
    .title = Włącz wyszukiwarkę
search-outlink-to-extensions-page =
    .title = Zarządzaj w rozszerzeniach i motywach
search-choose-engine-column =
    .label = Nazwa
search-choose-keyword-column =
    .label = Słowo kluczowe
search-restore-default =
    .label = Przywróć domyślne
    .accesskey = d
search-remove-engine =
    .label = Usuń
    .accesskey = U
search-add-engine =
    .label = Dodaj
    .accesskey = o
search-add-engine-2 =
    .label = Dodaj wyszukiwarkę
    .accesskey = o
search-edit-engine =
    .label = Edytuj
    .accesskey = E
search-find-more-link = Znajdź więcej wyszukiwarek
search-filtering-for-add-engine = Dodaj wyszukiwarkę
# This warning is displayed when the chosen keyword is already in use
# ('Duplicate' is an adjective)
search-keyword-warning-title = Słowo kluczowe już istnieje
# Variables:
#   $name (string) - Name of a search engine.
search-keyword-warning-engine = Wybrano słowo kluczowe używane obecnie przez wyszukiwarkę { $name }. Należy wybrać inne.
search-keyword-warning-bookmark = Wybrano słowo kluczowe używane obecnie przez zakładkę. Należy wybrać inne.
# This warning is displayed when the chosen name is already in use.
# Variables:
#   $name (string) - Name of a search engine.
edit-engine-name-warning-duplicate = Wyszukiwarka o nazwie „{ $name }” już istnieje. Należy wybrać inną nazwę.
remove-engine-confirmation = Czy na pewno usunąć tę wyszukiwarkę?
remove-engine-remove = Usuń
remove-addon-engine-alert = Przed usunięciem tej wyszukiwarki należy usunąć powiązany z nią dodatek.
search-engine-group =
    .label = Domyślna wyszukiwarka
search-default-engine =
    .aria-label = Domyślna wyszukiwarka
# Header for the search section ("search" is a noun).
search-section =
    .heading = Wyszukiwanie

## Containers Section

containers-section-header2 =
    .heading = Ustawienia kontenerów
containers-card-header2 =
    .description = Rozdzielaj ciasteczka w kontenerach, dzięki czemu można korzystać z różnych kont na tej samej witrynie i ograniczyć śledzenie między witrynami.
    .label = Kontenery
containers-add-button2 =
    .label = Dodaj kontener
    .accesskey = D
containers-list =
    .aria-label = Kontenery
containers-new-tab-check3 =
    .label = Wybieraj kontener dla każdej nowej karty
    .accesskey = W
# Checkbox in the Containers settings. By default, when a link is opened from
# another application, Firefox tries to pick a matching container for it. When
# this checkbox is checked, such links always open outside of any container.
containers-external-links-check =
    .label = Nie używaj kontenerów dla odnośników otwieranych z zewnętrznych aplikacji
    .accesskey = N
containers-new-tab-check2 =
    .description = Spowoduje to otwieranie menu kontenerów po każdym kliknięciu przycisku nowej karty.
    .label = Wybieraj kontener dla każdej nowej karty
    .accesskey = W
containers-settings-button2 =
    .title = Ustawienia
containers-remove-button3 =
    .title = Usuń
containers-sites-card-header =
    .description = Wybierz kontener dla witryny, a { -brand-short-name } będzie go używać przy każdym jej otwarciu.
    .label = Kontenery dla konkretnych witryn
containers-sites-add-button =
    .label = Dodaj witrynę
    .accesskey = D
# The dropdown that picks which container a site opens in.
# Variables:
#   $site (string) - Domain of the website, for example “example.com”.
containers-site-container-select = Kontener dla witryny { $site }
containers-site-remove-button =
    .title = Usuń
containers-remove-button2 =
    .title = Usuń

## Account and sync

sync-group-label =
    .label = Synchronizacja
account-group-label2 =
    .label = Konto
account-disabled-group =
    .description = Ustawienia konta są niedostępne.
    .label = Konto
account-placeholder2 =
    .description = Zaloguj się, a Twoje dane będą prywatne, zaszyfrowane i błyskawicznie dostępne wszędzie tam, gdzie używasz { -brand-short-name(case: "gen") }.
    .label = Nie zalogowano
account-sync-section =
    .heading = Konto i synchronizacja
pane-account-sync-title2 = Konto i synchronizacja
    .title = Konto i synchronizacja

## Firefox account - Signed out. Note that "Sync" and "Firefox account" are now
## more discrete ("signed in" no longer means "and sync is connected").

sync-signedout-caption = Zabierz swoją sieć ze sobą
sync-signedout-description2 = Synchronizuj zakładki, historię, karty, hasła, dodatki i ustawienia między wszystkimi swoimi urządzeniami.
sync-signedout-account-signin3 =
    .label = Zaloguj się do synchronizacji…
    .accesskey = Z
sync-signedout-account-signin-4 =
    .label = Zaloguj się na konto i zacznij synchronizację
    .accesskey = Z
sync-signedout-account-short =
    .label = Zaloguj się
    .accesskey = Z
# This message contains two links and two icon images.
#   `<img data-l10n-name="android-icon"/>` - Android logo icon
#   `<a data-l10n-name="android-link">` - Link to Android Download
#   `<img data-l10n-name="ios-icon">` - iOS logo icon
#   `<a data-l10n-name="ios-link">` - Link to iOS Download
#
# They can be moved within the sentence as needed to adapt
# to your language, but should not be changed or translated.
sync-mobile-promo = Firefox na <a data-l10n-name="android-link">Androida</a> <img data-l10n-name="android-icon"/> i <a data-l10n-name="ios-link">iOS</a> <img data-l10n-name="ios-icon"/> daje możliwość synchronizacji z urządzeniami przenośnymi.

## Firefox account - Signed in

sync-profile-picture-with-alt =
    .alt = Zmień zdjęcie profilowe
    .tooltiptext = Zmień zdjęcie profilowe
sync-profile-picture-account-problem =
    .alt = Zdjęcie profilowe konta
fxa-login-rejected-warning =
    .alt = Ostrzeżenie
sync-sign-out =
    .label = Wyloguj się…
    .accesskey = W
sync-sign-out2 =
    .label = Wyloguj się
    .accesskey = W
sync-manage-account = Zarządzaj kontem
    .accesskey = Z
sync-manage-account2 =
    .label = Zarządzaj kontem
    .accesskey = Z

## Variables
## $email (string) - Email used for Firefox account
## $name (string) - Name used for Firefox account

sync-signedin-unverified = Konto { $email } nie zostało zweryfikowane.
sync-signedin-unverified2 =
    .description = Sprawdź skrzynkę pocztową i oficjalnie potwierdź konto.
    .label = Konto { $email } nie jest jeszcze potwierdzone
sync-signedin-login-failure = Zaloguj się, aby ponownie połączyć konto { $email }
sync-signedin-login-failure2 =
    .description = Zaloguj się z powrotem, aby zacząć synchronizować dane.
    .label = Wylogowano z konta { $email }
sync-account-signed-in =
    .label = { $email }
sync-account-signed-in-display-name =
    .description = { $email }
    .label = { $name }

##

sync-verify-account =
    .label = Zweryfikuj konto
    .accesskey = w
sync-remove-account =
    .label = Usuń konto
    .accesskey = U
sync-sign-in =
    .label = Zaloguj się
    .accesskey = o

## Sync section - enabling or disabling sync.

prefs-syncing-on = Synchronizowanie: włączone
prefs-syncing-on-2 =
    .label = Synchronizowanie jest włączone
prefs-syncing-off = Synchronizowanie: wyłączone
prefs-syncing-off-2 =
    .description = Włącz synchronizację, aby mieć dostęp do zakładek, haseł, historii i innych danych na wszystkich urządzeniach.
    .label = Synchronizowanie jest wyłączone
# This string is shown when the user's device has per-device syncing enabled but sync is disabled on the device.
prefs-syncing-off-3 =
    .description = Włącz synchronizację, aby pobrać zakładki, hasła, historię i inne dane na to urządzenie.
    .label = Synchronizowanie jest wyłączone
prefs-sync-turn-on-syncing =
    .label = Włącz synchronizację…
    .accesskey = s
prefs-sync-turn-on-syncing-2 =
    .label = Włącz synchronizację
    .accesskey = s
prefs-sync-offer-setup-label2 = Synchronizuj zakładki, historię, karty, hasła, dodatki i ustawienia między wszystkimi swoimi urządzeniami.
prefs-sync-now-button =
    .label = Synchronizuj teraz
    .accesskey = S
prefs-sync-now-button-2 =
    .label = Synchronizuj teraz
    .accesskey = S
prefs-syncing-button =
    .label = Synchronizowanie…
prefs-syncing-button-2 =
    .label = Synchronizowanie…
    .title = Synchronizuj teraz
# "Your sync choices" refers to the choices a user makes on what types of data they want to sync
sync-cwts-migration-notification =
    .message = Wybór synchronizowanych danych dotyczy teraz tylko tego urządzenia.

## The list of things currently syncing.

sync-syncing-across-devices-heading = Obecnie synchronizowane na wszystkich połączonych urządzeniach:
sync-syncing-across-devices-heading-2 = Dane synchronizowane między urządzeniami
sync-syncing-across-devices-heading-3 = Dane synchronizowane na tym urządzeniu
sync-syncing-across-devices-empty-state2 =
    .description = Nic nie jest synchronizowane… jeszcze. Zacznij synchronizację, aby wszystkie Twoje dane były na wszystkich Twoich urządzeniach.
    .label = Zarządzaj synchronizowanymi danymi
sync-syncing-across-devices-empty-state3 =
    .description = Nic nie jest synchronizowane… jeszcze. Wybierz, co synchronizować na tym urządzeniu.
    .label = Zarządzaj synchronizowanymi danymi
sync-currently-syncing-bookmarks = Zakładki
sync-currently-syncing-history = Historia
sync-currently-syncing-tabs = Otwarte karty
sync-currently-syncing-passwords = Hasła
sync-currently-syncing-addresses = Adresy
sync-currently-syncing-payment-methods = Metody płatności
sync-currently-syncing-addons = Dodatki
sync-currently-syncing-settings = Ustawienia
sync-manage-options =
    .label = Zarządzaj synchronizacją…
    .accesskey = d
sync-manage-options-2 =
    .label = Zarządzaj synchronizowanymi danymi
    .accesskey = d
settings-sync-disconnect-button =
    .label = Rozłącz

## The "Choose what to sync" dialog.

sync-engine-bookmarks =
    .label = Zakładki
    .accesskey = Z
sync-engine-history =
    .label = Historia
    .accesskey = H
# This string is a modified noun (i.e. tabs that are open)
sync-engine-tabs2 =
    .label = Otwarte karty
    .tooltiptext = Otwarte karty na innych urządzeniach
    .accesskey = O
sync-engine-tabs =
    .label = Otwarte karty
    .tooltiptext = Lista otwartych stron na wszystkich synchronizowanych urządzeniach
    .accesskey = O
sync-engine-passwords =
    .label = Hasła
    .tooltiptext = Zachowane hasła
    .accesskey = H
sync-engine-addresses2 =
    .label = Adresy
    .tooltiptext = Adresy zachowane w { -brand-short-name(case: "loc") }
    .accesskey = A
sync-engine-payment-methods3 =
    .label = Metody płatności
    .tooltiptext = Zachowane metody płatności
    .accesskey = M
sync-engine-addons2 =
    .label = Dodatki
    .tooltiptext = Rozszerzenia i motywy dodane do { -brand-short-name(case: "gen") } w wersji na komputery
    .accesskey = D
sync-engine-settings2 =
    .label = Ustawienia
    .tooltiptext = Ustawienia { -brand-short-name(case: "gen") }, które można synchronizować
    .accesskey = U
sync-engine-addresses =
    .label = Adresy
    .tooltiptext = Zachowane adresy pocztowe (tylko na komputerach)
    .accesskey = A
sync-engine-payment-methods2 =
    .label = Metody płatności
    .tooltiptext = Nazwiska, numery kart i okresy ważności
    .accesskey = M
sync-engine-addons =
    .label = Dodatki
    .tooltiptext = Rozszerzenia i motywy w wersji na komputery
    .accesskey = D
sync-engine-settings =
    .label = Ustawienia
    .tooltiptext = Zmienione ustawienia ogólne, prywatności i bezpieczeństwa
    .accesskey = U
sync-choose-what-to-sync-dialog4 =
    .buttonlabelaccept = Zachowaj
    .buttonlabelextra2 = Rozłącz…
    .buttonaccesskeyaccept = Z
    .buttonaccesskeyextra2 = R
    .style = min-width: 36em;
    .title = Wybierz, co ma być synchronizowane na wszystkich połączonych urządzeniach
sync-choose-what-to-sync-dialog5 =
    .buttonlabelaccept = Zachowaj
    .buttonlabelextra2 = Rozłącz…
    .buttonaccesskeyaccept = Z
    .buttonaccesskeyextra2 = R
    .style = min-width: 36em;
    .title = Wybierz, co ma być synchronizowane na tym urządzeniu

## The device name controls.

sync-device-name-header = Nazwa urządzenia
sync-device-name-header-2 =
    .label = Nazwa urządzenia
# Variables:
#   $placeholder (string) - The placeholder text of the input
sync-device-name-input =
    .aria-label = Nazwa urządzenia
    .placeholder = { $placeholder }
sync-device-name-change-2 =
    .label = Zmień nazwę urządzenia
    .accesskey = n
sync-device-name-change =
    .label = Zmień nazwę urządzenia…
    .accesskey = n
sync-device-name-cancel =
    .label = Anuluj
    .accesskey = A
sync-device-name-save =
    .label = Zachowaj
    .accesskey = Z
sync-connect-another-device = Połącz inne urządzenie
sync-connect-another-device-2 =
    .label = Połącz inne urządzenie

## Privacy Section

privacy-header = Prywatność

## Privacy Panel Settings

# "Logins" is the former term for "Passwords". Users should find password settings
# by searching for the former term "logins". It's not displayed in the UI.
pane-privacy-passwords-header = Hasła
    .searchkeywords = dane logowania
forms-passwords-header =
    .aria-label = Hasła
    .label = Hasła
# Checkbox to control whether UI is shown to users to save or fill logins/passwords.
forms-ask-to-save-passwords =
    .label = Pytaj o zachowywanie haseł
    .accesskey = P
forms-manage-password-exceptions =
    .label = Zarządzaj wyjątkami zachowywania haseł
    .accesskey = Z
forms-exceptions =
    .label = Wyjątki…
    .accesskey = i
forms-suggest-passwords =
    .label = Proponuj silne hasła.
    .accesskey = s
forms-breach-alerts =
    .label = Powiadomienia o hasłach do stron, z których wyciekły dane.
    .accesskey = o
forms-breach-alerts-learn-more-link = Więcej informacji
preferences-relay-integration-checkbox2 =
    .label = Proponuj maski { -relay-brand-name } do ochrony adresu e-mail.
    .accesskey = m
relay-integration-learn-more-link = Więcej informacji
# Checkbox which controls filling saved logins into fields automatically when they appear, in some cases without user interaction.
forms-fill-usernames-and-passwords =
    .label = Automatyczne wypełnianie nazw użytkownika i haseł
    .accesskey = A
forms-fill-usernames-and-passwords-2 =
    .label = Zachowuj i automatycznie wypełniaj nazwy użytkownika i hasła
    .accesskey = a
forms-saved-passwords =
    .label = Zachowane hasła
    .accesskey = c
forms-saved-passwords-2 =
    .label = Zarządzaj zachowanymi hasłami
    .accesskey = c
forms-saved-passwords-searchkeywords = Dane logowania do poniższych witryn są przechowywane na tym komputerze
# Header for additional protections when managing password settings.
forms-additional-protections-header =
    .label = Dodatkowa ochrona
forms-primary-pw-use =
    .label = Hasło główne.
    .accesskey = H
forms-primary-pw-use-2 =
    .description = Dodaje dodatkową warstwę zabezpieczeń, aby chronić zachowane hasła.
    .label = Hasło główne
    .accesskey = H
forms-primary-pw-set =
    .label = Ustaw hasło główne
forms-primary-pw-on-2 = Hasło główne jest <strong>włączone</strong>
forms-primary-pw-on =
    .label = Hasło główne jest włączone
forms-primary-pw-change-2 =
    .label = Zmień hasło główne
# Label for button to disable primary password.
forms-primary-pw-turn-off =
    .label = Wyłącz hasło główne
# This operation requires the user to authenticate with the operating system (device sign-in)
forms-os-reauth =
    .label = Wymaganie zalogowania się na urządzeniu, aby wypełniać hasła i zarządzać nimi
forms-os-reauth-2 =
    .label = Wymagaj zalogowania się na urządzeniu, aby zarządzać hasłami
forms-primary-pw-learn-more-link = Więcej informacji
# This string uses the former name of the Primary Password feature
# ("Master Password" in English) so that the preferences can be found
# when searching for the old name. The accesskey is unused.
forms-master-pw-change =
    .label = Zmień hasło główne…
    .accesskey = Z
forms-primary-pw-change =
    .label = Zmień hasło główne…
    .accesskey = Z
# Leave this message empty if the translation for "Primary Password" matches
# "Master Password" in your language. If you're editing the FTL file directly,
# use { "" } as the value.
forms-primary-pw-former-name = { "" }
forms-primary-pw-fips-title = Program pracuje obecnie w trybie FIPS. Tryb FIPS wymaga niepustego hasła głównego.
forms-master-pw-fips-desc = Zmiana hasła się nie powiodła.
forms-windows-sso =
    .label = Zezwalaj na pojedyncze logowanie Windows do kont Microsoft, służbowych i szkolnych.
forms-windows-sso-learn-more-link = Więcej informacji
forms-windows-sso-desc = Zarządzaj kontami w ustawieniach urządzenia
windows-passkey-settings-label = Zarządzaj kluczami dostępu w ustawieniach urządzenia
privacy-panel-settings-header =
    .description = { -brand-short-name } pomaga chronić Twoje dane w sieci.
    .label = Ustawienia panelu prywatności
# By “breach message” we mean the UI messaging shown when Firefox detects that a
# site the user has interacted with has been involved in a known data breach
privacy-panel-breach-alerts =
    .label = Wyświetlaj powiadomienia o wyciekach danych
    .accesskey = W

## OS Authentication dialog

# This message can be seen by trying to add a Primary Password.
primary-password-os-auth-dialog-message-win = Aby utworzyć hasło główne, wprowadź swoje dane logowania do systemu Windows. Pomaga to chronić bezpieczeństwo Twoich kont.
# This message can be seen by trying to add a Primary Password.
# The macOS strings are preceded by the operating system with "Firefox is trying to "
# and includes subtitle of "Enter password for the user "xxx" to allow this." These
# notes are only valid for English. Please test in your locale.
primary-password-os-auth-dialog-message-macosx = utworzenie hasła głównego
master-password-os-auth-dialog-caption = { -brand-full-name }
# The macOS string is preceded by the operating system with "Firefox is trying to ".
autofill-creditcard-os-dialog-message =
    { PLATFORM() ->
        [macos] zmiana ustawień metod płatności
       *[other] { -brand-short-name } próbuje zmienić ustawienia metod płatności. Aby na to pozwolić, zaloguj się na swoim urządzeniu.
    }
autofill-creditcard-os-auth-dialog-caption = { -brand-full-name }

## Privacy section - Autofill

autofill-payment-methods-header =
    .aria-label = Metody płatności
autofill-payment-methods-checkbox-message-2 =
    .label = Zachowuj i automatycznie wypełniaj informacje płatnicze.
    .accesskey = m
autofill-payment-methods-manage-payments-title =
    .heading = Zarządzaj metodami płatności
autofill-payment-methods-manage-payments-button =
    .label = Zarządzaj metodami płatności
    .accesskey = d
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-payment-methods-require-device-sign-in-checkbox =
    .label = Wymagaj zalogowania się na urządzeniu przed automatycznym wypełnieniem
    .accesskey = W
# This operation requires the user to authenticate with the operating system (device sign-in)
autofill-reauth-payment-methods-checkbox-2 =
    .label = Wymagaj zalogowania się na urządzeniu, aby automatycznie wypełniać metody płatności i zarządzać nimi.
    .accesskey = W
# Security codes are the CVV/CVC card codes
autofill-payment-methods-save-security-codes-checkbox =
    .label = Zachowuj kody zabezpieczające
    .accesskey = k
autofill-payment-methods-add-button = Dodaj nową metodę płatności
payments-list-header =
    .label = Metody płatności
payments-delete-payment-prompt-title = Czy usunąć tę metodę płatności?
payments-delete-payment-prompt-confirm-button = Usuń
payments-delete-payment-prompt-cancel-button = Anuluj
payments-delete-payment-button-label =
    .aria-label = Usuń
payments-edit-payment-button-label =
    .aria-label = Edytuj
# This message is displayed when no payment methods such as credit card are stored in Firefox
payments-no-payments-stored-message =
    .label = Nie dodano żadnych metod płatności
autofill-addresses-checkbox-message =
    .label = Zachowuj i automatycznie wypełniaj adresy.
    .accesskey = Z
autofill-addresses-manage-addresses-button =
    .label = Zarządzaj adresami i nie tylko
    .accesskey = d
addresses-list-header =
    .label = Adresy
addreses-delete-address-button-label =
    .aria-label = Usuń
addreses-edit-address-button-label =
    .aria-label = Edytuj
addresses-delete-address-prompt-title = Czy usunąć ten adres?
addresses-delete-address-prompt-confirm-button = Usuń
addresses-delete-address-prompt-cancel-button = Anuluj
autofill-addresses-add-button = Dodaj nowy adres
autofill-addresses-manage-addresses-title =
    .heading = Zarządzaj adresami i nie tylko
# This message is displayed when no addresses are stored in Firefox
addresses-no-addresses-stored-message =
    .label = Nie dodano żadnych adresów
personal-info-group =
    .label = Dane osobowe
autofill-personal-info-checkbox-message =
    .label = Zachowuj i automatycznie wypełniaj dane osobowe
autofill-personal-info-manage-button =
    .label = Zarządzaj danymi osobowymi
passports-list-header =
    .label = Paszporty
passports-delete-passport-button-label =
    .aria-label = Usuń
passports-edit-passport-button-label =
    .aria-label = Edytuj
passports-delete-passport-prompt-title = Czy usunąć ten paszport?
passports-delete-passport-prompt-confirm-button = Usuń
passports-delete-passport-prompt-cancel-button = Anuluj
autofill-passports-add-button = Dodaj nowy paszport
autofill-personal-info-manage-title =
    .heading = Zarządzaj danymi osobowymi
# This message is displayed when no passports are stored in Firefox
passports-no-passports-stored-message =
    .label = Nie dodano żadnych paszportów
pane-passwords-autofill-title2 = Hasła i automatyczne wypełnianie
    .title = Hasła i automatyczne wypełnianie
preferences-passwords-autofill-header =
    .heading = Hasła i automatyczne wypełnianie
# These values are displayed for each credit card record listed on the Manage Payment methods
# settings page.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
payment-moz-box-item =
    .description = { $expDate }
    .label = { $cardNumber }
# Used in place of payment-moz-box-item when a security code is saved alongside
# the card. Only the presence of a saved security code is ever shown, never the
# code itself: "•••" stands for the hidden code, so keep it as is rather than
# translating it into words.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $expDate (string) - The obscured expiry date of the credit card (for example: XX/2027)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-with-security-code-2 =
    .description = { $expDate } | { $securityCode } •••
    .label = { $cardNumber }
# Used in place of payment-moz-box-item-with-security-code-2 for a card that has
# a saved security code but no expiry date to show alongside it. "•••" stands for
# the hidden code.
# Variables:
#   $cardNumber (string) - The obscured credit card number (for example: ********* 2423)
#   $securityCode (string) - The name of the card's security code, which depends
#     on the card network (for example: CVV)
payment-moz-box-item-security-code-only-2 =
    .description = { $securityCode } •••
    .label = { $cardNumber }
addresses-group =
    .label = Adresy i nie tylko
payments-group =
    .label = Metody płatności

## Privacy Section - History

history-remember-option-never2 =
    .description = Każde okno zachowuje się, jakby było w trybie prywatnym. Po włączeniu każde rozszerzenie musi mieć pozwolenie na działanie.
    .label = Nie zachowuj historii
history-remember-option-custom2 =
    .label = Dostosuj ustawienia historii
history-remember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } zachowa historię przeglądania, wyszukiwania, pobieranych plików i danych formularzy.
history-dontremember-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } będzie używał tych samych ustawień co w trybie prywatnym i nie będzie zachowywał historii podczas przeglądania witryn WWW.
history-custom-description4 =
    .aria-label = { history-group.label }
    .description = { -brand-short-name } będzie używał ustawień historii przeglądania, wyszukiwania, pobieranych plików i danych formularzy określonych przez użytkownika.
history-private-browsing-permanent =
    .label = Zawsze aktywny tryb przeglądania prywatnego
    .accesskey = t
history-remember-browser-option =
    .label = Zachowuj historię przeglądania i pobierania plików
    .accesskey = h
history-remember-search-option =
    .label = Zachowuj historię pola wyszukiwania i formularzy
    .accesskey = o
history-clear-on-close-option =
    .label = Czyść historię po zamknięciu { -brand-short-name(case: "gen") }
    .accesskey = z
history-clear-on-close-settings =
    .label = Ustawienia…
    .accesskey = U
history-shutdown-exceptions =
    .label = Zarządzaj wyjątkami
    .accesskey = k
history-clear-button =
    .label = Wyczyść historię…
    .accesskey = W
history-header2 =
    .heading = Historia
history-section-header =
    .description = Wybierz, co { -brand-short-name } ma zachowywać po zamknięciu przeglądarki.
    .label = Historia
history-custom-section-header =
    .description = Dostosuj, co { -brand-short-name } ma zachowywać po zamknięciu przeglądarki.
    .label = Ustawienia zaawansowane
history-custom-button =
    .label = Wybierz, co { -brand-short-name } ma zachowywać
history-group =
    .label = Historia
history-mode-radio-group =
    .aria-label = Historia
history-remember-option-all2 =
    .label = Zachowuj historię

## Privacy Section - Site Data

sitedata-total-size-calculating = Obliczanie rozmiaru danych i pamięci podręcznej witryn…
# Variables:
#   $value (number) - Value of the unit (for example: 4.6, 500)
#   $unit (string) - Name of the unit (for example: "bytes", "KB")
sitedata-total-size3 = Witryny obecnie zajmują <strong>{ $value } { $unit }</strong> na dysku.
sitedata-learn-more = Więcej informacji
sitedata-delete-on-close2 =
    .label = Usuwaj ciasteczka i dane witryn po zamknięciu { -brand-short-name(case: "gen") }
    .accesskey = U
sitedata-delete-on-close-private-browsing3 =
    .message = Ustawienia historii powodują, że { -brand-short-name } usuwa ciasteczka i dane witryn z obecnej sesji po zamknięciu przeglądarki.
sitedata-delete-on-close-private-browsing4 =
    .heading = Historia nie będzie zachowywana.
    .message = { -brand-short-name } usuwa ciasteczka i dane witryn z obecnej sesji po zamknięciu przeglądarki.
sitedata-option-block-cross-site-trackers =
    .label = Śledzące między witrynami
sitedata-option-block-cross-site-tracking-cookies =
    .label = Ciasteczka śledzące między witrynami
sitedata-option-block-cross-site-cookies2 =
    .label = Izoluj ciasteczka między witrynami
sitedata-option-block-unvisited =
    .label = Ciasteczka nieodwiedzonych witryn
sitedata-option-block-all-cross-site-cookies =
    .label = Wszystkie ciasteczka między witrynami (może powodować niepoprawne działanie stron)
sitedata-option-block-all =
    .label = Wszystkie ciasteczka (spowoduje niepoprawne działanie stron)
sitedata-clear2 =
    .label = Wyczyść dane przeglądania
    .accesskey = a
sitedata-settings2 =
    .label = Zachowane dane przeglądania
    .accesskey = c
sitedata-cookies-exceptions =
    .label = Zarządzaj wyjątkami…
    .accesskey = k
sitedata-cookies-exceptions2 =
    .description = Określ zasady akceptacji ciasteczek i danych witryn.
    .label = Zarządzaj wyjątkami
    .accesskey = k
sitedata-heading =
    .description = Zarządzaj ciasteczkami, historią, pamięcią podręczną, danymi witryn i nie tylko.
    .label = Dane przeglądania
sitedata-settings3 =
    .label = Usuń dane konkretnych witryn
    .accesskey = k
sitedata-cookies-exceptions3 =
    .description = Wybierz, jak konkretne witryny obsługują ciasteczka i dane.
    .label = Zarządzaj wyjątkami
    .accesskey = k
cookies-site-data-group =
    .label = Ciasteczka i dane witryn

## Privacy Section - Cookie Banner Blocking

cookie-banner-blocker-header = Blokowanie informacji o ciasteczkach
cookie-banner-blocker-description = Kiedy witryna pyta, czy może używać ciasteczek w trybie prywatnym, { -brand-short-name } automatycznie odmawia za Ciebie. Działa tylko na obsługiwanych witrynach.
cookie-banner-learn-more = Więcej informacji
cookie-banner-blocker-checkbox-label =
    .label = Automatycznie odrzucaj prośby o akceptację ciasteczek

## Search Section

addressbar-locbar-history-option =
    .label = Historia przeglądania
    .accesskey = H
addressbar-locbar-bookmarks-option =
    .label = Zakładki
    .accesskey = Z
addressbar-locbar-clipboard-option =
    .label = Schowek
    .accesskey = c
addressbar-locbar-openpage-option =
    .label = Otwarte karty
    .accesskey = k
# Shortcuts refers to the shortcut tiles on the new tab page, previously known as top sites. Translation should be consistent.
addressbar-locbar-shortcuts-option =
    .label = Skróty
    .accesskey = S
addressbar-locbar-topsites-option =
    .label = Popularne witryny
    .accesskey = o
addressbar-locbar-engines-option-1 =
    .label = Wyszukiwarki
    .accesskey = W
addressbar-locbar-quickactions-option =
    .label = Szybkie działania.
    .accesskey = d
addressbar-locbar-showrecentsearches-option-2 =
    .label = Ostatnie wyszukiwania
    .accesskey = n
addressbar-locbar-showtrendingsuggestions-option-2 =
    .label = Popularne wyszukiwania.
    .accesskey = u
# Toggles whether suggestions are obtained from Firefox Suggest or not (local or online).
addressbar-locbar-suggest-all-option-2 =
    .description = Otrzymuj podpowiedzi z Internetu związane z wyszukiwanymi słowami.
    .label = Podpowiedzi { -brand-short-name(case: "gen") }
addressbar-locbar-suggest-sponsored-option-2 =
    .description = Wspieraj { -brand-short-name(case: "acc") }, od czasu do czasu wyświetlając sponsorowane podpowiedzi.
    .label = Podpowiedzi sponsorów
# This string is used for a checkbox in the settings UI that opts the
# user into "online" Firefox Suggest, allowing them to receive suggestions from
# Mozilla's Merino server.
# "Mozilla" is intentionally hardcoded to prevent forks from replacing it
# with their own vendor name, since the online suggest is created and maintained
# by Mozilla.
addressbar-firefox-suggest-online =
    .label = Pobieranie podpowiedzi od Mozilli podczas pisania
addressbar-dismissed-suggestions-label-2 =
    .description = Przywróć odrzucone podpowiedzi sponsorów i { -brand-short-name(case: "gen") }.
    .label = Odrzucone podpowiedzi
addressbar-restore-dismissed-suggestions-button-2 =
    .label = Przywróć podpowiedzi

## Privacy Section - Content Blocking

content-blocking-enhanced-tracking-protection = Wzmocniona ochrona przed śledzeniem
content-blocking-section-top-level-description = Elementy śledzące monitorują Cię w Internecie, zbierając informacje o Twoich działaniach i zainteresowaniach. { -brand-short-name } blokuje wiele tych elementów i inne złośliwe skrypty.
content-blocking-learn-more = Więcej informacji
content-blocking-fpi-incompatibility-warning = Używasz funkcji FPI („First Party Isolation”), która zastępuje część ustawień ciasteczek { -brand-short-name(case: "gen") }.
# There is no need to translate "Resist Fingerprinting (RFP)". This is a
# feature that can only be enabled via about:config, and it's not exposed to
# standard users (e.g. via Settings).
content-blocking-rfp-incompatibility-warning = Używasz funkcji RFP („Resist Fingerprinting”), która zastępuje część ustawień ochrony przed zbieraniem informacji o konfiguracji { -brand-short-name(case: "gen") }. Może to powodować problemy z działaniem niektórych stron.

## These strings are used to define the different levels of
## Enhanced Tracking Protection.

# "Standard" in this case is an adjective, meaning "default" or "normal".
enhanced-tracking-protection-setting-standard =
    .label = Standardowa
    .accesskey = S
enhanced-tracking-protection-setting-strict =
    .label = Ścisła
    .accesskey = c
enhanced-tracking-protection-setting-custom =
    .label = Własna
    .accesskey = W

## Privacy Section - Content Blocking

content-blocking-etp-standard-desc = Równowaga między bezpieczeństwem a szybkością wczytywania stron. Strony będą działać bez problemów.
content-blocking-etp-strict-desc = Silniejsza ochrona, ale może powodować niepoprawne działanie niektórych stron.
content-blocking-etp-custom-desc = Wybierz, które elementy śledzące i skrypty blokować:
content-blocking-etp-blocking-desc = { -brand-short-name } blokuje:
content-blocking-private-windows = treści z elementami śledzącymi w oknach prywatnych
content-blocking-cross-site-cookies-in-all-windows2 = ciasteczka między witrynami we wszystkich oknach
content-blocking-cross-site-tracking-cookies = ciasteczka śledzące między witrynami
content-blocking-all-cross-site-cookies-private-windows = ciasteczka między witrynami w prywatnych oknach
content-blocking-isolate-cross-site-cookies = izolowanie ciasteczek między witrynami
content-blocking-social-media-trackers = elementy śledzące serwisów społecznościowych
content-blocking-all-cookies = wszystkie ciasteczka
content-blocking-unvisited-cookies = ciasteczka z nieodwiedzonych witryn
content-blocking-all-windows-tracking-content = treści z elementami śledzącymi we wszystkich oknach
content-blocking-all-cross-site-cookies = wszystkie ciasteczka między witrynami
content-blocking-cryptominers = elementy używające komputera użytkownika do generowania kryptowalut
content-blocking-fingerprinters = elementy śledzące przez zbieranie informacji o konfiguracji
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices. And
# the suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-known-and-suspected-fingerprinters = znane i podejrzewane elementy śledzące przez zbieranie informacji o konfiguracji
# "Contains" here means "isolates", "limits".
content-blocking-etp-standard-tcp-rollout-description = Całkowita ochrona ciasteczek ogranicza ciasteczka do odwiedzanej witryny, więc elementy śledzące nie mogą ich używać do śledzenia Cię między witrynami.
content-blocking-etp-standard-tcp-rollout-learn-more = Więcej informacji
content-blocking-etp-standard-tcp-title = Zawiera całkowitą ochronę ciasteczek, naszą najpotężniejszą funkcję ochrony prywatności w historii
content-blocking-warning-title-2 = Ścisła ochrona przed śledzeniem może powodować niepoprawne działanie niektórych stron
content-blocking-warning-title-custom = Własna ochrona przed śledzeniem może powodować niepoprawne działanie niektórych stron
# “Fix site issues” references the string content-blocking-exceptions-subheader
content-blocking-and-isolating-etp-warning-description-4 = { -brand-short-name } zaleca korzystanie z ustawień „Naprawianie problemów ze stronami”, aby ograniczyć liczbę niedziałających funkcji i treści stron. Jeśli strona wydaje się niepoprawnie działać, spróbuj wyłączyć na niej ochronę przed śledzeniem, aby wczytać całą treść.
content-blocking-warning-learn-how = Więcej informacji
content-blocking-baseline-exceptions-3 =
    .description = Pomaga wczytywać strony i funkcje przez odblokowanie tylko niezbędnych rzeczy, które mogą zawierać elementy śledzące. Rozwiązuje najczęstsze problemy.
    .label = Naprawiaj poważne problemy ze stronami (zalecane)
# This option to fix minor site issues must be used with the option to fix major site issues (string content-blocking-baseline-exceptions-3)
content-blocking-convenience-exceptions-3 =
    .description = Przywraca między innymi filmy w artykułach czy sekcje komentarzy przez odblokowanie rzeczy, które mogą zawierać elementy śledzące. Może to ograniczyć problemy ze stronami, ale zmniejsza poziom ochrony. Wymaga włączenia opcji naprawiania poważnych problemów.
    .label = Naprawiaj drobne problemy ze stronami
content-blocking-baseline-uncheck-warning-dialog-title = Czy na pewno wyłączyć naprawianie?
content-blocking-baseline-uncheck-warning-dialog-body = To ustawienie pomaga naprawiać najczęstsze problemy ze stronami. Wyłączenie może spowodować niepoprawne działanie niektórych stron, a { -brand-short-name } nie będzie mógł pomagać w rozwiązywaniu tych problemów.
content-blocking-baseline-uncheck-warning-dialog-ok-button = Wyłącz naprawianie
content-blocking-baseline-uncheck-warning-dialog-cancel-button = Nie wyłączaj naprawiania
content-blocking-reload-description = Zastosowanie tych zmian wymaga odświeżenia kart.
content-blocking-reload-tabs-button =
    .label = Odśwież wszystkie karty
    .accesskey = O
content-blocking-tracking-content-label =
    .label = treści z elementami śledzącymi:
    .accesskey = e
content-blocking-tracking-protection-option-all-windows =
    .label = zawsze
    .accesskey = z
content-blocking-option-private =
    .label = w oknach prywatnych
    .accesskey = w
content-blocking-cookies-label =
    .label = ciasteczka:
    .accesskey = c
content-blocking-expand-section =
    .tooltiptext = Więcej informacji
# Cryptomining refers to using scripts on websites that can use a computer’s resources to mine cryptocurrency without a user’s knowledge.
content-blocking-cryptominers-label =
    .label = elementy używające komputera użytkownika do generowania kryptowalut
    .accesskey = e
# Browser fingerprinting is a method of tracking users by the configuration and settings information (their "digital fingerprint")
# that is visible to websites they browse, rather than traditional tracking methods such as IP addresses and unique cookies.
#
# The known fingerprinters are those that are known for collecting browser fingerprints from user devices.
content-blocking-known-fingerprinters-label =
    .label = znane elementy śledzące przez zbieranie informacji o konfiguracji
    .accesskey = z
# The suspected fingerprinters are those that we are uncertain about browser fingerprinting activities. But they could
# possibly acquire browser fingerprints because of the behavior on accessing APIs that expose browser fingerprints.
content-blocking-suspected-fingerprinters-label =
    .label = podejrzewane elementy śledzące przez zbieranie informacji o konfiguracji
    .accesskey = d

## Privacy Section - Tracking

tracking-manage-exceptions =
    .label = Zarządzaj wyjątkami…
    .accesskey = k

## Privacy Section - Permissions

permissions-notification-pause =
    .label = Wstrzymaj powiadomienia do czasu ponownego uruchomienia { -brand-short-name(case: "gen") }
    .accesskey = W
permissions-autoplay2 =
    .label = Automatyczne odtwarzanie
permissions-block-popups2 =
    .label = Blokuj wyskakujące okna i zewnętrzne przekierowania
    .accesskey = B
# "popup" is a misspelling that is more popular than the correct spelling of
# "pop-up" so it's included as a search keyword, not displayed in the UI.
permissions-block-popups-exceptions-button4 =
    .description = Dodaj witryny, które mogą otwierać wyskakujące okna i korzystać z zewnętrznych przekierowań.
    .label = Zarządzaj wyjątkami
    .searchkeywords = popups pop-ups wyskakujące okienka przekierowania
    .accesskey = t
permissions-addon-install-warning3 =
    .label = Ostrzegaj, gdy witryny próbują instalować rozszerzenia
    .accesskey = O
permissions-addon-exceptions2 =
    .label = Wybierz, które witryny mogą instalować rozszerzenia
    .accesskey = W
# App links are links that a website can ask to open for you, like email
# (mailto:) links.
permissions-allow-app-links =
    .label = Zezwalaj witrynom na proszenie o otwieranie odnośników w aplikacjach.
    .accesskey = d
# Opens the list of sites that are blocked from asking to open app links.
permissions-app-links-manage-button =
    .label = Zarządzaj witrynami bez zezwolenia
    .accesskey = b
permissions-location2 =
    .label = Położenie
permissions-localhost2 =
    .label = Aplikacje i usługi na urządzeniu
permissions-local-network2 =
    .label = Urządzenia w sieci lokalnej
permissions-xr2 =
    .label = Rzeczywistość wirtualna
permissions-camera2 =
    .label = Kamera
permissions-microphone2 =
    .label = Mikrofon
# Privacy permission for sound output devices.
permissions-speaker2 =
    .label = Głośniki
permissions-notification2 =
    .label = Powiadomienia
permissions-header3 =
    .description = Zarządzaj, do czego witryny mają dostęp, czym mogą sterować i co mogą wywoływać.
    .label = Uprawnienia
permissions-data-section =
    .heading = Uprawnienia i dane
pane-permissions-data-title2 = Uprawnienia i dane
    .title = Uprawnienia i dane
notifications-section-header =
    .heading = Powiadomienia
notifications-entry-card-header =
    .description = Wybierz, które witryny mogą wysyłać powiadomienia i w jaki sposób są one wyświetlane.
    .label = Powiadomienia
# Variables:
#   $count (number) - Number of websites with a stored notification decision,
#                     always one or more. The zero case is a separate message,
#                     notifications-entry-manage-button-empty.
notifications-entry-manage-button =
    .description =
        { $count ->
            [one] { $count } witryna
            [few] { $count } witryny
           *[many] { $count } witryn
        }
    .label = Ustawienia powiadomień
# Replaces notifications-entry-manage-button when no website has a stored
# notification decision. It deliberately carries no description: the empty
# state is stated on the Notifications page rather than on this row.
notifications-entry-manage-button-empty =
    .label = Ustawienia powiadomień witryn
notifications-website-card-header =
    .description = Wybierz, w jaki sposób witryny mogą wysyłać powiadomienia.
    .label = Powiadomienia witryn
notifications-filter =
    .placeholder = Szukaj witryn
# Heading of the website column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header =
    .label = Witryna
# Heading of the state column in the list of websites and their notification
# state, shown when the list has rows.
notifications-list-header-state = Zezwolenie na powiadomienia
# Heading of the list of websites when it has no rows, because no website has a
# stored notification decision or a search matches no website.
notifications-list-header-empty =
    .label = Witryny
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Always" is used where notifications can
# also be delivered while Firefox is closed.
notifications-state-always = Zezwalaj także po zamknięciu przeglądarki
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications". "Allow" is used where notifications
# cannot be delivered while Firefox is closed.
notifications-state-allow = Zezwalaj
# Read-only state shown on each row of the website notifications list, in the
# column headed "Allow notifications", for websites blocked from sending
# notifications.
notifications-state-never = Nigdy nie zezwalaj
# Shown as a row under the list header when no website has a stored
# notification decision.
notifications-empty-message =
    .label = Nie dodano powiadomień z żadnych witryn.
# Shown as a row under the list header when a search matches no website.
notifications-no-results-message =
    .label = Żadne powiadomienia z witryn nie pasują do wyszukiwania.

## Privacy Section - Data Collection

backup-multi-profile-warning-message =
    .message = Aby upewnić się, że ta zmiana zostanie uwzględniona w kopiach zapasowych, otwórz każdy profil i kliknij „Utwórz kopię zapasową” w Ustawieniach.
nimbus-rollouts =
    .description = Zmiany będą wprowadzane zdalnie.
    .label = { -brand-short-name } może ulepszać funkcje oraz zwiększać wydajność i stabilność pomiędzy aktualizacjami
addon-recommendations3 =
    .description = Polecenia rozszerzeń, które usprawnią przeglądanie Internetu.
    .label = Personalizowane polecenia rozszerzeń
# This message is displayed above disabled data sharing options in developer builds
# or builds with no Telemetry support available.
collection-health-report-disabled2 = Przesyłanie danych jest wyłączone przy tej konfiguracji programu.
collection-backlogged-crash-reports2 =
    .label = Automatycznie wysyłaj zgłoszenia awarii
    .accesskey = o
collection-backlogged-crash-reports-description = Umożliwia to { -vendor-short-name(case: "dat") } diagnozowanie i naprawianie problemów z przeglądarką. Zgłoszenia mogą zawierać dane osobowe lub prywatne informacje.
# Promotional message displayed in the Settings panes to inform users of the new redesign
settings-redesign-promo =
    .heading = Te same ustawienia, nowy wygląd!
    .message = Przeprojektowaliśmy tę stronę, aby ułatwić przeglądanie i poruszanie się po niej. Twoje ustawienia pozostały bez zmian, a wszystko jest nadal dostępne. Wskazówka: skorzystaj z wyszukiwarki, aby od razu przejść do tego, czego potrzebujesz.
settings-redesign-promo-dismiss-button =
    .label = OK
privacy-segmentation-section-header = Nowe funkcje usprawniające przeglądanie
privacy-segmentation-section-description = Kiedy oferujemy funkcje wykorzystujące Twoje dane do zapewniania bardziej spersonalizowanej przeglądarki:
privacy-segmentation-radio-off =
    .label = Używaj zaleceń { -brand-product-name(case: "gen") }
privacy-segmentation-radio-on =
    .label = Wyświetlaj szczegółowe informacje
# The search keyword isn't shown to users but is used to find relevant settings in about:preferences.
data-collection =
    .description = Dokładamy wszelkich starań, aby zapewnić Ci wybór i zbierać tylko minimalną ilość danych niezbędnych do ulepszania { -brand-product-name(case: "gen") } dla wszystkich.
    .label = Dane zbierane przez { -brand-short-name(case: "acc") }
    .searchkeywords = telemetria
data-collection-link = Zasady ochrony prywatności
data-collection-preferences-across-profiles =
    .message = Te ustawienia dotyczą każdego profilu { -brand-product-name(case: "gen") } na tym urządzeniu.
data-collection-profiles-link = Wyświetl wszystkie profile
data-collection-health-report-telemetry-disabled =
    .message = { -vendor-short-name } nie ma już zezwolenia na zbieranie danych technicznych i o interakcjach z przeglądarką. Wszystkie wcześniej zebrane dane zostaną usunięte w ciągu 30 dni.
data-collection-health-report =
    .description = To pomaga nam ulepszać funkcje, wydajność i stabilność { -brand-product-name(case: "gen") }.
    .label = Wysyłaj dane techniczne i o interakcjach do { -vendor-short-name(case: "gen") }
    .accesskey = z
data-collection-health-report-disabled =
    .description = Przesyłanie danych jest wyłączone przy tej konfiguracji programu.
    .label = Wysyłaj dane techniczne i o interakcjach do { -vendor-short-name(case: "gen") }
    .accesskey = z
data-collection-run-studies =
    .description = { -brand-short-name } losowo wybiera użytkowników do testowania funkcji, co pomaga poprawić jakość dla wszystkich.
    .label = { -brand-short-name } może przeprowadzać badania funkcji
data-collection-studies-link =
    .label = Wyświetl badania { -brand-short-name(case: "gen") }
data-collection-backlogged-crash-reports =
    .description = Umożliwia to { -vendor-short-name(case: "dat") } diagnozowanie i naprawianie problemów z przeglądarką. Zgłoszenia mogą zawierać dane osobowe lub prywatne informacje.
    .label = Automatycznie wysyłaj zgłoszenia awarii
    .accesskey = o
data-collection-usage-ping =
    .description = To pomaga { -vendor-short-name(case: "dat") } oszacować liczbę aktywnych użytkowników.
    .label = Wysyłaj dzienny sygnał o użyciu do { -vendor-short-name(case: "gen") }
    .accesskey = d

## Privacy Section - Security
##
## It is important that wording follows the guidelines outlined on this page:
## https://developers.google.com/safe-browsing/developers_guide_v2#AcceptableUsage

security-header = Bezpieczeństwo
browsing-protection-group2 =
    .description = Niebezpieczne witryny i pliki mogą zagrozić Twoim danym i urządzeniu. { -brand-short-name } automatycznie je blokuje i ostrzega przed ryzykownym i niechcianym oprogramowaniem.
    .label = Ochrona przed oszustwami i niebezpiecznym oprogramowaniem
security-enable-safe-browsing =
    .label = Blokuj niebezpieczne i podejrzane treści.
    .accesskey = B
security-enable-safe-browsing-link = Więcej informacji
security-safe-browsing-warning =
    .message = Wyłączenie zmniejsza ochronę przed oszustwami, złośliwymi witrynami i niebezpiecznymi plikami.
security-block-downloads =
    .label = Blokuj możliwość pobierania niebezpiecznych plików
    .accesskey = e
security-block-uncommon-software =
    .label = Ostrzegaj przed niepożądanym i nietypowym oprogramowaniem
    .accesskey = n

## Privacy Section - Certificates

certs-thirdparty-toggle =
    .label = { -brand-short-name } może automatycznie ufać zewnętrznym certyfikatom głównym zainstalowanym przez użytkownika.
    .accesskey = m
certs-devices-enable-fips = Włącz FIPS
space-alert-over-5gb-settings-button =
    .label = Otwórz ustawienia
    .accesskey = O
space-alert-over-5gb-message2 = <strong>{ -brand-short-name(case: "dat") } zaczyna brakować miejsca na dysku.</strong> Zawartość stron może być wyświetlana niepoprawnie. Przechowywane dane można wyczyścić w Ustawienia → Prywatność i bezpieczeństwo → Ciasteczka i dane witryn.
space-alert-under-5gb-message2 = <strong>{ -brand-short-name(case: "dat") } zaczyna brakować miejsca na dysku.</strong> Zawartość stron może być wyświetlana niepoprawnie. Skorzystaj z odnośnika „Więcej informacji”, aby zoptymalizować użycie dysku dla lepszego przeglądania.
certs-description3 =
    .description = Skonfiguruj certyfikaty, których { -brand-short-name } używa do weryfikacji zabezpieczonych połączeń.
    .label = Certyfikaty
certs-view2 =
    .label = Zarządzaj certyfikatami
    .accesskey = c
certs-devices2 =
    .label = Zarządzaj urządzeniami zabezpieczającymi
    .accesskey = u

## Privacy Section - HTTPS-Only

httpsonly-learn-more2 = Jak działa tryb używania wyłącznie protokołu HTTPS
httpsonly-radio-enabled =
    .label = Włącz we wszystkich oknach
httpsonly-radio-enabled-pbm =
    .label = Włącz tylko w oknach prywatnych
httpsonly-radio-disabled3 =
    .description = { -brand-short-name } nadal może przełączać część połączeń.
    .label = Nie włączaj
httpsonly-group =
    .description = Zezwala wyłącznie na zabezpieczone połączenia z witrynami. { -brand-short-name } będzie pytał przed niezabezpieczonym połączeniem.
    .label = Tryb używania wyłącznie protokołu HTTPS
httpsonly-label2 =
    .aria-label = { httpsonly-group.label }

## DoH Section

preferences-doh-header = DNS poprzez HTTPS
dns-over-https-group2 =
    .description = System nazw domen poprzez HTTPS (DoH) szyfruje zapytania o nazwy domen, utrudniając dostawcy Internetu i innym podejrzenie, jakie witryny zaraz otworzysz.
    .label = DNS poprzez HTTPS
preferences-doh-description2 = System nazw domen (DNS) poprzez HTTPS wysyła zapytanie o nazwę domeny przez zaszyfrowane połączenie, zapewniając zabezpieczony serwer DNS i utrudniając innym podejrzenie, jaką witrynę zaraz otworzysz.
# Variables:
#   $status (string) - The status of the DoH connection
preferences-doh-status = Stan: { $status }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-resolver = Dostawca: { $name }
# This is displayed instead of $name in preferences-doh-resolver
# when the DoH URL is not a valid URL
preferences-doh-bad-url = Nieprawidłowy adres URL
preferences-doh-steering-status = Używanie lokalnego dostawcy
preferences-doh-status-active = Aktywne
preferences-doh-status-disabled = Wyłączone
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-not-active = Nieaktywne ({ $reason })
preferences-doh-group-message2 = Włącz serwer DNS poprzez HTTPS:
preferences-doh-radio-group =
    .aria-label = Włącz serwer DNS poprzez HTTPS:
preferences-doh-expand-section =
    .tooltiptext = Więcej informacji
preferences-doh-setting-default =
    .label = Domyślna ochrona
    .accesskey = D
preferences-doh-default-desc = { -brand-short-name } decyduje, kiedy używać zabezpieczonego serwera DNS do ochrony prywatności użytkownika.
preferences-doh-default-detailed-desc-1 = Używa zabezpieczonego serwera DNS w regionach, gdzie jest dostępny
preferences-doh-default-detailed-desc-2 = Używa domyślnego serwera DNS, jeśli występuje problem z dostawcą zabezpieczonego serwera DNS
preferences-doh-default-detailed-desc-3 = Używa lokalnego dostawcy, jeśli to możliwe.
preferences-doh-default-detailed-desc-4 = Wyłącza, kiedy aktywna jest sieć VPN, kontrola rodzicielska lub zasady organizacji
preferences-doh-default-detailed-desc-5 = Wyłącza, kiedy sieć mówi { -brand-short-name(case: "dat") }, że nie powinien używać zabezpieczonego serwera DNS.
preferences-doh-setting-enabled =
    .label = Zwiększona ochrona
    .accesskey = Z
preferences-doh-enabled-desc = Użytkownik decyduje, kiedy używać zabezpieczonego serwera DNS i wybiera dostawcę.
preferences-doh-enabled-detailed-desc-1 = Używa dostawcy wybranego przez użytkownika
preferences-doh-enabled-detailed-desc-2 = Używa domyślnego serwera DNS tylko, jeśli występuje problem z zabezpieczonym serwerem DNS
preferences-doh-setting-strict =
    .label = Maksymalna ochrona
    .accesskey = M
preferences-doh-strict-desc = { -brand-short-name } będzie zawsze używał zabezpieczonego serwera DNS. Przed użyciem systemowego serwera DNS zostanie wyświetlone ostrzeżenie o zagrożeniu bezpieczeństwa.
preferences-doh-strict-detailed-desc-1 = Używa wyłącznie dostawcy wybranego przez użytkownika
preferences-doh-strict-detailed-desc-2 = Zawsze ostrzega, jeśli zabezpieczony serwer DNS jest niedostępny
preferences-doh-strict-detailed-desc-3 = Jeśli zabezpieczony serwer DNS jest niedostępny, witryny nie będą się wczytywać ani poprawnie działać
preferences-doh-setting-off =
    .label = Wyłączone
    .accesskey = W
preferences-doh-off-desc = Używa domyślnego serwera DNS
preferences-doh-select-resolver = Wybierz dostawcę:
preferences-doh-manage-exceptions =
    .label = Zarządzaj wyjątkami…
    .accesskey = k
preferences-doh-overview-default =
    .description = Używa zabezpieczonego serwera DNS w regionach, gdzie jest dostępny.
    .label = Domyślna ochrona
preferences-doh-overview-custom =
    .description = Zawsze używa zabezpieczonego serwera DNS, umożliwiając wybranie dostawcy i sterowanie zachowaniem w razie problemów.
    .label = Własne ustawienia
preferences-doh-overview-off =
    .description = Używa domyślnego serwera DNS.
    .label = Wyłączone
preferences-doh-advanced-button =
    .label = Ustawienia zaawansowane
preferences-doh-advanced-section =
    .description = System nazw domen poprzez HTTPS (DoH) szyfruje zapytania o nazwy domen, utrudniając dostawcy Internetu i innym podejrzenie, jakie witryny zaraz otworzysz.
    .label = Ustawienia zaawansowane
preferences-doh-manage-exceptions2 =
    .label = Zarządzaj wyjątkami
    .accesskey = k
preferences-doh-radio-default =
    .description = Używa zabezpieczonego serwera DNS w regionach, gdzie jest dostępny.
    .label = Domyślne ustawienia
preferences-doh-radio-custom =
    .description = Zawsze używa zabezpieczonego serwera DNS, umożliwiając wybranie dostawcy i sterowanie zachowaniem w razie problemów
    .label = Własne ustawienia
preferences-doh-radio-off =
    .description = Używa domyślnego serwera DNS
    .label = Wyłączone
preferences-doh-fallback-label =
    .label = Zawsze ostrzega, jeśli zabezpieczony serwer DNS jest niedostępny
preferences-doh-status-item-off =
    .message = DNS poprzez HTTPS jest wyłączony
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active =
    .message = DNS poprzez HTTPS nie działa, ponieważ wystąpił błąd ({ $reason }) podczas próby użycia dostawcy { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
preferences-doh-status-item-not-active-bad-url =
    .message = DNS poprzez HTTPS nie działa, ponieważ otrzymano nieprawidłowy adres URL ({ $reason })
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active =
    .message = DNS poprzez HTTPS używa dostawcy { $name }
# Variables:
#   $reason (string) - A string representation of the reason DoH is not active. For example NS_ERROR_UNKNOWN_HOST or TRR_RCODE_FAIL.
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-not-active-local =
    .message = DNS poprzez HTTPS nie działa, ponieważ wystąpił błąd ({ $reason }) podczas próby użycia lokalnego dostawcy { $name }
# Variables:
#   $name (string) - The name of the DNS over HTTPS resolver. If a custom resolver is used, the name will be the domain of the URL.
preferences-doh-status-item-active-local =
    .message = DNS poprzez HTTPS używa lokalnego dostawcy { $name }
preferences-doh-select-resolver-label =
    .label = Wybierz dostawcę:
# Variables:
#   $name (String) - Display name or URL for the DNS over HTTPS provider
connection-dns-over-https-url-item =
    .label = { $name }
    .tooltiptext = Używa tego dostawcy DNS poprzez HTTPS
preferences-doh-custom-provider-label =
    .aria-label = Wpisz adres URL własnego dostawcy
preferences-doh-header2 =
    .heading = DNS poprzez HTTPS

## Connection and software security section

preferences-connection-header =
    .heading = Bezpieczeństwo połączeń i oprogramowania
preferences-connection-link-section =
    .description = Zobacz, w jaki sposób zapewniane jest bezpieczeństwo połączeń, blokowane jest szkodliwe oprogramowanie oraz weryfikowane są witryny.
    .label = Bezpieczeństwo połączeń i oprogramowania
preferences-connection-link-button =
    .label = Ustawienia zaawansowane

## The following strings are used in the Download section of settings

desktop-folder-name = Pulpit
downloads-folder-name = Pobrane

## Appearance page

preferences-appearance-header =
    .heading = Wygląd
browser-theme-group =
    .description = Dostosuj wygląd { -brand-short-name(case: "gen") } do swoich upodobań. Kolory motywu są używane na paskach narzędzi, menu i komunikatach.
    .label = Motyw przeglądarki
browser-theme-manage-link =
    .label = Zarządzaj motywami { -brand-short-name(case: "gen") }
appearance-window-density-group =
    .description = Dostosuj odstępy między elementami okna, takimi jak pasek narzędzi, karty i panel boczny.
    .label = Gęstość i upakowanie okna
appearance-window-density-radio-group =
    .aria-label = Gęstość i upakowanie okna
appearance-window-density-automatic =
    .description = Odstępy standardowe, zwarte i dotykowe są stosowane automatycznie
    .label = Automatyczne (domyślnie)
appearance-window-density-automatic-no-touch =
    .description = Odstępy standardowe lub zwarte są stosowane automatycznie
    .label = Automatyczne (domyślnie)
appearance-window-density-standard =
    .description = Zrównoważone odstępy pasujące do większości ekranów
    .label = Standardowe
appearance-window-density-auto-touch-mode =
    .label = Odstępy dotykowe w trybie tabletowym
appearance-window-density-compact =
    .description = Zmniejszone odstępy pasujące do mniejszych ekranów
    .label = Zwarte
appearance-window-density-touch =
    .description = Większe elementy okna, dostosowane do ekranów dotykowych
    .label = Dotykowe
related-settings-group =
    .label = Powiązane ustawienia
related-settings-accessibility-link =
    .label = Dostosuj powiększenie i czcionki w ustawieniach ułatwień dostępu
related-settings-home-link =
    .label = Dostosuj { -firefox-home-brand-name(capitalization: "lower", case: "acc") }
related-settings-tabs-browsing-link =
    .label = Dostosuj układ przeglądarki

## AI controls page

preferences-ai-controls-description = W { -brand-short-name(case: "loc") } zawsze masz wybór, także w korzystaniu z funkcji ulepszonych za pomocą sztucznej inteligencji. Więcej opcji sterowania wkrótce.
preferences-ai-controls-block-ai-label = Blokuj ulepszenia SI
preferences-ai-controls-block-ai =
    .label = { preferences-ai-controls-block-ai-label }
preferences-ai-controls-block-ai-description = Blokowanie oznacza, że nie zobaczysz nowych ani obecnych ulepszeń SI w { -brand-short-name(case: "loc") } czy nawet informacji o nich. <a data-l10n-name="link">Więcej informacji</a> o tym, co to obejmuje i jak sterować tradycyjnymi funkcjami uczenia maszynowego, takimi jak podpowiedzi wyszukiwania i polecenia.
preferences-ai-controls-blocked-message =
    .message = Nowe i obecne ulepszenia SI są domyślnie blokowane. Aby odblokować konkretną funkcję, skorzystaj z poniższych opcji sterowania.
preferences-ai-controls-on-device-group =
    .description = Te funkcje korzystają z małych modeli sztucznej inteligencji pobieranych na urządzenie, jeśli są włączone. Takie podejście chroni Twoją prywatność.
    .label = Sztuczna inteligencja na urządzeniu
preferences-ai-controls-translations-control =
    .description = Płynne przeglądanie Internetu w preferowanym języku.
    .label = Tłumaczenia
preferences-ai-controls-translations-more-link = Więcej ustawień tłumaczeń
preferences-ai-controls-pdfjs-control =
    .description = Ta funkcja dodaje opisy podczas dodawania obrazów do plików PDF, aby zwiększyć ich dostępność.
    .label = Alternatywny tekst obrazów w przeglądarce plików PDF { -brand-short-name(case: "gen") }
preferences-ai-controls-tab-group-suggestions-control =
    .description = Podpowiada, jak nazywać i organizować karty.
    .label = Podpowiedzi grup kart
preferences-ai-controls-key-points-control =
    .description = Wyświetla krótkie streszczenie przed otwarciem odnośnika.
    .label = Podsumowanie w podglądach odnośników
preferences-ai-controls-speech-recognition-control =
    .description = Zamienia głos na tekst na urządzeniu.
    .label = Rozpoznawanie mowy
preferences-ai-controls-sidebar-chatbot-group-3 =
    .description = Wyświetla czatbota na wierzchu podczas przeglądania. Wybierz spośród wielu dostawców i zmień go, kiedy chcesz.
    .label = Czatboty SI w panelu bocznym
preferences-ai-controls-sidebar-chatbot-group =
    .description = Wyświetla czatbota na wierzchu podczas przeglądania. Wybierz spośród Anthropic Claude, ChatGPT, Copilot, Google Gemini i Le Chat Mistral.
    .label = Dostawcy czatbotów SI w panelu bocznym
preferences-ai-controls-sidebar-chatbot-control =
    .label = Czatbot w panelu bocznym
# This option means that a user will see the feature and can use it.
preferences-ai-controls-state-available =
    .label = Dostępne
# This option means a user has opted in to use the feature.
preferences-ai-controls-state-enabled =
    .label = Włączone
# This option means the user won't see and can't use the feature. For on-device AI, any models already downloaded are removed.
preferences-ai-controls-state-blocked =
    .label = Zablokowane
preferences-ai-controls-state-description-before = Co oznaczają te opcje:
preferences-ai-controls-state-description-available = <strong>Dostępne:</strong> funkcja będzie widoczna i można z niej korzystać.
preferences-ai-controls-state-description-enabled = <strong>Włączone:</strong> wybrano korzystanie z tej funkcji.
preferences-ai-controls-state-description-blocked = <strong>Zablokowane:</strong> funkcja nie będzie widoczna i nie można z niej korzystać. W przypadku sztucznej inteligencji na urządzeniu wszystkie pobrane wcześniej modele zostaną usunięte.
preferences-ai-controls-block-confirmation-heading = Czy zablokować ulepszenia SI?
preferences-ai-controls-block-confirmation-description = Nie zobaczysz nowych ani obecnych ulepszeń SI w { -brand-short-name(case: "loc") } czy nawet informacji o nich. Następnie można odblokować poszczególne funkcje, aby z nich korzystać.
preferences-ai-controls-block-confirmation-features-start = Co zostanie zablokowane:
preferences-ai-controls-block-confirmation-translations = Tłumaczenia
preferences-ai-controls-block-confirmation-pdfjs = Alternatywny tekst obrazów w przeglądarce plików PDF { -brand-short-name(case: "gen") }
preferences-ai-controls-block-confirmation-tab-group-suggestions = Podpowiedzi grup kart
preferences-ai-controls-block-confirmation-key-points = Podsumowanie w podglądach odnośników
preferences-ai-controls-block-confirmation-sidebar-chatbot = Czatboty w panelu bocznym
preferences-ai-controls-block-confirmation-speech-recognition = Rozpoznawanie mowy
preferences-ai-controls-block-confirmation-features-after = Zablokowanie wpływa także na rozszerzenia wykorzystujące sztuczną inteligencję dostarczaną przez { -brand-short-name(case: "acc") }.
preferences-ai-controls-block-confirmation-cancel =
    .label = Anuluj
preferences-ai-controls-block-confirmation-confirm =
    .label = Zablokuj
preferences-ai-controls-header3 =
    .heading = Sterowanie SI

## Privacy and security status card

security-privacy-status-ok-header = { -brand-short-name } jest na straży
# This is the header above a section telling the user about problems in their settings
security-privacy-status-problem-header = { -brand-short-name } poleca kilka usprawnień bezpieczeństwa
security-privacy-status-ok-label = Wzmocniona ochrona przed śledzeniem jest włączona
security-privacy-status-problem-label = Znaleźliśmy ustawienia wpływające na Twoją ochronę
security-privacy-status-problem-helper-label = Wyświetl problemy
security-privacy-status-pending-trackers-label = Sprawdzanie, ile elementów śledzących { -brand-short-name } zablokował w ciągu ostatniego miesiąca
# This label tells the user how many trackers we have blocked for them.
# Variables:
#   $trackerCount (Number) - Number of trackers we have blocked in the last month
security-privacy-status-trackers-label =
    { $trackerCount ->
        [one] W ciągu ostatniego miesiąca zablokowano { $trackerCount } element śledzący
        [few] W ciągu ostatniego miesiąca zablokowano { $trackerCount } elementy śledzące
       *[many] W ciągu ostatniego miesiąca zablokowano { $trackerCount } elementów śledzących
    }
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Strict" in Enhanced Tracking Protection advanced settings
security-privacy-status-strict-enabled-label = Wybrano <a data-l10n-name="strict-tracking-protection">ścisłą ochronę</a>
# This string appears under "Enhanced Tracking Protection is on" when a user has enabled "Custom" in Enhanced Tracking Protection advanced settings
security-privacy-status-custom-enabled-label = Wybrano <a data-l10n-name="custom-tracking-protection">własne ustawienia ochrony</a>
security-privacy-status-up-to-date-label = Masz najnowszą, najbezpieczniejszą wersję { -brand-short-name(case: "gen") }
security-privacy-status-update-needed-label = Dostępna jest nowa wersja { -brand-short-name(case: "gen") }.
security-privacy-status-update-error-label = { -brand-short-name } ma problem z aktualizacją
security-privacy-status-update-checking-label = { -brand-short-name } wyszukuje aktualizacje
security-privacy-status-update-needed-description = Zaktualizuj, aby korzystać z najszybszej, najstabilniejszej i najbezpieczniejszej przeglądarki.
security-privacy-status-update-button-label =
    .label = Zaktualizuj { -brand-short-name(case: "acc") }
security-privacy-image-warning =
    .alt = Tarcza z wykrzyknikiem, wyrażająca obawy związane z ostrzeżeniami bezpieczeństwa
security-privacy-image-ok =
    .alt = Tarcza ze znakiem pokazującym, że nie ma żadnych nierozwiązanych problemów z bezpieczeństwem
security-privacy-issue-card =
    .heading = Ostrzeżenia bezpieczeństwa
issue-card-reset-button =
    .label = Przywróć
issue-card-dismiss-button =
    .aria-label = Zamknij
    .tooltiptext = Zamknij

## Enhanced Tracking Protection (ETP) status section

preferences-etp-status-header =
    .description = Witryny używają elementów śledzących, aby śledzić Cię w Internecie i wyświetlać podejrzane reklamy. { -brand-short-name } chroni Cię podczas przeglądania Internetu, automatycznie blokując elementy śledzące, dzięki czemu masz kontrolę nad swoim cyfrowym śladem.
    .label = Wzmocniona ochrona przed śledzeniem
preferences-etp-level-radio-group =
    .aria-label = Wzmocniona ochrona przed śledzeniem
preferences-etp-level-standard =
    .description = Silna, niezawodna ochrona, która bezproblemowo działa na większości witryn.
    .label = Standardowa (domyślna)
preferences-etp-level-strict =
    .description = Silniejsza ochrona, która blokuje więcej elementów śledzących, ale może powodować niepoprawne działanie niektórych stron.
    .label = Ścisła
preferences-etp-level-custom =
    .description = Wybierz, które funkcje ochrony włączyć.
    .label = Własna
preferences-etp-status-advanced-button =
    .label = Ustawienia zaawansowane
preferences-etp-tracker-count-enabled =
    .label = Liczba zablokowanych elementów śledzących na pasku adresu
preferences-etp-status-protections-dashboard-link =
    .description = Zobacz, ile podstępnych elementów śledzących { -brand-short-name } dla Ciebie zablokował, w tym elementy śledzące serwisów społecznościowych, elementy śledzące przez zbieranie informacji o konfiguracji i elementy używające komputera użytkownika do generowania kryptowalut.
    .label = Spersonalizowany panel ochrony
preferences-etp-header =
    .heading = Wzmocniona ochrona przed śledzeniem
preferences-etp-advanced-settings-group =
    .description = Witryny używają elementów śledzących, aby śledzić Cię w Internecie i wyświetlać podejrzane reklamy. { -brand-short-name } chroni Cię podczas przeglądania Internetu, automatycznie blokując większość elementów śledzących, dzięki czemu masz kontrolę nad swoim cyfrowym śladem.
    .label = Ustawienia zaawansowane
preferences-etp-customize-button =
    .label = Dostosuj ochronę przed śledzeniem
preferences-etp-reload-tabs-hint =
    .message = Odśwież karty, aby zastosować te zmiany.
preferences-etp-reload-tabs-hint-button =
    .label = Odśwież wszystkie karty
preferences-etp-rfp-warning-message =
    .message = Używasz funkcji RFP („Resist Fingerprinting”), która zastępuje część ustawień ochrony przed zbieraniem informacji o konfiguracji { -brand-short-name(case: "gen") }. Może to powodować problemy z działaniem niektórych stron.
preferences-etp-level-warning-message =
    .heading = Uwaga! Niektóre witryny mogą nie działać, jak powinny.
    .message = Niektóre witryny wbudowują elementy śledzące w swoje funkcje lub treść. Kiedy { -brand-short-name } je blokuje, witryna wydaje się uszkodzona. Spróbuj użyć ustawień „Naprawianie problemów ze stronami” lub wyłączyć na niej ochronę przed śledzeniem.
preferences-etp-manage-exceptions-button =
    .description = Zarządzaj witrynami, na których wzmocniona ochrona przed śledzeniem jest wyłączona.
    .label = Zarządzaj wyjątkami
preferences-etp-customize-header =
    .heading = Dostosuj ochronę przed śledzeniem
preferences-etp-reset =
    .description = Przywróć ustawienia do danego poziomu ochrony.
    .label = Przywróć modyfikacje
preferences-etp-reset-standard-button =
    .label = Przywróć na standardową
preferences-etp-reset-strict-button =
    .label = Przywróć na ścisłą
preferences-etp-custom-control-group =
    .description = Wybierz, które funkcje ochrony włączyć.
    .label = Ochrona przed śledzeniem
preferences-etp-custom-cookies-enabled =
    .label = Ciasteczka
preferences-etp-custom-cookie-behavior =
    .aria-label = Ciasteczka
preferences-etp-custom-cookie-behavior-accept-all =
    .label = Zezwalaj na wszystkie ciasteczka
preferences-etp-custom-cookie-behavior-block-cross-site-tracking-cookies =
    .label = Blokuj ciasteczka śledzące między witrynami
preferences-etp-custom-cookie-behavior-block-cross-site-cookies =
    .label = Blokuj ciasteczka między witrynami
preferences-etp-custom-cookie-behavior-isolate-cross-site-cookies =
    .label = Izoluj ciasteczka między witrynami
preferences-etp-custom-cookie-behavior-block-unvisited =
    .label = Blokuj ciasteczka nieodwiedzonych witryn
preferences-etp-custom-cookie-behavior-block-all-cross-site-cookies =
    .label = Blokuj wszystkie ciasteczka między witrynami (może powodować niepoprawne działanie stron)
preferences-etp-custom-cookie-behavior-block-all =
    .label = Blokuj wszystkie ciasteczka (spowoduje niepoprawne działanie stron)
preferences-etp-custom-tracking-protection-enabled =
    .label = Treści z elementami śledzącymi
preferences-etp-custom-tracking-protection-enabled-context =
    .aria-label = Treści z elementami śledzącymi
preferences-etp-custom-crypto-mining-protection-enabled =
    .label = Elementy używające komputera użytkownika do generowania kryptowalut
preferences-etp-custom-known-fingerprinting-protection-enabled =
    .label = Znane elementy śledzące przez zbieranie informacji o konfiguracji
preferences-etp-custom-suspect-fingerprinting-protection-enabled =
    .label = Podejrzewane elementy śledzące przez zbieranie informacji o konfiguracji
preferences-etp-custom-suspect-fingerprinting-protection-enabled-context =
    .aria-label = Podejrzewane elementy śledzące przez zbieranie informacji o konfiguracji

## Warnings section

security-privacy-issue-warning-fingerprinters =
    .description = Może to zezwolić niektórym elementom śledzącym na śledzenie Cię bez ciasteczek.
    .label = Znane elementy śledzące przez zbieranie informacji o konfiguracji nie są blokowane
security-privacy-issue-warning-third-party-cookies =
    .description = Ciasteczka zewnętrznych witryn są używane do śledzenia Cię między witrynami.
    .label = Ciasteczka zewnętrznych witryn są włączone
security-privacy-issue-warning-password-manager =
    .description = Menedżery haseł pomagają przechowywać silne hasła do Twoich kont.
    .label = Menedżer haseł jest wyłączony
security-privacy-issue-warning-popup-blocker =
    .description = Wyskakujące okna przeszkadzają i mogą być szkodliwe.
    .label = Blokowanie wyskakujących okien jest wyłączone
security-privacy-issue-warning-extension-install =
    .description = Witryny mogą instalować rozszerzenia w { -brand-short-name(case: "loc") } bez pytania.
    .label = Witryny mogą instalować rozszerzenia
security-privacy-issue-warning-safe-browsing =
    .description = Powoduje to większe narażenie na oszustwa i złośliwe oprogramowanie z witryn.
    .label = Niebezpieczne i podejrzane treści nie są blokowane
security-privacy-issue-warning-doh2 =
    .description = DNS poprzez HTTPS pomaga ukrywać przed dostawcą Internetu informacje o witrynach, które zostaną zaraz otwarte.
    .label = DNS poprzez HTTPS jest wyłączony
security-privacy-issue-warning-ech2 =
    .description = Funkcja „Encrypted Client Hello” pomaga ukrywać przed dostawcą Internetu informacje o witrynach, które zostaną zaraz otwarte.
    .label = Funkcja „Encrypted Client Hello” jest wyłączona
security-privacy-issue-warning-doh =
    .description = DNS poprzez HTTPS ukrywa przed dostawcą Internetu informacje o otwieranych witrynach.
    .label = DNS poprzez HTTPS jest wyłączony
security-privacy-issue-warning-ech =
    .description = Funkcja „Encrypted Client Hello” ukrywa przed dostawcą Internetu informacje o otwieranych witrynach.
    .label = Funkcja „Encrypted Client Hello” jest wyłączona
security-privacy-issue-warning-proxy-autodetection =
    .description = Automatyczna konfiguracja serwerów proxy może pozwolić niezaufanym sieciom na monitorowanie Twoich działań.
    .label = Automatyczna konfiguracja proxy jest włączona

## Referrals Section

# The header in settings with link to the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-section-header2 =
    .description = Zachęć kogoś do wybrania przeglądarki, która stawia prywatność na pierwszym miejscu.
    .label = Podziel się { -brand-product-name(case: "ins") }
# Link that opens the referral page, where the user can invite others to
# use the browser. "Share" here means recommending or referring the browser
referrals-link2 =
    .label = Podziel się { -brand-product-name(case: "ins") }


pane-vorbit-title = vOrbit-lite
vorbit-network-heading = Sieć
vorbit-privacy-heading = Prywatność
vorbit-header = Ustawienia vOrbit-lite
vorbit-warning-title = Uwaga!
vorbit-general-heading = Zachowanie przeglądarki
vorbit-ipv6-checkbox =
    .label = Włącz IPv6
vorbit-webgl-checkbox =
    .label = Włącz WebGL z ograniczeniami per witryna
vorbit-rfp-checkbox =
    .label = Włącz opcję ResistFingerprinting
vorbit-extension-update-checkbox =
    .label = Automatycznie aktualizuj rozszerzenia
vorbit-sync-checkbox =
    .label = Włącz Firefox Sync
vorbit-footer = Przydatne linki
vorbit-goog-safe-download-checkbox =
    .label = Skanuj pobrane pliki
vorbit-config-link = Wszystkie zaawansowane ustawienia (about:confg)
vorbit-open-profile = Otwórz katalog profilu użytkownika
vorbit-security-heading = Bezpieczeństwo
vorbit-goog-safe-download-description = Zezwól funkcji Safe Browsing na skanowanie pobrań w celu identyfikacji podejrzanych plików.
vorbit-goog-safe-description = Jeśli obawiasz się złośliwego oprogramowania lub phishingu, rozważ włączenie tej opcji.
content-blocking-section-top-level-description = vOrbit-lite wspiera — i domyślnie włącza — ulepszoną ochronę przed śledzeniem w trybie restrykcyjnym. Jest to jedno z najważniejszych ustawień w przeglądarce, ponieważ dostarcza rozdzielanie stanu, listy restrykcyjnego blokowania i inne przydatne funkcje prywatności. Nie zalecamy zmiany trybu na inny.
vorbit-goog-safe-download-warning1 = Wszystkie sprawdzenia odbywają się lokalnie.
vorbit-goog-safe-warning1 = Wyłączone ze względu na obawy o cenzurę ale rekomendowane dla mniej zaawansowanych użytkowników. Wszystkie sprawdzenia odbywają się lokalnie.
vorbit-styling-checkbox =
    .label = Zezwól na modyfikacje userChrome.css
vorbit-rfp-description = ResistFingerprinting jest jednym z najlepszych narzędzi zapobiegających identyfikacji.
vorbit-autocopy-checkbox =
    .label = Włącz wklejanie środkowym przyciskiem myszy
vorbit-extension-update-description = Aktualizuj rozszerzenia automatycznie. Jest to dobry wybór dla zapewnienia bezpieczeństwa.
vorbit-extension-update-warning1 = Jeśli nie sprawdzasz kodu źródłowego swoich rozszerzeń przed każdą aktualizacją powinieneś włączyć tę opcję.
vorbit-ipv6-description = Zezwól { -brand-short-name } na połączenia z użyciem IPv6.
vorbit-ipv6-warning1 = Zamiast blokady użycia IPv6 w przeglądarce zalecamy włączenie rozszerzenia prywatności IPv6 w systemie operacyjnym.
vorbit-webgl-description = Włącza WebGL z pytaniem o uprawnienia per witryna.
vorbit-webgl-warning1 = Gdy witryna spróbuje utworzyć kontekst WebGL, zostaniesz najpierw zapytany o udzielenie uprawnienia.
vorbit-rfp-warning1 = Jeśli musisz je wyłączyć, rozważ użycie rozszerzenia takiego jak Canvas Blocker.
vorbit-letterboxing-checkbox =
    .label = Włącz letterboxing
category-vorbit =
    .tooltiptext = Zmiany w about:config pogrupowane logicznie i łatwo dostępne
vorbit-warning-description = Dobraliśmy domyślne ustawienia z myślą o prywatności i bezpieczeństwie. Podczas ich modyfikacji czytaj opisy aby zrozumieć konsekwencje wprowadzonych zmian.
vorbit-broken-heading = Cyfrowy odcisk palca przeglądarki
vorbit-styling-warning1 = Upewnij się, że ufasz dostawcy motywu.
vorbit-xorigin-ref-description = Wyślij informacje o źródle żądania (referrer) tylko w obrębie tego samego serwera (same-origin).
vorbit-xorigin-ref-warning1 = Może spowodować błąd. Nawet jeśli żądanie zostanie wysłane, adres źródła żądania (referrer) zostanie obcięty.
vorbit-goog-safe-checkbox =
    .label = Włącz Google Safe Browsing
vorbit-sync-description = Synchronizuj dane z innymi przeglądarkami. Wymaga restartu.
vorbit-sync-warning1 = Firefox Sync szyfruje dane lokalnie przed przesłaniem do serwera.
vorbit-ocsp-checkbox =
    .label = Wymuś zrywanie połączeń w związku z OCSP
vorbit-xorigin-ref-checkbox =
    .label = Ogranicz przekazywanie źródeł żądania pomiędzy serwerami (cross-origin referrers)
vorbit-autocopy-description = Zaznacz tekst do skopiowania, następnie wklej korzystając ze środkowego przycisku myszy.
vorbit-styling-description = Włącz jeśli chcesz zmodyfikować interfejs użytkownika motywem wgranym samodzielnie.
vorbit-letterboxing-description = Letterboxing dodaje marginesy dookoła okna wyświetlania w celu redukcji liczby zwracanych przybliżonych rozdzielczości.
vorbit-ocsp-description = Zapobiegaj połączeniu do witryny jeśli sprawdzenia OCSP nie mogą zostać wykonane.
vorbit-ocsp-warning1 = Ta opcja zwiększa bezpieczeństwo ale spowoduje błąd połączenia kiedy serwer OCSP jest niedostępny.
permissions-webgl2 =
    .label = WebGL
vorbit-webgl-prompt-checkbox =
    .label = Ukryj okno WebGL wyskakujące per witryna
vorbit-webgl-prompt-description = Ukrywa wyskakujące okienko, które pojawia się, gdy witryna próbuje utworzyć kontekst WebGL. Możesz nadal ręcznie wywołać pytanie klikając ikonę w pasku wyszukiwania.
vorbit-general-heading2 =
    .label = Zachowanie przeglądarki
vorbit-extension-update-checkbox2 =
    .label = Aktualizuj rozszerzenia automatycznie
    .description = Utrzymuj rozszerzenia w bieżących wersjach bez ręcznej interwencji. Dobry wybór dla Twojego bezpieczeństwa.
vorbit-sync-checkbox2 =
    .label = Włącz Firefox Sync
    .description = Synchronizuj Twoje dane z innymi przeglądarkami. Wymaga ponownego uruchomienia.
vorbit-autocopy-checkbox2 =
    .label = Włącz wklejanie środkowym przyciskiem myszy
    .description = Zaznacz tekst aby go skopiować, następnie wklej klikając środkowym przyciskiem myszy.
vorbit-styling-checkbox2 =
    .label = Zezwól na dostosowywanie userChrome.css
    .description = Włącz jeśli chcesz dostosować interfejs użytkownika motywem wgranym samodzielnie.
vorbit-network-heading2 =
    .label = Sieć
vorbit-ipv6-checkbox2 =
    .label = Włącz IPv6
    .description = Zezwól { -brand-short-name } na łączenie się za pomocą IPv6.
vorbit-privacy-heading2 =
    .label = Prywatność
vorbit-xorigin-ref-checkbox2 =
    .label = Ogranicz przekazywanie źródeł żądania pomiędzy serwerami (cross-origin referrers)
    .description = Wyślij informacje o źródle żądania (referrer) tylko w obrębie tego samego serwera (same-origin).
vorbit-broken-heading2 =
    .label = Cyfrowy odcisk palca przeglądarki
vorbit-webgl-checkbox2 =
    .label = Zawsze zezwalaj na WebGL
    .description = To umożliwi witrynom używanie WebGL bez pytania o uprawnienia.
vorbit-webgl-prompt-checkbox2 =
    .label = Ukryj wyskakujący per witryna dialog WebGL
    .description = To ukrywa okienko dialogowe, które pojawia się, gdy witryna próbuje utworzyć kontekst WebGL. Możesz nadal ręcznie wywołać dialog klikając ikonkę w pasku wyszukiwania.
vorbit-rfp-checkbox2 =
    .label = Włącz ochronę przed wyliczaniem cyfrowego odcisku palca (ResistFingerprinting)
    .description = Włącza wszystkie dostępne mechanizmy ochrony przed wyliczaniem cyfrowego odcisku palca, ale może sprawić, że niektóre witryny będą działać nieprawidłowo.
vorbit-letterboxing-checkbox2 =
    .label = Włącz letterboxing
    .description = Letterboxing dodaje marginesy dookoła okna wyświetlania w celu redukcji liczby zwracanych przybliżonych rozdzielczości.
vorbit-security-heading2 =
    .label = Bezpieczeństwo
