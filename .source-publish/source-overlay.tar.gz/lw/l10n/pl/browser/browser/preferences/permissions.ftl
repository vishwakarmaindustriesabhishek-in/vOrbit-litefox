# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

permissions-window2 =
    .style = min-width: 35em
    .title = Wyjątki
permissions-close-key =
    .key = w
permissions-address = Adres witryny:
    .accesskey = s
permissions-block =
    .label = Blokuj
    .accesskey = B
permissions-disable-etp =
    .label = Dodaj wyjątek
    .accesskey = D
permissions-session =
    .label = Zezwalaj na czas sesji
    .accesskey = c
permissions-allow =
    .label = Zezwalaj
    .accesskey = Z
permissions-add =
    .label = Dodaj
    .accesskey = o
permissions-button-off =
    .label = Wyłącz
    .accesskey = W
permissions-button-off-temporarily =
    .label = Wyłącz tymczasowo
    .accesskey = m
permissions-site-name =
    .label = Witryna
permissions-status =
    .label = Stan
permissions-remove =
    .label = Usuń witrynę
    .accesskey = U
permissions-remove-all =
    .label = Usuń wszystkie witryny
    .accesskey = w
permissions-save-changes-2 =
    .buttonlabelaccept = Zachowaj
    .buttonaccesskeyaccept = h
permission-dialog =
    .buttonlabelaccept = Zachowaj
    .buttonaccesskeyaccept = h
permissions-autoplay-menu = Domyślne dla wszystkich witryn:
permissions-searchbox =
    .placeholder = Szukaj witryn
permissions-capabilities-autoplay-allow =
    .label = Zezwalaj na dźwięk i wideo
permissions-capabilities-autoplay-block =
    .label = Blokuj dźwięk
permissions-capabilities-autoplay-blockall =
    .label = Blokuj dźwięk i wideo
permissions-capabilities-allow =
    .label = Zezwalaj
permissions-capabilities-block =
    .label = Blokuj
permissions-capabilities-prompt =
    .label = Zawsze pytaj
permissions-capabilities-listitem-allow =
    .value = Zezwalaj
permissions-capabilities-listitem-block =
    .value = Blokuj
permissions-capabilities-listitem-allow-session =
    .value = Zezwalaj na czas sesji
permissions-capabilities-listitem-off =
    .value = Wyłącz
permissions-capabilities-listitem-off-temporarily =
    .value = Wyłącz tymczasowo

## Invalid Hostname Dialog

permissions-invalid-uri-title = Podano nieprawidłową nazwę witryny
permissions-invalid-uri-label = Podaj prawidłową nazwę witryny

## Exceptions - Tracking Protection

permissions-exceptions-etp-window2 =
    .style = { permissions-window2.style }
    .title = Wzmocniona ochrona przed śledzeniem — wyjątki
permissions-exceptions-manage-etp-desc = Określ, na których witrynach wyłączyć wzmocnioną ochronę przed śledzeniem. Podaj dokładny adres witryny, której ustawienia chcesz zmodyfikować, i kliknij Dodaj wyjątek.

## Exceptions - Cookies

permissions-exceptions-cookie-window2 =
    .style = { permissions-window2.style }
    .title = Ciasteczka i dane witryn — wyjątki
permissions-exceptions-cookie-desc = Określ zasady akceptacji ciasteczek i danych witryn. Podaj dokładny adres witryny, której uprawnienia chcesz zmodyfikować, a następnie kliknij Zezwalaj, Blokuj lub Zezwalaj na czas sesji.

## Exceptions - Clear on Shutdown

permissions-exceptions-shutdown-clearing-window =
    .style = { permissions-window2.style }
    .title = Czyszczenie historii podczas wyłączania — wyjątki
permissions-exceptions-shutdown-clearing-desc = Określ, których witryn dane nie będą usuwane, kiedy { -brand-short-name } czyści historię podczas zamykania. Podaj dokładny adres witryny, która będzie zarządzana przez użytkownika, i kliknij Zezwalaj.

## Exceptions - HTTPS-Only Mode

permissions-exceptions-https-only-window2 =
    .style = { permissions-window2.style }
    .title = Tryb używania wyłącznie protokołu HTTPS — wyjątki
permissions-exceptions-https-only-desc2 = Określ, na których witrynach nie korzystać z trybu używania wyłącznie protokołu HTTPS. { -brand-short-name } nie będzie próbował przełączyć na zabezpieczone połączenie HTTPS na tych witrynach.

## Exceptions - Pop-ups And Third-Party Redirects

permissions-exceptions-popup-window3 =
    .style = { permissions-window2.style }
    .title = Wyskakujące okna i zewnętrzne przekierowania — uprawnione witryny
permissions-exceptions-popup-desc2 = Określ, które witryny mogą otwierać wyskakujące okna i być przekierowywane przez zewnętrzne ramki.

## Exceptions - Saved Passwords

permissions-exceptions-saved-passwords-window =
    .style = { permissions-window2.style }
    .title = Zachowywanie hasła — wyjątki
permissions-exceptions-saved-passwords-desc = { -brand-short-name } nie będzie zachowywać haseł do wymienionych tutaj witryn.

## Exceptions - Add-ons

permissions-exceptions-addons-window2 =
    .style = { permissions-window2.style }
    .title = Instalacja dodatków — uprawnione witryny
permissions-exceptions-addons-desc = Określ, które witryny mogą instalować dodatki. Podaj dokładny adres witryny, której chcesz na to zezwolić, i kliknij Zezwalaj.

## Site Permissions - Autoplay

permissions-site-autoplay-window2 =
    .style = { permissions-window2.style }
    .title = Automatyczne odtwarzanie — uprawnione witryny
permissions-site-autoplay-desc = Zarządzaj witrynami, które nie korzystają z domyślnych ustawień automatycznego odtwarzania.

## Site Permissions - Notifications

permissions-site-notification-window2 =
    .style = { permissions-window2.style }
    .title = Wyświetlanie powiadomień — uprawnione witryny
permissions-site-notification-desc = Następujące strony prosiły o możliwość wyświetlania powiadomień. Określ, które witryny mogą je wyświetlać. Można także zablokować nowe prośby.
permissions-site-notification-disable-label =
    .label = Blokuj nowe prośby o możliwość wyświetlania powiadomień
permissions-site-notification-disable-desc = Uniemożliwi to witrynom spoza listy powyżej proszenie o możliwość wysyłania powiadomień. Zablokowanie powiadomień może spowodować, że niektóre funkcje witryny nie będą działać.
# Shown only where notifications can be delivered while the browser is closed.
permissions-site-notification-closed-delivery-label =
    .label = Zezwalaj na wyświetlanie powiadomień także po zamknięciu { -brand-short-name(case: "gen") }
# Notes that the operating system's own notification settings can still block
# notifications delivered while the browser is closed.
permissions-site-notification-closed-delivery-desc = Obowiązują również ustawienia powiadomień systemu operacyjnego.

## Site Permissions - Location

permissions-site-location-window2 =
    .style = { permissions-window2.style }
    .title = Informowanie o położeniu — uprawnione witryny
permissions-site-location-desc = Następujące strony prosiły o możliwość uzyskiwania informacji o położeniu. Określ, które witryny mogą je uzyskiwać. Można także zablokować nowe prośby.
permissions-site-location-disable-label =
    .label = Blokuj nowe prośby o możliwość uzyskiwania informacji o położeniu
permissions-site-location-disable-desc = Uniemożliwi to witrynom spoza listy powyżej proszenie o możliwość uzyskiwania informacji o położeniu. Zablokowanie uzyskiwania informacji o położeniu może spowodować, że niektóre funkcje witryny nie będą działać.

## Site Permissions - Virtual Reality

permissions-site-xr-window2 =
    .style = { permissions-window2.style }
    .title = Rzeczywistość wirtualna — uprawnione witryny
permissions-site-xr-desc = Następujące strony prosiły o dostęp do urządzeń rzeczywistości wirtualnej. Określ, które witryny mogą uzyskiwać do nich dostęp. Można także zablokować nowe prośby.
permissions-site-xr-disable-label =
    .label = Blokuj nowe prośby o dostęp do urządzeń rzeczywistości wirtualnej
permissions-site-xr-disable-desc = Uniemożliwi to witrynom spoza listy powyżej proszenie o dostęp do urządzeń rzeczywistości wirtualnej. Zablokowanie dostępu do urządzeń rzeczywistości wirtualnej może spowodować, że niektóre funkcje witryny nie będą działać.

## Site Permissions - App Links
## App links are links that a website can ask to open for you, like email
## (mailto:) links. Sites in this list are blocked from asking.

permissions-site-app-links-window =
    .style = { permissions-window2.style }
    .title = Odnośniki w aplikacjach — witryny bez zezwolenia
permissions-site-app-links-desc = Te witryny nie mogą prosić o otwieranie odnośników w aplikacjach, na przykład odnośników do poczty e-mail (mailto:). Usuń witrynę z listy, aby jej na to zezwolić.

## Site Permissions - Camera

permissions-site-camera-window2 =
    .style = { permissions-window2.style }
    .title = Udostępnianie kamery — uprawnione witryny
permissions-site-camera-desc = Następujące strony prosiły o dostęp do kamery. Określ, które witryny mogą uzyskiwać do niej dostęp. Można także zablokować nowe prośby.
permissions-site-camera-disable-label =
    .label = Blokuj nowe prośby o dostęp do kamery
permissions-site-camera-disable-desc = Uniemożliwi to witrynom spoza listy powyżej proszenie o dostęp do kamery. Zablokowanie dostępu do kamery może spowodować, że niektóre funkcje witryny nie będą działać.

## Site Permissions - Loopback network

permissions-site-localhost-window =
    .style = { permissions-window2.style }
    .title = Aplikacje i usługi na urządzeniu — uprawnione witryny
permissions-site-localhost-desc = Te strony prosiły o dostęp do aplikacji i usług na tym urządzeniu. Możesz na to zezwolić lub zablokować witrynom ten dostęp.
permissions-site-localhost-disable-label =
    .label = Blokuj nowe prośby o dostęp do aplikacji i usług na tym urządzeniu
permissions-site-localhost-disable-desc = Spowoduje to, że witryny spoza powyższej listy nie będą mogły prosić o dostęp do aplikacji i usług na tym urządzeniu. Może to sprawić, że niektóre funkcje witryny nie będą poprawnie działać.

## Site Permissions - Local network

permissions-site-local-network-window =
    .style = { permissions-window2.style }
    .title = Urządzenia w sieci lokalnej — uprawnione witryny
permissions-site-local-network-desc = Te strony prosiły o dostęp do aplikacji i usług na urządzeniach podłączonych do sieci lokalnej lub Wi-Fi. Możesz na to zezwolić lub zablokować witrynom ten dostęp.
permissions-site-local-network-disable-label =
    .label = Blokuj nowe prośby o dostęp do aplikacji i usług na urządzeniach podłączonych do sieci lokalnej lub Wi-Fi
permissions-site-local-network-disable-desc = Spowoduje to, że witryny spoza powyższej listy nie będą mogły prosić o dostęp do aplikacji i usług na urządzeniach podłączonych do sieci lokalnej lub Wi-Fi. Może to sprawić, że niektóre funkcje witryny nie będą poprawnie działać.

## Site Permissions - Microphone

permissions-site-microphone-window2 =
    .style = { permissions-window2.style }
    .title = Udostępnianie mikrofonu — uprawnione witryny
permissions-site-microphone-desc = Następujące strony prosiły o dostęp do mikrofonu. Określ, które witryny mogą uzyskiwać do niego dostęp. Można także zablokować nowe prośby.
permissions-site-microphone-disable-label =
    .label = Blokuj nowe prośby o dostęp do mikrofonu
permissions-site-microphone-disable-desc = Uniemożliwi to witrynom spoza listy powyżej proszenie o dostęp do mikrofonu. Zablokowanie dostępu do mikrofonu może spowodować, że niektóre funkcje witryny nie będą działać.

## Site Permissions - Speaker
##
## "Speaker" refers to an audio output device.

permissions-site-speaker-window =
    .style = { permissions-window2.style }
    .title = Wybieranie głośników — uprawnione witryny
permissions-site-speaker-desc = Następujące strony prosiły o możliwość wyboru wyjściowego urządzenia dźwiękowego. Określ, które witryny mogą je wybierać.
permissions-exceptions-doh-window =
    .style = { permissions-window2.style }
    .title = DNS poprzez HTTPS — wyjątki
permissions-exceptions-manage-doh-desc = { -brand-short-name } nie będzie używał zabezpieczonego serwera DNS na tych witrynach i ich poddomenach.
permissions-doh-entry-field = Wpisz nazwę domeny
    .accesskey = W
permissions-doh-add-exception =
    .label = Dodaj
    .accesskey = D
permissions-doh-col =
    .label = Domena
permissions-doh-remove =
    .label = Usuń
    .accesskey = U
permissions-doh-remove-all =
    .label = Usuń wszystkie
    .accesskey = w


permissions-site-webgl-window2 =
    .title = Ustawienia — uprawnienia WebGL
    .style = { permissions-window2.style }
permissions-site-webgl-desc = Następujące witryny chciały utworzyć kontekst WebGL. Możesz określić, którym witrynom można na to zezwolić. Możesz również zablokować nowe próby utworzenia kontekstu WebGL.
